MapStudio = MapStudio or {}
MapStudio.Tools = MapStudio.Tools or {}

function MapStudio.Tools.Register(id, definition)
    if type(id) ~= "string" or type(definition) ~= "table" then
        return
    end

    definition.id = id
    MapStudio.Tools[id] = definition
    MapStudio.RegisterTool(id, definition)
end

function MapStudio.Tools.Get(id)
    return MapStudio.Tools[id]
end

function MapStudio.Tools.GetAll()
    return MapStudio.Tools
end
