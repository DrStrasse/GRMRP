MapStudio.Tools.Register("select", {
    nameKey = "tool.select",
    icon = "icon16/cursor.png"
})
