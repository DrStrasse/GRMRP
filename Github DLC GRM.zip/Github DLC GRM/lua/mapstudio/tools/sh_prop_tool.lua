MapStudio.Tools.Register("place", {
    nameKey = "tool.place",
    icon = "icon16/brick_add.png"
})
