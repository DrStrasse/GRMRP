MapStudio.Tools.Register("scale", {
    nameKey = "tool.scale",
    icon = "icon16/shape_handles.png"
})
