MapStudio.Tools.Register("delete", {
    nameKey = "tool.delete",
    icon = "icon16/delete.png"
})
