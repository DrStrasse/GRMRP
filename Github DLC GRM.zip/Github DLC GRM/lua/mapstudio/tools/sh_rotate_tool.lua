MapStudio.Tools.Register("rotate", {
    nameKey = "tool.rotate",
    icon = "icon16/arrow_rotate_clockwise.png"
})
