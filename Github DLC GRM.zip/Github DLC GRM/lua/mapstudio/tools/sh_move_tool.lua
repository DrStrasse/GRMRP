MapStudio.Tools.Register("move", {
    nameKey = "tool.move",
    icon = "icon16/arrow_out.png"
})
