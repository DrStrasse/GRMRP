local PANEL = {}

function PANEL:Init()
    self:SetKeyboardInputEnabled(true)
    self:SetMouseInputEnabled(true)
end

function PANEL:Paint(width, height)
    return true
end

vgui.Register("MS_Frame", PANEL, "EditablePanel")
