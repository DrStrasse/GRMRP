local PANEL = {}

function PANEL:Init()
    self:SetTall(32)

    self.Label = vgui.Create("DLabel", self)
    self.Label:Dock(LEFT)
    self.Label:SetWide(92)
    self.Label:SetContentAlignment(4)
    MapStudio.Theme.StyleLabel(self.Label, true)

    self.Content = vgui.Create("DPanel", self)
    self.Content:Dock(FILL)
    self.Content:SetPaintBackground(false)
end

function PANEL:SetLabel(text)
    self.Label:SetText(text or "")
end

function PANEL:GetContent()
    return self.Content
end

vgui.Register("MS_PropertyRow", PANEL, "DPanel")
