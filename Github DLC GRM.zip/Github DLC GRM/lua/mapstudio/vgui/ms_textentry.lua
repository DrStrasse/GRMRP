local PANEL = {}

function PANEL:Init()
    self:SetFont("MapStudio.Label")
    self:SetTextColor(MapStudio.Theme.Colors.text)
    self:SetHighlightColor(MapStudio.Theme.Colors.accent)
    self:SetCursorColor(MapStudio.Theme.Colors.text)
    self:SetPaintBackground(false)
    self:SetTall(28)
end

function PANEL:Paint(width, height)
    surface.SetDrawColor(MapStudio.Theme.Colors.field)
    surface.DrawRect(0, 0, width, height)
    surface.SetDrawColor(MapStudio.Theme.Colors.border)
    surface.DrawOutlinedRect(0, 0, width, height, 1)
    self:DrawTextEntryText(self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor())
end

vgui.Register("MS_TextEntry", PANEL, "DTextEntry")
