local PANEL = {}

function PANEL:Init()
    self.ModelPath = ""
    self:SetSize(96, 112)
    self:SetText("")

    self.Icon = vgui.Create("SpawnIcon", self)
    self.Icon:SetSize(80, 80)
    self.Icon:SetPos(8, 6)
    self.Icon.DoClick = function()
        if self.DoClick then
            self:DoClick()
        end
    end
    self.Icon.DoDoubleClick = function()
        if self.DoDoubleClick then
            self:DoDoubleClick()
        end
    end
    self.Icon.DoRightClick = function()
        if self.DoRightClick then
            self:DoRightClick()
        end
    end

    self.Label = vgui.Create("DLabel", self)
    self.Label:SetPos(4, 88)
    self.Label:SetSize(88, 20)
    self.Label:SetContentAlignment(5)
    self.Label:SetFont("MapStudio.Small")
    self.Label:SetTextColor(MapStudio.Theme.Colors.text)
end

function PANEL:SetModelPath(path)
    self.ModelPath = path or ""

    if IsValid(self.Icon) then
        self.Icon:SetModel(self.ModelPath)
        self.Icon:SetTooltip(MapStudio.T("asset.tooltip_full_path", { model = self.ModelPath }))
    end

    if IsValid(self.Label) then
        self.Label:SetText(MapStudio.AssetBrowser.ShortName(self.ModelPath))
        self.Label:SetTooltip(MapStudio.T("asset.tooltip_full_path", { model = self.ModelPath }))
    end

    self:SetTooltip(MapStudio.T("asset.tooltip_full_path", { model = self.ModelPath }))
end

function PANEL:PerformLayout(width, height)
    if IsValid(self.Icon) then
        self.Icon:SetSize(80, 80)
        self.Icon:SetPos((width - 80) * 0.5, 6)
    end

    if IsValid(self.Label) then
        self.Label:SetPos(4, height - 24)
        self.Label:SetSize(width - 8, 20)
    end
end

function PANEL:Paint(width, height)
    local selected = self.Selected == true or (MapStudio.ClientState and MapStudio.ClientState.selectedModel == self.ModelPath)
    local color = selected and MapStudio.Theme.Colors.accent or (self:IsHovered() and MapStudio.Theme.Colors.panelAlt or MapStudio.Theme.Colors.panel)

    surface.SetDrawColor(color)
    surface.DrawRect(0, 0, width, height)

    surface.SetDrawColor(selected and MapStudio.Theme.Colors.text or MapStudio.Theme.Colors.border)
    surface.DrawOutlinedRect(0, 0, width, height, selected and 2 or 1)
end

vgui.Register("MS_ModelCard", PANEL, "DButton")
