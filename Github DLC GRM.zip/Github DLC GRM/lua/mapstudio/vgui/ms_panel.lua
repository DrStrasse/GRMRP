local PANEL = {}

function PANEL:Init()
    self:SetPaintBackground(false)
end

function PANEL:Paint(width, height)
    MapStudio.Theme.PaintPanel(self, width, height)
end

vgui.Register("MS_Panel", PANEL, "DPanel")
