local PANEL = {}

function PANEL:Init()
    self:SetFont("MapStudio.Label")
    self:SetTextColor(MapStudio.Theme.Colors.text)
    self:SetTall(30)
end

function PANEL:SetDanger(value)
    self.Danger = value == true
end

function PANEL:SetToggled(value)
    self.Toggled = value == true
end

function PANEL:Paint(width, height)
    if not self:IsEnabled() then
        surface.SetDrawColor(MapStudio.Theme.Colors.panelAlt)
        surface.DrawRect(0, 0, width, height)
        return
    end

    if self.Toggled == false then
        surface.SetDrawColor(MapStudio.Theme.Colors.panelAlt)
        surface.DrawRect(0, 0, width, height)
        surface.SetDrawColor(MapStudio.Theme.Colors.border)
        surface.DrawOutlinedRect(0, 0, width, height, 1)
        return
    end

    MapStudio.Theme.PaintButton(self, width, height, self.Danger)
end

vgui.Register("MS_Button", PANEL, "DButton")
