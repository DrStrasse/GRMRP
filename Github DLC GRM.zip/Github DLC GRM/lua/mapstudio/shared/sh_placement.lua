MapStudio = MapStudio or {}
MapStudio.Placement = MapStudio.Placement or {}

local placement = MapStudio.Placement

local function toVector(value, fallback)
    if isvector and isvector(value) then
        return Vector(value.x, value.y, value.z)
    end

    if type(value) == "table" then
        return Vector(tonumber(value.x or value[1]) or 0, tonumber(value.y or value[2]) or 0, tonumber(value.z or value[3]) or 0)
    end

    return fallback or Vector(0, 0, 0)
end

local function toAngle(value)
    if isangle and isangle(value) then
        return Angle(value.p, value.y, value.r)
    end

    if type(value) == "table" then
        return Angle(tonumber(value.p or value.pitch or value[1]) or 0, tonumber(value.y or value.yaw or value[2]) or 0, tonumber(value.r or value.roll or value[3]) or 0)
    end

    return Angle(0, 0, 0)
end

local function rotatedOffset(offset, ang)
    return (ang:Forward() * offset.x) + (ang:Right() * offset.y) + (ang:Up() * offset.z)
end

local function getCorners(bounds)
    local mins = bounds.mins
    local maxs = bounds.maxs

    return {
        Vector(mins.x, mins.y, mins.z),
        Vector(mins.x, mins.y, maxs.z),
        Vector(mins.x, maxs.y, mins.z),
        Vector(mins.x, maxs.y, maxs.z),
        Vector(maxs.x, mins.y, mins.z),
        Vector(maxs.x, mins.y, maxs.z),
        Vector(maxs.x, maxs.y, mins.z),
        Vector(maxs.x, maxs.y, maxs.z)
    }
end

function placement.BoundsFromEntity(ent)
    if not IsValid(ent) then
        return {
            mins = Vector(-8, -8, 0),
            maxs = Vector(8, 8, 16)
        }
    end

    local mins, maxs = ent:OBBMins(), ent:OBBMaxs()

    return {
        mins = Vector(mins.x, mins.y, mins.z),
        maxs = Vector(maxs.x, maxs.y, maxs.z)
    }
end

function placement.NormalizeBounds(bounds)
    bounds = type(bounds) == "table" and bounds or {}

    return {
        mins = toVector(bounds.mins, Vector(-8, -8, 0)),
        maxs = toVector(bounds.maxs, Vector(8, 8, 16))
    }
end

function placement.Calculate(model, hitPos, hitNormal, angles, mode, bounds)
    bounds = placement.NormalizeBounds(bounds)
    hitPos = toVector(hitPos, Vector(0, 0, 0))
    hitNormal = toVector(hitNormal, Vector(0, 0, 1))
    angles = toAngle(angles)

    if hitNormal:LengthSqr() <= 0 then
        hitNormal = Vector(0, 0, 1)
    end

    hitNormal:Normalize()

    local minProjection

    for _, corner in ipairs(getCorners(bounds)) do
        local projection = rotatedOffset(corner, angles):Dot(hitNormal)

        if minProjection == nil or projection < minProjection then
            minProjection = projection
        end
    end

    local clearance = mode == "center" and 0.5 or 0.25
    local pos = hitPos - hitNormal * (minProjection or 0) + hitNormal * clearance

    return {
        pos = pos,
        bounds = bounds,
        model = model,
        ang = angles
    }
end
