MapStudio = MapStudio or {}
MapStudio.Objects = MapStudio.Objects or {}

local objects = MapStudio.Objects

local SERIALIZABLE_OBJECT_FIELDS = {
    id = true,
    type = true,
    class = true,
    model = true,
    pos = true,
    ang = true,
    originalTransform = true,
    scale = true,
    skin = true,
    bodygroups = true,
    color = true,
    material = true,
    submaterials = true,
    renderMode = true,
    renderFx = true,
    collision = true,
    frozen = true,
    gravity = true,
    motion = true,
    reactive = true,
    behavior = true,
    layer = true,
    notes = true,
    createdBy = true,
    createdAt = true,
    updatedBy = true,
    updatedAt = true,
    noPhysicsFallback = true,
    spawnWarning = true,
    custom = true,
    entityData = true,
    keyValues = true
}

local function isTable(value)
    return type(value) == "table"
end

local function trim(value)
    if string.Trim then
        return string.Trim(value)
    end

    return string.gsub(value, "^%s*(.-)%s*$", "%1")
end

local function clamp(value, minValue, maxValue)
    value = tonumber(value) or 0

    if math.Clamp then
        return math.Clamp(value, minValue, maxValue)
    end

    return math.min(math.max(value, minValue), maxValue)
end

function objects.NormalizeAngleValue(value)
    value = tonumber(value) or 0

    if value ~= value or value == math.huge or value == -math.huge then
        return 0
    end

    local normalized = value % 360

    if normalized < 0 then
        normalized = normalized + 360
    end

    if normalized >= 359.999 or normalized < 0.001 then
        return 0
    end

    return normalized
end

function MapStudio.NormalizeAngleDegrees(value)
    return objects.NormalizeAngleValue(value)
end

local function copyTable(value)
    if not isTable(value) then
        return value
    end

    local result = {}

    for key, child in pairs(value) do
        result[key] = copyTable(child)
    end

    return result
end

function objects.SanitizeSerializable(value, depth)
    depth = tonumber(depth) or 0

    if depth > (MapStudio.Config.MaxSerializableDepth or 8) then
        return nil
    end

    local valueType = type(value)

    if valueType == "nil" or valueType == "boolean" or valueType == "string" then
        return value
    end

    if valueType == "number" then
        if value ~= value or value == math.huge or value == -math.huge then
            return nil
        end

        return value
    end

    if isvector and isvector(value) then
        return {
            x = tonumber(value.x) or 0,
            y = tonumber(value.y) or 0,
            z = tonumber(value.z) or 0
        }
    end

    if isangle and isangle(value) then
        return {
            p = objects.NormalizeAngleValue(value.p),
            y = objects.NormalizeAngleValue(value.y),
            r = objects.NormalizeAngleValue(value.r)
        }
    end

    if IsColor and IsColor(value) then
        return {
            r = clamp(value.r, 0, 255),
            g = clamp(value.g, 0, 255),
            b = clamp(value.b, 0, 255),
            a = clamp(value.a, 0, 255)
        }
    end

    if valueType ~= "table" then
        return nil
    end

    local result = {}

    for key, child in pairs(value) do
        local keyType = type(key)

        if keyType == "string" or keyType == "number" then
            local cleanChild = objects.SanitizeSerializable(child, depth + 1)

            if cleanChild ~= nil then
                result[key] = cleanChild
            end
        end
    end

    return result
end

function objects.MakeID()
    return "ms_" .. tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))
end

function objects.SanitizeProfileName(profile)
    profile = trim(tostring(profile or MapStudio.Config.DefaultProfile))
    profile = string.gsub(profile, "[^%w_%-]", "_")

    if profile == "" then
        profile = MapStudio.Config.DefaultProfile
    end

    return string.sub(profile, 1, MapStudio.Config.MaxProfileNameLength)
end

function MapStudio.NormalizeModelPath(path)
    if type(path) ~= "string" then
        return nil, "error.invalid_model"
    end

    path = trim(path)
    path = string.gsub(path, "\\", "/")
    local lowerPath = string.lower(path)

    if path == "" then
        return nil, "error.empty_model"
    end

    if string.find(path, "..", 1, true) or string.find(path, "%z") then
        return nil, "error.invalid_model_path"
    end

    if string.sub(lowerPath, 1, 7) ~= "models/" or string.sub(lowerPath, -4) ~= ".mdl" then
        return nil, "error.invalid_model_path"
    end

    return path
end

function objects.SanitizeModel(model)
    return MapStudio.NormalizeModelPath(model)
end

function objects.ModelExists(model)
    local cleanModel = MapStudio.NormalizeModelPath(model)

    if not cleanModel then
        return false
    end

    if util and util.IsValidModel then
        local ok, valid = pcall(util.IsValidModel, cleanModel)

        if ok and valid then
            return true
        end
    end

    if file and file.Exists then
        local lowerModel = string.lower(cleanModel)
        local okGame, existsGame = pcall(file.Exists, cleanModel, "GAME")

        if okGame and existsGame then
            return true
        end

        if lowerModel ~= cleanModel then
            okGame, existsGame = pcall(file.Exists, lowerModel, "GAME")

            if okGame and existsGame then
                return true
            end
        end

        local okMod, existsMod = pcall(file.Exists, cleanModel, "MOD")

        if okMod and existsMod then
            return true
        end

        if lowerModel ~= cleanModel then
            okMod, existsMod = pcall(file.Exists, lowerModel, "MOD")

            if okMod and existsMod then
                return true
            end
        end
    end

    return false
end

function objects.SanitizeVector(value, fallback)
    fallback = fallback or { x = 0, y = 0, z = 0 }

    if isvector and isvector(value) then
        value = { x = value.x, y = value.y, z = value.z }
    end

    if not isTable(value) then
        value = fallback
    end

    local bound = MapStudio.Config.WorldBound

    return {
        x = clamp(value.x or value[1] or fallback.x, -bound, bound),
        y = clamp(value.y or value[2] or fallback.y, -bound, bound),
        z = clamp(value.z or value[3] or fallback.z, -bound, bound)
    }
end

function objects.SanitizeAngle(value, fallback)
    fallback = fallback or { p = 0, y = 0, r = 0 }

    if isangle and isangle(value) then
        value = { p = value.p, y = value.y, r = value.r }
    end

    if not isTable(value) then
        value = fallback
    end

    return {
        p = objects.NormalizeAngleValue(value.p or value.pitch or value[1] or fallback.p),
        y = objects.NormalizeAngleValue(value.y or value.yaw or value[2] or fallback.y),
        r = objects.NormalizeAngleValue(value.r or value.roll or value[3] or fallback.r)
    }
end

function objects.SanitizeColor(value, fallback)
    fallback = fallback or { r = 255, g = 255, b = 255, a = 255 }

    if IsColor and IsColor(value) then
        value = { r = value.r, g = value.g, b = value.b, a = value.a }
    end

    if not isTable(value) then
        value = fallback
    end

    return {
        r = clamp(value.r or value[1] or fallback.r, 0, 255),
        g = clamp(value.g or value[2] or fallback.g, 0, 255),
        b = clamp(value.b or value[3] or fallback.b, 0, 255),
        a = clamp(value.a or value[4] or fallback.a, 0, 255)
    }
end

function objects.SanitizeBodygroups(value)
    local result = {}

    if not isTable(value) then
        return result
    end

    local maxBodygroups = MapStudio.Config.MaxBodygroups or 64

    for key, groupValue in pairs(value) do
        local group = tonumber(key)

        if group and group >= 0 and group < maxBodygroups then
            result[math.floor(group)] = math.floor(clamp(groupValue, 0, 32))
        end
    end

    return result
end

function objects.SanitizeSubmaterials(value)
    local result = {}

    if not isTable(value) then
        return result
    end

    local maxSubMaterials = MapStudio.Config.MaxSubMaterials or 64

    for key, material in pairs(value) do
        local index = tonumber(key)

        if index and index >= 0 and index < maxSubMaterials then
            result[math.floor(index)] = string.sub(trim(tostring(material or "")), 1, MapStudio.Config.MaxMaterialLength)
        end
    end

    return result
end

function objects.SanitizeLayerID(layerID)
    layerID = trim(tostring(layerID or "default"))
    layerID = string.gsub(layerID, "[^%w_%-]", "_")

    if layerID == "" then
        layerID = "default"
    end

    return string.sub(layerID, 1, 48)
end

function objects.SanitizeBehavior(value)
    value = string.lower(trim(tostring(value or "static")))

    if not MapStudio.Config.ObjectBehaviors[value] then
        return "static"
    end

    return value
end

function objects.SanitizeLayer(data, existing)
    local source = copyTable(existing or MapStudio.Config.DefaultLayer)

    if isTable(data) then
        for key, value in pairs(data) do
            source[key] = value
        end
    end

    source.id = objects.SanitizeLayerID(source.id)
    source.name = string.sub(trim(tostring(source.name or source.id)), 1, 64)
    source.color = objects.SanitizeColor(source.color, MapStudio.Config.DefaultLayer.color)
    source.visible = source.visible ~= false
    source.locked = source.locked == true

    return source
end

function objects.SanitizeOriginalTransform(value, currentPos, currentAng)
    value = isTable(value) and value or {}

    return {
        pos = objects.SanitizeVector(value.pos, currentPos),
        ang = objects.SanitizeAngle(value.ang, currentAng)
    }
end

function objects.SanitizeObject(data, existing)
    data = isTable(data) and data or {}

    local source = copyTable(MapStudio.Config.DefaultObject)
    local originalFallback

    if isTable(existing) then
        for key, value in pairs(existing) do
            source[key] = copyTable(value)
        end

        originalFallback = {
            pos = existing.originalTransform and existing.originalTransform.pos or existing.pos,
            ang = existing.originalTransform and existing.originalTransform.ang or existing.ang
        }
    end

    for key, value in pairs(data) do
        source[key] = copyTable(value)
    end

    local model, modelError = objects.SanitizeModel(source.model)
    if not model then
        return nil, modelError
    end

    local class = tostring(source.class or MapStudio.Config.DefaultClass)
    if not MapStudio.Config.AllowedClasses[class] then
        class = MapStudio.Config.DefaultClass
    end

    source.id = tostring(source.id or objects.MakeID())
    source.type = "prop"
    source.class = class
    source.model = model
    source.pos = objects.SanitizeVector(source.pos, MapStudio.Config.DefaultObject.pos)
    source.ang = objects.SanitizeAngle(source.ang, MapStudio.Config.DefaultObject.ang)
    source.originalTransform = objects.SanitizeOriginalTransform(source.originalTransform or source.OriginalTransform or originalFallback, source.pos, source.ang)
    source.OriginalTransform = nil
    source.scale = clamp(source.scale or 1, MapStudio.Config.MinScale, MapStudio.Config.MaxScale)
    source.skin = math.floor(clamp(source.skin or 0, 0, 255))
    source.bodygroups = objects.SanitizeBodygroups(source.bodygroups)
    source.color = objects.SanitizeColor(source.color, MapStudio.Config.DefaultObject.color)
    source.material = string.sub(trim(tostring(source.material or "")), 1, MapStudio.Config.MaxMaterialLength)
    source.submaterials = objects.SanitizeSubmaterials(source.submaterials or source.subMaterials)
    source.subMaterials = nil
    source.renderMode = math.floor(clamp(source.renderMode or source.render_mode or MapStudio.Config.DefaultObject.renderMode or 1, 0, 32))
    source.render_mode = nil
    source.renderFx = math.floor(clamp(source.renderFx or source.renderFX or source.render_fx or MapStudio.Config.DefaultObject.renderFx or 0, 0, 32))
    source.renderFX = nil
    source.render_fx = nil
    source.collision = source.collision ~= false
    source.frozen = source.frozen ~= false
    source.gravity = source.gravity == true
    source.motion = source.motion == true

    if data.reactive ~= nil then
        source.reactive = source.reactive == true
    else
        source.reactive = objects.SanitizeBehavior(source.behavior) == "reactive"
    end

    source.behavior = source.reactive and "reactive" or "static"

    if source.reactive then
        source.frozen = true
        source.motion = false
    end

    source.layer = objects.SanitizeLayerID(source.layer or MapStudio.Config.DefaultObject.layer)
    source.notes = string.sub(trim(tostring(source.notes or "")), 1, MapStudio.Config.MaxNotesLength)
    source.noPhysicsFallback = source.noPhysicsFallback == true
    source.spawnWarning = source.spawnWarning and string.sub(trim(tostring(source.spawnWarning)), 1, 128) or nil
    source.custom = objects.SanitizeSerializable(source.custom)
    source.entityData = objects.SanitizeSerializable(source.entityData)
    source.keyValues = objects.SanitizeSerializable(source.keyValues)

    for key in pairs(source) do
        if not SERIALIZABLE_OBJECT_FIELDS[key] then
            source[key] = nil
        end
    end

    return source
end

function objects.ToVector(value)
    value = objects.SanitizeVector(value)

    if Vector then
        return Vector(value.x, value.y, value.z)
    end

    return value
end

function objects.ToAngle(value)
    value = objects.SanitizeAngle(value)

    if Angle then
        return Angle(value.p, value.y, value.r)
    end

    return value
end

function objects.ToColor(value)
    value = objects.SanitizeColor(value)

    if Color then
        return Color(value.r, value.g, value.b, value.a)
    end

    return value
end

function objects.IsLayerLocked(layerID)
    return false
end
