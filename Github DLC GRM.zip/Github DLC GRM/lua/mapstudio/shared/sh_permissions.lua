MapStudio = MapStudio or {}

function MapStudio.GetPlayerRank(ply)
    if not IsValid(ply) then
        return ""
    end

    if ply.GetUserGroup then
        return string.lower(ply:GetUserGroup() or "")
    end

    return ""
end

local function replicatedBool(name, fallback)
    local conVar = GetConVar and GetConVar(name)

    if not conVar then
        return fallback == true
    end

    return conVar:GetBool()
end

function MapStudio.IsPrivilegedUser(ply)
    if not IsValid(ply) then
        return false
    end

    if ply.IsListenServerHost and ply:IsListenServerHost() then
        return true
    end

    if ply.IsSuperAdmin and ply:IsSuperAdmin() then
        return true
    end

    if MapStudio.Config.AllowedRanks[MapStudio.GetPlayerRank(ply)] then
        return true
    end

    return ply.IsAdmin and ply:IsAdmin() and MapStudio.Config.AllowedRanks.admin == true
end

function MapStudio.CanUse(ply, action)
    if SERVER and MapStudio.ServerCanUse then
        return MapStudio.ServerCanUse(ply, action, true)
    end

    if MapStudio.IsPrivilegedUser(ply) then
        return true
    end

    if SERVER and MapStudio.IsSteamIDWhitelisted and MapStudio.IsSteamIDWhitelisted(ply) then
        return true
    end

    if replicatedBool(MapStudio.Config.PermissionAllowPlayersConVar or "mapstudio_allow_players", false) then
        return true
    end

    return false
end
