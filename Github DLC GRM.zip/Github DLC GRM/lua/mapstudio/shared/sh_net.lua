MapStudio = MapStudio or {}
MapStudio.Net = MapStudio.Net or {}

MapStudio.Net.Messages = {
    RequestState = "ms_request_state",
    StateChunk = "ms_state_chunk",
    CreateObject = "ms_create_object",
    CreateObjects = "ms_create_objects",
    ObjectCreated = "ms_object_created",
    UpdateObject = "ms_update_object",
    UpdateObjects = "ms_update_objects",
    DeleteObject = "ms_delete_object",
    ClearObjects = "ms_clear_objects",
    SaveProfile = "ms_save_profile",
    LoadProfile = "ms_load_profile",
    ListProfiles = "ms_list_profiles",
    ProfileList = "ms_profile_list",
    SaveLayout = "ms_save_layout",
    LoadLayout = "ms_load_layout",
    DeleteLayout = "ms_delete_layout",
    ListLayouts = "ms_list_layouts",
    LayoutList = "ms_layout_list",
    LayerUpdate = "ms_layer_update",
    Notify = "ms_notify",
    ImportPermaProps = "ms_import_permaprops",
    OpenEditor = "ms_open_editor",
    OpenEditorResult = "ms_open_editor_result"
}

function MapStudio.Net.Get(name)
    return MapStudio.Net.Messages[name]
end
