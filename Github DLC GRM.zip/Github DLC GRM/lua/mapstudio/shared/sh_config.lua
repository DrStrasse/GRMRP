MapStudio = MapStudio or {}

MapStudio.Version = "1.0 Release"
MapStudio.Name = "MapStudio - In-Game Map Editor"
MapStudio.ShortName = "MapStudio"

MapStudio.Config = MapStudio.Config or {}

local config = MapStudio.Config

config.DefaultProfile = config.DefaultProfile or "default"
config.DefaultLanguage = config.DefaultLanguage or "en"
config.LanguageConVar = config.LanguageConVar or "mapstudio_language"
config.StorageRoot = config.StorageRoot or "mapstudio"
config.AutoSave = config.AutoSave ~= false
config.AutoSaveDelay = config.AutoSaveDelay or 0.5
config.MaxObjects = config.MaxObjects or 1000
config.WarningObjects = config.WarningObjects or 500
config.MaxNetChunkSize = config.MaxNetChunkSize or 56000
config.MinScale = config.MinScale or 0.05
config.MaxScale = config.MaxScale or 10
config.WorldBound = config.WorldBound or 32768
config.MaxNotesLength = config.MaxNotesLength or 512
config.MaxMaterialLength = config.MaxMaterialLength or 128
config.MaxSubMaterials = config.MaxSubMaterials or 64
config.MaxBodygroups = config.MaxBodygroups or 64
config.MaxProfileNameLength = config.MaxProfileNameLength or 48
config.DefaultClass = config.DefaultClass or "prop_physics"
config.ProtectPersistentObjects = config.ProtectPersistentObjects ~= false
config.ProtectFromDamage = config.ProtectFromDamage ~= false
config.AssetScanBatchSize = config.AssetScanBatchSize or 80
config.AssetIconBatchSize = config.AssetIconBatchSize or 70
config.DefaultGridSize = config.DefaultGridSize or 40
config.DefaultRotationSnap = config.DefaultRotationSnap or 15
config.MaxSerializableDepth = config.MaxSerializableDepth or 8
config.PermissionAllowPlayersConVar = config.PermissionAllowPlayersConVar or "mapstudio_allow_players"
config.PermissionWhitelistConVar = config.PermissionWhitelistConVar or "mapstudio_allowed_steamids"
config.PermissionPublicEditConVar = config.PermissionPublicEditConVar or "mapstudio_public_edit_existing"
config.DebugConVar = config.DebugConVar or "mapstudio_debug"

config.AllowedRanks = config.AllowedRanks or {
    superadmin = true,
    admin = true
}

config.RateLimits = config.RateLimits or {
    create = 0.2,
    update = 0.1,
    delete = 0.2,
    save = 1,
    load = 1,
    layer = 0.2,
    import = 1,
    clear = 1,
    open = 0.5
}

config.AllowedClasses = config.AllowedClasses or {
    prop_physics = true,
    prop_physics_multiplayer = true,
    prop_dynamic = true
}

config.ObjectBehaviors = config.ObjectBehaviors or {
    static = true,
    reactive = true
}

config.DefaultLayer = config.DefaultLayer or {
    id = "default",
    name = "Default",
    nameKey = "layer.default",
    color = { r = 75, g = 149, b = 255, a = 255 },
    visible = true,
    locked = false
}

config.DefaultObject = config.DefaultObject or {
    type = "prop",
    class = "prop_physics",
    model = "models/props_c17/oildrum001.mdl",
    pos = { x = 0, y = 0, z = 0 },
    ang = { p = 0, y = 0, r = 0 },
    scale = 1,
    skin = 0,
    bodygroups = {},
    color = { r = 255, g = 255, b = 255, a = 255 },
    material = "",
    submaterials = {},
    renderMode = 1,
    renderFx = 0,
    collision = true,
    frozen = true,
    gravity = false,
    motion = false,
    reactive = false,
    behavior = "static",
    layer = "default",
    notes = ""
}

config.CommonModels = config.CommonModels or {
    "models/props_c17/oildrum001.mdl",
    "models/props_c17/chair02a.mdl",
    "models/props_c17/FurnitureTable001a.mdl",
    "models/props_c17/FurnitureShelf001a.mdl",
    "models/props_c17/bench01a.mdl",
    "models/props_junk/wood_crate001a.mdl",
    "models/props_junk/wood_pallet001a.mdl",
    "models/props_junk/TrafficCone001a.mdl",
    "models/props_wasteland/controlroom_chair001a.mdl",
    "models/props_wasteland/kitchen_counter001b.mdl",
    "models/props_interiors/Furniture_Couch01a.mdl",
    "models/props_interiors/Furniture_Desk01a.mdl",
    "models/props_borealis/bluebarrel001.mdl"
}

config.AssetModelFolders = config.AssetModelFolders or {
    {
        id = "garrysmod",
        nameKey = "asset.category_garrysmod",
        roots = {
            "models/props_phx",
            "models/hunter",
            "models/maxofs2d",
            "models/sprops"
        }
    },
    {
        id = "halflife2",
        nameKey = "asset.category_halflife2",
        roots = {
            "models/props_c17",
            "models/props_junk",
            "models/props_wasteland",
            "models/props_interiors",
            "models/props_lab",
            "models/props_combine",
            "models/props_borealis",
            "models/props_trainstation",
            "models/props_debris",
            "models/props_vehicles",
            "models/props_canal",
            "models/props_docks",
            "models/props_foliage",
            "models/props_buildings"
        }
    },
    {
        id = "css",
        nameKey = "asset.category_css",
        roots = {
            "models/props/cs_assault",
            "models/props/cs_italy",
            "models/props/de_dust",
            "models/props/de_inferno",
            "models/props/de_nuke",
            "models/props/de_train"
        }
    }
}
