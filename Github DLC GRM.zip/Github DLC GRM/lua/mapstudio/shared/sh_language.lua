MapStudio = MapStudio or {}
MapStudio.Lang = MapStudio.Lang or {}

local lang = MapStudio.Lang

lang.Languages = lang.Languages or {}
lang.Current = lang.Current or "en"

local function trim(value)
    if string.Trim then
        return string.Trim(value)
    end

    return string.gsub(value, "^%s*(.-)%s*$", "%1")
end

function lang.Register(code, phrases)
    if type(code) == "string" and type(phrases) == "table" then
        lang.Languages[string.lower(code)] = phrases
    end
end

function lang.DetectLanguage()
    if CLIENT then
        local conVar = GetConVar and GetConVar("gmod_language")
        local gameLanguage = conVar and string.lower(conVar:GetString() or "") or ""

        if string.find(gameLanguage, "ru", 1, true) or string.find(gameLanguage, "russian", 1, true) then
            return "ru"
        end

        if system and system.GetCountry and string.lower(system.GetCountry() or "") == "ru" then
            return "ru"
        end
    end

    return "en"
end

function lang.NormalizeLanguage(code)
    code = type(code) == "string" and string.lower(trim(code)) or MapStudio.Config.DefaultLanguage

    if code == "auto" then
        return MapStudio.Config.DefaultLanguage or "en"
    end

    if lang.Languages[code] then
        return code
    end

    return "en"
end

function lang.SetLanguage(code)
    lang.Current = lang.NormalizeLanguage(code)

    if CLIENT and hook then
        hook.Run("MapStudioLanguageChanged", lang.Current)
    end

    return lang.Current
end

function lang.GetLanguage()
    return lang.Current or "en"
end

function lang.Exists(key)
    local current = lang.Languages[lang.Current]
    local english = lang.Languages.en

    return (type(current) == "table" and current[key] ~= nil) or (type(english) == "table" and english[key] ~= nil)
end

function lang.Format(text, replacements)
    if type(text) ~= "string" or type(replacements) ~= "table" then
        return text
    end

    return (string.gsub(text, "{([%w_%.%-]+)}", function(name)
        local value = replacements[name]
        return value == nil and ("{" .. name .. "}") or tostring(value)
    end))
end

function lang.Get(key, replacements)
    if type(key) ~= "string" then
        return ""
    end

    local current = lang.Languages[lang.Current]
    local english = lang.Languages.en
    local text = type(current) == "table" and current[key] or nil

    if text == nil and type(english) == "table" then
        text = english[key]
    end

    return lang.Format(text or key, replacements)
end

function lang.RefreshFromConVar()
    if not CLIENT or not GetConVar then
        return lang.SetLanguage(MapStudio.Config.DefaultLanguage or "en")
    end

    local conVar = GetConVar(MapStudio.Config.LanguageConVar)
    return lang.SetLanguage(conVar and conVar:GetString() or (MapStudio.Config.DefaultLanguage or "en"))
end

function MapStudio.T(key, replacements)
    return lang.Get(key, replacements)
end
