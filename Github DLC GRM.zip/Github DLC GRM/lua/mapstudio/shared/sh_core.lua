MapStudio = MapStudio or {}

MapStudio.State = MapStudio.State or nil
MapStudio.Extensions = MapStudio.Extensions or {
    objectTypes = {},
    tools = {},
    panels = {},
    importers = {},
    layerActions = {}
}

function MapStudio.DeepCopy(value)
    if type(value) ~= "table" then
        return value
    end

    local result = {}

    for key, child in pairs(value) do
        result[key] = MapStudio.DeepCopy(child)
    end

    return result
end

function MapStudio.GetMapName()
    if game and game.GetMap then
        return game.GetMap() or "unknown"
    end

    return "unknown"
end

function MapStudio.GetDefaultLayer()
    return MapStudio.Objects.SanitizeLayer(MapStudio.Config.DefaultLayer)
end

function MapStudio.CreateEmptyState(mapName, profile)
    local defaultLayer = MapStudio.GetDefaultLayer()

    return {
        version = MapStudio.Version,
        map = mapName or MapStudio.GetMapName(),
        profile = MapStudio.Objects.SanitizeProfileName(profile),
        updatedAt = os.time(),
        layers = {
            [defaultLayer.id] = defaultLayer
        },
        objects = {},
        warnings = {}
    }
end

function MapStudio.SetState(state)
    MapStudio.State = state or MapStudio.CreateEmptyState()
    MapStudio.State.layers = MapStudio.State.layers or {}
    MapStudio.State.objects = MapStudio.State.objects or {}
    MapStudio.State.warnings = MapStudio.State.warnings or {}

    if not MapStudio.State.layers.default then
        local defaultLayer = MapStudio.GetDefaultLayer()
        MapStudio.State.layers[defaultLayer.id] = defaultLayer
    end

    return MapStudio.State
end

function MapStudio.GetState()
    if not MapStudio.State then
        MapStudio.SetState(MapStudio.CreateEmptyState())
    end

    return MapStudio.State
end

function MapStudio.GetObjectCount()
    local count = 0

    for _ in pairs(MapStudio.GetState().objects or {}) do
        count = count + 1
    end

    return count
end

function MapStudio.GetLayerCount()
    local count = 0

    for _ in pairs(MapStudio.GetState().layers or {}) do
        count = count + 1
    end

    return count
end

function MapStudio.RegisterObjectType(id, definition)
    MapStudio.Extensions.objectTypes[id] = definition
end

function MapStudio.RegisterTool(id, definition)
    MapStudio.Extensions.tools[id] = definition
end

function MapStudio.RegisterPanel(id, title, buildFunc)
    MapStudio.Extensions.panels[id] = { title = title, build = buildFunc }
end

function MapStudio.RegisterImporter(id, definition)
    MapStudio.Extensions.importers[id] = definition
end

function MapStudio.RegisterLayerAction(id, definition)
    MapStudio.Extensions.layerActions[id] = definition
end

function MapStudio.Objects.Create(data)
    local objectData, err = MapStudio.Objects.SanitizeObject(data)

    if not objectData then
        return nil, err
    end

    MapStudio.GetState().objects[objectData.id] = objectData
    return objectData
end

function MapStudio.Objects.Update(id, patch)
    local state = MapStudio.GetState()
    local existing = state.objects[id]

    if not existing then
        return nil, "error.invalid_object"
    end

    local objectData, err = MapStudio.Objects.SanitizeObject(patch or {}, existing)

    if not objectData then
        return nil, err
    end

    objectData.id = id
    state.objects[id] = objectData

    return objectData
end

function MapStudio.Objects.Delete(id)
    local state = MapStudio.GetState()
    local existing = state.objects[id]

    if not existing then
        return nil, "error.invalid_object"
    end

    state.objects[id] = nil
    return existing
end

function MapStudio.Objects.Get(id)
    return MapStudio.GetState().objects[id]
end

function MapStudio.Objects.GetAll()
    return MapStudio.GetState().objects
end

function MapStudio.IsDebugEnabled()
    local name = MapStudio.Config and MapStudio.Config.DebugConVar or "mapstudio_debug"
    local conVar = GetConVar and GetConVar(name)

    return conVar and conVar:GetBool() or false
end

function MapStudio.Log(message, level)
    level = level and string.upper(tostring(level)) or nil
    local prefix = "[MapStudio] "

    if level and level ~= "" then
        prefix = prefix .. level .. ": "
    end

    if MsgC and Color then
        local color = level == "ERROR" and Color(235, 80, 80) or level == "WARNING" and Color(255, 185, 70) or Color(90, 160, 255)
        MsgC(color, prefix, color_white, tostring(message) .. "\n")
    else
        print(prefix .. tostring(message))
    end
end

function MapStudio.LogWarning(message)
    MapStudio.Log(message, "WARNING")
end

function MapStudio.LogError(message)
    MapStudio.Log(message, "ERROR")
end

function MapStudio.Debug(message)
    if MapStudio.IsDebugEnabled() then
        MapStudio.Log(message, "DEBUG")
    end
end
