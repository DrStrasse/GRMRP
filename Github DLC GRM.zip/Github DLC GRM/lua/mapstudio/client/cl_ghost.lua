MapStudio = MapStudio or {}
MapStudio.Ghost = MapStudio.Ghost or {}

local ghost = MapStudio.Ghost

ghost.Entity = nil
ghost.Model = MapStudio.Config.DefaultObject.model
ghost.Ang = Angle(0, 0, 0)
ghost.Trace = nil
ghost.Bounds = nil
ghost.PlacePos = nil
ghost.ValidPlacement = true
ghost.FreePlacementDepth = nil
ghost.FreePlacementActive = false
ghost.SnapContext = nil
ghost.Template = nil
ghost.GroupTemplate = nil
ghost.GroupEntities = ghost.GroupEntities or {}

local GHOST_COLOR = Color(75, 149, 255, 170)
local GHOST_RENDER_MODE = RENDERMODE_TRANSCOLOR or RENDERMODE_TRANSALPHA
local FREE_DEPTH_DEFAULT = 512
local FREE_DEPTH_MIN = 24
local FREE_DEPTH_MAX = 12000
local RING_ANGLE_FIELDS = {
    rot_x = "r",
    rot_y = "p",
    rot_z = "y"
}
local RINGS = {
    rot_x = { normal = Vector(1, 0, 0) },
    rot_y = { normal = Vector(0, 1, 0) },
    rot_z = { normal = Vector(0, 0, 1) }
}

local function copyVector(vec)
    return Vector(vec.x, vec.y, vec.z)
end

local function vectorToTable(vec)
    return { x = vec.x, y = vec.y, z = vec.z }
end

local function angleToTable(ang)
    return {
        p = MapStudio.Objects.NormalizeAngleValue(ang.p),
        y = MapStudio.Objects.NormalizeAngleValue(ang.y),
        r = MapStudio.Objects.NormalizeAngleValue(ang.r)
    }
end

local function applyRingDelta(baseAng, handle, delta)
    local clean = MapStudio.Objects.SanitizeAngle(baseAng)
    local field = RING_ANGLE_FIELDS[handle]

    if not field then
        return Angle(clean.p, clean.y, clean.r)
    end

    clean[field] = MapStudio.Objects.NormalizeAngleValue((clean[field] or 0) + (tonumber(delta) or 0))
    return Angle(clean.p, clean.y, clean.r)
end

local function rotateVectorAroundAxis(vec, axis, degrees)
    axis = Vector(axis.x, axis.y, axis.z)

    if axis:LengthSqr() <= 0.0001 then
        return copyVector(vec)
    end

    axis:Normalize()

    local radians = math.rad(tonumber(degrees) or 0)
    local c = math.cos(radians)
    local s = math.sin(radians)

    return vec * c + axis:Cross(vec) * s + axis * (axis:Dot(vec) * (1 - c))
end

local function rotateAngleAroundAxis(baseAng, axis, degrees, fallbackHandle)
    local ang = MapStudio.Objects.ToAngle(baseAng)
    axis = Vector(axis.x, axis.y, axis.z)

    if axis:LengthSqr() <= 0.0001 then
        return ang
    end

    axis:Normalize()

    if ang.RotateAroundAxis then
        ang:RotateAroundAxis(axis, tonumber(degrees) or 0)
        return Angle(
            MapStudio.Objects.NormalizeAngleValue(ang.p),
            MapStudio.Objects.NormalizeAngleValue(ang.y),
            MapStudio.Objects.NormalizeAngleValue(ang.r)
        )
    end

    return applyRingDelta(baseAng, fallbackHandle, degrees)
end

local function validBounds(mins, maxs)
    return mins and maxs and (maxs - mins):LengthSqr() > 1
end

local function getModelBounds(ent)
    local mins, maxs

    if ent.GetRenderBounds then
        mins, maxs = ent:GetRenderBounds()
    end

    if not validBounds(mins, maxs) then
        mins, maxs = ent:OBBMins(), ent:OBBMaxs()
    end

    if not validBounds(mins, maxs) then
        mins, maxs = Vector(-16, -16, -16), Vector(16, 16, 16)
    end

    return copyVector(mins), copyVector(maxs)
end

local function paddedBounds(mins, maxs)
    local extent = maxs - mins
    local pad = math.Clamp(extent:Length() * 0.12, 64, 2048)
    local padding = Vector(pad, pad, pad)

    return mins - padding, maxs + padding
end

local function rotatedOffset(offset, ang)
    return (ang:Forward() * offset.x) + (ang:Right() * offset.y) + (ang:Up() * offset.z)
end

local function worldBounds(pos, ang, mins, maxs)
    local corners = {
        Vector(mins.x, mins.y, mins.z),
        Vector(mins.x, mins.y, maxs.z),
        Vector(mins.x, maxs.y, mins.z),
        Vector(mins.x, maxs.y, maxs.z),
        Vector(maxs.x, mins.y, mins.z),
        Vector(maxs.x, mins.y, maxs.z),
        Vector(maxs.x, maxs.y, mins.z),
        Vector(maxs.x, maxs.y, maxs.z)
    }
    local worldMins
    local worldMaxs

    for _, corner in ipairs(corners) do
        local point = pos + rotatedOffset(corner, ang)

        if not worldMins then
            worldMins = Vector(point.x, point.y, point.z)
            worldMaxs = Vector(point.x, point.y, point.z)
        else
            worldMins.x = math.min(worldMins.x, point.x)
            worldMins.y = math.min(worldMins.y, point.y)
            worldMins.z = math.min(worldMins.z, point.z)
            worldMaxs.x = math.max(worldMaxs.x, point.x)
            worldMaxs.y = math.max(worldMaxs.y, point.y)
            worldMaxs.z = math.max(worldMaxs.z, point.z)
        end
    end

    return worldMins, worldMaxs
end

local function includeBoundsPoint(mins, maxs, point)
    if not mins then
        return Vector(point.x, point.y, point.z), Vector(point.x, point.y, point.z)
    end

    mins.x = math.min(mins.x, point.x)
    mins.y = math.min(mins.y, point.y)
    mins.z = math.min(mins.z, point.z)
    maxs.x = math.max(maxs.x, point.x)
    maxs.y = math.max(maxs.y, point.y)
    maxs.z = math.max(maxs.z, point.z)

    return mins, maxs
end

local function boundsCorners(mins, maxs)
    return {
        Vector(mins.x, mins.y, mins.z),
        Vector(mins.x, mins.y, maxs.z),
        Vector(mins.x, maxs.y, mins.z),
        Vector(mins.x, maxs.y, maxs.z),
        Vector(maxs.x, mins.y, mins.z),
        Vector(maxs.x, mins.y, maxs.z),
        Vector(maxs.x, maxs.y, mins.z),
        Vector(maxs.x, maxs.y, maxs.z)
    }
end

local function applyGhostAppearance(ent)
    if not IsValid(ent) then
        return
    end

    ent.MapStudioGhost = true
    ent:SetRenderMode(GHOST_RENDER_MODE)
    ent:SetColor(GHOST_COLOR)
    ent:SetMaterial("")
    ent.RenderOverride = function(self)
        cam.IgnoreZ(true)
        render.SetBlend(GHOST_COLOR.a / 255)
        render.SetColorModulation(GHOST_COLOR.r / 255, GHOST_COLOR.g / 255, GHOST_COLOR.b / 255)
        self:DrawModel()
        render.SetColorModulation(1, 1, 1)
        render.SetBlend(1)
        cam.IgnoreZ(false)
    end
end

local function applyTemplateShape(ent, template)
    template = template or ghost.Template

    if not IsValid(ent) or type(template) ~= "table" then
        return
    end

    ent:SetSkin(template.skin or 0)

    for group, value in pairs(template.bodygroups or {}) do
        ent:SetBodygroup(tonumber(group) or 0, tonumber(value) or 0)
    end

    if ent.SetModelScale then
        ent:SetModelScale(template.scale or 1, 0)
    end
end

local function isGroupActive()
    return type(ghost.GroupTemplate) == "table" and type(ghost.GroupTemplate.items) == "table"
end

local function removeSingleEntity()
    if IsValid(ghost.Entity) then
        ghost.Entity:Remove()
    end

    ghost.Entity = nil
end

local function clearGroupEntities()
    for _, ent in ipairs(ghost.GroupEntities or {}) do
        if IsValid(ent) then
            ent:Remove()
        end
    end

    ghost.GroupEntities = {}
    ghost.GroupTemplate = nil
end

local function removeGroupEntitiesOnly()
    for _, ent in ipairs(ghost.GroupEntities or {}) do
        if IsValid(ent) then
            ent:Remove()
        end
    end

    ghost.GroupEntities = {}
end

local function groupFilterEnts()
    if #(ghost.GroupEntities or {}) == 1 then
        return ghost.GroupEntities[1]
    end

    return ghost.GroupEntities
end

local function isGhostEntity(ent)
    if IsValid(ghost.Entity) and ent == ghost.Entity then
        return true
    end

    for _, groupEnt in ipairs(ghost.GroupEntities or {}) do
        if IsValid(groupEnt) and ent == groupEnt then
            return true
        end
    end

    return false
end

local function ensureGroupEntities()
    if not isGroupActive() then
        return false
    end

    if #(ghost.GroupEntities or {}) == #(ghost.GroupTemplate.items or {}) then
        local valid = true

        for _, ent in ipairs(ghost.GroupEntities or {}) do
            if not IsValid(ent) then
                valid = false
                break
            end
        end

        if valid then
            return true
        end
    end

    local template = ghost.GroupTemplate
    removeGroupEntitiesOnly()
    ghost.GroupTemplate = template

    if not isGroupActive() then
        return false
    end

    for _, item in ipairs(ghost.GroupTemplate.items or {}) do
        local template = item.template

        if template and template.model then
            local ent = ClientsideModel(template.model, RENDERGROUP_TRANSLUCENT)

            if IsValid(ent) then
                ent:SetModelScale(1, 0)
                applyGhostAppearance(ent)
                applyTemplateShape(ent, template)
                ent:SetNoDraw(false)
                table.insert(ghost.GroupEntities, ent)
            end
        end
    end

    return #(ghost.GroupEntities or {}) > 0
end

local function groupBoundsFromTemplate()
    if not isGroupActive() then
        return nil
    end

    ensureGroupEntities()

    local mins
    local maxs

    for index, item in ipairs(ghost.GroupTemplate.items or {}) do
        local template = item.template

        if template then
            local ent = ghost.GroupEntities and ghost.GroupEntities[index]
            local obbMins
            local obbMaxs

            if IsValid(ent) then
                obbMins, obbMaxs = getModelBounds(ent)
            else
                obbMins, obbMaxs = Vector(-8, -8, 0), Vector(8, 8, 16)
            end

            local relPos = MapStudio.Objects.ToVector(item.relPos)
            local ang = MapStudio.Objects.ToAngle(template.ang)

            for _, corner in ipairs(boundsCorners(obbMins, obbMaxs)) do
                local point = relPos + rotatedOffset(corner, ang)
                mins, maxs = includeBoundsPoint(mins, maxs, point)
            end
        end
    end

    if not mins or not maxs then
        return nil
    end

    return {
        mins = mins,
        maxs = maxs
    }
end

function ghost.UpdateRenderBounds(pos, ang)
    if not IsValid(ghost.Entity) then
        return
    end

    if ghost.Entity.SetupBones then
        ghost.Entity:SetupBones()
    end

    local mins, maxs = getModelBounds(ghost.Entity)
    local renderMins, renderMaxs = paddedBounds(mins, maxs)

    ghost.Entity:SetRenderBounds(renderMins, renderMaxs)

    if ghost.Entity.SetRenderBoundsWS and pos and ang then
        local worldMins, worldMaxs = worldBounds(pos, ang, renderMins, renderMaxs)
        ghost.Entity:SetRenderBoundsWS(worldMins, worldMaxs)
    end
end

function ghost.IsActive()
    return MapStudio.ClientState and MapStudio.ClientState.tool == "place" and ghost.Model ~= nil
end

local function freePropsEnabled()
    return MapStudio.Editor and MapStudio.Editor.IsFreePropsEnabled and MapStudio.Editor.IsFreePropsEnabled()
end

local function mouseRay()
    local startPos = MapStudio.Freecam.Active and MapStudio.Freecam.Pos or EyePos()
    local direction = MapStudio.Freecam.Active and MapStudio.Freecam.Ang:Forward() or EyeAngles():Forward()
    local mouseX, mouseY = gui.MousePos()

    if gui.ScreenToVector and mouseX and mouseY and mouseX >= 0 and mouseY >= 0 then
        direction = gui.ScreenToVector(mouseX, mouseY)
    end

    direction:Normalize()

    return startPos, direction
end

function ghost.ResetFreePlacement()
    ghost.FreePlacementDepth = nil
    ghost.FreePlacementActive = false

    if MapStudio.Grid and ghost.SnapContext then
        MapStudio.Grid.ClearActiveContext(ghost.SnapContext)
    end

    ghost.SnapContext = nil
end

local function resetSnapContext()
    if MapStudio.Grid and ghost.SnapContext then
        MapStudio.Grid.ClearActiveContext(ghost.SnapContext)
    end

    ghost.SnapContext = nil
end

function ghost.InitializeFreePlacementDepth()
    local startPos, direction = mouseRay()
    local trace = util.TraceLine({
        start = startPos,
        endpos = startPos + direction * FREE_DEPTH_MAX,
        filter = function(ent)
            if not IsValid(ent) then return true end
            local ply = LocalPlayer()
            if IsValid(ply) and ent == ply then return false end
            if IsValid(ply) then
                local weapon = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
                if IsValid(weapon) and ent == weapon then return false end
            end
            if isGhostEntity(ent) then return false end
            return true
        end,
        mask = MASK_SOLID
    })

    if trace and trace.Hit and not trace.HitSky then
        ghost.FreePlacementDepth = math.Clamp(startPos:Distance(trace.HitPos), FREE_DEPTH_MIN, FREE_DEPTH_MAX)
    else
        ghost.FreePlacementDepth = FREE_DEPTH_DEFAULT
    end

    ghost.FreePlacementActive = true
    resetSnapContext()
end

function ghost.Cancel()
    MapStudio.ClientState.tool = "select"
    ghost.ValidPlacement = true
    ghost.Template = nil
    clearGroupEntities()
    ghost.ResetFreePlacement()

    if IsValid(ghost.Entity) then
        ghost.Entity:SetNoDraw(true)
    end

    hook.Run("MapStudioToolChanged", "select")
end

function ghost.Remove()
    ghost.ResetFreePlacement()
    ghost.Template = nil
    clearGroupEntities()
    removeSingleEntity()
end

function ghost.SetModel(model, keepTemplate)
    if not keepTemplate then
        ghost.Template = nil
    end

    clearGroupEntities()

    local cleanModel, err = MapStudio.Objects.SanitizeModel(model)

    if not cleanModel then
        MapStudio.NotifyLocal(err or "asset.invalid_model", "error")
        return false
    end

    ghost.Model = cleanModel
    ghost.ResetFreePlacement()

    if IsValid(ghost.Entity) and ghost.Entity:GetModel() == cleanModel then
        return true
    end

    removeSingleEntity()

    if MapStudio.Objects.ModelExists and not MapStudio.Objects.ModelExists(cleanModel) then
        MapStudio.NotifyLocal("error.invalid_model", "error")
        return false
    end

    ghost.Entity = ClientsideModel(cleanModel, RENDERGROUP_TRANSLUCENT)
    if not IsValid(ghost.Entity) then
        return false
    end

    ghost.Entity:SetModelScale(1, 0)
    applyGhostAppearance(ghost.Entity)
    applyTemplateShape(ghost.Entity)
    ghost.Entity:SetNoDraw(false)
    ghost.Bounds = MapStudio.Placement.BoundsFromEntity(ghost.Entity)
    ghost.UpdateRenderBounds(ghost.Entity:GetPos(), ghost.Entity:GetAngles())

    return true
end

function ghost.SetTemplate(template)
    local clean, err = MapStudio.Objects.SanitizeObject(MapStudio.DeepCopy(template or {}))

    if not clean then
        MapStudio.NotifyLocal(err or "error.invalid_object", "error")
        return false
    end

    clean.id = nil
    clean.createdBy = nil
    clean.createdAt = nil
    clean.updatedBy = nil
    clean.updatedAt = nil
    clean.originalTransform = nil

    ghost.Ang = MapStudio.Objects.ToAngle(clean.ang)
    MapStudio.ClientState.selectedModel = clean.model

    if not ghost.SetModel(clean.model, true) then
        return false
    end

    ghost.Template = clean
    applyTemplateShape(ghost.Entity)
    ghost.Bounds = IsValid(ghost.Entity) and MapStudio.Placement.BoundsFromEntity(ghost.Entity) or ghost.Bounds

    return true
end

function ghost.ClearTemplate()
    ghost.Template = nil
    clearGroupEntities()

    if IsValid(ghost.Entity) then
        ghost.Entity:SetSkin(0)

        if ghost.Entity.GetNumBodyGroups then
            for index = 0, (ghost.Entity:GetNumBodyGroups() or 0) - 1 do
                ghost.Entity:SetBodygroup(index, 0)
            end
        end

        if ghost.Entity.SetModelScale then
            ghost.Entity:SetModelScale(1, 0)
        end

        ghost.Bounds = MapStudio.Placement.BoundsFromEntity(ghost.Entity)
        ghost.UpdateRenderBounds(ghost.Entity:GetPos(), ghost.Entity:GetAngles())
    end
end

function ghost.SetGroupTemplate(groupTemplate)
    if type(groupTemplate) ~= "table" or groupTemplate.isGroup ~= true or type(groupTemplate.items) ~= "table" then
        return false
    end

    local clean = {
        isGroup = true,
        pivot = MapStudio.Objects.SanitizeVector(groupTemplate.pivot),
        bounds = MapStudio.Placement.NormalizeBounds(groupTemplate.bounds),
        ang = MapStudio.Objects.SanitizeAngle(groupTemplate.ang),
        items = {}
    }

    for _, item in ipairs(groupTemplate.items or {}) do
        local template = item and item.template
        local objectData = template and MapStudio.Objects.SanitizeObject(MapStudio.DeepCopy(template))

        if objectData then
            objectData.id = nil
            objectData.pos = nil
            objectData.originalTransform = nil
            objectData.OriginalTransform = nil
            objectData.createdBy = nil
            objectData.createdAt = nil
            objectData.updatedBy = nil
            objectData.updatedAt = nil

            table.insert(clean.items, {
                relPos = MapStudio.Objects.SanitizeVector(item.relPos),
                template = objectData
            })
        end
    end

    if #clean.items == 0 then
        return false
    end

    ghost.Template = nil
    removeSingleEntity()
    clearGroupEntities()
    ghost.GroupTemplate = clean
    ghost.Model = clean.items[1].template.model
    ghost.Ang = MapStudio.Objects.ToAngle(clean.ang)
    MapStudio.ClientState.selectedModel = ghost.Model
    ghost.ResetFreePlacement()

    return ensureGroupEntities()
end

local function groupPlacement()
    local groupTemplate = ghost.GroupTemplate

    if not isGroupActive() then
        return nil
    end

    if freePropsEnabled() then
        if not ghost.FreePlacementDepth then
            ghost.InitializeFreePlacementDepth()
        end

        local startPos, direction = mouseRay()
        local pos = startPos + direction * (ghost.FreePlacementDepth or FREE_DEPTH_DEFAULT)

        if MapStudio.Grid and MapStudio.Grid.GetBool("snap_grid") then
            if not ghost.SnapContext or ghost.SnapContext.type ~= "free" then
                ghost.SnapContext = MapStudio.Grid.CreateFreeContext(pos)
            end

            MapStudio.Grid.SetActiveContext(ghost.SnapContext)
            pos = MapStudio.Grid.SnapVector(pos, ghost.SnapContext)
        else
            resetSnapContext()
        end

        return {
            pos = pos,
            bounds = groupTemplate.bounds,
            model = ghost.Model,
            ang = MapStudio.Objects.ToAngle(groupTemplate.ang)
        }
    end

    ghost.FreePlacementActive = false

    if not ghost.Trace or not ghost.Trace.Hit then
        ghost.Trace = ghost.GetTrace()
    end

    if not ghost.Trace or not ghost.Trace.Hit then
        resetSnapContext()
        return nil
    end

    local placementTrace = ghost.Trace

    if MapStudio.Grid and MapStudio.Grid.GetSnappedTrace then
        if MapStudio.Grid.GetBool("snap_grid") then
            local filterEnt = groupFilterEnts()
            local snapTrace = MapStudio.Grid.TraceFromMouse and MapStudio.Grid.TraceFromMouse(filterEnt) or ghost.Trace

            if snapTrace and snapTrace.Hit then
                placementTrace = snapTrace
            end

            if MapStudio.Grid.ShouldRefreshSurfaceContext and MapStudio.Grid.ShouldRefreshSurfaceContext(ghost.SnapContext, placementTrace) then
                resetSnapContext()
            end

            if not ghost.SnapContext or ghost.SnapContext.type ~= "surface" then
                ghost.SnapContext = MapStudio.Grid.CreateSurfaceContext(placementTrace)

                if ghost.SnapContext then
                    ghost.SnapContext.ignoreEnt = filterEnt
                end
            end

            MapStudio.Grid.SetActiveContext(ghost.SnapContext)
        else
            resetSnapContext()
        end

        placementTrace = MapStudio.Grid.GetSnappedTrace(ghost.Trace, ghost.SnapContext)
    end

    return MapStudio.Placement.Calculate(
        ghost.Model,
        placementTrace.HitPos,
        placementTrace.HitNormal,
        Angle(0, 0, 0),
        "ground",
        groupTemplate.bounds
    )
end

function ghost.GetPlacement()
    if MapStudio.Editor and MapStudio.Editor.GetPlacementOverride then
        local placement = MapStudio.Editor.GetPlacementOverride()

        if placement then
            resetSnapContext()
            return placement
        end
    end

    if isGroupActive() then
        return groupPlacement()
    end

    if freePropsEnabled() then
        if not ghost.FreePlacementDepth then
            ghost.InitializeFreePlacementDepth()
        end

        local startPos, direction = mouseRay()
        local pos = startPos + direction * (ghost.FreePlacementDepth or FREE_DEPTH_DEFAULT)

        if MapStudio.Grid and MapStudio.Grid.GetBool("snap_grid") then
            if not ghost.SnapContext or ghost.SnapContext.type ~= "free" then
                ghost.SnapContext = MapStudio.Grid.CreateFreeContext(pos)
            end

            MapStudio.Grid.SetActiveContext(ghost.SnapContext)
            pos = MapStudio.Grid.SnapVector(pos, ghost.SnapContext)
        else
            resetSnapContext()
        end

        return {
            pos = pos,
            bounds = ghost.Bounds,
            model = ghost.Model,
            ang = ghost.Ang
        }
    end

    ghost.FreePlacementActive = false

    if not ghost.Trace or not ghost.Trace.Hit then
        ghost.Trace = ghost.GetTrace()
    end

    if not ghost.Trace or not ghost.Trace.Hit then
        resetSnapContext()
        return nil
    end

    if IsValid(ghost.Entity) then
        ghost.Bounds = MapStudio.Placement.BoundsFromEntity(ghost.Entity)
    end

    local placementTrace = ghost.Trace

    if MapStudio.Grid and MapStudio.Grid.GetSnappedTrace then
        if MapStudio.Grid.GetBool("snap_grid") then
            local snapTrace = MapStudio.Grid.TraceFromMouse and MapStudio.Grid.TraceFromMouse(ghost.Entity) or ghost.Trace

            if snapTrace and snapTrace.Hit then
                placementTrace = snapTrace
            end

            if MapStudio.Grid.ShouldRefreshSurfaceContext and MapStudio.Grid.ShouldRefreshSurfaceContext(ghost.SnapContext, placementTrace) then
                resetSnapContext()
            end

            if not ghost.SnapContext or ghost.SnapContext.type ~= "surface" then
                ghost.SnapContext = MapStudio.Grid.CreateSurfaceContext(placementTrace)

                if ghost.SnapContext then
                    ghost.SnapContext.ignoreEnt = ghost.Entity
                end
            end

            MapStudio.Grid.SetActiveContext(ghost.SnapContext)
        else
            resetSnapContext()
        end

        placementTrace = MapStudio.Grid.GetSnappedTrace(ghost.Trace, ghost.SnapContext)
    end

    local placement = MapStudio.Placement.Calculate(
        ghost.Model,
        placementTrace.HitPos,
        placementTrace.HitNormal,
        ghost.Ang,
        "ground",
        ghost.Bounds
    )

    return placement
end

function ghost.GetTrace()
    local startPos, direction = mouseRay()

    return util.TraceLine({
        start = startPos,
        endpos = startPos + direction * 12000,
        filter = function(ent)
            if not IsValid(ent) then return true end
            local ply = LocalPlayer()
            if IsValid(ply) and ent == ply then return false end
            if IsValid(ply) then
                local weapon = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
                if IsValid(weapon) and ent == weapon then return false end
            end
            if isGhostEntity(ent) then return false end
            return true
        end
    })
end

function ghost.RotateByHandle(handle, delta)
    local field = RING_ANGLE_FIELDS[handle]
    local ring = RINGS[handle]

    if not field or not ring then
        return false
    end

    delta = tonumber(delta) or 0

    if isGroupActive() then
        ensureGroupEntities()

        local groupAng = rotateAngleAroundAxis(ghost.GroupTemplate.ang, ring.normal, delta, handle)
        ghost.GroupTemplate.ang = angleToTable(groupAng)
        ghost.Ang = groupAng

        for _, item in ipairs(ghost.GroupTemplate.items or {}) do
            local template = item.template

            if template then
                local relPos = MapStudio.Objects.ToVector(item.relPos)
                local nextPos = rotateVectorAroundAxis(relPos, ring.normal, delta)
                local nextAng = rotateAngleAroundAxis(template.ang, ring.normal, delta, handle)

                item.relPos = vectorToTable(nextPos)
                template.ang = angleToTable(nextAng)
            end
        end

        ghost.GroupTemplate.bounds = groupBoundsFromTemplate() or ghost.GroupTemplate.bounds

        return true
    end

    ghost.Ang = applyRingDelta(ghost.Ang, handle, delta)

    if ghost.Template then
        ghost.Template.ang = angleToTable(ghost.Ang)
    end

    if IsValid(ghost.Entity) then
        ghost.Entity:SetAngles(ghost.Ang)
        ghost.UpdateRenderBounds(ghost.Entity:GetPos(), ghost.Ang)
    end

    return true
end

function ghost.RotateYaw(delta)
    ghost.RotateByHandle("rot_z", delta)
end

function ghost.ResetRotation()
    ghost.Ang = Angle(0, 0, 0)
end

local function updateGroupPreview(placement)
    if not placement or not isGroupActive() then
        return false
    end

    ensureGroupEntities()

    for index, item in ipairs(ghost.GroupTemplate.items or {}) do
        local ent = ghost.GroupEntities and ghost.GroupEntities[index]
        local template = item.template

        if IsValid(ent) and template then
            local relPos = MapStudio.Objects.ToVector(item.relPos)
            local pos = placement.pos + relPos
            local ang = MapStudio.Objects.ToAngle(template.ang)

            ent:SetNoDraw(false)
            ent:SetPos(pos)
            ent:SetAngles(ang)
            applyGhostAppearance(ent)
            applyTemplateShape(ent, template)
        end
    end

    return true
end

function ghost.Update()
    if not MapStudio.Editor or not MapStudio.Editor.IsOpen() then
        ghost.Remove()
        return
    end

    if not ghost.IsActive() then
        if IsValid(ghost.Entity) then
            ghost.Entity:SetNoDraw(true)
        end

        for _, ent in ipairs(ghost.GroupEntities or {}) do
            if IsValid(ent) then
                ent:SetNoDraw(true)
            end
        end

        ghost.ResetFreePlacement()
        return
    end

    if isGroupActive() then
        ensureGroupEntities()
        ghost.Trace = freePropsEnabled() and nil or ghost.GetTrace()

        local placement = ghost.GetPlacement()

        if not placement then
            for _, ent in ipairs(ghost.GroupEntities or {}) do
                if IsValid(ent) then
                    ent:SetNoDraw(true)
                end
            end

            return
        end

        ghost.PlacePos = placement.pos
        ghost.ValidPlacement = true
        updateGroupPreview(placement)
        return
    end

    if not IsValid(ghost.Entity) then
        ghost.SetModel(MapStudio.ClientState.selectedModel or ghost.Model, ghost.Template ~= nil)
    end

    ghost.Trace = freePropsEnabled() and nil or ghost.GetTrace()

    if IsValid(ghost.Entity) then
        local placement = ghost.GetPlacement()

        if not placement then
            ghost.Entity:SetNoDraw(true)
            return
        end

        ghost.PlacePos = placement.pos
        ghost.ValidPlacement = true

        ghost.Entity:SetNoDraw(false)
        ghost.Entity:SetPos(placement.pos)
        ghost.Entity:SetAngles(placement.ang or ghost.Ang)
        applyGhostAppearance(ghost.Entity)
        applyTemplateShape(ghost.Entity)
        ghost.UpdateRenderBounds(placement.pos, placement.ang or ghost.Ang)
    end
end

function ghost.Place()
    if not ghost.IsActive() then
        return
    end

    local placement = ghost.GetPlacement()

    if not placement then
        return
    end

    if isGroupActive() then
        local payloads

        if MapStudio.Editor and MapStudio.Editor.BuildGroupObjectPayloadsFromTemplate then
            payloads = MapStudio.Editor.BuildGroupObjectPayloadsFromTemplate(ghost.GroupTemplate, placement)
        end

        if not payloads or #payloads == 0 then
            return
        end

        if MapStudio.Editor and MapStudio.Editor.QueueSelectCreatedObject then
            MapStudio.Editor.QueueSelectCreatedObject(#payloads)
        end

        if MapStudio.Client.CreateObjects then
            MapStudio.Client.CreateObjects(payloads)
        else
            for _, payload in ipairs(payloads) do
                MapStudio.Client.CreateObject(payload)
            end
        end

        if MapStudio.Editor and MapStudio.Editor.OnGhostPlaced then
            MapStudio.Editor.OnGhostPlaced(payloads, placement)
        end

        return
    end

    local payload

    if MapStudio.Editor and MapStudio.Editor.BuildObjectPayloadFromTemplate then
        payload = MapStudio.Editor.BuildObjectPayloadFromTemplate(ghost.Template, placement)
    end

    payload = payload or {
        model = MapStudio.ClientState.selectedModel or ghost.Model,
        pos = { x = placement.pos.x, y = placement.pos.y, z = placement.pos.z },
        ang = { p = ghost.Ang.p, y = ghost.Ang.y, r = ghost.Ang.r },
        layer = "default",
        frozen = true,
        motion = false,
        collision = true
    }

    if ghost.Template and MapStudio.Editor and MapStudio.Editor.QueueSelectCreatedObject then
        MapStudio.Editor.QueueSelectCreatedObject()
    end

    MapStudio.Client.CreateObject(payload)

    if MapStudio.Editor and MapStudio.Editor.OnGhostPlaced then
        MapStudio.Editor.OnGhostPlaced(payload, placement)
    end
end

hook.Add("Think", "MapStudio_GhostThink", function()
    ghost.Update()
end)
