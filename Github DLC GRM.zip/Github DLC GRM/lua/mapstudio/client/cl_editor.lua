MapStudio = MapStudio or {}
MapStudio.Editor = MapStudio.Editor or {}

local editor = MapStudio.Editor

editor.Frame = nil
editor.WorldPanel = nil
editor.LeftPanel = nil
editor.RightPanel = nil
editor.RightMode = "inspector"
editor.SelectedEntityCache = nil
editor.FreeProps = false
editor.KeyState = editor.KeyState or {}
editor.SuppressedKeys = editor.SuppressedKeys or {}
editor.CtrlShortcutState = editor.CtrlShortcutState or {}
editor.StatusText = nil
editor.StatusUntil = 0
editor.LeftCollapsed = editor.LeftCollapsed == true
editor.RightCollapsed = editor.RightCollapsed == true
editor.ClipboardTemplate = editor.ClipboardTemplate or nil
editor.SmartDuplicate = editor.SmartDuplicate or nil
editor.PendingCreatedSelections = editor.PendingCreatedSelections or 0
editor.PendingCreatedID = editor.PendingCreatedID or nil
editor.PendingCreatedIDs = editor.PendingCreatedIDs or nil

local debugBindsConVar = CreateClientConVar("mapstudio_debug_binds", "0", false, false, "Print MapStudio editor keybind diagnostics")
local LEFT_PANEL_WIDTH = 390
local RIGHT_PANEL_WIDTH = 360
local COLLAPSE_HANDLE_WIDTH = 18
local SMART_DUPLICATE_GAP = 0.5
local CLONE_FIELDS = {
    "type", "class", "model", "ang", "scale", "skin", "bodygroups", "color", "material",
    "submaterials", "renderMode", "renderFx", "collision", "frozen", "gravity", "motion",
    "reactive", "behavior", "layer", "notes"
}
local SMART_DUPLICATE_SIDES = { "left", "right", "front", "back" }
local SMART_DUPLICATE_LABELS = {
    left = "smart_duplicate.left",
    right = "smart_duplicate.right",
    front = "smart_duplicate.front",
    back = "smart_duplicate.back"
}
local ACTION_HANDLERS
local ACTION_BINDS = {
    { action = "delete_selected", conVar = "bind_delete" },
    { action = "cancel_selection", conVar = "bind_cancel" },
    { action = "toggle_grid", conVar = "bind_grid" },
    { action = "toggle_snap", conVar = "bind_snap" },
    { action = "rotate_blue_left", conVar = "bind_rotate_blue_left" },
    { action = "rotate_blue_right", conVar = "bind_rotate_blue_right" },
    { action = "rotate_red_up", conVar = "bind_rotate_red_up" },
    { action = "rotate_red_down", conVar = "bind_rotate_red_down" },
    { action = "rotate_green_left", conVar = "bind_rotate_green_left" },
    { action = "rotate_green_right", conVar = "bind_rotate_green_right" },
    { action = "cycle_rotation_angle", conVar = "bind_cycle_rotation_angle" },
    { action = "reset_transform", conVar = "bind_reset_transform" },
    { action = "toggle_reactive", conVar = "bind_toggle_reactive" },
    { action = "smart_duplicate", conVar = "bind_smart_duplicate", requireCtrl = true }
}

local function debugBinds(message)
    if debugBindsConVar and debugBindsConVar:GetBool() then
        print("[MapStudio binds] " .. tostring(message))
    end
end

function editor.IsOpen()
    return IsValid(editor.Frame)
end

local function editorTraceback(err)
    if debug and debug.traceback then
        return debug.traceback(tostring(err), 2)
    end

    return tostring(err)
end

function editor.Focus()
    local frame = editor.Frame

    if not IsValid(frame) then
        return false, "error.editor_open_failed"
    end

    local ok, err = xpcall(function()
        frame:SetVisible(true)
        frame:MakePopup()
        frame:SetKeyboardInputEnabled(true)
        frame:SetMouseInputEnabled(true)

        if frame.RequestFocus then
            frame:RequestFocus()
        end

        gui.EnableScreenClicker(true)
    end, editorTraceback)

    if not ok then
        MapStudio.LogError("Editor focus failed: " .. tostring(err))
        return false, "error.editor_open_failed"
    end

    return true
end

local function makePanel(parent, dock, wide, tall)
    if not IsValid(parent) then
        return nil
    end

    local panel = vgui.Create("MS_Panel", parent)
    if not IsValid(panel) then
        return nil
    end

    panel:Dock(dock)
    panel:DockPadding(10, 10, 10, 10)

    if wide then panel:SetWide(wide) end
    if tall then panel:SetTall(tall) end

    return panel
end

function editor.KeyboardFocused()
    local focus = vgui.GetKeyboardFocus()
    local class = IsValid(focus) and focus:GetClassName() or ""

    return class == "TextEntry" or class == "DTextEntry" or class == "MS_TextEntry" or class == "DBinder"
end

function editor.SetTool(toolID)
    MapStudio.ClientState.tool = toolID or "select"

    if MapStudio.ClientState.tool ~= "place" then
        editor.SmartDuplicate = nil
    end

    hook.Run("MapStudioToolChanged", MapStudio.ClientState.tool)
end

function editor.GetSelectedIDs()
    local result = {}
    local seen = {}

    if not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return result
    end

    for _, id in ipairs(MapStudio.ClientState.selectedIds or {}) do
        if id and MapStudio.ClientState.objects[id] and not seen[id] then
            seen[id] = true
            table.insert(result, id)
        end
    end

    local id = MapStudio.ClientState.selectedId
    if id and MapStudio.ClientState.objects[id] and not seen[id] then
        table.insert(result, id)
    end

    return result
end

function editor.IsSelected(id)
    id = tostring(id or "")

    if id == "" then
        return false
    end

    for _, selectedId in ipairs(editor.GetSelectedIDs()) do
        if selectedId == id then
            return true
        end
    end

    return false
end

function editor.GetSelectedObjects()
    local result = {}

    if not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return result
    end

    for _, id in ipairs(editor.GetSelectedIDs()) do
        local objectData = MapStudio.ClientState.objects[id]

        if objectData then
            table.insert(result, {
                id = id,
                object = objectData
            })
        end
    end

    return result
end

function editor.GetSelectionCount()
    return #editor.GetSelectedIDs()
end

function editor.GetPrimarySelectedID()
    local ids = editor.GetSelectedIDs()
    return MapStudio.ClientState.selectedId or ids[#ids]
end

function editor.GetSelectionPivot()
    local objects = editor.GetSelectedObjects()

    if #objects == 0 then
        return nil
    end

    if #objects > 1 then
        local mins
        local maxs

        for _, item in ipairs(objects) do
            local ent = editor.FindEntityByObjectID and editor.FindEntityByObjectID(item.id)

            if IsValid(ent) and ent.WorldSpaceAABB then
                local itemMins, itemMaxs = ent:WorldSpaceAABB()

                if itemMins and itemMaxs then
                    if not mins then
                        mins = Vector(itemMins.x, itemMins.y, itemMins.z)
                        maxs = Vector(itemMaxs.x, itemMaxs.y, itemMaxs.z)
                    else
                        mins.x = math.min(mins.x, itemMins.x)
                        mins.y = math.min(mins.y, itemMins.y)
                        mins.z = math.min(mins.z, itemMins.z)
                        maxs.x = math.max(maxs.x, itemMaxs.x)
                        maxs.y = math.max(maxs.y, itemMaxs.y)
                        maxs.z = math.max(maxs.z, itemMaxs.z)
                    end
                end
            end
        end

        if mins and maxs then
            return (mins + maxs) * 0.5
        end
    end

    local sum = Vector(0, 0, 0)

    for _, item in ipairs(objects) do
        local pos = MapStudio.Objects.ToVector(item.object.pos)
        sum = sum + pos
    end

    return Vector(sum.x / #objects, sum.y / #objects, sum.z / #objects)
end

function editor.SelectOnly(id)
    editor.Select(id, false)
end

function editor.ToggleSelection(id)
    editor.Select(id, true)
end

function editor.UpdateToolbarState()
    local hasSelection = #editor.GetSelectedIDs() > 0
    local hasHeldModel = MapStudio.Ghost and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive()

    if IsValid(editor.DeleteButton) then
        editor.DeleteButton:SetDisabled(not hasSelection)
    end

    if IsValid(editor.SmartDuplicateButton) then
        editor.SmartDuplicateButton:SetDisabled(not hasSelection)
    end

    if IsValid(editor.GridButton) then
        editor.GridButton:SetText(MapStudio.Grid.GetBool("show_grid") and MapStudio.T("editor.grid_on") or MapStudio.T("editor.grid"))
    end

    if IsValid(editor.FreePropsButton) then
        editor.FreePropsButton:SetText(MapStudio.T("toolbar.free_props"))

        if editor.FreePropsButton.SetToggled then
            editor.FreePropsButton:SetToggled(editor.FreeProps == true)
        end
    end

    if IsValid(editor.CancelButton) then
        editor.CancelButton:SetDisabled(not hasSelection and not hasHeldModel)
    end
end

function editor.IsFreePropsEnabled()
    return editor.FreeProps == true
end

function editor.SetFreeProps(enabled)
    local previous = editor.FreeProps == true
    editor.FreeProps = enabled == true

    if previous ~= editor.FreeProps and MapStudio.Ghost then
        if editor.FreeProps and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive() then
            MapStudio.Ghost.InitializeFreePlacementDepth()
        elseif MapStudio.Ghost.ResetFreePlacement then
            MapStudio.Ghost.ResetFreePlacement()
        end
    end

    editor.UpdateToolbarState()
end

function editor.ToggleFreeProps()
    editor.SetFreeProps(not editor.FreeProps)
end

function editor.ShowStatus(key, replacements)
    editor.StatusText = MapStudio.T(key, replacements)
    editor.StatusUntil = CurTime() + 1
end

function editor.ClearSelection()
    MapStudio.ClientState.selectedId = nil
    MapStudio.ClientState.selectedIds = {}
    editor.SelectedEntityCache = nil
    hook.Run("MapStudioSelectionChanged", nil, {})
    editor.UpdateToolbarState()
end

function editor.Select(id, additive)
    if not id or id == "" or not MapStudio.ClientState.objects[id] then
        if not additive then
            editor.ClearSelection()
        end

        return
    end

    local selected = additive and editor.GetSelectedIDs() or {}
    local found = false

    for index = #selected, 1, -1 do
        if selected[index] == id then
            found = true

            if additive then
                table.remove(selected, index)
            end
        end
    end

    if not found or not additive then
        table.insert(selected, id)
    end

    MapStudio.ClientState.selectedIds = selected
    MapStudio.ClientState.selectedId = selected[#selected]
    editor.SelectedEntityCache = nil
    hook.Run("MapStudioSelectionChanged", MapStudio.ClientState.selectedId, selected)
    editor.UpdateToolbarState()
end

function editor.FindEntityByObjectID(id)
    if not id or id == "" then
        return nil
    end

    if IsValid(editor.SelectedEntityCache) and (editor.SelectedEntityCache:GetNWString("MapStudioObjectID") == id or editor.SelectedEntityCache:GetNWString("MapStudioID") == id) then
        return editor.SelectedEntityCache
    end

    for _, ent in ipairs(ents.GetAll()) do
        if ent:GetNWString("MapStudioObjectID") == id or ent:GetNWString("MapStudioID") == id then
            editor.SelectedEntityCache = ent
            return ent
        end
    end

    return nil
end

local function entitySelectionCenter(ent)
    if not IsValid(ent) then
        return nil
    end

    if ent.WorldSpaceCenter then
        local ok, center = pcall(ent.WorldSpaceCenter, ent)

        if ok and isvector(center) then
            return center
        end
    end

    return ent:GetPos()
end

local function fallbackSelectionID(trace)
    if not trace or not isvector(trace.HitPos) then
        return nil
    end

    local startPos = isvector(trace.StartPos) and trace.StartPos or EyePos()
    local ray = trace.HitPos - startPos
    local rayLengthSqr = ray:LengthSqr()

    if rayLengthSqr <= 0 then
        return nil
    end

    local bestID
    local bestDistance

    for id in pairs((MapStudio.ClientState and MapStudio.ClientState.objects) or {}) do
        local ent = editor.FindEntityByObjectID(id)
        local center = entitySelectionCenter(ent)

        if center then
            local offset = center - startPos
            local fraction = math.Clamp(offset:Dot(ray) / rayLengthSqr, 0, 1)
            local closest = startPos + ray * fraction
            local distance = center:DistToSqr(closest)
            local radius = 32

            if ent.BoundingRadius then
                local ok, value = pcall(ent.BoundingRadius, ent)
                radius = ok and math.max(radius, tonumber(value) or radius) or radius
            end

            if distance <= radius * radius and (not bestDistance or distance < bestDistance) then
                bestID = id
                bestDistance = distance
            end
        end
    end

    return bestID
end

function editor.SelectByTrace(additive)
    local trace = MapStudio.Ghost.GetTrace()
    local ent = trace and trace.Entity

    if not IsValid(ent) then
        editor.Select(fallbackSelectionID(trace), additive)
        return
    end

    local id = ent:GetNWString("MapStudioObjectID", "")
    if id == "" then
        id = ent:GetNWString("MapStudioID", "")
    end

    if id == "" or not MapStudio.ClientState.objects[id] then
        editor.Select(fallbackSelectionID(trace), additive)
        return
    end

    editor.Select(id, additive)
end

local function isReactiveObject(objectData)
    return objectData and (objectData.reactive == true or MapStudio.Objects.SanitizeBehavior(objectData.behavior) == "reactive")
end

local function vectorToTable(pos)
    return { x = pos.x, y = pos.y, z = pos.z }
end

local function angleToTable(ang)
    return { p = ang.p, y = ang.y, r = ang.r }
end

local function horizontalBasis(ang)
    local yaw = Angle(0, (ang and ang.y) or 0, 0)
    local forward = yaw:Forward()
    local right = yaw:Right()

    forward.z = 0
    right.z = 0
    forward:Normalize()
    right:Normalize()

    return forward, right
end

local function directionForSide(ang, side)
    local forward, right = horizontalBasis(ang)

    if side == "front" then return forward end
    if side == "back" then return -forward end
    if side == "left" then return -right end

    return right
end

local function extentForSide(bounds, side, direction, worldBounds)
    bounds = MapStudio.Placement.NormalizeBounds(bounds)

    if worldBounds and direction then
        local corners = {
            Vector(bounds.mins.x, bounds.mins.y, bounds.mins.z),
            Vector(bounds.mins.x, bounds.mins.y, bounds.maxs.z),
            Vector(bounds.mins.x, bounds.maxs.y, bounds.mins.z),
            Vector(bounds.mins.x, bounds.maxs.y, bounds.maxs.z),
            Vector(bounds.maxs.x, bounds.mins.y, bounds.mins.z),
            Vector(bounds.maxs.x, bounds.mins.y, bounds.maxs.z),
            Vector(bounds.maxs.x, bounds.maxs.y, bounds.mins.z),
            Vector(bounds.maxs.x, bounds.maxs.y, bounds.maxs.z)
        }
        local minProjection
        local maxProjection

        for _, corner in ipairs(corners) do
            local projection = corner:Dot(direction)

            minProjection = minProjection and math.min(minProjection, projection) or projection
            maxProjection = maxProjection and math.max(maxProjection, projection) or projection
        end

        return math.max(1, (maxProjection or 0) - (minProjection or 0))
    end

    if side == "front" or side == "back" then
        return math.max(1, bounds.maxs.x - bounds.mins.x)
    end

    return math.max(1, bounds.maxs.y - bounds.mins.y)
end

local function mouseRay()
    local startPos = MapStudio.Freecam.Active and MapStudio.Freecam.Pos or EyePos()
    local direction = MapStudio.Freecam.Active and MapStudio.Freecam.Ang:Forward() or EyeAngles():Forward()
    local mouseX, mouseY = gui.MousePos()

    if gui.ScreenToVector and mouseX and mouseY and mouseX >= 0 and mouseY >= 0 then
        direction = gui.ScreenToVector(mouseX, mouseY)
    end

    direction:Normalize()

    return startPos, direction
end

local function pointRayDistanceSqr(point, startPos, direction)
    local offset = point - startPos
    local distance = math.max(0, offset:Dot(direction))
    local closest = startPos + direction * distance

    return point:DistToSqr(closest)
end

local function entityBounds(ent)
    if not IsValid(ent) then
        return MapStudio.Placement.NormalizeBounds()
    end

    local mins
    local maxs

    if ent.GetRenderBounds then
        mins, maxs = ent:GetRenderBounds()
    end

    if not mins or not maxs or (maxs - mins):LengthSqr() <= 1 then
        return MapStudio.Placement.BoundsFromEntity(ent)
    end

    return {
        mins = Vector(mins.x, mins.y, mins.z),
        maxs = Vector(maxs.x, maxs.y, maxs.z)
    }
end

local function boundsForObject(id, objectData)
    local ent = editor.FindEntityByObjectID(id)

    if IsValid(ent) then
        return entityBounds(ent)
    end

    if MapStudio.Ghost and IsValid(MapStudio.Ghost.Entity) then
        return entityBounds(MapStudio.Ghost.Entity)
    end

    return MapStudio.Placement.NormalizeBounds()
end

local function selectedCloneItems()
    local result = {}

    for _, item in ipairs(editor.GetSelectedObjects()) do
        local pos = MapStudio.Objects.ToVector(item.object.pos)

        table.insert(result, {
            id = item.id,
            object = item.object,
            pos = pos,
            ang = MapStudio.Objects.ToAngle(item.object.ang)
        })
    end

    return result
end

local function itemWorldBounds(item)
    local ent = item and editor.FindEntityByObjectID(item.id)

    if IsValid(ent) and ent.WorldSpaceAABB then
        local mins, maxs = ent:WorldSpaceAABB()

        if mins and maxs then
            return Vector(mins.x, mins.y, mins.z), Vector(maxs.x, maxs.y, maxs.z)
        end
    end

    local pos = item and item.pos

    if pos then
        return Vector(pos.x, pos.y, pos.z), Vector(pos.x, pos.y, pos.z)
    end

    return nil, nil
end

local function selectionPivotAndBounds(items)
    local mins
    local maxs

    for _, item in ipairs(items or {}) do
        local itemMins, itemMaxs = itemWorldBounds(item)

        if itemMins and itemMaxs then
            if not mins then
                mins = itemMins
                maxs = itemMaxs
            else
                mins.x = math.min(mins.x, itemMins.x)
                mins.y = math.min(mins.y, itemMins.y)
                mins.z = math.min(mins.z, itemMins.z)
                maxs.x = math.max(maxs.x, itemMaxs.x)
                maxs.y = math.max(maxs.y, itemMaxs.y)
                maxs.z = math.max(maxs.z, itemMaxs.z)
            end
        end
    end

    if not mins or not maxs then
        return nil, nil
    end

    local pivot = (mins + maxs) * 0.5

    return pivot, {
        mins = mins - pivot,
        maxs = maxs - pivot
    }
end

local function primaryAngleForItems(items)
    local primaryId = editor.GetPrimarySelectedID()

    for _, item in ipairs(items or {}) do
        if item.id == primaryId then
            return item.ang
        end
    end

    return items and items[1] and items[1].ang or Angle(0, 0, 0)
end

function editor.MakeCloneTemplate(objectData)
    local clean, err = MapStudio.Objects.SanitizeObject(MapStudio.DeepCopy(objectData or {}))

    if not clean then
        MapStudio.NotifyLocal(err or "error.invalid_object", "error")
        return nil
    end

    local template = {}

    for _, field in ipairs(CLONE_FIELDS) do
        template[field] = MapStudio.DeepCopy(clean[field])
    end

    template.id = nil
    template.pos = nil
    template.originalTransform = nil
    template.OriginalTransform = nil
    template.createdBy = nil
    template.createdAt = nil
    template.updatedBy = nil
    template.updatedAt = nil

    return template
end

function editor.MakeGroupCloneTemplate(items)
    items = items or selectedCloneItems()

    if #items <= 1 then
        return nil
    end

    local pivot, bounds = selectionPivotAndBounds(items)

    if not pivot or not bounds then
        return nil
    end

    local group = {
        isGroup = true,
        pivot = vectorToTable(pivot),
        bounds = bounds,
        ang = angleToTable(primaryAngleForItems(items)),
        items = {}
    }

    for _, item in ipairs(items) do
        local template = editor.MakeCloneTemplate(item.object)

        if template then
            table.insert(group.items, {
                relPos = vectorToTable(item.pos - pivot),
                template = template
            })
        end
    end

    if #group.items <= 1 then
        return nil
    end

    return group
end

function editor.BuildObjectPayloadFromTemplate(template, placement)
    placement = placement or {}
    template = type(template) == "table" and template or {}

    local payload = MapStudio.DeepCopy(template)
    local pos = placement.pos or Vector(0, 0, 0)
    local ang = placement.ang or (MapStudio.Ghost and MapStudio.Ghost.Ang) or MapStudio.Objects.ToAngle(payload.ang)

    payload.id = nil
    payload.createdBy = nil
    payload.createdAt = nil
    payload.updatedBy = nil
    payload.updatedAt = nil
    payload.originalTransform = nil
    payload.OriginalTransform = nil
    payload.model = payload.model or MapStudio.ClientState.selectedModel or (MapStudio.Ghost and MapStudio.Ghost.Model)
    payload.pos = vectorToTable(pos)
    payload.ang = angleToTable(ang)
    payload.layer = payload.layer or MapStudio.ClientState.activeLayer or "default"
    payload.frozen = true
    payload.motion = false

    return payload
end

function editor.BuildGroupObjectPayloadsFromTemplate(groupTemplate, placement)
    if type(groupTemplate) ~= "table" or groupTemplate.isGroup ~= true then
        return nil
    end

    placement = placement or {}
    local pivot = placement.pos or MapStudio.Objects.ToVector(groupTemplate.pivot)
    local payloads = {}

    for _, item in ipairs(groupTemplate.items or {}) do
        local relPos = MapStudio.Objects.ToVector(item.relPos)
        local template = item.template

        if template then
            local payload = editor.BuildObjectPayloadFromTemplate(template, {
                pos = pivot + relPos,
                ang = MapStudio.Objects.ToAngle(template.ang)
            })

            table.insert(payloads, payload)
        end
    end

    return payloads
end

function editor.QueueSelectCreatedObject(count)
    editor.PendingCreatedSelections = (editor.PendingCreatedSelections or 0) + math.max(1, tonumber(count) or 1)
end

local function trySelectPendingCreated()
    local ids = editor.PendingCreatedIDs

    if (not ids or #ids == 0) and editor.PendingCreatedID then
        ids = { editor.PendingCreatedID }
    end

    if not ids or #ids == 0 or not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return false
    end

    local selected = {}

    for _, id in ipairs(ids) do
        id = tostring(id or "")

        if id == "" or not MapStudio.ClientState.objects[id] then
            return false
        end

        table.insert(selected, id)
    end

    editor.PendingCreatedID = nil
    editor.PendingCreatedIDs = nil
    MapStudio.ClientState.selectedIds = selected
    MapStudio.ClientState.selectedId = selected[#selected]
    editor.SelectedEntityCache = nil
    hook.Run("MapStudioSelectionChanged", MapStudio.ClientState.selectedId, selected)
    editor.UpdateToolbarState()
    return true
end

function editor.HandleObjectCreated(ids)
    if (editor.PendingCreatedSelections or 0) <= 0 then
        return
    end

    local clean = {}

    if type(ids) == "table" then
        for _, id in ipairs(ids) do
            id = tostring(id or "")

            if id ~= "" then
                table.insert(clean, id)
            end
        end
    else
        local id = tostring(ids or "")

        if id ~= "" then
            table.insert(clean, id)
        end
    end

    if #clean == 0 then
        return
    end

    editor.PendingCreatedSelections = math.max(0, editor.PendingCreatedSelections - #clean)
    editor.PendingCreatedID = clean[1]
    editor.PendingCreatedIDs = clean
    trySelectPendingCreated()
end

function editor.BeginPlacementFromTemplate(template, statusKey)
    if not template then
        return false
    end

    editor.SmartDuplicate = nil

    if not MapStudio.Ghost or not MapStudio.Ghost.SetTemplate or not MapStudio.Ghost.SetTemplate(template) then
        return false
    end

    editor.SetTool("place")

    if statusKey then
        editor.ShowStatus(statusKey)
    end

    return true
end

function editor.BeginGroupPlacementFromTemplate(groupTemplate, statusKey)
    if type(groupTemplate) ~= "table" or groupTemplate.isGroup ~= true then
        return false
    end

    editor.SmartDuplicate = nil

    if not MapStudio.Ghost or not MapStudio.Ghost.SetGroupTemplate or not MapStudio.Ghost.SetGroupTemplate(groupTemplate) then
        return false
    end

    editor.SetTool("place")

    if statusKey then
        editor.ShowStatus(statusKey)
    end

    return true
end

function editor.CopySelectedObject()
    local items = selectedCloneItems()

    if #items == 0 then
        editor.ShowStatus("editor.no_selection")
        return false
    end

    if #items > 1 then
        editor.ClipboardTemplate = editor.MakeGroupCloneTemplate(items)
    else
        editor.ClipboardTemplate = editor.MakeCloneTemplate(items[1].object)
    end

    if editor.ClipboardTemplate then
        editor.ShowStatus("clipboard.object_copied")
        return true
    end

    return false
end

function editor.PasteClipboard()
    if not editor.ClipboardTemplate then
        editor.ShowStatus("clipboard.empty")
        return false
    end

    if editor.ClipboardTemplate.isGroup == true then
        return editor.BeginGroupPlacementFromTemplate(editor.ClipboardTemplate, "clipboard.paste_object")
    end

    return editor.BeginPlacementFromTemplate(editor.ClipboardTemplate, "clipboard.paste_object")
end

local function activePreviewTemplate(smart)
    if smart and smart.isGroup then
        return MapStudio.Ghost and MapStudio.Ghost.GroupTemplate or smart.template
    end

    return MapStudio.Ghost and MapStudio.Ghost.Template or smart and smart.template
end

function editor.SyncSmartDuplicatePreviewState()
    local smart = editor.SmartDuplicate

    if not smart or smart.active ~= true then
        return false
    end

    local template = activePreviewTemplate(smart)

    if smart.isGroup then
        if type(template) ~= "table" or template.isGroup ~= true then
            return false
        end

        smart.template = template
        smart.sourceAng = MapStudio.DeepCopy(template.ang)
        smart.bounds = template.bounds or smart.bounds
    else
        if type(template) == "table" then
            smart.template = template
            smart.sourceAng = MapStudio.DeepCopy(template.ang)
        elseif MapStudio.Ghost and MapStudio.Ghost.Ang then
            smart.sourceAng = angleToTable(MapStudio.Ghost.Ang)
        end
    end

    smart.candidates = nil
    editor.RebuildSmartDuplicateCandidates()

    return true
end

function editor.RebuildSmartDuplicateCandidates()
    local smart = editor.SmartDuplicate

    if not smart or not smart.sourcePivot then
        return
    end

    local sourcePos = MapStudio.Objects.ToVector(smart.sourcePivot)
    local sourceAng = MapStudio.Objects.ToAngle(smart.sourceAng)
    local bounds = MapStudio.Placement.NormalizeBounds(smart.bounds)
    local candidates = {}

    for _, side in ipairs(SMART_DUPLICATE_SIDES) do
        local direction = directionForSide(sourceAng, side)
        local distance = extentForSide(bounds, side, direction, smart.boundsAreWorld) + SMART_DUPLICATE_GAP
        local pos = sourcePos + direction * distance
        pos.z = sourcePos.z

        candidates[side] = {
            side = side,
            pos = pos,
            direction = direction,
            labelKey = SMART_DUPLICATE_LABELS[side]
        }
    end

    smart.candidates = candidates
end

function editor.UpdateSmartDuplicateSide()
    local smart = editor.SmartDuplicate

    if not smart or not smart.candidates then
        return
    end

    local startPos, direction = mouseRay()
    local bestSide = smart.side or "right"
    local bestDistance

    for _, side in ipairs(SMART_DUPLICATE_SIDES) do
        local candidate = smart.candidates[side]

        if candidate then
            local distance = pointRayDistanceSqr(candidate.pos, startPos, direction)

            if not bestDistance or distance < bestDistance then
                bestDistance = distance
                bestSide = side
            end
        end
    end

    smart.side = bestSide
end

function editor.GetPlacementOverride()
    local smart = editor.SmartDuplicate

    if not smart or smart.active ~= true then
        return nil
    end

    if not smart.candidates then
        editor.RebuildSmartDuplicateCandidates()
    end

    editor.UpdateSmartDuplicateSide()

    local side = smart.side or "right"
    local candidate = smart.candidates and smart.candidates[side]

    if not candidate then
        return nil
    end

    local template = activePreviewTemplate(smart) or smart.template
    local templateAng = template and template.ang or smart.sourceAng

    return {
        pos = Vector(candidate.pos.x, candidate.pos.y, candidate.pos.z),
        bounds = smart.isGroup and template and template.bounds or smart.bounds,
        model = smart.isGroup and template and template.items and template.items[1] and template.items[1].template and template.items[1].template.model or template and template.model,
        ang = MapStudio.Objects.ToAngle(templateAng)
    }
end

function editor.StartSmartDuplicate()
    local items = selectedCloneItems()

    if #items == 0 then
        editor.ShowStatus("editor.no_selection")
        return false
    end

    local previousSide = editor.SmartDuplicate and editor.SmartDuplicate.side or "right"

    if #items > 1 then
        local groupTemplate = editor.MakeGroupCloneTemplate(items)

        if not groupTemplate then
            return false
        end

        if not MapStudio.Ghost or not MapStudio.Ghost.SetGroupTemplate or not MapStudio.Ghost.SetGroupTemplate(groupTemplate) then
            return false
        end

        editor.SmartDuplicate = {
            active = true,
            isGroup = true,
            template = groupTemplate,
            sourcePivot = MapStudio.DeepCopy(groupTemplate.pivot),
            sourceAng = MapStudio.DeepCopy(groupTemplate.ang),
            bounds = groupTemplate.bounds,
            boundsAreWorld = true,
            side = previousSide
        }

        editor.RebuildSmartDuplicateCandidates()
        editor.SetTool("place")
        editor.ShowStatus("smart_duplicate.choose")
        return true
    end

    local primaryId = items[1].id
    local objectData = items[1].object
    local template = editor.MakeCloneTemplate(objectData)

    if not template then
        return false
    end

    if not MapStudio.Ghost or not MapStudio.Ghost.SetTemplate or not MapStudio.Ghost.SetTemplate(template) then
        return false
    end

    editor.SmartDuplicate = {
        active = true,
        isGroup = false,
        template = template,
        sourcePivot = vectorToTable(items[1].pos),
        sourceAng = MapStudio.DeepCopy(objectData.ang),
        bounds = boundsForObject(primaryId, objectData),
        boundsAreWorld = false,
        side = previousSide
    }

    editor.RebuildSmartDuplicateCandidates()
    editor.SetTool("place")
    editor.ShowStatus("smart_duplicate.choose")
    return true
end

function editor.StopSmartDuplicate()
    editor.SmartDuplicate = nil
end

function editor.OnGhostPlaced(payload, placement)
    local smart = editor.SmartDuplicate

    if not smart or smart.active ~= true or type(payload) ~= "table" then
        return
    end

    if smart.isGroup then
        smart.sourcePivot = vectorToTable(placement.pos)
        local template = activePreviewTemplate(smart)

        if type(template) == "table" and template.isGroup == true then
            smart.template = template
            smart.sourceAng = MapStudio.DeepCopy(template.ang)
            smart.bounds = template.bounds or smart.bounds
        end
    else
        smart.sourcePivot = payload.pos or vectorToTable(placement.pos)
        smart.sourceAng = payload.ang or angleToTable(placement.ang or MapStudio.Objects.ToAngle(smart.template.ang))
        smart.template = editor.MakeCloneTemplate(payload) or smart.template
    end

    smart.candidates = nil
    editor.RebuildSmartDuplicateCandidates()
end

function editor.SetReactiveObjects(ids, enabled)
    if type(ids) ~= "table" or not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return false
    end

    enabled = enabled == true

    local behavior = enabled and "reactive" or "static"
    local updates = {}
    local undoUpdates = {}

    for _, id in ipairs(ids) do
        local objectData = MapStudio.ClientState.objects[id]

        if objectData then
            local before = MapStudio.DeepCopy(objectData)
            local after = MapStudio.DeepCopy(objectData)

            after.reactive = enabled
            after.behavior = behavior
            after.frozen = true
            after.motion = false

            objectData.reactive = enabled
            objectData.behavior = behavior
            objectData.frozen = true
            objectData.motion = false

            table.insert(undoUpdates, {
                id = id,
                before = before,
                after = after
            })

            table.insert(updates, {
                id = id,
                patch = {
                    reactive = enabled,
                    behavior = behavior,
                    frozen = true,
                    motion = false
                }
            })
        end
    end

    if #updates == 0 then
        return false
    end

    if #updates == 1 then
        local update = updates[1]
        local undoUpdate = undoUpdates[1]

        MapStudio.Undo.Push({
            type = "update",
            id = undoUpdate.id,
            before = undoUpdate.before,
            after = undoUpdate.after
        })
        MapStudio.Client.UpdateObject(update.id, update.patch)
    else
        MapStudio.Undo.Push({
            type = "batch_update",
            updates = undoUpdates
        })

        if MapStudio.Client.UpdateObjects then
            MapStudio.Client.UpdateObjects(updates)
        else
            for _, update in ipairs(updates) do
                MapStudio.Client.UpdateObject(update.id, update.patch)
            end
        end
    end

    hook.Run("MapStudioSelectionChanged", MapStudio.ClientState.selectedId, MapStudio.ClientState.selectedIds or {})
    return true
end

function editor.ToggleReactiveSelected()
    local ids = editor.GetSelectedIDs()

    if #ids == 0 then
        return false
    end

    local primaryId = editor.GetPrimarySelectedID() or ids[#ids]
    local primaryObject = primaryId and MapStudio.ClientState.objects[primaryId] or nil

    if not primaryObject then
        return false
    end

    return editor.SetReactiveObjects(ids, not isReactiveObject(primaryObject))
end

function editor.DeleteSelected()
    local ids = editor.GetSelectedIDs()

    if #ids == 0 then
        return
    end

    debugBinds("delete_selected sending ids=" .. table.concat(ids, ","))

    if MapStudio.Gizmo then
        MapStudio.Gizmo.CancelDrag()
    end

    MapStudio.Client.DeleteObjects(ids)
    editor.ClearSelection()
end

function editor.ConfirmDeleteSelected()
    editor.DeleteSelected()
end

function editor.RotateSelectedYaw(delta)
    if MapStudio.Gizmo and MapStudio.Gizmo.RotateSelectedByHandle then
        MapStudio.Gizmo.RotateSelectedByHandle("rot_z", delta)
    end
end

local function rotateHandle(handle, delta)
    if MapStudio.Ghost and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive() and MapStudio.Ghost.RotateByHandle then
        local rotated = MapStudio.Ghost.RotateByHandle(handle, delta)

        if rotated then
            editor.SyncSmartDuplicatePreviewState()
            return true
        end

        return false
    end

    if MapStudio.Gizmo and MapStudio.Gizmo.RotateSelectedByHandle and MapStudio.Gizmo.RotateSelectedByHandle(handle, delta) then
        return true
    end

    return false
end

function editor.RotateYaw(delta)
    rotateHandle("rot_z", delta)
end

function editor.CancelOrClear()
    editor.StopSmartDuplicate()

    if MapStudio.Ghost and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive() then
        MapStudio.ClientState.selectedModel = nil
        MapStudio.Ghost.Cancel()
    end

    if MapStudio.Gizmo then
        MapStudio.Gizmo.CancelDrag()
    end

    editor.ClearSelection()
    editor.SetTool("select")
end

ACTION_HANDLERS = {
    delete_selected = function()
        editor.DeleteSelected()
    end,
    cancel_selection = function()
        editor.CancelOrClear()
    end,
    toggle_grid = function()
        MapStudio.Grid.Toggle("show_grid")
        editor.UpdateToolbarState()
    end,
    toggle_snap = function()
        MapStudio.Grid.Toggle("snap_grid")
    end,
    rotate_blue_left = function()
        rotateHandle("rot_z", -MapStudio.Grid.GetRotationSnap())
    end,
    rotate_blue_right = function()
        rotateHandle("rot_z", MapStudio.Grid.GetRotationSnap())
    end,
    rotate_red_up = function()
        rotateHandle("rot_x", MapStudio.Grid.GetRotationSnap())
    end,
    rotate_red_down = function()
        rotateHandle("rot_x", -MapStudio.Grid.GetRotationSnap())
    end,
    rotate_green_left = function()
        rotateHandle("rot_y", -MapStudio.Grid.GetRotationSnap())
    end,
    rotate_green_right = function()
        rotateHandle("rot_y", MapStudio.Grid.GetRotationSnap())
    end,
    cycle_rotation_angle = function()
        local degrees = MapStudio.Grid.CycleRotationSnap()
        editor.ShowStatus("settings.rotation_angle_status", { degrees = degrees })
    end,
    reset_transform = function()
        if MapStudio.Gizmo and MapStudio.Gizmo.ResetSelectedTransform then
            MapStudio.Gizmo.ResetSelectedTransform()
        end
    end,
    toggle_reactive = function()
        editor.ToggleReactiveSelected()
    end,
    copy_object = function()
        editor.CopySelectedObject()
    end,
    paste_object = function()
        editor.PasteClipboard()
    end,
    smart_duplicate = function()
        editor.StartSmartDuplicate()
    end,
    exit_editor = function()
        editor.Close()
    end,
    toggle_free_props = function()
        editor.ToggleFreeProps()
    end
}

function editor.DispatchAction(action, source)
    local handler = ACTION_HANDLERS and ACTION_HANDLERS[action]

    if not handler then
        return false
    end

    debugBinds("action=" .. tostring(action) .. " source=" .. tostring(source or "ui") .. " selected=" .. tostring(MapStudio.ClientState and MapStudio.ClientState.selectedId or "nil"))
    handler()
    return true
end

function editor.SuppressKey(key)
    key = tonumber(key) or 0

    if key > 0 then
        editor.SuppressedKeys[key] = true
        editor.KeyState[key] = true
    end
end

local function buildToolbar(parent)
    if not IsValid(parent) then
        return
    end

    editor.DeleteButton = nil
    editor.GridButton = nil
    editor.FreePropsButton = nil
    editor.CancelButton = nil
    editor.SmartDuplicateButton = nil

    local settingsButton = vgui.Create("MS_Button", parent)
    settingsButton:Dock(LEFT)
    settingsButton:DockMargin(0, 0, 6, 0)
    settingsButton:SetWide(105)
    settingsButton:SetText(MapStudio.T("common.settings"))
    settingsButton.DoClick = function()
        editor.ShowSettings()
    end

    editor.GridButton = vgui.Create("MS_Button", parent)
    editor.GridButton:Dock(LEFT)
    editor.GridButton:DockMargin(0, 0, 6, 0)
    editor.GridButton:SetWide(95)
    editor.GridButton.DoClick = function()
        editor.DispatchAction("toggle_grid", "toolbar")
    end

    editor.FreePropsButton = vgui.Create("MS_Button", parent)
    editor.FreePropsButton:Dock(LEFT)
    editor.FreePropsButton:DockMargin(0, 0, 6, 0)
    editor.FreePropsButton:SetWide(145)
    editor.FreePropsButton:SetText(MapStudio.T("toolbar.free_props"))
    editor.FreePropsButton:SetTooltip(MapStudio.T("toolbar.free_props_tooltip"))

    if editor.FreePropsButton.SetToggled then
        editor.FreePropsButton:SetToggled(editor.FreeProps == true)
    end

    editor.FreePropsButton.DoClick = function()
        editor.DispatchAction("toggle_free_props", "toolbar")
    end

    editor.CancelButton = vgui.Create("MS_Button", parent)
    editor.CancelButton:Dock(LEFT)
    editor.CancelButton:DockMargin(0, 0, 6, 0)
    editor.CancelButton:SetWide(145)
    editor.CancelButton:SetText(MapStudio.T("toolbar.cancel_selection"))
    editor.CancelButton.DoClick = function()
        editor.DispatchAction("cancel_selection", "toolbar")
    end

    editor.SmartDuplicateButton = vgui.Create("MS_Button", parent)
    editor.SmartDuplicateButton:Dock(LEFT)
    editor.SmartDuplicateButton:DockMargin(0, 0, 6, 0)
    editor.SmartDuplicateButton:SetWide(180)
    editor.SmartDuplicateButton:SetText(MapStudio.T("smart_duplicate.title"))
    editor.SmartDuplicateButton.DoClick = function()
        editor.DispatchAction("smart_duplicate", "toolbar")
    end

    editor.DeleteButton = vgui.Create("MS_Button", parent)
    editor.DeleteButton:Dock(LEFT)
    editor.DeleteButton:DockMargin(0, 0, 6, 0)
    editor.DeleteButton:SetWide(95)
    editor.DeleteButton:SetText(MapStudio.T("common.delete"))
    editor.DeleteButton:SetDanger(true)
    editor.DeleteButton.DoClick = function()
        editor.DispatchAction("delete_selected", "toolbar")
    end

    local exit = vgui.Create("MS_Button", parent)
    exit:Dock(RIGHT)
    exit:SetWide(130)
    exit:SetText(MapStudio.T("editor.exit"))
    exit.DoClick = function()
        editor.DispatchAction("exit_editor", "toolbar")
    end

    editor.UpdateToolbarState()
end

local function paintCollapseButton(button, width, height)
    local bg = button:IsHovered() and MapStudio.Theme.Colors.accent or MapStudio.Theme.Colors.panelAlt

    surface.SetDrawColor(bg)
    surface.DrawRect(0, 0, width, height)
    surface.SetDrawColor(MapStudio.Theme.Colors.border)
    surface.DrawOutlinedRect(0, 0, width, height, 1)
    draw.SimpleText(button.Arrow or ">", "MapStudio.Label", width * 0.5, height * 0.5, MapStudio.Theme.Colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function buildCollapseHandle(parent, side)
    local handle = vgui.Create("DPanel", parent)
    if not IsValid(handle) then return nil end

    handle:Dock(side == "left" and LEFT or RIGHT)
    handle:SetWide(COLLAPSE_HANDLE_WIDTH)
    handle:SetPaintBackground(false)

    local button = vgui.Create("DButton", handle)
    if not IsValid(button) then return handle end

    button:Dock(TOP)
    button:SetTall(36)
    button:SetText("")
    button.Paint = paintCollapseButton
    button.DoClick = function()
        if side == "left" then
            editor.LeftCollapsed = not editor.LeftCollapsed
        else
            editor.RightCollapsed = not editor.RightCollapsed
        end

        editor.ApplyPanelCollapse()
    end

    if side == "left" then
        editor.LeftCollapseButton = button
    else
        editor.RightCollapseButton = button
    end

    return handle
end

function editor.ApplyPanelCollapse()
    if IsValid(editor.LeftPanel) then
        editor.LeftPanel:SetVisible(not editor.LeftCollapsed)
        editor.LeftPanel:SetWide(editor.LeftCollapsed and 0 or LEFT_PANEL_WIDTH)
    end

    if IsValid(editor.LeftCollapseButton) then
        editor.LeftCollapseButton.Arrow = editor.LeftCollapsed and ">" or "<"
        editor.LeftCollapseButton:SetTooltip(MapStudio.T(editor.LeftCollapsed and "ui.expand_asset_browser" or "ui.collapse_asset_browser"))
    end

    if IsValid(editor.RightPanel) then
        editor.RightPanel:SetVisible(not editor.RightCollapsed)
        editor.RightPanel:SetWide(editor.RightCollapsed and 0 or RIGHT_PANEL_WIDTH)
    end

    if IsValid(editor.RightCollapseButton) then
        editor.RightCollapseButton.Arrow = editor.RightCollapsed and "<" or ">"
        editor.RightCollapseButton:SetTooltip(MapStudio.T(editor.RightCollapsed and "ui.expand_inspector" or "ui.collapse_inspector"))
    end

    if IsValid(editor.Frame) then
        editor.Frame:InvalidateLayout(true)
    end
end

function editor.BuildRightPanel()
    local right = editor.RightPanel

    if not IsValid(right) then
        return
    end

    right:Clear()

    local scroll = vgui.Create("DScrollPanel", right)
    if not IsValid(scroll) then return end
    scroll:Dock(FILL)

    if editor.RightMode == "settings" then
        MapStudio.Settings.Build(scroll)
    else
        MapStudio.Inspector.Build(scroll)
    end
end

function editor.ShowSettings()
    editor.RightMode = "settings"
    editor.BuildRightPanel()
end

function editor.ShowInspector()
    editor.RightMode = "inspector"
    editor.BuildRightPanel()
end

local function buildWorld(parent)
    if not IsValid(parent) then
        return
    end

    editor.WorldPanel = vgui.Create("DPanel", parent)
    if not IsValid(editor.WorldPanel) then
        editor.WorldPanel = nil
        return
    end

    editor.WorldPanel:Dock(FILL)
    editor.WorldPanel:SetPaintBackground(false)
    editor.WorldPanel.OnRemove = function(panel)
        if editor.WorldPanel == panel then
            editor.WorldPanel = nil
        end
    end

    editor.WorldPanel.OnMousePressed = function(_, mouseCode)
        if mouseCode == MOUSE_LEFT then
            if MapStudio.Ghost and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive() then
                MapStudio.Ghost.Place()
                return
            end

            if MapStudio.Gizmo and MapStudio.Gizmo.BeginDrag and MapStudio.Gizmo.BeginDrag() then
                return
            end

            local additive = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
            editor.SelectByTrace(additive)
        elseif mouseCode == MOUSE_RIGHT then
            if MapStudio.Freecam then
                MapStudio.Freecam.SetMouseLook(true)
            end
        end
    end

    editor.WorldPanel.OnMouseReleased = function(_, mouseCode)
        if mouseCode == MOUSE_RIGHT and MapStudio.Freecam then
            MapStudio.Freecam.SetMouseLook(false)
        end
    end

    editor.WorldPanel.OnMouseWheeled = function(_, delta)
        if editor.KeyboardFocused() then
            return
        end

        if MapStudio.Settings and MapStudio.Settings.IsCapturingBind and MapStudio.Settings.IsCapturingBind() then
            return
        end

        if MapStudio.Grid and MapStudio.Grid.MouseOverWorld and not MapStudio.Grid.MouseOverWorld() then
            return
        end

        if MapStudio.Ghost and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive() then
            return true
        end

        if editor.IsFreePropsEnabled() and MapStudio.Gizmo and MapStudio.Gizmo.AdjustSelectedDepth and MapStudio.Gizmo.AdjustSelectedDepth(delta) then
            return true
        end
    end
end

function editor.Build()
    local frame = editor.Frame
    if not IsValid(frame) then
        return
    end

    frame:Clear()

    local toolbar = makePanel(frame, TOP, nil, 52)
    if not IsValid(toolbar) then return end
    buildToolbar(toolbar)

    local body = vgui.Create("DPanel", frame)
    if not IsValid(body) then return end
    body:Dock(FILL)
    body:SetPaintBackground(false)

    local left = makePanel(body, LEFT, LEFT_PANEL_WIDTH)
    if not IsValid(left) then return end
    editor.LeftPanel = left

    local asset = vgui.Create("DPanel", left)
    if not IsValid(asset) then return end
    asset:Dock(TOP)
    asset:SetTall(math.floor(ScrH() * 0.62))
    asset:SetPaintBackground(false)
    MapStudio.AssetBrowser.Build(asset)

    local objectPanel = vgui.Create("DPanel", left)
    if not IsValid(objectPanel) then return end
    objectPanel:Dock(FILL)
    objectPanel:DockMargin(0, 10, 0, 0)
    objectPanel:SetPaintBackground(false)
    MapStudio.ObjectList.Build(objectPanel)

    editor.LeftCollapseHandle = buildCollapseHandle(body, "left")

    editor.RightPanel = makePanel(body, RIGHT, RIGHT_PANEL_WIDTH)
    if not IsValid(editor.RightPanel) then return end
    editor.BuildRightPanel()

    editor.RightCollapseHandle = buildCollapseHandle(body, "right")

    buildWorld(body)
    editor.ApplyPanelCollapse()
end

function editor.Open()
    if IsValid(editor.Frame) then
        return editor.Focus()
    end

    editor.Frame = nil
    editor.RightMode = "inspector"
    editor.SetFreeProps(false)
    MapStudio.Client.RequestState()

    local frame = vgui.Create("MS_Frame")
    if not IsValid(frame) then
        MapStudio.LogError("Editor frame could not be created. The MS_Frame client UI control may be missing.")
        return false, "error.editor_open_failed"
    end

    editor.Frame = frame

    frame.OnRemove = function(panel)
        if editor.Frame == panel then
            editor.Frame = nil
        end

        editor.WorldPanel = nil
        editor.LeftPanel = nil
        editor.RightPanel = nil
        editor.SelectedEntityCache = nil
        editor.FreeProps = false
        editor.KeyState = {}
        editor.SuppressedKeys = {}
        editor.CtrlShortcutState = {}
        editor.SmartDuplicate = nil
        editor.PendingCreatedSelections = 0
        editor.PendingCreatedID = nil
        editor.PendingCreatedIDs = nil

        if MapStudio.ClientState then
            MapStudio.ClientState.selectedId = nil
            MapStudio.ClientState.selectedIds = {}
            hook.Run("MapStudioSelectionChanged", nil, {})
        end

        if MapStudio.Freecam then
            MapStudio.Freecam.Disable()
        end

        if MapStudio.Ghost then
            MapStudio.Ghost.Remove()
        end

        if MapStudio.Gizmo then
            MapStudio.Gizmo.CancelDrag()
        end

        gui.EnableScreenClicker(false)
    end

    local prepared, prepareError = xpcall(function()
        frame:SetSize(ScrW(), ScrH())
        frame:SetPos(0, 0)
        frame:MakePopup()
        frame:SetKeyboardInputEnabled(true)
        frame:SetMouseInputEnabled(true)
    end, editorTraceback)

    if not prepared then
        MapStudio.LogError("Editor frame setup failed: " .. tostring(prepareError))
        frame:Remove()
        return false, "error.editor_open_failed"
    end

    local ok, err = pcall(editor.Build)

    if not ok then
        local message = tostring(err or "error.editor_open_failed")
        frame:Remove()
        editor.Frame = nil
        MapStudio.LogError("Editor build failed: " .. message)
        return false, "error.editor_open_failed"
    end

    if not IsValid(editor.WorldPanel) then
        frame:Remove()
        editor.Frame = nil
        MapStudio.LogError("Editor build failed: world panel was not created.")
        return false, "error.editor_open_failed"
    end

    local initialized, initializeError = xpcall(function()
        gui.EnableScreenClicker(true)

        if MapStudio.Freecam then
            MapStudio.Freecam.Enable()
        end

        if MapStudio.Ghost then
            MapStudio.Ghost.SetModel(MapStudio.ClientState.selectedModel or MapStudio.Config.DefaultObject.model)
            MapStudio.Ghost.Cancel()
        end
    end, editorTraceback)

    if not initialized then
        MapStudio.LogError("Editor initialization failed: " .. tostring(initializeError))
        frame:Remove()
        return false, "error.editor_open_failed"
    end

    return true
end

function editor.Close()
    editor.ClearSelection()

    if MapStudio.Freecam then
        MapStudio.Freecam.Disable()
    end

    if MapStudio.Ghost then
        MapStudio.Ghost.Remove()
    end

    if MapStudio.Gizmo then
        MapStudio.Gizmo.CancelDrag()
    end

    gui.EnableScreenClicker(false)

    local frame = editor.Frame

    editor.Frame = nil
    editor.WorldPanel = nil
    editor.LeftPanel = nil
    editor.RightPanel = nil
    editor.FreeProps = false
    editor.KeyState = {}
    editor.SuppressedKeys = {}
    editor.CtrlShortcutState = {}
    editor.SmartDuplicate = nil
    editor.PendingCreatedSelections = 0
    editor.PendingCreatedID = nil
    editor.PendingCreatedIDs = nil

    if IsValid(frame) then
        frame:Remove()
    end
end

function editor.Rebuild()
    if editor.IsOpen() then
        editor.Build()
    end
end

hook.Add("MapStudioStateChanged", "MapStudio_EditorStateChanged", function()
    if not editor.IsOpen() then
        return
    end

    trySelectPendingCreated()
    editor.UpdateToolbarState()
end)

hook.Add("MapStudioSelectionChanged", "MapStudio_EditorSelectionChanged", function()
    editor.UpdateToolbarState()
end)

hook.Add("MapStudioToolChanged", "MapStudio_EditorToolChanged", function()
    editor.UpdateToolbarState()
end)

hook.Add("HUDPaint", "MapStudio_EditorStatus", function()
    if not editor.IsOpen() or not editor.StatusText or CurTime() > (editor.StatusUntil or 0) then
        return
    end

    surface.SetFont("MapStudio.Title")
    local width, height = surface.GetTextSize(editor.StatusText)
    local x = (ScrW() - width) * 0.5
    local y = ScrH() - math.max(90, height + 32)

    draw.RoundedBox(6, x - 14, y - 8, width + 28, height + 16, Color(20, 24, 28, 190))
    draw.SimpleText(editor.StatusText, "MapStudio.Title", ScrW() * 0.5, y, MapStudio.Theme.Colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)

hook.Add("PreDrawHalos", "MapStudio_SelectedHalo", function()
    if not editor.IsOpen() then
        return
    end

    local staticEntities = {}
    local reactiveEntities = {}

    for _, id in ipairs(editor.GetSelectedIDs()) do
        local ent = editor.FindEntityByObjectID(id)
        local objectData = MapStudio.ClientState and MapStudio.ClientState.objects and MapStudio.ClientState.objects[id]

        if IsValid(ent) then
            if isReactiveObject(objectData) then
                table.insert(reactiveEntities, ent)
            else
                table.insert(staticEntities, ent)
            end
        end
    end

    if #staticEntities > 0 then
        halo.Add(staticEntities, MapStudio.Theme.Colors.accent, 2, 2, 1, true, true)
    end

    if #reactiveEntities > 0 then
        halo.Add(reactiveEntities, Color(235, 70, 70), 2, 2, 1, true, true)
    end
end)

local function smartMarkerPosition(candidate, bounds)
    bounds = MapStudio.Placement.NormalizeBounds(bounds)
    local height = math.max(18, bounds.maxs.z - bounds.mins.z)

    return candidate.pos + Vector(0, 0, height + 10)
end

hook.Add("PostDrawTranslucentRenderables", "MapStudio_SmartDuplicateMarkers", function()
    local smart = editor.SmartDuplicate

    if not editor.IsOpen() or not smart or smart.active ~= true or not smart.candidates then
        return
    end

    render.SetColorMaterial()

    local sourcePos = MapStudio.Objects.ToVector(smart.sourcePivot)

    for _, side in ipairs(SMART_DUPLICATE_SIDES) do
        local candidate = smart.candidates[side]

        if candidate then
            local selected = smart.side == side
            local color = selected and MapStudio.Theme.Colors.accentHover or Color(75, 149, 255, 115)
            local markerPos = smartMarkerPosition(candidate, smart.bounds)

            render.DrawLine(sourcePos, candidate.pos, color, true)
            render.DrawSphere(markerPos, selected and 5 or 3, 10, 10, color)
        end
    end
end)

hook.Add("HUDPaint", "MapStudio_SmartDuplicateLabels", function()
    local smart = editor.SmartDuplicate

    if not editor.IsOpen() or not smart or smart.active ~= true or not smart.candidates then
        return
    end

    for _, side in ipairs(SMART_DUPLICATE_SIDES) do
        local candidate = smart.candidates[side]

        if candidate then
            local screenPos = smartMarkerPosition(candidate, smart.bounds):ToScreen()

            if screenPos.visible ~= false then
                local label = MapStudio.T(candidate.labelKey)
                local selected = smart.side == side
                surface.SetFont("MapStudio.Small")
                local width, height = surface.GetTextSize(label)
                local x = screenPos.x - width * 0.5
                local y = screenPos.y - height * 0.5
                local bg = selected and Color(30, 80, 145, 220) or Color(20, 24, 28, 185)

                draw.RoundedBox(4, x - 6, y - 3, width + 12, height + 6, bg)
                draw.SimpleText(label, "MapStudio.Small", screenPos.x, screenPos.y, MapStudio.Theme.Colors.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end
    end
end)

local function keyForBind(name)
    local conVar = MapStudio.Grid.GetConVar(name)
    local key = conVar and conVar:GetInt() or 0

    if MOUSE_RIGHT and key == MOUSE_RIGHT then
        return 0
    end

    return key
end

local function ctrlDown()
    return input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
end

local function updateSuppressedKey(key, isDown)
    if not editor.SuppressedKeys[key] then
        return false
    end

    if not isDown then
        editor.SuppressedKeys[key] = nil
    end

    return true
end

local function handleClipboardShortcuts()
    if not ctrlDown() then
        editor.CtrlShortcutState = {}
        return false
    end

    local shortcuts = {
        { key = KEY_C, action = "copy_object" },
        { key = KEY_V, action = "paste_object" }
    }

    for _, shortcut in ipairs(shortcuts) do
        local isDown = input.IsKeyDown(shortcut.key)
        local wasDown = editor.CtrlShortcutState[shortcut.key] == true
        editor.CtrlShortcutState[shortcut.key] = isDown

        if isDown and not wasDown then
            editor.SuppressKey(shortcut.key)
            editor.DispatchAction(shortcut.action, "shortcut")
            return true
        end
    end

    return false
end

local function rememberBindStates()
    for _, bind in ipairs(ACTION_BINDS) do
        local key = keyForBind(bind.conVar)

        if key > 0 then
            local isDown = input.IsKeyDown(key)
            editor.KeyState[key] = isDown
            updateSuppressedKey(key, isDown)
        end
    end
end

local function inputCaptureActive()
    return MapStudio.Settings and MapStudio.Settings.IsCapturingBind and MapStudio.Settings.IsCapturingBind()
end

hook.Add("Think", "MapStudio_EditorKeybinds", function()
    if not editor.IsOpen() then
        editor.KeyState = {}
        editor.SuppressedKeys = {}
        editor.CtrlShortcutState = {}
        return
    end

    if editor.KeyboardFocused() or inputCaptureActive() then
        rememberBindStates()
        return
    end

    if handleClipboardShortcuts() then
        rememberBindStates()
        return
    end

    local ctrl = ctrlDown()

    for _, bind in ipairs(ACTION_BINDS) do
        local key = keyForBind(bind.conVar)

        if key > 0 then
            local isDown = input.IsKeyDown(key)
            local wasDown = editor.KeyState[key] == true
            editor.KeyState[key] = isDown
            local modifierAllowed = (bind.requireCtrl == true and ctrl) or (bind.requireCtrl ~= true and not ctrl)

            if not updateSuppressedKey(key, isDown) and modifierAllowed and isDown and not wasDown then
                debugBinds("key edge action=" .. bind.action .. " key=" .. tostring(key))
                editor.DispatchAction(bind.action, "bind")
                break
            end
        end
    end
end)

hook.Add("SpawnMenuOpen", "MapStudio_BlockSpawnMenuWhileEditor", function()
    if editor.IsOpen() then
        return false
    end
end)

hook.Add("ContextMenuOpen", "MapStudio_BlockContextMenuWhileEditor", function()
    if editor.IsOpen() then
        return false
    end
end)

cvars.AddChangeCallback("mapstudio_show_grid", function()
    editor.UpdateToolbarState()
end, "MapStudio_GridToolbarState")
