MapStudio = MapStudio or {}
MapStudio.ObjectList = MapStudio.ObjectList or {}

local objectList = MapStudio.ObjectList
objectList.SortColumn = objectList.SortColumn or nil
objectList.SortAscending = objectList.SortAscending ~= false

local function shortID(id)
    id = tostring(id or "")

    if #id <= 12 then
        return id
    end

    return string.sub(id, 1, 6) .. "..." .. string.sub(id, -4)
end

local function selectedSet()
    local set = {}

    if MapStudio.Editor and MapStudio.Editor.GetSelectedIDs then
        for _, id in ipairs(MapStudio.Editor.GetSelectedIDs()) do
            set[id] = true
        end
    end

    return set
end

local function displayModelName(objectData)
    local model = objectData and objectData.model or ""
    return MapStudio.AssetBrowser and MapStudio.AssetBrowser.ShortName and MapStudio.AssetBrowser.ShortName(model) or tostring(model)
end

local function stableID(id)
    return string.lower(tostring(id or ""))
end

local function stableCreatedAt(objectData)
    return tonumber(objectData and objectData.createdAt) or 0
end

local function stableLess(left, right)
    local leftTime = stableCreatedAt(left.objectData)
    local rightTime = stableCreatedAt(right.objectData)

    if leftTime ~= rightTime then
        return leftTime < rightTime
    end

    return stableID(left.id) < stableID(right.id)
end

local function sortedObjects()
    local rows = {}
    local objects = MapStudio.ClientState and MapStudio.ClientState.objects or {}

    for id, objectData in pairs(objects or {}) do
        table.insert(rows, {
            id = tostring(id or ""),
            objectData = objectData,
            model = tostring(objectData and objectData.model or ""),
            modelName = displayModelName(objectData)
        })
    end

    local sortColumn = objectList.SortColumn
    local ascending = objectList.SortAscending ~= false

    table.sort(rows, function(left, right)
        local result

        if sortColumn == "id" then
            local leftID = stableID(left.id)
            local rightID = stableID(right.id)

            if leftID ~= rightID then
                result = leftID < rightID
            else
                result = stableLess(left, right)
            end
        elseif sortColumn == "model" then
            local leftModel = string.lower(left.model)
            local rightModel = string.lower(right.model)

            if leftModel ~= rightModel then
                result = leftModel < rightModel
            else
                result = stableLess(left, right)
            end
        else
            result = stableLess(left, right)
        end

        if ascending then
            return result
        end

        if sortColumn == nil and not result then
            return false
        end

        return not result and stableID(left.id) ~= stableID(right.id)
    end)

    return rows
end

local function applyColumnSort(column, sortColumn)
    local function doSort()
        if objectList.SortColumn == sortColumn then
            objectList.SortAscending = objectList.SortAscending == false
        else
            objectList.SortColumn = sortColumn
            objectList.SortAscending = true
        end

        objectList.Refresh()
    end

    if column then
        column.DoClick = doSort
    end

    local header = column and (column.Header or column.m_Header or (column.GetHeader and column:GetHeader()))

    if IsValid(header) then
        header.DoClick = doSort
    end
end

function objectList.Build(parent)
    if not IsValid(parent) then
        return
    end

    parent:Clear()

    local title = vgui.Create("DLabel", parent)
    if not IsValid(title) then return end

    title:Dock(TOP)
    title:DockMargin(0, 0, 0, 6)
    title:SetText(MapStudio.T("objectlist.title"))
    title:SetFont("MapStudio.Title")
    title:SetTextColor(MapStudio.Theme.Colors.text)

    local filter = vgui.Create("MS_TextEntry", parent)
    if not IsValid(filter) then return end

    filter:Dock(TOP)
    filter:DockMargin(0, 0, 0, 6)
    filter:SetPlaceholderText(MapStudio.T("objectlist.filter"))

    local list = vgui.Create("DListView", parent)
    if not IsValid(list) then return end

    list:Dock(FILL)
    list:SetMultiSelect(true)
    local idColumn = list:AddColumn(MapStudio.T("objectlist.column_id"))
    local modelColumn = list:AddColumn(MapStudio.T("objectlist.column_model"))
    applyColumnSort(idColumn, "id")
    applyColumnSort(modelColumn, "model")

    objectList.Panel = parent
    objectList.List = list
    objectList.Filter = filter

    filter.OnChange = function()
        objectList.Refresh()
    end

    list.OnRowSelected = function(_, _, row)
        if objectList.Refreshing then
            return
        end

        local additive = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
        MapStudio.Editor.Select(row.ObjectID, additive)
    end

    list.DoDoubleClick = function(_, _, row)
        if not row or not row.ObjectID then
            return
        end

        MapStudio.Editor.Select(row.ObjectID)

        if MapStudio.Freecam and MapStudio.Freecam.FocusObject then
            MapStudio.Freecam.FocusObject(row.ObjectID)
        end
    end

    list.OnRowRightClick = function(_, _, row)
        if not row or not row.ObjectID then
            return
        end

        if selectedSet()[row.ObjectID] then
            MapStudio.Editor.ClearSelection()
        else
            MapStudio.Editor.Select(row.ObjectID)
        end
    end

    list.OnKeyCodePressed = function(_, key)
        if key == KEY_DELETE then
            MapStudio.Editor.ConfirmDeleteSelected()
        end
    end

    objectList.Refresh()
end

function objectList.Refresh()
    local list = objectList.List
    if not IsValid(list) then
        return
    end

    objectList.Refreshing = true
    list:Clear()

    local needle = IsValid(objectList.Filter) and string.lower(objectList.Filter:GetText() or "") or ""
    local selected = selectedSet()

    for _, rowData in ipairs(sortedObjects()) do
        local id = rowData.id
        local objectData = rowData.objectData
        local haystack = string.lower(id .. " " .. tostring(objectData and objectData.model))

        if needle == "" or string.find(haystack, needle, 1, true) then
            local modelName = rowData.modelName
            local row = list:AddLine(shortID(id), modelName)
            row.ObjectID = id
            row:SetTooltip(id .. "\n" .. tostring(objectData and objectData.model))

            if selected[id] then
                row:SetSelected(true)
            end
        end
    end

    objectList.Refreshing = false
end

function objectList.UpdateSelection()
    local list = objectList.List
    if not IsValid(list) then
        return
    end

    local selected = selectedSet()
    objectList.Refreshing = true

    if list.ClearSelection then
        list:ClearSelection()
    end

    for _, row in pairs(list:GetLines() or {}) do
        if row.ObjectID and selected[row.ObjectID] then
            row:SetSelected(true)
        else
            row:SetSelected(false)
        end
    end

    objectList.Refreshing = false
end

hook.Add("MapStudioStateChanged", "MapStudio_ObjectListRefresh", function()
    objectList.Refresh()
end)

hook.Add("MapStudioSelectionChanged", "MapStudio_ObjectListSelection", function()
    objectList.UpdateSelection()
end)
