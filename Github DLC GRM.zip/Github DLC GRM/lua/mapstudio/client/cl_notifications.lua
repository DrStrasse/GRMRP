MapStudio = MapStudio or {}

local levels = {
    info = NOTIFY_GENERIC,
    error = NOTIFY_ERROR,
    warning = NOTIFY_HINT
}

function MapStudio.NotifyLocal(key, level, replacements)
    local translated, text = pcall(function()
        return MapStudio.T(key, replacements)
    end)

    if not translated then
        text = tostring(key or "notify.invalid_request")

        if MapStudio.LogError then
            MapStudio.LogError("Notification translation failed: " .. tostring(text))
        else
            print("[MapStudio] ERROR: Notification translation failed: " .. tostring(text))
        end
    end

    text = tostring(text or key or "notify.invalid_request")

    local logLevel = level == "error" and "ERROR" or level == "warning" and "WARNING" or nil

    if MapStudio.Log then
        MapStudio.Log(text, logLevel)
    else
        local prefix = logLevel and ("[MapStudio] " .. logLevel .. ": ") or "[MapStudio] "
        print(prefix .. text)
    end

    if notification and notification.AddLegacy then
        local ok, err = pcall(notification.AddLegacy, text, levels[level or "info"] or NOTIFY_GENERIC, 4)

        if not ok and MapStudio.LogWarning then
            MapStudio.LogWarning("Local notification could not be displayed: " .. tostring(err))
        end
    end

    if chat and chat.AddText then
        local accent = MapStudio.Theme and MapStudio.Theme.Colors and MapStudio.Theme.Colors.accent

        if not accent and Color then
            accent = Color(90, 160, 255)
        end

        accent = accent or color_white

        local name = "MapStudio"

        if MapStudio.T then
            local nameOk, translatedName = pcall(MapStudio.T, "addon.name")

            if nameOk and translatedName then
                name = tostring(translatedName)
            end
        end

        local ok, err = pcall(chat.AddText, accent, "[" .. tostring(name) .. "] ", color_white, text)

        if not ok and MapStudio.LogWarning then
            MapStudio.LogWarning("Chat notification could not be displayed: " .. tostring(err))
        end
    end
end

net.Receive(MapStudio.Net.Get("Notify"), function()
    local raw = net.ReadString() or "{}"
    local ok, payload = pcall(util.JSONToTable, raw)

    if not ok or type(payload) ~= "table" then
        MapStudio.NotifyLocal("notify.invalid_request", "warning")

        if MapStudio.LogWarning then
            MapStudio.LogWarning("Received an invalid notification payload from the server.")
        end

        return
    end

    MapStudio.NotifyLocal(payload.key or "notify.invalid_request", payload.level or "info", payload.replacements or {})
end)
