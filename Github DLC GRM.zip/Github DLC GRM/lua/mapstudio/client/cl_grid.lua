MapStudio = MapStudio or {}
MapStudio.Grid = MapStudio.Grid or {}

local grid = MapStudio.Grid

grid.ConVars = grid.ConVars or {}
grid.Cache = grid.Cache or {}
grid.ActiveContext = grid.ActiveContext or nil
grid.RotationPresets = { 15, 30, 45, 60, 90 }

local function createConVar(name, default, help)
    grid.ConVars[name] = CreateClientConVar("mapstudio_" .. name, tostring(default), true, false, help)
    return grid.ConVars[name]
end

createConVar("show_grid", "0", "Show the MapStudio editor grid")
createConVar("snap_grid", "0", "Snap MapStudio placement and movement to the grid")
createConVar("grid_size", tostring(MapStudio.Config.DefaultGridSize or 40), "MapStudio grid size in Source units")
createConVar("grid_radius", "12", "MapStudio local grid radius in cells")
createConVar("rotation_snap", tostring(MapStudio.Config.DefaultRotationSnap or 15), "MapStudio rotation snap step")
createConVar("bind_delete", tostring(KEY_DELETE), "MapStudio delete selected key")
createConVar("bind_cancel", tostring(KEY_BACKSPACE), "MapStudio cancel placement or clear selection key")
createConVar("bind_grid", tostring(KEY_G), "MapStudio toggle grid key")
createConVar("bind_snap", tostring(KEY_V), "MapStudio toggle snap key")
createConVar("bind_rotate_blue_left", tostring(KEY_Q), "MapStudio rotate blue ring left key")
createConVar("bind_rotate_blue_right", tostring(KEY_E), "MapStudio rotate blue ring right key")
createConVar("bind_rotate_red_up", tostring(KEY_UP), "MapStudio rotate red ring up key")
createConVar("bind_rotate_red_down", tostring(KEY_DOWN), "MapStudio rotate red ring down key")
createConVar("bind_rotate_green_left", tostring(KEY_LEFT), "MapStudio rotate green ring left key")
createConVar("bind_rotate_green_right", tostring(KEY_RIGHT), "MapStudio rotate green ring right key")
createConVar("bind_cycle_rotation_angle", tostring(KEY_P), "MapStudio cycle rotation angle key")
createConVar("bind_reset_transform", tostring(KEY_R), "MapStudio reset selected transform key")
createConVar("bind_toggle_reactive", tostring(KEY_K), "MapStudio toggle selected reactive object mode key")
createConVar("bind_smart_duplicate", tostring(KEY_D), "MapStudio smart duplicate key used with Ctrl")

local function extraContains(extra, ent)
    if not IsValid(ent) then
        return false
    end

    if istable and istable(extra) then
        for _, candidate in pairs(extra) do
            if IsValid(candidate) and candidate == ent then
                return true
            end
        end
    elseif IsValid(extra) and extra == ent then
        return true
    end

    return false
end

function grid.ShouldIgnoreTraceEntity(ent, extra)
    if not IsValid(ent) then
        return false
    end

    local ply = LocalPlayer()

    if IsValid(ply) then
        if ent == ply then
            return true
        end

        local weapon = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
        if IsValid(weapon) and ent == weapon then
            return true
        end
    end

    if MapStudio.Ghost and IsValid(MapStudio.Ghost.Entity) and ent == MapStudio.Ghost.Entity then
        return true
    end

    if extraContains(extra, ent) then
        return true
    end

    return ent.MapStudioGizmo == true or ent.MapStudioGhost == true or ent.MapStudioEditorHelper == true
end

local function traceFilter(extra)
    return function(ent)
        return not grid.ShouldIgnoreTraceEntity(ent, extra)
    end
end

local function basisFromNormal(normal)
    normal = Vector(normal.x, normal.y, normal.z)

    if normal:LengthSqr() <= 0 then normal = Vector(0, 0, 1) end
    normal:Normalize()

    local tangent = normal:Cross(Vector(0, 0, 1))

    if tangent:LengthSqr() < 0.001 then
        tangent = normal:Cross(Vector(1, 0, 0))
    end

    tangent:Normalize()

    local bitangent = normal:Cross(tangent)
    bitangent:Normalize()

    return tangent, bitangent, normal
end

local function sampleSurface(point, normal, extraFilter)
    local trace = util.TraceLine({
        start = point + normal * 48,
        endpos = point - normal * 96,
        filter = traceFilter(extraFilter),
        mask = MASK_SOLID
    })

    if not trace or not trace.Hit or trace.HitSky then
        return nil
    end

    if trace.HitPos:DistToSqr(point) > 128 * 128 then
        return nil
    end

    return {
        pos = trace.HitPos + trace.HitNormal * 0.55,
        normal = trace.HitNormal
    }
end

local function rounded(value, step)
    return math.Round((value or 0) / step) * step
end

local function vecKey(vec, step)
    return rounded(vec.x, step) .. "," .. rounded(vec.y, step) .. "," .. rounded(vec.z, step)
end

local function editorMouseOverWorld()
    if not MapStudio.Editor or not IsValid(MapStudio.Editor.WorldPanel) then
        return true
    end

    local hovered = vgui.GetHoveredPanel()

    if not IsValid(hovered) then
        return true
    end

    return hovered == MapStudio.Editor.WorldPanel or hovered:HasParent(MapStudio.Editor.WorldPanel)
end

function grid.MouseOverWorld()
    return editorMouseOverWorld()
end

function grid.GetConVar(name)
    return grid.ConVars[name] or GetConVar("mapstudio_" .. name)
end

function grid.GetBool(name)
    local conVar = grid.GetConVar(name)
    return conVar and conVar:GetBool() or false
end

function grid.GetNumber(name, fallback)
    local conVar = grid.GetConVar(name)
    return conVar and conVar:GetFloat() or fallback
end

function grid.GetSize()
    return math.max(1, grid.GetNumber("grid_size", MapStudio.Config.DefaultGridSize or 40))
end

function grid.GetRadiusCells()
    return math.Clamp(math.floor(grid.GetNumber("grid_radius", 12)), 4, 16)
end

function grid.NormalizeRotationStep(value)
    value = tonumber(value) or MapStudio.Config.DefaultRotationSnap or 15

    local best = grid.RotationPresets[1]
    local bestDistance = math.huge

    for _, preset in ipairs(grid.RotationPresets) do
        local distance = math.abs(value - preset)

        if distance < bestDistance then
            best = preset
            bestDistance = distance
        end
    end

    return best
end

function grid.SetRotationSnap(value)
    local preset = grid.NormalizeRotationStep(value)
    RunConsoleCommand("mapstudio_rotation_snap", tostring(preset))
    hook.Run("MapStudioRotationSnapChanged", preset)
    return preset
end

function grid.GetRotationSnap()
    local conVar = grid.GetConVar("rotation_snap")
    local raw = conVar and conVar:GetFloat() or MapStudio.Config.DefaultRotationSnap or 15
    local preset = grid.NormalizeRotationStep(raw)

    if raw ~= preset then
        RunConsoleCommand("mapstudio_rotation_snap", tostring(preset))
        hook.Run("MapStudioRotationSnapChanged", preset)
    end

    return preset
end

function grid.CycleRotationSnap()
    local current = grid.GetRotationSnap()
    local nextPreset = grid.RotationPresets[1]

    for index, preset in ipairs(grid.RotationPresets) do
        if preset == current then
            nextPreset = grid.RotationPresets[(index % #grid.RotationPresets) + 1]
            break
        end
    end

    return grid.SetRotationSnap(nextPreset)
end

cvars.AddChangeCallback("mapstudio_rotation_snap", function(_, _, newValue)
    hook.Run("MapStudioRotationSnapChanged", grid.NormalizeRotationStep(newValue))
end, "MapStudio_RotationSnapChanged")

function grid.Toggle(name)
    local conVar = grid.GetConVar(name)

    if conVar then
        RunConsoleCommand("mapstudio_" .. name, conVar:GetBool() and "0" or "1")
    end
end

function grid.SnapNumber(value, size)
    size = size or grid.GetSize()

    if size <= 0 then return value end
    return math.Round(value / size) * size
end

function grid.SnapNumberToCellCenter(value, size, originValue)
    size = size or grid.GetSize()
    originValue = originValue or 0

    if size <= 0 then return value end

    local normalized = ((value or 0) - originValue) / size
    return originValue + (math.Round(normalized - 0.5) + 0.5) * size
end

function grid.CreateSurfaceContext(trace)
    if not trace or not trace.Hit then
        return nil
    end

    local size = grid.GetSize()
    local tangent, bitangent, normal = basisFromNormal(trace.HitNormal)
    local hitPos = trace.HitPos or Vector(0, 0, 0)
    local originU = grid.SnapNumber(hitPos:Dot(tangent), size)
    local originV = grid.SnapNumber(hitPos:Dot(bitangent), size)

    return {
        type = "surface",
        size = size,
        tangent = tangent,
        bitangent = bitangent,
        normal = normal,
        originU = originU,
        originV = originV,
        planeDistance = hitPos:Dot(normal),
        anchorPos = tangent * originU + bitangent * originV + normal * hitPos:Dot(normal),
        entity = trace.Entity,
        matType = trace.MatType
    }
end

function grid.ShouldRefreshSurfaceContext(context, trace)
    if not context or context.type ~= "surface" then
        return true
    end

    if not trace or not trace.Hit then
        return false
    end

    local size = context.size or grid.GetSize()

    if math.abs(size - grid.GetSize()) > 0.001 then
        return true
    end

    local normal = trace.HitNormal or Vector(0, 0, 1)
    if normal:Dot(context.normal or Vector(0, 0, 1)) < 0.92 then
        return true
    end

    local hitPos = trace.HitPos or Vector(0, 0, 0)
    local anchor = context.anchorPos or hitPos
    local delta = hitPos - anchor
    local radius = size * math.max(1, (grid.GetRadiusCells() or 12) * 0.75)
    local u = math.abs(delta:Dot(context.tangent or Vector(1, 0, 0)))
    local v = math.abs(delta:Dot(context.bitangent or Vector(0, 1, 0)))
    local plane = math.abs(delta:Dot(context.normal or Vector(0, 0, 1)))

    return u > radius or v > radius or plane > math.max(32, size * 1.25)
end

function grid.CreateFreeContext(pos)
    return {
        type = "free",
        size = grid.GetSize(),
        origin = Vector(0, 0, 0),
        startPos = pos and Vector(pos.x, pos.y, pos.z) or Vector(0, 0, 0)
    }
end

function grid.SetActiveContext(context)
    grid.ActiveContext = context
end

function grid.ClearActiveContext(context)
    if not context or grid.ActiveContext == context then
        grid.ActiveContext = nil
    end
end

function grid.SnapPointToSurface(pos, context)
    if not pos or not context or context.type ~= "surface" then
        return pos
    end

    local size = context.size or grid.GetSize()
    local u = grid.SnapNumberToCellCenter(pos:Dot(context.tangent), size, context.originU or 0)
    local v = grid.SnapNumberToCellCenter(pos:Dot(context.bitangent), size, context.originV or 0)

    return context.tangent * u + context.bitangent * v + context.normal * (context.planeDistance or pos:Dot(context.normal))
end

function grid.SnapVector(pos, context)
    if not pos or not grid.GetBool("snap_grid") then return pos end
    if input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT) then return pos end

    if context and context.type == "surface" then
        return grid.SnapPointToSurface(pos, context)
    end

    local size = context and context.size or grid.GetSize()
    local origin = context and context.origin or Vector(0, 0, 0)

    return Vector(
        grid.SnapNumberToCellCenter(pos.x, size, origin.x),
        grid.SnapNumberToCellCenter(pos.y, size, origin.y),
        grid.SnapNumberToCellCenter(pos.z, size, origin.z)
    )
end

function grid.SnapAxisVector(pos, startPos, axis, context)
    if not pos or not grid.GetBool("snap_grid") then return pos end
    if input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT) then return pos end

    local result = Vector(startPos.x, startPos.y, startPos.z)
    local size = context and context.size or grid.GetSize()
    local origin = context and context.origin or Vector(0, 0, 0)

    if axis == "x" then
        result.x = grid.SnapNumberToCellCenter(pos.x, size, origin.x)
    elseif axis == "y" then
        result.y = grid.SnapNumberToCellCenter(pos.y, size, origin.y)
    elseif axis == "z" then
        result.z = grid.SnapNumberToCellCenter(pos.z, size, origin.z)
    end

    return result
end

function grid.SnapAngleYaw(yaw)
    if input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT) then return yaw end

    local step = grid.GetRotationSnap()
    return math.Round((tonumber(yaw) or 0) / step) * step
end

local function traceFromContext(context)
    if not context or context.type ~= "surface" then
        return nil
    end

    return {
        Hit = true,
        HitPos = context.anchorPos or Vector(0, 0, 0),
        HitNormal = context.normal or Vector(0, 0, 1),
        Entity = context.entity,
        MatType = context.matType
    }
end

function grid.GetAnchorTrace()
    if not MapStudio.Editor or not MapStudio.Editor.IsOpen() or not editorMouseOverWorld() then
        return nil
    end

    if grid.ActiveContext then
        return traceFromContext(grid.ActiveContext)
    end

    local trace = grid.TraceFromMouse()

    if trace and trace.Hit and not trace.HitSky then
        return trace
    end

    return nil
end

function grid.TraceFromMouse(extra)
    if not MapStudio.Editor or not MapStudio.Editor.IsOpen() or not editorMouseOverWorld() then
        return nil
    end

    local startPos = MapStudio.Freecam.Active and MapStudio.Freecam.Pos or EyePos()
    local direction = MapStudio.Freecam.Active and MapStudio.Freecam.Ang:Forward() or EyeAngles():Forward()
    local mouseX, mouseY = gui.MousePos()

    if gui.ScreenToVector and mouseX and mouseY and mouseX >= 0 and mouseY >= 0 then
        direction = gui.ScreenToVector(mouseX, mouseY)
    end

    local trace = util.TraceLine({
        start = startPos,
        endpos = startPos + direction * 12000,
        filter = traceFilter(extra),
        mask = MASK_SOLID
    })

    if trace and trace.Hit and not trace.HitSky then
        return trace
    end

    return nil
end

function grid.BuildSurfaceSamples(anchorTrace, gridSize, radiusCells, extraFilter)
    if not anchorTrace or not anchorTrace.Hit then return nil end

    gridSize = gridSize or grid.GetSize()
    radiusCells = radiusCells or grid.GetRadiusCells()

    local tangent, bitangent, normal = basisFromNormal(anchorTrace.HitNormal)
    local anchor = anchorTrace.HitPos
    local snappedU = grid.SnapNumber(anchor:Dot(tangent), gridSize)
    local snappedV = grid.SnapNumber(anchor:Dot(bitangent), gridSize)
    local origin = tangent * snappedU + bitangent * snappedV + normal * anchor:Dot(normal)
    local cacheKey = table.concat({
        gridSize,
        radiusCells,
        vecKey(origin, gridSize * 0.5),
        vecKey(normal, 0.05)
    }, "|")

    if grid.Cache.key == cacheKey and grid.Cache.lines then
        return grid.Cache.lines
    end

    local points = {}
    local lines = {}
    local maxStep = math.max(48, gridSize * 2.25)

    for x = -radiusCells, radiusCells do
        for y = -radiusCells, radiusCells do
            local planePoint = origin + tangent * (x * gridSize) + bitangent * (y * gridSize)
            local sample = sampleSurface(planePoint, normal, extraFilter)

            if sample then
                points[x .. ":" .. y] = sample
            end
        end
    end

    for x = -radiusCells, radiusCells do
        for y = -radiusCells, radiusCells do
            local sample = points[x .. ":" .. y]

            if sample then
                local right = points[(x + 1) .. ":" .. y]
                local up = points[x .. ":" .. (y + 1)]

                if right and sample.pos:Distance(right.pos) <= maxStep then
                    table.insert(lines, { sample.pos, right.pos })
                end

                if up and sample.pos:Distance(up.pos) <= maxStep then
                    table.insert(lines, { sample.pos, up.pos })
                end
            end
        end
    end

    grid.Cache.key = cacheKey
    grid.Cache.lines = lines

    return lines
end

function grid.GetSnappedTrace(trace, context)
    if not trace or not trace.Hit or not grid.GetBool("snap_grid") then return trace end
    if input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT) then return trace end

    context = context or grid.CreateSurfaceContext(trace)
    if not context then return trace end

    local snapped = grid.SnapPointToSurface(trace.HitPos, context)

    return {
        Hit = true,
        HitPos = snapped,
        HitNormal = context.normal or trace.HitNormal,
        Entity = trace.Entity,
        MatType = trace.MatType
    }
end

function grid.DrawSurfaceGrid()
    if not MapStudio.Editor or not MapStudio.Editor.IsOpen() or not grid.GetBool("show_grid") then
        return
    end

    local trace = grid.GetAnchorTrace()
    if not trace then return end

    local lines = grid.BuildSurfaceSamples(trace, grid.GetSize(), grid.GetRadiusCells(), grid.ActiveContext and grid.ActiveContext.ignoreEnt)
    if not lines then return end

    render.SetColorMaterial()

    for _, line in ipairs(lines) do
        render.DrawLine(line[1], line[2], Color(125, 145, 170, 88), true)
    end
end

hook.Add("PostDrawTranslucentRenderables", "MapStudio_DrawGrid", function()
    grid.DrawSurfaceGrid()
end)
