MapStudio = MapStudio or {}
MapStudio.Gizmo = MapStudio.Gizmo or {}

local gizmo = MapStudio.Gizmo

gizmo.Drag = nil
gizmo.HoverHandle = nil
gizmo.WheelDepth = nil
gizmo.PendingWheelCommit = nil

local AXES = {
    x = { vector = Vector(1, 0, 0), color = Color(230, 80, 80) },
    y = { vector = Vector(0, 1, 0), color = Color(80, 210, 95) },
    z = { vector = Vector(0, 0, 1), color = Color(85, 150, 255) }
}

local RINGS = {
    rot_x = { axis = "x", normal = Vector(1, 0, 0), a = Vector(0, 1, 0), b = Vector(0, 0, 1), color = Color(230, 80, 80) },
    rot_y = { axis = "y", normal = Vector(0, 1, 0), a = Vector(1, 0, 0), b = Vector(0, 0, 1), color = Color(80, 210, 95) },
    rot_z = { axis = "z", normal = Vector(0, 0, 1), a = Vector(1, 0, 0), b = Vector(0, 1, 0), color = Color(85, 150, 255) }
}

local RING_ANGLE_FIELDS = {
    rot_x = "r",
    rot_y = "p",
    rot_z = "y"
}

local atan2 = math.atan2 or function(y, x) return math.atan(y, x) end

local function selectedIDs()
    if MapStudio.Editor and MapStudio.Editor.GetSelectedIDs then
        return MapStudio.Editor.GetSelectedIDs()
    end

    local result = {}
    local seen = {}

    if not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return result
    end

    for _, id in ipairs(MapStudio.ClientState.selectedIds or {}) do
        if id and MapStudio.ClientState.objects[id] and not seen[id] then
            seen[id] = true
            table.insert(result, id)
        end
    end

    local id = MapStudio.ClientState.selectedId
    if id and MapStudio.ClientState.objects[id] and not seen[id] then
        table.insert(result, id)
    end

    return result
end

local function selectedObject()
    if not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return nil, nil
    end

    local id = MapStudio.ClientState.selectedId

    if id and id ~= "" and MapStudio.ClientState.objects[id] then
        return id, MapStudio.ClientState.objects[id]
    end

    for _, selectedId in ipairs(selectedIDs()) do
        if MapStudio.ClientState.objects[selectedId] then
            return selectedId, MapStudio.ClientState.objects[selectedId]
        end
    end

    return nil, nil
end

local function objectPosition(objectData)
    return objectData and MapStudio.Objects.ToVector(objectData.pos) or nil
end

local function objectAngle(objectData)
    return MapStudio.Objects.ToAngle(objectData and objectData.ang)
end

local function copyVector(vec)
    return Vector(vec.x, vec.y, vec.z)
end

local function selectedItems()
    local result = {}

    if not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return result
    end

    for _, id in ipairs(selectedIDs()) do
        local objectData = MapStudio.ClientState.objects[id]
        local pos = objectPosition(objectData)

        if objectData and pos then
            table.insert(result, {
                id = id,
                object = objectData,
                pos = pos,
                ang = objectAngle(objectData)
            })
        end
    end

    return result
end

local function selectedEntity(id)
    if not MapStudio.Editor or not MapStudio.Editor.FindEntityByObjectID then
        return nil
    end

    return MapStudio.Editor.FindEntityByObjectID(id)
end

local function entityInFilter(filterEnt, ent)
    if not IsValid(ent) then
        return false
    end

    if istable and istable(filterEnt) then
        for _, candidate in pairs(filterEnt) do
            if IsValid(candidate) and candidate == ent then
                return true
            end
        end

        return false
    end

    return IsValid(filterEnt) and filterEnt == ent
end

local function gizmoSize(pos)
    local eye = MapStudio.Freecam and MapStudio.Freecam.Active and MapStudio.Freecam.Pos or EyePos()
    local distance = eye:Distance(pos)
    return math.Clamp(distance * 0.13, 96, 300)
end

local function entityHalfExtents(ent)
    if not IsValid(ent) then
        return { x = 16, y = 16, z = 16 }
    end

    local mins, maxs = ent:OBBMins(), ent:OBBMaxs()

    if not mins or not maxs then
        return { x = 16, y = 16, z = 16 }
    end

    local scale = ent.GetModelScale and ent:GetModelScale() or 1
    scale = math.max(tonumber(scale) or 1, 0.01)

    return {
        x = math.max(math.abs(mins.x or 0), math.abs(maxs.x or 0)) * scale,
        y = math.max(math.abs(mins.y or 0), math.abs(maxs.y or 0)) * scale,
        z = math.max(math.abs(mins.z or 0), math.abs(maxs.z or 0)) * scale
    }
end

local function itemWorldBounds(item)
    local ent = item and selectedEntity(item.id)

    if IsValid(ent) and ent.WorldSpaceAABB then
        local mins, maxs = ent:WorldSpaceAABB()

        if mins and maxs then
            return mins, maxs
        end
    end

    local pos = item and item.pos
    if pos then
        return pos, pos
    end

    return nil, nil
end

local function selectionPivot(items)
    items = items or selectedItems()

    if #items == 0 then
        return nil
    end

    if #items == 1 then
        return copyVector(items[1].pos)
    end

    local mins
    local maxs

    for _, item in ipairs(items) do
        local itemMins, itemMaxs = itemWorldBounds(item)

        if itemMins and itemMaxs then
            if not mins then
                mins = copyVector(itemMins)
                maxs = copyVector(itemMaxs)
            else
                mins.x = math.min(mins.x, itemMins.x)
                mins.y = math.min(mins.y, itemMins.y)
                mins.z = math.min(mins.z, itemMins.z)
                maxs.x = math.max(maxs.x, itemMaxs.x)
                maxs.y = math.max(maxs.y, itemMaxs.y)
                maxs.z = math.max(maxs.z, itemMaxs.z)
            end
        end
    end

    if mins and maxs then
        return (mins + maxs) * 0.5
    end

    local sum = Vector(0, 0, 0)

    for _, item in ipairs(items) do
        sum = sum + item.pos
    end

    return Vector(sum.x / #items, sum.y / #items, sum.z / #items)
end

local function selectionHalfExtents(items, pivot)
    items = items or selectedItems()

    if #items <= 1 then
        return entityHalfExtents(selectedEntity(items[1] and items[1].id))
    end

    pivot = pivot or selectionPivot(items)
    local mins
    local maxs

    for _, item in ipairs(items) do
        local itemMins, itemMaxs = itemWorldBounds(item)

        if itemMins and itemMaxs then
            if not mins then
                mins = copyVector(itemMins)
                maxs = copyVector(itemMaxs)
            else
                mins.x = math.min(mins.x, itemMins.x)
                mins.y = math.min(mins.y, itemMins.y)
                mins.z = math.min(mins.z, itemMins.z)
                maxs.x = math.max(maxs.x, itemMaxs.x)
                maxs.y = math.max(maxs.y, itemMaxs.y)
                maxs.z = math.max(maxs.z, itemMaxs.z)
            end
        end
    end

    if not mins or not maxs or not pivot then
        return { x = 16, y = 16, z = 16 }
    end

    return {
        x = math.max(math.abs(mins.x - pivot.x), math.abs(maxs.x - pivot.x)),
        y = math.max(math.abs(mins.y - pivot.y), math.abs(maxs.y - pivot.y)),
        z = math.max(math.abs(mins.z - pivot.z), math.abs(maxs.z - pivot.z))
    }
end

local function gizmoTarget()
    local items = selectedItems()
    local pivot = selectionPivot(items)

    if not pivot then
        return nil, nil, items
    end

    if #items == 1 then
        return pivot, items[1].object, items
    end

    local _, primaryObject = selectedObject()
    local proxy = {
        id = primaryObject and primaryObject.id or items[#items].id,
        __groupHalfExtents = selectionHalfExtents(items, pivot)
    }

    return pivot, proxy, items
end

function gizmo.GetGeometry(pos, objectData)
    local id = objectData and objectData.id
    local base = gizmoSize(pos)
    local half = objectData and objectData.__groupHalfExtents or entityHalfExtents(selectedEntity(id))
    local margin = math.Clamp(base * 0.28, 32, 140)
    local minRing = base * 0.78

    local geometry = {
        base = base,
        hitDistance = math.Clamp(base * 0.08, 16, 32),
        centerHit = math.Clamp(base * 0.08, 14, 26),
        centerRadius = math.Clamp(base * 0.045, 4.5, 11),
        axisLength = {},
        ringRadius = {}
    }

    geometry.axisLength.x = math.Clamp(math.max(base, half.x + margin), 96, 1000)
    geometry.axisLength.y = math.Clamp(math.max(base, half.y + margin), 96, 1000)
    geometry.axisLength.z = math.Clamp(math.max(base, half.z + margin), 96, 1000)

    geometry.ringRadius.rot_z = math.Clamp(math.max(minRing, math.sqrt(half.x * half.x + half.y * half.y) + margin), 72, 1100)
    geometry.ringRadius.rot_x = math.Clamp(math.max(minRing, math.sqrt(half.y * half.y + half.z * half.z) + margin), 72, 1100)
    geometry.ringRadius.rot_y = math.Clamp(math.max(minRing, math.sqrt(half.x * half.x + half.z * half.z) + margin), 72, 1100)

    return geometry
end

local function screenAngle(pos)
    local sx, sy = gui.MousePos()
    local center = pos:ToScreen()
    return math.deg(atan2(sy - center.y, sx - center.x))
end

local function angleDelta(current, start)
    local delta = current - start

    while delta > 180 do delta = delta - 360 end
    while delta < -180 do delta = delta + 360 end

    return delta
end

local function snapAngle(value)
    if not MapStudio.Grid or not MapStudio.Grid.GetBool("snap_grid") then
        return value
    end

    if input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT) then
        return value
    end

    local step = MapStudio.Grid.GetRotationSnap()
    return math.Round(value / step) * step
end

local function distanceToSegment(px, py, ax, ay, bx, by)
    local vx = bx - ax
    local vy = by - ay
    local wx = px - ax
    local wy = py - ay
    local len = vx * vx + vy * vy

    if len <= 0.001 then
        local dx = px - ax
        local dy = py - ay
        return math.sqrt(dx * dx + dy * dy)
    end

    local t = math.Clamp((wx * vx + wy * vy) / len, 0, 1)
    local cx = ax + vx * t
    local cy = ay + vy * t
    local dx = px - cx
    local dy = py - cy
    return math.sqrt(dx * dx + dy * dy)
end

local function mouseRay()
    local startPos = MapStudio.Freecam.Active and MapStudio.Freecam.Pos or EyePos()
    local direction = MapStudio.Freecam.Active and MapStudio.Freecam.Ang:Forward() or EyeAngles():Forward()
    local mouseX, mouseY = gui.MousePos()

    if gui.ScreenToVector and mouseX and mouseY and mouseX >= 0 and mouseY >= 0 then
        direction = gui.ScreenToVector(mouseX, mouseY)
    end

    direction:Normalize()

    return startPos, direction
end

local function cameraDirection()
    local direction = MapStudio.Freecam.Active and MapStudio.Freecam.Ang:Forward() or EyeAngles():Forward()
    direction = Vector(direction.x, direction.y, direction.z)

    if direction:LengthSqr() <= 0.0001 then
        direction = Vector(1, 0, 0)
    end

    direction:Normalize()
    return direction
end

local function traceFromMouse(filterEnt)
    local startPos, direction = mouseRay()

    return util.TraceLine({
        start = startPos,
        endpos = startPos + direction * 12000,
        filter = function(ent)
            if not IsValid(ent) then return true end
            local ply = LocalPlayer()
            if IsValid(ply) and ent == ply then return false end
            if IsValid(ply) then
                local weapon = ply.GetActiveWeapon and ply:GetActiveWeapon() or nil
                if IsValid(weapon) and ent == weapon then return false end
            end
            if entityInFilter(filterEnt, ent) then return false end
            return true
        end,
        mask = MASK_SOLID
    })
end

local function intersectRayPlane(rayStart, rayDirection, planePoint, planeNormal)
    local denom = rayDirection:Dot(planeNormal)

    if math.abs(denom) < 0.0001 then
        return nil
    end

    local distance = (planePoint - rayStart):Dot(planeNormal) / denom

    return rayStart + rayDirection * distance
end

local function freePropsEnabled()
    return MapStudio.Editor and MapStudio.Editor.IsFreePropsEnabled and MapStudio.Editor.IsFreePropsEnabled()
end

local function applyRingDelta(baseAng, handle, delta, snap)
    local ang = Angle(baseAng.p or 0, baseAng.y or 0, baseAng.r or 0)
    local field = RING_ANGLE_FIELDS[handle]

    if not field then
        return ang
    end

    local value = (ang[field] or 0) + delta
    ang[field] = MapStudio.Objects.NormalizeAngleValue(snap and snapAngle(value) or value)

    return ang
end

local function rotateVectorAroundAxis(vec, axis, degrees)
    axis = Vector(axis.x, axis.y, axis.z)

    if axis:LengthSqr() <= 0.0001 then
        return copyVector(vec)
    end

    axis:Normalize()

    local radians = math.rad(tonumber(degrees) or 0)
    local c = math.cos(radians)
    local s = math.sin(radians)

    return vec * c + axis:Cross(vec) * s + axis * (axis:Dot(vec) * (1 - c))
end

local function rotateAngleAroundAxis(baseAng, axis, degrees, fallbackHandle)
    local ang = MapStudio.Objects.ToAngle(baseAng)
    axis = Vector(axis.x, axis.y, axis.z)

    if axis:LengthSqr() <= 0.0001 then
        return ang
    end

    axis:Normalize()

    if ang.RotateAroundAxis then
        ang:RotateAroundAxis(axis, tonumber(degrees) or 0)
        return Angle(
            MapStudio.Objects.NormalizeAngleValue(ang.p),
            MapStudio.Objects.NormalizeAngleValue(ang.y),
            MapStudio.Objects.NormalizeAngleValue(ang.r)
        )
    end

    return applyRingDelta(baseAng, fallbackHandle, degrees, false)
end

local function ringHitDistance(pos, radius, ring, mx, my)
    local best = 9999
    local previous

    for i = 0, 72 do
        local radians = math.rad((i / 72) * 360)
        local point = pos + ring.a * math.cos(radians) * radius + ring.b * math.sin(radians) * radius
        local screen = point:ToScreen()

        if previous then
            best = math.min(best, distanceToSegment(mx, my, previous.x, previous.y, screen.x, screen.y))
        end

        previous = screen
    end

    return best
end

function gizmo.GetHoveredHandle()
    if not MapStudio.ClientState or not MapStudio.Editor or not MapStudio.Editor.IsOpen() then return nil end
    if MapStudio.Ghost and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive() then return nil end

    local pos, objectData = gizmoTarget()
    if not pos then return nil end

    local mx, my = gui.MousePos()
    if mx < 0 or my < 0 then return nil end

    local center = pos:ToScreen()
    local centerDistance = math.sqrt((mx - center.x) ^ 2 + (my - center.y) ^ 2)
    local geometry = gizmo.GetGeometry(pos, objectData)

    if centerDistance <= geometry.centerHit then return "center" end

    local bestHandle
    local bestDistance = geometry.hitDistance

    for axis, data in pairs(AXES) do
        local endScreen = (pos + data.vector * (geometry.axisLength[axis] or geometry.base)):ToScreen()
        local distance = distanceToSegment(mx, my, center.x, center.y, endScreen.x, endScreen.y)

        if distance < bestDistance then
            bestDistance = distance
            bestHandle = axis
        end
    end

    for handle, ring in pairs(RINGS) do
        local distance = ringHitDistance(pos, geometry.ringRadius[handle] or geometry.base, ring, mx, my)

        if distance < bestDistance then
            bestDistance = distance
            bestHandle = handle
        end
    end

    return bestHandle
end

function gizmo.BeginDrag()
    if gizmo.Drag then return true end

    local handle = gizmo.GetHoveredHandle()
    if not handle then return false end

    local pos, objectData, items = gizmoTarget()
    if not pos or #items == 0 then return false end

    local primaryId = select(1, selectedObject()) or items[#items].id

    local mx, my = gui.MousePos()
    local geometry = gizmo.GetGeometry(pos, objectData)
    local drag = {
        id = primaryId,
        ids = {},
        handle = handle,
        items = items,
        startPivot = copyVector(pos),
        currentPivot = copyVector(pos),
        beforeById = {},
        startById = {},
        filterEnts = {},
        mouseX = mx,
        mouseY = my,
        length = geometry.axisLength[handle] or geometry.base,
        startMouseAngle = screenAngle(pos)
    }

    for _, item in ipairs(items) do
        table.insert(drag.ids, item.id)
        drag.beforeById[item.id] = MapStudio.DeepCopy(item.object)
        drag.startById[item.id] = {
            pos = copyVector(item.pos),
            ang = MapStudio.Objects.SanitizeAngle(item.object.ang)
        }

        local ent = selectedEntity(item.id)
        if IsValid(ent) then
            table.insert(drag.filterEnts, ent)
        end
    end

    if AXES[handle] then
        local center = pos:ToScreen()
        local endScreen = (pos + AXES[handle].vector * drag.length):ToScreen()
        drag.screenX = endScreen.x - center.x
        drag.screenY = endScreen.y - center.y
        drag.screenLengthSqr = drag.screenX * drag.screenX + drag.screenY * drag.screenY

        if drag.screenLengthSqr <= 0.001 then return false end
    elseif handle == "center" and freePropsEnabled() then
        local rayStart, rayDirection = mouseRay()
        local planeNormal = MapStudio.Freecam.Active and MapStudio.Freecam.Ang:Forward() or EyeAngles():Forward()
        planeNormal:Normalize()

        local planeHit = intersectRayPlane(rayStart, rayDirection, drag.startPivot, planeNormal)

        if planeHit then
            drag.freePlaneNormal = planeNormal
            drag.freePlaneOffset = drag.startPivot - planeHit
        end
    end

    if MapStudio.Grid and MapStudio.Grid.GetBool("snap_grid") then
        if handle == "center" and not freePropsEnabled() then
            local filterEnt = #drag.filterEnts == 1 and drag.filterEnts[1] or drag.filterEnts
            local trace = MapStudio.Grid.TraceFromMouse and MapStudio.Grid.TraceFromMouse(filterEnt) or traceFromMouse(filterEnt)

            if trace and trace.Hit then
                drag.snapContext = MapStudio.Grid.CreateSurfaceContext(trace)

                if drag.snapContext then
                    drag.snapContext.ignoreEnt = filterEnt
                end
            end
        end

        drag.snapContext = drag.snapContext or MapStudio.Grid.CreateFreeContext(pos)
        MapStudio.Grid.SetActiveContext(drag.snapContext)
    end

    gizmo.Drag = drag
    return true
end

local function applyPreview(id, objectData, pos, ang)
    if pos then objectData.pos = { x = pos.x, y = pos.y, z = pos.z } end
    if ang then objectData.ang = { p = ang.p, y = ang.y, r = ang.r } end

    local ent = MapStudio.Editor and MapStudio.Editor.FindEntityByObjectID and MapStudio.Editor.FindEntityByObjectID(id)

    if IsValid(ent) then
        if pos then ent:SetPos(pos) end
        if ang then ent:SetAngles(ang) end
    end
end

local function copyPos(pos)
    pos = MapStudio.Objects.SanitizeVector(pos)
    return { x = pos.x, y = pos.y, z = pos.z }
end

local function copyAng(ang)
    ang = MapStudio.Objects.SanitizeAngle(ang)
    return { p = ang.p, y = ang.y, r = ang.r }
end

local function pushUndoAndCommit(updates)
    if #updates == 0 then
        return
    end

    if #updates == 1 then
        local update = updates[1]
        MapStudio.Undo.Push({
            type = "update",
            id = update.id,
            before = update.before,
            after = update.after
        })
        MapStudio.Client.UpdateObject(update.id, update.patch)
        return
    end

    local undoUpdates = {}
    local payload = {}

    for _, update in ipairs(updates) do
        table.insert(undoUpdates, {
            id = update.id,
            before = update.before,
            after = update.after
        })
        table.insert(payload, {
            id = update.id,
            patch = update.patch
        })
    end

    MapStudio.Undo.Push({
        type = "batch_update",
        updates = undoUpdates
    })

    if MapStudio.Client.UpdateObjects then
        MapStudio.Client.UpdateObjects(payload)
    else
        for _, update in ipairs(payload) do
            MapStudio.Client.UpdateObject(update.id, update.patch)
        end
    end
end

local function selectedTransformBaseline(objectData)
    local original = objectData and objectData.originalTransform

    if type(original) ~= "table" then
        original = {
            pos = copyPos(objectData and objectData.pos),
            ang = copyAng(objectData and objectData.ang)
        }
        objectData.originalTransform = MapStudio.DeepCopy(original)
    end

    return {
        pos = copyPos(original.pos or objectData.pos),
        ang = copyAng(original.ang or objectData.ang)
    }
end

local function previewTranslation(drag, pivot)
    if not pivot then
        return
    end

    local translation = pivot - drag.startPivot

    for _, id in ipairs(drag.ids or {}) do
        local objectData = MapStudio.ClientState.objects[id]
        local start = drag.startById[id]

        if objectData and start then
            applyPreview(id, objectData, start.pos + translation)
        end
    end

    drag.currentPivot = copyVector(pivot)
end

local function previewGroupRotation(drag, delta)
    local ring = RINGS[drag.handle]
    if not ring then return end

    for _, id in ipairs(drag.ids or {}) do
        local objectData = MapStudio.ClientState.objects[id]
        local start = drag.startById[id]

        if objectData and start then
            local offset = start.pos - drag.startPivot
            local pos = drag.startPivot + rotateVectorAroundAxis(offset, ring.normal, delta)
            local ang = rotateAngleAroundAxis(start.ang, ring.normal, delta, drag.handle)
            applyPreview(id, objectData, pos, ang)
        end
    end

    drag.currentPivot = copyVector(drag.startPivot)
end

local function snapDragAngleDelta(delta)
    if not MapStudio.Grid or not MapStudio.Grid.GetBool("snap_grid") then
        return delta
    end

    if input.IsKeyDown(KEY_LALT) or input.IsKeyDown(KEY_RALT) then
        return delta
    end

    local step = MapStudio.Grid.GetRotationSnap()
    return math.Round(delta / step) * step
end

local function previewAxisDrag(drag)
    local mx, my = gui.MousePos()
    local dx = mx - drag.mouseX
    local dy = my - drag.mouseY
    local scalar = ((dx * drag.screenX) + (dy * drag.screenY)) / drag.screenLengthSqr
    local pos = drag.startPivot + AXES[drag.handle].vector * (scalar * drag.length)

    if MapStudio.Grid then pos = MapStudio.Grid.SnapAxisVector(pos, drag.startPivot, drag.handle, drag.snapContext) end
    previewTranslation(drag, pos)
end

local function previewCenterDrag(drag)
    if drag.freePlaneNormal then
        local rayStart, rayDirection = mouseRay()
        local planeHit = intersectRayPlane(rayStart, rayDirection, drag.startPivot, drag.freePlaneNormal)

        if not planeHit then return end

        local pos = planeHit + (drag.freePlaneOffset or Vector(0, 0, 0))
        if MapStudio.Grid then pos = MapStudio.Grid.SnapVector(pos, drag.snapContext) end
        previewTranslation(drag, pos)
        return
    end

    local filterEnt = #(drag.filterEnts or {}) == 1 and drag.filterEnts[1] or drag.filterEnts
    local trace = MapStudio.Grid and MapStudio.Grid.GetBool("snap_grid") and MapStudio.Grid.TraceFromMouse and MapStudio.Grid.TraceFromMouse(filterEnt) or traceFromMouse(filterEnt)

    if not trace or not trace.Hit then return end
    if MapStudio.Grid and MapStudio.Grid.GetSnappedTrace then
        if MapStudio.Grid.GetBool("snap_grid") and MapStudio.Grid.ShouldRefreshSurfaceContext and MapStudio.Grid.ShouldRefreshSurfaceContext(drag.snapContext, trace) then
            MapStudio.Grid.ClearActiveContext(drag.snapContext)
            drag.snapContext = nil
        end

        if MapStudio.Grid.GetBool("snap_grid") and (not drag.snapContext or drag.snapContext.type ~= "surface") then
            drag.snapContext = MapStudio.Grid.CreateSurfaceContext(trace)

            if drag.snapContext then
                drag.snapContext.ignoreEnt = filterEnt
            end

            MapStudio.Grid.SetActiveContext(drag.snapContext)
        end

        trace = MapStudio.Grid.GetSnappedTrace(trace, drag.snapContext)
    end

    if #(drag.ids or {}) <= 1 then
        local id = drag.ids and drag.ids[1] or drag.id
        local objectData = MapStudio.ClientState.objects[id]
        local ent = selectedEntity(id)
        local bounds = IsValid(ent) and MapStudio.Placement.BoundsFromEntity(ent) or nil
        local placement = objectData and MapStudio.Placement.Calculate(objectData.model, trace.HitPos, trace.HitNormal, objectAngle(objectData), "ground", bounds)

        if placement then
            previewTranslation(drag, placement.pos)
        end

        return
    end

    previewTranslation(drag, trace.HitPos)
end

local function previewRingDrag(drag)
    local current = screenAngle(drag.startPivot)
    -- Screen Y grows downward, so invert the screen delta to match the visual ring direction.
    local delta = -angleDelta(current, drag.startMouseAngle)

    if #(drag.ids or {}) <= 1 then
        local id = drag.ids and drag.ids[1] or drag.id
        local objectData = MapStudio.ClientState.objects[id]
        local start = drag.startById[id]

        if objectData and start then
            local ang = applyRingDelta(start.ang, drag.handle, delta, true)
            applyPreview(id, objectData, nil, ang)
        end

        return
    end

    previewGroupRotation(drag, snapDragAngleDelta(delta))
end

function gizmo.RotateSelectedByHandle(handle, delta)
    if not RINGS[handle] then
        return false
    end

    local items = selectedItems()
    if #items == 0 then
        return false
    end

    delta = tonumber(delta) or 0

    if #items == 1 then
        local id = items[1].id
        local objectData = items[1].object
        local before = MapStudio.DeepCopy(objectData)
        local currentAng = MapStudio.Objects.SanitizeAngle(objectData.ang)
        local ang = applyRingDelta(currentAng, handle, delta, false)

        applyPreview(id, objectData, nil, ang)
        MapStudio.Undo.Push({ type = "update", id = id, before = before, after = MapStudio.DeepCopy(objectData) })
        MapStudio.Client.UpdateObject(id, { ang = objectData.ang })

        return true
    end

    local pivot = selectionPivot(items)
    if not pivot then
        return false
    end

    local updates = {}
    local ring = RINGS[handle]

    for _, item in ipairs(items) do
        local objectData = MapStudio.ClientState.objects[item.id]

        if objectData then
            local before = MapStudio.DeepCopy(objectData)
            local pos = objectPosition(objectData)
            local offset = pos - pivot
            local nextPos = pivot + rotateVectorAroundAxis(offset, ring.normal, delta)
            local ang = rotateAngleAroundAxis(item.ang or objectData.ang, ring.normal, delta, handle)

            applyPreview(item.id, objectData, nextPos, ang)
            table.insert(updates, {
                id = item.id,
                before = before,
                after = MapStudio.DeepCopy(objectData),
                patch = {
                    pos = objectData.pos,
                    ang = objectData.ang
                }
            })
        end
    end

    pushUndoAndCommit(updates)

    return true
end

local function wheelSelectionKey(items)
    local ids = {}

    for _, item in ipairs(items or {}) do
        table.insert(ids, item.id)
    end

    return table.concat(ids, "\n"), ids
end

local function reapplyWheelPreview()
    local wheel = gizmo.WheelDepth or gizmo.PendingWheelCommit
    if not wheel or not MapStudio.ClientState or not MapStudio.ClientState.objects then
        return
    end

    if wheel.expiresAt and CurTime() > wheel.expiresAt then
        if gizmo.PendingWheelCommit == wheel then
            gizmo.PendingWheelCommit = nil
        end

        return
    end

    local matched = true

    for _, id in ipairs(wheel.ids or {}) do
        local objectData = MapStudio.ClientState.objects[id]
        local pos = wheel.positions and wheel.positions[id]

        if objectData and pos then
            local current = objectPosition(objectData)
            if current and current:DistToSqr(pos) > 0.01 then
                matched = false
            end

            applyPreview(id, objectData, pos)
        end
    end

    if gizmo.PendingWheelCommit == wheel and matched then
        gizmo.PendingWheelCommit = nil
    end
end

function gizmo.CommitWheelDepth()
    local wheel = gizmo.WheelDepth
    if not wheel then return end

    timer.Remove("MapStudio_WheelDepthCommit")
    gizmo.PendingWheelCommit = {
        ids = table.Copy and table.Copy(wheel.ids or {}) or wheel.ids,
        positions = {},
        expiresAt = CurTime() + 1
    }

    for id, pos in pairs(wheel.positions or {}) do
        gizmo.PendingWheelCommit.positions[id] = copyVector(pos)
    end

    gizmo.WheelDepth = nil

    local updates = {}

    for _, id in ipairs(wheel.ids or {}) do
        local objectData = MapStudio.ClientState and MapStudio.ClientState.objects and MapStudio.ClientState.objects[id]
        local pos = wheel.positions and wheel.positions[id]
        local before = wheel.beforeById and wheel.beforeById[id]

        if objectData and pos and before then
            applyPreview(id, objectData, pos)
            table.insert(updates, {
                id = id,
                before = before,
                after = MapStudio.DeepCopy(objectData),
                patch = {
                    pos = objectData.pos
                }
            })
        end
    end

    pushUndoAndCommit(updates)
end

function gizmo.AdjustSelectedDepth(delta)
    if not freePropsEnabled() then
        return false
    end

    if MapStudio.Grid and MapStudio.Grid.MouseOverWorld and not MapStudio.Grid.MouseOverWorld() then
        return false
    end

    local items = selectedItems()
    if #items == 0 then
        return false
    end

    local pivot = selectionPivot(items)
    if not pivot then
        return false
    end

    local key, ids = wheelSelectionKey(items)
    local wheel = gizmo.WheelDepth

    if not wheel or wheel.key ~= key then
        gizmo.PendingWheelCommit = nil

        wheel = {
            key = key,
            ids = ids,
            beforeById = {},
            positions = {},
            pivot = copyVector(pivot),
            snapContext = MapStudio.Grid and MapStudio.Grid.CreateFreeContext(pivot) or nil
        }

        for _, item in ipairs(items) do
            wheel.beforeById[item.id] = MapStudio.DeepCopy(item.object)
            wheel.positions[item.id] = copyVector(item.pos)
        end

        gizmo.WheelDepth = wheel
    end

    local step = MapStudio.Grid and MapStudio.Grid.GetBool("snap_grid") and MapStudio.Grid.GetSize() or 48
    local direction = cameraDirection()
    local nextPivot = wheel.pivot + direction * ((tonumber(delta) or 0) * step)

    if MapStudio.Grid and MapStudio.Grid.GetBool("snap_grid") then
        wheel.snapContext = wheel.snapContext or MapStudio.Grid.CreateFreeContext(wheel.pivot)
        nextPivot = MapStudio.Grid.SnapVector(nextPivot, wheel.snapContext)
    end

    local translation = nextPivot - wheel.pivot
    wheel.pivot = copyVector(nextPivot)

    for _, id in ipairs(wheel.ids or {}) do
        local objectData = MapStudio.ClientState.objects[id]
        local pos = wheel.positions[id]

        if objectData and pos then
            pos = pos + translation
            wheel.positions[id] = pos
            applyPreview(id, objectData, pos)
        end
    end

    timer.Create("MapStudio_WheelDepthCommit", 0.2, 1, function()
        gizmo.CommitWheelDepth()
    end)

    return true
end

function gizmo.ResetSelectedTransform()
    local items = selectedItems()
    if #items == 0 then
        return false
    end

    if gizmo.WheelDepth then
        timer.Remove("MapStudio_WheelDepthCommit")
        gizmo.WheelDepth = nil
    end

    gizmo.PendingWheelCommit = nil

    local updates = {}

    for _, item in ipairs(items) do
        local objectData = MapStudio.ClientState.objects[item.id]

        if objectData then
            local before = MapStudio.DeepCopy(objectData)
            local baseline = selectedTransformBaseline(objectData)
            local pos = MapStudio.Objects.ToVector(baseline.pos)
            local ang = MapStudio.Objects.ToAngle(baseline.ang)

            applyPreview(item.id, objectData, pos, ang)
            objectData.originalTransform = MapStudio.DeepCopy(baseline)

            table.insert(updates, {
                id = item.id,
                before = before,
                after = MapStudio.DeepCopy(objectData),
                patch = {
                    pos = objectData.pos,
                    ang = objectData.ang,
                    originalTransform = objectData.originalTransform
                }
            })
        end
    end

    pushUndoAndCommit(updates)
    return #updates > 0
end

local function previewDrag()
    local drag = gizmo.Drag
    if not drag then return end

    local hasObject = false

    for _, id in ipairs(drag.ids or {}) do
        if MapStudio.ClientState.objects[id] then
            hasObject = true
            break
        end
    end

    if not hasObject then
        if MapStudio.Grid then
            MapStudio.Grid.ClearActiveContext(drag.snapContext)
        end

        gizmo.Drag = nil
        return
    end

    if AXES[drag.handle] then
        previewAxisDrag(drag)
    elseif drag.handle == "center" then
        previewCenterDrag(drag)
    elseif RINGS[drag.handle] then
        previewRingDrag(drag)
    end
end

function gizmo.EndDrag()
    local drag = gizmo.Drag
    if not drag then return end

    gizmo.Drag = nil

    if MapStudio.Grid then
        MapStudio.Grid.ClearActiveContext(drag.snapContext)
    end

    local updates = {}
    local count = #(drag.ids or {})

    for _, id in ipairs(drag.ids or {}) do
        local objectData = MapStudio.ClientState.objects[id]
        local before = drag.beforeById and drag.beforeById[id]

        if objectData and before then
            local after = MapStudio.DeepCopy(objectData)
            local patch

            if RINGS[drag.handle] then
                patch = count > 1 and { pos = after.pos, ang = after.ang } or { ang = after.ang }
            else
                patch = { pos = after.pos }
            end

            table.insert(updates, {
                id = id,
                before = before,
                after = after,
                patch = patch
            })
        end
    end

    pushUndoAndCommit(updates)
end

function gizmo.CancelDrag()
    gizmo.CommitWheelDepth()

    if MapStudio.Grid and gizmo.Drag then
        MapStudio.Grid.ClearActiveContext(gizmo.Drag.snapContext)
    end

    gizmo.Drag = nil
    gizmo.HoverHandle = nil
end

hook.Add("Think", "MapStudio_GizmoThink", function()
    if not MapStudio.ClientState or not MapStudio.Editor or not MapStudio.Editor.IsOpen() then
        gizmo.CancelDrag()
        return
    end

    if gizmo.Drag then
        if input.IsMouseDown(MOUSE_LEFT) then
            previewDrag()
        else
            gizmo.EndDrag()
        end

        return
    end

    gizmo.HoverHandle = gizmo.GetHoveredHandle()
end)

hook.Add("MapStudioStateChanged", "MapStudio_GizmoPendingWheelPreview", function()
    reapplyWheelPreview()
end)

local function scaledColor(color, alpha)
    return Color(color.r, color.g, color.b, alpha or color.a or 255)
end

local function handleColor(handle, baseColor, alpha)
    local active = gizmo.HoverHandle == handle or (gizmo.Drag and gizmo.Drag.handle == handle)
    local color = active and Color(255, 255, 255) or baseColor

    return scaledColor(color, alpha)
end

local function drawAxis(pos, axis, data, geometry, alpha)
    local size = geometry.axisLength[axis] or geometry.base
    local color = handleColor(axis, data.color, alpha)
    local endPos = pos + data.vector * size
    local wing = math.Clamp(size * 0.12, 16, 72)
    local headRadius = math.Clamp(size * 0.018, 3.5, 12)

    render.DrawLine(pos, endPos, color, true)
    render.DrawSphere(endPos, headRadius, 8, 8, color)
    render.DrawLine(endPos, endPos - data.vector * wing + Vector(0, 0, 1) * wing * 0.45, color, true)
    render.DrawLine(endPos, endPos - data.vector * wing - Vector(0, 0, 1) * wing * 0.45, color, true)
end

local function drawRing(pos, handle, ring, radius, alpha)
    local color = handleColor(handle, ring.color, alpha)
    local previous

    for i = 0, 72 do
        local radians = math.rad((i / 72) * 360)
        local point = pos + ring.a * math.cos(radians) * radius + ring.b * math.sin(radians) * radius

        if previous then
            render.DrawLine(previous, point, color, true)
        end

    previous = point
    end
end

local function drawGizmoPass(pos, objectData, xray)
    local geometry = gizmo.GetGeometry(pos, objectData)
    local alpha = xray and 88 or 255

    if xray then
        cam.IgnoreZ(true)
    end

    render.DrawSphere(pos, geometry.centerRadius, 10, 10, handleColor("center", Color(235, 235, 235), xray and 95 or 255))

    for axis, data in pairs(AXES) do
        drawAxis(pos, axis, data, geometry, alpha)
    end

    for handle, ring in pairs(RINGS) do
        drawRing(pos, handle, ring, geometry.ringRadius[handle] or geometry.base, alpha)
    end

    if xray then
        cam.IgnoreZ(false)
    end
end

hook.Add("PostDrawTranslucentRenderables", "MapStudio_DrawGizmo", function()
    if not MapStudio.ClientState or not MapStudio.Editor or not MapStudio.Editor.IsOpen() then return end
    if MapStudio.Ghost and MapStudio.Ghost.IsActive and MapStudio.Ghost.IsActive() then return end

    local pos, objectData = gizmoTarget()
    if not pos then return end

    render.SetColorMaterial()
    drawGizmoPass(pos, objectData, false)
    drawGizmoPass(pos, objectData, true)
end)
