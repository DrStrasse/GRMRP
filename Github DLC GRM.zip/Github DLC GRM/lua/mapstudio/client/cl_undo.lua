MapStudio = MapStudio or {}
MapStudio.Undo = MapStudio.Undo or {}

local undo = MapStudio.Undo

undo.UndoStack = undo.UndoStack or {}
undo.RedoStack = undo.RedoStack or {}
undo.MaxSize = 80

function undo.Push(action)
    if type(action) ~= "table" or not action.type then
        return
    end

    table.insert(undo.UndoStack, action)
    undo.RedoStack = {}

    while #undo.UndoStack > undo.MaxSize do
        table.remove(undo.UndoStack, 1)
    end
end

local function copy(value)
    return MapStudio.DeepCopy(value)
end

local function apply(action, reverse)
    if action.type == "update" then
        local payload = reverse and action.before or action.after

        if payload and action.id then
            MapStudio.Client.UpdateObject(action.id, copy(payload))
        end
    elseif action.type == "batch_update" then
        local updates = {}

        for _, item in ipairs(action.updates or {}) do
            local payload = reverse and item.before or item.after

            if item.id and payload then
                table.insert(updates, {
                    id = item.id,
                    patch = copy(payload)
                })
            end
        end

        if #updates > 0 and MapStudio.Client.UpdateObjects then
            MapStudio.Client.UpdateObjects(updates)
        end
    elseif action.type == "delete" then
        if reverse and action.before then
            MapStudio.Client.CreateObject(copy(action.before))
        elseif action.id then
            MapStudio.Client.DeleteObject(action.id)
        end
    end
end

function undo.Undo()
    local action = table.remove(undo.UndoStack)
    if not action then
        return
    end

    apply(action, true)

    if action.type ~= "delete" then
        table.insert(undo.RedoStack, action)
    end
end

function undo.Redo()
    local action = table.remove(undo.RedoStack)
    if not action then
        return
    end

    apply(action, false)
    table.insert(undo.UndoStack, action)
end

hook.Add("MapStudioStateChanged", "MapStudio_ClearUndoOnProfileChange", function()
    local profile = MapStudio.ClientState.profile

    if undo.LastProfile and undo.LastProfile ~= profile then
        undo.UndoStack = {}
        undo.RedoStack = {}
    end

    undo.LastProfile = profile
end)
