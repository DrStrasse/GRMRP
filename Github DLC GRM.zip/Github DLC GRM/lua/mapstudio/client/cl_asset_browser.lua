MapStudio = MapStudio or {}
MapStudio.AssetBrowser = MapStudio.AssetBrowser or {}

local browser = MapStudio.AssetBrowser

local INITIAL_ICON_LIMIT = 200
local LOAD_MORE_STEP = 200
local ICONS_PER_FRAME = 12
local FRAME_BUDGET = 0.0025
local PANEL_CACHE_LIMIT = 5

browser.ActiveBuildToken = browser.ActiveBuildToken or 0
browser.CategoryDataCache = browser.CategoryDataCache or {}

local function addCopyMenu(icon, model)
    local menu = DermaMenu()
    menu:AddOption("#spawnmenu.menu.copy", function()
        if SetClipboardText then
            SetClipboardText(model or "")
        end
    end):SetIcon("icon16/page_copy.png")
    hook.Run("SpawnmenuIconMenuOpen", menu, icon, "model")
    menu:Open()
end

local function cleanModel(model)
    return MapStudio.NormalizeModelPath and MapStudio.NormalizeModelPath(model) or nil
end

local function trim(value)
    if string.Trim then
        return string.Trim(value or "")
    end

    return string.gsub(value or "", "^%s*(.-)%s*$", "%1")
end

local function lower(value)
    return string.lower(tostring(value or ""))
end

local function endsWithMdl(value)
    value = lower(value)

    if string.EndsWith then
        return string.EndsWith(value, ".mdl")
    end

    return string.sub(value, -4) == ".mdl"
end

local function copyObject(object)
    local result = {}

    for key, value in pairs(object or {}) do
        result[key] = value
    end

    return result
end

local function safeName(value)
    value = tostring(value or "")

    if value == "" then
        return "Spawnlist"
    end

    return value
end

local function tableIsEmpty(tbl)
    return not tbl or next(tbl) == nil
end

local function sortedKeys(tbl)
    local keys = {}

    for key in pairs(tbl or {}) do
        table.insert(keys, key)
    end

    table.sort(keys, function(a, b)
        return tostring(a) < tostring(b)
    end)

    return keys
end

local function sortedByMemberValue(tbl, member)
    local result = {}

    for _, value in pairs(tbl or {}) do
        table.insert(result, value)
    end

    table.sort(result, function(a, b)
        return tostring((a and a[member]) or "") < tostring((b and b[member]) or "")
    end)

    return result
end

function browser.ShortName(modelPath)
    local fileName = string.GetFileFromFilename and string.GetFileFromFilename(modelPath or "") or string.match(modelPath or "", "([^/\\]+)$")
    fileName = fileName or "model"

    if string.StripExtension then
        return string.StripExtension(fileName)
    end

    return string.gsub(fileName, "%.[^%.]+$", "")
end

function browser.SetModel(model)
    local clean, err = MapStudio.Objects.SanitizeModel(model)

    if not clean then
        MapStudio.NotifyLocal(err or "asset.invalid_model", "error")
        return false
    end

    if MapStudio.Objects.ModelExists and not MapStudio.Objects.ModelExists(clean) then
        MapStudio.NotifyLocal("error.invalid_model", "error")
        return false
    end

    if MapStudio.ClientState.tool == "place" and MapStudio.ClientState.selectedModel == clean then
        MapStudio.ClientState.selectedModel = nil

        if MapStudio.Ghost and MapStudio.Ghost.Cancel then
            MapStudio.Ghost.Cancel()
        end

        return true
    end

    MapStudio.ClientState.selectedModel = clean

    if MapStudio.Editor and MapStudio.Editor.StopSmartDuplicate then
        MapStudio.Editor.StopSmartDuplicate()
    end

    if MapStudio.Ghost and MapStudio.Ghost.ClearTemplate then
        MapStudio.Ghost.ClearTemplate()
    end

    if MapStudio.Ghost and MapStudio.Ghost.SetModel and not MapStudio.Ghost.SetModel(clean) then
        return false
    end

    if MapStudio.Editor and MapStudio.Editor.SetTool then
        MapStudio.Editor.SetTool("place")
    else
        MapStudio.ClientState.tool = "place"
        hook.Run("MapStudioToolChanged", "place")
    end

    return true
end

local function patchOwnedIcon(icon, model)
    model = cleanModel(model)

    if not IsValid(icon) or not model then
        return
    end

    icon.MapStudioModelPath = model
    icon.DoClick = function()
        surface.PlaySound("ui/buttonclickrelease.wav")
        browser.SetModel(model)
    end
    icon.DoDoubleClick = icon.DoClick
    icon.OpenMenu = function(panel)
        addCopyMenu(panel, model)
    end
end

local function setReadOnly(container)
    if IsValid(container) and container.IconList and container.IconList.SetReadOnly then
        container.IconList:SetReadOnly(true)
    end
end

local function clearContainer(container)
    if IsValid(container) and container.Clear then
        container:Clear()
        setReadOnly(container)
    end
end

local function addModelIcon(container, object)
    if not IsValid(container) or type(object) ~= "table" then
        return
    end

    local model = cleanModel(object.model or object.spawnname)

    if not model then
        return
    end

    local cp = spawnmenu.GetContentType and spawnmenu.GetContentType("model")
    local icon

    if cp then
        local data = copyObject(object)
        data.type = "model"
        data.model = model
        icon = cp(container, data)
    end

    if not IsValid(icon) then
        icon = vgui.Create("SpawnIcon", container)
        icon:SetModel(model)
        icon:SetTooltip(model)

        if container.Add then
            container:Add(icon)
        end
    end

    patchOwnedIcon(icon, model)
end

local function addContentLabel(container, text)
    if not IsValid(container) then
        return
    end

    local label = vgui.Create("DLabel")
    label:SetText(text or MapStudio.T("asset.no_results"))
    label:SetTextColor(Color(80, 80, 80))
    label:SetContentAlignment(7)
    label:SetWrap(true)
    label:SetSize(260, 42)

    if container.Add then
        container:Add(label)
    end
end

local function addHeader(container, object)
    if not IsValid(container) then
        return
    end

    local label = vgui.Create("DLabel")
    label:SetText(tostring(object and object.text or ""))
    label:SetTextColor(Color(70, 70, 70))
    label:SetFont("DermaDefaultBold")
    label:SetContentAlignment(4)
    label:SetSize(300, 20)

    if container.Add then
        container:Add(label)
    end
end

local function addContentObject(container, object)
    if type(object) ~= "table" then
        return
    end

    if object.type == "model" then
        addModelIcon(container, object)
    elseif object.type == "header" then
        addHeader(container, object)
    end
end

local function getStatusText(loaded, total)
    loaded = tonumber(loaded or 0) or 0
    total = tonumber(total or 0) or 0

    if total <= 0 then
        return ""
    end

    return MapStudio.T("asset.scanning") .. " " .. loaded .. "/" .. total
end

local function setStatus(state, text)
    if IsValid(state.Status) then
        state.Status:SetText(text or "")
    end
end

function browser.CancelActiveBuild()
    browser.ActiveBuildToken = (browser.ActiveBuildToken or 0) + 1
    browser.ActiveQueue = nil
end

local function rememberPanel(state, key, panel)
    if not key or not IsValid(panel) then
        return
    end

    state.PanelCache[key] = panel

    for index = #state.PanelOrder, 1, -1 do
        if state.PanelOrder[index] == key then
            table.remove(state.PanelOrder, index)
        end
    end

    table.insert(state.PanelOrder, key)

    while #state.PanelOrder > PANEL_CACHE_LIMIT do
        local oldKey = table.remove(state.PanelOrder, 1)
        local oldPanel = state.PanelCache[oldKey]
        state.PanelCache[oldKey] = nil

        if IsValid(oldPanel) and oldPanel ~= panel then
            oldPanel:Remove()
        end
    end
end

local function showPanel(state, key, query)
    if IsValid(state.ActivePanel) then
        state.ActivePanel:SetVisible(false)
    end

    local cacheKey = query == "" and key or nil
    local panel

    if cacheKey then
        panel = state.PanelCache[cacheKey]
    else
        panel = state.SearchPanel
    end

    if not IsValid(panel) then
        panel = vgui.Create("ContentContainer", state.PanelHost)
        panel:Dock(FILL)
        setReadOnly(panel)

        if cacheKey then
            rememberPanel(state, cacheKey, panel)
        else
            state.SearchPanel = panel
        end
    elseif cacheKey then
        rememberPanel(state, cacheKey, panel)
    end

    panel:SetVisible(true)
    panel:MoveToFront()
    state.ActivePanel = panel

    return panel, cacheKey ~= nil and panel.MapStudioCacheComplete == true
end

local function filterObjects(objects, query)
    query = lower(trim(query or ""))

    if query == "" then
        return objects or {}
    end

    local filtered = {}

    for _, object in ipairs(objects or {}) do
        if type(object) == "table" and object.type == "model" then
            local model = cleanModel(object.model or object.spawnname)
            local short = browser.ShortName(model or "")

            if model and (string.find(lower(model), query, 1, true) or string.find(lower(short), query, 1, true)) then
                table.insert(filtered, object)
            end
        end
    end

    return filtered
end

local function addLoadMoreButton(state, panel, key, total, shown, query)
    if not IsValid(panel) or shown >= total then
        return
    end

    local button = vgui.Create("DButton")
    button:SetText(MapStudio.T("common.load") .. " " .. math.min(LOAD_MORE_STEP, total - shown))
    button:SetTall(28)
    button:SetWide(180)
    button.DoClick = function()
        state.VisibleLimits[key] = math.min(total, (state.VisibleLimits[key] or INITIAL_ICON_LIMIT) + LOAD_MORE_STEP)
        browser.RenderCategoryObjects(state, key, state.ActiveObjects or {}, query or "")
    end

    if panel.Add then
        panel:Add(button)
    end
end

function browser.RenderCategoryObjects(state, key, objects, query)
    if not state or not IsValid(state.PanelHost) then
        return
    end

    query = trim(query or "")
    key = key or "category"
    state.ActiveCategoryKey = key
    state.ActiveObjects = objects or {}

    local panel, cacheComplete = showPanel(state, key, query)
    local filtered = filterObjects(objects, query)
    local limit = math.min(#filtered, state.VisibleLimits[key] or INITIAL_ICON_LIMIT)

    browser.CancelActiveBuild()

    if cacheComplete and query == "" and panel.MapStudioCacheLimit == limit and panel.MapStudioCacheTotal == #filtered then
        setStatus(state, panel.MapStudioStatusText or "")
        return
    end

    clearContainer(panel)
    panel.MapStudioCacheComplete = false
    panel.MapStudioCacheLimit = limit
    panel.MapStudioCacheTotal = #filtered

    if #filtered == 0 then
        setStatus(state, "")
        addContentLabel(panel, MapStudio.T("asset.no_results"))
        panel.MapStudioCacheComplete = true
        panel.MapStudioStatusText = ""
        return
    end

    setStatus(state, getStatusText(0, #filtered))

    browser.ActiveQueue = {
        token = browser.ActiveBuildToken,
        state = state,
        panel = panel,
        key = key,
        query = query,
        objects = filtered,
        index = 1,
        finish = limit,
        total = #filtered
    }
end

function browser.ProcessQueue()
    local queue = browser.ActiveQueue

    if not queue then
        return
    end

    if queue.token ~= browser.ActiveBuildToken or not IsValid(queue.panel) or not IsValid(queue.state.PanelHost) then
        browser.ActiveQueue = nil
        return
    end

    local started = SysTime()
    local created = 0

    while queue.index <= queue.finish and created < ICONS_PER_FRAME and SysTime() - started < FRAME_BUDGET do
        addContentObject(queue.panel, queue.objects[queue.index])
        queue.index = queue.index + 1
        created = created + 1
    end

    local loaded = math.min(queue.index - 1, queue.finish)
    setStatus(queue.state, getStatusText(loaded, queue.total))

    if queue.index <= queue.finish then
        return
    end

    browser.ActiveQueue = nil

    if IsValid(queue.panel) then
        addLoadMoreButton(queue.state, queue.panel, queue.key, queue.total, queue.finish, queue.query)
        queue.panel.MapStudioCacheComplete = queue.query == ""
        queue.panel.MapStudioCacheLimit = queue.finish
        queue.panel.MapStudioCacheTotal = queue.total
        queue.panel.MapStudioStatusText = MapStudio.T("asset.models_loaded", { count = queue.finish }) .. " / " .. queue.total
    end

    setStatus(queue.state, MapStudio.T("asset.models_loaded", { count = queue.finish }) .. " / " .. queue.total)
end

hook.Add("Think", "MapStudio_AssetBrowserLazyIcons", function()
    browser.ProcessQueue()
end)

local function getPropTable()
    if spawnmenu and spawnmenu.PopulateFromEngineTextFiles and not browser.PropTableInitialized and tableIsEmpty(spawnmenu.GetPropTable and spawnmenu.GetPropTable()) then
        browser.PropTableInitialized = true
        spawnmenu.PopulateFromEngineTextFiles()
    end

    return spawnmenu and spawnmenu.GetPropTable and spawnmenu.GetPropTable() or {}
end

local function getCustomPropTable()
    return spawnmenu and spawnmenu.GetCustomPropTable and spawnmenu.GetCustomPropTable() or {}
end

local function appVisible(info)
    if not info or not info.needsapp or info.needsapp == "" then
        return true
    end

    return not IsMounted or IsMounted(info.needsapp)
end

local function buildChildren(propTable)
    local children = {}

    for _, key in ipairs(sortedKeys(propTable)) do
        local info = propTable[key]

        if type(info) == "table" and appVisible(info) then
            local parentId = tostring(info.parentid or "0")
            children[parentId] = children[parentId] or {}
            table.insert(children[parentId], info)
        end
    end

    return children
end

local function collectSpawnlistObjects(info)
    local objects = {}

    for _, object in ipairs(info and info.contents or {}) do
        if type(object) == "table" and (object.type == "header" or (object.type == "model" and cleanModel(object.model or object.spawnname))) then
            table.insert(objects, object)
        end
    end

    return objects
end

local function selectObjects(state, key, producer)
    if not state or not key then
        return
    end

    local objects = browser.CategoryDataCache[key]

    if not objects then
        objects = producer and producer() or {}
        browser.CategoryDataCache[key] = objects
    end

    if IsValid(state.Search) and state.Search:GetText() ~= "" then
        state.SuppressSearch = true
        state.Search:SetText("")
        state.SuppressSearch = false
    end

    browser.RenderCategoryObjects(state, key, objects, "")
end

local function wireNodeSelection(tree, node, selectFn)
    node.MapStudioSelect = selectFn
    node.DoClick = function(self)
        if self.MapStudioSelect then
            self:MapStudioSelect()
        end
    end
end

local function addSpawnlistNodes(tree, parentNode, children, parentId, state)
    for _, info in ipairs(children[tostring(parentId)] or {}) do
        local node = parentNode:AddNode(safeName(info.name), info.icon or "icon16/folder.png")
        node.MapStudioSpawnlistInfo = info

        wireNodeSelection(tree, node, function()
            selectObjects(state, "spawnlist:" .. tostring(info.id or safeName(info.name)), function()
                return collectSpawnlistObjects(info)
            end)
        end)

        node:SetExpanded(true)
        addSpawnlistNodes(tree, node, children, info.id, state)
    end
end

local function listFolderModels(path, pathID)
    local objects = {}
    local files = file.Find(path .. "/*.mdl", pathID or "GAME")

    for _, name in ipairs(files or {}) do
        if endsWithMdl(name) then
            table.insert(objects, { type = "model", model = path .. "/" .. name })
        end
    end

    table.sort(objects, function(a, b)
        return lower(a.model) < lower(b.model)
    end)

    return objects
end

local function collectRecursiveFolderModels(path, pathID, out)
    out = out or {}

    local files, folders = file.Find(path .. "/*", pathID or "GAME")

    for _, name in ipairs(files or {}) do
        if endsWithMdl(name) then
            table.insert(out, { type = "model", model = path .. "/" .. name })
        end
    end

    table.sort(folders or {}, function(a, b)
        return lower(a) < lower(b)
    end)

    for _, folder in ipairs(folders or {}) do
        collectRecursiveFolderModels(path .. "/" .. folder, pathID, out)
    end

    return out
end

local function addFolderNode(tree, parentNode, label, path, pathID, state, icon)
    local node = parentNode:AddNode(label, icon or "icon16/folder.png")
    local key = "folder:" .. tostring(pathID or "GAME") .. ":" .. tostring(path)

    wireNodeSelection(tree, node, function()
        selectObjects(state, key, function()
            return listFolderModels(path, pathID)
        end)
    end)

    local loaded = false
    node.DoPopulate = function(self)
        if loaded then
            return
        end

        loaded = true

        local _, folders = file.Find(path .. "/*", pathID or "GAME")
        table.sort(folders or {}, function(a, b)
            return lower(a) < lower(b)
        end)

        for _, folder in ipairs(folders or {}) do
            addFolderNode(tree, self, folder, path .. "/" .. folder, pathID, state)
        end
    end

    if node.SetNeedsPopulating then
        node:SetNeedsPopulating(true)
    end

    return node
end

local function addonQualifies(addon)
    return addon and addon.downloaded and addon.mounted and tonumber(addon.models or 0) > 0
end

local function addonPath(addon)
    return addon and (addon.title or addon.wsid or addon.file or addon.name) or nil
end

local function addAddonNode(tree, parentNode, addon, state)
    local title = addon.title or addon.name or addon.wsid or "Addon"
    local pathID = addonPath(addon)

    if not pathID then
        return
    end

    local label = title .. " (" .. tostring(addon.models or 0) .. ")"
    local key = "addon:" .. tostring(pathID)
    local node = parentNode:AddNode(label, "icon16/bricks.png")

    wireNodeSelection(tree, node, function()
        selectObjects(state, key, function()
            local objects = collectRecursiveFolderModels("models", pathID)
            table.sort(objects, function(a, b)
                return lower(a.model) < lower(b.model)
            end)
            return objects
        end)
    end)
end

local function buildBrowse(tree, state)
    local browse = tree:AddNode("#spawnmenu.category.browse", "icon16/bricks.png")
    local addons = browse:AddNode("#spawnmenu.category.addons", "icon16/folder_database.png")

    if engine and engine.GetAddons then
        for _, addon in ipairs(sortedByMemberValue(engine.GetAddons() or {}, "title")) do
            if addonQualifies(addon) then
                addAddonNode(tree, addons, addon, state)
            end
        end
    end

    local games = browse:AddNode("#spawnmenu.category.games", "icon16/controller.png")

    if engine and engine.GetGames then
        local gameInfos = {}

        for _, gameInfo in pairs(engine.GetGames() or {}) do
            table.insert(gameInfos, gameInfo)
        end

        table.insert(gameInfos, { title = "Garry's Mod", folder = "garrysmod", mounted = true, icon = "garrysmod" })
        table.insert(gameInfos, { title = "All", folder = "GAME", mounted = true, icon = "all" })

        for _, gameInfo in ipairs(sortedByMemberValue(gameInfos, "title")) do
            if gameInfo.mounted then
                local pathID = gameInfo.folder or gameInfo.depot or "GAME"
                local icon = gameInfo.icon and ("games/16/" .. gameInfo.icon .. ".png") or (gameInfo.folder and ("games/16/" .. gameInfo.folder .. ".png")) or "icon16/folder.png"
                addFolderNode(tree, games, gameInfo.title or gameInfo.folder or "Game", "models", pathID, state, icon)
            end
        end
    end

    browse:SetExpanded(true)
    addons:SetExpanded(true)
    games:SetExpanded(true)

    return browse
end

function browser.BuildNativeStyleClone(parent)
    browser.CancelActiveBuild()
    parent:Clear()

    local state = {
        PanelCache = {},
        PanelOrder = {},
        VisibleLimits = {}
    }

    local search = vgui.Create("DTextEntry", parent)
    search:Dock(TOP)
    search:DockMargin(0, 0, 0, 6)
    search:SetTall(24)
    search:SetPlaceholderText(MapStudio.T("asset.search_placeholder"))
    state.Search = search

    local body = vgui.Create("DPanel", parent)
    body:Dock(FILL)
    body:SetPaintBackground(false)

    local tree = vgui.Create("DTree", body)
    tree:Dock(LEFT)
    tree:SetWide(178)
    tree:DockMargin(0, 0, 6, 0)
    if tree.SetBackgroundColor then
        tree:SetBackgroundColor(Color(240, 240, 240))
    end
    tree.OnNodeSelected = function(_, selected)
        if IsValid(selected) and selected.MapStudioSelect then
            selected:MapStudioSelect()
        end
    end

    local right = vgui.Create("DPanel", body)
    right:Dock(FILL)
    right:SetPaintBackground(false)

    local status = vgui.Create("DLabel", right)
    status:Dock(BOTTOM)
    status:SetTall(18)
    status:SetText("")
    status:SetTextColor(Color(90, 90, 90))
    state.Status = status

    local panelHost = vgui.Create("DPanel", right)
    panelHost:Dock(FILL)
    panelHost:SetPaintBackground(false)
    state.PanelHost = panelHost

    parent.OnRemove = function()
        browser.CancelActiveBuild()
    end

    search.OnChange = function()
        if state.SuppressSearch then
            return
        end

        if not state.ActiveCategoryKey or not state.ActiveObjects then
            return
        end

        browser.RenderCategoryObjects(state, state.ActiveCategoryKey, state.ActiveObjects, search:GetText())
    end

    local propTable = getPropTable()
    local customPropTable = getCustomPropTable()

    local your = tree:AddNode("#spawnmenu.category.your_spawnlists", "icon16/folder.png")
    addSpawnlistNodes(tree, your, buildChildren(propTable), 0, state)
    your:SetExpanded(true)

    if not tableIsEmpty(customPropTable) then
        local custom = tree:AddNode("#spawnmenu.category.addon_spawnlists", "icon16/folder_database.png")
        addSpawnlistNodes(tree, custom, buildChildren(customPropTable), 0, state)
        custom:SetExpanded(true)
    end

    buildBrowse(tree, state)

    local initialPanel = showPanel(state, "__empty", "")
    clearContainer(initialPanel)
    addContentLabel(initialPanel, MapStudio.T("asset.no_results"))
    setStatus(state, "")
end

function browser.Build(parent)
    if not IsValid(parent) then
        return
    end

    browser.BuildNativeStyleClone(parent)
end
