MapStudio = MapStudio or {}
MapStudio.Theme = MapStudio.Theme or {}

local theme = MapStudio.Theme

theme.Colors = {
    background = Color(18, 21, 27, 235),
    panel = Color(28, 33, 42, 245),
    panelAlt = Color(34, 40, 51, 245),
    border = Color(70, 82, 105, 180),
    accent = Color(75, 149, 255, 255),
    accentHover = Color(100, 170, 255, 255),
    danger = Color(225, 83, 83, 255),
    text = Color(235, 239, 247, 255),
    muted = Color(155, 165, 184, 255),
    field = Color(18, 22, 29, 255)
}

surface.CreateFont("MapStudio.Title", { font = "Roboto", size = 22, weight = 700 })
surface.CreateFont("MapStudio.Label", { font = "Roboto", size = 15, weight = 500 })
surface.CreateFont("MapStudio.Small", { font = "Roboto", size = 13, weight = 400 })

function theme.PaintPanel(panel, width, height, color)
    surface.SetDrawColor(color or theme.Colors.panel)
    surface.DrawRect(0, 0, width, height)
    surface.SetDrawColor(theme.Colors.border)
    surface.DrawOutlinedRect(0, 0, width, height, 1)
end

function theme.PaintButton(panel, width, height, danger)
    local color = danger and theme.Colors.danger or theme.Colors.accent

    if panel:IsDown() then
        color = Color(color.r * 0.75, color.g * 0.75, color.b * 0.75, color.a)
    elseif panel:IsHovered() then
        color = danger and Color(245, 105, 105, 255) or theme.Colors.accentHover
    end

    surface.SetDrawColor(color)
    surface.DrawRect(0, 0, width, height)
end

function theme.StyleLabel(label, muted)
    label:SetFont("MapStudio.Label")
    label:SetTextColor(muted and theme.Colors.muted or theme.Colors.text)
end
