MapStudio = MapStudio or {}
MapStudio.Freecam = MapStudio.Freecam or {}

local freecam = MapStudio.Freecam

freecam.Active = false
freecam.MouseLook = false
freecam.Pos = Vector(0, 0, 0)
freecam.Ang = Angle(0, 0, 0)
freecam.Speed = 650

function freecam.Enable()
    local ply = LocalPlayer()
    freecam.Active = true
    freecam.Pos = IsValid(ply) and ply:EyePos() or Vector(0, 0, 0)
    freecam.Ang = IsValid(ply) and ply:EyeAngles() or Angle(0, 0, 0)

    if IsValid(ply) and ply.DrawShadow then
        ply:DrawShadow(false)
    end
end

function freecam.Disable()
    local ply = LocalPlayer()

    freecam.Active = false
    freecam.MouseLook = false

    if IsValid(ply) and ply.DrawShadow then
        ply:DrawShadow(true)
    end
end

function freecam.SetMouseLook(enabled)
    freecam.MouseLook = enabled == true

    if freecam.MouseLook then
        input.SetCursorPos(ScrW() / 2, ScrH() / 2)
    end
end

local function keyboardFocused()
    local focus = vgui.GetKeyboardFocus()
    local class = IsValid(focus) and focus:GetClassName() or ""

    return class == "TextEntry" or class == "DTextEntry" or class == "MS_TextEntry" or class == "DBinder"
end

function freecam.FocusObject(idOrObject)
    local objectData = idOrObject

    if type(idOrObject) ~= "table" then
        objectData = MapStudio.ClientState.objects[tostring(idOrObject or "")]
    end

    if not objectData then
        return false
    end

    local pos = MapStudio.Objects.ToVector(objectData.pos)
    freecam.Pos = pos - freecam.Ang:Forward() * 180 + Vector(0, 0, 60)

    return true
end

hook.Add("Think", "MapStudio_FreecamThink", function()
    if not freecam.Active or keyboardFocused() then
        return
    end

    local ctrl = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
    local speed = freecam.Speed
    if input.IsKeyDown(KEY_LSHIFT) or input.IsKeyDown(KEY_RSHIFT) then
        speed = speed * 2.5
    elseif ctrl then
        speed = speed * 0.35
    end

    local direction = Vector(0, 0, 0)
    local editorOpen = MapStudio.Editor and MapStudio.Editor.IsOpen and MapStudio.Editor.IsOpen()
    local smartBind = MapStudio.Grid and MapStudio.Grid.GetConVar and MapStudio.Grid.GetConVar("bind_smart_duplicate")
    local smartKey = smartBind and smartBind:GetInt() or KEY_D
    local blockCtrlC = editorOpen and ctrl and input.IsKeyDown(KEY_C)
    local blockSmartKey = editorOpen and ctrl and smartKey > 0 and input.IsKeyDown(smartKey)
    local function movementKeyBlocked(key)
        return blockSmartKey and smartKey == key
    end

    if input.IsKeyDown(KEY_W) and not movementKeyBlocked(KEY_W) then direction = direction + freecam.Ang:Forward() end
    if input.IsKeyDown(KEY_S) and not movementKeyBlocked(KEY_S) then direction = direction - freecam.Ang:Forward() end
    if input.IsKeyDown(KEY_D) and not movementKeyBlocked(KEY_D) then direction = direction + freecam.Ang:Right() end
    if input.IsKeyDown(KEY_A) and not movementKeyBlocked(KEY_A) then direction = direction - freecam.Ang:Right() end
    if input.IsKeyDown(KEY_SPACE) then direction = direction + Vector(0, 0, 1) end
    if input.IsKeyDown(KEY_C) and not blockCtrlC then direction = direction - Vector(0, 0, 1) end

    if direction:LengthSqr() > 0 then
        direction:Normalize()
        freecam.Pos = freecam.Pos + direction * speed * FrameTime()
    end

    if freecam.MouseLook then
        local centerX = ScrW() / 2
        local centerY = ScrH() / 2
        local x, y = input.GetCursorPos()
        local dx = x - centerX
        local dy = y - centerY

        if dx ~= 0 or dy ~= 0 then
            freecam.Ang.p = math.Clamp(freecam.Ang.p + dy * 0.06, -89, 89)
            freecam.Ang.y = freecam.Ang.y - dx * 0.06
            freecam.Ang.r = 0
            input.SetCursorPos(centerX, centerY)
        end
    end
end)

hook.Add("CalcView", "MapStudio_FreecamView", function(_, _, _, fov)
    if not freecam.Active then
        return
    end

    return {
        origin = freecam.Pos,
        angles = freecam.Ang,
        fov = fov,
        drawviewer = false
    }
end)

hook.Add("ShouldDrawLocalPlayer", "MapStudio_HideLocalPlayerInEditor", function()
    if freecam.Active then
        return false
    end
end)

hook.Add("PrePlayerDraw", "MapStudio_HideLocalPlayerModelInEditor", function(ply)
    if freecam.Active and ply == LocalPlayer() then
        return true
    end
end)

hook.Add("PreDrawViewModel", "MapStudio_HideViewModelInEditor", function()
    if freecam.Active then
        return true
    end
end)

hook.Add("PreDrawPlayerHands", "MapStudio_HideHandsInEditor", function(_, _, ply)
    if freecam.Active and ply == LocalPlayer() then
        return true
    end
end)

hook.Add("CreateMove", "MapStudio_BlockPlayerControls", function(cmd)
    if freecam.Active then
        cmd:ClearMovement()
        cmd:ClearButtons()
    end
end)

hook.Add("HUDShouldDraw", "MapStudio_HideHUD", function()
    if freecam.Active then
        return false
    end
end)
