MapStudio = MapStudio or {}
MapStudio.Client = MapStudio.Client or {}
MapStudio.ClientState = MapStudio.ClientState or {
    map = "unknown",
    profile = MapStudio.Config.DefaultProfile,
    objects = {},
    layers = {},
    selectedId = nil,
    selectedIds = {},
    selectedModel = MapStudio.Config.DefaultObject.model,
    activeLayer = "default",
    tool = "select",
    profiles = {},
    layouts = {}
}

CreateClientConVar(MapStudio.Config.LanguageConVar, MapStudio.Config.DefaultLanguage or "en", true, false, "MapStudio interface language")
MapStudio.Lang.RefreshFromConVar()

cvars.AddChangeCallback(MapStudio.Config.LanguageConVar, function()
    MapStudio.Lang.RefreshFromConVar()
end, "MapStudioLanguage")

local transfers = {}
local editorOpenRequest = nil
local editorOpenSequence = 0
local EDITOR_OPEN_TIMEOUT = 8

local function traceback(err)
    if debug and debug.traceback then
        return debug.traceback(tostring(err), 2)
    end

    return tostring(err)
end

local function reportEditorOpenError(key, detail)
    if MapStudio.NotifyLocal then
        MapStudio.NotifyLocal(key or "error.editor_open_failed", "error")
    else
        print("[MapStudio] ERROR: " .. tostring(key or "error.editor_open_failed"))
    end

    if MapStudio.LogError then
        MapStudio.LogError(detail or "Editor could not be opened.")
    else
        print("[MapStudio] ERROR: " .. tostring(detail or "Editor could not be opened."))
    end
end

local function isEditorReady()
    return MapStudio.Editor and type(MapStudio.Editor.Open) == "function"
end

local function encode(payload)
    return util.TableToJSON(payload or {}, false) or "{}"
end

function MapStudio.Client.Send(messageKey, payload)
    net.Start(MapStudio.Net.Get(messageKey))
    net.WriteString(encode(payload))
    net.SendToServer()
end

function MapStudio.Client.RequestState()
    net.Start(MapStudio.Net.Get("RequestState"))
    net.SendToServer()
end

function MapStudio.Client.RequestProfiles()
    net.Start(MapStudio.Net.Get("ListProfiles"))
    net.SendToServer()
end

function MapStudio.Client.RequestLayouts()
    net.Start(MapStudio.Net.Get("ListLayouts"))
    net.SendToServer()
end

function MapStudio.Client.OpenEditorUI()
    if not isEditorReady() then
        reportEditorOpenError("error.editor_not_ready", "Editor module is not loaded on the client.")
        return false, "error.editor_not_ready"
    end

    local ok, opened, err = xpcall(MapStudio.Editor.Open, traceback)

    if not ok then
        reportEditorOpenError("error.editor_open_failed", "Editor open raised an error: " .. tostring(opened))
        return false, "error.editor_open_failed"
    end

    if opened == false then
        reportEditorOpenError(err or "error.editor_open_failed", "Editor open failed: " .. tostring(err or "unknown error"))
        return false, err or "error.editor_open_failed"
    end

    if MapStudio.Log then
        MapStudio.Log("Editor opened.")
    else
        print("[MapStudio] Editor opened.")
    end

    return true
end

function MapStudio.Client.OpenEditor()
    if not isEditorReady() then
        reportEditorOpenError("error.editor_not_ready", "Editor module is not loaded on the client.")
        return false, "error.editor_not_ready"
    end

    if type(MapStudio.Editor.IsOpen) == "function" then
        local stateOk, isOpen = xpcall(MapStudio.Editor.IsOpen, traceback)

        if not stateOk then
            reportEditorOpenError("error.editor_open_failed", "Could not determine editor window state: " .. tostring(isOpen))
            return false, "error.editor_open_failed"
        end

        if isOpen then
            return MapStudio.Client.OpenEditorUI()
        end
    end

    if editorOpenRequest then
        if MapStudio.LogWarning then
            MapStudio.LogWarning("Editor open request is already pending.")
        else
            print("[MapStudio] WARNING: Editor open request is already pending.")
        end

        return false, "error.editor_open_failed"
    end

    local messageName = MapStudio.Net and MapStudio.Net.Get and MapStudio.Net.Get("OpenEditor")

    if type(messageName) ~= "string" or not net or not net.Start or not net.SendToServer then
        reportEditorOpenError("error.editor_not_ready", "Open-editor network message is unavailable on the client.")
        return false, "error.editor_not_ready"
    end

    local sent, sendError = xpcall(function()
        net.Start(messageName)
        net.SendToServer()
    end, traceback)

    if not sent then
        reportEditorOpenError("error.editor_open_failed", "Could not send editor open request: " .. tostring(sendError))
        return false, "error.editor_open_failed"
    end

    editorOpenSequence = editorOpenSequence + 1
    local request = {
        id = editorOpenSequence
    }

    editorOpenRequest = request

    if MapStudio.Log then
        MapStudio.Log("Opening editor...")
    else
        print("[MapStudio] Opening editor...")
    end

    if timer and timer.Simple then
        timer.Simple(EDITOR_OPEN_TIMEOUT, function()
            if editorOpenRequest == request then
                editorOpenRequest = nil
                reportEditorOpenError("error.editor_open_failed", "Editor open request timed out after " .. tostring(EDITOR_OPEN_TIMEOUT) .. " seconds.")
            end
        end)
    end

    return true
end

function MapStudio.Client.CreateObject(data)
    MapStudio.Client.Send("CreateObject", data)
end

function MapStudio.Client.CreateObjects(objects)
    if type(objects) ~= "table" then
        return
    end

    local clean = {}

    for _, objectData in ipairs(objects) do
        if type(objectData) == "table" then
            table.insert(clean, objectData)
        end
    end

    if #clean == 0 then
        return
    end

    MapStudio.Client.Send("CreateObjects", { objects = clean })
end

function MapStudio.Client.UpdateObject(id, patch)
    MapStudio.Client.Send("UpdateObject", { id = id, patch = patch })
end

function MapStudio.Client.UpdateObjects(updates)
    if type(updates) ~= "table" then
        return
    end

    local clean = {}
    local seen = {}

    for key, update in pairs(updates) do
        if type(update) == "table" then
            local id = tostring(update.id or key or "")
            local patch = update.patch or update

            if id ~= "" and type(patch) == "table" and not seen[id] then
                seen[id] = true
                table.insert(clean, {
                    id = id,
                    patch = patch
                })
            end
        end
    end

    if #clean == 0 then
        return
    end

    MapStudio.Client.Send("UpdateObjects", { updates = clean })
end

function MapStudio.Client.DeleteObjects(ids)
    if type(ids) ~= "table" then
        ids = { ids }
    end

    local clean = {}
    local seen = {}

    for _, id in pairs(ids) do
        id = tostring(id or "")

        if id ~= "" and not seen[id] then
            seen[id] = true
            table.insert(clean, id)
        end
    end

    if #clean == 0 then
        return
    end

    MapStudio.Client.Send("DeleteObject", { ids = clean })
end

function MapStudio.Client.DeleteObject(id)
    MapStudio.Client.DeleteObjects({ id })
end

function MapStudio.Client.ClearAllObjects()
    net.Start(MapStudio.Net.Get("ClearObjects"))
    net.SendToServer()
end

function MapStudio.Client.SaveProfile()
    net.Start(MapStudio.Net.Get("SaveProfile"))
    net.SendToServer()
end

function MapStudio.Client.LoadProfile(profile)
    MapStudio.Client.Send("LoadProfile", { profile = profile })
end

function MapStudio.Client.SaveLayout(name, overwrite)
    MapStudio.Client.Send("SaveLayout", {
        name = name,
        overwrite = overwrite == true
    })
end

function MapStudio.Client.LoadLayout(id)
    MapStudio.Client.Send("LoadLayout", { id = id })
end

function MapStudio.Client.DeleteLayout(id)
    MapStudio.Client.Send("DeleteLayout", { id = id })
end

function MapStudio.Client.UpdateLayer(action, id, layer)
    MapStudio.Client.Send("LayerUpdate", {
        action = action,
        id = id,
        layer = layer
    })
end

function MapStudio.Client.ImportPermaProps()
    net.Start(MapStudio.Net.Get("ImportPermaProps"))
    net.SendToServer()
end

function MapStudio.Client.SetState(state)
    if type(state) ~= "table" then
        return
    end

    MapStudio.ClientState.map = state.map or "unknown"
    MapStudio.ClientState.profile = state.profile or MapStudio.Config.DefaultProfile
    MapStudio.ClientState.objects = state.objects or {}
    MapStudio.ClientState.layers = state.layers or {
        default = MapStudio.GetDefaultLayer()
    }
    MapStudio.ClientState.warnings = state.warnings or {}
    MapStudio.ClientState.dirty = state.dirty == true

    local nextSelected = {}
    local selectedIds = MapStudio.ClientState.selectedIds or {}

    for _, id in ipairs(selectedIds) do
        if MapStudio.ClientState.objects[id] then
            table.insert(nextSelected, id)
        end
    end

    if MapStudio.ClientState.selectedId and not MapStudio.ClientState.objects[MapStudio.ClientState.selectedId] then
        MapStudio.ClientState.selectedId = nextSelected[1]
    end

    if MapStudio.ClientState.selectedId and MapStudio.ClientState.objects[MapStudio.ClientState.selectedId] then
        local exists = false

        for _, id in ipairs(nextSelected) do
            if id == MapStudio.ClientState.selectedId then
                exists = true
                break
            end
        end

        if not exists then
            table.insert(nextSelected, 1, MapStudio.ClientState.selectedId)
        end
    end

    MapStudio.ClientState.selectedIds = nextSelected
    MapStudio.ClientState.selectedId = MapStudio.ClientState.selectedId or nextSelected[1]

    if not MapStudio.ClientState.layers[MapStudio.ClientState.activeLayer or "default"] then
        MapStudio.ClientState.activeLayer = "default"
    end

    hook.Run("MapStudioStateChanged", MapStudio.ClientState)
end

net.Receive(MapStudio.Net.Get("StateChunk"), function()
    local transferId = net.ReadString()
    local index = net.ReadUInt(16)
    local total = net.ReadUInt(16)
    local chunk = net.ReadString()
    local transfer = transfers[transferId] or { total = total, chunks = {}, received = 0 }

    transfers[transferId] = transfer

    if not transfer.chunks[index] then
        transfer.received = transfer.received + 1
    end

    transfer.chunks[index] = chunk

    if transfer.received < transfer.total then
        return
    end

    local json = table.concat(transfer.chunks, "")
    transfers[transferId] = nil
    MapStudio.Client.SetState(util.JSONToTable(json))
end)

net.Receive(MapStudio.Net.Get("ObjectCreated"), function()
    local payload = util.JSONToTable(net.ReadString() or "{}") or {}

    if MapStudio.Editor and MapStudio.Editor.HandleObjectCreated then
        MapStudio.Editor.HandleObjectCreated(payload.ids or payload.id)
    end
end)

net.Receive(MapStudio.Net.Get("ProfileList"), function()
    local payload = util.JSONToTable(net.ReadString() or "{}") or {}
    MapStudio.ClientState.profiles = payload.profiles or {}
    hook.Run("MapStudioProfileListChanged", payload)
end)

net.Receive(MapStudio.Net.Get("LayoutList"), function()
    local payload = util.JSONToTable(net.ReadString() or "{}") or {}
    MapStudio.ClientState.layouts = payload.layouts or {}
    hook.Run("MapStudioLayoutListChanged", payload)
end)

net.Receive(MapStudio.Net.Get("OpenEditorResult"), function()
    local payload = util.JSONToTable(net.ReadString() or "{}") or {}
    editorOpenRequest = nil

    if payload.allowed ~= true then
        MapStudio.NotifyLocal(payload.reason or "notify.no_permission", "error")
        return
    end

    MapStudio.Client.OpenEditorUI()
end)

concommand.Add("mapstudio_open", function()
    MapStudio.Client.OpenEditor()
end, nil, MapStudio.T("command.open"))

concommand.Add("mapstudio_close", function()
    if not MapStudio.Editor or type(MapStudio.Editor.Close) ~= "function" then
        reportEditorOpenError("error.editor_not_ready", "Editor close command was used before the client editor module loaded.")
        return
    end

    local ok, err = xpcall(MapStudio.Editor.Close, traceback)

    if not ok then
        reportEditorOpenError("error.editor_open_failed", "Editor close failed: " .. tostring(err))
    end
end, nil, MapStudio.T("command.close"))

concommand.Add("mapstudio_help", function()
    local lines = {
        "MapStudio " .. tostring(MapStudio.Version),
        "Open editor: mapstudio_open",
        "Example bind: bind m mapstudio_open",
        "Validate scene/server state: mapstudio_validate",
        "Close editor: mapstudio_close",
        "Q Menu: open Spawn Menu, then the MapStudio tab.",
        "MapStudio places managed objects; it does not edit BSP terrain."
    }

    for _, line in ipairs(lines) do
        print("[MapStudio] " .. line)
    end

    MapStudio.NotifyLocal("help.printed", "info")
end, nil, MapStudio.T("command.help"))

hook.Add("MapStudioLanguageChanged", "MapStudio_RebuildVisibleUI", function()
    if MapStudio.Spawnmenu and MapStudio.Spawnmenu.RefreshVisible then
        MapStudio.Spawnmenu.RefreshVisible()
    end

    if MapStudio.Editor and MapStudio.Editor.IsOpen() then
        MapStudio.Editor.Rebuild()
    end
end)

timer.Simple(1, function()
    MapStudio.Client.RequestState()
    MapStudio.Client.RequestLayouts()
end)
