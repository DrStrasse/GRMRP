MapStudio = MapStudio or {}
MapStudio.Inspector = MapStudio.Inspector or {}

local inspector = MapStudio.Inspector

local function addRow(parent, labelKey)
    local row = vgui.Create("MS_PropertyRow", parent)
    row:Dock(TOP)
    row:DockMargin(0, 0, 0, 5)
    row:SetLabel(MapStudio.T(labelKey))

    return row
end

local function addEntry(parent, labelKey, value, editable)
    local row = addRow(parent, labelKey)
    local entry = vgui.Create("MS_TextEntry", row:GetContent())
    entry:Dock(FILL)
    entry:SetText(tostring(value or ""))
    entry:SetEditable(editable ~= false)

    return entry
end

local function addCheck(parent, labelKey, value)
    local row = addRow(parent, labelKey)
    local check = vgui.Create("DCheckBoxLabel", row:GetContent())
    check:Dock(FILL)
    check:SetText("")
    check:SetValue(value and 1 or 0)

    return check
end

local function numeric(entry)
    return tonumber(entry:GetText()) or 0
end

local function bodygroupsToText(bodygroups)
    local entries = {}

    for group, value in pairs(type(bodygroups) == "table" and bodygroups or {}) do
        local index = tonumber(group)

        if index then
            table.insert(entries, {
                index = math.floor(index),
                value = math.floor(tonumber(value) or 0)
            })
        end
    end

    table.sort(entries, function(left, right)
        return left.index < right.index
    end)

    local result = {}
    for _, entry in ipairs(entries) do
        table.insert(result, tostring(entry.index) .. ":" .. tostring(entry.value))
    end

    return table.concat(result, ", ")
end

local function textToBodygroups(value)
    local result = {}

    for group, amount in string.gmatch(tostring(value or ""), "([^,%s:]+)%s*:%s*([^,%s:]+)") do
        local index = tonumber(group)
        local bodygroup = tonumber(amount)

        if index and bodygroup then
            result[math.floor(index)] = math.floor(bodygroup)
        end
    end

    return result
end

local function selectedIDs()
    if MapStudio.Editor and MapStudio.Editor.GetSelectedIDs then
        return MapStudio.Editor.GetSelectedIDs()
    end

    local id = MapStudio.ClientState.selectedId
    return id and { id } or {}
end

local function selectedObject(ids)
    ids = ids or selectedIDs()

    if #ids ~= 1 then
        return nil
    end

    return MapStudio.ClientState.objects[ids[1] or ""]
end

local function isReactiveObject(objectData)
    return objectData and (objectData.reactive == true or MapStudio.Objects.SanitizeBehavior(objectData.behavior) == "reactive")
end

local function addReactiveToggle(parent, objectData)
    local row = addRow(parent, "inspector.reactive_object")
    local check = vgui.Create("DCheckBoxLabel", row:GetContent())
    check:Dock(FILL)

    local current = isReactiveObject(objectData)

    local function refreshLabel()
        if IsValid(check) then
            check:SetText(MapStudio.T(current and "inspector.reactive_on" or "inspector.reactive_off"))
        end
    end

    check:SetValue(current and 1 or 0)
    refreshLabel()

    check.OnChange = function(_, value)
        local reactive = value == true or value == 1

        if reactive == current then
            refreshLabel()
            return
        end

        local behavior = reactive and "reactive" or "static"
        local before = MapStudio.DeepCopy(objectData)
        local after = MapStudio.DeepCopy(objectData)

        after.reactive = reactive
        after.behavior = behavior
        after.frozen = true
        after.motion = false

        objectData.reactive = reactive
        objectData.behavior = behavior
        objectData.frozen = true
        objectData.motion = false

        current = reactive
        refreshLabel()

        MapStudio.Undo.Push({ type = "update", id = objectData.id, before = before, after = after })
        MapStudio.Client.UpdateObject(objectData.id, {
            reactive = reactive,
            behavior = behavior,
            frozen = true,
            motion = false
        })

        hook.Run("MapStudioSelectionChanged", MapStudio.ClientState.selectedId, MapStudio.ClientState.selectedIds or {})
    end

    return check
end

function inspector.Build(parent)
    if not IsValid(parent) then
        return
    end

    inspector.Panel = parent
    inspector.Refresh()
end

function inspector.Refresh()
    local parent = inspector.Panel
    if not IsValid(parent) then
        return
    end

    parent:Clear()

    local title = vgui.Create("DLabel", parent)
    if not IsValid(title) then return end

    title:Dock(TOP)
    title:DockMargin(0, 0, 0, 8)
    title:SetText(MapStudio.T("inspector.title"))
    title:SetFont("MapStudio.Title")
    title:SetTextColor(MapStudio.Theme.Colors.text)

    local ids = selectedIDs()

    if #ids > 1 then
        local label = vgui.Create("DLabel", parent)
        label:Dock(TOP)
        label:SetWrap(true)
        label:SetAutoStretchVertical(true)
        label:SetText(MapStudio.T("selection.count", { count = #ids }))
        MapStudio.Theme.StyleLabel(label, true)
        return
    end

    local objectData = selectedObject(ids)
    if not objectData then
        local label = vgui.Create("DLabel", parent)
        label:Dock(TOP)
        label:SetWrap(true)
        label:SetAutoStretchVertical(true)
        label:SetText(MapStudio.T("inspector.select_prompt"))
        MapStudio.Theme.StyleLabel(label, true)
        return
    end

    addEntry(parent, "inspector.id", objectData.id, false)
    addEntry(parent, "inspector.class", objectData.class, false)
    addEntry(parent, "inspector.model", objectData.model, false)
    addEntry(parent, "inspector.owner", objectData.createdBy or "", false)
    addReactiveToggle(parent, objectData)

    local x = addEntry(parent, "inspector.axis_x", objectData.pos and objectData.pos.x)
    local y = addEntry(parent, "inspector.axis_y", objectData.pos and objectData.pos.y)
    local z = addEntry(parent, "inspector.axis_z", objectData.pos and objectData.pos.z)
    local pitch = addEntry(parent, "inspector.pitch", objectData.ang and objectData.ang.p)
    local yaw = addEntry(parent, "inspector.yaw", objectData.ang and objectData.ang.y)
    local roll = addEntry(parent, "inspector.roll", objectData.ang and objectData.ang.r)
    local scale = addEntry(parent, "inspector.scale", objectData.scale or 1)
    local skin = addEntry(parent, "inspector.skin", objectData.skin or 0)
    local material = addEntry(parent, "inspector.material", objectData.material or "")
    local bodygroups = addEntry(parent, "inspector.bodygroups", bodygroupsToText(objectData.bodygroups))
    bodygroups:SetTooltip("0:1, 1:0")

    local colorRow = addRow(parent, "inspector.color")
    local colorPanel = colorRow:GetContent()
    local r = vgui.Create("MS_TextEntry", colorPanel)
    local g = vgui.Create("MS_TextEntry", colorPanel)
    local b = vgui.Create("MS_TextEntry", colorPanel)
    local a = vgui.Create("MS_TextEntry", colorPanel)
    r:Dock(LEFT)
    g:Dock(LEFT)
    b:Dock(LEFT)
    a:Dock(FILL)
    r:SetWide(42)
    g:SetWide(42)
    b:SetWide(42)
    r:DockMargin(0, 0, 4, 0)
    g:DockMargin(0, 0, 4, 0)
    b:DockMargin(0, 0, 4, 0)
    r:SetText(tostring(objectData.color and objectData.color.r or 255))
    g:SetText(tostring(objectData.color and objectData.color.g or 255))
    b:SetText(tostring(objectData.color and objectData.color.b or 255))
    a:SetText(tostring(objectData.color and objectData.color.a or 255))

    local collision = addCheck(parent, "inspector.collision", objectData.collision ~= false)
    local frozen = addCheck(parent, "inspector.frozen", objectData.frozen == true)
    local motion = addCheck(parent, "inspector.motion", objectData.motion == true)
    local gravity = addCheck(parent, "inspector.gravity", objectData.gravity == true)
    local isReactive = isReactiveObject(objectData)

    if isReactive then
        frozen:SetValue(1)
        frozen:SetEnabled(false)
        motion:SetValue(0)
        motion:SetEnabled(false)
    end

    local apply = vgui.Create("MS_Button", parent)
    apply:Dock(TOP)
    apply:DockMargin(0, 8, 0, 0)
    apply:SetText(MapStudio.T("inspector.apply"))
    apply.DoClick = function()
        local before = MapStudio.DeepCopy(objectData)
        local reactive = isReactiveObject(objectData)
        local patch = {
            pos = { x = numeric(x), y = numeric(y), z = numeric(z) },
            ang = { p = numeric(pitch), y = numeric(yaw), r = numeric(roll) },
            scale = numeric(scale),
            skin = numeric(skin),
            material = material:GetText(),
            bodygroups = textToBodygroups(bodygroups:GetText()),
            color = { r = numeric(r), g = numeric(g), b = numeric(b), a = numeric(a) },
            collision = collision:GetChecked(),
            frozen = reactive or frozen:GetChecked(),
            motion = not reactive and not frozen:GetChecked() and motion:GetChecked(),
            gravity = gravity:GetChecked(),
            layer = objectData.layer or "default"
        }
        local after = MapStudio.DeepCopy(before)

        for key, value in pairs(patch) do
            after[key] = value
        end

        MapStudio.Undo.Push({ type = "update", id = objectData.id, before = before, after = after })
        MapStudio.Client.UpdateObject(objectData.id, patch)
    end

    local reset = vgui.Create("MS_Button", parent)
    reset:Dock(TOP)
    reset:DockMargin(0, 8, 0, 0)
    reset:SetText(MapStudio.T("inspector.reset_transform"))
    reset.DoClick = function()
        if MapStudio.Gizmo and MapStudio.Gizmo.ResetSelectedTransform then
            MapStudio.Gizmo.ResetSelectedTransform()
        end
    end

    local copy = vgui.Create("MS_Button", parent)
    copy:Dock(TOP)
    copy:DockMargin(0, 5, 0, 0)
    copy:SetText(MapStudio.T("inspector.copy_data"))
    copy.DoClick = function()
        if MapStudio.Editor and MapStudio.Editor.CopySelectedObject then
            MapStudio.Editor.CopySelectedObject()
        end
    end

    local duplicate = vgui.Create("MS_Button", parent)
    duplicate:Dock(TOP)
    duplicate:DockMargin(0, 5, 0, 0)
    duplicate:SetText(MapStudio.T("inspector.duplicate"))
    duplicate.DoClick = function()
        if MapStudio.Editor and MapStudio.Editor.CopySelectedObject and MapStudio.Editor.PasteClipboard then
            if MapStudio.Editor.CopySelectedObject() then
                MapStudio.Editor.PasteClipboard()
            end
        end
    end

    local delete = vgui.Create("MS_Button", parent)
    delete:Dock(TOP)
    delete:DockMargin(0, 5, 0, 0)
    delete:SetDanger(true)
    delete:SetText(MapStudio.T("inspector.delete"))
    delete.DoClick = function()
        local remove = function()
            if MapStudio.Editor and MapStudio.Editor.DeleteSelected then
                MapStudio.Editor.DeleteSelected()
            end
        end

        if Derma_Query then
            Derma_Query(MapStudio.T("object.confirm_delete"), MapStudio.T("inspector.title"), MapStudio.T("common.delete"), remove, MapStudio.T("common.cancel"))
        else
            remove()
        end
    end
end

hook.Add("MapStudioStateChanged", "MapStudio_InspectorRefreshState", function()
    inspector.Refresh()
end)

hook.Add("MapStudioSelectionChanged", "MapStudio_InspectorRefreshSelection", function()
    inspector.Refresh()
end)
