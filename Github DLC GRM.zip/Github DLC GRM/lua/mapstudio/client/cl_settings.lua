MapStudio = MapStudio or {}
MapStudio.Settings = MapStudio.Settings or {}

local settings = MapStudio.Settings
settings.Binders = settings.Binders or {}
settings.BindConVars = {
    "bind_delete",
    "bind_cancel",
    "bind_grid",
    "bind_snap",
    "bind_rotate_blue_left",
    "bind_rotate_blue_right",
    "bind_rotate_red_up",
    "bind_rotate_red_down",
    "bind_rotate_green_left",
    "bind_rotate_green_right",
    "bind_cycle_rotation_angle",
    "bind_reset_transform",
    "bind_toggle_reactive",
    "bind_smart_duplicate"
}

local DEGREE = string.char(194, 176)

local function rotationPresetLabel(value)
    local preset = MapStudio.Grid.NormalizeRotationStep(value)
    return tostring(preset) .. DEGREE
end

function settings.IsCapturingBind()
    local focus = vgui.GetKeyboardFocus()

    return IsValid(focus) and focus:GetClassName() == "DBinder"
end

function settings.UpdateRotationPreset(value)
    local combo = settings.RotationCombo

    if not IsValid(combo) then
        return
    end

    local label = rotationPresetLabel(value or MapStudio.Grid.GetRotationSnap())

    if combo.GetValue and combo:GetValue() == label then
        return
    end

    combo:SetValue(label)
end

local function setBinderValue(conVarName, key)
    local binder = settings.Binders[conVarName]

    if IsValid(binder) and binder:GetValue() ~= key then
        binder:SetValue(key)
    end
end

local function applyBind(conVarName, key, sourceBinder)
    if settings.ApplyingBind then
        return
    end

    settings.ApplyingBind = true
    key = tonumber(key) or 0

    if key == MOUSE_RIGHT then
        key = 0
    end

    local currentConVar = MapStudio.Grid.GetConVar(conVarName)
    local previousKey = currentConVar and currentConVar:GetInt() or 0

    if previousKey == MOUSE_RIGHT then
        previousKey = 0
    end

    if key > 0 then
        for _, otherConVarName in ipairs(settings.BindConVars) do
            if otherConVarName ~= conVarName then
                local otherConVar = MapStudio.Grid.GetConVar(otherConVarName)

                if otherConVar and otherConVar:GetInt() == key then
                    RunConsoleCommand("mapstudio_" .. otherConVarName, tostring(previousKey))
                    setBinderValue(otherConVarName, previousKey)
                end
            end
        end
    end

    RunConsoleCommand("mapstudio_" .. conVarName, tostring(key))

    if IsValid(sourceBinder) and sourceBinder:GetValue() ~= key then
        sourceBinder:SetValue(key)
    end

    if MapStudio.Editor and MapStudio.Editor.SuppressKey then
        MapStudio.Editor.SuppressKey(key)
    end

    settings.ApplyingBind = false
end

local function addTitle(parent, text)
    local label = vgui.Create("DLabel", parent)
    label:Dock(TOP)
    label:DockMargin(0, 0, 0, 8)
    label:SetText(text)
    label:SetFont("MapStudio.Title")
    label:SetTextColor(MapStudio.Theme.Colors.text)

    return label
end

local function addCheck(parent, text, conVarName)
    local check = vgui.Create("DCheckBoxLabel", parent)
    check:Dock(TOP)
    check:DockMargin(0, 0, 0, 8)
    check:SetText(text)
    check:SetTextColor(MapStudio.Theme.Colors.text)
    check:SetConVar("mapstudio_" .. conVarName)

    return check
end

local function addNumber(parent, text, conVarName, minValue, maxValue, decimals)
    local slider = vgui.Create("DNumSlider", parent)
    slider:Dock(TOP)
    slider:DockMargin(0, 0, 0, 8)
    slider:SetText(text)
    slider:SetMinMax(minValue, maxValue)
    slider:SetDecimals(decimals or 0)
    slider:SetConVar("mapstudio_" .. conVarName)

    if slider.Label then
        slider.Label:SetTextColor(MapStudio.Theme.Colors.text)
    end

    return slider
end

local function addRotationPreset(parent)
    local row = vgui.Create("MS_PropertyRow", parent)
    row:Dock(TOP)
    row:DockMargin(0, 0, 0, 8)
    row:SetLabel(MapStudio.T("settings.rotation_snap"))
    row.Label:SetWide(170)

    local combo = vgui.Create("DComboBox", row:GetContent())
    combo:Dock(FILL)

    local current = MapStudio.Grid.GetRotationSnap()
    combo:SetValue(rotationPresetLabel(current))
    settings.RotationCombo = combo
    combo.OnRemove = function(panel)
        if settings.RotationCombo == panel then
            settings.RotationCombo = nil
        end
    end

    for _, preset in ipairs(MapStudio.Grid.RotationPresets or { 15, 30, 45, 60, 90 }) do
        combo:AddChoice(rotationPresetLabel(preset), preset, preset == current)
    end

    combo.OnSelect = function(_, _, _, data)
        settings.UpdateRotationPreset(MapStudio.Grid.SetRotationSnap(data or 15))
    end

    return combo
end

local function addBinder(parent, text, conVarName)
    local row = vgui.Create("MS_PropertyRow", parent)
    row:Dock(TOP)
    row:DockMargin(0, 0, 0, 8)
    row:SetLabel(text)
    row.Label:SetWide(230)

    local binder = vgui.Create("DBinder", row:GetContent())
    binder:Dock(FILL)

    local conVar = MapStudio.Grid.GetConVar(conVarName)
    binder:SetValue(conVar and conVar:GetInt() or 0)
    settings.Binders[conVarName] = binder
    binder.OnChange = function(panel, key)
        applyBind(conVarName, key, panel)
    end

    return binder
end

local function addLanguage(parent)
    local row = vgui.Create("MS_PropertyRow", parent)
    row:Dock(TOP)
    row:DockMargin(0, 0, 0, 8)
    row:SetLabel(MapStudio.T("settings.language"))
    row.Label:SetWide(170)

    local combo = vgui.Create("DComboBox", row:GetContent())
    combo:Dock(FILL)
    combo:SetValue(MapStudio.T("language." .. MapStudio.Lang.GetLanguage()))
    combo:AddChoice(MapStudio.T("language.en"), "en", MapStudio.Lang.GetLanguage() == "en")
    combo:AddChoice(MapStudio.T("language.ru"), "ru", MapStudio.Lang.GetLanguage() == "ru")
    combo.OnSelect = function(_, _, _, data)
        RunConsoleCommand(MapStudio.Config.LanguageConVar, data or "en")
    end
end

function settings.Build(parent)
    if not IsValid(parent) then
        return
    end

    parent:Clear()
    settings.RotationCombo = nil

    addTitle(parent, MapStudio.T("settings.title"))

    local back = vgui.Create("MS_Button", parent)
    back:Dock(TOP)
    back:DockMargin(0, 0, 0, 12)
    back:SetText(MapStudio.T("settings.back_to_inspector"))
    back.DoClick = function()
        if MapStudio.Editor and MapStudio.Editor.ShowInspector then
            MapStudio.Editor.ShowInspector()
        end
    end

    addLanguage(parent)
    addCheck(parent, MapStudio.T("settings.show_grid"), "show_grid")
    addCheck(parent, MapStudio.T("settings.snap_grid"), "snap_grid")
    addNumber(parent, MapStudio.T("settings.grid_size"), "grid_size", 8, 256, 0)
    addRotationPreset(parent)

    local bindTitle = vgui.Create("DLabel", parent)
    bindTitle:Dock(TOP)
    bindTitle:DockMargin(0, 10, 0, 8)
    bindTitle:SetText(MapStudio.T("settings.keybinds"))
    MapStudio.Theme.StyleLabel(bindTitle, false)

    addBinder(parent, MapStudio.T("settings.bind_delete"), "bind_delete")
    addBinder(parent, MapStudio.T("settings.bind_cancel"), "bind_cancel")
    addBinder(parent, MapStudio.T("settings.bind_grid"), "bind_grid")
    addBinder(parent, MapStudio.T("settings.bind_snap"), "bind_snap")
    addBinder(parent, MapStudio.T("settings.bind_rotate_blue_left"), "bind_rotate_blue_left")
    addBinder(parent, MapStudio.T("settings.bind_rotate_blue_right"), "bind_rotate_blue_right")
    addBinder(parent, MapStudio.T("settings.bind_rotate_red_up"), "bind_rotate_red_up")
    addBinder(parent, MapStudio.T("settings.bind_rotate_red_down"), "bind_rotate_red_down")
    addBinder(parent, MapStudio.T("settings.bind_rotate_green_left"), "bind_rotate_green_left")
    addBinder(parent, MapStudio.T("settings.bind_rotate_green_right"), "bind_rotate_green_right")
    addBinder(parent, MapStudio.T("settings.bind_cycle_rotation_angle"), "bind_cycle_rotation_angle")
    addBinder(parent, MapStudio.T("settings.bind_reset_transform"), "bind_reset_transform")
    addBinder(parent, MapStudio.T("settings.bind_toggle_reactive"), "bind_toggle_reactive")
    addBinder(parent, MapStudio.T("settings.bind_smart_duplicate"), "bind_smart_duplicate")

    local dangerTitle = vgui.Create("DLabel", parent)
    dangerTitle:Dock(TOP)
    dangerTitle:DockMargin(0, 12, 0, 8)
    dangerTitle:SetText(MapStudio.T("settings.danger_zone"))
    MapStudio.Theme.StyleLabel(dangerTitle, false)

    local clear = vgui.Create("MS_Button", parent)
    clear:Dock(TOP)
    clear:SetDanger(true)
    clear:SetText(MapStudio.T("settings.clear_map"))
    clear.DoClick = function()
        Derma_Query(MapStudio.T("settings.clear_map_confirm"), MapStudio.T("settings.clear_map"), MapStudio.T("common.yes"), function()
            MapStudio.Client.ClearAllObjects()
            if MapStudio.Editor then
                MapStudio.Editor.ClearSelection()
            end
        end, MapStudio.T("common.no"))
    end
end

hook.Add("MapStudioRotationSnapChanged", "MapStudio_SettingsRotationPreset", function(value)
    settings.UpdateRotationPreset(value)
end)
