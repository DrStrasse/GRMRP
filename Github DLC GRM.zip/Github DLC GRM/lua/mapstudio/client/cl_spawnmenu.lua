MapStudio = MapStudio or {}
MapStudio.Spawnmenu = MapStudio.Spawnmenu or {}

local spawnmenuPanel = MapStudio.Spawnmenu

local function addLanguageChoice(combo, key, code)
    combo:AddChoice(MapStudio.T(key), code, MapStudio.Lang.GetLanguage() == code)
end

local function currentMapName()
    return MapStudio.ClientState and MapStudio.ClientState.map or game.GetMap() or "unknown"
end

local function trim(value)
    value = tostring(value or "")

    if string.Trim then
        return string.Trim(value)
    end

    return string.gsub(value, "^%s*(.-)%s*$", "%1")
end

local function layoutNameExists(name)
    name = string.lower(trim(name))

    for _, layout in ipairs((MapStudio.ClientState and MapStudio.ClientState.layouts) or {}) do
        if string.lower(trim(layout.displayName or "")) == name then
            return true
        end
    end

    return false
end

local function requestEditorOpen()
    if MapStudio.Client and type(MapStudio.Client.OpenEditor) == "function" then
        return MapStudio.Client.OpenEditor()
    end

    if MapStudio.NotifyLocal then
        MapStudio.NotifyLocal("error.editor_not_ready", "error")
    else
        print("[MapStudio] ERROR: MapStudio client opener is not ready.")
    end

    if MapStudio.LogError then
        MapStudio.LogError("Q Menu open button was used before the client opener loaded.")
    end

    return false
end

local function openSaveLayoutDialog()
    if MapStudio.Client and MapStudio.Client.RequestLayouts then
        MapStudio.Client.RequestLayouts()
    end

    local frame = vgui.Create("DFrame")
    if not IsValid(frame) then return end

    frame:SetSize(380, 190)
    frame:Center()
    frame:SetTitle(MapStudio.T("layout.save"))
    frame:MakePopup()

    local nameLabel = vgui.Create("DLabel", frame)
    nameLabel:Dock(TOP)
    nameLabel:DockMargin(12, 10, 12, 4)
    nameLabel:SetText(MapStudio.T("layout.name"))
    nameLabel:SetTextColor(MapStudio.Theme.Colors.text)

    local input = vgui.Create("MS_TextEntry", frame)
    input:Dock(TOP)
    input:DockMargin(12, 0, 12, 10)
    input:SetTall(28)
    input:RequestFocus()

    local mapLabel = vgui.Create("DLabel", frame)
    mapLabel:Dock(TOP)
    mapLabel:DockMargin(12, 0, 12, 10)
    mapLabel:SetText(MapStudio.T("layout.current_map") .. ": " .. currentMapName())
    mapLabel:SetTextColor(MapStudio.Theme.Colors.muted)

    local buttons = vgui.Create("DPanel", frame)
    buttons:Dock(BOTTOM)
    buttons:DockMargin(12, 0, 12, 12)
    buttons:SetTall(34)
    buttons:SetPaintBackground(false)

    local cancel = vgui.Create("MS_Button", buttons)
    cancel:Dock(RIGHT)
    cancel:SetWide(105)
    cancel:SetText(MapStudio.T("layout.cancel"))
    cancel.DoClick = function()
        frame:Close()
    end

    local save = vgui.Create("MS_Button", buttons)
    save:Dock(RIGHT)
    save:DockMargin(0, 0, 8, 0)
    save:SetWide(105)
    save:SetText(MapStudio.T("layout.save"))
    save.DoClick = function()
        local name = trim(input:GetValue())

        if name == "" then
            input:RequestFocus()
            return
        end

        local function submit(overwrite)
            MapStudio.Client.SaveLayout(name, overwrite)
            frame:Close()
        end

        if layoutNameExists(name) then
            Derma_Query(MapStudio.T("layout.overwrite_confirm"), MapStudio.T("layout.save"), MapStudio.T("common.yes"), function()
                submit(true)
            end, MapStudio.T("common.no"))
        else
            submit(false)
        end
    end
end

local function openLoadLayoutDialog()
    if MapStudio.Client and MapStudio.Client.RequestLayouts then
        MapStudio.Client.RequestLayouts()
    end

    local frame = vgui.Create("DFrame")
    if not IsValid(frame) then return end

    frame:SetSize(560, 420)
    frame:Center()
    frame:SetTitle(MapStudio.T("layout.saved_for_map"))
    frame:MakePopup()

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    scroll:DockMargin(10, 10, 10, 10)

    local function rebuild()
        if not IsValid(scroll) then return end

        scroll:Clear()

        local layouts = (MapStudio.ClientState and MapStudio.ClientState.layouts) or {}
        if #layouts == 0 then
            local empty = vgui.Create("DLabel", scroll)
            empty:Dock(TOP)
            empty:SetTall(28)
            empty:SetText(MapStudio.T("layout.none_for_map"))
            empty:SetTextColor(MapStudio.Theme.Colors.muted)
            return
        end

        for _, layout in ipairs(layouts) do
            local row = vgui.Create("DPanel", scroll)
            row:Dock(TOP)
            row:DockMargin(0, 0, 0, 8)
            row:SetTall(54)
            row.Paint = function(_, width, height)
                draw.RoundedBox(6, 0, 0, width, height, MapStudio.Theme.Colors.panelAlt)
            end

            local load = vgui.Create("MS_Button", row)
            load:Dock(RIGHT)
            load:DockMargin(6, 10, 10, 10)
            load:SetWide(84)
            load:SetText(MapStudio.T("layout.load"))
            load.DoClick = function()
                Derma_Query(MapStudio.T("layout.replace_confirm"), MapStudio.T("layout.load"), MapStudio.T("common.yes"), function()
                    MapStudio.Client.LoadLayout(layout.id)
                    frame:Close()
                end, MapStudio.T("common.no"))
            end

            local delete = vgui.Create("MS_Button", row)
            delete:Dock(RIGHT)
            delete:DockMargin(6, 10, 0, 10)
            delete:SetWide(120)
            delete:SetText(MapStudio.T("layout.delete"))
            delete:SetDanger(true)
            delete.DoClick = function()
                Derma_Query(MapStudio.T("layout.delete_confirm"), MapStudio.T("layout.delete"), MapStudio.T("common.yes"), function()
                    MapStudio.Client.DeleteLayout(layout.id)
                end, MapStudio.T("common.no"))
            end

            local label = vgui.Create("DLabel", row)
            label:Dock(FILL)
            label:DockMargin(12, 5, 10, 5)
            local saved = tonumber(layout.savedAt) and tonumber(layout.savedAt) > 0 and os.date("%Y-%m-%d %H:%M", tonumber(layout.savedAt)) or ""
            local details = tostring(layout.objectCount or 0) .. " " .. MapStudio.T("common.objects")
            if saved ~= "" then details = details .. " | " .. saved end
            label:SetText(tostring(layout.displayName or layout.id or "") .. "\n" .. details)
            label:SetTextColor(MapStudio.Theme.Colors.text)
        end
    end

    local hookName = "MapStudioLayoutDialog_" .. tostring(frame)
    hook.Add("MapStudioLayoutListChanged", hookName, function()
        if IsValid(frame) then
            rebuild()
        else
            hook.Remove("MapStudioLayoutListChanged", hookName)
        end
    end)

    frame.OnClose = function()
        hook.Remove("MapStudioLayoutListChanged", hookName)
    end

    rebuild()
end

function spawnmenuPanel.BuildDashboard(parent)
    if not IsValid(parent) then
        return
    end

    spawnmenuPanel.CurrentPanel = parent
    parent:Clear()
    parent:DockPadding(16, 16, 16, 16)

    local title = vgui.Create("DLabel", parent)
    title:Dock(TOP)
    title:DockMargin(0, 0, 0, 14)
    title:SetText(MapStudio.T("addon.full_name"))
    title:SetFont("MapStudio.Title")
    title:SetTextColor(MapStudio.Theme.Colors.text)

    local open = vgui.Create("MS_Button", parent)
    open:Dock(TOP)
    open:DockMargin(0, 0, 0, 12)
    open:SetTall(36)
    open:SetText(MapStudio.T("spawnmenu.open_editor"))
    open:SetTooltip(MapStudio.T("spawnmenu.open_editor_tooltip"))
    open.DoClick = function()
        requestEditorOpen()
    end

    local saveLayout = vgui.Create("MS_Button", parent)
    saveLayout:Dock(TOP)
    saveLayout:DockMargin(0, 0, 0, 8)
    saveLayout:SetTall(34)
    saveLayout:SetText(MapStudio.T("layout.save"))
    saveLayout.DoClick = function()
        openSaveLayoutDialog()
    end

    local loadLayout = vgui.Create("MS_Button", parent)
    loadLayout:Dock(TOP)
    loadLayout:DockMargin(0, 0, 0, 14)
    loadLayout:SetTall(34)
    loadLayout:SetText(MapStudio.T("layout.load"))
    loadLayout.DoClick = function()
        openLoadLayoutDialog()
    end

    local languageLabel = vgui.Create("DLabel", parent)
    languageLabel:Dock(TOP)
    languageLabel:DockMargin(0, 0, 0, 6)
    languageLabel:SetText(MapStudio.T("settings.language"))
    MapStudio.Theme.StyleLabel(languageLabel, true)

    local language = vgui.Create("DComboBox", parent)
    language:Dock(TOP)
    language:SetTall(28)
    language:SetValue(MapStudio.T("language." .. MapStudio.Lang.GetLanguage()))
    addLanguageChoice(language, "language.en", "en")
    addLanguageChoice(language, "language.ru", "ru")
    language.OnSelect = function(_, _, _, data)
        RunConsoleCommand(MapStudio.Config.LanguageConVar, data or "en")
    end
end

function spawnmenuPanel.RefreshVisible()
    if IsValid(spawnmenuPanel.CurrentPanel) then
        spawnmenuPanel.BuildDashboard(spawnmenuPanel.CurrentPanel)
    end
end

local function createTab()
    local panel = vgui.Create("MS_Panel")
    spawnmenuPanel.BuildDashboard(panel)

    if MapStudio.Client and type(MapStudio.Client.RequestState) == "function" then
        MapStudio.Client.RequestState()
    end

    return panel
end

local function registerCreationTab()
    if spawnmenuPanel.TabRegistered then
        return true
    end

    if not spawnmenu or type(spawnmenu.AddCreationTab) ~= "function" then
        return false
    end

    local ok, err = pcall(spawnmenu.AddCreationTab, MapStudio.T("spawnmenu.tab"), createTab, "icon16/world.png", 80)

    if not ok then
        err = tostring(err)

        if spawnmenuPanel.LastTabRegistrationError ~= err and MapStudio.LogWarning then
            MapStudio.LogWarning("Could not register the Q Menu tab yet: " .. tostring(err))
        elseif spawnmenuPanel.LastTabRegistrationError ~= err then
            print("[MapStudio] WARNING: Could not register the Q Menu tab yet: " .. tostring(err))
        end

        spawnmenuPanel.LastTabRegistrationError = err

        return false
    end

    spawnmenuPanel.TabRegistered = true
    return true
end

if not registerCreationTab() then
    local attempts = 0

    hook.Add("Think", "MapStudio_RegisterSpawnmenuTab", function()
        attempts = attempts + 1

        if registerCreationTab() then
            hook.Remove("Think", "MapStudio_RegisterSpawnmenuTab")
        elseif attempts >= 300 then
            hook.Remove("Think", "MapStudio_RegisterSpawnmenuTab")

            if MapStudio.LogError then
                MapStudio.LogError("MapStudio Q Menu tab could not be registered; use mapstudio_open in the console.")
            else
                print("[MapStudio] ERROR: MapStudio Q Menu tab could not be registered; use mapstudio_open in the console.")
            end
        end
    end)
end
