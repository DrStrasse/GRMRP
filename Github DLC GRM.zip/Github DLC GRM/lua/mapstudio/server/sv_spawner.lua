MapStudio = MapStudio or {}
MapStudio.Spawner = MapStudio.Spawner or {}
MapStudio.RuntimeEntities = MapStudio.RuntimeEntities or {}

local spawner = MapStudio.Spawner

local function addWarning(key, replacements)
    local state = MapStudio.GetState()
    state.warnings = state.warnings or {}
    table.insert(state.warnings, {
        key = key,
        replacements = replacements or {},
        createdAt = os.time()
    })
end

local function call(ent, methodName, ...)
    local method = IsValid(ent) and ent[methodName] or nil

    if not method then
        return true
    end

    local ok, err = pcall(method, ent, ...)

    if not ok then
        MapStudio.LogWarning("Entity method failed: " .. tostring(methodName) .. " (" .. tostring(err) .. ")")
        return false, err
    end

    return true
end

local function callPhysics(phys, methodName, ...)
    local method = IsValid(phys) and phys[methodName] or nil

    if not method then
        return true
    end

    local ok, err = pcall(method, phys, ...)

    if not ok then
        MapStudio.LogWarning("Physics method failed: " .. tostring(methodName) .. " (" .. tostring(err) .. ")")
        return false, err
    end

    return true
end

local function getPhysicsObject(ent)
    if not IsValid(ent) or not ent.GetPhysicsObject then
        return nil, "invalid entity or missing GetPhysicsObject"
    end

    local ok, phys = pcall(ent.GetPhysicsObject, ent)
    if not ok then
        return nil, phys
    end

    return phys
end

local function markNoPhysicsFallback(ent, objectData, reason)
    reason = tostring(reason or "warning.no_physics_fallback")
    local alreadyMarked = objectData.noPhysicsFallback == true
    objectData.noPhysicsFallback = true
    objectData.spawnWarning = reason

    if IsValid(ent) then
        ent.MapStudioNoPhysicsFallback = true
        call(ent, "SetNWBool", "MapStudioNoPhysicsFallback", true)

        call(ent, "SetNotSolid", true)
        call(ent, "SetSolid", SOLID_NONE)
        call(ent, "SetMoveType", MOVETYPE_NONE)
        call(ent, "SetCollisionGroup", COLLISION_GROUP_WORLD)
    end

    if alreadyMarked then
        return
    end

    addWarning("warning.no_physics_fallback", {
        id = objectData.id,
        model = objectData.model,
        class = objectData.class,
        reason = reason
    })

    local entityIndex = nil
    if IsValid(ent) and ent.EntIndex then
        local ok, value = pcall(ent.EntIndex, ent)
        entityIndex = ok and tonumber(value) or nil
    end

    MapStudio.LogWarning("Using no-physics fallback for id=" .. tostring(objectData.id)
        .. " model=" .. tostring(objectData.model)
        .. " class=" .. tostring(objectData.class)
        .. (entityIndex and " entity=" .. tostring(entityIndex) or "")
        .. " reason=" .. reason)
end

function spawner.ApplyNoPhysicsFallback(ent, objectData, reason)
    if type(objectData) ~= "table" then
        return false
    end

    markNoPhysicsFallback(ent, objectData, reason)
    return true
end

local function clearNoPhysicsFallback(ent, objectData)
    objectData.noPhysicsFallback = false
    objectData.spawnWarning = nil

    if IsValid(ent) then
        ent.MapStudioNoPhysicsFallback = nil
        call(ent, "SetNWBool", "MapStudioNoPhysicsFallback", false)
    end
end

local function applyCollision(ent, objectData)
    if objectData.collision == false then
        clearNoPhysicsFallback(ent, objectData)
        call(ent, "SetNotSolid", true)
        call(ent, "SetSolid", SOLID_NONE)
        call(ent, "SetCollisionGroup", COLLISION_GROUP_WORLD)
        call(ent, "CollisionRulesChanged")

        return true
    end

    call(ent, "SetNotSolid", false)
    call(ent, "SetCollisionGroup", COLLISION_GROUP_NONE)
    call(ent, "SetMoveType", MOVETYPE_VPHYSICS)

    if ent.PhysicsInit then
        local ok, err = pcall(ent.PhysicsInit, ent, SOLID_VPHYSICS)

        if not ok then
            markNoPhysicsFallback(ent, objectData, err)
            return false
        end
    end

    local phys, physicsErr = getPhysicsObject(ent)
    if not IsValid(phys) then
        markNoPhysicsFallback(ent, objectData, physicsErr or "warning.no_physics_fallback")
        return false
    end

    call(ent, "SetSolid", SOLID_VPHYSICS)
    call(ent, "SetCollisionGroup", COLLISION_GROUP_NONE)
    call(ent, "CollisionRulesChanged")
    clearNoPhysicsFallback(ent, objectData)

    return true
end

local function applyPhysics(ent, objectData)
    local phys, physicsErr = getPhysicsObject(ent)
    if not IsValid(phys) then
        if objectData.collision == false then
            return true
        end

        markNoPhysicsFallback(ent, objectData, physicsErr or "warning.no_physics_fallback")
        return false
    end

    callPhysics(phys, "EnableGravity", objectData.gravity == true)

    local motionAllowed = objectData.motion == true and objectData.frozen ~= true and objectData.reactive ~= true

    callPhysics(phys, "EnableMotion", motionAllowed)

    if objectData.frozen == true then
        callPhysics(phys, "EnableMotion", false)
        motionAllowed = false
    end

    if motionAllowed then
        callPhysics(phys, "Wake")
    else
        callPhysics(phys, "Sleep")
    end

    return true
end

function spawner.ApplyProperties(ent, objectData)
    if not IsValid(ent) then
        return false
    end

    call(ent, "SetSkin", objectData.skin or 0)

    for group, value in pairs(objectData.bodygroups or {}) do
        call(ent, "SetBodygroup", tonumber(group) or 0, tonumber(value) or 0)
    end

    call(ent, "SetColor", MapStudio.Objects.ToColor(objectData.color))
    call(ent, "SetRenderMode", objectData.renderMode or RENDERMODE_TRANSALPHA)

    call(ent, "SetRenderFX", objectData.renderFx or 0)
    call(ent, "SetMaterial", objectData.material and objectData.material ~= "" and objectData.material or "")

    for index, material in pairs(objectData.submaterials or {}) do
        call(ent, "SetSubMaterial", tonumber(index) or 0, material or "")
    end

    call(ent, "SetModelScale", objectData.scale or 1, 0)

    applyCollision(ent, objectData)
    applyPhysics(ent, objectData)

    return true
end

function spawner.Spawn(objectData)
    local sanitized, cleanObject, err = pcall(MapStudio.Objects.SanitizeObject, objectData)
    if not sanitized or not cleanObject then
        local reason = sanitized and err or cleanObject
        addWarning("error.invalid_object", {
            id = type(objectData) == "table" and objectData.id or "",
            model = type(objectData) == "table" and objectData.model or "",
            class = type(objectData) == "table" and objectData.class or "",
            reason = tostring(reason)
        })
        MapStudio.LogWarning("Could not sanitize object for spawn: " .. tostring(reason))
        return nil, reason or "error.invalid_object"
    end

    local modelOK, modelExists = true, true

    if MapStudio.Objects.ModelExists then
        modelOK, modelExists = pcall(MapStudio.Objects.ModelExists, cleanObject.model)
    end

    if not modelOK or not modelExists then
        addWarning("error.invalid_model", { model = cleanObject.model, id = cleanObject.id })
        MapStudio.LogWarning("Could not spawn invalid model id=" .. tostring(cleanObject.id)
            .. " model=" .. tostring(cleanObject.model)
            .. " class=" .. tostring(cleanObject.class)
            .. (modelOK and "" or " reason=" .. tostring(modelExists)))
        return nil, "error.invalid_model"
    end

    local created, ent = pcall(ents.Create, cleanObject.class or MapStudio.Config.DefaultClass)
    if not created then
        addWarning("error.spawn_failed", { id = cleanObject.id, model = cleanObject.model, class = cleanObject.class, reason = tostring(ent) })
        MapStudio.LogWarning("Entity creation failed id=" .. tostring(cleanObject.id)
            .. " model=" .. tostring(cleanObject.model)
            .. " class=" .. tostring(cleanObject.class)
            .. " reason=" .. tostring(ent))
        return nil, "error.spawn_failed"
    end

    if not IsValid(ent) then
        addWarning("error.spawn_failed", { id = cleanObject.id, model = cleanObject.model, class = cleanObject.class })
        return nil, "error.spawn_failed"
    end

    local ok, spawnErr = pcall(function()
        ent:SetModel(cleanObject.model)
        ent:SetPos(MapStudio.Objects.ToVector(cleanObject.pos))
        ent:SetAngles(MapStudio.Objects.ToAngle(cleanObject.ang))
        ent:Spawn()
        ent:Activate()
    end)

    if not ok then
        addWarning("error.spawn_failed", { id = cleanObject.id, model = cleanObject.model, class = cleanObject.class, reason = tostring(spawnErr) })

        if SafeRemoveEntity then
            SafeRemoveEntity(ent)
        else
            ent:Remove()
        end

        return nil, "error.spawn_failed"
    end

    ent.MapStudioObject = true
    ent.MapStudioID = cleanObject.id
    ent.MapStudioObjectID = cleanObject.id
    ent.MapStudioBehavior = cleanObject.behavior
    ent.MapStudioReactive = cleanObject.reactive == true
    call(ent, "SetNWBool", "MapStudioObject", true)
    call(ent, "SetNWBool", "MapStudioReactive", cleanObject.reactive == true)
    call(ent, "SetNWBool", "MapStudioNoPhysicsFallback", cleanObject.noPhysicsFallback == true)
    call(ent, "SetNWString", "MapStudioID", cleanObject.id)
    call(ent, "SetNWString", "MapStudioObjectID", cleanObject.id)
    call(ent, "SetNWString", "MapStudioBehavior", cleanObject.behavior)

    call(ent, "SetPersistent", true)

    local propertiesOK, propertiesErr = pcall(spawner.ApplyProperties, ent, cleanObject)
    if not propertiesOK then
        MapStudio.LogWarning("Property application failed for id=" .. tostring(cleanObject.id)
            .. " model=" .. tostring(cleanObject.model)
            .. " class=" .. tostring(cleanObject.class)
            .. ": " .. tostring(propertiesErr))
        markNoPhysicsFallback(ent, cleanObject, propertiesErr)
    end

    if type(objectData) == "table" then
        objectData.noPhysicsFallback = cleanObject.noPhysicsFallback == true
        objectData.spawnWarning = cleanObject.spawnWarning
    end

    MapStudio.RuntimeEntities[cleanObject.id] = ent

    return ent
end

function spawner.Remove(id, reason)
    local ent = MapStudio.RuntimeEntities[id]
    MapStudio.RuntimeEntities[id] = nil

    if IsValid(ent) then
        ent.MapStudioInternalRemove = true
        ent.MapStudioInternalRemoveReason = reason or "mapstudio"

        if SafeRemoveEntity then
            SafeRemoveEntity(ent)
        else
            ent:Remove()
        end
    end
end

function spawner.Cleanup()
    for id in pairs(MapStudio.RuntimeEntities) do
        spawner.Remove(id, "cleanup")
    end
end

function spawner.ReloadAll(state)
    state = state or MapStudio.GetState()
    spawner.Cleanup()

    local report = { spawned = 0, failed = 0 }

    for id, objectData in pairs(state.objects or {}) do
        local ok, ent, err = pcall(spawner.Spawn, objectData)

        if ok and IsValid(ent) then
            report.spawned = report.spawned + 1
        else
            report.failed = report.failed + 1
            MapStudio.LogWarning("Failed to restore object id=" .. tostring(id)
                .. " model=" .. tostring(type(objectData) == "table" and objectData.model or "")
                .. " class=" .. tostring(type(objectData) == "table" and objectData.class or "")
                .. ": " .. tostring(ok and err or ent))
        end
    end

    return report
end

function spawner.Update(id, objectData)
    spawner.Remove(id, "update")
    return spawner.Spawn(objectData)
end

function spawner.FindEntity(id)
    local ent = MapStudio.RuntimeEntities[id]

    if IsValid(ent) then
        return ent
    end

    MapStudio.RuntimeEntities[id] = nil
    return nil
end

hook.Add("EntityRemoved", "MapStudio_RuntimeEntityCleanup", function(ent)
    if not ent or not (ent.MapStudioObjectID or ent.MapStudioID) then
        return
    end

    local id = ent.MapStudioObjectID or ent.MapStudioID

    if MapStudio.RuntimeEntities[id] == ent then
        MapStudio.RuntimeEntities[id] = nil
    end
end)
