MapStudio = MapStudio or {}
MapStudio.Storage = MapStudio.Storage or {}

local storage = MapStudio.Storage

local function safeSegment(value, fallback)
    value = tostring(value or fallback or "default")
    value = string.gsub(value, "[^%w_%-]", "_")

    if value == "" then
        value = fallback or "default"
    end

    return value
end

local function trim(value)
    value = tostring(value or "")

    if string.Trim then
        return string.Trim(value)
    end

    return string.gsub(value, "^%s*(.-)%s*$", "%1")
end

local function timestamp()
    return os.date("%Y%m%d_%H%M%S")
end

local function objectDetails(objectData, id)
    objectData = type(objectData) == "table" and objectData or {}

    local objectID = tostring(objectData.id or id or "")
    local ent = MapStudio.RuntimeEntities and MapStudio.RuntimeEntities[objectID] or nil
    local entityIndex = nil

    if IsValid(ent) and ent.EntIndex then
        local ok, value = pcall(ent.EntIndex, ent)
        entityIndex = ok and tonumber(value) or nil
    end

    return {
        id = objectID,
        model = tostring(objectData.model or ""),
        class = tostring(objectData.class or ""),
        entityIndex = entityIndex
    }
end

local function reportObjectIssue(report, key, objectData, id, reason, fallback)
    local details = objectDetails(objectData, id)

    if report then
        report.issues = report.issues or {}

        if fallback then
            report.fallback = (report.fallback or 0) + 1
        else
            report.skipped = (report.skipped or 0) + 1
        end

        table.insert(report.issues, {
            key = key or "error.invalid_object",
            id = details.id,
            model = details.model,
            class = details.class,
            entityIndex = details.entityIndex,
            reason = reason and tostring(reason) or nil
        })
    end

    if report and report.logIssues == true then
        local level = fallback and "Saved with no-physics fallback" or "Skipped invalid object while saving"
        MapStudio.LogWarning(level
            .. " id=" .. details.id
            .. " model=" .. details.model
            .. " class=" .. details.class
            .. (details.entityIndex and " entity=" .. tostring(details.entityIndex) or "")
            .. (reason and " reason=" .. tostring(reason) or ""))
    end
end

local function safeRead(path)
    local ok, content = pcall(file.Read, path, "DATA")

    if not ok then
        MapStudio.LogError("Storage read failed for " .. tostring(path) .. ": " .. tostring(content))
        return nil, content
    end

    return content
end

local function safeWrite(path, content)
    local ok, err = pcall(file.Write, path, content)

    if not ok then
        MapStudio.LogError("Storage write failed for " .. tostring(path) .. ": " .. tostring(err))
        return false, err
    end

    return true
end

local function safeDelete(path)
    local ok, err = pcall(file.Delete, path)

    if not ok then
        MapStudio.LogWarning("Storage cleanup failed for " .. tostring(path) .. ": " .. tostring(err))
        return false, err
    end

    return true
end

local function runtimeNoPhysics(objectData)
    if not objectData or not MapStudio.RuntimeEntities then
        return false
    end

    local ent = MapStudio.RuntimeEntities[objectData.id]

    if not IsValid(ent) then
        return objectData.noPhysicsFallback == true
    end

    if ent.MapStudioNoPhysicsFallback == true then
        return true
    end

    if objectData.collision == false then
        return false
    end

    local ok, phys = pcall(function()
        return ent.GetPhysicsObject and ent:GetPhysicsObject() or nil
    end)

    if not ok then
        local details = objectDetails(objectData, objectData.id)
        MapStudio.LogWarning("Could not inspect physics while saving id=" .. details.id
            .. " model=" .. details.model
            .. " class=" .. details.class
            .. ": " .. tostring(phys))
        return true
    end

    return not IsValid(phys)
end

function storage.SerializeObjectSafe(objectData, id, report)
    if type(objectData) ~= "table" then
        if report then
            report.skipped = report.skipped + 1
            table.insert(report.issues, { key = "error.invalid_object", id = tostring(id or "") })
        end

        return nil, "error.invalid_object"
    end

    local copied, source = pcall(MapStudio.DeepCopy, objectData)

    if not copied or type(source) ~= "table" then
        reportObjectIssue(report, "error.invalid_object", objectData, id, copied and "copy did not return a table" or source)
        return nil, "error.invalid_object"
    end

    source.id = source.id or id

    local ok, cleanOrErr, err = pcall(MapStudio.Objects.SanitizeObject, source)
    local clean = ok and cleanOrErr or nil

    if not clean then
        local reason = ok and (cleanOrErr or err) or tostring(cleanOrErr or "error.invalid_object")

        reportObjectIssue(report, reason or "error.invalid_object", source, id, reason)

        return nil, reason or "error.invalid_object"
    end

    clean.id = tostring(source.id or clean.id)
    clean.createdBy = source.createdBy and tostring(source.createdBy) or clean.createdBy
    clean.createdAt = tonumber(source.createdAt) or clean.createdAt
    clean.updatedBy = source.updatedBy and tostring(source.updatedBy) or clean.updatedBy
    clean.updatedAt = tonumber(source.updatedAt) or clean.updatedAt

    if runtimeNoPhysics(clean) then
        clean.noPhysicsFallback = true
        clean.spawnWarning = clean.spawnWarning or "warning.no_physics_fallback"

        reportObjectIssue(report, "warning.no_physics_fallback", clean, clean.id, clean.spawnWarning, true)
    end

    if report then
        report.saved = report.saved + 1
    end

    return clean
end

function storage.BuildSerializableState(state, mapName, profile, logIssues)
    state = type(state) == "table" and state or MapStudio.GetState()

    local report = {
        saved = 0,
        skipped = 0,
        fallback = 0,
        issues = {},
        logIssues = logIssues == true
    }

    local safe = {
        version = MapStudio.Version,
        map = tostring(mapName or state.map or MapStudio.GetMapName()),
        profile = storage.SafeProfileName(profile or state.profile or MapStudio.Config.DefaultProfile),
        updatedAt = os.time(),
        layers = {},
        objects = {},
        warnings = {},
        dirty = false
    }

    local warningsOK, warnings = pcall(MapStudio.Objects.SanitizeSerializable, state.warnings)
    if warningsOK and type(warnings) == "table" then
        safe.warnings = warnings
    elseif state.warnings ~= nil and report.logIssues == true then
        MapStudio.LogWarning("Skipped malformed MapStudio warnings while building save state: " .. tostring(warnings))
    end

    local defaultLayer = MapStudio.GetDefaultLayer()
    safe.layers[defaultLayer.id] = defaultLayer

    for id, layer in pairs(type(state.layers) == "table" and state.layers or {}) do
        local ok, cleanLayer = pcall(MapStudio.Objects.SanitizeLayer, layer)

        if ok and type(cleanLayer) == "table" then
            safe.layers[cleanLayer.id or id] = cleanLayer
        elseif report.logIssues == true then
            MapStudio.LogWarning("Skipped malformed layer while saving id=" .. tostring(id) .. ": " .. tostring(cleanLayer))
        end
    end

    for id, objectData in pairs(type(state.objects) == "table" and state.objects or {}) do
        local cleanObject = storage.SerializeObjectSafe(objectData, id, report)

        if cleanObject then
            if not safe.layers[cleanObject.layer] then
                cleanObject.layer = defaultLayer.id
            end

            safe.objects[cleanObject.id] = cleanObject
        end
    end

    return safe, report
end

function storage.ValidateState(state)
    state = type(state) == "table" and state or MapStudio.GetState()

    local safe, report = storage.BuildSerializableState(state, nil, nil, true)
    report.total = 0
    report.invalidModels = 0

    for id, objectData in pairs(state.objects or {}) do
        report.total = report.total + 1

        local model = objectData and objectData.model
        local modelOK, modelExists = true, true

        if model and MapStudio.Objects.ModelExists then
            modelOK, modelExists = pcall(MapStudio.Objects.ModelExists, model)
        end

        if model and (not modelOK or not modelExists) then
            report.invalidModels = report.invalidModels + 1
            table.insert(report.issues, {
                key = "error.invalid_model",
                id = tostring(id),
                model = tostring(model),
                class = tostring(objectData.class or ""),
                reason = modelOK and nil or tostring(modelExists)
            })
        end
    end

    report.valid = math.max(0, report.saved - report.invalidModels)
    report.canSave = true
    report.serializableState = safe

    return report
end

function storage.SafeMapName(mapName)
    return safeSegment(mapName or MapStudio.GetMapName(), "unknown")
end

function storage.SafeProfileName(profile)
    return MapStudio.Objects.SanitizeProfileName(profile)
end

function storage.SafeLayoutID(displayName)
    local raw = string.lower(string.sub(trim(displayName), 1, 64))
    local name = string.gsub(raw, "[^%w_%-]", "_")

    if name == "" or string.match(name, "^_+$") then
        name = "layout"
    end

    local hash = util and util.CRC and util.CRC(raw) or tostring(string.len(raw))
    return string.sub(name, 1, 48) .. "_" .. tostring(hash)
end

function storage.EnsureBaseDirs(mapName)
    local root = MapStudio.Config.StorageRoot
    local map = storage.SafeMapName(mapName)
    local directories = {
        root,
        root .. "/maps",
        root .. "/maps/" .. map,
        root .. "/backups",
        root .. "/backups/" .. map,
        root .. "/imports",
        root .. "/exports",
        root .. "/layouts",
        root .. "/layouts/" .. map
    }

    for _, path in ipairs(directories) do
        local ok, err = pcall(file.CreateDir, path)

        if not ok then
            MapStudio.LogError("Storage directory creation failed for " .. tostring(path) .. ": " .. tostring(err))
            return false, err
        end
    end

    return true
end

function storage.ProfilePath(mapName, profile)
    return MapStudio.Config.StorageRoot .. "/maps/" .. storage.SafeMapName(mapName) .. "/" .. storage.SafeProfileName(profile) .. ".json"
end

function storage.LayoutDir(mapName)
    return MapStudio.Config.StorageRoot .. "/layouts/" .. storage.SafeMapName(mapName)
end

function storage.LayoutPath(mapName, layoutID)
    return storage.LayoutDir(mapName) .. "/" .. storage.SafeLayoutID(layoutID) .. ".json"
end

function storage.BackupPath(mapName, profile, suffix)
    local safeProfile = storage.SafeProfileName(profile)
    local name = timestamp() .. "_" .. safeProfile

    if suffix then
        name = name .. "_" .. suffix
    end

    return MapStudio.Config.StorageRoot .. "/backups/" .. storage.SafeMapName(mapName) .. "/" .. name .. ".json"
end

function storage.NormalizeState(data, mapName, profile)
    local state = MapStudio.CreateEmptyState(mapName, profile)

    if type(data) ~= "table" then
        return state
    end

    state.version = tostring(data.version or MapStudio.Version)
    state.map = tostring(data.map or mapName or MapStudio.GetMapName())
    state.profile = storage.SafeProfileName(data.profile or profile)
    state.updatedAt = tonumber(data.updatedAt) or os.time()
    state.layers = {}
    state.objects = {}
    state.warnings = type(data.warnings) == "table" and data.warnings or {}

    local defaultLayer = MapStudio.GetDefaultLayer()
    state.layers[defaultLayer.id] = defaultLayer

    if type(data.layers) == "table" then
        for id, layer in pairs(data.layers) do
            if type(layer) == "table" then
                local ok, cleanLayer = pcall(function()
                    local source = MapStudio.DeepCopy(layer)
                    source.id = source.id or id
                    return MapStudio.Objects.SanitizeLayer(source)
                end)

                if ok and type(cleanLayer) == "table" then
                    state.layers[cleanLayer.id] = cleanLayer
                else
                    MapStudio.LogWarning("Skipped malformed saved layer id=" .. tostring(id) .. ": " .. tostring(cleanLayer))
                end
            end
        end
    end

    if type(data.objects) == "table" then
        for id, objectData in pairs(data.objects) do
            if type(objectData) == "table" then
                local ok, cleanObject, err = pcall(function()
                    local source = MapStudio.DeepCopy(objectData)
                    source.id = source.id or id
                    return MapStudio.Objects.SanitizeObject(source)
                end)

                if ok and cleanObject then
                    if not state.layers[cleanObject.layer] then
                        cleanObject.layer = defaultLayer.id
                    end

                    state.objects[cleanObject.id] = cleanObject
                else
                    local reason = ok and err or cleanObject
                    local details = objectDetails(objectData, id)
                    table.insert(state.warnings, {
                        key = reason or "error.invalid_object",
                        id = tostring(id),
                        model = details.model,
                        class = details.class,
                        reason = reason and tostring(reason) or nil
                    })
                    MapStudio.LogWarning("Skipped malformed saved object id=" .. details.id
                        .. " model=" .. details.model
                        .. " class=" .. details.class
                        .. ": " .. tostring(reason))
                end
            end
        end
    end

    return state
end

function storage.BackupProfile(mapName, profile, suffix)
    local ensured = storage.EnsureBaseDirs(mapName)
    if not ensured then
        return nil
    end

    local path = storage.ProfilePath(mapName, profile)
    if not file.Exists(path, "DATA") then
        return nil
    end

    local content = safeRead(path)
    if not content then
        return nil
    end

    local backupPath = storage.BackupPath(mapName, profile, suffix)
    if not safeWrite(backupPath, content) then
        return nil
    end

    return backupPath
end

function storage.LoadProfile(mapName, profile)
    mapName = mapName or MapStudio.GetMapName()
    profile = storage.SafeProfileName(profile)
    local ensured = storage.EnsureBaseDirs(mapName)
    if not ensured then
        return MapStudio.CreateEmptyState(mapName, profile), "error.storage_load_failed"
    end

    local path = storage.ProfilePath(mapName, profile)
    if not file.Exists(path, "DATA") then
        return MapStudio.CreateEmptyState(mapName, profile)
    end

    local content, readErr = safeRead(path)
    if not content or content == "" then
        return MapStudio.CreateEmptyState(mapName, profile), readErr and "error.storage_load_failed" or nil
    end

    local ok, data = pcall(util.JSONToTable, content)
    if not ok or type(data) ~= "table" then
        storage.BackupProfile(mapName, profile, "corrupted")

        local state = MapStudio.CreateEmptyState(mapName, profile)
        table.insert(state.warnings, { key = "error.storage_corrupted" })

        return state, "error.storage_corrupted"
    end

    local normalized, stateOrErr = pcall(storage.NormalizeState, data, mapName, profile)
    if not normalized or type(stateOrErr) ~= "table" then
        MapStudio.LogError("Profile normalization failed for " .. tostring(path) .. ": " .. tostring(stateOrErr))
        local state = MapStudio.CreateEmptyState(mapName, profile)
        table.insert(state.warnings, { key = "error.storage_corrupted" })
        return state, "error.storage_corrupted"
    end

    return stateOrErr
end

function storage.SaveProfile(state, mapName, profile)
    state = type(state) == "table" and state or MapStudio.GetState()
    mapName = mapName or state.map or MapStudio.GetMapName()
    profile = storage.SafeProfileName(profile or state.profile)

    local ensured = storage.EnsureBaseDirs(mapName)
    if not ensured then
        return false, "error.storage_save_failed", { saved = 0, skipped = 0, fallback = 0, issues = {} }
    end

    storage.BackupProfile(mapName, profile)

    local built, safeState, report = pcall(storage.BuildSerializableState, state, mapName, profile, true)
    if not built or type(safeState) ~= "table" then
        MapStudio.LogError("Profile save state build failed for map=" .. tostring(mapName)
            .. " profile=" .. tostring(profile) .. ": " .. tostring(safeState))
        return false, "error.storage_save_failed", report or { saved = 0, skipped = 0, fallback = 0, issues = {} }
    end

    local ok, json = pcall(util.TableToJSON, safeState, true)
    if not ok or type(json) ~= "string" then
        MapStudio.LogError("Profile save serialization failed for map=" .. tostring(mapName) .. " profile=" .. tostring(profile) .. ": " .. tostring(json))
        return false, "error.storage_save_failed", report
    end

    local path = storage.ProfilePath(mapName, profile)
    local tempPath = path .. ".tmp"

    local wroteTemp = safeWrite(tempPath, json)
    if not wroteTemp then
        return false, "error.storage_save_failed", report
    end

    local verified = safeRead(tempPath)
    if verified ~= json then
        MapStudio.LogError("Profile save verification failed for " .. tostring(path))
        safeDelete(tempPath)
        return false, "error.storage_save_failed", report
    end

    local wroteProfile = safeWrite(path, json)
    if not wroteProfile then
        safeDelete(tempPath)
        return false, "error.storage_save_failed", report
    end

    safeDelete(tempPath)

    state.version = MapStudio.Version
    state.map = mapName
    state.profile = profile
    state.updatedAt = safeState.updatedAt
    state.dirty = false

    if report.skipped > 0 or report.fallback > 0 then
        MapStudio.LogWarning("Profile saved with warnings: saved=" .. tostring(report.saved)
            .. ", fallback=" .. tostring(report.fallback)
            .. ", skipped=" .. tostring(report.skipped))
    else
        MapStudio.Debug("Profile saved: saved=" .. tostring(report.saved))
    end

    return true, nil, report
end

function storage.ListProfiles(mapName)
    mapName = mapName or MapStudio.GetMapName()
    storage.EnsureBaseDirs(mapName)

    local root = MapStudio.Config.StorageRoot .. "/maps/" .. storage.SafeMapName(mapName)
    local files = file.Find(root .. "/*.json", "DATA")
    local profiles = {}

    for _, name in ipairs(files or {}) do
        table.insert(profiles, string.gsub(name, "%.json$", ""))
    end

    table.sort(profiles)

    if #profiles == 0 then
        table.insert(profiles, MapStudio.Config.DefaultProfile)
    end

    return profiles
end

local function layoutDisplayName(value)
    value = trim(value)

    if value == "" then
        return nil
    end

    return string.sub(value, 1, 64)
end

local function snapshotObjects(state)
    local result = {}
    local report = { saved = 0, skipped = 0, fallback = 0, issues = {} }
    state = type(state) == "table" and state or MapStudio.GetState()

    for _, objectData in pairs(state.objects or {}) do
        local clean = storage.SerializeObjectSafe(objectData, objectData and objectData.id, report)

        if clean then
            table.insert(result, clean)
        end
    end

    table.sort(result, function(a, b)
        return tostring(a.id or "") < tostring(b.id or "")
    end)

    return result
end

function storage.SaveLayout(state, mapName, displayName, overwrite)
    mapName = mapName or MapStudio.GetMapName()
    storage.EnsureBaseDirs(mapName)

    displayName = layoutDisplayName(displayName)
    if not displayName then
        return false, "layout.invalid_name"
    end

    local id = storage.SafeLayoutID(displayName)
    local path = storage.LayoutPath(mapName, id)

    if file.Exists(path, "DATA") and overwrite ~= true then
        return false, "layout.exists", { id = id, displayName = displayName }
    end

    local objects = snapshotObjects(state)
    local payload = {
        format = 1,
        version = MapStudio.Version,
        id = id,
        displayName = displayName,
        map = mapName,
        savedAt = os.time(),
        objectCount = #objects,
        objects = objects
    }

    local ok, json = pcall(util.TableToJSON, payload, true)
    if not ok or type(json) ~= "string" then
        return false, "error.storage_save_failed"
    end

    file.Write(path, json)

    return true, nil, payload
end

function storage.LoadLayout(mapName, layoutID)
    mapName = mapName or MapStudio.GetMapName()
    storage.EnsureBaseDirs(mapName)

    local path = storage.LayoutPath(mapName, layoutID)
    if not file.Exists(path, "DATA") then
        return nil, "layout.not_found"
    end

    local content = file.Read(path, "DATA")
    local ok, data = pcall(util.JSONToTable, content or "")

    if not ok or type(data) ~= "table" or tostring(data.map or "") ~= tostring(mapName) then
        return nil, "error.storage_load_failed"
    end

    data.objects = type(data.objects) == "table" and data.objects or {}
    return data
end

function storage.DeleteLayout(mapName, layoutID)
    mapName = mapName or MapStudio.GetMapName()
    storage.EnsureBaseDirs(mapName)

    local path = storage.LayoutPath(mapName, layoutID)
    if not file.Exists(path, "DATA") then
        return false, "layout.not_found"
    end

    file.Delete(path)
    return true
end

function storage.ListLayouts(mapName)
    mapName = mapName or MapStudio.GetMapName()
    storage.EnsureBaseDirs(mapName)

    local files = file.Find(storage.LayoutDir(mapName) .. "/*.json", "DATA")
    local layouts = {}

    for _, name in ipairs(files or {}) do
        local path = storage.LayoutDir(mapName) .. "/" .. name
        local content = file.Read(path, "DATA")
        local ok, data = pcall(util.JSONToTable, content or "")

        if ok and type(data) == "table" and tostring(data.map or "") == tostring(mapName) then
            table.insert(layouts, {
                id = tostring(data.id or string.gsub(name, "%.json$", "")),
                displayName = tostring(data.displayName or data.name or string.gsub(name, "%.json$", "")),
                map = tostring(data.map or mapName),
                savedAt = tonumber(data.savedAt) or 0,
                objectCount = tonumber(data.objectCount) or (type(data.objects) == "table" and #data.objects or 0)
            })
        end
    end

    table.sort(layouts, function(a, b)
        return (a.savedAt or 0) > (b.savedAt or 0)
    end)

    return layouts
end

function storage.ExportProfile(state)
    state = state or MapStudio.GetState()
    storage.EnsureBaseDirs(state.map)

    local safeState = storage.BuildSerializableState(state)
    local ok, json = pcall(util.TableToJSON, safeState, true)
    if not ok then
        return false, "error.storage_save_failed"
    end

    local fileName = storage.SafeMapName(state.map) .. "_" .. storage.SafeProfileName(state.profile) .. "_" .. timestamp() .. ".json"
    local path = MapStudio.Config.StorageRoot .. "/exports/" .. fileName

    file.Write(path, json)

    return true, path
end
