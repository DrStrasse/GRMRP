MapStudio = MapStudio or {}
MapStudio.RateLimit = MapStudio.RateLimit or {}

local allowPlayersConVar = CreateConVar(MapStudio.Config.PermissionAllowPlayersConVar or "mapstudio_allow_players", "0", FCVAR_ARCHIVE + FCVAR_REPLICATED, "Allow non-admin players to use MapStudio with ownership restrictions")
local whitelistConVar = CreateConVar(MapStudio.Config.PermissionWhitelistConVar or "mapstudio_allowed_steamids", "", FCVAR_ARCHIVE, "Comma or space separated SteamID/SteamID64 values allowed to use MapStudio")
local publicEditConVar = CreateConVar(MapStudio.Config.PermissionPublicEditConVar or "mapstudio_public_edit_existing", "0", FCVAR_ARCHIVE, "Allow non-admin MapStudio users to edit objects created by other players")
local adminOnlyConVar = CreateConVar("mapstudio_admin_only", "1", FCVAR_ARCHIVE + FCVAR_REPLICATED, "Require admin access unless a player is explicitly whitelisted")
local whitelistEnabledConVar = CreateConVar("mapstudio_whitelist_enabled", "0", FCVAR_ARCHIVE + FCVAR_REPLICATED, "Allow SteamIDs listed in mapstudio_allowed_steamids to use MapStudio")
CreateConVar(MapStudio.Config.DebugConVar or "mapstudio_debug", "0", FCVAR_ARCHIVE + FCVAR_REPLICATED, "Enable extra MapStudio debug logging")

local function playerKey(ply)
    if not IsValid(ply) then
        return "console"
    end

    if ply.SteamID64 then
        return ply:SteamID64()
    end

    return tostring(ply:EntIndex())
end

local function playerIDs(ply)
    if not IsValid(ply) then
        return {}
    end

    return {
        ply.SteamID64 and tostring(ply:SteamID64()) or "",
        ply.SteamID and tostring(ply:SteamID()) or ""
    }
end

function MapStudio.IsSteamIDWhitelisted(ply)
    local raw = whitelistConVar and whitelistConVar:GetString() or ""

    if raw == "" or not IsValid(ply) or not MapStudio.WhitelistEnabled() then
        return false
    end

    local ids = playerIDs(ply)

    for token in string.gmatch(raw, "[^,%s;]+") do
        token = string.Trim and string.Trim(token) or string.gsub(token, "^%s*(.-)%s*$", "%1")

        for _, id in ipairs(ids) do
            if id ~= "" and token == id then
                return true
            end
        end
    end

    return false
end

function MapStudio.PublicPlayersAllowed()
    return allowPlayersConVar and allowPlayersConVar:GetBool() or false
end

function MapStudio.AdminsOnly()
    if not adminOnlyConVar then
        return true
    end

    return adminOnlyConVar:GetBool()
end

function MapStudio.WhitelistEnabled()
    return whitelistEnabledConVar and whitelistEnabledConVar:GetBool() or false
end

function MapStudio.PublicEditExistingAllowed()
    return publicEditConVar and publicEditConVar:GetBool() or false
end

function MapStudio.ServerCanUse(ply, action, silent)
    if not IsValid(ply) then
        return true
    end

    if game and game.SinglePlayer and game.SinglePlayer() then
        return true
    end

    if MapStudio.IsPrivilegedUser(ply) then
        return true
    end

    if MapStudio.IsSteamIDWhitelisted(ply) then
        return true
    end

    if MapStudio.PublicPlayersAllowed() and not MapStudio.AdminsOnly() then
        return true
    end

    if not silent and MapStudio.Notify then
        MapStudio.Notify(ply, "notify.no_permission", "error")
    end

    return false
end

function MapStudio.ServerCanEditObject(ply, objectData, action, silent)
    if not IsValid(ply) then
        return true
    end

    if not MapStudio.ServerCanUse(ply, action or "update", silent) then
        return false
    end

    if MapStudio.IsPrivilegedUser(ply) or MapStudio.PublicEditExistingAllowed() then
        return true
    end

    local owner = objectData and tostring(objectData.createdBy or "")

    if owner ~= "" then
        for _, requester in ipairs(playerIDs(ply)) do
            if requester ~= "" and owner == requester then
                return true
            end
        end
    end

    if not silent and MapStudio.Notify then
        MapStudio.Notify(ply, "notify.no_permission_object", "error")
    end

    return false
end

function MapStudio.ServerCanManageScene(ply, action, silent)
    if not IsValid(ply) then
        return true
    end

    if not MapStudio.ServerCanUse(ply, action or "manage", silent) then
        return false
    end

    if MapStudio.IsPrivilegedUser(ply) then
        return true
    end

    if not silent and MapStudio.Notify then
        MapStudio.Notify(ply, "notify.no_permission", "error")
    end

    return false
end

function MapStudio.CheckRateLimit(ply, action, silent)
    if not IsValid(ply) then
        return true
    end

    local rateLimits = MapStudio.Config.RateLimits or {}
    local interval = tonumber(rateLimits[action]) or 0.2
    interval = math.max(0.05, math.min(interval, 30))
    local key = playerKey(ply) .. ":" .. tostring(action)
    local now = CurTime()

    if MapStudio.RateLimit[key] and MapStudio.RateLimit[key] > now then
        if not silent and MapStudio.Notify then
            MapStudio.Notify(ply, "error.rate_limited", "error")
        end

        return false
    end

    MapStudio.RateLimit[key] = now + interval
    return true
end
