MapStudio = MapStudio or {}
MapStudio.Protection = MapStudio.Protection or {}

local protection = MapStudio.Protection

local VISUAL_SYNC_DELAY = 0.15
local TRANSFORM_GUARD_INTERVAL = 0.05
local TRANSFORM_GUARD_REPEATS = 8
local TRANSFORM_GUARD_PERIOD = 1
local EXTERNAL_INTERACTION_WINDOW = 2
local POSITION_EPSILON_SQR = 0.01
local ANGLE_EPSILON = 0.05
local NPC_CREATOR_TOOL = "creator"
local NPC_CREATOR_TYPE = 2

local DELETION_TOOLS = {
    remover = true
}

local DELETION_PROPERTIES = {
    delete = true,
    remove = true,
    remover = true
}

local function isDeletionName(name, explicit)
    name = string.lower(tostring(name or ""))

    return explicit[name] == true
        or string.find(name, "remov", 1, true) ~= nil
        or string.find(name, "delete", 1, true) ~= nil
end

local function now()
    return CurTime and CurTime() or os.time()
end

local function objectID(ent)
    if not IsValid(ent) then
        return nil
    end

    local id = ent.MapStudioObjectID or ent.MapStudioID

    if (id == nil or id == "") and ent.GetNWString then
        id = ent:GetNWString("MapStudioObjectID", "")

        if id == "" then
            id = ent:GetNWString("MapStudioID", "")
        end
    end

    id = tostring(id or "")

    if id == "" then
        return nil
    end

    return id
end

local function managedObject(ent)
    if not IsValid(ent) then
        return nil, nil
    end

    local id = objectID(ent)

    if not id then
        return nil, nil
    end

    if not MapStudio.RuntimeEntities or MapStudio.RuntimeEntities[id] ~= ent then
        return nil, nil
    end

    local state = MapStudio.GetState and MapStudio.GetState()
    local objectData = state and state.objects and state.objects[id]

    if not objectData then
        return nil, nil
    end

    return id, objectData
end

function protection.GetObjectID(ent)
    return objectID(ent)
end

function protection.GetManagedObject(ent)
    return managedObject(ent)
end

function protection.IsMapStudioEntity(ent)
    return managedObject(ent) ~= nil
end

local function refreeze(ent)
    if not IsValid(ent) then
        return
    end

    local gotPhysics, phys = pcall(ent.GetPhysicsObject, ent)

    if gotPhysics and IsValid(phys) then
        pcall(phys.EnableMotion, phys, false)
        pcall(phys.Sleep, phys)
    end
end

local function canSyncVisuals(ply, ent)
    local _, objectData = managedObject(ent)

    return objectData ~= nil
        and MapStudio.ServerCanEditObject
        and MapStudio.ServerCanEditObject(ply, objectData, "update", true)
end

local function isNPCPlacementTool(ply, toolName, toolObject, button)
    if toolName ~= NPC_CREATOR_TOOL then
        return false
    end

    if button ~= nil and button ~= 1 then
        return false
    end

    if not IsValid(ply) then
        return false
    end

    local creatorType = toolObject and toolObject.GetClientNumber and toolObject:GetClientNumber("type", 0)
        or ply.GetInfoNum and ply:GetInfoNum("creator_type", 0)
        or 0

    if creatorType ~= NPC_CREATOR_TYPE then
        return false
    end

    local npcName = toolObject and toolObject.GetClientInfo and toolObject:GetClientInfo("name")
        or ply.GetInfo and ply:GetInfo("creator_name")
        or ""

    if npcName == "" then
        return false
    end

    if list and list.GetEntry then
        return list.GetEntry("NPC", npcName) ~= nil
    end

    return false
end

local function captureBodygroups(ent)
    local result = {}

    if not IsValid(ent) or not ent.GetNumBodyGroups or not ent.GetBodygroup then
        return result
    end

    local count = math.max(0, tonumber(ent:GetNumBodyGroups()) or 0)

    for index = 0, count - 1 do
        result[index] = tonumber(ent:GetBodygroup(index)) or 0
    end

    return result
end

local function captureSubmaterials(ent, existing)
    local result = {}

    if not IsValid(ent) or not ent.GetSubMaterial then
        return result
    end

    local materials = ent.GetMaterials and ent:GetMaterials() or {}
    local count = math.min(#materials, MapStudio.Config.MaxSubMaterials or 64)

    for index = 0, count - 1 do
        local material = ent:GetSubMaterial(index) or ""

        if material ~= "" then
            result[index] = material
        end
    end

    for index in pairs(existing and existing.submaterials or {}) do
        index = tonumber(index)

        if index and result[index] == nil then
            result[index] = ""
        end
    end

    return result
end

local function captureVisualState(ent, existing)
    local color = ent.GetColor and ent:GetColor() or Color(255, 255, 255, 255)

    return {
        skin = ent.GetSkin and ent:GetSkin() or 0,
        bodygroups = captureBodygroups(ent),
        color = { r = color.r or 255, g = color.g or 255, b = color.b or 255, a = color.a or 255 },
        material = ent.GetMaterial and ent:GetMaterial() or "",
        submaterials = captureSubmaterials(ent, existing),
        renderMode = ent.GetRenderMode and ent:GetRenderMode() or (existing and existing.renderMode) or RENDERMODE_TRANSALPHA,
        renderFx = ent.GetRenderFX and ent:GetRenderFX() or (existing and existing.renderFx) or 0
    }
end

local function tablesEqual(left, right)
    left = type(left) == "table" and left or {}
    right = type(right) == "table" and right or {}

    for key, value in pairs(left) do
        if type(value) == "table" then
            if not tablesEqual(value, right[key]) then
                return false
            end
        elseif value ~= right[key] then
            return false
        end
    end

    for key in pairs(right) do
        if left[key] == nil then
            return false
        end
    end

    return true
end

local function angleDifference(left, right)
    local diff = math.abs(((tonumber(left) or 0) - (tonumber(right) or 0) + 180) % 360 - 180)
    return diff
end

local function transformDiffers(ent, targetPos, targetAng)
    local gotPos, currentPos = pcall(ent.GetPos, ent)
    if not gotPos or not isvector(currentPos) then
        return false
    end

    if currentPos:DistToSqr(targetPos) > POSITION_EPSILON_SQR then
        return true
    end

    local gotAng, currentAng = pcall(ent.GetAngles, ent)
    if not gotAng or not isangle(currentAng) then
        return false
    end

    return angleDifference(currentAng.p, targetAng.p) > ANGLE_EPSILON
        or angleDifference(currentAng.y, targetAng.y) > ANGLE_EPSILON
        or angleDifference(currentAng.r, targetAng.r) > ANGLE_EPSILON
end

function protection.RestoreTransform(ent)
    local _, objectData = managedObject(ent)

    if not objectData then
        return false
    end

    local targetPos = MapStudio.Objects.ToVector(objectData.pos)
    local targetAng = MapStudio.Objects.ToAngle(objectData.ang)
    local restored = false

    if transformDiffers(ent, targetPos, targetAng) then
        local setPos = pcall(ent.SetPos, ent, targetPos)
        local setAng = pcall(ent.SetAngles, ent, targetAng)
        restored = setPos and setAng
    end

    refreeze(ent)
    return restored
end

local function scheduleTransformRestore(ent)
    local id = objectID(ent)

    if not id then
        return
    end

    local timerName = "MapStudio_TransformGuard_" .. id
    timer.Remove(timerName)
    timer.Create(timerName, TRANSFORM_GUARD_INTERVAL, TRANSFORM_GUARD_REPEATS, function()
        if IsValid(ent) then
            protection.RestoreTransform(ent)
        end
    end)
end

local function markExternalInteraction(ent, ply, source)
    if not protection.IsMapStudioEntity(ent) then
        return
    end

    local interaction = {
        source = tostring(source or ""),
        player = IsValid(ply) and ply or nil,
        expires = now() + EXTERNAL_INTERACTION_WINDOW
    }

    ent.MapStudioLastExternalInteraction = interaction
end

local function clearCopiedMapStudioTags(ent)
    if not IsValid(ent) then
        return
    end

    ent.MapStudioObject = nil
    ent.MapStudioID = nil
    ent.MapStudioObjectID = nil
    ent.MapStudioBehavior = nil
    ent.MapStudioReactive = nil

    if ent.SetNWBool then
        ent:SetNWBool("MapStudioObject", false)
        ent:SetNWBool("MapStudioReactive", false)
    end

    if ent.SetNWString then
        ent:SetNWString("MapStudioID", "")
        ent:SetNWString("MapStudioObjectID", "")
        ent:SetNWString("MapStudioBehavior", "")
    end
end

function protection.SyncEntityVisuals(ent, ply)
    local id, existing = managedObject(ent)

    if not id or not existing then
        return false
    end

    if not canSyncVisuals(ply, ent) then
        protection.RestoreTransform(ent)
        return false
    end

    local state = MapStudio.GetState()
    local captured, patch = pcall(captureVisualState, ent, existing)
    if not captured or type(patch) ~= "table" then
        MapStudio.LogWarning("Could not capture external visual change for MapStudio object id=" .. tostring(id) .. ": " .. tostring(patch))
        protection.RestoreTransform(ent)
        return false
    end

    local sanitized, updated, err = pcall(MapStudio.Objects.SanitizeObject, patch, existing)
    if not sanitized then
        MapStudio.LogWarning("Could not sanitize external visual change for MapStudio object id=" .. tostring(id) .. ": " .. tostring(updated))
        protection.RestoreTransform(ent)
        return false
    end

    if not updated then
        MapStudio.Log(MapStudio.Lang.Get(err or "error.invalid_object"))
        return false
    end

    if existing.skin == updated.skin
        and existing.material == updated.material
        and existing.renderMode == updated.renderMode
        and existing.renderFx == updated.renderFx
        and tablesEqual(existing.color, updated.color)
        and tablesEqual(existing.bodygroups, updated.bodygroups)
        and tablesEqual(existing.submaterials, updated.submaterials) then
        protection.RestoreTransform(ent)
        return false
    end

    if IsValid(ply) and MapStudio.CheckRateLimit and not MapStudio.CheckRateLimit(ply, "external_visual", true) then
        protection.RestoreTransform(ent)
        return false
    end

    updated.id = id
    updated.createdBy = existing.createdBy
    updated.createdAt = existing.createdAt
    updated.updatedBy = IsValid(ply) and ply:SteamID64() or existing.updatedBy
    updated.updatedAt = os.time()
    state.objects[id] = updated

    if MapStudio.Spawner and MapStudio.Spawner.ApplyProperties then
        MapStudio.Spawner.ApplyProperties(ent, updated)
    end

    protection.RestoreTransform(ent)

    if MapStudio.MarkDirty then
        MapStudio.MarkDirty()
    end

    if MapStudio.BroadcastState then
        MapStudio.BroadcastState()
    end

    return true
end

local function scheduleVisualSync(ent, ply)
    if not canSyncVisuals(ply, ent) then
        return
    end

    local id = objectID(ent)

    if not id then
        return
    end

    timer.Remove("MapStudio_VisualSync_" .. id)
    timer.Create("MapStudio_VisualSync_" .. id, VISUAL_SYNC_DELAY, 4, function()
        if IsValid(ent) then
            protection.SyncEntityVisuals(ent, ply)
        end
    end)
end

local function objectBehavior(ent)
    if not IsValid(ent) then
        return "static"
    end

    if ent.MapStudioReactive == true or (ent.GetNWBool and ent:GetNWBool("MapStudioReactive", false)) then
        return "reactive"
    end

    local behavior = ent.MapStudioBehavior

    if behavior == nil and ent.GetNWString then
        behavior = ent:GetNWString("MapStudioBehavior", "")
    end

    if behavior == nil or behavior == "" then
        local id = ent.MapStudioObjectID or ent.MapStudioID

        if (id == nil or id == "") and ent.GetNWString then
            id = ent:GetNWString("MapStudioObjectID", "")
            if id == "" then
                id = ent:GetNWString("MapStudioID", "")
            end
        end

        local objectData = id and MapStudio.GetState().objects and MapStudio.GetState().objects[id]
        behavior = objectData and objectData.behavior
    end

    return MapStudio.Objects.SanitizeBehavior(behavior)
end

hook.Add("PhysgunPickup", "MapStudio_BlockPhysgunPickup", function(ply, ent)
    if protection.IsMapStudioEntity(ent) then
        protection.RestoreTransform(ent)
        return false
    end
end)

hook.Add("GravGunPickupAllowed", "MapStudio_BlockGravityGunPickup", function(ply, ent)
    if protection.IsMapStudioEntity(ent) then
        protection.RestoreTransform(ent)
        return false
    end
end)

hook.Add("GravGunPunt", "MapStudio_BlockGravityGunPunt", function(ply, ent)
    if protection.IsMapStudioEntity(ent) then
        protection.RestoreTransform(ent)
        return false
    end
end)

hook.Add("CanTool", "MapStudio_AllowExternalTools", function(ply, trace, tool, toolObject, button)
    local ent = trace and trace.Entity

    if protection.IsMapStudioEntity(ent) then
        local toolName = string.lower(tostring(tool or ""))
        local destructive = isDeletionName(toolName, DELETION_TOOLS)

        if destructive then
            protection.RestoreTransform(ent)
            return false
        end

        if isNPCPlacementTool(ply, toolName, toolObject, button) then
            protection.RestoreTransform(ent)
            return
        end

        local _, objectData = managedObject(ent)
        if not MapStudio.ServerCanEditObject(ply, objectData, "update") then
            protection.RestoreTransform(ent)
            return false
        end

        markExternalInteraction(ent, ply, "tool:" .. toolName)
        scheduleTransformRestore(ent)
        scheduleVisualSync(ent, ply)
    end
end)

hook.Add("CanProperty", "MapStudio_AllowContextProperties", function(ply, property, ent)
    if protection.IsMapStudioEntity(ent) then
        local propertyName = string.lower(tostring(property or ""))
        local destructive = isDeletionName(propertyName, DELETION_PROPERTIES)

        if destructive then
            protection.RestoreTransform(ent)
            return false
        end

        local _, objectData = managedObject(ent)
        if not MapStudio.ServerCanEditObject(ply, objectData, "update") then
            protection.RestoreTransform(ent)
            return false
        end

        markExternalInteraction(ent, ply, "property:" .. propertyName)
        scheduleTransformRestore(ent)
        scheduleVisualSync(ent, ply)
    end
end)

hook.Add("AllowPlayerPickup", "MapStudio_BlockUsePickup", function(ply, ent)
    if protection.IsMapStudioEntity(ent) then
        protection.RestoreTransform(ent)
        return false
    end
end)

hook.Add("PlayerUse", "MapStudio_AllowObjectUse", function(ply, ent)
    if protection.IsMapStudioEntity(ent) then
        protection.RestoreTransform(ent)
        scheduleTransformRestore(ent)
    end
end)

hook.Add("EntityTakeDamage", "MapStudio_BlockObjectDamage", function(ent, damageInfo)
    if not protection.IsMapStudioEntity(ent) then
        return
    end

    if objectBehavior(ent) == "reactive" then
        ent.MapStudioAllowRuntimeRemovalUntil = now() + 2
        protection.RestoreTransform(ent)
        timer.Simple(0, function()
            if IsValid(ent) then
                protection.RestoreTransform(ent)
            end
        end)
        return
    end

    if MapStudio.Config.ProtectFromDamage ~= false then
        damageInfo:SetDamage(0)
        protection.RestoreTransform(ent)
        return true
    end
end)

hook.Add("OnPhysgunFreeze", "MapStudio_KeepObjectsFrozen", function(_, _, ent)
    if protection.IsMapStudioEntity(ent) then
        protection.RestoreTransform(ent)
        return false
    end
end)

hook.Add("PlayerUnfrozeObject", "MapStudio_PreventObjectUnfreeze", function(_, ent)
    if protection.IsMapStudioEntity(ent) then
        protection.RestoreTransform(ent)
        return false
    end
end)

hook.Add("EntityRemoved", "MapStudio_RestoreExternalDeletion", function(ent)
    if not ent or ent.MapStudioInternalRemove == true then
        return
    end

    if ent.MapStudioAllowRuntimeRemovalUntil and ent.MapStudioAllowRuntimeRemovalUntil >= now() then
        return
    end

    local id = objectID(ent)

    if not id then
        return
    end

    local state = MapStudio.GetState()
    local existing = state.objects and state.objects[id]

    if not existing then
        return
    end

    if MapStudio.RuntimeEntities and MapStudio.RuntimeEntities[id] == ent then
        MapStudio.RuntimeEntities[id] = nil
    end

    timer.Simple(0, function()
        local currentState = MapStudio.GetState()
        local objectData = currentState.objects and currentState.objects[id]

        if not objectData or not MapStudio.Spawner or not MapStudio.Spawner.Spawn then
            return
        end

        if MapStudio.RuntimeEntities and IsValid(MapStudio.RuntimeEntities[id]) then
            return
        end

        local spawned, entOrErr = pcall(MapStudio.Spawner.Spawn, objectData)
        if not spawned then
            MapStudio.LogWarning("Could not restore externally removed MapStudio object id=" .. tostring(id) .. ": " .. tostring(entOrErr))
            return
        end

        if MapStudio.BroadcastState then
            MapStudio.BroadcastState()
        end
    end)
end)

hook.Add("OnEntityCreated", "MapStudio_ClearCopiedObjectTags", function(ent)
    timer.Simple(0, function()
        if not IsValid(ent) then
            return
        end

        local id = objectID(ent)

        if not id then
            return
        end

        if MapStudio.RuntimeEntities and MapStudio.RuntimeEntities[id] == ent then
            return
        end

        clearCopiedMapStudioTags(ent)
    end)
end)

timer.Create("MapStudio_TransformInvariant", TRANSFORM_GUARD_PERIOD, 0, function()
    for id, ent in pairs(MapStudio.RuntimeEntities or {}) do
        if IsValid(ent) then
            protection.RestoreTransform(ent)
        else
            MapStudio.RuntimeEntities[id] = nil
        end
    end
end)
