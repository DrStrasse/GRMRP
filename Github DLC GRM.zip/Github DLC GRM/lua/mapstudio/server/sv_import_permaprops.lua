MapStudio = MapStudio or {}
MapStudio.Importers = MapStudio.Importers or {}
MapStudio.Importers.PermaProps = MapStudio.Importers.PermaProps or {}

local importer = MapStudio.Importers.PermaProps

local candidatePatterns = {
    "permaprops/*.json",
    "permaprops/*.txt",
    "permaprops/maps/*.json",
    "permaprops/maps/*.txt",
    "permaprops/" .. MapStudio.GetMapName() .. "/*.json",
    "permaprops/" .. MapStudio.GetMapName() .. "/*.txt"
}

local function findCandidates()
    local found = {}

    for _, pattern in ipairs(candidatePatterns) do
        local files = file.Find(pattern, "DATA")
        local folder = string.GetPathFromFilename and string.GetPathFromFilename(pattern) or string.gsub(pattern, "[^/]+$", "")

        for _, name in ipairs(files or {}) do
            table.insert(found, folder .. name)
        end
    end

    return found
end

local function looksLikeObject(record)
    return type(record) == "table" and (record.model or record.Model or record.mdl)
end

local function normalizePermaProp(record)
    local model = record.model or record.Model or record.mdl
    local pos = record.pos or record.Position or record.position
    local ang = record.ang or record.Angles or record.angle

    if type(pos) == "table" and pos.x == nil then
        pos = { x = pos[1], y = pos[2], z = pos[3] }
    end

    if type(ang) == "table" and ang.p == nil then
        ang = { p = ang[1], y = ang[2], r = ang[3] }
    end

    return MapStudio.Objects.SanitizeObject({
        model = model,
        pos = pos,
        ang = ang,
        layer = "imported_permaprops",
        frozen = true,
        collision = record.collision ~= false
    })
end

local function collectObjects(data)
    local result = {}

    if looksLikeObject(data) then
        local objectData = normalizePermaProp(data)

        if objectData then
            table.insert(result, objectData)
        end

        return result
    end

    if type(data) ~= "table" then
        return result
    end

    for _, record in pairs(data) do
        if looksLikeObject(record) then
            local objectData = normalizePermaProp(record)

            if objectData then
                table.insert(result, objectData)
            end
        end
    end

    return result
end

function importer.CanImport()
    local candidates = findCandidates()
    return #candidates > 0, candidates
end

function importer.Preview()
    local _, candidates = importer.CanImport()
    local preview = {
        files = candidates,
        count = 0,
        objects = {}
    }

    for _, path in ipairs(candidates) do
        local content = file.Read(path, "DATA")
        local ok, data = pcall(util.JSONToTable, content or "")
        data = ok and data or nil

        for _, objectData in ipairs(collectObjects(data)) do
            table.insert(preview.objects, objectData)
            preview.count = preview.count + 1
        end
    end

    return preview
end

function importer.Import()
    local preview = importer.Preview()

    if preview.count == 0 then
        return false, "import.permaprops.not_found"
    end

    MapStudio.Storage.BackupProfile(MapStudio.GetMapName(), MapStudio.GetState().profile, "before_permaprops_import")

    local state = MapStudio.GetState()
    local importLayer = MapStudio.Objects.SanitizeLayer({
        id = "imported_permaprops",
        nameKey = "layer.imported_permaprops",
        name = "Imported PermaProps",
        color = { r = 255, g = 185, b = 70, a = 255 },
        visible = true,
        locked = false
    })

    state.layers[importLayer.id] = importLayer

    for _, objectData in ipairs(preview.objects) do
        objectData.id = MapStudio.Objects.MakeID()
        state.objects[objectData.id] = objectData
    end

    MapStudio.Spawner.ReloadAll(state)
    MapStudio.MarkDirty()

    return true, nil, preview.count
end

MapStudio.RegisterImporter("permaprops", {
    name = "PermaProps",
    canImport = importer.CanImport,
    preview = importer.Preview,
    import = importer.Import
})
