MapStudio = MapStudio or {}

local MAX_INBOUND_PAYLOAD_BYTES = 60000
local MAX_BATCH_OBJECTS = math.min(256, math.max(1, tonumber(MapStudio.Config.MaxObjects) or 1000))
local MAX_BATCH_MUTATIONS = MAX_BATCH_OBJECTS
local MAX_PAYLOAD_DEPTH = math.max(12, math.min((tonumber(MapStudio.Config.MaxSerializableDepth) or 8) + 8, 24))
local MAX_PAYLOAD_ENTRIES = 8192
local MAX_STATE_CHUNKS = 65535

for _, messageName in pairs(MapStudio.Net.Messages) do
    util.AddNetworkString(messageName)
end

local function encode(value)
    return util.TableToJSON(value or {}, false) or "{}"
end

local function decode(text)
    if type(text) ~= "string" or text == "" then
        return nil, "empty payload"
    end

    local ok, data = pcall(util.JSONToTable, text)

    if not ok or type(data) ~= "table" then
        return nil, "invalid JSON"
    end

    return data
end

local debugBindsConVar = CreateConVar("mapstudio_debug_binds", "0", 0, "Print MapStudio editor keybind diagnostics")

local function debugBinds(message)
    if debugBindsConVar and debugBindsConVar:GetBool() then
        print("[MapStudio binds] " .. tostring(message))
    end
end

local function validatePayloadShape(value)
    local pending = {
        { value = value, depth = 0 }
    }
    local seen = {}
    local entries = 0

    while #pending > 0 do
        local current = pending[#pending]
        pending[#pending] = nil
        local currentValue = current.value

        if type(currentValue) == "table" then
            if seen[currentValue] then
                return false, "cyclic table"
            end

            seen[currentValue] = true

            for key, child in pairs(currentValue) do
                entries = entries + 1

                if entries > MAX_PAYLOAD_ENTRIES then
                    return false, "too many values"
                end

                local keyType = type(key)
                if keyType ~= "string" and keyType ~= "number" then
                    return false, "invalid key type"
                end

                local childType = type(child)
                if childType == "table" then
                    if current.depth >= MAX_PAYLOAD_DEPTH then
                        return false, "payload nesting is too deep"
                    end

                    pending[#pending + 1] = {
                        value = child,
                        depth = current.depth + 1
                    }
                elseif childType ~= "string" and childType ~= "number" and childType ~= "boolean" and childType ~= "nil" then
                    return false, "invalid value type"
                end
            end
        end
    end

    return true
end

local function readPayload()
    local text = net.ReadString()

    if type(text) ~= "string" then
        return nil, "payload is not a string"
    end

    if #text > MAX_INBOUND_PAYLOAD_BYTES then
        return nil, "payload exceeds byte limit"
    end

    local payload, decodeErr = decode(text)
    if not payload then
        return nil, decodeErr
    end

    local valid, shapeErr = validatePayloadShape(payload)
    if not valid then
        return nil, shapeErr
    end

    return payload
end

local function readPayloadForAction(ply, action, messageBits)
    local maxBits = (MAX_INBOUND_PAYLOAD_BYTES + 64) * 8

    if type(messageBits) == "number" and messageBits > maxBits then
        MapStudio.LogWarning("Rejected oversized " .. tostring(action) .. " request from " .. tostring(IsValid(ply) and ply:Nick() or "unknown"))
        MapStudio.Notify(ply, "notify.invalid_request", "error")
        return nil
    end

    local payload, err = readPayload()
    if payload then
        return payload
    end

    MapStudio.LogWarning("Rejected malformed " .. tostring(action) .. " request from " .. tostring(IsValid(ply) and ply:Nick() or "unknown") .. ": " .. tostring(err))
    MapStudio.Notify(ply, "notify.invalid_request", "error")
    return nil
end

local function boundedEntryCount(value, maxEntries)
    if type(value) ~= "table" then
        return nil
    end

    local count = 0

    for _ in pairs(value) do
        count = count + 1

        if count > maxEntries then
            return nil
        end
    end

    return count
end

local function objectSummary(objectData)
    objectData = type(objectData) == "table" and objectData or {}

    return "id=" .. tostring(objectData.id or "")
        .. " model=" .. tostring(objectData.model or "")
        .. " class=" .. tostring(objectData.class or "")
end

local function sanitizeObjectSafely(data, existing)
    local ok, objectData, err = pcall(MapStudio.Objects.SanitizeObject, data, existing)

    if not ok then
        MapStudio.LogWarning("Object sanitization failed: " .. objectSummary(data) .. " reason=" .. tostring(objectData))
        return nil, "error.invalid_object"
    end

    return objectData, err
end

local function spawnObjectSafely(objectData)
    local ok, ent, err = pcall(MapStudio.Spawner.Spawn, objectData)

    if not ok then
        MapStudio.LogWarning("Object spawn failed: " .. objectSummary(objectData) .. " reason=" .. tostring(ent))
        return nil, "error.spawn_failed"
    end

    return ent, err
end

local function updateObjectSafely(id, objectData)
    local ok, ent, err = pcall(MapStudio.Spawner.Update, id, objectData)

    if not ok then
        MapStudio.LogWarning("Object update failed: " .. objectSummary(objectData) .. " reason=" .. tostring(ent))
        return nil, "error.spawn_failed"
    end

    return ent, err
end

local function sanitizeLayerSafely(data, existing)
    local ok, layer = pcall(MapStudio.Objects.SanitizeLayer, data, existing)

    if not ok or type(layer) ~= "table" then
        MapStudio.LogWarning("Layer sanitization failed: " .. tostring(ok and layer or layer))
        return nil
    end

    return layer
end

local function reloadObjectsSafely(state)
    local ok, report = pcall(MapStudio.Spawner.ReloadAll, state)

    if not ok then
        MapStudio.LogError("Scene entity reload failed: " .. tostring(report))
        return false
    end

    if type(report) == "table" and (report.failed or 0) > 0 then
        MapStudio.LogWarning("Scene reloaded with warnings: spawned=" .. tostring(report.spawned or 0)
            .. ", failed=" .. tostring(report.failed or 0))
    end

    return true
end

local function sendPayload(messageName, target, payload)
    net.Start(messageName)
    net.WriteString(encode(payload))

    if target then
        net.Send(target)
    else
        net.Broadcast()
    end
end

function MapStudio.Notify(target, key, level, replacements)
    if not target or not IsValid(target) then
        MapStudio.Log(MapStudio.Lang.Get(key, replacements))
        return
    end

    sendPayload(MapStudio.Net.Get("Notify"), target, {
        key = key,
        level = level or "info",
        replacements = replacements or {}
    })
end

local function sendStateChunk(target, transferId, index, total, chunk)
    net.Start(MapStudio.Net.Get("StateChunk"))
    net.WriteString(transferId)
    net.WriteUInt(index, 16)
    net.WriteUInt(total, 16)
    net.WriteString(chunk)

    if IsValid(target) then
        net.Send(target)
    end
end

local function buildStateJSON()
    local built, state, report = pcall(function()
        if MapStudio.Storage and MapStudio.Storage.BuildSerializableState then
            return MapStudio.Storage.BuildSerializableState(MapStudio.GetState())
        end

        return MapStudio.GetState()
    end)

    if not built or type(state) ~= "table" then
        MapStudio.LogError("Failed to build state for network transfer: " .. tostring(state))
        state = {}
    elseif report and ((report.skipped or 0) > 0 or (report.fallback or 0) > 0) then
        MapStudio.Debug("Network state built with warnings: saved=" .. tostring(report.saved or 0)
            .. ", fallback=" .. tostring(report.fallback or 0)
            .. ", skipped=" .. tostring(report.skipped or 0))
    end

    local ok, json = pcall(util.TableToJSON, state, false)

    if not ok or type(json) ~= "string" then
        MapStudio.LogError("Failed to encode state for network transfer: " .. tostring(json))
        json = "{}"
    end

    return json
end

local function sendStateJSON(target, json)
    if not IsValid(target) then
        return false
    end

    local chunkSize = math.max(1024, math.min(60000, tonumber(MapStudio.Config.MaxNetChunkSize) or 56000))
    local total = math.max(1, math.ceil(string.len(json) / chunkSize))

    if total > MAX_STATE_CHUNKS then
        MapStudio.LogError("State transfer exceeds the maximum chunk count for " .. tostring(target:Nick()))
        return false
    end

    local transferId = tostring(os.time()) .. "_" .. tostring(math.random(100000, 999999))

    for index = 1, total do
        local startIndex = ((index - 1) * chunkSize) + 1
        local chunk = string.sub(json, startIndex, startIndex + chunkSize - 1)
        sendStateChunk(target, transferId, index, total, chunk)
    end

    return true
end

function MapStudio.SendState(target)
    if target == nil then
        MapStudio.BroadcastState()
        return true
    end

    if not IsValid(target) or not MapStudio.ServerCanUse(target, "view", true) then
        return false
    end

    return sendStateJSON(target, buildStateJSON())
end

function MapStudio.BroadcastState()
    local json = buildStateJSON()

    for _, target in ipairs(player.GetAll()) do
        if MapStudio.ServerCanUse(target, "view", true) then
            sendStateJSON(target, json)
        end
    end
end

local function markAndBroadcast()
    MapStudio.MarkDirty()
    MapStudio.BroadcastState()
end

local function canMutate(ply, action)
    return MapStudio.ServerCanUse(ply, action) and MapStudio.CheckRateLimit(ply, action)
end

local function canGlobalMutate(ply, action)
    if not canMutate(ply, action) then
        return false
    end

    if MapStudio.ServerCanManageScene and MapStudio.ServerCanManageScene(ply, action, true) then
        return true
    end

    MapStudio.Notify(ply, "notify.no_permission", "error")
    return false
end

net.Receive(MapStudio.Net.Get("RequestState"), function(_, ply)
    if MapStudio.ServerCanUse(ply, "view") and MapStudio.CheckRateLimit(ply, "view") then
        MapStudio.SendState(ply)
    end
end)

net.Receive(MapStudio.Net.Get("OpenEditor"), function(_, ply)
    local allowed = MapStudio.ServerCanUse(ply, "open", true)
    local reason = allowed and "editor.open" or "notify.no_permission"

    if allowed and not MapStudio.CheckRateLimit(ply, "open") then
        allowed = false
        reason = "error.rate_limited"
    end

    sendPayload(MapStudio.Net.Get("OpenEditorResult"), ply, {
        allowed = allowed == true,
        reason = reason
    })

    if not allowed and reason == "notify.no_permission" then
        MapStudio.Debug("Denied editor open for " .. tostring(IsValid(ply) and ply:Nick() or "unknown"))
    end
end)

net.Receive(MapStudio.Net.Get("CreateObject"), function(messageBits, ply)
    if not canMutate(ply, "create") then
        return
    end

    local payload = readPayloadForAction(ply, "create", messageBits)
    if not payload then
        return
    end

    local objectData, err = sanitizeObjectSafely(payload)
    if not objectData then
        MapStudio.Notify(ply, err or "error.invalid_object", "error")
        return
    end

    if MapStudio.GetObjectCount() >= MapStudio.Config.MaxObjects then
        MapStudio.Notify(ply, "error.object_limit", "error")
        return
    end

    objectData.id = MapStudio.Objects.MakeID()
    objectData.createdBy = ply:SteamID64()
    objectData.createdAt = os.time()
    objectData.updatedBy = objectData.createdBy
    objectData.updatedAt = objectData.createdAt

    local ent, spawnErr = spawnObjectSafely(objectData)
    if not ent then
        MapStudio.Notify(ply, spawnErr or "error.spawn_failed", "error")
        return
    end

    MapStudio.GetState().objects[objectData.id] = objectData
    markAndBroadcast()
    sendPayload(MapStudio.Net.Get("ObjectCreated"), ply, { id = objectData.id })
end)

net.Receive(MapStudio.Net.Get("CreateObjects"), function(messageBits, ply)
    if not canMutate(ply, "create") then
        return
    end

    local payload = readPayloadForAction(ply, "create batch", messageBits)
    if not payload then
        return
    end

    local objects = payload.objects
    local objectCount = boundedEntryCount(objects, MAX_BATCH_OBJECTS)

    if not objectCount or objectCount == 0 or #objects ~= objectCount then
        MapStudio.Notify(ply, "notify.invalid_request", "error")
        return
    end

    local cleanObjects = {}

    for _, rawObject in ipairs(objects) do
        local objectData, err = sanitizeObjectSafely(rawObject)

        if not objectData then
            MapStudio.Notify(ply, err or "error.invalid_object", "error")
            return
        end

        table.insert(cleanObjects, objectData)
    end

    if #cleanObjects == 0 then
        MapStudio.Notify(ply, "error.invalid_object", "error")
        return
    end

    if MapStudio.GetObjectCount() + #cleanObjects > MapStudio.Config.MaxObjects then
        MapStudio.Notify(ply, "error.object_limit", "error")
        return
    end

    local createdAt = os.time()
    local createdBy = ply:SteamID64()
    local spawned = {}
    local createdIDs = {}

    for _, objectData in ipairs(cleanObjects) do
        objectData.id = MapStudio.Objects.MakeID()
        objectData.createdBy = createdBy
        objectData.createdAt = createdAt
        objectData.updatedBy = createdBy
        objectData.updatedAt = createdAt

        local ent, spawnErr = spawnObjectSafely(objectData)
        if not ent then
            for _, rollback in ipairs(spawned) do
                MapStudio.GetState().objects[rollback.id] = nil
                MapStudio.Spawner.Remove(rollback.id)
            end

            MapStudio.Notify(ply, spawnErr or "error.spawn_failed", "error")
            return
        end

        MapStudio.GetState().objects[objectData.id] = objectData
        table.insert(spawned, objectData)
        table.insert(createdIDs, objectData.id)
    end

    markAndBroadcast()
    sendPayload(MapStudio.Net.Get("ObjectCreated"), ply, { ids = createdIDs })
end)

local function applyObjectUpdates(ply, rawUpdates)
    local updateCount = boundedEntryCount(rawUpdates, MAX_BATCH_MUTATIONS)

    if not updateCount or updateCount == 0 then
        MapStudio.Notify(ply, "notify.invalid_request", "error")
        return false
    end

    local state = MapStudio.GetState()
    local updates = {}
    local seen = {}
    local updatedAt = os.time()
    local updatedBy = IsValid(ply) and ply:SteamID64() or "server"

    for _, rawUpdate in pairs(rawUpdates) do
        if type(rawUpdate) ~= "table" then
            MapStudio.Notify(ply, "notify.invalid_request", "error")
            return false
        end

        local rawID = rawUpdate.id
        local id = (type(rawID) == "string" or type(rawID) == "number") and tostring(rawID) or ""
        local patch = rawUpdate.patch

        if patch == nil then
            patch = rawUpdate
        end

        if id == "" or #id > 128 or seen[id] or type(patch) ~= "table" then
            MapStudio.Notify(ply, "notify.invalid_request", "error")
            return false
        end

        local existing = state.objects[id]
        if not existing then
            MapStudio.Notify(ply, "error.invalid_object", "error")
            return false
        end

        if not MapStudio.ServerCanEditObject(ply, existing, "update") then
            return false
        end

        local updated, err = sanitizeObjectSafely(patch, existing)
        if not updated then
            MapStudio.Notify(ply, err or "error.invalid_object", "error")
            return false
        end

        updated.id = id
        updated.createdBy = existing.createdBy
        updated.createdAt = existing.createdAt
        updated.updatedBy = updatedBy
        updated.updatedAt = updatedAt

        seen[id] = true
        table.insert(updates, {
            id = id,
            previous = existing,
            updated = updated
        })
    end

    if #updates == 0 then
        MapStudio.Notify(ply, "error.invalid_object", "error")
        return false
    end

    for _, update in ipairs(updates) do
        state.objects[update.id] = update.updated
    end

    for _, update in ipairs(updates) do
        local ent, spawnErr = updateObjectSafely(update.id, update.updated)

        if not ent then
            for _, rollback in ipairs(updates) do
                state.objects[rollback.id] = rollback.previous
                updateObjectSafely(rollback.id, rollback.previous)
            end

            MapStudio.Notify(ply, spawnErr or "error.spawn_failed", "error")
            return false
        end
    end

    markAndBroadcast()
    return true
end

net.Receive(MapStudio.Net.Get("UpdateObject"), function(messageBits, ply)
    if not canMutate(ply, "update") then
        return
    end

    local payload = readPayloadForAction(ply, "update", messageBits)
    if not payload then
        return
    end

    applyObjectUpdates(ply, {
        {
            id = payload.id,
            patch = payload.patch or payload
        }
    })
end)

net.Receive(MapStudio.Net.Get("UpdateObjects"), function(messageBits, ply)
    if not canMutate(ply, "update") then
        return
    end

    local payload = readPayloadForAction(ply, "update batch", messageBits)
    if not payload then
        return
    end

    applyObjectUpdates(ply, payload.updates)
end)

net.Receive(MapStudio.Net.Get("DeleteObject"), function(messageBits, ply)
    if not canMutate(ply, "delete") then
        return
    end

    local payload = readPayloadForAction(ply, "delete", messageBits)
    if not payload then
        return
    end

    local ids = payload.ids

    if type(ids) ~= "table" then
        ids = { payload.id }
    end

    local requestCount = boundedEntryCount(ids, MAX_BATCH_MUTATIONS)
    if not requestCount or requestCount == 0 then
        MapStudio.Notify(ply, "notify.invalid_request", "error")
        return
    end

    debugBinds("server delete request from " .. tostring(IsValid(ply) and ply:Nick() or "unknown") .. " count=" .. tostring(requestCount))

    local state = MapStudio.GetState()
    local deleteIDs = {}
    local seen = {}

    for _, rawID in pairs(ids) do
        local id = (type(rawID) == "string" or type(rawID) == "number") and tostring(rawID) or ""

        if id == "" or #id > 128 or seen[id] then
            MapStudio.Notify(ply, "notify.invalid_request", "error")
            return
        end

        local existing = state.objects[id]

        if not existing then
            MapStudio.Notify(ply, "error.invalid_object", "error")
            return
        end

        if not MapStudio.ServerCanEditObject(ply, existing, "delete") then
            return
        end

        seen[id] = true
        deleteIDs[#deleteIDs + 1] = id
    end

    for _, id in ipairs(deleteIDs) do
        state.objects[id] = nil
        MapStudio.Spawner.Remove(id)
    end

    markAndBroadcast()
end)

net.Receive(MapStudio.Net.Get("ClearObjects"), function(_, ply)
    if not canGlobalMutate(ply, "clear") then
        return
    end

    local state = MapStudio.GetState()

    for id in pairs(state.objects or {}) do
        state.objects[id] = nil
        MapStudio.Spawner.Remove(id)
    end

    markAndBroadcast()
end)

net.Receive(MapStudio.Net.Get("SaveProfile"), function(_, ply)
    if not canMutate(ply, "save") then
        return
    end

    local ok, err, report = MapStudio.SaveActiveProfile()
    local warningSave = ok and report and ((report.skipped or 0) > 0 or (report.fallback or 0) > 0)
    MapStudio.Notify(ply, ok and (warningSave and "profile.saved_with_warnings" or "profile.saved") or (err or "error.storage_save_failed"), ok and (warningSave and "warning" or "info") or "error", {
        saved = report and report.saved or 0,
        skipped = report and report.skipped or 0,
        fallback = report and report.fallback or 0
    })

    if ok then
        MapStudio.BroadcastState()
    end
end)

net.Receive(MapStudio.Net.Get("LoadProfile"), function(messageBits, ply)
    if not canGlobalMutate(ply, "load") then
        return
    end

    local payload = readPayloadForAction(ply, "load profile", messageBits)
    if not payload then
        return
    end

    local ok, err = MapStudio.LoadActiveProfile(payload.profile)

    MapStudio.Notify(ply, ok and "profile.loaded" or (err or "error.storage_load_failed"), ok and "info" or "error")

    if ok then
        MapStudio.BroadcastState()
    end
end)

net.Receive(MapStudio.Net.Get("ListProfiles"), function(_, ply)
    if MapStudio.ServerCanUse(ply, "view") and MapStudio.CheckRateLimit(ply, "view") then
        sendPayload(MapStudio.Net.Get("ProfileList"), ply, {
            profiles = MapStudio.Storage.ListProfiles(MapStudio.GetMapName()),
            active = MapStudio.GetState().profile
        })
    end
end)

local function sendLayoutList(ply)
    if MapStudio.ServerCanUse(ply, "view", true) then
        sendPayload(MapStudio.Net.Get("LayoutList"), ply, {
            map = MapStudio.GetMapName(),
            layouts = MapStudio.Storage.ListLayouts(MapStudio.GetMapName())
        })
    end
end

net.Receive(MapStudio.Net.Get("ListLayouts"), function(_, ply)
    if MapStudio.ServerCanUse(ply, "view") and MapStudio.CheckRateLimit(ply, "view") then
        sendLayoutList(ply)
    end
end)

net.Receive(MapStudio.Net.Get("SaveLayout"), function(messageBits, ply)
    if not canGlobalMutate(ply, "save") then
        return
    end

    local payload = readPayloadForAction(ply, "save layout", messageBits)
    if not payload then
        return
    end

    local completed, ok, err = pcall(MapStudio.Storage.SaveLayout, MapStudio.GetState(), MapStudio.GetMapName(), payload.name, payload.overwrite == true)
    if not completed then
        MapStudio.LogError("Layout save failed: " .. tostring(ok))
        ok = false
        err = "error.storage_save_failed"
    end

    MapStudio.Notify(ply, ok and "layout.saved" or (err or "error.storage_save_failed"), ok and "info" or "error")
    sendLayoutList(ply)
end)

net.Receive(MapStudio.Net.Get("LoadLayout"), function(messageBits, ply)
    if not canGlobalMutate(ply, "load") then
        return
    end

    local payload = readPayloadForAction(ply, "load layout", messageBits)
    if not payload then
        return
    end

    local loaded, layout, err = pcall(MapStudio.Storage.LoadLayout, MapStudio.GetMapName(), payload.id)

    if not loaded then
        MapStudio.LogError("Layout load failed: " .. tostring(layout))
        layout = nil
        err = "error.storage_load_failed"
    end

    if not layout then
        MapStudio.Notify(ply, err or "error.storage_load_failed", "error")
        sendLayoutList(ply)
        return
    end

    local state = MapStudio.GetState()
    state.objects = {}

    for _, objectData in ipairs(layout.objects or {}) do
        local cleanObject = sanitizeObjectSafely(objectData)

        if cleanObject then
            if state.objects[cleanObject.id] then
                cleanObject.id = MapStudio.Objects.MakeID()
            end

            if not state.layers[cleanObject.layer] then
                cleanObject.layer = "default"
            end

            state.objects[cleanObject.id] = cleanObject
        end
    end

    if not reloadObjectsSafely(state) then
        MapStudio.Notify(ply, "error.spawn_failed", "error")
        return
    end
    markAndBroadcast()
    MapStudio.Notify(ply, "layout.loaded", "info")
    sendLayoutList(ply)
end)

net.Receive(MapStudio.Net.Get("DeleteLayout"), function(messageBits, ply)
    if not canGlobalMutate(ply, "delete") then
        return
    end

    local payload = readPayloadForAction(ply, "delete layout", messageBits)
    if not payload then
        return
    end

    local completed, ok, err = pcall(MapStudio.Storage.DeleteLayout, MapStudio.GetMapName(), payload.id)
    if not completed then
        MapStudio.LogError("Layout deletion failed: " .. tostring(ok))
        ok = false
        err = "error.storage_save_failed"
    end

    MapStudio.Notify(ply, ok and "layout.deleted" or (err or "notify.invalid_request"), ok and "info" or "error")
    sendLayoutList(ply)
end)

net.Receive(MapStudio.Net.Get("LayerUpdate"), function(messageBits, ply)
    if not canGlobalMutate(ply, "layer") then
        return
    end

    local payload = readPayloadForAction(ply, "layer", messageBits)
    if not payload then
        return
    end

    local action = string.lower(tostring(payload.action or "update"))
    if action ~= "create" and action ~= "update" and action ~= "delete" then
        MapStudio.Notify(ply, "notify.invalid_request", "error")
        return
    end

    local state = MapStudio.GetState()

    if action == "create" then
        if type(payload.layer) ~= "table" then
            MapStudio.Notify(ply, "notify.invalid_request", "error")
            return
        end

        local layer = sanitizeLayerSafely(payload.layer or {})
        if not layer then
            MapStudio.Notify(ply, "error.invalid_layer", "error")
            return
        end
        if layer.id == "default" then
            layer.id = "layer_" .. tostring(MapStudio.Objects.MakeID())
        end

        if state.layers[layer.id] then
            MapStudio.Notify(ply, "error.invalid_layer", "error")
            return
        end

        state.layers[layer.id] = layer
    elseif action == "delete" then
        local id = MapStudio.Objects.SanitizeLayerID(payload.id)
        if id == "default" or not state.layers[id] then
            MapStudio.Notify(ply, "error.invalid_layer", "error")
            return
        end

        for _, objectData in pairs(state.objects) do
            if objectData.layer == id then
                objectData.layer = "default"
            end
        end

        state.layers[id] = nil
    else
        local id = MapStudio.Objects.SanitizeLayerID(payload.id)
        local existing = state.layers[id]

        if not existing then
            MapStudio.Notify(ply, "error.invalid_layer", "error")
            return
        end

        if type(payload.layer) ~= "table" then
            MapStudio.Notify(ply, "notify.invalid_request", "error")
            return
        end

        local patch = payload.layer
        patch.id = id
        local layer = sanitizeLayerSafely(patch, existing)
        if not layer then
            MapStudio.Notify(ply, "error.invalid_layer", "error")
            return
        end

        state.layers[id] = layer
    end

    if not reloadObjectsSafely(state) then
        MapStudio.Notify(ply, "error.spawn_failed", "error")
        return
    end
    markAndBroadcast()
end)

net.Receive(MapStudio.Net.Get("ImportPermaProps"), function(_, ply)
    if not canGlobalMutate(ply, "import") then
        return
    end

    local completed, ok, err, count = pcall(MapStudio.Importers.PermaProps.Import)
    if not completed then
        MapStudio.LogError("PermaProps import failed: " .. tostring(ok))
        ok = false
        err = "error.storage_load_failed"
        count = 0
    end
    MapStudio.Notify(ply, ok and "import.permaprops.done" or (err or "import.permaprops.not_found"), ok and "info" or "error", {
        count = count or 0
    })

    if ok then
        MapStudio.BroadcastState()
    end
end)
