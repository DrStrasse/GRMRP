MapStudio = MapStudio or {}

function MapStudio.MarkDirty()
    local state = MapStudio.GetState()
    state.dirty = true
    state.updatedAt = os.time()

    if MapStudio.Config.AutoSave then
        MapStudio.ScheduleAutoSave()
    end
end

function MapStudio.ScheduleAutoSave()
    timer.Create("MapStudio_AutoSave", MapStudio.Config.AutoSaveDelay or 0.5, 1, function()
        local completed, ok, err, report = pcall(MapStudio.SaveActiveProfile)

        if not completed or not ok then
            MapStudio.LogError("Automatic profile save failed: " .. tostring(completed and err or ok))
            return
        end

        if report and ((report.skipped or 0) > 0 or (report.fallback or 0) > 0) then
            MapStudio.LogWarning("Automatic profile save completed with warnings: saved=" .. tostring(report.saved or 0)
                .. ", fallback=" .. tostring(report.fallback or 0)
                .. ", skipped=" .. tostring(report.skipped or 0))
        end

        MapStudio.BroadcastState()
    end)
end

function MapStudio.LoadActiveProfile(profile)
    profile = MapStudio.Objects.SanitizeProfileName(profile or MapStudio.Config.DefaultProfile)

    local loaded, state, err = pcall(MapStudio.Storage.LoadProfile, MapStudio.GetMapName(), profile)

    if not loaded or type(state) ~= "table" then
        MapStudio.LogError("Profile load failed for map=" .. tostring(MapStudio.GetMapName())
            .. " profile=" .. tostring(profile) .. ": " .. tostring(loaded and err or state))
        state = MapStudio.CreateEmptyState(MapStudio.GetMapName(), profile)
        err = "error.storage_load_failed"
    end

    MapStudio.SetState(state)

    local reloaded, spawnReport = pcall(MapStudio.Spawner.ReloadAll, state)
    if not reloaded then
        MapStudio.LogError("Profile entity restore failed for profile=" .. tostring(profile) .. ": " .. tostring(spawnReport))
        return false, "error.spawn_failed"
    end

    if type(spawnReport) == "table" and (spawnReport.failed or 0) > 0 then
        MapStudio.LogWarning("Profile loaded with restore warnings: spawned=" .. tostring(spawnReport.spawned or 0)
            .. ", failed=" .. tostring(spawnReport.failed or 0))
    end

    return err == nil, err
end

function MapStudio.SaveActiveProfile()
    local state = MapStudio.GetState()
    local completed, ok, err, report = pcall(MapStudio.Storage.SaveProfile, state, state.map or MapStudio.GetMapName(), state.profile or MapStudio.Config.DefaultProfile)

    if not completed then
        MapStudio.LogError("Profile save crashed before completion: " .. tostring(ok))
        return false, "error.storage_save_failed", { saved = 0, skipped = 0, fallback = 0, issues = {} }
    end

    return ok, err, report
end

local function consoleAllowed(ply, action)
    if not IsValid(ply) then
        return true
    end

    return MapStudio.ServerCanUse(ply, action)
end

concommand.Add("mapstudio_reload", function(ply)
    if not consoleAllowed(ply, "load") then
        return
    end

    local ok, err = MapStudio.LoadActiveProfile(MapStudio.GetState().profile)

    if IsValid(ply) then
        MapStudio.Notify(ply, ok and "profile.reloaded" or (err or "error.storage_load_failed"), ok and "info" or "error")
    else
        MapStudio.Log(ok and "Profile reloaded." or (err or "Profile reload failed."))
    end

    if ok then
        MapStudio.BroadcastState()
    end
end)

concommand.Add("mapstudio_save", function(ply)
    if not consoleAllowed(ply, "save") then
        return
    end

    local ok, err, report = MapStudio.SaveActiveProfile()
    local warningSave = ok and report and ((report.skipped or 0) > 0 or (report.fallback or 0) > 0)

    if IsValid(ply) then
        MapStudio.Notify(ply, ok and (warningSave and "profile.saved_with_warnings" or "profile.saved") or (err or "error.storage_save_failed"), ok and (warningSave and "warning" or "info") or "error", {
            saved = report and report.saved or 0,
            skipped = report and report.skipped or 0,
            fallback = report and report.fallback or 0
        })
    else
        if ok then
            MapStudio.Log("Profile saved. saved=" .. tostring(report and report.saved or 0) .. " fallback=" .. tostring(report and report.fallback or 0) .. " skipped=" .. tostring(report and report.skipped or 0))
        else
            MapStudio.LogError(err or "Profile save failed.")
        end
    end
end)

local function printLines(ply, lines)
    for _, line in ipairs(lines) do
        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTCONSOLE, "[MapStudio] " .. line)
        else
            MapStudio.Log(line)
        end
    end
end

concommand.Add("mapstudio_validate", function(ply)
    if not consoleAllowed(ply, "view") then
        return
    end

    local validated, report = pcall(MapStudio.Storage.ValidateState, MapStudio.GetState())
    if not validated or type(report) ~= "table" then
        printLines(ply, { "Validation failed. Check the server console for details." })
        MapStudio.LogError("Profile validation failed: " .. tostring(report))
        return
    end
    local lines = {
        "Validation complete.",
        "Total objects: " .. tostring(report.total or 0),
        "Valid objects: " .. tostring(report.valid or 0),
        "No-physics fallback objects: " .. tostring(report.fallback or 0),
        "Invalid models: " .. tostring(report.invalidModels or 0),
        "Skipped/invalid objects: " .. tostring(report.skipped or 0),
        report.canSave and "Profile can be saved with fallback." or "Profile cannot be saved."
    }

    printLines(ply, lines)

    for _, issue in ipairs(report.issues or {}) do
        printLines(ply, {
            "WARNING: " .. tostring(issue.key)
                .. " id=" .. tostring(issue.id or "")
                .. " model=" .. tostring(issue.model or "")
                .. " class=" .. tostring(issue.class or "")
                .. (issue.entityIndex and " entity=" .. tostring(issue.entityIndex) or "")
                .. (issue.reason and " reason=" .. tostring(issue.reason) or "")
        })
    end
end)

concommand.Add("mapstudio_help", function(ply)
    printLines(ply, {
        "MapStudio " .. MapStudio.Version,
        "Open editor: mapstudio_open",
        "Example bind: bind m mapstudio_open",
        "Validate scene: mapstudio_validate",
        "Save profile: mapstudio_save",
        "Reload profile: mapstudio_reload",
        "Multiplayer ConVars: mapstudio_admin_only, mapstudio_allow_players, mapstudio_whitelist_enabled, mapstudio_allowed_steamids, mapstudio_public_edit_existing",
        "MapStudio places managed objects; it does not edit or recompile BSP terrain."
    })
end)

concommand.Add("mapstudio_import_permaprops", function(ply)
    if not consoleAllowed(ply, "import") then
        return
    end

    local canImport, candidates = MapStudio.Importers.PermaProps.CanImport()
    if not canImport then
        if IsValid(ply) then
            MapStudio.Notify(ply, "import.permaprops.not_found", "error")
        else
            MapStudio.Log("No supported PermaProps data found.")
        end

        return
    end

    local preview = MapStudio.Importers.PermaProps.Preview()

    if IsValid(ply) then
        MapStudio.Notify(ply, "import.permaprops.preview", "info", { count = preview.count })
    else
        MapStudio.Log("PermaProps candidate files: " .. tostring(#candidates) .. ", objects: " .. tostring(preview.count))
    end
end)

concommand.Add("mapstudio_debug_dump", function(ply)
    if not consoleAllowed(ply, "debug") then
        return
    end

    local state = MapStudio.GetState()
    local runtimeCount = table.Count and table.Count(MapStudio.RuntimeEntities) or 0
    local lines = {
        "MapStudio " .. MapStudio.Version,
        "Map: " .. tostring(state.map),
        "Profile: " .. tostring(state.profile),
        "Objects: " .. tostring(MapStudio.GetObjectCount()),
        "Layers: " .. tostring(MapStudio.GetLayerCount()),
        "Runtime entities: " .. tostring(runtimeCount)
    }

    for _, line in ipairs(lines) do
        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTCONSOLE, "[MapStudio] " .. line)
        else
            MapStudio.Log(line)
        end
    end
end)

hook.Add("InitPostEntity", "MapStudio_LoadDefaultProfile", function()
    timer.Simple(1, function()
        local ok, err = MapStudio.LoadActiveProfile(MapStudio.Config.DefaultProfile)

        if ok then
            MapStudio.Log("Loaded " .. MapStudio.Name .. " " .. MapStudio.Version)
        else
            MapStudio.LogError("Initial profile load failed: " .. tostring(err or "error.storage_load_failed"))
        end
    end)
end)
