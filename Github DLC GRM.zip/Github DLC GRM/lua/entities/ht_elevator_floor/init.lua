AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

util.AddNetworkString("HT_Elevator_OpenMenu")
util.AddNetworkString("HT_Elevator_GoTo")

resource.AddFile("sound/tenpenny_tower.mp3")

local SoundProfiles = {
    [0] = { -- Industrial
        Contact = "buttons/button19.wav",
        Open = "doors/door_metal_thin_open1.wav",
        Close = "doors/door_metal_thin_close2.wav",
        Move = "plats/elevator_move_loop1.wav",
        Stop = "plats/elevator_large_stop1.wav",
        Step = "buttons/button17.wav",
        Arrive = "buttons/bell1.wav"
    },
    [1] = { -- Modern
        Contact = "buttons/button15.wav",
        Open = "buttons/combine_button1.wav",
        Close = "buttons/combine_button2.wav",
        Move = "ambient/machines/combine_terminal_loop1.wav",
        Stop = "buttons/combine_button3.wav",
        Step = "buttons/button16.wav",
        Arrive = "buttons/button3.wav"
    },
    [2] = { -- Luxury
        Contact = "npc/turret_floor/active.wav",
        Open = "items/ammocrate_open.wav",
        Close = "items/ammocrate_close.wav",
        Move = "ambient/levels/canals/wind_loop2.wav",
        Stop = "plats/elevator_stop1.wav",
        Step = "buttons/lightswitch2.wav",
        Arrive = "ambient/alarms/warningbell1.wav"
    }
}

function ENT:GetSound(key)
    local profile = SoundProfiles[self:GetSoundArchetype()] or SoundProfiles[0]
    return profile[key] or ""
end

function ENT:Initialize()
    self:SetModel("models/hunter/blocks/cube025x025x025.mdl")
    self:DrawShadow(false)
    
    -- No physics, no collision, no movetype. This entity is purely a data container.
    -- All visuals are rendered client-side via DrawTranslucent in cl_init.lua.
    -- The cube model is hidden by ENT:Draw() returning empty on the client.
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_NONE)
    self:SetUseType(SIMPLE_USE)
    

    if self:GetFloorNumber() == 1 then
        self:SetDoorState(2)
        self.DoorOffset = 36
    else
        self:SetDoorState(0)
        self.DoorOffset = 0  
    end
    
    self:SetCurrentDisplayFloor(self:GetFloorNumber())
    self.MaxDoorOffset = 36
    self:SpawnChamberParts()
end

function ENT:OnRemove()
    if self.MoveSound then
        self.MoveSound:Stop()
    end

    -- When a floor is undone/removed, tell the rest of the system to update their models!
    -- This ensures that if the top floor is removed, the new top floor gets the correct model.
    local sysID = self:GetSystemID()
    timer.Simple(0.1, function()
        local floors = {}
        for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
            if f:GetSystemID() == sysID and f ~= self then
                table.insert(floors, f)
            end
        end
        
        -- Sort and update
        table.sort(floors, function(a, b) return a:GetPos().z < b:GetPos().z end)
        -- Re-number floors by height so the lowest floor is always Floor 1
        for i, f in ipairs(floors) do
            f:SetFloorNumber(i)
            f:SetFloorName("Floor " .. i)
        end
        for i, f in ipairs(floors) do
            local preset = HT_GetPreset(f:GetPreset())
            local mdl = preset.ChamberTop
            if #floors > 1 then
                if i == 1 then
                    mdl = preset.ChamberBase
                elseif i == #floors then
                    mdl = preset.ChamberTop
                end
            end
            f.TargetChamberModel = mdl
            if f.SpawnChamberParts then f:SpawnChamberParts() end
        end
    end)
end

function ENT:SpawnChamberParts()
    for _, part in ipairs({self.PtFloor, self.PtShell, self.DoorL, self.DoorR, self.CallButton, self.BtnInside}) do
        if IsValid(part) then part:Remove() end
    end

    local pos = self:GetPos()
    local ang = self:GetAngles()
    local preset = HT_GetPreset(self:GetPreset())

    local function SpawnPart(model)
        local part = ents.Create("prop_dynamic")
        part:SetModel(model)
        part:SetPos(pos)
        part:SetAngles(ang)
        part:Spawn()
        
        part:SetParent(self)
        self:DeleteOnRemove(part)
        
        -- PhysicsInit creates the actual collision mesh so players bump into it.
        part:PhysicsInit(SOLID_VPHYSICS)
        part:SetSolid(SOLID_VPHYSICS)
        
        -- MOVETYPE_NONE locks it to the world so it can NEVER be pushed.
        part:SetMoveType(MOVETYPE_NONE)
        
        -- Freeze every physics hull as extra safety
        for i = 0, part:GetPhysicsObjectCount() - 1 do
            local p = part:GetPhysicsObjectNum(i)
            if IsValid(p) then p:EnableMotion(false) end
        end
        
        return part
    end

    local chamberMdl = self.TargetChamberModel or preset.ChamberTop
    self.PtFloor = SpawnPart(chamberMdl)
    self.PtShell = SpawnPart(preset.Shell)
    
    -- Apply selected material to the CHAMBER prop, not the elevator frame
    local mat = self:GetShellMaterial()
    if mat and mat ~= "" then
        self.PtFloor:SetMaterial(mat)
    end
    
    -- Lift Skins: default to skin 0 on spawn
    self.PtShell:SetSkin(0)
    

    -- (Prop Call Button removed in favor of 3D2D UI)


    
    self.DoorL = SpawnPart(preset.DoorL)
    
    self.DoorR = nil
    if preset.DoorR and preset.DoorR ~= "" then
        self.DoorR = SpawnPart(preset.DoorR)
    end

    self:UpdateShell()
    self:UpdateDoors()
end

function ENT:UpdateShell()
    if not IsValid(self.PtShell) then return end
    self.PtShell:SetLocalPos(Vector(self:GetShellX(), self:GetShellY(), self:GetShellZ()))
    self.PtShell:SetLocalAngles(self:GetShellAng())
end

function ENT:UpdateDoors()
    local dx = self:GetDoorX()
    local dy = self:GetDoorY()
    local dz = self:GetDoorZ()
    local dAng = self:GetDoorAng()
    local sep = self:GetDoorSep()
    
    local slideOffset = self.DoorOffset

    if IsValid(self.DoorL) then
        local slideL = Vector(slideOffset - sep, 0, 0)
        slideL:Rotate(dAng)
        self.DoorL:SetLocalPos(Vector(dx, dy, dz) + slideL)
        self.DoorL:SetLocalAngles(dAng)
    end
    
    if IsValid(self.DoorR) then
        local slideR = Vector(-slideOffset + sep, 0, 0)
        slideR:Rotate(dAng)
        self.DoorR:SetLocalPos(Vector(dx, dy, dz) + slideR)
        
        if IsValid(self.DoorL) and self.DoorL:GetModel() == self.DoorR:GetModel() then
            local rAng = Angle(dAng.p, dAng.y + 180, dAng.r)
            self.DoorR:SetLocalAngles(rAng)
        else
            self.DoorR:SetLocalAngles(dAng)
        end
    end
end

function ENT:Think()
    local state = self:GetDoorState()
    local targetOffset = (state == 1 or state == 2) and self.MaxDoorOffset or 0
    
    if self.DoorOffset ~= targetOffset then
        self.DoorOffset = math.Approach(self.DoorOffset, targetOffset, FrameTime() * 35)
        self:UpdateDoors()
    end
    
    -- Auto-Close Logic
    if state == 2 and not self.IsTeleporting then
        local acTime = self:GetAutoCloseTime()
        if acTime > 0 then
            self.NextAutoClose = self.NextAutoClose or (CurTime() + acTime)
            if CurTime() > self.NextAutoClose then
                self:SetDoorState(3) -- Close
                self:EmitSound(self:GetSound("Close"), 70, 100)
                self.NextAutoClose = nil
            end
        end
    else
        self.NextAutoClose = nil
    end
    
    -- Synchronize display counter when idle (fixes 0 showing immediately after spawn)
    if not self.IsTeleporting and self:GetCurrentDisplayFloor() ~= self:GetFloorNumber() then
        self:SetCurrentDisplayFloor(self:GetFloorNumber())
    end
    
    if self:GetDebugMode() then
        self:UpdateShell()
        self:UpdateDoors()
    end
    
    self:NextThink(CurTime())
    return true
end

function ENT:Use(activator, caller)
    if IsValid(activator) and activator:IsPlayer() then
        local rayPos = activator:GetShootPos()
        local rayDir = activator:GetAimVector()


        -- 1. Check for CALL BUTTON (Outside/Side Wall)
        local cbAng = self:GetAngles()
        cbAng:RotateAroundAxis(cbAng:Forward(), 90)
        
        local customAng = self:GetCallAng()
        cbAng:RotateAroundAxis(cbAng:Up(), customAng.y)
        cbAng:RotateAroundAxis(cbAng:Right(), customAng.p)
        cbAng:RotateAroundAxis(cbAng:Forward(), customAng.r)

        local cbNormal = cbAng:Up()


        local cX = self:GetCallX()
        local cY = self:GetCallY()
        local cZ = self:GetCallZ()
        local cScale = self:GetCallScale()
        if cScale == 0 then cScale = 0.08 end

        local cbPos = self:LocalToWorld(HT_CALLBUTTON_POS + Vector(cX, cY, cZ))
        local cbIntersect = util.IntersectRayWithPlane(rayPos, rayDir, cbPos, cbNormal)

        if cbIntersect and rayPos:DistToSqr(cbIntersect) < 10000 then
            local diff = cbIntersect - cbPos
            local x = diff:Dot(cbAng:Forward()) / cScale
            local y = diff:Dot(cbAng:Right()) / cScale


            -- Call Button Area: Hit detection for UP/DOWN buttons
            local bw, bh = HT_CALLBUTTON_SIZE.w / 2, HT_CALLBUTTON_SIZE.h / 2
            if x >= -bw and x <= bw and y >= -bh and y <= bh then
                -- Only play sound if we actually hit the UI area
                self:EmitSound(self:GetSound("Contact"))
                
                if self:GetDoorState() == 0 then
                    local currentFloor = nil
                    for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
                        if f:GetSystemID() == self:GetSystemID() and (f:GetDoorState() == 2 or f.IsTeleporting) then
                            currentFloor = f
                            break
                        end
                    end
                    
                    if currentFloor and currentFloor ~= self and not self.IsTeleporting then
                        currentFloor:StartTeleportSequence(self)
                    elseif not self.IsTeleporting then
                        self:SetDoorState(1)
                        self:EmitSound("doors/door_metal_thin_open1.wav", 75, 100, 0.8)
                        timer.Simple(1.5, function()
                            if IsValid(self) then self:SetDoorState(2) end
                        end)
                    end
                end
                return
            end
        end

        -- 2. Check for KEYPAD (Inside/Back Wall)
        -- Keypad Interaction Logic (Server-side)

        local rayPos = activator:GetShootPos()
        local rayDir = activator:GetAimVector()
        local customX = self:GetDisplayX()
        local customY = self:GetDisplayY()
        local customZ = self:GetDisplayZ()
        local scale = self:GetDisplayScale()
        if scale == 0 then scale = 0.08 end
        
        -- Match the client-side display position and orientation using shared constants
        local displayPos = self:LocalToWorld(HT_DISPLAY_POS + Vector(customX, customY, customZ))
        local iAng = self:GetAngles()
        if HT_DISPLAY_ANG_OFFSET then
            iAng:RotateAroundAxis(iAng:Right(), HT_DISPLAY_ANG_OFFSET.p)
            iAng:RotateAroundAxis(iAng:Up(), HT_DISPLAY_ANG_OFFSET.y)
            iAng:RotateAroundAxis(iAng:Forward(), HT_DISPLAY_ANG_OFFSET.r)
        else
            iAng:RotateAroundAxis(iAng:Forward(), 90)
        end
        
        -- Must match client: apply custom display angle offset
        local customAng = self:GetDisplayAng()
        iAng:RotateAroundAxis(iAng:Up(), customAng.y)
        iAng:RotateAroundAxis(iAng:Right(), customAng.p)
        iAng:RotateAroundAxis(iAng:Forward(), customAng.r)
        
        local normal = iAng:Up()
        local intersect = util.IntersectRayWithPlane(rayPos, rayDir, displayPos, normal)
        
        if intersect and rayPos:DistToSqr(intersect) < 10000 then
            local diff = intersect - displayPos
            -- Map to screen coordinates: X is Forward, Y is Right
            local x = diff:Dot(iAng:Forward()) / scale
            local y = diff:Dot(iAng:Right()) / scale
            
            -- Keypad Layout (Synchronized via shared.lua)
            local buttonW, buttonH = 42, 32
            local spacingX, spacingY = 8, 8
            
            for i = 0, 14 do
                local col = i % 3
                local row = math.floor(i / 3)
                local bx = HT_KEYPAD_START_X + (col * (buttonW + spacingX))
                local by = HT_KEYPAD_START_Y + (row * (buttonH + spacingY))
                
                if x >= bx and x <= bx + buttonW and y >= by and y <= by + buttonH then
                    -- Only play sound if we actually hit the UI area
                    self:EmitSound(self:GetSound("Contact"))
                    
                    local floorNum = i + 1

                    local sysID = self:GetSystemID()
                    
                    -- Find target floor
                    local targetFloor = nil
                    for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
                        if f:GetSystemID() == sysID and f:GetFloorNumber() == floorNum then
                            targetFloor = f
                            break
                        end
                    end
                    
                    if targetFloor and targetFloor ~= self then
                        self:EmitSound("buttons/button19.wav", 60, 100)
                        self:StartTeleportSequence(targetFloor)
                    end
                    return
                end
            end
        end
    end
end


net.Receive("HT_Elevator_GoTo", function(len, ply)
    local fromFloor = net.ReadEntity()
    local toFloor = net.ReadEntity()
    
    if not IsValid(fromFloor) or not IsValid(toFloor) then return end
    if fromFloor == toFloor then return end
    if fromFloor.IsTeleporting or toFloor.IsTeleporting then return end
    if ply:GetPos():DistToSqr(fromFloor:GetPos()) > 60000 then return end
    
    fromFloor:StartTeleportSequence(toFloor)
end)

function ENT:StartTeleportSequence(toFloor)
    self.IsTeleporting = true
    toFloor.IsTeleporting = true
    
    self:SetNWBool("HT_IsMoving", true)
    self:SetNWInt("HT_DestFloor", toFloor:GetFloorNumber())
    toFloor:SetNWBool("HT_IsMoving", true)
    toFloor:SetNWInt("HT_DestFloor", toFloor:GetFloorNumber())
    
    self:SetDoorState(3) -- Doors Closing
    self:EmitSound(self:GetSound("Close"), 75, 100, 0.8)
    
    toFloor:SetFloorRequested(true)
    
    timer.Simple(1.5, function()
        if not IsValid(self) then return end
        self:SetDoorState(0) -- Locked closed
        self:EmitSound(self:GetSound("Stop"), 75, 120, 0.6)
        
        if not IsValid(toFloor) then return end
        
        -- Digital Floor Counting Sequence!
        local startNum = self:GetFloorNumber()
        local endNum = toFloor:GetFloorNumber()
        local diff = math.abs(endNum - startNum)
        
        -- Update the Arrow and Call Button on the destination floor
        -- (Physical skin swapping removed for 3D2D integration)

        
        -- 4 seconds per floor traveled!
        local totalDelay = math.max(diff * 4.0, 4.0) 
        
        -- Play a smooth mechanical looping sound for movement
        -- Pitch it up for going up, and down for going down
        local pitch = (endNum > startNum) and 105 or 95
        self.MoveSound = CreateSound(self, Sound(self:GetSound("Move")))
        if self.MoveSound then
            self.MoveSound:PlayEx(0.6, pitch)
        end

        if diff > 0 then
            local stepTime = totalDelay / diff
            for i = 1, diff do
                timer.Simple(stepTime * i, function()
                    if not IsValid(self) then return end
                    local step = endNum > startNum and i or -i
                    self:SetCurrentDisplayFloor(startNum + step)
                    self:EmitSound(self:GetSound("Step"), 65, 120, 0.5)
                end)
            end
        end
        
        -- Extended dynamically scaled delay in darkness before the snap
        timer.Simple(totalDelay, function()
            -- Always safely stop the self teleporting lock, even if aborted
            if IsValid(self) then
                self.IsTeleporting = false
                self:SetNWBool("HT_IsMoving", false)
                -- Reset display back to this floor's own number now that the cab has left
                self:SetCurrentDisplayFloor(self:GetFloorNumber())
                if self.MoveSound then
                    self.MoveSound:Stop()
                end
                self:EmitSound(self:GetSound("Stop"), 75, 100, 0.8) -- Arrival heavy clunk
            end
            
            -- If either the start or destination elevators were deleted, violently abort the teleport
            if not IsValid(self) or not IsValid(toFloor) then 
                if IsValid(toFloor) then toFloor.IsTeleporting = false end
                return 
            end
            
            local b1 = self:GetPos() - Vector(60, 60, 10)
            local b2 = self:GetPos() + Vector(60, 60, 130)
            local minLine = Vector(math.min(b1.x, b2.x), math.min(b1.y, b2.y), math.min(b1.z, b2.z))
            local maxLine = Vector(math.max(b1.x, b2.x), math.max(b1.y, b2.y), math.max(b1.z, b2.z))
            
            for _, ent in ipairs(ents.FindInBox(minLine, maxLine)) do
                -- Only move players - stop it from moving props
                if IsValid(ent) and ent:IsPlayer() then
                    local offset = self:WorldToLocal(ent:GetPos())
                    local newPos = toFloor:LocalToWorld(offset)
                    
                    local angDiff = toFloor:GetAngles().y - self:GetAngles().y
                    
                    local eyeAng = ent:EyeAngles()
                    eyeAng.y = eyeAng.y + angDiff
                    ent:SetPos(newPos)
                    ent:SetEyeAngles(eyeAng)
                end
            end
            
            -- Wait another delay at new floor before opening doors
            timer.Simple(0.5, function()
                if not IsValid(toFloor) then return end
                

                -- (Physical skin swapping removed for 3D2D integration)

                
                toFloor:SetDoorState(1) -- Opening
                toFloor:EmitSound(self:GetSound("Arrive"), 80, 100, 1) -- Classic Arrival Ding!
                toFloor:EmitSound(self:GetSound("Open"), 75, 100, 0.8)
                
                timer.Simple(1.5, function()
                    if IsValid(toFloor) then
                        toFloor:SetDoorState(2) -- Locked open
                        toFloor.IsTeleporting = false
                        toFloor:SetNWBool("HT_IsMoving", false)
                        toFloor:SetFloorRequested(false)
                        -- Ensure destination display shows the correct floor number
                        toFloor:SetCurrentDisplayFloor(toFloor:GetFloorNumber())
                    end
                end)
                
                -- (Skin reversion disabled)
            end)
        end)
    end)
end

-- ADVANCED DUPLICATOR 2 SUPPORT
-- PreEntityCopy is the primary hook AdvDupe2 uses to serialize entity data
function ENT:PreEntityCopy()
    -- Save gap filler data from tracked gap fillers
    local fillers = {}
    if self.GapFillerEnts then
        for _, filler in ipairs(self.GapFillerEnts) do
            if IsValid(filler) then
                local localPos = self:WorldToLocal(filler:GetPos())
                local localAng = self:WorldToLocalAngles(filler:GetAngles())
                table.insert(fillers, {
                    Model = filler:GetModel(),
                    LocalPos = localPos,
                    LocalAng = localAng,
                    Mat = filler:GetMaterial()
                })
            end
        end
    end
    
    print("[EasyElevator] PreEntityCopy: Saving " .. #fillers .. " gap fillers for floor " .. self:GetFloorNumber())

    local d = {
        SystemID = self:GetSystemID(),
        FloorNumber = self:GetFloorNumber(),
        FloorName = self:GetFloorName(),
        ShellMaterial = self:GetShellMaterial(),
        SoundArchetype = self:GetSoundArchetype(),
        AutoCloseTime = self:GetAutoCloseTime(),
        Preset = self:GetPreset(),
        Display = { x = self:GetDisplayX(), y = self:GetDisplayY(), z = self:GetDisplayZ(), s = self:GetDisplayScale(), a = self:GetDisplayAng() },
        Sign = { x = self:GetSignX(), y = self:GetSignY(), z = self:GetSignZ(), s = self:GetSignScale(), a = self:GetSignAng() },
        Call = { x = self:GetCallX(), y = self:GetCallY(), z = self:GetCallZ(), s = self:GetCallScale(), a = self:GetCallAng() },
        Over = { x = self:GetOverX(), y = self:GetOverY(), z = self:GetOverZ(), s = self:GetOverScale(), a = self:GetOverAng() },
        ShellOffsets = { x = self:GetShellX(), y = self:GetShellY(), z = self:GetShellZ(), a = self:GetShellAng() },
        DoorOffsets = { x = self:GetDoorX(), y = self:GetDoorY(), z = self:GetDoorZ(), sep = self:GetDoorSep(), a = self:GetDoorAng() },
        GapFillers = fillers
    }
    -- StoreEntityModifier is what AdvDupe2 reads when saving
    duplicator.StoreEntityModifier(self, "HT_Elevator_Data", d)
end

function ENT:OnPostEntityPaste(ply, ent, createdEntities)
    -- Restore state and rebuild models after paste
    timer.Simple(0.1, function()
        if not IsValid(self) then return end

        -- Always rebuild chamber parts — even if no EntityMods exist
        self:SpawnChamberParts()

        -- Restore all saved data from the HT_Elevator_Data entity modifier
        if self.EntityMods and self.EntityMods.HT_Elevator_Data then
            local d = self.EntityMods.HT_Elevator_Data

            -- Core identity
            if d.SystemID      then self:SetSystemID(d.SystemID)           end
            if d.FloorNumber   then self:SetFloorNumber(d.FloorNumber)     end
            if d.FloorName     then self:SetFloorName(d.FloorName)         end
            if d.ShellMaterial then self:SetShellMaterial(d.ShellMaterial) end
            if d.SoundArchetype ~= nil then self:SetSoundArchetype(d.SoundArchetype) end
            if d.AutoCloseTime  ~= nil then self:SetAutoCloseTime(d.AutoCloseTime)   end
            if d.Preset         ~= nil then self:SetPreset(d.Preset)                 end

            -- UI offsets
            if d.Display then
                self:SetDisplayX(d.Display.x) self:SetDisplayY(d.Display.y) self:SetDisplayZ(d.Display.z)
                self:SetDisplayScale(d.Display.s) self:SetDisplayAng(d.Display.a)
            end
            if d.Sign then
                self:SetSignX(d.Sign.x) self:SetSignY(d.Sign.y) self:SetSignZ(d.Sign.z)
                self:SetSignScale(d.Sign.s) self:SetSignAng(d.Sign.a)
            end
            if d.Call then
                self:SetCallX(d.Call.x) self:SetCallY(d.Call.y) self:SetCallZ(d.Call.z)
                self:SetCallScale(d.Call.s) self:SetCallAng(d.Call.a)
            end
            if d.Over then
                self:SetOverX(d.Over.x) self:SetOverY(d.Over.y) self:SetOverZ(d.Over.z)
                self:SetOverScale(d.Over.s) self:SetOverAng(d.Over.a)
            end

            -- Physical model offsets
            if d.ShellOffsets then
                self:SetShellX(d.ShellOffsets.x) self:SetShellY(d.ShellOffsets.y)
                self:SetShellZ(d.ShellOffsets.z) self:SetShellAng(d.ShellOffsets.a)
            end
            if d.DoorOffsets then
                self:SetDoorX(d.DoorOffsets.x) self:SetDoorY(d.DoorOffsets.y) self:SetDoorZ(d.DoorOffsets.z)
                if d.DoorOffsets.sep then self:SetDoorSep(d.DoorOffsets.sep) end
                self:SetDoorAng(d.DoorOffsets.a)
            end

            -- Re-spawn gap fillers (inside this block — local d must be in scope)
            if d.GapFillers and #d.GapFillers > 0 then
                self.GapFillerEnts = {}
                for _, fData in ipairs(d.GapFillers) do
                    local filler = ents.Create("prop_dynamic")
                    filler:SetModel(fData.Model)
                    filler:SetPos(self:LocalToWorld(fData.LocalPos))
                    filler:SetAngles(self:LocalToWorldAngles(fData.LocalAng))
                    filler:SetParent(self)
                    self:DeleteOnRemove(filler)
                    filler:Spawn()
                    if fData.Mat and fData.Mat ~= "" then
                        filler:SetMaterial(fData.Mat)
                    end
                    filler:SetSolid(SOLID_NONE)
                    filler:SetCollisionGroup(COLLISION_GROUP_WORLD)
                    filler:DrawShadow(false)
                    table.insert(self.GapFillerEnts, filler)
                end
            end
        end -- end if self.EntityMods

        -- Re-number all floors in this system by height (lowest = Floor 1)
        local sysID = self:GetSystemID()
        local systemFloors = {}
        for _, sf in ipairs(ents.FindByClass("ht_elevator_floor")) do
            if sf:GetSystemID() == sysID then table.insert(systemFloors, sf) end
        end

        table.sort(systemFloors, function(a, b) return a:GetPos().z < b:GetPos().z end)
        for i, sf in ipairs(systemFloors) do
            sf:SetFloorNumber(i)
            sf:SetFloorName("Floor " .. i)
        end

        -- Refresh chamber models for every floor in the system
        for i, sf in ipairs(systemFloors) do
            local preset = HT_GetPreset(sf:GetPreset())
            sf.TargetChamberModel = (i == 1) and preset.ChamberBase or preset.ChamberTop
            if sf.SpawnChamberParts then sf:SpawnChamberParts() end
        end
    end)
end

-- AdvDupe2 calls PostEntityPaste; standard GMod duplicator calls OnPostEntityPaste.
-- Alias one to the other so both systems fire our restoration logic.
ENT.PostEntityPaste = ENT.OnPostEntityPaste

-- Register for duplication support (AdvDupe2, standard Duplicator, etc.)
-- This function is called by duplicator.CreateEntityFromTable when pasting.
-- When AdvDupe2 has "Data" in the Args list it passes the FULL serialized entity
-- table as the data argument (see AdvDupe2 sv_clipboard.lua:1035-1037).
-- The standard GMod save system extracts entity["Data"] which is nil, so we
-- guard `if data` before calling DoGeneric to avoid a crash.
-- NOTE: We do NOT call ApplyEntityModifiers here because AdvDupe2 copies EntityMods
-- onto the entity AFTER this function returns, then calls its own ApplyEntityModifiers.
duplicator.RegisterEntityClass("ht_elevator_floor", function(ply, data)
    local ent = ents.Create("ht_elevator_floor")
    if not IsValid(ent) then return end

    -- data is the full entity table from AdvDupe2, or nil from standard GMod save
    if data and type(data) == "table" then
        duplicator.DoGeneric(ent, data)
    end

    ent:Spawn()
    ent:Activate()

    return ent
end, "Data")
