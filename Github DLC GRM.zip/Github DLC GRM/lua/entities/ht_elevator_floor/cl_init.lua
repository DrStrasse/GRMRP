include("shared.lua")

local ElevatorMusicSound = Sound("tenpenny_tower.mp3")

-- Floor display fonts
-- Floor display fonts (Strict Tahoma rule)
surface.CreateFont("HT_Lantern_Small", { font = "Tahoma", size = 20, weight = 800, scanlines = 2, antialias = true })
surface.CreateFont("HT_Lantern_Large", { font = "Tahoma", size = 45, weight = 900, antialias = true })


-- Only one music source per elevator system, tracked globally
HT_MusicSources = HT_MusicSources or {}

-- Keypad/Display Constants are now in shared.lua

function ENT:Initialize()
    self:SetRenderBounds(Vector(-60, -60, -10), Vector(60, 60, 150))
    self.MusicInitialized = false
    self.SmoothFloor = 1
end

function ENT:Think()
    if self:GetRenderGroup() ~= RENDERGROUP_BOTH then
        self:SetRenderGroup(RENDERGROUP_BOTH)
    end
    
    -- Force Think to run every frame on the client so 3D2D hit detection NEVER lags!
    self:NextThink(CurTime())

    -- Lazy-init music: NetworkVars (SystemID) aren't ready during Initialize()
    local sysID = self:GetSystemID()
    local musicEnabled = GetConVar("ht_elevator_music"):GetBool()
    local musicVar = GetConVar("ht_elevator_music_volume")
    local musicVol = musicVar and musicVar:GetFloat() or 0.6

    if sysID and sysID > 0 then
        -- Play music if enabled and we should own it
        if musicEnabled then
            if not HT_MusicSources[sysID] or not IsValid(HT_MusicSources[sysID]) then
                HT_MusicSources[sysID] = self
                if not self.ElevatorMusic then
                    self.ElevatorMusic = CreateSound(self, ElevatorMusicSound)
                end
                
                if self.ElevatorMusic and not self.ElevatorMusic:IsPlaying() then
                    self.ElevatorMusic:PlayEx(musicVol, 100)
                    self.ElevatorMusic:SetSoundLevel(40)
                end
            end
            
            -- Dynamically update volume if this floor owns the music
            if HT_MusicSources[sysID] == self and self.ElevatorMusic and self.ElevatorMusic:IsPlaying() then
                self.ElevatorMusic:ChangeVolume(musicVol, 0)
            end
        else
            -- Stop music if disabled
            if self.ElevatorMusic and self.ElevatorMusic:IsPlaying() then
                self.ElevatorMusic:Stop()
            end
            
            if HT_MusicSources[sysID] == self then
                HT_MusicSources[sysID] = nil
            end
        end
    end

    -- Handle keypad interaction
    if IsValid(LocalPlayer()) then
        local rayPos = LocalPlayer():GetShootPos()
        local rayDir = LocalPlayer():GetAimVector()
        
        local iAng = self:GetAngles()
        if HT_DISPLAY_ANG_OFFSET then
            iAng:RotateAroundAxis(iAng:Right(), HT_DISPLAY_ANG_OFFSET.p)
            iAng:RotateAroundAxis(iAng:Up(), HT_DISPLAY_ANG_OFFSET.y)
            iAng:RotateAroundAxis(iAng:Forward(), HT_DISPLAY_ANG_OFFSET.r)
        else
            iAng:RotateAroundAxis(iAng:Forward(), 90)
        end
        
        -- Must match DrawTranslucent: apply custom display angle offset
        local customAng = self:GetDisplayAng()
        iAng:RotateAroundAxis(iAng:Up(), customAng.y)
        iAng:RotateAroundAxis(iAng:Right(), customAng.p)
        iAng:RotateAroundAxis(iAng:Forward(), customAng.r)
        
        local customX = self:GetDisplayX()
        local customY = self:GetDisplayY()
        local customZ = self:GetDisplayZ()
        local scale = self:GetDisplayScale()
        if scale == 0 then scale = 0.08 end
        
        local displayPos = self:LocalToWorld(HT_DISPLAY_POS + Vector(customX, customY, customZ))

        
        local normal = iAng:Up()
        local intersect = util.IntersectRayWithPlane(rayPos, rayDir, displayPos, normal)
        
        if intersect and rayPos:DistToSqr(intersect) < 10000 then
            local diff = intersect - displayPos
            -- X axis = Forward, Y axis = Right
            local x = diff:Dot(iAng:Forward()) / scale
            local y = diff:Dot(iAng:Right()) / scale

            
            self.LastHoverX = x
            self.LastHoverY = y
            self.IsPressing = LocalPlayer():KeyDown(IN_USE)
        else
            self.LastHoverX = nil
            self.LastHoverY = nil
            self.IsPressing = false
        end

        -- Call Button Interaction (Outside)
        local cbAng = self:GetAngles()
        cbAng:RotateAroundAxis(cbAng:Forward(), 90)
        
        local customAng = self:GetCallAng()
        cbAng:RotateAroundAxis(cbAng:Up(), customAng.y)
        cbAng:RotateAroundAxis(cbAng:Right(), customAng.p)
        cbAng:RotateAroundAxis(cbAng:Forward(), customAng.r)

        local cbNormal = cbAng:Up()






        local cX = self:GetCallX()
        local cY = self:GetCallY()
        local cZ = self:GetCallZ()
        local cScale = self:GetCallScale()
        if cScale == 0 then cScale = 0.08 end

        local cbPos = self:LocalToWorld(HT_CALLBUTTON_POS + Vector(cX, cY, cZ))
        local cbIntersect = util.IntersectRayWithPlane(rayPos, rayDir, cbPos, cbNormal)
        
        self.CBHover = nil
        if cbIntersect and rayPos:DistToSqr(cbIntersect) < 10000 then
            local diff = cbIntersect - cbPos
            local x = diff:Dot(cbAng:Forward()) / cScale
            local y = diff:Dot(cbAng:Right()) / cScale

            
            local bw, bh = HT_CALLBUTTON_SIZE.w / 2, HT_CALLBUTTON_SIZE.h / 2
            if x >= -bw and x <= bw and y >= -bh and y <= bh then
                self.CBHover = {x = x, y = y}
                self.CBIsPressing = LocalPlayer():KeyDown(IN_USE)
            end

        end
    end

    -- Smooth Floor Counter
    local target = self:GetCurrentDisplayFloor()
    self.SmoothFloor = math.Approach(self.SmoothFloor or target, target, FrameTime() * 2)
    
    return true
end


function ENT:OnRemove()
    if self.ElevatorMusic then
        self.ElevatorMusic:Stop()
    end
    
    -- Release ownership so another floor can take over if this one is removed
    local sysID = self:GetSystemID()
    if sysID and HT_MusicSources[sysID] == self then
        HT_MusicSources[sysID] = nil
    end
end

surface.CreateFont("HT_Level_Label", { font = "CloseCaption_Bold", size = 18, weight = 1000 })
surface.CreateFont("HT_Level_Number", { font = "CloseCaption_Bold", size = 52, weight = 1000 })
surface.CreateFont("HT_Chevron", { font = "CloseCaption_Bold", size = 26, weight = 1000 })

local function DrawDisplayPlate(text, font, textColor, borderColor, w, h)
    draw.RoundedBox(4, -w / 2, -h / 2, w, h, Color(10, 10, 10, 240))
    surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, 200)
    surface.DrawOutlinedRect(-w / 2, -h / 2, w, h, 2)
    surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, 60)
    surface.DrawOutlinedRect(-w / 2 + 3, -h / 2 + 3, w - 6, h - 6, 1)
    draw.SimpleText(text, font, 0, 0, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end

local function DrawInsideKeypad(ent, floors, currentDisplayFloor, w, h, xOffset, yOffset)
    local buttonW, buttonH = 42, 32
    local spacingX, spacingY = 8, 8
    local startX = HT_KEYPAD_START_X
    local startY = HT_KEYPAD_START_Y
    
    local hX, hY = ent.LastHoverX or -999, ent.LastHoverY or -999
    local floorMap = {}
    for _, f in ipairs(floors) do
        floorMap[f:GetFloorNumber()] = f
    end

    for i = 0, 14 do
        local floorNum = i + 1
        local col = i % 3
        local row = math.floor(i / 3)
        
        local bx = startX + (col * (buttonW + spacingX))
        local by = startY + (row * (buttonH + spacingY))
        
        local exists = floorMap[floorNum]
        local isCurrent = (floorNum == currentDisplayFloor)
        local isHovered = (hX >= bx and hX <= bx + buttonW and hY >= by and hY <= by + buttonH)
        local isPressed = isHovered and ent.IsPressing
        
        -- Press animation: slightly sink the button
        local push = isPressed and 2 or 0
        local drawX, drawY = bx, by + push

        -- 1. GLOW HALO (Drawn behind the button)
        if exists and (isHovered or isCurrent) then
            local glowCol = isCurrent and Color(255, 100, 0) or Color(255, 200, 50)
            if isPressed then glowCol = Color(255, 255, 200) end
            
            local alphaBase = isPressed and 150 or (isHovered and 100 or 40)
            
            -- Multi-layered Bloom
            for bloom = 1, 3 do
                local expand = bloom * 3
                surface.SetDrawColor(glowCol.r, glowCol.g, glowCol.b, alphaBase / (bloom * 1.5))
                draw.RoundedBox(4, drawX - expand, drawY - expand, buttonW + (expand * 2), buttonH + (expand * 2), Color(glowCol.r, glowCol.g, glowCol.b, alphaBase / (bloom * 1.5)))
            end
        end

        -- 2. BUTTON BASE
        local bgCol = isHovered and Color(50, 50, 50) or Color(20, 20, 20)
        if isPressed then bgCol = Color(120, 120, 100) end
        draw.RoundedBox(4, drawX, drawY, buttonW, buttonH, bgCol)
        
        -- 3. INTERACTABLE DETAILS
        if exists then
            local borderAlpha = (isCurrent or isHovered) and 255 or 60
            local borderCol = isCurrent and Color(255, 120, 0, borderAlpha) or Color(150, 70, 0, borderAlpha)
            if isHovered then borderCol = Color(255, 220, 100, borderAlpha) end
            if isPressed then borderCol = Color(255, 255, 255, 255) end
            
            surface.SetDrawColor(borderCol)
            surface.DrawOutlinedRect(drawX, drawY, buttonW, buttonH, 1)
            
            -- Internal 'Lit' look
            if isHovered or isCurrent then
                surface.SetDrawColor(borderCol.r, borderCol.g, borderCol.b, isPressed and 100 or 30)
                surface.DrawRect(drawX + 2, drawY + 2, buttonW - 4, buttonH - 4)
            end
            
            -- Text with shadow/glow
            local textColor = isCurrent and Color(255, 180, 0) or Color(200, 100, 0)
            if isHovered then textColor = Color(255, 255, 150) end
            if isPressed then textColor = Color(255, 255, 255) end
            
            -- Subtle text shadow for depth
            draw.SimpleText(tostring(floorNum), "HT_Level_Label", drawX + buttonW/2 + 1, drawY + buttonH/2 + 1, Color(0,0,0,150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            draw.SimpleText(tostring(floorNum), "HT_Level_Label", drawX + buttonW/2, drawY + buttonH/2, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        else
            -- Non-existent button (dark metal placeholder)
            surface.SetDrawColor(30, 30, 30, 150)
            surface.DrawOutlinedRect(drawX, drawY, buttonW, buttonH, 1)
            draw.SimpleText("•", "HT_Level_Label", drawX + buttonW/2, drawY + buttonH/2, Color(40,40,40), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end
end

local function DrawInsideDisplayPlate(ent, floorNum, w, h, isMoving, srcFloor, destFloor, floors)
    -- Panel Dimensions
    local totalW = 160
    local totalH = 340
    
    -- 1. MAIN BACKGROUND (Centered at 0,0)
    draw.RoundedBox(4, -totalW / 2, -totalH / 2, totalW, totalH, Color(30, 30, 30, 255))
    surface.SetDrawColor(60, 60, 60, 255)
    surface.DrawOutlinedRect(-totalW / 2, -totalH / 2, totalW, totalH, 2)

    -- 2. DISPLAY AREA (Top half)
    local dispY = -140
    draw.RoundedBox(2, -w / 2, dispY, w, h, Color(10, 10, 10, 255))
    surface.SetDrawColor(255, 140, 0, 100)
    surface.DrawOutlinedRect(-w / 2, dispY, w, h, 2)
    
    -- "level:" label
    draw.SimpleText("level:", "HT_Level_Label", -w / 2 + 10, dispY + 5, Color(255, 160, 0, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    
    -- Large Floor Number (Scrolling)
    local sFloor = ent.SmoothFloor or floorNum
    local floorInt = math.floor(sFloor)
    local frac = sFloor - floorInt
    
    render.SetScissorRect(0, 0, ScrW(), ScrH(), true) -- Simplified; we'll use a local offset instead
    
    local function DrawScrollingNum(num, alpha, offset)
        draw.SimpleText(tostring(num), "HT_Level_Number", -w / 2 + 15, dispY + h/2 + 6 + offset, Color(255, 160, 0, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    
    DrawScrollingNum(floorInt, 255 * (1 - frac), -frac * 40)
    if frac > 0 then
        DrawScrollingNum(floorInt + 1, 255 * frac, 40 - (frac * 40))
    end
    
    -- Chevron direction
    local moveDir = 0
    if isMoving and destFloor ~= srcFloor then
        moveDir = destFloor > srcFloor and 1 or -1
    end
    
    local chevX = w / 2 - 16
    local chevY = dispY + h/2
    if moveDir ~= 0 then
        local t = (CurTime() * 4) % 3
        local symbol = moveDir > 0 and "▲" or "▼"
        for i = 0, 2 do
            local lit = (moveDir > 0 and t >= i) or (moveDir < 0 and t >= (2 - i))
            local col = lit and Color(255, 160, 0, 255) or Color(90, 40, 0, 150)
            draw.SimpleText(symbol, "HT_Chevron", chevX, chevY + (i - 1) * 12, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    else
        for i = 0, 2 do
            draw.SimpleText("—", "HT_Chevron", chevX, chevY + (i - 1) * 12, Color(255, 140, 0, 40), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    -- 3. KEYPAD RECESSED AREA (Bottom half)
    local recW = totalW - 10
    local recH = 210
    local recY = -70
    draw.RoundedBox(0, -recW / 2, recY, recW, recH, Color(15, 15, 15, 255))
    surface.SetDrawColor(0, 0, 0, 255)
    surface.DrawOutlinedRect(-recW / 2, recY, recW, recH, 1)

    -- Draw Keypad (drawn relative to center 0,0)
    DrawInsideKeypad(ent, floors, floorNum, w, h, 0, 0)
end

local function DrawChevrons(x, y, w, h, direction, color)
    -- direction: 1 for Up, -1 for Down
    local time = CurTime() * 3
    local spacing = 20
    local count = 3
    
    for i = 1, count do
        local offset = ( (time + (i * (spacing/count))) % spacing ) - (spacing/2)
        if direction == -1 then
            offset = -offset
        end
        
        local cy = y + offset
        local alpha = 255 * (1 - math.abs(offset) / (spacing/2))
        local col = Color(color.r, color.g, color.b, alpha)
        
        surface.SetDrawColor(col)
        local cw, ch = w, h
        if direction == 1 then
            -- Up Chevron ^
            surface.DrawLine(x - cw, cy + ch, x, cy)
            surface.DrawLine(x, cy, x + cw, cy + ch)
        else
            -- Down Chevron v
            surface.DrawLine(x - cw, cy - ch, x, cy)
            surface.DrawLine(x, cy, x + cw, cy - ch)
        end
    end
end

local function DrawOverDoorDisplay(ent, floorNum, isMoving, srcFloor, destFloor)

    local w, h = HT_OVERDOOR_SIZE.w, HT_OVERDOOR_SIZE.h
    
    if ent:GetDebugMode() then
        surface.SetDrawColor(255, 0, 0, 100)
        surface.DrawOutlinedRect(-w/2, -h/2, w, h, 2)
        surface.DrawLine(-5, 0, 5, 0)
        surface.DrawLine(0, -5, 0, 5)
    end

    -- Background shell
    draw.RoundedBox(4, -w/2, -h/2, w, h, Color(20, 20, 20, 255))
    surface.SetDrawColor(40, 40, 40, 255)
    surface.DrawOutlinedRect(-w/2, -h/2, w, h, 2)
    
    -- Floor Number (Scrolling)
    local sFloor = ent.SmoothFloor or floorNum
    local floorInt = math.floor(sFloor)
    local frac = sFloor - floorInt
    
    local function DrawScrollingNum(num, alpha, offset)
        draw.SimpleText(tostring(num), "HT_Lantern_Large", 0, offset, Color(255, 160, 0, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    DrawScrollingNum(floorInt, 255 * (1 - frac), -frac * 30)
    if frac > 0 then
        DrawScrollingNum(floorInt + 1, 255 * frac, 30 - (frac * 30))
    end
end

local function DrawHallwaySign(ent, floorNum)
    local w, h = HT_FLOORSIGN_SIZE.w, HT_FLOORSIGN_SIZE.h

    if ent:GetDebugMode() then
        surface.SetDrawColor(0, 255, 0, 100)
        surface.DrawOutlinedRect(-w/2, -h/2, w, h, 2)
    end

    -- Background
    draw.RoundedBox(8, -w/2, -h/2, w, h, Color(20, 20, 20, 255))
    surface.SetDrawColor(255, 160, 0, 100)
    surface.DrawOutlinedRect(-w/2, -h/2, w, h, 2)

    local isMoving = ent:GetNWBool("HT_IsMoving", false)
    local srcFloor = ent:GetFloorNumber()
    local destFloor = ent:GetNWInt("HT_DestFloor", srcFloor)
    
    draw.SimpleText(floorNum, "HT_Lantern_Large", 0, 0, Color(255, 200, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    draw.SimpleText("FLOOR", "HT_Lantern_Small", 0, 32, Color(255, 160, 0, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
end




local function DrawCallButton(ent)
    local w, h = HT_CALLBUTTON_SIZE.w, HT_CALLBUTTON_SIZE.h

    if ent:GetDebugMode() then
        surface.SetDrawColor(0, 0, 255, 100)
        surface.DrawOutlinedRect(-w/2, -h/2, w, h, 2)
    end

    -- Background


    draw.RoundedBox(4, -w/2, -h/2, w, h, Color(30, 30, 30, 255))
    surface.SetDrawColor(60, 60, 60, 255)
    surface.DrawOutlinedRect(-w/2, -h/2, w, h, 2)
    
    local isHovered = ent.CBHover ~= nil
    local isPressed = ent.CBIsPressing
    
    local function DrawButton(x, y, label, active)
        local bw, bh = (w - 14), (h / 2) - 15
        local bx, by = -bw/2, y - bh/2

        
        local col = active and Color(255, 160, 0) or Color(20, 20, 20)
        local textCol = active and Color(255, 255, 255) or Color(150, 80, 0)
        
        if isHovered then
            local hx, hy = ent.CBHover.x, ent.CBHover.y
            if hx >= bx and hx <= bx + bw and hy >= by and hy <= by + bh then
                col = isPressed and Color(255, 200, 100) or Color(60, 60, 60)
                textCol = Color(255, 220, 150)
            end
        end
        
        draw.RoundedBox(4, bx, by, bw, bh, col)
        surface.SetDrawColor(textCol.r, textCol.g, textCol.b, 100)
        surface.DrawOutlinedRect(bx, by, bw, bh, 1)
        
        draw.SimpleText(label, "DermaDefaultBold", 0, y, textCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    
    DrawButton(0, -20, "▲", ent:GetDoorState() == 1 or ent:GetDoorState() == 2 or ent:GetFloorRequested())
    DrawButton(0, 20, "▼", ent:GetDoorState() == 1 or ent:GetDoorState() == 2 or ent:GetFloorRequested())
end


function ENT:Draw()
    -- Deliberately empty! NOT calling self:DrawModel() keeps the root cube correctly invisible.
end

function ENT:DrawTranslucent()
    local isMoving  = self:GetNWBool("HT_IsMoving", false)
    local srcFloor  = self:GetFloorNumber()
    local destFloor = self:GetNWInt("HT_DestFloor", srcFloor)
    local displayNum = self:GetCurrentDisplayFloor()

    -- 1. OVER-DOOR DISPLAY (New Arrival Lantern)
    local oAng = self:GetAngles()
    oAng:RotateAroundAxis(oAng:Forward(), 90)
    
    local customAng = self:GetOverAng()
    oAng:RotateAroundAxis(oAng:Up(), customAng.y)
    oAng:RotateAroundAxis(oAng:Right(), customAng.p)
    oAng:RotateAroundAxis(oAng:Forward(), customAng.r)

    local oX = self:GetOverX()

    local oY = self:GetOverY()
    local oZ = self:GetOverZ()
    local oScale = self:GetOverScale()
    if oScale == 0 then oScale = 0.08 end

    local lanternPos = self:LocalToWorld(HT_OVERDOOR_POS + Vector(oX, oY, oZ))
    
    cam.Start3D2D(lanternPos, oAng, oScale)
        DrawOverDoorDisplay(self, displayNum, isMoving, srcFloor, destFloor)
    cam.End3D2D()


    -- 2. OUTSIDE CALL BUTTON: Custom UI
    local cbAng = self:GetAngles()
    cbAng:RotateAroundAxis(cbAng:Forward(), 90)
    
    local customAng = self:GetCallAng()
    cbAng:RotateAroundAxis(cbAng:Up(), customAng.y)
    cbAng:RotateAroundAxis(cbAng:Right(), customAng.p)
    cbAng:RotateAroundAxis(cbAng:Forward(), customAng.r)

    local cX = self:GetCallX()

    local cY = self:GetCallY()
    local cZ = self:GetCallZ()
    local cScale = self:GetCallScale()
    if cScale == 0 then cScale = 0.08 end

    local cbPos = self:LocalToWorld(HT_CALLBUTTON_POS + Vector(cX, cY, cZ))
    
    cam.Start3D2D(cbPos, cbAng, cScale)
        DrawCallButton(self)
    cam.End3D2D()



    -- 3. INSIDE DISPLAY: always render on every floor.
    local iAng = self:GetAngles()
    if HT_DISPLAY_ANG_OFFSET then
        iAng:RotateAroundAxis(iAng:Right(), HT_DISPLAY_ANG_OFFSET.p)
        iAng:RotateAroundAxis(iAng:Up(), HT_DISPLAY_ANG_OFFSET.y)
        iAng:RotateAroundAxis(iAng:Forward(), HT_DISPLAY_ANG_OFFSET.r)
    else
        iAng:RotateAroundAxis(iAng:Forward(), 90)
    end

    local customAng = self:GetDisplayAng()
    iAng:RotateAroundAxis(iAng:Up(), customAng.y)
    iAng:RotateAroundAxis(iAng:Right(), customAng.p)
    iAng:RotateAroundAxis(iAng:Forward(), customAng.r)


    local basePos = Vector(HT_DISPLAY_POS.x, HT_DISPLAY_POS.y, HT_DISPLAY_POS.z)
    
    local customX = self:GetDisplayX()
    local customY = self:GetDisplayY()
    local customZ = self:GetDisplayZ()
    local scale = self:GetDisplayScale()
    if scale == 0 then scale = 0.08 end

    basePos.x = basePos.x + customX
    basePos.y = basePos.y + customY
    basePos.z = basePos.z + customZ

    local inPos = self:LocalToWorld(basePos)
    HT_DISPLAY_SIZE = HT_DISPLAY_SIZE or {w = 160, h = 60}

    cam.Start3D2D(inPos, iAng, scale)
        -- Get all floors in the system to check availability
        local sysID = self:GetSystemID()
        local floors = {}
        for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
            if f:GetSystemID() == sysID then
                table.insert(floors, f)
            end
        end
        DrawInsideDisplayPlate(self, displayNum, HT_DISPLAY_SIZE.w, HT_DISPLAY_SIZE.h, isMoving, srcFloor, destFloor, floors)
    cam.End3D2D()

    -- 4. HALLWAY FLOOR SIGN
    local hAng = self:GetAngles()
    hAng:RotateAroundAxis(hAng:Forward(), 90)
    
    local customAng = self:GetSignAng()
    hAng:RotateAroundAxis(hAng:Up(), customAng.y)
    hAng:RotateAroundAxis(hAng:Right(), customAng.p)
    hAng:RotateAroundAxis(hAng:Forward(), customAng.r)

    local sX = self:GetSignX()

    local sY = self:GetSignY()
    local sZ = self:GetSignZ()
    local sScale = self:GetSignScale()
    if sScale == 0 then sScale = 0.15 end

    local signPos = self:LocalToWorld(HT_FLOORSIGN_POS + Vector(sX, sY, sZ))
    cam.Start3D2D(signPos, hAng, sScale)
        DrawHallwaySign(self, displayNum)
    cam.End3D2D()





end


-- Legacy Menu Removed: Interaction is now exclusive to the physical keypad.

