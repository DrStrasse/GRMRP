if ENT then
    ENT.Type = "anim"
    ENT.Base = "base_gmodentity"
    ENT.PrintName = "Modular Elevator Floor"
    ENT.Author = "Antigravity"
    ENT.Spawnable = false
    ENT.RenderGroup = RENDERGROUP_BOTH

    function ENT:SetupDataTables()
        self:NetworkVar("Int", 0, "SystemID")
        self:NetworkVar("Int", 1, "FloorNumber")
        self:NetworkVar("String", 0, "FloorName")
        self:NetworkVar("Int", 2, "DoorState") -- 0: Closed, 1: Opening, 2: Open, 3: Closing
        self:NetworkVar("Int", 3, "CurrentDisplayFloor")
        self:NetworkVar("String", 1, "ShellMaterial")
        self:NetworkVar("Float", 0, "DisplayX")
        self:NetworkVar("Float", 1, "DisplayY")
        self:NetworkVar("Float", 2, "DisplayZ")
        self:NetworkVar("Float", 3, "DisplayScale")
        self:NetworkVar("Float", 4, "SignX") -- Hallway Sign X
        self:NetworkVar("Float", 5, "SignY") -- Hallway Sign Y
        self:NetworkVar("Float", 6, "SignZ") -- Hallway Sign Z
        self:NetworkVar("Float", 7, "SignScale") -- Hallway Sign Scale
        
        self:NetworkVar("Float", 8, "CallX") -- Call Button X
        self:NetworkVar("Float", 9, "CallY") -- Call Button Y
        self:NetworkVar("Float", 10, "CallZ") -- Call Button Z
        self:NetworkVar("Float", 11, "CallScale") -- Call Button Scale
        
        self:NetworkVar("Float", 12, "OverX") -- Over Door X
        self:NetworkVar("Float", 13, "OverY") -- Over Door Y
        self:NetworkVar("Float", 14, "OverZ") -- Over Door Z
        self:NetworkVar("Float", 15, "OverScale") -- Over Door Scale
        
        self:NetworkVar("Angle", 0, "DisplayAng") -- Keypad Rotation
        self:NetworkVar("Angle", 1, "SignAng") -- Hallway Sign Rotation
        self:NetworkVar("Angle", 2, "CallAng") -- Call Button Rotation
        self:NetworkVar("Angle", 3, "OverAng") -- Over Door Rotation
        
        self:NetworkVar("Int", 4, "SoundArchetype") -- 0: Industrial, 1: Modern, 2: Luxury
        self:NetworkVar("Float", 16, "AutoCloseTime") -- Seconds until doors close (0 = never)
        self:NetworkVar("Bool", 1, "FloorRequested") 
        self:NetworkVar("Bool", 0, "DebugMode") -- Toggle Mode
        self:NetworkVar("Int", 5, "Preset") -- 0: Hightower (Default), 1: Welker

        -- Physical Offsets (Shell & Doors)
        self:NetworkVar("Float", 17, "ShellX")
        self:NetworkVar("Float", 18, "ShellY")
        self:NetworkVar("Float", 19, "ShellZ")
        self:NetworkVar("Float", 20, "DoorX")
        self:NetworkVar("Float", 21, "DoorY")
        self:NetworkVar("Float", 22, "DoorZ")
        self:NetworkVar("Float", 23, "DoorSep")
        
        self:NetworkVar("Angle", 4, "ShellAng")
        self:NetworkVar("Angle", 5, "DoorAng")
    end
end





-- Shared Keypad/Display Constants
HT_DISPLAY_POS = Vector(-39.2, 21, 50) -- Chest height origin (Synced with debug tools)



HT_DISPLAY_ANG_OFFSET = Angle(0, 90, 90)
HT_DISPLAY_SIZE = {w = 160, h = 60}
HT_KEYPAD_START_X = -71
HT_KEYPAD_START_Y = -61 -- Centered within the recessed keypad area


-- Call Button Constants (Outside the elevator)
HT_CALLBUTTON_POS = Vector(-31, 59.8, 46.5)
HT_CALLBUTTON_ANG = Angle(0, 0, 0) 
HT_CALLBUTTON_SIZE = {w = 64, h = 115}



-- Over-Door Display Constants (Arrival Lantern/Floor Indicator)
HT_OVERDOOR_POS = Vector(47.7, -2, 114)
HT_OVERDOOR_ANG = Angle(0, 0, 90)
HT_OVERDOOR_SIZE = {w = 120, h = 40}


-- External Hallway Floor Sign (Calculated from user setpos)
HT_FLOORSIGN_POS = Vector(-31, 59.8, 85)
HT_FLOORSIGN_ANG = Angle(0, 0, 0) 
HT_FLOORSIGN_SIZE = {w = 100, h = 100}


-- ============================================
-- ELEVATOR PRESET DEFINITIONS
-- ============================================
-- Each preset defines the models used for every component.
-- Preset 0 is the original Hightower set (default).
-- Preset 1 is the Welker / Office set.
-- ============================================
HT_ELEVATOR_PRESETS = {
    [0] = {
        Name        = "Hightower (Default)",
        Shell       = "models/Hightower/construction/elevator.mdl",
        ChamberBase = "models/Hightower/construction/elevator_chamber_base.mdl",
        ChamberTop  = "models/Hightower/construction/elevator_chamber_floor.mdl",
        GapFiller   = "models/Hightower/construction/elevator_chamber.mdl",
        DoorL       = "models/Hightower/construction/elevator_door_l.mdl",
        DoorR       = "models/Hightower/construction/elevator_door_r.mdl",
        SolidChamberBox = true,
        Offsets     = {
            display_x = 0, display_y = 0, display_z = 9.88, display_scale = 0.10, display_p = 0, display_y_rot = 0, display_r = 0,
            sign_x = 32, sign_y = 0.63, sign_z = 22, sign_scale = 0.15, sign_p = 180, sign_y_rot = 0, sign_r = 0,
            call_x = 0, call_y = 0.63, call_z = 0, call_scale = 0.08, call_p = 180, call_y_rot = 0, call_r = 0,
            over_x = 0, over_y = 0, over_z = 0, over_scale = 0.08, over_p = 0, over_y_rot = 0, over_r = 0,
            shell_x = 0, shell_y = 0, shell_z = 0, shell_p = 0, shell_y_rot = 0, shell_r = 0,
            door_x = 0, door_y = 0, door_z = 0, door_sep = 0, door_p = 0, door_y_rot = 0, door_r = 0
        }
    },
    [1] = {
        Name        = "Welker (Office)",
        Shell       = "models/mark2580/gtav/mp_office_03c/misc/office_elevator.mdl",
        ChamberBase = "models/welker/room.mdl",
        ChamberTop  = "models/welker/room.mdl",
        GapFiller   = "models/welker/foundation.mdl",
        DoorL       = "models/mark2580/gtav/mp_office_03c/misc/elevator_door.mdl",
        DoorR       = "models/mark2580/gtav/mp_office_03c/misc/elevator_door.mdl",
        SolidChamberBox = false,
        SolidShell      = false,
        Offsets     = {
            display_x = 94.40, display_y = -62.00, display_z = 5.81, display_scale = 0.10, display_p = -180, display_y_rot = 0, display_r = 0,
            sign_x = 32, sign_y = 0.63, sign_z = 22, sign_scale = 0.15, sign_p = 0, sign_y_rot = 0, sign_r = 0,
            call_x = 103, call_y = -20, call_z = 0, call_scale = 0.08, call_p = -90, call_y_rot = 0, call_r = 0,
            over_x = 0, over_y = 0, over_z = 0, over_scale = 0.08, over_p = 0, over_y_rot = 0, over_r = 0,
            shell_x = 11, shell_y = 0, shell_z = 60, shell_p = 0, shell_y_rot = 180, shell_r = 0,
            door_x = 60.32, door_y = 0, door_z = 7.91, door_sep = -15.3, door_p = 0, door_y_rot = -90, door_r = 0
        }
    },
}

function HT_GetPreset(id)
    return HT_ELEVATOR_PRESETS[id] or HT_ELEVATOR_PRESETS[0]
end
