-- Debug helper: position elevator props in-game
-- Usage in console:
--   ht_move_callbutton   - moves the call button to where you're looking
--   ht_move_display      - prints the local offset for the level display position
--   ht_show_entpos       - shows the elevator entity position and angle

if SERVER then
    concommand.Add("ht_move_callbutton", function(ply)
        local tr = ply:GetEyeTrace()
        if not tr.Hit then ply:ChatPrint("Look at a surface first!") return end
        
        -- Find the nearest elevator floor entity
        local closest = nil
        local closestDist = math.huge
        for _, ent in ipairs(ents.FindByClass("ht_elevator_floor")) do
            local d = ent:GetPos():DistToSqr(tr.HitPos)
            if d < closestDist then
                closestDist = d
                closest = ent
            end
        end
        
        if not IsValid(closest) then ply:ChatPrint("No elevator found nearby!") return end
        
        local localPos = closest:WorldToLocal(tr.HitPos)
        
        if IsValid(closest.CallButton) then
            closest.CallButton:SetPos(tr.HitPos)
        end
        
        ply:ChatPrint("Call button moved!")
        ply:ChatPrint("Local vector: Vector(" .. math.Round(localPos.x, 1) .. ", " .. math.Round(localPos.y, 1) .. ", " .. math.Round(localPos.z, 1) .. ")")
        print("CALL BUTTON LOCAL: Vector(" .. math.Round(localPos.x, 1) .. ", " .. math.Round(localPos.y, 1) .. ", " .. math.Round(localPos.z, 1) .. ")")
    end)
    
    
    concommand.Add("ht_move_display", function(ply)
        local tr = ply:GetEyeTrace()
        if not tr.Hit then ply:ChatPrint("Look at a surface first!") return end
        
        local closest = nil
        local closestDist = math.huge
        for _, ent in ipairs(ents.FindByClass("ht_elevator_floor")) do
            local d = ent:GetPos():DistToSqr(tr.HitPos)
            if d < closestDist then
                closestDist = d
                closest = ent
            end
        end
        
        if not IsValid(closest) then ply:ChatPrint("No elevator found nearby!") return end
        
        local localPos = closest:WorldToLocal(tr.HitPos)
        
        ply:ChatPrint("Display target position:")
        ply:ChatPrint("Local vector: Vector(" .. math.Round(localPos.x, 1) .. ", " .. math.Round(localPos.y, 1) .. ", " .. math.Round(localPos.z, 1) .. ")")
        print("DISPLAY LOCAL: Vector(" .. math.Round(localPos.x, 1) .. ", " .. math.Round(localPos.y, 1) .. ", " .. math.Round(localPos.z, 1) .. ")")
    end)
    
    concommand.Add("ht_show_entpos", function(ply)
        for _, ent in ipairs(ents.FindByClass("ht_elevator_floor")) do
            local pos = ent:GetPos()
            local ang = ent:GetAngles()
            ply:ChatPrint("Elevator #" .. ent:GetFloorNumber() .. " Pos: " .. math.Round(pos.x, 1) .. ", " .. math.Round(pos.y, 1) .. ", " .. math.Round(pos.z, 1))
            ply:ChatPrint("  Angle: " .. math.Round(ang.p, 1) .. ", " .. math.Round(ang.y, 1) .. ", " .. math.Round(ang.r, 1))
            print("ENT POS: " .. tostring(pos) .. " ANG: " .. tostring(ang))
        end
    end)
end
