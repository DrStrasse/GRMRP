MapStudio = MapStudio or {}

local sharedFiles = {
    "mapstudio/shared/sh_config.lua",
    "mapstudio/shared/sh_language.lua",
    "mapstudio/shared/languages/en.lua",
    "mapstudio/shared/languages/ru.lua",
    "mapstudio/shared/sh_net.lua",
    "mapstudio/shared/sh_permissions.lua",
    "mapstudio/shared/sh_objects.lua",
    "mapstudio/shared/sh_placement.lua",
    "mapstudio/shared/sh_core.lua",
    "mapstudio/tools/sh_registry.lua",
    "mapstudio/tools/sh_select_tool.lua",
    "mapstudio/tools/sh_prop_tool.lua",
    "mapstudio/tools/sh_move_tool.lua",
    "mapstudio/tools/sh_rotate_tool.lua",
    "mapstudio/tools/sh_scale_tool.lua",
    "mapstudio/tools/sh_delete_tool.lua"
}

local serverFiles = {
    "mapstudio/server/sv_permissions.lua",
    "mapstudio/server/sv_storage.lua",
    "mapstudio/server/sv_spawner.lua",
    "mapstudio/server/sv_protection.lua",
    "mapstudio/server/sv_import_permaprops.lua",
    "mapstudio/server/sv_net.lua",
    "mapstudio/server/sv_init.lua"
}

local clientFiles = {
    "mapstudio/client/cl_theme.lua",
    "mapstudio/vgui/ms_panel.lua",
    "mapstudio/vgui/ms_button.lua",
    "mapstudio/vgui/ms_textentry.lua",
    "mapstudio/vgui/ms_frame.lua",
    "mapstudio/vgui/ms_model_card.lua",
    "mapstudio/vgui/ms_property_row.lua",
    "mapstudio/client/cl_notifications.lua",
    "mapstudio/client/cl_freecam.lua",
    "mapstudio/client/cl_grid.lua",
    "mapstudio/client/cl_ghost.lua",
    "mapstudio/client/cl_asset_browser.lua",
    "mapstudio/client/cl_object_list.lua",
    "mapstudio/client/cl_inspector.lua",
    "mapstudio/client/cl_undo.lua",
    "mapstudio/client/cl_gizmo.lua",
    "mapstudio/client/cl_settings.lua",
    "mapstudio/client/cl_editor.lua",
    "mapstudio/client/cl_spawnmenu.lua",
    "mapstudio/client/cl_init.lua"
}

local function includeShared()
    for _, path in ipairs(sharedFiles) do
        include(path)
    end
end

if SERVER then
    for _, path in ipairs(sharedFiles) do
        AddCSLuaFile(path)
    end

    for _, path in ipairs(clientFiles) do
        AddCSLuaFile(path)
    end

    includeShared()

    for _, path in ipairs(serverFiles) do
        include(path)
    end
else
    includeShared()

    for _, path in ipairs(clientFiles) do
        include(path)
    end
end
