-- Advanced rotation/position debugger for elevator props and displays

if SERVER then
    concommand.Add("ht_rotate_callbutton", function(ply, cmd, args)
        if #args < 3 then return end
        local p, y, r = tonumber(args[1]) or 0, tonumber(args[2]) or 0, tonumber(args[3]) or 0
        for _, ent in ipairs(ents.FindByClass("ht_elevator_floor")) do
            if IsValid(ent.CallButton) then
                local ang = ent:GetAngles()
                ang:RotateAroundAxis(ang:Up(), y)
                ang:RotateAroundAxis(ang:Right(), p)
                ang:RotateAroundAxis(ang:Forward(), r)
                ent.CallButton:SetAngles(ang)
            end
        end
    end)

else
    -- Client-side display angle, pos, and size offsets
    HT_DISPLAY_ANG_OFFSET = HT_DISPLAY_ANG_OFFSET or Angle(0, 90, 90)
    HT_DISPLAY_POS = HT_DISPLAY_POS or Vector(-39.2, 21, 74)
    HT_DISPLAY_SIZE = HT_DISPLAY_SIZE or {w = 160, h = 60}
    
    concommand.Add("ht_display_angle", function(ply, cmd, args)
        if #args < 3 then return end
        HT_DISPLAY_ANG_OFFSET.p = tonumber(args[1]) or 0
        HT_DISPLAY_ANG_OFFSET.y = tonumber(args[2]) or 0
        HT_DISPLAY_ANG_OFFSET.r = tonumber(args[3]) or 0
    end)
    
    concommand.Add("ht_display_pos", function(ply, cmd, args)
        if #args < 3 then return end
        HT_DISPLAY_POS.x = tonumber(args[1]) or HT_DISPLAY_POS.x
        HT_DISPLAY_POS.y = tonumber(args[2]) or HT_DISPLAY_POS.y
        HT_DISPLAY_POS.z = tonumber(args[3]) or HT_DISPLAY_POS.z
    end)
    
    concommand.Add("ht_display_size", function(ply, cmd, args)
        if #args < 2 then return end
        HT_DISPLAY_SIZE.w = tonumber(args[1]) or HT_DISPLAY_SIZE.w
        HT_DISPLAY_SIZE.h = tonumber(args[2]) or HT_DISPLAY_SIZE.h
    end)
end
