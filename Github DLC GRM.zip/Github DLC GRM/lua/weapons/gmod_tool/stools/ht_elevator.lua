TOOL.Category = "Construction"
TOOL.Name = "Easy Elevator Tool"
TOOL.Command = nil
TOOL.ConfigName = ""

-- Ensure shared constants and HT_GetPreset are available
if SERVER then
    AddCSLuaFile("entities/ht_elevator_floor/shared.lua")
end
include("entities/ht_elevator_floor/shared.lua")

TOOL.ClientConVar = {
    system_id = "1",
    model_chamber = "models/Hightower/construction/elevator_chamber.mdl",
    model_door = "models/Hightower/construction/heavy_elevator_door.mdl",
    snap_z = "0",
    shell_material = "",
    preset = "0",
    display_x = "0",
    display_y = "0",
    display_z = "9.88",
    display_scale = "0.10",
    display_p = "0",
    display_y_rot = "0", -- Renamed to avoid collision with display_y position
    display_r = "0",
    sign_x = "32",
    sign_y = "0.63",
    sign_z = "22",
    sign_scale = "0.15",
    sign_p = "180",
    sign_y_rot = "0",
    sign_r = "0",
    call_x = "0",
    call_y = "0.63",
    call_z = "0",
    call_scale = "0.08",
    call_p = "180",
    call_y_rot = "0",
    call_r = "0",
    over_x = "0",
    over_y = "0",
    over_z = "0",
    over_scale = "0.08",
    over_p = "0",
    over_y_rot = "0",
    over_r = "0",
    shell_x = "0",
    shell_y = "0",
    shell_z = "0",
    shell_p = "0",
    shell_y_rot = "0",
    shell_r = "0",
    door_x = "0",
    door_y = "0",
    door_z = "0",
    door_sep = "0",
    door_p = "0",
    door_y_rot = "0",
    door_r = "0",
    debug_mode = "0",
    music = "1",
    music_volume = "0.6",
    spawn_gap_fillers = "1",
    sound_archetype = "0",
    auto_close_timer = "5.0"
}





if CLIENT then
    -- Force factory defaults on every startup/reload to prevent "Sticky 0" values from local config
    local factory_defaults = {
        display_x = "0", display_y = "0", display_z = "9.88", display_scale = "0.10",
        display_p = "0", display_y_rot = "0", display_r = "0",
        sign_x = "32", sign_y = "0.63", sign_z = "22", sign_scale = "0.15",
        sign_p = "180", sign_y_rot = "0", sign_r = "0",
        call_x = "0", call_y = "0.63", call_z = "0", call_scale = "0.08",
        call_p = "180", call_y_rot = "0", call_r = "0",
        over_x = "0", over_y = "0", over_z = "0", over_scale = "0.08",
        over_p = "0", over_y_rot = "0", over_r = "0",
        shell_x = "0", shell_y = "0", shell_z = "0", shell_p = "0", shell_y_rot = "0", shell_r = "0",
        door_x = "0", door_y = "0", door_z = "0", door_sep = "0", door_p = "0", door_y_rot = "0", door_r = "0",
        debug_mode = "0",
        music_volume = "0.6",
        spawn_gap_fillers = "1"
    }
    for cmd, val in pairs(factory_defaults) do
        RunConsoleCommand("ht_elevator_" .. cmd, val)
    end

    language.Add("tool.ht_elevator.name", "Easy Elevator Tool")
    language.Add("tool.ht_elevator.desc", "Teleport-based multilevel elevator tool")
    language.Add("tool.ht_elevator.0", "Left-Click: Place a floor. Right-Click: Copy System ID. Shift + Right-Click: Update Elevator. (Sliders update live!)")

    -- Add a command to reset all offsets
    concommand.Add("ht_elevator_reset_offsets", function()
        local ply = LocalPlayer()
        local defaults = {
            display_x = "0", display_y = "0", display_z = "9.88", display_scale = "0.10",
            display_p = "0", display_y_rot = "0", display_r = "0",
            sign_x = "32", sign_y = "0.63", sign_z = "22", sign_scale = "0.15",
            sign_p = "180", sign_y_rot = "0", sign_r = "0",
            call_x = "0", call_y = "0.63", call_z = "0", call_scale = "0.08",
            call_p = "180", call_y_rot = "0", call_r = "0",
            over_x = "0", over_y = "0", over_z = "0", over_scale = "0.08",
            over_p = "0", over_y_rot = "0", over_r = "0",
            shell_x = "0", shell_y = "0", shell_z = "0", shell_p = "0", shell_y_rot = "0", shell_r = "0",
            door_x = "0", door_y = "0", door_z = "0", door_sep = "0", door_p = "0", door_y_rot = "0", door_r = "0",
            spawn_gap_fillers = "1"
        }

        for cmd, val in pairs(defaults) do
            RunConsoleCommand("ht_elevator_" .. cmd, val)
        end

        ply:ChatPrint("Easy Elevator Tool: All offsets and rotations reset to factory defaults.")
    end)
end


function TOOL:LeftClick(trace)
    if not trace.HitPos then return false end
    if CLIENT then return true end

    local ply = self:GetOwner()
    local sysID = self:GetClientNumber("system_id")
    
    -- Auto-calculate the floor number based on existing floors in this system
    local floorCount = 1
    for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
        if f:GetSystemID() == sysID then
            floorCount = floorCount + 1
        end
    end
    
    local fNum = floorCount
    local fName = "Floor " .. fNum
    
    local spawnPos = trace.HitPos
    local plyAng = ply:EyeAngles()
    local spawnAng = Angle(0, math.Round(plyAng.y / 90) * 90 + 90, 0)
    
    local snapZ = self:GetClientNumber("snap_z") + 22
    -- Ensure vertical alignment with other floors of the same System ID
    for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
        if f:GetSystemID() == sysID then
            local basePos = f:GetPos()
            local zHit = trace.HitPos.z
            
            if snapZ and snapZ >= 22 then
                local diffZ = zHit - basePos.z
                local snappedDiff = math.Round(diffZ / snapZ) * snapZ
                zHit = basePos.z + snappedDiff
            end
            
            spawnPos = Vector(basePos.x, basePos.y, zHit)
            -- We no longer lock spawnAng here, allowing the player to rotate doors per-floor!
            break -- We only need one existing floor for reference
        end
    end

    local ent = ents.Create("ht_elevator_floor")
    ent:SetPos(spawnPos)
    ent:SetAngles(spawnAng)
    ent:Spawn()
    
    ent:SetSystemID(sysID)
    ent:SetFloorNumber(fNum)
    ent:SetFloorName(fName)
    ent:SetShellMaterial(self:GetClientInfo("shell_material"))
    ent:SetPreset(self:GetClientNumber("preset"))
    ent:SetDisplayX(self:GetClientNumber("display_x"))
    ent:SetDisplayY(self:GetClientNumber("display_y"))
    ent:SetDisplayZ(self:GetClientNumber("display_z"))
    ent:SetDisplayScale(self:GetClientNumber("display_scale"))
    ent:SetDisplayAng(Angle(self:GetClientNumber("display_p"), self:GetClientNumber("display_y_rot"), self:GetClientNumber("display_r")))

    ent:SetSignX(self:GetClientNumber("sign_x"))
    ent:SetSignY(self:GetClientNumber("sign_y"))
    ent:SetSignZ(self:GetClientNumber("sign_z"))
    ent:SetSignScale(self:GetClientNumber("sign_scale"))
    ent:SetSignAng(Angle(self:GetClientNumber("sign_p"), self:GetClientNumber("sign_y_rot"), self:GetClientNumber("sign_r")))
    
    ent:SetCallX(self:GetClientNumber("call_x"))
    ent:SetCallY(self:GetClientNumber("call_y"))
    ent:SetCallZ(self:GetClientNumber("call_z"))
    ent:SetCallScale(self:GetClientNumber("call_scale"))
    ent:SetCallAng(Angle(self:GetClientNumber("call_p"), self:GetClientNumber("call_y_rot"), self:GetClientNumber("call_r")))
    
    ent:SetOverX(self:GetClientNumber("over_x"))
    ent:SetOverY(self:GetClientNumber("over_y"))
    ent:SetOverZ(self:GetClientNumber("over_z"))
    ent:SetOverScale(self:GetClientNumber("over_scale"))
    ent:SetOverAng(Angle(self:GetClientNumber("over_p"), self:GetClientNumber("over_y_rot"), self:GetClientNumber("over_r")))
    
    ent:SetShellX(self:GetClientNumber("shell_x"))
    ent:SetShellY(self:GetClientNumber("shell_y"))
    ent:SetShellZ(self:GetClientNumber("shell_z"))
    ent:SetShellAng(Angle(self:GetClientNumber("shell_p"), self:GetClientNumber("shell_y_rot"), self:GetClientNumber("shell_r")))
    
    ent:SetDoorX(self:GetClientNumber("door_x"))
    ent:SetDoorY(self:GetClientNumber("door_y"))
    ent:SetDoorZ(self:GetClientNumber("door_z"))
    ent:SetDoorSep(self:GetClientNumber("door_sep"))
    ent:SetDoorAng(Angle(self:GetClientNumber("door_p"), self:GetClientNumber("door_y_rot"), self:GetClientNumber("door_r")))
    
    ent:SetSoundArchetype(self:GetClientNumber("sound_archetype"))
    ent:SetAutoCloseTime(self:GetClientNumber("auto_close_timer"))


    ent:SetDebugMode(self:GetClientNumber("debug_mode") == 1)



    
    self:UpdateSystemModels(sysID)

    undo.Create("Easy Elevator Tool (" .. fName .. ")")
        undo.AddEntity(ent)
        
        -- Automatically construct the physical shaft between floors!
        if fNum > 1 then
            local prevFloor = nil
            for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
                if f:GetSystemID() == sysID and f:GetFloorNumber() == (fNum - 1) then
                    prevFloor = f
                    break
                end
            end
            
            if IsValid(prevFloor) then
                local bottomZ = math.min(spawnPos.z, prevFloor:GetPos().z)
                local topZ = math.max(spawnPos.z, prevFloor:GetPos().z)
                
                -- Measure the lower elevator's exact roof height so we start precisely above its doors
                local dummyLower = ents.Create("prop_dynamic")
                local lowerPreset = HT_GetPreset(prevFloor:GetPreset())
                dummyLower:SetModel(prevFloor.TargetChamberModel or lowerPreset.ChamberTop)
                dummyLower:SetNoDraw(true)
                dummyLower:Spawn()
                local lowerRoofZ = dummyLower:OBBMaxs().z
                if lowerRoofZ <= 0 then lowerRoofZ = 120 end
                dummyLower:Remove()

                local curPreset = HT_GetPreset(self:GetClientNumber("preset"))
                local dummy = ents.Create("prop_dynamic")
                dummy:SetModel(curPreset.GapFiller)
                dummy:SetNoDraw(true)
                dummy:Spawn()
                local minZ = dummy:OBBMins().z
                local maxZ = dummy:OBBMaxs().z
                local height = maxZ - minZ
                if height <= 0 then height = 120; minZ = 0; maxZ = 120 end
                dummy:Remove()
                
                -- Start exactly at the roof, end exactly at the upper floor base
                -- We subtract/add 2 units of overlap to perfectly bury the ends of the shaft into the chambers
                -- This completely eradicates the microscopic visible gaps between pieces!
                local gapStart = bottomZ + lowerRoofZ - 2
                local gapEnd = topZ + minZ + 2
                local gapSize = gapEnd - gapStart
                
                if gapSize >= 5 and self:GetClientNumber("spawn_gap_fillers") == 1 then
                    local numFillers = math.ceil(gapSize / height)
                    
                    local z_first = gapStart
                    local z_last = gapEnd - height
                    
                    local isSquished = false
                    -- If floors are too close for a full gap filler, perfectly scale it to fit!
                    if z_last < z_first then
                        z_first = gapStart
                        z_last = z_first
                        isSquished = true
                    end
                    
                    -- Track gap fillers on the entity for AdvDupe2 saving
                    ent.GapFillerEnts = ent.GapFillerEnts or {}
                    
                    for i = 0, numFillers - 1 do
                        local currentBottomZ = z_first
                        if numFillers > 1 then
                            currentBottomZ = Lerp(i / (numFillers - 1), z_first, z_last)
                        end
                        
                        local filler = ents.Create("prop_dynamic")
                        filler:SetModel(curPreset.GapFiller)
                        filler:SetPos(Vector(spawnPos.x, spawnPos.y, currentBottomZ - minZ))
                        filler:SetAngles(spawnAng) 
                        
                        -- Parent and Link BEFORE spawning for perfect engine-level cleanup
                        filler:SetParent(ent)
                        ent:DeleteOnRemove(filler)
                        
                        filler:Spawn()
                        
                        local mat = self:GetClientInfo("shell_material")
                        if mat and mat ~= "" then
                            filler:SetMaterial(mat)
                        end
                        
                        -- Scale it vertically if the gap is too small, so it NEVER overlaps doors
                        if isSquished then
                            if CLIENT then
                                local scaleMat = Matrix()
                                scaleMat:Scale(Vector(1, 1, gapSize / height))
                                filler:EnableMatrix("RenderMultiply", scaleMat)
                            end
                        end
                        
                        -- Make the filler visible but purely visual! no door collision ever
                        filler:SetSolid(SOLID_NONE)
                        filler:SetCollisionGroup(COLLISION_GROUP_WORLD)
                        filler:DrawShadow(false)
                        
                        -- Track for AdvDupe2
                        table.insert(ent.GapFillerEnts, filler)
                    end
                end
            end
        end
        
        undo.SetPlayer(ply)
    undo.Finish()

    ply:ChatPrint("Placed " .. fName .. " (System ID: " .. sysID .. ")")
    
    return true
end

function TOOL:RightClick(trace)
    if IsValid(trace.Entity) and trace.Entity:GetClass() == "ht_elevator_floor" then
        if CLIENT then return true end
        local ply = self:GetOwner()
        local sysID = trace.Entity:GetSystemID()
        
        -- SHIFT + RIGHT CLICK: Push all current tool presets to the elevator
        if ply:KeyDown(IN_SPEED) then
            local toolSysID = self:GetClientNumber("system_id")
            trace.Entity:SetSystemID(toolSysID)
            trace.Entity:SetShellMaterial(self:GetClientInfo("shell_material"))
            trace.Entity:SetPreset(self:GetClientNumber("preset"))
            
            -- Push all UI offsets
            trace.Entity:SetDisplayX(self:GetClientNumber("display_x"))
            trace.Entity:SetDisplayY(self:GetClientNumber("display_y"))
            trace.Entity:SetDisplayZ(self:GetClientNumber("display_z"))
            trace.Entity:SetDisplayScale(self:GetClientNumber("display_scale"))
            trace.Entity:SetDisplayAng(Angle(self:GetClientNumber("display_p"), self:GetClientNumber("display_y_rot"), self:GetClientNumber("display_r")))
            
            trace.Entity:SetSignX(self:GetClientNumber("sign_x"))
            trace.Entity:SetSignY(self:GetClientNumber("sign_y"))
            trace.Entity:SetSignZ(self:GetClientNumber("sign_z"))
            trace.Entity:SetSignScale(self:GetClientNumber("sign_scale"))
            trace.Entity:SetSignAng(Angle(self:GetClientNumber("sign_p"), self:GetClientNumber("sign_y_rot"), self:GetClientNumber("sign_r")))
            
            trace.Entity:SetCallX(self:GetClientNumber("call_x"))
            trace.Entity:SetCallY(self:GetClientNumber("call_y"))
            trace.Entity:SetCallZ(self:GetClientNumber("call_z"))
            trace.Entity:SetCallScale(self:GetClientNumber("call_scale"))
            trace.Entity:SetCallAng(Angle(self:GetClientNumber("call_p"), self:GetClientNumber("call_y_rot"), self:GetClientNumber("call_r")))
            
            trace.Entity:SetOverX(self:GetClientNumber("over_x"))
            trace.Entity:SetOverY(self:GetClientNumber("over_y"))
            trace.Entity:SetOverZ(self:GetClientNumber("over_z"))
            trace.Entity:SetOverScale(self:GetClientNumber("over_scale"))
            trace.Entity:SetOverAng(Angle(self:GetClientNumber("over_p"), self:GetClientNumber("over_y_rot"), self:GetClientNumber("over_r")))
            
            trace.Entity:SetShellX(self:GetClientNumber("shell_x"))
            trace.Entity:SetShellY(self:GetClientNumber("shell_y"))
            trace.Entity:SetShellZ(self:GetClientNumber("shell_z"))
            trace.Entity:SetShellAng(Angle(self:GetClientNumber("shell_p"), self:GetClientNumber("shell_y_rot"), self:GetClientNumber("shell_r")))
            
            trace.Entity:SetDoorX(self:GetClientNumber("door_x"))
            trace.Entity:SetDoorY(self:GetClientNumber("door_y"))
            trace.Entity:SetDoorZ(self:GetClientNumber("door_z"))
            trace.Entity:SetDoorSep(self:GetClientNumber("door_sep"))
            trace.Entity:SetDoorAng(Angle(self:GetClientNumber("door_p"), self:GetClientNumber("door_y_rot"), self:GetClientNumber("door_r")))
            
            trace.Entity:SetSoundArchetype(self:GetClientNumber("sound_archetype"))
            trace.Entity:SetAutoCloseTime(self:GetClientNumber("auto_close_timer"))


            trace.Entity:SetDebugMode(self:GetClientNumber("debug_mode") == 1)

            
            self:UpdateSystemModels(toolSysID)
            ply:ChatPrint("Updated Elevator Presets from Toolgun (System " .. toolSysID .. ")")
        else
            -- NORMAL RIGHT CLICK: Select the system ID (Copy from Elevator to Tool)
            ply:ConCommand("ht_elevator_system_id " .. sysID)
            ply:ChatPrint("Selected Elevator System ID " .. sysID)
        end
        return true
    end
    return false
end

function TOOL:UpdateSystemModels(sysID)
    local floors = {}
    for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
        if f:GetSystemID() == sysID then
            table.insert(floors, f)
        end
    end
    table.sort(floors, function(a, b) return a:GetPos().z < b:GetPos().z end)
    
    -- Re-number floors by height so the lowest floor is always Floor 1
    for i, f in ipairs(floors) do
        f:SetFloorNumber(i)
        f:SetFloorName("Floor " .. i)
    end
    
    for i, f in ipairs(floors) do
        local preset = HT_GetPreset(f:GetPreset())
        local mdl = preset.ChamberTop
        if #floors > 1 then
            if i == 1 then
                mdl = preset.ChamberBase
            elseif i == #floors then
                mdl = preset.ChamberTop
            end
        end
        f.TargetChamberModel = mdl
        if f.SpawnChamberParts then
            f:SpawnChamberParts()
        end
    end
end

function TOOL:UpdateGhostEntity(ent, ply)
    if not IsValid(ent) then return end
    
    local trace = ply:GetEyeTrace()
    if not trace.Hit then
        ent:SetNoDraw(true)
        if CLIENT and self.GhostFillers then
            for _, g in pairs(self.GhostFillers) do if IsValid(g) then g:SetNoDraw(true) end end
        end
        return
    end

    local sysID = self:GetClientNumber("system_id")
    local spawnPos = trace.HitPos
    local plyAng = ply:EyeAngles()
    local spawnAng = Angle(0, math.Round(plyAng.y / 90) * 90 + 90, 0)
    
    local snapZ = self:GetClientNumber("snap_z") + 22
    for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
        if f:GetSystemID() == sysID then
            local basePos = f:GetPos()
            local zHit = trace.HitPos.z
            
            if snapZ and snapZ >= 22 then
                local diffZ = zHit - basePos.z
                local snappedDiff = math.Round(diffZ / snapZ) * snapZ
                local zHeight = basePos.z + snappedDiff
                spawnPos = Vector(basePos.x, basePos.y, zHeight)
            else
                spawnPos = Vector(basePos.x, basePos.y, zHit)
            end
            break
        end
    end
    
    ent:SetPos(spawnPos)
    ent:SetAngles(spawnAng)
    ent:SetMaterial("models/Hightower/construction/prop_grey_plastic")
    ent:SetNoDraw(false)

    -- SHAFT PREVIEW
    if CLIENT then
        self.GhostFillers = self.GhostFillers or {}
        -- Clean up stale ghosts
        for i, g in pairs(self.GhostFillers) do
            if not IsValid(g) then self.GhostFillers[i] = nil end
        end

        local prevFloor = nil
        for _, f in ipairs(ents.FindByClass("ht_elevator_floor")) do
            if f:GetSystemID() == sysID then
                if not prevFloor or math.abs(spawnPos.z - f:GetPos().z) < math.abs(spawnPos.z - prevFloor:GetPos().z) then
                    prevFloor = f
                end
            end
        end

        if IsValid(prevFloor) then
            local bottomZ = math.min(spawnPos.z, prevFloor:GetPos().z)
            local topZ = math.max(spawnPos.z, prevFloor:GetPos().z)
            local gapSize = (topZ - bottomZ) - 120 -- Approximate height
            
            if gapSize > 5 then
                local height = 120
                local numFillers = math.ceil(gapSize / height)
                
                -- Ensure we have enough ghost fillers
                for i = 1, numFillers do
                    if not IsValid(self.GhostFillers[i]) then
                        local ghostPreset = HT_GetPreset(self:GetClientNumber("preset"))
                        self.GhostFillers[i] = ents.CreateClientProp(ghostPreset.GapFiller)
                        self.GhostFillers[i]:SetRenderMode(RENDERMODE_TRANSCOLOR)
                        self.GhostFillers[i]:SetColor(Color(255, 255, 255, 150))
                        self.GhostFillers[i]:SetMaterial("models/debug/debugwhite")
                    end
                    
                    local g = self.GhostFillers[i]
                    local currentZ = bottomZ + 120 + ((i-1) * (gapSize / numFillers))
                    g:SetPos(Vector(spawnPos.x, spawnPos.y, currentZ))
                    g:SetAngles(spawnAng)
                    g:SetNoDraw(false)
                end
                
                -- Hide unused
                for i = numFillers + 1, #self.GhostFillers do
                    if IsValid(self.GhostFillers[i]) then self.GhostFillers[i]:SetNoDraw(true) end
                end
            else
                for _, g in pairs(self.GhostFillers) do if IsValid(g) then g:SetNoDraw(true) end end
            end
        else
            for _, g in pairs(self.GhostFillers) do if IsValid(g) then g:SetNoDraw(true) end end
        end
    end
end

function TOOL:Think()
    local curPreset = HT_GetPreset(self:GetClientNumber("preset"))
    local mdl = curPreset.ChamberBase
    if not IsValid(self.GhostEntity) or self.GhostEntity:GetModel() ~= mdl then
        self:MakeGhostEntity(mdl, Vector(0,0,0), Angle(0,0,0))
    end
    self:UpdateGhostEntity(self.GhostEntity, self:GetOwner())

    -- LIVE UPDATE: Push slider values instantly to the elevator being looked at
    if SERVER then
        local ply = self:GetOwner()
        local trace = ply:GetEyeTrace()
        if IsValid(trace.Entity) and trace.Entity:GetClass() == "ht_elevator_floor" then
            -- Using a throttling check to avoid excessive network variable updates
            local curTime = CurTime()
            self.NextLiveUpdate = self.NextLiveUpdate or 0
            if curTime > self.NextLiveUpdate then
                trace.Entity:SetDisplayX(self:GetClientNumber("display_x"))
                trace.Entity:SetDisplayY(self:GetClientNumber("display_y"))
                trace.Entity:SetDisplayZ(self:GetClientNumber("display_z"))
                trace.Entity:SetDisplayScale(self:GetClientNumber("display_scale"))
                trace.Entity:SetDisplayAng(Angle(self:GetClientNumber("display_p"), self:GetClientNumber("display_y_rot"), self:GetClientNumber("display_r")))

                trace.Entity:SetSignX(self:GetClientNumber("sign_x"))
                trace.Entity:SetSignY(self:GetClientNumber("sign_y"))
                trace.Entity:SetSignZ(self:GetClientNumber("sign_z"))
                trace.Entity:SetSignScale(self:GetClientNumber("sign_scale"))
                trace.Entity:SetSignAng(Angle(self:GetClientNumber("sign_p"), self:GetClientNumber("sign_y_rot"), self:GetClientNumber("sign_r")))

                trace.Entity:SetCallX(self:GetClientNumber("call_x"))
                trace.Entity:SetCallY(self:GetClientNumber("call_y"))
                trace.Entity:SetCallZ(self:GetClientNumber("call_z"))
                trace.Entity:SetCallScale(self:GetClientNumber("call_scale"))
                trace.Entity:SetCallAng(Angle(self:GetClientNumber("call_p"), self:GetClientNumber("call_y_rot"), self:GetClientNumber("call_r")))

                trace.Entity:SetOverX(self:GetClientNumber("over_x"))
                trace.Entity:SetOverY(self:GetClientNumber("over_y"))
                trace.Entity:SetOverZ(self:GetClientNumber("over_z"))
                trace.Entity:SetOverScale(self:GetClientNumber("over_scale"))
                trace.Entity:SetOverAng(Angle(self:GetClientNumber("over_p"), self:GetClientNumber("over_y_rot"), self:GetClientNumber("over_r")))
                
                trace.Entity:SetShellX(self:GetClientNumber("shell_x"))
                trace.Entity:SetShellY(self:GetClientNumber("shell_y"))
                trace.Entity:SetShellZ(self:GetClientNumber("shell_z"))
                trace.Entity:SetShellAng(Angle(self:GetClientNumber("shell_p"), self:GetClientNumber("shell_y_rot"), self:GetClientNumber("shell_r")))
                
                trace.Entity:SetDoorX(self:GetClientNumber("door_x"))
                trace.Entity:SetDoorY(self:GetClientNumber("door_y"))
                trace.Entity:SetDoorZ(self:GetClientNumber("door_z"))
                trace.Entity:SetDoorSep(self:GetClientNumber("door_sep"))
                trace.Entity:SetDoorAng(Angle(self:GetClientNumber("door_p"), self:GetClientNumber("door_y_rot"), self:GetClientNumber("door_r")))
                
                trace.Entity:SetSoundArchetype(self:GetClientNumber("sound_archetype"))
                trace.Entity:SetAutoCloseTime(self:GetClientNumber("auto_close_timer"))


                trace.Entity:SetDebugMode(self:GetClientNumber("debug_mode") == 1)

                self.NextLiveUpdate = curTime + 0.05 -- Update 20 times per second for smooth adjustment
            end
        end
    end
end




function TOOL:Holster()
    if CLIENT and self.GhostFillers then
        for _, g in pairs(self.GhostFillers) do
            if IsValid(g) then g:Remove() end
        end
        self.GhostFillers = nil
    end
end


function TOOL.BuildCPanel(panel)
    panel:AddControl("Header", { description = "Place elevator chambers. Floors sharing the same System ID teleport to each other. Floor numbers are assigned automatically starting from 1." })
    
    panel:AddControl("Slider", { Label = "Link: System ID", Command = "ht_elevator_system_id", Type = "Integer", Min = 1, Max = 100 })

    -- Preset selector dropdown (DComboBox is more reliable than ListBox in tool panels)
    local presetLabel = vgui.Create("DLabel", panel)
    presetLabel:SetText("Elevator Preset")
    presetLabel:SetDark(true)
    panel:AddItem(presetLabel)

    local presetCombo = vgui.Create("DComboBox", panel)
    presetCombo:SetValue("Hightower (Default)")
    presetCombo:AddChoice("Hightower (Default)", 0)
    presetCombo:AddChoice("Welker (Office)", 1)

    -- Sync initial display with current convar
    local curPreset = GetConVar("ht_elevator_preset")
    if curPreset then
        local pIdx = curPreset:GetInt()
        if pIdx == 1 then 
            presetCombo:SetValue("Welker (Office)") 
        end
        
        -- Auto-sync ConVars to the currently loaded preset so we don't have to bounce it back and forth
        timer.Simple(0.1, function()
            if not HT_ELEVATOR_PRESETS then return end
            local defs = HT_ELEVATOR_PRESETS[pIdx]
            if defs and defs.Offsets then
                for cmd, val in pairs(defs.Offsets) do
                    RunConsoleCommand("ht_elevator_" .. cmd, tostring(val))
                end
            end
        end)
    end

    presetCombo.OnSelect = function(self, index, value, data)
        RunConsoleCommand("ht_elevator_preset", tostring(data))
        
        -- Apply the preset's matching built-in offsets
        local defs = HT_ELEVATOR_PRESETS[data]
        if defs and defs.Offsets then
            for cmd, val in pairs(defs.Offsets) do
                RunConsoleCommand("ht_elevator_" .. cmd, tostring(val))
            end
        end
    end
    panel:AddItem(presetCombo)

    panel:AddControl("Slider", { Label = "Floor Gap Snap Amount (Source Units)", Command = "ht_elevator_snap_z", Type = "Float", Min = 0, Max = 1000, Help = "Set greater than 0 to snap floor placement to specific vertical heights" })
    
    local adv = vgui.Create("DForm", panel)
    adv:SetLabel("Advanced Offset Adjustment (Debug)")
    adv:SetExpanded(false)

    adv:Help("Inner Pad Offsets")
    adv:NumSlider("Pad X", "ht_elevator_display_x", -20, 20)
    adv:NumSlider("Pad Y", "ht_elevator_display_y", -20, 20)
    adv:NumSlider("Pad Z", "ht_elevator_display_z", -20, 20)
    adv:NumSlider("Pad Scale", "ht_elevator_display_scale", 0.01, 0.2)
    adv:NumSlider("Pad Pitch", "ht_elevator_display_p", -180, 180)
    adv:NumSlider("Pad Yaw", "ht_elevator_display_y_rot", -180, 180)
    adv:NumSlider("Pad Roll", "ht_elevator_display_r", -180, 180)

    adv:Help("Hallway Sign Offsets")
    adv:NumSlider("Sign X", "ht_elevator_sign_x", -200, 200)
    adv:NumSlider("Sign Y", "ht_elevator_sign_y", -400, 400)
    adv:NumSlider("Sign Z", "ht_elevator_sign_z", -200, 200)
    adv:NumSlider("Sign Scale", "ht_elevator_sign_scale", 0.01, 0.5)
    adv:NumSlider("Sign Pitch", "ht_elevator_sign_p", -180, 180)
    adv:NumSlider("Sign Yaw", "ht_elevator_sign_y_rot", -180, 180)
    adv:NumSlider("Sign Roll", "ht_elevator_sign_r", -180, 180)

    adv:Help("Call Button Offsets")
    adv:NumSlider("Call X", "ht_elevator_call_x", -20, 20)
    adv:NumSlider("Call Y", "ht_elevator_call_y", -20, 20)
    adv:NumSlider("Call Z", "ht_elevator_call_z", -20, 20)
    adv:NumSlider("Call Scale", "ht_elevator_call_scale", 0.01, 0.2)
    adv:NumSlider("Call Pitch", "ht_elevator_call_p", -180, 180)
    adv:NumSlider("Call Yaw", "ht_elevator_call_y_rot", -180, 180)
    adv:NumSlider("Call Roll", "ht_elevator_call_r", -180, 180)

    adv:Help("Over Door Display Offsets")
    adv:NumSlider("Over X", "ht_elevator_over_x", -20, 20)
    adv:NumSlider("Over Y", "ht_elevator_over_y", -20, 20)
    adv:NumSlider("Over Z", "ht_elevator_over_z", -20, 20)
    adv:NumSlider("Over Scale", "ht_elevator_over_scale", 0.01, 0.2)
    adv:NumSlider("Over Pitch", "ht_elevator_over_p", -180, 180)
    adv:NumSlider("Over Yaw", "ht_elevator_over_y_rot", -180, 180)
    adv:NumSlider("Over Roll", "ht_elevator_over_r", -180, 180)

    adv:Help("Elevator Shell Offsets")
    adv:NumSlider("Shell X", "ht_elevator_shell_x", -200, 200)
    adv:NumSlider("Shell Y", "ht_elevator_shell_y", -200, 200)
    adv:NumSlider("Shell Z", "ht_elevator_shell_z", -200, 200)
    adv:NumSlider("Shell Pitch", "ht_elevator_shell_p", -180, 180)
    adv:NumSlider("Shell Yaw", "ht_elevator_shell_y_rot", -180, 180)
    adv:NumSlider("Shell Roll", "ht_elevator_shell_r", -180, 180)

    adv:Help("Doors Offsets")
    adv:NumSlider("Door X", "ht_elevator_door_x", -200, 200)
    adv:NumSlider("Door Y", "ht_elevator_door_y", -200, 200)
    adv:NumSlider("Door Z", "ht_elevator_door_z", -200, 200)
    adv:NumSlider("Door Sep Base", "ht_elevator_door_sep", -100, 100)
    adv:NumSlider("Door Pitch", "ht_elevator_door_p", -180, 180)
    adv:NumSlider("Door Yaw", "ht_elevator_door_y_rot", -180, 180)
    adv:NumSlider("Door Roll", "ht_elevator_door_r", -180, 180)

    adv:CheckBox("DEBUG: Toggle Alignment Mode", "ht_elevator_debug_mode")
    adv:Button("Reset All Offsets and Rotations", "ht_elevator_reset_offsets")
    
    panel:AddItem(adv)

    panel:AddControl("CheckBox", { Label = "Enable Elevator Music", Command = "ht_elevator_music" })
    panel:AddControl("Slider", { Label = "Music Volume", Command = "ht_elevator_music_volume", Type = "Float", Min = 0, Max = 1 })
    panel:AddControl("CheckBox", { Label = "Spawn Gap Fillers Between Floors", Command = "ht_elevator_spawn_gap_fillers", Help = "Automatically drop solid connection shafts vertically between connected floors."})
    panel:AddControl("Slider", { Label = "Auto-Close Timer (Seconds)", Command = "ht_elevator_auto_close_timer", Type = "Float", Min = 0, Max = 30, Help = "Set to 0 to disable auto-closing" })
    
    local soundList = {
        ["Industrial (Clunky)"] = { ht_elevator_sound_archetype = 0 },
        ["Modern (Digital)"] = { ht_elevator_sound_archetype = 1 },
        ["Luxury (Elegant)"] = { ht_elevator_sound_archetype = 2 }
    }
    panel:AddControl("ListBox", { Label = "Sound Profile", Options = soundList })







    panel:AddControl("Label", { Text = "Elevator Inner Shell Material" })
    panel:MatSelect("ht_elevator_shell_material", {
        ["Polished Wood"] = "models/Hightower/construction/yacht_wood_2",
        ["Black Office"] = "models/Hightower/construction/ak_dlc_ex1_col_black",
        ["Silver Metal"] = "models/Hightower/construction/km_v_r_silver",
        ["Grey Plastic"] = "models/Hightower/construction/prop_grey_plastic",
        ["Brown Wood"] = "models/Hightower/construction/ak_dlc_ex1_brownwood_d",
        ["Dark Metal"] = "models/props_combine/combine_interface001"
    }, false, 64, 64)

    panel:AddControl("Label", { Text = "Prop Configuration" })
    panel:AddControl("TextBox", { Label = "Chamber Model", Command = "ht_elevator_model_chamber" })
    panel:AddControl("TextBox", { Label = "Door Model", Command = "ht_elevator_model_door" })
end

if CLIENT then
    function TOOL:DrawToolScreen(width, height)
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(0, 0, width, height)
        
        draw.SimpleText("EASY ELEVATOR TOOL", "DermaLarge", width / 2, height / 2 - 20, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Sys: " .. self:GetClientNumber("system_id"), "DermaDefault", width / 2, height / 2 + 20, color_white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end
