AddCSLuaFile() // Для того что бы передавалась клиенту (ну на всякий случай)
if SERVER then
	print("Improved Revive System loaded! v1.0.8")
	util.AddNetworkString("BleedOutMessage")
	util.AddNetworkString("BleedoutDownClient")
end
tabhalo = {} // Создание столбика для обводки + иконок над игроками.
convar = GetConVar( "bleedout_shouldtakedmg" )
convar0 = GetConVar( "sbox_playershurtplayers" )
convar2 = GetConVar( "bleedout_draw_outlines" )
convar3 = GetConVar( "bleedout_draw_icons" )
convar4 = GetConVar( "bleedout_enable" )
convar5 = GetConVar( "bleedout_death_time" )
convar6 = GetConVar( "bleedout_revive_time" )
convar7 = GetConVar( "bleedout_icon_drawmode" )
convar8 = GetConVar( "bleedout_outline_color_r" )
convar9 = GetConVar( "bleedout_outline_color_g" )
convar10 = GetConVar( "bleedout_outline_color_b" )
convar11 = GetConVar( "bleedout_crawl" )
convar12 = GetConVar( "bleedout_shouldshoot" )
convar13 = GetConVar( "bleedout_icon_custom" )
convar14 = GetConVar( "bleedout_icon_size" )
convar15 = GetConVar( "bleedout_draw_blood" )
convar16 = GetConVar( "bleedout_draw_colorcorrection" )
convar17 = GetConVar( "bleedout_num_bleedouts" )
convar18 = GetConVar( "bleedout_draw_timer" )
convar19 = GetConVar( "bleedout_legacyui" )
convar20 = GetConVar( "bleedout_view_roll" )
convar21 = GetConVar( "bleedout_draw_revive_timer" )
convar22 = GetConVar( "bleedout_notarget" )
convar23 = GetConVar( "bleedout_reducedmg" ) --3
convar25 = GetConVar( "bleedout_npc_can_revive" )
convar26 = GetConVar( "bleedout_view_draw_body" )
convar27 = GetConVar( "bleedout_enable_bleeding" )
convar28 = GetConVar( "bleedout_sound_enable" )
convar29 = GetConVar( "bleedout_reviveonkill" )
convar30 = GetConVar( "bleedout_killcount" )
convar31 = GetConVar( "bleedout_hp" )
convar32 = GetConVar( "bleedout_blacknwhite" )
convar33 = GetConVar( "bleedout_heartbeat" )
convar34 = GetConVar( "bleedout_stage2" )
convar35 = GetConVar( "bleedout_message" )
convar36 = GetConVar( "bleedout_chance" )
convar37 = GetConVar( "bleedout_weapon" )
convar38 = GetConVar( "bleedout_cansuicide" )
local delay = CurTime() + 3
local join = false
local loweredview = Vector(0, 0, 38) // Используется в FireBullets, CalcView, CalcViewModelView
local normalhullbottom, normalhulltop, duckhullbottom, duckhulltop = Vector(-16, -16, 0), Vector(16, 16, 72), Vector(-16, -16, 0), Vector(16, 16, 36) // Хуллы для игрока, используется в self:SetHull()
local distancetotrace = 91
local PLAYER = FindMetaTable("Player") // Метатабл для игроков
local NPC = FindMetaTable("NPC")
local cyclex, cycley = 0.6,0.65 // Период анимации, своровал с nzombies
local loweredpos = Vector(0,0,0) // Вычитаем из обычного вектора.
local rotate = Angle(0,0,0) -- Вращение
local yellsounds = {"vo/npc/male01/help01.wav","vo/npc/male01/pain01.wav","vo/npc/male01/pain02.wav","vo/npc/male01/pain03.wav","vo/npc/male01/pain04.wav","vo/npc/male01/pain05.wav","vo/npc/male01/pain06.wav","vo/npc/male01/pain07.wav","vo/npc/male01/pain08.wav","vo/npc/male01/pain09.wav"}
local table_npc = {["npc_citizen"] = true, ["npc_barney"] = true, ["npc_alyx"] = true}
table_down_npc = {}
function SearchForClassInTable(tab, class)
	for k, v in pairs(tab) do
		if v:GetClass() == class then return v end
	end
	return nil
end

hook.Add("PlayerInitialSpawn", "BleedoutSpawn", function(ply)
	if not join then
		join = true
		RunConsoleCommand("bleedout_view_draw_body", 1)
		RunConsoleCommand("bleedout_enable", 1)
		ply:ChatPrint("--------------------------------------")
		ply:ChatPrint("IMPROVED REVIVE SYSTEM v1.0.8")
		ply:ChatPrint("--------------------------------------")
	end
	net.Start("BleedoutDownClient")
	net.WriteTable(table_down_npc)
	net.Send(ply)
end)

concommand.Add("bleedout_removerevivenpc", function(ply)
	if not ply:IsSuperAdmin() then return end
	if not GetConVar("bleedout_enable"):GetBool() then return end
	local ent = ply:GetEyeTrace().Entity
	if ent:IsNPC() then	 
		table_npc[ent:GetClass()] = false
		ply:ChatPrint(ent:GetClass() .. ' was removed from revive npc list!')
	end
end)

concommand.Add("bleedout_addrevivenpc", function(ply)
	if not ply:IsSuperAdmin() then return end
	if not GetConVar("bleedout_enable"):GetBool() then return end
	local ent = ply:GetEyeTrace().Entity
	if ent:IsNPC() then	 
		table_npc[ent:GetClass()] = true
		ply:ChatPrint(ent:GetClass() .. ' was added to revive npc list!')
	end
end)

concommand.Add("bleedout_removedownnpc", function(ply)
	if not ply:IsSuperAdmin() then return end
	if not GetConVar("bleedout_enable"):GetBool() then return end
	local ent = ply:GetEyeTrace().Entity
	if ent:IsNPC() then	 
		table_down_npc[ent:GetClass()] = false
		ply:ChatPrint(ent:GetClass() .. ' was removed from downed npc list!')
		net.Start("BleedoutDownClient")
		net.WriteTable(table_down_npc)
		net.Broadcast()
	end
end)

concommand.Add("bleedout_adddownnpc", function(ply)
	if not ply:IsSuperAdmin() then return end
	if not GetConVar("bleedout_enable"):GetBool() then return end
	local ent = ply:GetEyeTrace().Entity
	if ent:IsNPC() then	 
		table_down_npc[ent:GetClass()] = true
		ply:ChatPrint(ent:GetClass() .. ' was added to downed npc list!')
		net.Start("BleedoutDownClient")
		net.WriteTable(table_down_npc)
		net.Broadcast()
	end
end)

function DrawColorCorrection(t, from, to)
	local tab = {
		["$pp_colour_addr"] = Lerp(t, from["$pp_colour_addr"], to["$pp_colour_addr"]),
		["$pp_colour_addg"] = Lerp(t, from["$pp_colour_addg"], to["$pp_colour_addg"]),
		["$pp_colour_addb"] = Lerp(t, from["$pp_colour_addb"], to["$pp_colour_addb"]),
		["$pp_colour_brightness"] = Lerp(t, from["$pp_colour_brightness"], to["$pp_colour_brightness"]),
		["$pp_colour_contrast"] = Lerp(t, from["$pp_colour_contrast"], to["$pp_colour_contrast"]),
		["$pp_colour_colour"] = Lerp(t, from["$pp_colour_colour"], to["$pp_colour_colour"]),
		["$pp_colour_mulr"] = Lerp(t, from["$pp_colour_mulr"], to["$pp_colour_mulr"]),
		["$pp_colour_mulg"] = Lerp(t, from["$pp_colour_mulg"], to["$pp_colour_mulg"]),
		["$pp_colour_mulb"] = Lerp(t, from["$pp_colour_mulb"], to["$pp_colour_mulb"])
	}
	DrawColorModify(tab)
end
function LerpColor(t, fromcol, tocol)
	local from1, from2, from3 = ColorToHSL(fromcol) // Как подсказывают на форумах и вики: лучше переводить в hsv, а потом уже лерпать.
	local to1, to2, to3 = ColorToHSL(tocol)
	local f1 = Lerp(t, from1, to1)
	local f2 = Lerp(t, from2, to2)
	local f3 = Lerp(t, from3, to3)
	return HSLToColor(f1, f2, f3)
end
function BuildCircle(xx, yy, radius)
	local triangle = {} // P.s На будущее - если мне лень пользоваться math.cos - могу представить это как угол, а потом forward()
		triangle[1] = { 
			{x = xx + radius * -0.382683, y = yy + radius * -0.923880},
			{x = xx, y = yy - radius},
			{x = xx, y = yy}
		}
		triangle[2] = { 
			{x = xx + radius * -0.707107, y = yy + radius * -0.707107},
			{x = xx + radius * -0.382683, y = yy + radius * -0.923880},
			{x = xx, y = yy}
		}
		triangle[3] = { 
			{x = xx + radius * -0.920505, y = yy + radius * -0.390731},
			{x = xx + radius * -0.707107, y = yy + radius * -0.707107},
			{x = xx, y = yy}
		}
		triangle[4] = { 
			{x = xx - radius, y = yy},
			{x = xx + radius * -0.920505, y = yy + radius * -0.390731},
			{x = xx, y = yy}
		}
		triangle[5] = { 
			{x = xx + radius * -0.920505, y = yy + radius * 0.390731},
			{x = xx - radius, y = yy},
			{x = xx, y = yy}
		}
		triangle[6] = { 
			{x = xx + radius * -0.707107, y = yy + radius * 0.707107},
			{x = xx + radius * -0.920505, y = yy + radius * 0.390731},
			{x = xx, y = yy}
		}
		triangle[7] = { 
			{x = xx + radius * -0.382683, y = yy + radius * 0.923880},
			{x = xx + radius * -0.707107, y = yy + radius * 0.707107},
			{x = xx, y = yy}
		}
		triangle[8] = { 
			{x = xx, y = yy + radius},
			{x = xx + radius * -0.382683, y = yy + radius * 0.923880},
			{x = xx, y = yy}
		}
		triangle[9] = { 
			{x = xx + radius * 0.382683, y = yy + radius * 0.923880},
			{x = xx, y = yy + radius},
			{x = xx, y = yy}
		}
		triangle[10] = { 
			{x = xx + radius * 0.707107, y = yy + radius * 0.707107},
			{x = xx + radius * 0.382683, y = yy + radius * 0.923880},
			{x = xx, y = yy}
		}
		triangle[11] = { 
			{x = xx + radius * 0.920505, y = yy + radius * 0.390731},
			{x = xx + radius * 0.707107, y = yy + radius * 0.707107},
			{x = xx, y = yy}
		}
		triangle[12] = { 
			{x = xx + radius, y = yy},
			{x = xx + radius * 0.920505, y = yy + radius * 0.390731},
			{x = xx, y = yy}
		}
		triangle[13] = { 
			{x = xx + radius * 0.920505, y = yy + radius * -0.390731},
			{x = xx + radius, y = yy},
			{x = xx, y = yy}
		}
		triangle[14] = { 
			{x = xx + radius * 0.707107, y = yy + radius * -0.707107},
			{x = xx + radius * 0.920505, y = yy + radius * -0.390731},
			{x = xx, y = yy}
		}
		triangle[15] = { 
			{x = xx + radius * 0.382683, y = yy + radius * -0.923880},
			{x = xx + radius * 0.707107, y = yy + radius * -0.707107},
			{x = xx, y = yy}
		}
		triangle[16] = { 
			{x = xx, y = yy - radius},
			{x = xx + radius * 0.382683, y = yy + radius * -0.923880},
			{x = xx, y = yy}
		}
	return triangle
end
function DrawCircle(tab, t, color)
	draw.NoTexture()
	surface.SetDrawColor(color.r, color.g, color.b, color.a)
	local tab1 = {{}, {}, {}}
	if t <= 0.0625 then // Тут, к сожалению царит луа, так что никаких switch statement. Даже вариант с таблицей с функцииями хуже справляется.
		local t = t / 0.0625
		tab1[1].x = Lerp(t, tab[1][2].x, tab[1][1].x) // Так что придется довольствоваться if'ами. Может в луа они лучше чем с C..
		tab1[1].y = Lerp(t, tab[1][2].y, tab[1][1].y)
		tab1[2].x = tab[1][2].x
		tab1[2].y = tab[1][2].y
		tab1[3].x = tab[1][3].x
		tab1[3].y = tab[1][3].y
		surface.DrawPoly(tab1)
	elseif t <= 0.125 then
		local t = ( t - 0.0625 ) / 0.0625
		tab1[1].x = Lerp(t, tab[2][2].x, tab[2][1].x)
		tab1[1].y = Lerp(t, tab[2][2].y, tab[2][1].y)
		tab1[2].x = tab[2][2].x
		tab1[2].y = tab[2][2].y
		tab1[3].x = tab[2][3].x
		tab1[3].y = tab[2][3].y
		surface.DrawPoly(tab[1])
		surface.DrawPoly(tab1)
	elseif t <= 0.1875 then
		local t = ( t - 0.125 ) / 0.0625
		tab1[1].x = Lerp(t, tab[3][2].x, tab[3][1].x)
		tab1[1].y = Lerp(t, tab[3][2].y, tab[3][1].y)
		tab1[2].x = tab[3][2].x
		tab1[2].y = tab[3][2].y
		tab1[3].x = tab[3][3].x
		tab1[3].y = tab[3][3].y
		surface.DrawPoly(tab[1])
		surface.DrawPoly(tab[2])
		surface.DrawPoly(tab1)
	elseif t <= 0.25 then
		local t = ( t - 0.1875 ) / 0.0625
		tab1[1].x = Lerp(t, tab[4][2].x, tab[4][1].x)
		tab1[1].y = Lerp(t, tab[4][2].y, tab[4][1].y)
		tab1[2].x = tab[4][2].x
		tab1[2].y = tab[4][2].y
		tab1[3].x = tab[4][3].x
		tab1[3].y = tab[4][3].y
		surface.DrawPoly(tab[1])
		surface.DrawPoly(tab[2])
		surface.DrawPoly(tab[3])
		surface.DrawPoly(tab1)
	elseif t <= 0.3125 then
		local t = ( t - 0.25 ) / 0.0625
		tab1[1].x = Lerp(t, tab[5][2].x, tab[5][1].x)
		tab1[1].y = Lerp(t, tab[5][2].y, tab[5][1].y)
		tab1[2].x = tab[5][2].x
		tab1[2].y = tab[5][2].y
		tab1[3].x = tab[5][3].x
		tab1[3].y = tab[5][3].y
		for i = 1, 4 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.375 then
		local t = ( t - 0.3125 ) / 0.0625
		tab1[1].x = Lerp(t, tab[6][2].x, tab[6][1].x)
		tab1[1].y = Lerp(t, tab[6][2].y, tab[6][1].y)
		tab1[2].x = tab[6][2].x
		tab1[2].y = tab[6][2].y
		tab1[3].x = tab[6][3].x
		tab1[3].y = tab[6][3].y
		for i = 1, 5 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.4375 then
		local t = ( t - 0.375 ) / 0.0625
		tab1[1].x = Lerp(t, tab[7][2].x, tab[7][1].x)
		tab1[1].y = Lerp(t, tab[7][2].y, tab[7][1].y)
		tab1[2].x = tab[7][2].x
		tab1[2].y = tab[7][2].y
		tab1[3].x = tab[7][3].x
		tab1[3].y = tab[7][3].y
		for i = 1, 6 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.5 then
		local t = ( t - 0.4375 ) / 0.0625
		tab1[1].x = Lerp(t, tab[8][2].x, tab[8][1].x)
		tab1[1].y = Lerp(t, tab[8][2].y, tab[8][1].y)
		tab1[2].x = tab[8][2].x
		tab1[2].y = tab[8][2].y
		tab1[3].x = tab[8][3].x
		tab1[3].y = tab[8][3].y
		for i = 1, 7 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.5625 then
		local t = ( t - 0.5 ) / 0.0625
		tab1[1].x = Lerp(t, tab[9][2].x, tab[9][1].x)
		tab1[1].y = Lerp(t, tab[9][2].y, tab[9][1].y)
		tab1[2].x = tab[9][2].x
		tab1[2].y = tab[9][2].y
		tab1[3].x = tab[9][3].x
		tab1[3].y = tab[9][3].y
		for i = 1, 8 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.625 then
		local t = ( t - 0.5625 ) / 0.0625
		tab1[1].x = Lerp(t, tab[10][2].x, tab[10][1].x)
		tab1[1].y = Lerp(t, tab[10][2].y, tab[10][1].y)
		tab1[2].x = tab[10][2].x
		tab1[2].y = tab[10][2].y
		tab1[3].x = tab[10][3].x
		tab1[3].y = tab[10][3].y
		for i = 1, 9 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.6875 then
		local t = ( t - 0.625 ) / 0.0625
		tab1[1].x = Lerp(t, tab[11][2].x, tab[11][1].x)
		tab1[1].y = Lerp(t, tab[11][2].y, tab[11][1].y)
		tab1[2].x = tab[11][2].x
		tab1[2].y = tab[11][2].y
		tab1[3].x = tab[11][3].x
		tab1[3].y = tab[11][3].y
		for i = 1, 10 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.75 then
		local t = ( t - 0.6875 ) / 0.0625
		tab1[1].x = Lerp(t, tab[12][2].x, tab[12][1].x)
		tab1[1].y = Lerp(t, tab[12][2].y, tab[12][1].y)
		tab1[2].x = tab[12][2].x
		tab1[2].y = tab[12][2].y
		tab1[3].x = tab[12][3].x
		tab1[3].y = tab[12][3].y
		for i = 1, 11 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.8125 then
		local t = ( t - 0.75 ) / 0.0625
		tab1[1].x = Lerp(t, tab[13][2].x, tab[13][1].x)
		tab1[1].y = Lerp(t, tab[13][2].y, tab[13][1].y)
		tab1[2].x = tab[13][2].x
		tab1[2].y = tab[13][2].y
		tab1[3].x = tab[13][3].x
		tab1[3].y = tab[13][3].y
		for i = 1, 12 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.875 then
		local t = ( t - 0.8125 ) / 0.0625
		tab1[1].x = Lerp(t, tab[14][2].x, tab[14][1].x)
		tab1[1].y = Lerp(t, tab[14][2].y, tab[14][1].y)
		tab1[2].x = tab[14][2].x
		tab1[2].y = tab[14][2].y
		tab1[3].x = tab[14][3].x
		tab1[3].y = tab[14][3].y
		for i = 1, 13 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t <= 0.9375 then
		local t = ( t - 0.875 ) / 0.0625
		tab1[1].x = Lerp(t, tab[15][2].x, tab[15][1].x)
		tab1[1].y = Lerp(t, tab[15][2].y, tab[15][1].y)
		tab1[2].x = tab[15][2].x
		tab1[2].y = tab[15][2].y
		tab1[3].x = tab[15][3].x
		tab1[3].y = tab[15][3].y
		for i = 1, 14 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	elseif t < 1 then
		local t = ( t - 0.9375 ) / 0.0625
		tab1[1].x = Lerp(t, tab[16][2].x, tab[16][1].x)
		tab1[1].y = Lerp(t, tab[16][2].y, tab[16][1].y)
		tab1[2].x = tab[16][2].x
		tab1[2].y = tab[16][2].y
		tab1[3].x = tab[16][3].x
		tab1[3].y = tab[16][3].y
		for i = 1, 15 do
			surface.DrawPoly(tab[i])
		end
		surface.DrawPoly(tab1)
	else
		for i = 1, 16 do
			surface.DrawPoly(tab[i])
		end
	end
end
function NPC:IsTryingToRevive() // Простенькая функция
	return self:GetNWBool("TryingToRevive")
end
function NPC:SetTryingToRevive(bool) // Простенькая функция
	 self:SetNWBool("TryingToRevive", bool)
end
function NPC:GetReviveEnt() // Простенькая функция
	return self:GetNWEntity("NpcReviveent")
end
function NPC:SetReviveEnt(ent) // Простенькая функция
	self:SetNWEntity("NpcReviveent", ent)
end
function NPC:IsReviving() // Простенькая функция
	return self:GetNWBool("NPCReviving")
end
function NPC:SetReviving(bool) // Простенькая функция
	self:SetNWBool("NPCReviving", bool)
end
function NPC:GetReviveTime() // Простенькая функция
	return self:GetNWFloat("NPCReviveTime")
end
function NPC:SetReviveTime(time) // Простенькая функция
	self:SetNWFloat("NPCReviveTime", time)
end
function PLAYER:IsReviving() // Простенькая функция
	return self:GetNWBool("Reviving")
end
function PLAYER:SetReviving(bool) // Простенькая функция
	self:SetNWBool("Reviving", bool)
end
function PLAYER:GetBloodDelay() // Простенькая функция
	return self:GetNWFloat("Delay")
end
function PLAYER:SetBloodDelay(time) // Простенькая функция
	self:SetNWFloat("Delay", time)
end
function PLAYER:IsNPCReviving() // Простенькая функция
	return self:GetNWBool("NPCReviving")
end
function PLAYER:SetNPCReviving(bool) // Простенькая функция
	self:SetNWBool("NPCReviving", bool)
end
function PLAYER:GetNPCRevivour() // Простенькая функция
	return self:GetNWEntity("NPCRevivingEnt")
end
function PLAYER:SetNPCRevivour(ent) // Простенькая функция
	self:SetNWEntity("NPCRevivingEnt", ent)
end
function PLAYER:GetAttacker() // Простенькая функция
	return self:GetNWEntity("Attacker")
end
function PLAYER:SetAttacker(ent) // Простенькая функция
	self:SetNWEntity("Attacker", ent)
end
function PLAYER:GetAttackerWeapon() // Простенькая функция
	return self:GetNWEntity("AttackerWeap")
end
function PLAYER:SetAttackerWeapon(ent) // Простенькая функция
	self:SetNWEntity("AttackerWeap", ent)
end
function PLAYER:IsBeingReviving() // Простенькая функция
	return self:GetNWBool("BeingReviving")
end
function PLAYER:SetBeingReviving(bool) // Простенькая функция
	self:SetNWBool("BeingReviving", bool)
end
function PLAYER:IsBeingNPCReviving() // Простенькая функция
	return self:GetNWBool("BeingNPCReviving")
end
function PLAYER:SetBeingNPCReviving(bool) // Простенькая функция
	self:SetNWBool("BeingNPCReviving", bool)
end
function PLAYER:GetNumBleedOuts() // Простенькая функция
	return self:GetNWInt("NumBleedOuts")
end
function PLAYER:SetNumBleedOuts(num) // Простенькая функция
	self:SetNWInt("NumBleedOuts", num)
end
function PLAYER:GetReviveTimeFromEntity() // entity - игрок, которого возрождают
	return self:GetNWFloat("ReviveTimeFromEnt")
end
function PLAYER:SetReviveTimeFromEntity(time) // Простенькая функция
	self:SetNWFloat("ReviveTimeFromEnt", time)
end
function PLAYER:GetReviveTime() // Простенькая функция
	return self:GetNWFloat("ReviveTime")
end
function PLAYER:SetReviveTime(time) // Простенькая функция
	self:SetNWFloat("ReviveTime", time)
end
function PLAYER:GetBleedOutTime() // Простенькая функция
	return self:GetNWFloat("BleedOutTime")
end
function PLAYER:SetBleedOutTime(timing)
	self:SetNWFloat("BleedOutTime", timing)
end
function PLAYER:IsBleedOut() // Простенькая функция, показывающая упал ли игрок или нет?
	return self:GetNWBool("BleedOut")
end
function PLAYER:SetBleedOut(bool) // bool - да или нет. Упал или встал? Вот в чем вопрос
	local curtime = CurTime()
	if curtime == nil then //11
		curtime = RealTime() //11
	end
	self:SetNWBool("BleedOut", bool)
	if bool == true then
		self:SetNWFloat("BleedOutTime", curtime)
	else
		self:SetNWFloat("BleedOutTime", 0)
	end
end
function PLAYER:GetRevivingEntity()
	return self:GetNWEntity("RevivingEntity")
end
function PLAYER:SetRevivingEntity(ent)
	self:SetNWEntity("RevivingEntity", ent)
end

--- ^ shared functions
if SERVER then // Добавляю нетворк вары. Все предназначено для клиента.
	util.AddNetworkString("bleedout_go") // Когда кто то упал
	util.AddNetworkString("bleedout_out") // Когда кто то всталл
	util.AddNetworkString("bleedout_settable") // Сам процесс воскрешения.
	util.AddNetworkString("bleedout_suicide") // Типо команда, позволяющая сдохнуть. Наподобии kill
	util.AddNetworkString("bleedout_help") // Типо команда, позволяющая позвать на помощь.
end
if SERVER then
	function serverthink()
		local time = CurTime()
		for k, v in pairs(player.GetRevivingPlayers()) do // Эта функция где то на 260 строке. Уже нет....
			time1 = v:GetReviveTime()
			if time1 != 0 then
				time2 = time1 + convar6:GetInt()
				if v:GetRevivingEntity():IsBleedOut() == false then
					v:SetReviving(false)
					v:SetWalkSpeed(200)
					v:SetRunSpeed(400)
					v:GetRevivingEntity():StopReviving() // GetRevivingEntity - игрок, которого воскрешают. 
					v:GetRevivingEntity():Revive()
					v:SetRevivingEntity(Entity(0)) // Очищаем ненужные вещи.
				end
				if time >= time2 then
					v:SetReviving(false)
					v:SetWalkSpeed(200)
					v:SetRunSpeed(400)
					v:GetRevivingEntity():StopReviving() // GetRevivingEntity - игрок, которого воскрешают. 
					v:GetRevivingEntity():Revive()
					v:SetRevivingEntity(Entity(0)) // Очищаем ненужные вещи.
				end
			end
		end
		for k, v in pairs(player.GetBleedOuts()) do
			time1 = v:GetBleedOutTime()
			if convar27:GetBool() == true and time > v:GetBloodDelay() then
				util.Decal( "Blood", v:EyePos(), v:GetPos() - Vector(0, 0, 10), v )
				v:SetBloodDelay(CurTime() + 1)
			end
			if convar25:GetBool() == true then
				if v:IsNPCReviving() == false then // Снизу идет поиск нпс ревайвора.
					for _, ents in pairs(ents.GetAll()) do
						if table_npc[ents:GetClass()] then
							if ents:Visible(v) and ents:IsTryingToRevive() == false and ents:IsUnreachable(v) == false and v:IsNPCReviving() == false and ents:GetPos():Distance(v:GetPos()) < 512 and ents:Disposition( v ) == D_LI and v:IsBeingReviving() == false then
								ents:SetTryingToRevive(true)
								ents:SetReviveEnt(v)
								vectors = v:GetPos() + Vector(0, 0, 31)
								ents:SetSaveValue("m_vecLastPosition", vectors)
								ents:SetSchedule(SCHED_FORCED_GO_RUN)
								v:SetNPCReviving(true)
								v:SetNPCRevivour(ents)
							end
						end
					end
				else
					local revivour = v:GetNPCRevivour()
					if IsValid(revivour) == false or revivour:GetPos():Distance(v:GetPos() + Vector(0, 0, 36)) > 2048 or v:IsBleedOut() == false or v:IsBeingReviving() == true and !IsValid(v:GetNPCRevivour()) then 
						v:SetNPCRevivour(Entity(0))
						if IsValid(revivour) then 
								revivour:SetReviving(false)
								revivour:SetReviveTime(0)
								revivour:SetTryingToRevive(false)
								revivour:SetReviveEnt(Entity(0)) end
						revivour = Entity(0)
						v:SetNPCReviving(false)
						if v:IsBeingNPCReviving() == true then
							v:SetBeingNPCReviving(false)
							v:StopReviving()
						end
					elseif v:GetPos():Distance(vectors) > 64 then
						vectors = v:GetPos() + Vector(0, 0, 31)
						revivour:SetSaveValue("m_vecLastPosition", vectors)
						revivour:SetSchedule(SCHED_FORCED_GO_RUN)
					end
					if revivour != Entity(0) then
						if revivour:GetPos():Distance(v:GetPos() + Vector(0, 0, 36)) <= 128 and revivour:IsReviving() == false and !revivour:IsMoving() and v:IsBleedOut() == true and v:IsBeingReviving() == false then
							revivour:SetReviving(true)
							revivour:SetReviveTime(CurTime())
							v:SetBeingReviving(true)
							v:SetBeingNPCReviving(true)
							v:StartReviving()
						elseif revivour:IsReviving() == true then
							local npctime1 = CurTime()
							local npctime2 = revivour:GetReviveTime() + convar6:GetInt()
							if npctime1 >= npctime2 then
								revivour:SetReviving(false)
								revivour:SetReviveTime(0)
								v:SetBeingNPCReviving(false)
								revivour:SetTryingToRevive(false)
								revivour:SetReviveEnt(Entity(0))
								v:SetNPCRevivour(Entity(0))
								v:SetNPCReviving(false)
								v:StopReviving()
								v:Revive()
								revivour = Entity(0)
							end
						end
					end
				end
			end
			if time1 != 0 and v:IsBeingReviving() == false then
				time2 = time1 + convar5:GetInt()
				if time >= time2 then
					v:Freeze(false)
					v:GodDisable()
					v:SetNoTarget(false)
					v:Kill()
				end
			end
		end
	end
	hook.Add( "PlayerButtonDown", "PlayerButtonDownWikiExample", function( ply, button )
		if button == KEY_E and ply:IsBleedOut() == false and ply:IsReviving() == false then
			ply:TryRevive()
		end
	end)
	hook.Add( "PlayerButtonUp", "PlayerButtonDownWikiExample", function( ply, button )
		if button == KEY_E and ply:IsBleedOut() == false and ply:IsReviving() == true then
			ply:SetReviving(false)
			ply:GetRevivingEntity():StopReviving()
			ply:GetRevivingEntity():SetBleedOutTime(CurTime() - ply:GetReviveTimeFromEntity())
			ply:SetRevivingEntity(Entity(0))
		end
	end)
	hook.Add( "Think", "CheckDistanceRevive", function()
		for _, ply in pairs(player.GetAll()) do
			if ply:IsReviving() and ply:Alive() then
				local target = ply:GetRevivingEntity()
				if ply:GetPos():Distance(target:GetPos()) > 91 then
					ply:SetReviving(false)
					target:StopReviving()
					target:SetBleedOutTime(CurTime() - ply:GetReviveTimeFromEntity())
					ply:SetRevivingEntity(Entity(0))
				end
			end
		end
	end)
end
if CLIENT then
	function PLAYER:Revive()
	end
	local mator = Material("bleedout/REVIVESKULL.png") // Иконка revive над игроками
	local mator0 = Material("bleedout/REVIVEICON.png") // COD версия иконки
	local mator1 = Material("bleedout/BLOODONSCR.png") // Кровь
	local itext1 = Material("bleedout/BLOODONSCR.png"):GetTexture("$basetexture") // Кешированая текстура
	local mator2 = Material("bleedout/BLEEDINGOUT.png") // Таймер
	local skullmat = Material("bleedout/SKULL.png") // Черепок
	local syrmat = Material("bleedout/SYRINGE.png") // Шприц
	local itext2 = Material("bleedout/BLEEDINGOUT.png"):GetTexture("$basetexture") // Кешированая текстура
	local centre = ScrW() / 2
	local centrey = ScrH() - 96
	local circle = BuildCircle(centre, centrey, 64)
	local circle2 = BuildCircle(centre, centrey, 42)
	hook.Add("PostDrawOpaqueRenderables", "IconBleedoutNPC", function()
		for _, ent in pairs(ents.FindByClass('downed_entity')) do
			render.DepthRange(0, 0)
			render.SetMaterial(Material("bleedout/REVIVEICON.png")) // Ставит кастомный материал.
			vpos = ent:GetPos() + Vector(0, 0, 72)
			local time = CurTime()
			local time1 = ent:GetNWFloat("timetodeath") + convar5:GetInt()
			local time2 = time1 - time
			local percenttime = time2 / convar5:GetInt()
			--print(time1, time2, percenttime)
			if percenttime > 0 then
				render.DrawSprite(vpos, convar14:GetInt(), convar14:GetInt(), LerpColor(percenttime, Color(255,0,0), Color(0,255,0)))
			else
				render.DrawSprite(vpos, convar14:GetInt(), convar14:GetInt(), Color(255,255,255))
			end
			render.DepthRange(0, 1)
		end
	end )
	hook.Add("HUDPaint", "BleedOutHudPrint", function()
		if LocalPlayer():IsBleedOut() == true and convar15:GetBool() == true then
			surface.SetMaterial(mator1)
			local time = CurTime()
			local time1 = LocalPlayer():GetBleedOutTime() + convar5:GetInt()
			local time2 = time1 - time
			local percenttime = time2 / convar5:GetInt() // Делает это в виде процента десятичной системы
			if percenttime < 0 then percenttime = 1 end
			surface.SetDrawColor(255, 255, 255, Lerp(percenttime, 255, 0) )
			surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
		end
		if LocalPlayer():IsBleedOut() and LocalPlayer():GetBleedOutTime() == 0 then
			draw.DrawText("Your friend is reviving you.", "Trebuchet24", ScrW() * 0.5, ScrH() * 0.8, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
		end
		if LocalPlayer():IsBleedOut() and convar38:GetBool() then
			draw.DrawText("Hold SPACE to suicide", "Trebuchet24", ScrW() * 0.5, ScrH() * 0.7, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
		end
		if LocalPlayer():IsBleedOut() and LocalPlayer():GetNWInt("selfrevive") > 0 then
			draw.DrawText("Press CTRL to self-revive", "Trebuchet24", ScrW() * 0.5, ScrH() * 0.675, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
		end
		if LocalPlayer():IsReviving() and convar21:GetBool() and convar19:GetInt() == 0 then
			local time = CurTime()
			local time1 = LocalPlayer():GetReviveTime() + convar6:GetFloat()
			local time2 = time1 - time
			local time3 = ( time2 - convar6:GetFloat() ) * -1
			local percenttime = time3 / convar6:GetInt()
			DrawCircle(circle, percenttime, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)))
			DrawCircle(circle2, 1, Color(0,0,0) )
			surface.SetMaterial(syrmat)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawTexturedRect(centre - 32, centrey - 32, 64, 64)
		elseif LocalPlayer():IsReviving() == true and convar21:GetBool() == true and convar19:GetInt() == 1 then
			local time = CurTime()
			local time1 = LocalPlayer():GetReviveTime() + convar6:GetFloat()
			local time2 = time1 - time
			local time3 = ( time2 - convar6:GetFloat() ) * -1
			local percenttime = time3 / convar6:GetInt()
			widthdif = ScrW() * 0.6 - ScrW() * 0.4
			local greenboxmetr = widthdif * percenttime
			local greenred = LerpColor(percenttime, Color(255,0,0), Color(0,255,0))
			draw.DrawText("Reviving.", "Trebuchet24", ScrW() * 0.5, ScrH() * 0.8, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
			surface.SetDrawColor(50, 50, 50, 255)
			surface.DrawRect(ScrW() * 0.4, ScrH() * 0.7, ScrW() * 0.6 - ScrW() * 0.4, ScrH() * 0.75 - ScrH() * 0.7)
			surface.SetDrawColor(greenred.r, greenred.g, greenred.b)
			surface.DrawRect(ScrW() * 0.4, ScrH() * 0.7, greenboxmetr, ScrH() * 0.75 - ScrH() * 0.7)
		elseif LocalPlayer():IsReviving() == true and convar21:GetBool() == true and convar19:GetInt() == 2 then
			local time = CurTime()
			local time1 = LocalPlayer():GetReviveTime() + convar6:GetFloat()
			local time2 = math.ceil(time1 - time)
			draw.DrawText(tostring(time2), "Trebuchet24", ScrW() * 0.5, ScrH() * 0.725, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
			draw.DrawText("Reviving.", "Trebuchet24", ScrW() * 0.5, ScrH() * 0.8, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
		elseif LocalPlayer():IsReviving() == true and convar21:GetBool() == true and convar19:GetInt() == 3 then
			local time = CurTime()
			local time1 = LocalPlayer():GetReviveTime() + convar6:GetFloat()
			local time2 = time1 - time
			local time3 = ( time2 - convar6:GetFloat() ) * -1
			local percenttime = time3 / convar6:GetInt()
			DrawCircle(circle, percenttime, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)))
			DrawCircle(circle2, 1, Color(0,0,0) )
			surface.SetMaterial(syrmat)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawTexturedRect(centre - 32, centrey - 32, 64, 64)
			surface.DrawCircle(centre, centrey, 63, 0, 0, 0)
			surface.DrawCircle(centre, centrey, 63.5, 0, 0, 0)
			surface.DrawCircle(centre, centrey, 64, 0, 0, 0)
		end
		time = CurTime()
		if LocalPlayer():GetBleedOutTime() != 0 and convar18:GetBool() == true and convar19:GetInt() == 0 then
			local time = CurTime()
			local time1 = LocalPlayer():GetBleedOutTime() + convar5:GetInt()
			local time2 = time1 - time
			local percenttime = time2 / convar5:GetInt() // Делает это в виде процента десятичной системы
			DrawCircle(circle, percenttime, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)))
			DrawCircle(circle2, 1, Color(0,0,0))
			surface.SetMaterial(skullmat)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawTexturedRect(centre - 32, centrey - 32, 64, 64)
		elseif LocalPlayer():GetBleedOutTime() != 0 and convar18:GetBool() == true and convar19:GetInt() == 1 then
			local time = CurTime()
			local time1 = LocalPlayer():GetBleedOutTime() + convar5:GetInt()
			local time2 = time1 - time
			widthdif = ScrW() * 0.85 - ScrW() * 0.7 // Так как я делаю это без знаний сколько у игрока разрешение - использую scrw и тому подобное. Сейчас это отнимание большей части и меньшей и получение их разницы. В итоге получаем ширину
			local percenttime1 = time2 / convar5:GetInt() // Делает это в виде процента десятичной системы
			local greenboxmetr1 = widthdif * percenttime1
			surface.SetDrawColor(255, 255, 255, 230)
			surface.SetMaterial(mator2)
			local greenred = LerpColor(percenttime1, Color(255,0,0), Color(0,255,0))
			surface.DrawTexturedRect(ScrW() * 0.6, ScrH() * 0.6, ScrW() - ScrW() * 0.6, ScrH() - ScrH() * 0.6)
			surface.SetDrawColor(100, 100, 100, 255)
			surface.DrawRect(ScrW() * 0.7, ScrH() * 0.8, ScrW() * 0.85 - ScrW() * 0.7, ScrH() * 0.825 - ScrH() * 0.8)
			surface.SetDrawColor(greenred.r, greenred.g, greenred.b)
			surface.DrawRect(ScrW() * 0.7, ScrH() * 0.8, greenboxmetr1, ScrH() * 0.825 - ScrH() * 0.8)
		elseif LocalPlayer():GetBleedOutTime() != 0 and convar18:GetBool() == true and convar19:GetInt() == 2 then // Legacy UI
			local time = CurTime()
			local time1 = LocalPlayer():GetBleedOutTime() + convar5:GetInt()
			local time2 = math.ceil(time1 - time)
			draw.DrawText("You are Bleeding Out!", "Trebuchet24", ScrW() - 200, ScrH() - 200, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
			draw.DrawText(tostring(time2), "Trebuchet24", ScrW() - 200, ScrH() - 165, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER)
		elseif LocalPlayer():GetBleedOutTime() != 0 and convar18:GetBool() == true and convar19:GetInt() == 3 then
			local time = CurTime()
			local time1 = LocalPlayer():GetBleedOutTime() + convar5:GetInt()
			local time2 = time1 - time
			local percenttime = time2 / convar5:GetInt() // Делает это в виде процента десятичной системы
			DrawCircle(circle, percenttime, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)))
			DrawCircle(circle2, 1, Color(0,0,0))
			surface.SetMaterial(skullmat)
			surface.SetDrawColor(255, 255, 255)
			surface.DrawTexturedRect(centre - 32, centrey - 32, 64, 64)
			surface.DrawCircle(centre, centrey, 63, 0, 0, 0)
			surface.DrawCircle(centre, centrey, 63.5, 0, 0, 0)
			surface.DrawCircle(centre, centrey, 64, 0, 0, 0)
		end
	end)
	hook.Add("PostPlayerDraw", "BleedoutIconDraw", function(ply)
		if ply:IsBleedOut() == true and convar3:GetBool() == true then
			if convar7:GetBool() == false then
				if convar13:GetString() != "bleedout/REVIVEICON.png" and convar13:GetString() != "bleedout/REVIVESKULL.png" then
					cam.Start2D()
					surface.SetDrawColor(255, 255, 255)
					local mat1 = Material(convar13:GetString(), alphatest) // Кастомный материал
					surface.SetMaterial(mat1)
					vpos = ply:GetPos() + Vector(0, 0, 72)
					local pos = vpos:ToScreen() // Для оптимизации, если не видно - значит хер с ним.
					surface.SetDrawColor( 255,255,255 )
					if pos.visible == true then
						surface.DrawTexturedRect( pos.x - convar14:GetInt() * 0.5 , pos.y - convar14:GetInt() * 0.5, convar14:GetInt() * 2, convar14:GetInt() * 2 )
					end
					cam.End2D()
				elseif convar13:GetString() == "bleedout/REVIVEICON.png" then
					cam.Start2D()
					surface.SetMaterial(mator0)
					local time1 = ply:GetBleedOutTime() + convar5:GetInt()
					local time2 = time1 - time
					vpos = ply:GetPos() + Vector(0, 0, 72)
					local pos = vpos:ToScreen() // Для оптимизации, если не видно - значит хер с ним.
					local percenttime = time2 / convar5:GetInt()
					if percenttime > 0 then
						surface.SetDrawColor(LerpColor(percenttime, Color(255,0,0), Color(0,255,0)).r, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)).g, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)).b)
					else
						surface.SetDrawColor(255, 255, 255)
					end
					if pos.visible == true then
						surface.DrawTexturedRect( pos.x - convar14:GetInt() , pos.y - convar14:GetInt(), convar14:GetInt() * 2, convar14:GetInt() * 2 )
					end
					cam.End2D()
				elseif convar13:GetString() == "bleedout/REVIVESKULL.png" then
					cam.Start2D()
					surface.SetMaterial(mator)
					local time1 = ply:GetBleedOutTime() + convar5:GetInt()
					local time2 = time1 - time
					vpos = ply:GetPos() + Vector(0, 0, 72)
					local pos = vpos:ToScreen() // Для оптимизации, если не видно - значит хер с ним.
					local percenttime = time2 / convar5:GetInt()
					if percenttime > 0 then
						surface.SetDrawColor(LerpColor(percenttime, Color(255,0,0), Color(0,255,0)).r, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)).g, LerpColor(percenttime, Color(255,0,0), Color(0,255,0)).b)
					else
						surface.SetDrawColor(255, 255, 255)
					end	
					if pos.visible == true then
						surface.DrawTexturedRect( pos.x - convar14:GetInt() , pos.y - convar14:GetInt(), convar14:GetInt() * 2, convar14:GetInt() * 2 )
					end
					cam.End2D()
				end
			elseif convar13:GetString() != "bleedout/REVIVESKULL.png" and convar13:GetString() != "bleedout/REVIVEICON.png" then // Функция, которая позволяет менять текстурки иконок с помощью конс. Команд.
				render.DepthRange(0, 0)
				local mat1 = Material(convar13:GetString(), alphatest) // Кастомный материал
				render.SetMaterial(mat1) // Ставит кастомный материал.
				vpos = ply:GetPos() + Vector(0, 0, 72)
				render.DrawSprite(vpos, convar14:GetInt(), convar14:GetInt(), Color(255,255,255) )
				render.DepthRange(0, 1)
			elseif convar13:GetString() == "bleedout/REVIVEICON.png" then
				render.DepthRange(0, 0)
				render.SetMaterial(mator0) // Ставит кастомный материал.
				vpos = ply:GetPos() + Vector(0, 0, 72)
				local time = CurTime()
				local time1 = ply:GetBleedOutTime() + convar5:GetInt()
				local time2 = time1 - time
				local percenttime = time2 / convar5:GetInt()
				if percenttime > 0 then
					render.DrawSprite(vpos, convar14:GetInt(), convar14:GetInt(), LerpColor(percenttime, Color(255,0,0), Color(0,255,0)))
				else
					render.DrawSprite(vpos, convar14:GetInt(), convar14:GetInt(), Color(255,255,255))
				end
				render.DepthRange(0, 1)
			elseif convar13:GetString() == "bleedout/REVIVESKULL.png" then
				render.DepthRange(0, 0)
				render.SetMaterial(mator) // Ставит кастомный материал.
				vpos = ply:GetPos() + Vector(0, 0, 72)
				local time = CurTime()
				local time1 = ply:GetBleedOutTime() + convar5:GetInt()
				local time2 = time1 - time
				local percenttime = time2 / convar5:GetInt()
				if percenttime > 0 then
					render.DrawSprite(vpos, convar14:GetInt(), convar14:GetInt(), LerpColor(percenttime, Color(255,0,0), Color(0,255,0)))
				else
					render.DrawSprite(vpos, convar14:GetInt(), convar14:GetInt(), Color(255,255,255))
				end
				render.DepthRange(0, 1)
			end
		end
	end)
	hook.Add("PostDrawOpaqueRenderables", "BleedoutOutlines", function()
		if convar2:GetBool() == true then
			for k, v in pairs(tabhalo) do
				render.SetStencilWriteMask( 0xFF )
				render.SetStencilTestMask( 0xFF )
				render.SetStencilReferenceValue( 0 )
				render.SetStencilPassOperation( STENCIL_KEEP )
				render.SetStencilFailOperation( STENCIL_KEEP )
				render.SetStencilZFailOperation( STENCIL_KEEP )
				render.ClearStencil()
				render.SetStencilEnable( true )
				render.SetStencilReferenceValue( 1 )
				render.SetStencilCompareFunction( STENCIL_NOTEQUAL )
				render.SetStencilZFailOperation( STENCIL_REPLACE )
				v:DrawModel()
				if v:GetActiveWeapon() != NULL then
					v:GetActiveWeapon():DrawModel()
				end
				render.SetStencilCompareFunction( STENCIL_EQUAL )
				render.ClearBuffersObeyStencil(convar8:GetFloat(), convar9:GetFloat(), convar10:GetFloat(), 255, false);
				render.SetStencilEnable( false )
				v:DrawModel()
				if v:GetActiveWeapon() != NULL then
					v:GetActiveWeapon():DrawModel()
				end
			end
		else
			for k, v in pairs(tabhalo) do
				v:DrawModel()
			end
		end
	end)
	hook.Add("PlayerBindPress", "DisableJumpingAndCrouching", function(ply, bind, bool) // Если игрок упал, то он не сможет нажать прыжок и присед
		if bind == "+jump" and ply:IsBleedOut() == true or bind == "+duck" and ply:IsBleedOut() == true then
			return true
		end
	end)
	local totab = 
	{
		[ "$pp_colour_addr" ] = 0.35,
		[ "$pp_colour_addg" ] = 0.01,
		[ "$pp_colour_addb" ] = 0.01,
		[ "$pp_colour_brightness" ] = -0.55,
		[ "$pp_colour_contrast" ] = 1.5,
		[ "$pp_colour_colour" ] = 0.2,
		[ "$pp_colour_mulr" ] = 0.5,
		[ "$pp_colour_mulg" ] = 1,
		[ "$pp_colour_mulb" ] = 1
	}
	local fromtab = 
	{
		[ "$pp_colour_addr" ] = 0,
		[ "$pp_colour_addg" ] = 0,
		[ "$pp_colour_addb" ] = 0,
		[ "$pp_colour_brightness" ] = 0,
		[ "$pp_colour_contrast" ] = 1,
		[ "$pp_colour_colour" ] = 0,
		[ "$pp_colour_mulr" ] = 1,
		[ "$pp_colour_mulg" ] = 1,
		[ "$pp_colour_mulb" ] = 1,
	}
	local blacknwhitetab = 
	{
		[ "$pp_colour_addr" ] = 0,
		[ "$pp_colour_addg" ] = 0,
		[ "$pp_colour_addb" ] = 0,
		[ "$pp_colour_brightness" ] = 0,
		[ "$pp_colour_contrast" ] = 1,
		[ "$pp_colour_colour" ] = 0,
		[ "$pp_colour_mulr" ] = 0,
		[ "$pp_colour_mulg" ] = 0,
		[ "$pp_colour_mulb" ] = 0,
	}
	hook.Add("RenderScreenspaceEffects", "BleedOutColorCorrection", function()
		if LocalPlayer():IsBleedOut() and convar16:GetBool() then // Если игрок упал + конвара если стоит
			local time = CurTime()
			local time1 = LocalPlayer():GetBleedOutTime() + convar5:GetInt()
			local time2 = time1 - time
			local percenttime = time2 / convar5:GetInt() // Делает это в виде процента десятичной системы
			if percenttime < 0 then percenttime = 1 end
			DrawColorCorrection(percenttime, totab, fromtab)
		elseif LocalPlayer():GetNumBleedOuts() >= convar17:GetInt() and convar32:GetBool() == true then
			DrawColorModify(blacknwhitetab)
		end
	end)
	hook.Add("CreateMove", "DisableLeftRight", function(cmd)
		if LocalPlayer():IsBleedOut() then
			cmd:SetSideMove(0)
		end
	end)
end
hook.Add("CalcMainActivity", "BleedOutActivity", function(ply, vel)
	local angle, angle2 = vel:Angle(), ply:GetAngles()
	local ydif = math.abs(math.NormalizeAngle(angle.y-angle2.y))
	if ply:IsBleedOut() then
		if not convar12:GetBool() then 
			ply:ManipulateBoneAngles( ply:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(-70,0,0) )
			ply:ManipulateBoneAngles( ply:LookupBone("ValveBiped.Bip01_R_Upperarm"), Angle(0,-20,0) )
		else
			ply:ManipulateBoneAngles( ply:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(0,0,0) )
			ply:ManipulateBoneAngles( ply:LookupBone("ValveBiped.Bip01_R_Upperarm"), Angle(0,0,0) )
		end
		local seq1 = ply:LookupSequence("crawl_idle")
		local seq2 = ply:LookupSequence("crawl_idle2")
		local seq3 = ply:LookupSequence("crawl_back")
		local seq4 = ply:LookupSequence("crawl_forward")
		if ply:Health() > 1 and vel:Length2D() < 1 or !convar11:GetBool() then
			return ACT_IDLE, seq1
		elseif ply:Health() <= 1 and convar34:GetBool() then
			return ACT_IDLE, seq2
		elseif ydif < 90 then
			return ACT_IDLE, seq4
		else
			return ACT_IDLE, seq3
		end
	end
end)
hook.Add("UpdateAnimation", "BleedOutAnims", function(ply, vel, seqspeed)
	if ply:IsBleedOut() then
		local len = vel:Length2D()
		ply:ManipulateBonePosition(0, loweredpos)
		ply:ManipulateBoneAngles(0, rotate)
		ply:SetPoseParameter("move_x", -1)
		ply:SetPlaybackRate(0)
		ply:SetCycle(CurTime()*1.5)
	else
		ply:ManipulateBonePosition(0, Vector(0,0,0))
		ply:ManipulateBoneAngles(0, Angle(0,0,0))
	end
end)
hook.Add("SetupMove", "BleedOutSetupMove", function(ply, move, cmd)
	if ply:IsBleedOut() and not convar11:GetBool() then
		move:SetMaxSpeed(1)
		move:SetMaxClientSpeed(1)
	elseif ply:IsBleedOut() and convar11:GetBool() then
		move:SetMaxSpeed(37.5)
		move:SetMaxClientSpeed(37.5)
	end
	if SERVER then
		if ply:GetActiveWeapon() != NULL then ply.OldWeap = ply:GetActiveWeapon() end
		if ply:IsBleedOut() == true and convar12:GetBool() == false and ply:Alive() == true then
			if SearchForClassInTable(ply:GetWeapons(), "none") == nil then
				ply:SetActiveWeapon(NULL)
			else
				ply:SelectWeapon( "none" )
			end
			ply:DrawViewModel( SearchForClassInTable(ply:GetWeapons(), "none") and true or false)
		elseif ply:Alive() == true then
			ply:SetActiveWeapon(ply.OldWeap)
			ply:DrawViewModel(true)
		else
			ply:DrawViewModel(true)
		end
	end
end)
if SERVER then
	hook.Add("Think", "WeaponryGive", function()
		for _, ply in pairs(player.GetAll()) do
			if convar37:GetString() == "" then return end
			if ply:IsBleedOut() and ply:Alive() then
				ply:Give(convar37:GetString())
				ply:SelectWeapon(convar37:GetString())
			end
		end
	end)
end
function bleedoutsetfunc(ply, bool) // Спавн функция игроков, выставляет их булины падений при спавне.
	ply:SetBleedOut(false)
	ply:SetReviveTime(0)
	ply:SetReviving(false)
	ply:SetRevivingEntity(Entity(0))
	ply:SetBleedOutTime(0)
	ply:SetNumBleedOuts(0)
	ply:SetBeingReviving(false)
	ply:SetNPCReviving(false)
	ply:SetNPCRevivour(Entity(0))
	ply:SetBeingNPCReviving(false)
end
function bleedoutviewfunc(ply, pos, angles, fov) // view - столбик, оставляем все как есть, но с другим вектором
	local view = {}
	local head = ply:LookupAttachment("eyes")
	local headpos = ply:GetAttachment(head)
	view.origin = pos - loweredview
	if ply:Crouching() then // Если игрок приседает - убираем это в корне
		view.origin = pos - loweredview + Vector(0,0, 36)
	end
	if convar20:GetBool() then
		view.angles = angles + Angle(0, 0, -20)
	else
		view.angles = angles
	end
	if convar26:GetBool() then
		view.origin = headpos.Pos + Vector(4, 0, 6)
	end
	view.fov = fov
	view.znear = 5
	view.drawviewer = convar26:GetBool()
	return view
end
function bleedoutviewmodelviewfunc(wep, vm, oldp, olda, pos, ang)
	local finalpos = pos - loweredview
	if LocalPlayer():Crouching() == true then
		 finalpos = pos - loweredview + Vector(0, 0, 36)
	end
	if convar20:GetBool() == true then
		return finalpos, ang + Angle(0, 0, 10)
	else
		return finalpos, ang
	end
end
hook.Add("EntityFireBullets", "BleedOutFireBullets", function(ply, tab)
	if ply:IsNPC() and ply.IsVJBaseSNPC != true then
		if ply:GetEnemy():IsPlayer() and ply:GetEnemy():IsBleedOut() == true then
			tab.Dir = ( ply:GetEnemy():EyePos() - Vector(0, 0, 35) ) - ply:EyePos() + Vector(math.Rand(-10, 10), math.Rand(-10, 10), math.Rand(-10, 10))
			return true 
		end
	end
	if ply:IsPlayer() then
		local head = ply:LookupAttachment("eyes")
		local headpos = ply:GetAttachment(head).Pos
		if not ply:IsValid() then ply = LocalPlayer() end
		if ply:IsBleedOut() then
			if convar26:GetBool() == false then
				tab.Src = ply:EyePos() - loweredview
			else
				tab.Src = headpos
			end
		end
		return true // для того, что бы изменить начальное положение пули.
	end
end)
hook.Add("PlayerSpawn", "BleedoutSpawn", function(ply)
	ply.fragsbeforedeath = 0
	ply:Revive()
	ply:SetNWInt('selfrevive', 0)
	ply:SetNumBleedOuts(0)
end)
// --- Hook functions are set! ^
if SERVER then
	function PLAYER:TryRevive()
		self:LagCompensation( true )
		local trace = util.QuickTrace(self:EyePos(), self:EyeAngles():Forward() * distancetotrace, self)
		self:LagCompensation(false)
		if not self:IsBleedOut() and not self:IsReviving() and trace.Hit and trace.Entity:IsPlayer() and trace.Entity:IsBleedOut() and not trace.Entity:IsBeingReviving() then
			self:SetReviveTimeFromEntity(CurTime() - trace.Entity:GetBleedOutTime())
			trace.Entity:StartReviving() // Начатие процесса ревайвинга.
			if convar28:GetBool() == true then
				local rand = tostring(math.random(1, 5))
				local string1 = "vo/npc/male01/health0" .. rand .. ".wav"
				self:EmitSound(string1, 75, 100, 1, CHAN_AUTO)
			end
			self:SetReviving(true)
			self:SetRevivingEntity(trace.Entity)
			self:SetVelocity(self:GetVelocity() * -1)
			self:SetReviveTime(CurTime())
		end
	end
	function PLAYER:StartReviving()
		self:SetBeingReviving(true)
		self:SetBleedOutTime(0)
	end
	function PLAYER:StopReviving()
		self:SetBeingReviving(false)
		self:SetBleedOutTime(CurTime())
	end
	function PLAYER:GoBleedOut()
		self:SetBleedOut(true)
		self:SetNWBool("canttakedown", true)
		if convar22:GetBool() == true then // convar22 - как я помню является конварой с нотаргетом. Если включена - значит ок.
			self:SetNoTarget(true)
		end
		self:ExitVehicle()
		if convar33:GetBool() == true then
			self:SetDSP( 16, false ) 
		end
		self:SetBloodDelay(CurTime() + 1)
		self:SetBeingReviving(false)
		self:SetReviving(false)
		self:SetReviveTime(0)
		if self:GetRevivingEntity():IsPlayer() == true then 
			self:GetRevivingEntity():StopReviving()
			self:SetRevivingEntity(Entity(0))
		end
		self:SetHealth(self:GetMaxHealth() * ( convar31:GetFloat() / 100) )
		self:SetHull(duckhullbottom, duckhulltop) // Делаем хулл такой же как у игрока в присяде
		net.Start("bleedout_go") // Скидываем на клиентскую часть, что бы клиенты помучались))
		net.WriteEntity(self)
		net.WriteTable(player.GetBleedOuts())
		net.Broadcast()
		if convar35:GetBool() then
			net.Start("BleedOutMessage")
			net.WriteString(self:Nick())
			net.Broadcast()
		end
		if convar28:GetBool() then
			timer.Create("DownedSounds" .. self:SteamID(), math.random(2,4), 0, function()
				if IsValid(self) then
					self:EmitSound(yellsounds[math.random(1,10)])
				end
			end)
		end
	end
	function PLAYER:Revive() // Воскрешение
		timer.Simple(0, function()
			self:ManipulateBoneAngles( self:LookupBone("ValveBiped.Bip01_R_Forearm"), Angle(0,0,0) )
			self:ManipulateBoneAngles( self:LookupBone("ValveBiped.Bip01_R_Upperarm"), Angle(0,0,0) )
		end)
		self:SetNWBool("canttakedown", false)
		self:SetActiveWeapon(self.OldWeap)
		self:SetBleedOut(false)
		self:SetHealth(self:GetMaxHealth() * 0.5)
		self:SetHull(normalhullbottom, normalhulltop)
		self:SetNoTarget(false)
		self:Freeze(false)
		self:GodDisable()
		self:SetDSP( 0, true ) 
		self:SetBeingReviving(false)
		self:SetBleedOutTime(0)
		self:SetNumBleedOuts(self:GetNumBleedOuts() + 1)
		self:SetNWBool("canttakedown", false)
		net.Start("bleedout_out")
		net.WriteEntity(self)
		net.WriteTable(player.GetBleedOuts())
		net.Broadcast()
		timer.Remove("DownedSounds" .. self:SteamID())
	end
end
// Server Player Functions are set ^
function player.GetRevivingPlayers() // Дает список всех воскрешающих игроков.
	local tab = {}
	for k, v in pairs(player.GetAll()) do
		if v:IsReviving() == true then
			table.insert(tab, v)
		end
	end
	return tab
end
function player.GetBleedOuts() // Для рисовки обводки игроков. Работает онли на сервере, так что когда кто то падает/встает эта штука передается клиенту.
	local tab = {}
	for k, v in pairs(player.GetAll()) do
		if v:IsBleedOut() == true then
			table.insert(tab, v)
		end
	end
	return tab
end
function ents.GetShootingAtBleedOuts()
	local tab = {}
	for k, v in pairs(ents.FindByClass("npc_*")) do
		if v:GetEnemy():IsPlayer() then
			if v:GetEnemy():IsBleedOut() == true then
				table.insert(tab, v)
			end
		end
	end
end
function player.GetNoBleedOuts() // Для теста, дебаг функция, делает абсолютно обратную функцию player.GetBleedOuts(). Т.е - не упавшие игроки
	local tab = {}
	for k, v in pairs(player.GetAll()) do
		if v:IsBleedOut() == false then
			table.insert(tab, v)
		end
	end
	return tab
end
if CLIENT then
	net.Receive("bleedout_settable", function() // Предназначено для передачи тейбла с игроками, упавшими. Хорошая вещь однако
		tabhalo = net.ReadTable()
		table.RemoveByValue(tabhalo, LocalPlayer())
	end)
	net.Receive("bleedout_go", function()
		ply = net.ReadEntity()
		tabhalo = net.ReadTable() // Кидает клиенту столбик с падающими игроками
		table.RemoveByValue( tabhalo, LocalPlayer() ) // Если этого не сделать - будут сверху граф. артефакты.
		if ply == LocalPlayer() then
			hook.Add("CalcView", "BleedOutView", bleedoutviewfunc)
			hook.Add("CalcViewModelView", "BleedOutViewModelView", bleedoutviewmodelviewfunc)
		end
	end)
		net.Receive("bleedout_out", function() 
		ply = net.ReadEntity()
		tabhalo = net.ReadTable()
		table.RemoveByValue( tabhalo, LocalPlayer() )
		if ply == LocalPlayer() then
			hook.Remove("CalcView", "BleedOutView")
			hook.Remove("CalcViewModelView", "BleedOutViewModelView")
		end
	end)
end
hook.Add("PlayerSpawn", "BleedOutSet", bleedoutsetfunc)
if SERVER then
	hook.Add("EntityTakeDamage", "PlayerBleedOutWhen", function(ply, dmginfo)
		local att = dmginfo:GetAttacker()
		if (ply:IsPlayer() ) then // Если ply = игрок и получил дамаг от пули.
			if ply:IsBleedOut() == true then
				dmginfo:ScaleDamage( (ply:GetMaxHealth() - convar23:GetInt()) / 100) // Почему тут MaxHealth я уже не помню
			end
			if ply:Health() <= dmginfo:GetDamage() and not ply:IsBleedOut() and convar4:GetBool() and ply:GetNumBleedOuts() < convar17:GetInt() then
				if convar36:GetInt() > math.random(1,100) then
					if att:IsPlayer() and convar0:GetBool() or not att:IsPlayer() then
						dmginfo:SetDamage(0)
						ply:GoBleedOut()
					end
				end
				ply:SetAttacker( dmginfo:GetAttacker() )
			end
		elseif ply:IsNPC() == true then
			if ply:Health() <= dmginfo:GetDamage() and dmginfo:GetInflictor():IsPlayer() == true and ply:Disposition( dmginfo:GetInflictor() ) != D_LI and dmginfo:GetInflictor():IsBleedOut() == true then
				dmginfo:GetInflictor().fragsbeforedeath = dmginfo:GetInflictor().fragsbeforedeath + 1
			end
			if ply:Health() <= dmginfo:GetDamage() and convar29:GetBool() == true and dmginfo:GetInflictor():IsPlayer() == true and ply:Disposition( dmginfo:GetInflictor() ) != D_LI and dmginfo:GetInflictor():IsBleedOut() == true and dmginfo:GetInflictor().fragsbeforedeath == convar30:GetFloat() then
				dmginfo:GetInflictor():Revive()
				dmginfo:GetInflictor().fragsbeforedeath = 0
			end
		end
		if ply:IsPlayer() then
			if ply:Health() <= dmginfo:GetDamage() and ply:IsBleedOut() and convar34:GetBool() then
				dmginfo:SetDamage(0)
				ply:SetHealth(1)
			end
		end
	end)
	hook.Add("PlayerShouldTakeDamage", "BleedOutDamage", function(attacked, inflictor)
		local time = CurTime()
		local time2 = attacked:GetBleedOutTime() + convar5:GetFloat()
		if convar:GetBool() == false and attacked:IsBleedOut() == true and time < time2 or convar0:GetBool() == false and inflictor:IsPlayer() == true and attacked:IsBleedOut() == false or convar0:GetBool() == false and inflictor:IsPlayer() == true and attacked:IsBleedOut() == true and time < time2 then
			return false
		else
			return true
		end
	end)
	hook.Add("Think", "ServerThink", serverthink)
	hook.Add("PlayerDeath", "BleedOutDeath", function(victim, inflicto, attacker)
		if victim:GetNPCRevivour() != Entity(0) then
			victim:GetNPCRevivour():SetTryingToRevive(false)
			victim:GetNPCRevivour():SetReviveTime(0)
			victim:GetNPCRevivour():SetReviveEnt(Entity(0))
			victim:GetNPCRevivour():SetReviving(false)
		end
		if victim:IsBleedOut() == false and victim:IsReviving() == true then
			victim:SetReviving(false)
			victim:GetRevivingEntity():StopReviving()
			victim:GetRevivingEntity():SetBleedOutTime(CurTime() - victim:GetReviveTimeFromEntity())
			victim:SetRevivingEntity(Entity(0))
		end
		victim:SetBleedOut(false)
		victim:Revive()
		victim:SetNumBleedOuts(0)
		timer.Remove("DieSpace" .. victim:SteamID())
	end)
	hook.Add("PlayerDisconnected", "BleedOutDisconnect", function(ply) // Убираем с столбика значение игрока с дисконектом
		if ply:IsBleedOut() == true then
			local tab = player.GetBleedOuts()
			table.RemoveByValue(tab, ply)
			net.Start("bleedout_settable")
			net.WriteTable(tab)
			net.Broadcast()
		end
	end)
	hook.Add("EntityRemoved", "BleedOutRemove", function(ent) // ТОже самое, но если игрок магически исчез.
		if ent:IsPlayer() == true then
			if ent:IsBleedOut() == true then
				local tab = player.GetBleedOuts()
				table.RemoveByValue(tab, ent)
				net.Start("bleedout_settable")
				net.WriteTable(tab)
				net.Broadcast()	
			end
		end
	end)
	hook.Add("Think", "CantShoot", function()
		for _, ply in pairs(player.GetAll()) do
			if ply:IsBleedOut() and ply:Health() == 1 and convar34:GetBool() and ply:GetBleedOutTime() > 0.1 then
				local eyeang = ply:EyeAngles()
				ply:SetEyeAngles( Angle(0,eyeang.y,0))
				ply:Freeze(true)
				ply:GodEnable()
				ply:SetHealth(1)
				ply:SetNoTarget(true)
			end
		end
	end)
	hook.Add( "PlayerButtonDown", "HoldSuicide", function( ply, button )
		if convar38:GetBool() then
			if button == KEY_SPACE and ply:IsBleedOut() and not ply:IsReviving() and not timer.Exists("DieSpace" .. ply:SteamID()) then
				timer.Create("DieSpace" .. ply:SteamID(), 1.5, 1, function()
					ply:EmitSound("weapons/357_fire2.wav")
					ply:Kill()
				end)
			end
		end
		if ply:GetNWInt('selfrevive') > 0 and button == KEY_LCONTROL and ply:Alive() and ply:IsBleedOut() then
			ply:SetNWInt('selfrevive', ply:GetNWInt('selfrevive')-1)
			ply:Revive()
			ply:EmitSound('items/smallmedkit1.wav')
		end
	end)
	hook.Add( "PlayerButtonUp", "HoldSuicide", function( ply, button )
		if convar38:GetBool() then
			if button == KEY_SPACE and ply:IsBleedOut() then
				timer.Remove("DieSpace" .. ply:SteamID())
			end
		end
	end)
end

hook.Add( "OnEntityCreated", "SoftEntList", function( ent )
	if ent:IsNPC() then
		if not ent.bleedouts then
			ent.bleedouts = convar17:GetInt()
		end
	end
end )

hook.Add("OnNPCKilled", "DowningNPC", function(npc)
	if table_down_npc[npc:GetClass()] and convar4:GetBool() and convar36:GetInt() >= math.random(1,100) then
		if npc.bleedouts < 1 then return end
		local model = npc:GetModel()
		local bleedouts = npc.bleedouts
		local pos = npc:GetPos()
		local ang = npc:GetAngles()
		local class = npc:GetClass()
		local skin = npc:GetSkin()
		local weapon = "none"
		if IsValid(npc:GetActiveWeapon()) then
			weapon = npc:GetActiveWeapon():GetClass()
		end
		local bg = {}
		for i=0,#npc:GetBodyGroups()-1 do 
			bg[#bg+1] = npc:GetBodygroup(i)
		end
		
		npc:Remove()
		if npc.IsVJBaseSNPC then
			npc.HasDeathRagdoll = false
			npc.HasDeathAnimation = false
		end
		
		local d = ents.Create("downed_entity")
		d:SetPos(pos)
		d:SetAngles(ang)
		d.model = model
		d.skin = skin
		d.class = class
		d.bg = bg
		d.weapon = weapon
		d.bleedouts = bleedouts
		d:Spawn()
		d:DropToFloor()
	end
end)