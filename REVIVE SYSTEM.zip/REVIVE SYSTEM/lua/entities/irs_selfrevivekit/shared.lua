ENT.Type = "anim"
ENT.Spawnable = true
ENT.Category = "IRS: Items"
ENT.PrintName = "Self Revive Kit"
ENT.AdminOnly = true