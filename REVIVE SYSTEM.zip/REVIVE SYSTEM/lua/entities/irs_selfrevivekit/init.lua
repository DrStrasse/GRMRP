AddCSLuaFile('shared.lua')
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/irs/selfrevive/pg_shot.mdl')
	self:SetSolid(SOLID_VPHYSICS)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
end

function ENT:Use(ply)
	self:Remove()
	ply:SetNWBool('selfrevive', ply:GetNWBool('selfrevive')+1)
	ply:ChatPrint('You picked up Self Revive Kit!')
end