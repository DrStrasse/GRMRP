ENT.Type = "anim"
ENT.Spawnable = false