AddCSLuaFile('shared.lua')
AddCSLuaFile('cl_init.lua')
include("shared.lua")

function ENT:Initialize()
	local yellsounds = {"vo/npc/male01/help01.wav","vo/npc/male01/pain01.wav","vo/npc/male01/pain02.wav","vo/npc/male01/pain03.wav","vo/npc/male01/pain04.wav","vo/npc/male01/pain05.wav","vo/npc/male01/pain06.wav","vo/npc/male01/pain07.wav","vo/npc/male01/pain08.wav","vo/npc/male01/pain09.wav"}
	self.ID = self:EntIndex()
	self:SetModel('models/player/p2_chell.mdl')
	self:SetNoDraw(true)
	self:SetSequence('crawl_idle2')
	self:SetSolid(SOLID_BBOX)
	self:SetNWFloat("timetodeath", CurTime())

	local bm = ents.Create('base_anim')
	self:SetNWEntity("bm", bm)
	bm:Spawn()
	bm:SetModel(self.model)
	bm:SetSkin(self.skin)
	bm:SetPos(self:GetPos())
	for k, v in pairs(self.bg) do
		bm:SetBodygroup(k-1,v)
	end
	bm:SetParent(self)
	bm:AddEffects(EF_BONEMERGE)
	
	self:DeleteOnRemove(bm)
	
	self.bleedouts = self.bleedouts - 1
	
	if GetConVar( "bleedout_message" ):GetBool() then
		net.Start("BleedOutMessage")
		net.WriteString(self.class)
		net.Broadcast()
	end
	
	timer.Create("DownedEntityRemove" .. self.ID,GetConVar("bleedout_death_time"):GetInt(), 1, function()
		self:Remove()
		local entity = ents.Create(self.class)
		entity:SetPos(self:GetPos())
		entity:SetAngles(self:GetAngles())
		entity.bleedouts = 0
		entity:Spawn()
		entity:SetNWBool('fade_bo', true)
		entity:SetModel(self.model)
		entity:SetSkin(self.skin)
		entity:Give(self.weapon)
		for k, v in pairs(self.bg) do
			entity:SetBodygroup(k-1,v)
		end
		entity:DropToFloor()
		entity:SetHealth(1)
		entity:TakeDamage(entity:Health()*5)
	end)
	timer.Create("DownedSounds" .. self.ID, math.random(2,4), 0, function()
		if IsValid(self) and GetConVar("bleedout_sound_enable"):GetBool() then
			self:EmitSound(yellsounds[math.random(1,10)])
		end
	end)
end

function ENT:Use(ply)
	self:Remove()
	
	local entity = ents.Create(self.class)
	entity:SetPos(self:GetPos())
	entity:SetAngles(self:GetAngles())
	entity.bleedouts = self.bleedouts
	entity:Spawn()
	entity:SetModel(self.model)
	entity:SetSkin(self.skin)
	entity:Give(self.weapon)
	for k, v in pairs(self.bg) do
		entity:SetBodygroup(k-1,v)
	end
	entity:DropToFloor()
end

function ENT:OnRemove()
	timer.Remove("DownedEntityRemove" .. self.ID)
	timer.Remove("DownedSounds" .. self.ID)
end