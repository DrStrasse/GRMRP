include('shared.lua')

function ENT:Draw()
	if IsValid(self:GetNWEntity("bm")) then
		render.SetStencilWriteMask( 0xFF )
		render.SetStencilTestMask( 0xFF )
		render.SetStencilReferenceValue( 0 )
		render.SetStencilPassOperation( STENCIL_KEEP )
		render.SetStencilFailOperation( STENCIL_KEEP )
		render.SetStencilZFailOperation( STENCIL_KEEP )
		render.ClearStencil()
		render.SetStencilEnable( true )
		render.SetStencilReferenceValue( 1 )
		render.SetStencilCompareFunction( STENCIL_NOTEQUAL )
		render.SetStencilZFailOperation( STENCIL_REPLACE )
		self:GetNWEntity("bm"):DrawModel()
		render.SetStencilCompareFunction( STENCIL_EQUAL )
		render.ClearBuffersObeyStencil(convar8:GetFloat(), convar9:GetFloat(), convar10:GetFloat(), 255, false);
		render.SetStencilEnable( false )
		self:GetNWEntity("bm"):DrawModel()
	end
end