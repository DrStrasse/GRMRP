ENT.Type = "anim"
ENT.Spawnable = true
ENT.Category = "IRS: Items"
ENT.PrintName = "Medkit"
ENT.AdminOnly = true