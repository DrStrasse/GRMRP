AddCSLuaFile('shared.lua')
include("shared.lua")

function ENT:Initialize()
	self:SetModel('models/irs/medkit/healthkit.mdl')
	self:SetSolid(SOLID_VPHYSICS)
	self:PhysicsInit(SOLID_VPHYSICS)
	self:SetUseType(SIMPLE_USE)
end

function ENT:Use(ply)
	self:Remove()
	ply:SetNumBleedOuts(0)
	ply:SetHealth(math.min( ply:GetMaxHealth(), ply:Health() + 75 ))
	ply:ChatPrint('You picked up Medkit!')
	ply:EmitSound('items/smallmedkit1.wav')
end