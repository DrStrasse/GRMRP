--[[
================================================================================
VEIN Door System - Admin Context Menu
Adds admin options to door context menu
================================================================================
]]--

if SERVER then return end

-- Add admin menu option for doors
hook.Add("OnPlayerChat", "VEIN_AdminDoorCommands", function(ply, text)
    if not ply:IsAdmin() then return end
    
    text = string.lower(text)
    
    -- Check for door group command
    if text == "!doorgroup" or text == "/doorgroup" then
        local trace = ply:GetEyeTrace()
        local door = trace.Entity
        
        if IsValid(door) and door:GetClass():match("door") then
            if ply:GetPos():Distance(door:GetPos()) <= 150 then
                -- Open door group editor
                if VEIN.DoorGroups then
                    VEIN.DoorGroups.OpenEditor(door)
                    return true
                end
            else
                chat.AddText(Color(255, 100, 100), "[VEIN] You're too far from the door!")
                return true
            end
        else
            chat.AddText(Color(255, 100, 100), "[VEIN] You must be looking at a door!")
            return true
        end
    end
end)

-- Add help message and auto-show tutorial for new admins
hook.Add("PlayerInitialSpawn", "VEIN_AdminDoorHelp", function(ply)
    if not ply:IsAdmin() then return end
    
    -- Auto-show tutorial for first-time admins
    timer.Simple(2, function()
        if IsValid(ply) and VEIN and VEIN.Tutorial and VEIN.Tutorial.CheckFirstTime then
            VEIN.Tutorial.CheckFirstTime()
        end
    end)
    
    -- Show help message
    timer.Simple(10, function()
        if IsValid(ply) then
            chat.AddText(
                Color(180, 60, 60), "[VEIN Admin] ",
                Color(200, 200, 205), "Look at a door and type ",
                Color(255, 200, 100), "!doorgroup",
                Color(200, 200, 205), " to edit its job restrictions"
            )
        end
    end)
end)
