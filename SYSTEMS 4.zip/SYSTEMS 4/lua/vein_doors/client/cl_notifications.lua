--[[
================================================================================
VEIN Notification System - Client
================================================================================
Beautiful notification system that slides in from middle-right of screen
Dark VEIN theme with red accents
]]--

if not CLIENT then return end

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.Notifications = VEIN.Notifications or {}

-- Notification queue
local notifications = {}
local nextID = 1

-- Notification types
VEIN.Notifications.INFO = "info"
VEIN.Notifications.SUCCESS = "success"
VEIN.Notifications.WARNING = "warning"
VEIN.Notifications.ERROR = "error"

-- Type colors (dark VEIN theme)
local typeColors = {
    [VEIN.Notifications.INFO] = Color(100, 150, 255), -- Blue
    [VEIN.Notifications.SUCCESS] = Color(100, 255, 100), -- Green
    [VEIN.Notifications.WARNING] = Color(255, 200, 100), -- Orange
    [VEIN.Notifications.ERROR] = Color(255, 100, 100), -- Red
}

-- Type icons
local typeIcons = {
    [VEIN.Notifications.INFO] = "ℹ",
    [VEIN.Notifications.SUCCESS] = "✓",
    [VEIN.Notifications.WARNING] = "⚠",
    [VEIN.Notifications.ERROR] = "✖",
}

-- Add a notification
function VEIN.Notifications.Add(title, message, notifType, duration)
    notifType = notifType or VEIN.Notifications.INFO
    duration = duration or 5 -- Default 5 seconds
    
    local notif = {
        id = nextID,
        title = title,
        message = message,
        type = notifType,
        duration = duration,
        createdAt = CurTime(),
        expiresAt = CurTime() + duration,
        alpha = 0, -- Start invisible
        targetAlpha = 255,
        xOffset = 400, -- Start off-screen to the right
        targetXOffset = 0, -- Slide to visible position
        yOffset = 0, -- Current Y position (for smooth movement)
        targetYOffset = 0, -- Target Y position
        removing = false,
    }
    
    nextID = nextID + 1
    table.insert(notifications, notif)
    
    -- Play notification beep sound
    surface.PlaySound("tools/ifm/beep.wav")
    
    return notif.id
end

-- Remove a notification by ID
function VEIN.Notifications.Remove(id)
    for i, notif in ipairs(notifications) do
        if notif.id == id then
            notif.removing = true
            notif.targetAlpha = 0
            return true
        end
    end
    return false
end

-- Clear all notifications
function VEIN.Notifications.Clear()
    notifications = {}
end

-- Draw notifications
hook.Add("HUDPaint", "VEIN_DrawNotifications", function()
    if #notifications == 0 then return end
    
    local scrW, scrH = ScrW(), ScrH()
    local notifWidth = 350
    local notifHeight = 80
    local padding = 10
    local rightMargin = 20
    local startY = scrH / 4 -- Start from 1/4 down the screen
    
    -- Calculate target Y positions for each notification (for smooth movement)
    local targetY = 0
    for i, notif in ipairs(notifications) do
        if not notif.removing then
            notif.targetYOffset = targetY
            targetY = targetY + notifHeight + padding
        end
    end
    
    -- Update and draw each notification
    local toRemove = {}
    
    for i, notif in ipairs(notifications) do
        local timeRemaining = notif.expiresAt - CurTime()
        
        -- Start fade out when time is up
        if timeRemaining <= 0 and not notif.removing then
            notif.removing = true
            notif.targetAlpha = 0
            notif.targetXOffset = 400 -- Slide out to the right
        end
        
        -- Remove completely when faded out and slid out
        if notif.removing and notif.alpha <= 5 and notif.xOffset >= 380 then
            table.insert(toRemove, i)
        else
        
        -- Animate alpha (fade in/out)
        local fadeSpeed = 600 * FrameTime()
        if notif.removing then
            -- Fade out after progress bar finishes
            notif.alpha = math.Approach(notif.alpha, 0, fadeSpeed * 1.5)
        else
            -- Fade in
            notif.alpha = math.Approach(notif.alpha, 255, fadeSpeed)
        end
        
        -- Animate X position (slide in from right)
        local slideSpeed = 1500 * FrameTime()
        if notif.removing then
            -- Slide out to right faster
            notif.xOffset = math.Approach(notif.xOffset, notif.targetXOffset, slideSpeed * 1.5)
        else
            -- Slide in from right
            notif.xOffset = math.Approach(notif.xOffset, 0, slideSpeed)
        end
        
        -- Animate Y position (smooth vertical movement)
        local moveSpeed = 800 * FrameTime()
        notif.yOffset = math.Approach(notif.yOffset, notif.targetYOffset, moveSpeed)
        
        -- Calculate final position
        local x = scrW - notifWidth - rightMargin + notif.xOffset
        local y = startY + notif.yOffset
        
        -- Draw notification
        local alpha = notif.alpha
        
        -- Background (dark VEIN theme)
        draw.RoundedBox(8, x, y, notifWidth, notifHeight, Color(25, 25, 30, alpha * 0.95))
        
        -- Left accent bar (type color)
        local accentColor = typeColors[notif.type] or Color(255, 255, 255)
        surface.SetDrawColor(accentColor.r, accentColor.g, accentColor.b, alpha)
        surface.DrawRect(x, y, 5, notifHeight)
        
        -- Border (red VEIN theme)
        surface.SetDrawColor(180, 60, 60, alpha * 0.6)
        surface.DrawOutlinedRect(x, y, notifWidth, notifHeight, 2)
        
        -- Type icon
        local icon = typeIcons[notif.type] or "●"
        draw.SimpleText(icon, "DermaLarge", x + 25, y + 15, Color(accentColor.r, accentColor.g, accentColor.b, alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        
        -- Title
        draw.SimpleText(notif.title, "DermaDefaultBold", x + 45, y + 12, Color(255, 255, 255, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        
        -- Message
        draw.SimpleText(notif.message, "DermaDefault", x + 45, y + 32, Color(200, 200, 200, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        
        -- Progress bar (time remaining) - only show if not removing
        if not notif.removing and timeRemaining > 0 then
            local progress = math.Clamp(timeRemaining / notif.duration, 0, 1)
            local barWidth = (notifWidth - 50) * progress
            local barX = x + 45
            local barY = y + notifHeight - 15
            local barHeight = 3
            
            -- Background
            surface.SetDrawColor(50, 50, 55, alpha * 0.5)
            surface.DrawRect(barX, barY, notifWidth - 50, barHeight)
            
            -- Progress
            surface.SetDrawColor(accentColor.r, accentColor.g, accentColor.b, alpha * 0.8)
            surface.DrawRect(barX, barY, barWidth, barHeight)
        end
        end
    end
    
    -- Remove fully expired notifications
    for i = #toRemove, 1, -1 do
        table.remove(notifications, toRemove[i])
    end
end)

-- Helper functions for common notifications
function VEIN.Notifications.Info(title, message, duration)
    return VEIN.Notifications.Add(title, message, VEIN.Notifications.INFO, duration)
end

function VEIN.Notifications.Success(title, message, duration)
    return VEIN.Notifications.Add(title, message, VEIN.Notifications.SUCCESS, duration)
end

function VEIN.Notifications.Warning(title, message, duration)
    return VEIN.Notifications.Add(title, message, VEIN.Notifications.WARNING, duration)
end

function VEIN.Notifications.Error(title, message, duration)
    return VEIN.Notifications.Add(title, message, VEIN.Notifications.ERROR, duration)
end

-- Network receiver for server-sent notifications
net.Receive("VEIN_Notification", function()
    local title = net.ReadString()
    local message = net.ReadString()
    local notifType = net.ReadString()
    local duration = net.ReadFloat()
    
    VEIN.Notifications.Add(title, message, notifType, duration)
end)


