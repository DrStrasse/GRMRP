-- Keep DarkRP door HUD/key menu from overlapping VEIN doors without breaking other addons.

if not CLIENT then return end

local function isDoor(ent)
    if not IsValid(ent) then return false end
    local class = ent:GetClass()
    return class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating"
end

local function shouldBlockDarkRP(ent)
    if not isDoor(ent) then return false end
    if ent:GetNWBool("VEIN_IsVEINDoor", false) then return true end
    local cv = GetConVar("vein_override_darkrp_doors")
    return cv and cv:GetBool() or false
end

-- Block DarkRP HUD for all doors so VEIN UI stays consistent.
hook.Add("HUDDrawDoorData", "VEIN_BlockF2Menu", function(ent)
    if shouldBlockDarkRP(ent) then
        return true -- stop DarkRP door text for our doors only
    end
end)

-- Gently override ShowTeam (F2) so DarkRP keys menu stays hidden on VEIN doors.
timer.Simple(2, function()
    if not GAMEMODE then return end

    local oldShowTeam = GAMEMODE.ShowTeam
    function GAMEMODE:ShowTeam(...)
        local tr = LocalPlayer():GetEyeTrace()
        if tr and shouldBlockDarkRP(tr.Entity) then
            return -- use VEIN UI instead, leave others alone
        end

        if oldShowTeam then
            return oldShowTeam(self, ...)
        end
    end
end)
