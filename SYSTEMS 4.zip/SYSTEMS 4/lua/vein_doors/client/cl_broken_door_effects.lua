-- Broken door visuals without hammering the Think hook.
-- Scans nearby doors on a timer and only processes VEIN-marked broken doors.

if not CLIENT then return end

local playingAmbientSounds = {}
local trackedDoors = {}
local scanRadiusSqr = 800 * 800
local ambientRadiusSqr = 300 * 300

local brokenSounds = {
    "ambient/energy/spark1.wav",
    "ambient/energy/spark2.wav",
    "ambient/energy/spark3.wav",
    "ambient/energy/spark4.wav",
}

local function cleanupDoor(ent)
    local id = ent:EntIndex()
    if playingAmbientSounds[id] then
        playingAmbientSounds[id]:Stop()
        playingAmbientSounds[id] = nil
    end
    trackedDoors[ent] = nil
end

-- Periodic scan keeps the tracked list tight and cheap.
timer.Create("VEIN_BrokenDoorScan", 0.35, 0, function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local pos = ply:GetPos()
    -- retire doors that drifted away or were fixed
    for ent in pairs(trackedDoors) do
        if (not IsValid(ent))
            or not ent:GetNWBool("VEIN_Broken", false)
            or pos:DistToSqr(ent:GetPos()) > scanRadiusSqr then
            cleanupDoor(ent)
        end
    end

    -- add nearby broken doors
    for _, ent in ipairs(ents.FindInSphere(pos, math.sqrt(scanRadiusSqr))) do
        if IsValid(ent)
            and ent:GetNWBool("VEIN_Broken", false)
            and ent:GetClass():find("door", 1, true) then
            trackedDoors[ent] = trackedDoors[ent] or { nextSpark = 0 }
        end
    end
end)

hook.Add("Think", "VEIN_BrokenDoorEffects", function()
    if next(trackedDoors) == nil then return end

    local now = CurTime()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local plyPos = ply:GetPos()

    for ent, state in pairs(trackedDoors) do
        if not IsValid(ent) then
            cleanupDoor(ent)
        else
            local distSqr = plyPos:DistToSqr(ent:GetPos())

            -- Spark bursts throttled per door
            if now >= (state.nextSpark or 0) then
                local effectdata = EffectData()
                local doorMatrix = ent:GetWorldTransformMatrix()
                local localCenter = ent:OBBCenter()
                local sparkPos = doorMatrix and (doorMatrix * localCenter) or ent:GetPos()
                local offset = Vector(math.random(-20, 20), math.random(-20, 20), math.random(-10, 10))

                effectdata:SetOrigin(sparkPos + offset)
                effectdata:SetNormal(ent:GetForward() * -1)
                effectdata:SetMagnitude(2)
                effectdata:SetScale(0.5)
                effectdata:SetRadius(3)
                util.Effect("MetalSpark", effectdata)

                ent:EmitSound(table.Random(brokenSounds), 60, math.random(60, 100), 0.5)
                state.nextSpark = now + math.Rand(1, 2)
            end

            local id = ent:EntIndex()
            if distSqr <= ambientRadiusSqr then
                if not playingAmbientSounds[id] then
                    local soundObj = CreateSound(ent, "ambient/wind/wind_med1.wav")
                    if soundObj then
                        soundObj:SetSoundLevel(70)
                        soundObj:PlayEx(0.3, 80)
                        playingAmbientSounds[id] = soundObj
                    end
                end
            elseif playingAmbientSounds[id] then
                playingAmbientSounds[id]:Stop()
                playingAmbientSounds[id] = nil
            end
        end

    end
end)

-- Clean up sounds when client disconnects or map changes
hook.Add("ShutDown", "VEIN_CleanupAmbientSounds", function()
    for _, soundObj in pairs(playingAmbientSounds) do
        if soundObj then soundObj:Stop() end
    end
    for key in pairs(playingAmbientSounds) do
        playingAmbientSounds[key] = nil
    end
    for key in pairs(trackedDoors) do
        trackedDoors[key] = nil
    end
end)
