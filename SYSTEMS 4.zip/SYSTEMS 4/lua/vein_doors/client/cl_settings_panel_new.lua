--[[
================================================================================
VEIN Door System - NEW Client Settings Panel
Completely rewritten for reliability
================================================================================
]]--

if SERVER then return end

-- Initialize VEIN namespace
VEIN = VEIN or {}
local VEIN = VEIN
VEIN.NewSettingsPanel = {}
VEIN.DoorAdmin = VEIN.DoorAdmin or {isDoorAdmin = false, perms = {}}
VEIN.Net = VEIN.Net or {}

local Net = VEIN.Net

-- Local settings cache
local settingsCache = {
    loaded = false,
    useCustomMoney = true,
    defaultDoorLimit = 3,
    enableDoorLimits = true,
    playerLimits = {},
    doorAdmins = {}
}

local function ClampFrameSize(frame, baseW, baseH)
    local frameW = math.max(360, math.min(baseW, ScrW() - 80))
    local frameH = math.max(300, math.min(baseH, ScrH() - 80))
    if IsValid(frame) then
        frame:SetSize(frameW, frameH)
    end
    return frameW, frameH
end

-- Custom sorting function for DListView that maintains alphabetical order within groups
local function SetupAlphabeticalSorting(listView, defaultSortColumn)
    -- Store the current sort column and direction
    listView.m_iSortColumn = nil
    listView.m_bSortDescending = false
    listView.m_isAddingLines = false -- Flag to prevent sorting during bulk adds
    listView.m_defaultSortColumn = defaultSortColumn -- Store default sort column
    
    -- Store the original AddLine function
    local originalAddLine = listView.AddLine
    
    -- Override AddLine to maintain sort order
    listView.AddLine = function(self, ...)
        local line = originalAddLine(self, ...)
        
        -- Only auto-sort if we have a sort column set and we're not in bulk adding mode
        if not self.m_isAddingLines and self.m_iSortColumn then
            timer.Simple(0, function()
                if IsValid(self) then
                    self:SortByColumn(self.m_iSortColumn, self.m_bSortDescending)
                end
            end)
        end
        
        return line
    end
    
    -- Override the SortByColumn function
    listView.SortByColumn = function(self, columnIndex, descending)
        -- If descending is explicitly provided (not nil), use it
        -- Otherwise toggle if same column, or default to ascending
        if descending ~= nil then
            -- Explicitly set direction (programmatic call)
            self.m_bSortDescending = descending
        elseif self.m_iSortColumn == columnIndex then
            -- Same column clicked - toggle direction
            self.m_bSortDescending = not self.m_bSortDescending
        else
            -- New column - default to ascending
            self.m_bSortDescending = false
        end
        
        self.m_iSortColumn = columnIndex
        local desc = self.m_bSortDescending
        
        -- Get all lines
        local lines = self:GetLines()
        
        -- Sort lines with custom comparison
        table.sort(lines, function(a, b)
            local aVal = a:GetColumnText(columnIndex) or ""
            local bVal = b:GetColumnText(columnIndex) or ""
            local aFirst = a:GetColumnText(1) or ""
            local bFirst = b:GetColumnText(1) or ""
            
            -- If sorting by same column values, sort alphabetically by first column
            if aVal:lower() == bVal:lower() then
                return aFirst:lower() < bFirst:lower()
            end
            
            -- Otherwise sort by the selected column
            if desc then
                return aVal:lower() > bVal:lower()
            else
                return aVal:lower() < bVal:lower()
            end
        end)
        
        -- Set flag to prevent auto-sorting during bulk re-add
        self.m_isAddingLines = true
        
        -- Clear and re-add lines in sorted order
        self:Clear()
        for _, line in ipairs(lines) do
            -- Store the line data and colors
            local columns = {}
            local columnColors = {}
            for i = 1, #self.Columns do
                columns[i] = line:GetColumnText(i)
                -- Preserve column text colors
                if line.Columns[i] then
                    columnColors[i] = line.Columns[i]:GetTextColor()
                end
            end
            
            -- Re-add the line
            local newLine = originalAddLine(self, unpack(columns))
            
            -- Restore column colors
            for i = 1, #self.Columns do
                if columnColors[i] and newLine.Columns[i] then
                    newLine.Columns[i]:SetTextColor(columnColors[i])
                end
            end
            
            -- Copy any custom data from old line to new line
            if line.steamid then newLine.steamid = line.steamid end
            if line.doorIdentifier then newLine.doorIdentifier = line.doorIdentifier end
            if line.Paint then newLine.Paint = line.Paint end
        end
        
        -- Clear flag after re-adding
        self.m_isAddingLines = false
    end
    
    -- Apply default sort if specified
    if defaultSortColumn then
        timer.Simple(0.1, function()
            if IsValid(listView) then
                listView:SortByColumn(defaultSortColumn, false)
            end
        end)
    end
end

-- Simple network receivers
net.Receive("VEIN_SettingsData", function()
    settingsCache.useCustomMoney = net.ReadBool()
    settingsCache.defaultDoorLimit = net.ReadInt(16) 
    settingsCache.enableDoorLimits = net.ReadBool()
    settingsCache.playerLimits = Net.ReadStringIntMap(16)
    settingsCache.loaded = true
    
    -- Refresh panel if it exists and is valid
    if VEIN.NewSettingsPanel.activePanel and IsValid(VEIN.NewSettingsPanel.activePanel) then
        VEIN.NewSettingsPanel.RefreshPanel()
    end
end)

net.Receive("VEIN_PlayerListData", function()
    local players = Net.ReadPlayerList()
    
    if VEIN.NewSettingsPanel.playerListBox and IsValid(VEIN.NewSettingsPanel.playerListBox) then
        -- Set flag to prevent auto-sorting during bulk add
        VEIN.NewSettingsPanel.playerListBox.m_isAddingLines = true
        VEIN.NewSettingsPanel.playerListBox:Clear()
        
        for _, plyData in ipairs(players) do
            -- Format: Name, Owned Doors, Door Limit, SteamID
            local ownedDoors = plyData.ownedDoors or 0
            local doorLimit = plyData.customLimit or plyData.defaultLimit or 3
            local limitText = plyData.customLimit and (doorLimit .. " (Custom)") or (doorLimit .. " (Default)")
            
            local line = VEIN.NewSettingsPanel.playerListBox:AddLine(
                plyData.name, 
                tostring(ownedDoors),
                limitText,
                plyData.steamid
            )
            line.steamid = plyData.steamid
            
            -- Color code based on door usage using Paint hook
            local lineColor = Color(200, 255, 200) -- Default green
            if ownedDoors >= doorLimit then
                lineColor = Color(255, 150, 150) -- Red if at limit
            elseif ownedDoors > doorLimit * 0.7 then
                lineColor = Color(255, 200, 100) -- Orange if close to limit
            end
            
            line.Paint = function(self, w, h)
                if self:IsSelected() then
                    surface.SetDrawColor(60, 60, 100, 200)
                    surface.DrawRect(0, 0, w, h)
                end
            end
            
            -- Set column text colors
            for i = 1, 4 do
                local col = line:GetColumnText(i)
                if col then
                    line:SetColumnText(i, col)
                    line.Columns[i]:SetTextColor(lineColor)
                end
            end
        end
        
        -- Clear flag and trigger sort only if user has set a sort column
        VEIN.NewSettingsPanel.playerListBox.m_isAddingLines = false
        if VEIN.NewSettingsPanel.playerListBox.m_iSortColumn then
            timer.Simple(0, function()
                if IsValid(VEIN.NewSettingsPanel.playerListBox) then
                    VEIN.NewSettingsPanel.playerListBox:SortByColumn(
                        VEIN.NewSettingsPanel.playerListBox.m_iSortColumn,
                        VEIN.NewSettingsPanel.playerListBox.m_bSortDescending
                    )
                end
            end)
        end
    end
end)

net.Receive("VEIN_DoorAdminSelf", function()
    VEIN.DoorAdmin.isDoorAdmin = net.ReadBool()
    VEIN.DoorAdmin.perms = Net.ReadStringBoolMap() or {}
end)

net.Receive("VEIN_DoorAdminList", function()
    settingsCache.doorAdmins = Net.ReadDoorAdminList() or {}

    if VEIN.NewSettingsPanel.doorAdminList and IsValid(VEIN.NewSettingsPanel.doorAdminList) then
        VEIN.NewSettingsPanel.RefreshDoorAdminList()
    end
end)

-- Create the main settings panel
function VEIN.NewSettingsPanel.Create()
    if VEIN.NewSettingsPanel.activePanel and IsValid(VEIN.NewSettingsPanel.activePanel) then
        VEIN.NewSettingsPanel.activePanel:Remove()
    end
    
    -- Clean up any existing timers to prevent spam
    if timer.Exists("VEIN_SliderUpdate") then
        timer.Remove("VEIN_SliderUpdate")
    end
    
    local frame = vgui.Create("DFrame")
    frame:SetTitle("")
    local baseW, baseH = 620, 530
    local frameW = math.max(420, math.min(baseW, ScrW() - 80))
    local frameH = math.max(420, math.min(baseH, ScrH() - 80))
    frame:SetSize(frameW, frameH)
    frame:Center()
    frame:MakePopup()
    frame:SetDeleteOnClose(true)
    frame:ShowCloseButton(false)
    frame:SetDraggable(true)
    
    -- VEIN dark theme
    frame.Paint = function(self, w, h)
        -- Main dark background
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        
        -- Red accent border
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        
        -- Top red accent bar
        surface.SetDrawColor(180, 60, 60, 120)
        surface.DrawRect(10, 10, w - 20, 3)
        
        -- Bottom shadow
        surface.SetDrawColor(10, 10, 12, 150)
        draw.RoundedBox(0, 2, h - 8, w - 4, 8, Color(10, 10, 12, 150))
    end
    
    -- Custom title bar
    local titleBar = vgui.Create("DPanel", frame)
    titleBar:SetPos(0, 0)
    titleBar:SetSize(frameW, 50)
    titleBar.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 33, 200)
        surface.DrawRect(0, 0, w, h)
        
        -- Bottom border
        surface.SetDrawColor(50, 50, 53, 200)
        surface.DrawRect(0, h - 1, w, 1)
    end
    
    -- Title text
    local titleLabel = vgui.Create("DLabel", titleBar)
    titleLabel:SetPos(15, 10)
    titleLabel:SetText("VEIN Door System Configuration")
    titleLabel:SetFont("DermaLarge")
    titleLabel:SetTextColor(Color(255, 200, 200))
    titleLabel:SizeToContents()
    
    -- Close button
    local closeBtn = vgui.Create("DButton", titleBar)
    closeBtn:SetPos(frameW - 50, 11)
    closeBtn:SetSize(28, 28)
    closeBtn:SetText("")
    closeBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(180, 60, 60, 220) or Color(40, 40, 42, 150)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        
        if isHovered then
            surface.SetDrawColor(180, 60, 60, 220)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        -- X symbol
        local centerX, centerY = w/2, h/2
        local size = 6
        local lineColor = isHovered and Color(255, 200, 200) or Color(180, 180, 185)
        surface.SetDrawColor(lineColor)
        surface.DrawLine(centerX - size, centerY - size, centerX + size, centerY + size)
        surface.DrawLine(centerX + size, centerY - size, centerX - size, centerY + size)
    end
    closeBtn.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        frame:Close()
    end
    
    VEIN.NewSettingsPanel.activePanel = frame
    
    -- Admin check
    if not LocalPlayer():IsAdmin() then
        local notice = vgui.Create("DLabel", frame)
        notice:SetText("Admin access required to modify settings")
        notice:SetTextColor(Color(255, 100, 100))
        notice:SetFont("DermaLarge")
        notice:SizeToContents()
        notice:Center()
        return frame
    end
    
    -- Request settings data immediately
    net.Start("VEIN_RequestSettingsData")
    net.SendToServer()
    net.Start("VEIN_RequestDoorAdmins")
    net.SendToServer()
    
    -- Create tabs
    local propertySheet = vgui.Create("DPropertySheet", frame)
    propertySheet:SetPos(10, 60)
    propertySheet:SetSize(frameW - 20, frameH - 70)
    
    -- Dark theme for tabs
    propertySheet.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 33, 200)
        surface.DrawRect(0, 0, w, h)
    end
    
    -- General settings tab
    local generalPanel = vgui.Create("DPanel")
    generalPanel.Paint = function(self, w, h)
        surface.SetDrawColor(25, 25, 28, 255)
        surface.DrawRect(0, 0, w, h)
    end
    
    VEIN.NewSettingsPanel.CreateGeneralControls(generalPanel)
    propertySheet:AddSheet("General Settings", generalPanel, "icon16/cog.png")
    
    -- Player limits tab
    local limitsPanel = vgui.Create("DPanel")
    limitsPanel.Paint = function(self, w, h)
        surface.SetDrawColor(25, 25, 28, 255)
        surface.DrawRect(0, 0, w, h)
    end
    
    VEIN.NewSettingsPanel.CreateLimitsControls(limitsPanel)
    local limitsTab = propertySheet:AddSheet("Player Limits", limitsPanel, "icon16/user.png")
    
    -- Hook to refresh player list when switching to Player Limits tab
    limitsTab.Tab.DoClick = function(self)
        propertySheet:SetActiveTab(self)
        -- Refresh player list when tab is opened
        timer.Simple(0.1, function()
            if IsValid(VEIN.NewSettingsPanel.playerListBox) then
                VEIN.NewSettingsPanel.RefreshPlayerList()
            end
        end)
    end

    -- Door Admins tab (door-only permissions)
    local doorAdminPanel = vgui.Create("DPanel")
    doorAdminPanel.Paint = function(self, w, h)
        surface.SetDrawColor(25, 25, 28, 255)
        surface.DrawRect(0, 0, w, h)
    end
    
    VEIN.NewSettingsPanel.CreateDoorAdminControls(doorAdminPanel)
    local doorAdminTab = propertySheet:AddSheet("Door Admins", doorAdminPanel, "icon16/shield.png")
    doorAdminTab.Tab.DoClick = function(self)
        propertySheet:SetActiveTab(self)
        timer.Simple(0.1, function()
            VEIN.NewSettingsPanel.RequestDoorAdmins()
            VEIN.NewSettingsPanel.RefreshDoorAdminCombo()
        end)
    end
    
    -- Custom Door Types & Materials tab
    local customDoorPanel = vgui.Create("DPanel")
    customDoorPanel.Paint = function(self, w, h)
        surface.SetDrawColor(25, 25, 28, 255)
        surface.DrawRect(0, 0, w, h)
    end
    
    VEIN.NewSettingsPanel.CreateCustomDoorControls(customDoorPanel)
    propertySheet:AddSheet("Custom Doors", customDoorPanel, "icon16/door.png")
    
    -- Door Management tab
    local doorManagementPanel = vgui.Create("DPanel")
    doorManagementPanel.Paint = function(self, w, h)
        surface.SetDrawColor(25, 25, 28, 255)
        surface.DrawRect(0, 0, w, h)
    end
    
    VEIN.NewSettingsPanel.CreateDoorManagementControls(doorManagementPanel)
    local doorMgmtTab = propertySheet:AddSheet("Door Management", doorManagementPanel, "icon16/wrench.png")
    
    -- Hook to refresh door list when switching to Door Management tab
    doorMgmtTab.Tab.DoClick = function(self)
        propertySheet:SetActiveTab(self)
        -- Refresh door list when tab is opened
        timer.Simple(0.1, function()
            if IsValid(VEIN.NewSettingsPanel.doorListBox) then
                VEIN.NewSettingsPanel.RefreshDoorList()
            end
        end)
    end
    
    -- Auto-refresh when data arrives
    timer.Simple(0.5, function()
        if settingsCache.loaded then
            VEIN.NewSettingsPanel.RefreshPanel()
        end
    end)
    
    return frame
end

-- Create general settings controls
function VEIN.NewSettingsPanel.CreateGeneralControls(parent)
    local y = 20
    
    -- Money system
    local moneyLabel = vgui.Create("DLabel", parent)
    moneyLabel:SetText("Money System:")
    moneyLabel:SetTextColor(Color(200, 200, 255))
    moneyLabel:SetFont("DermaDefaultBold")
    moneyLabel:SetPos(20, y)
    moneyLabel:SizeToContents()
    
    local moneyCombo = vgui.Create("DComboBox", parent)
    moneyCombo:SetPos(150, y)
    moneyCombo:SetSize(200, 25)
    moneyCombo:AddChoice("VEIN Custom Money", true)
    moneyCombo:AddChoice("DarkRP Money", false)
    moneyCombo.OnSelect = function(self, index, value, data)
        if VEIN.NewSettingsPanel.isRefreshing then return end
        -- Add small delay to prevent rapid changes
        timer.Simple(0.1, function()
            VEIN.NewSettingsPanel.SendSettingsUpdate()
        end)
    end
    VEIN.NewSettingsPanel.moneyCombo = moneyCombo
    
    -- Current money system status indicator
    local moneyStatus = vgui.Create("DLabel", parent)
    moneyStatus:SetText("(Currently: VEIN Money)")
    moneyStatus:SetTextColor(Color(150, 255, 150))
    moneyStatus:SetFont("DermaDefault")
    moneyStatus:SetPos(360, y)
    moneyStatus:SizeToContents()
    VEIN.NewSettingsPanel.moneyStatus = moneyStatus
    
    y = y + 40
    
    -- Default door limit
    local limitLabel = vgui.Create("DLabel", parent)
    limitLabel:SetText("Default Door Limit:")
    limitLabel:SetTextColor(Color(200, 200, 255))
    limitLabel:SetFont("DermaDefaultBold")
    limitLabel:SetPos(20, y)
    limitLabel:SizeToContents()
    
    local limitSlider = vgui.Create("DNumSlider", parent)
    limitSlider:SetPos(20, y + 20)
    limitSlider:SetSize(300, 25)
    limitSlider:SetMin(1)
    limitSlider:SetMax(20)
    limitSlider:SetDecimals(0)
    limitSlider:SetValue(3)
    limitSlider.OnValueChanged = function(self, value)
        if VEIN.NewSettingsPanel.isRefreshing then return end
        -- Remove existing timer and create new one to prevent spam
        if timer.Exists("VEIN_SliderUpdate") then
            timer.Remove("VEIN_SliderUpdate")
        end
        timer.Create("VEIN_SliderUpdate", 0.5, 1, function()
            VEIN.NewSettingsPanel.SendSettingsUpdate()
        end)
    end
    VEIN.NewSettingsPanel.limitSlider = limitSlider
    
    y = y + 60
    
    -- Enable door limits
    local enableLabel = vgui.Create("DLabel", parent)
    enableLabel:SetText("Enable Door Limits:")
    enableLabel:SetTextColor(Color(200, 200, 255))
    enableLabel:SetFont("DermaDefaultBold")
    enableLabel:SetPos(20, y)
    enableLabel:SizeToContents()
    
    local enableCheck = vgui.Create("DCheckBox", parent)
    enableCheck:SetPos(180, y)
    enableCheck:SetSize(25, 25)
    enableCheck:SetChecked(true)
    enableCheck.OnChange = function(self, value)
        if VEIN.NewSettingsPanel.isRefreshing then return end
        -- Add small delay to prevent rapid changes
        timer.Simple(0.1, function()
            VEIN.NewSettingsPanel.SendSettingsUpdate()
        end)
    end
    VEIN.NewSettingsPanel.enableCheck = enableCheck
    
    y = y + 50
    
    -- Lock/Unlock Time
    local lockTimeLabel = vgui.Create("DLabel", parent)
    lockTimeLabel:SetText("Lock/Unlock Time (seconds):")
    lockTimeLabel:SetTextColor(Color(200, 200, 255))
    lockTimeLabel:SetFont("DermaDefaultBold")
    lockTimeLabel:SetPos(20, y)
    lockTimeLabel:SizeToContents()
    
    local lockTimeSlider = vgui.Create("DNumSlider", parent)
    lockTimeSlider:SetPos(20, y + 20)
    lockTimeSlider:SetSize(400, 25)
    lockTimeSlider:SetMin(0)
    lockTimeSlider:SetMax(5)
    lockTimeSlider:SetDecimals(1)
    lockTimeSlider:SetValue(GetConVar("vein_lock_time"):GetFloat())
    lockTimeSlider.OnValueChanged = function(self, value)
        RunConsoleCommand("vein_lock_time", tostring(value))
    end
    VEIN.NewSettingsPanel.lockTimeSlider = lockTimeSlider
    
    -- Lock time description
    local lockTimeDesc = vgui.Create("DLabel", parent)
    lockTimeDesc:SetText("Set to 0 for instant lock/unlock (no progress bar)")
    lockTimeDesc:SetTextColor(Color(180, 180, 180))
    lockTimeDesc:SetFont("DermaDefault")
    lockTimeDesc:SetPos(20, y + 48)
    lockTimeDesc:SizeToContents()
    
    y = y + 80
    
    -- Door Sell Refund Percentage
    local refundLabel = vgui.Create("DLabel", parent)
    refundLabel:SetText("Door Sell Refund Percentage:")
    refundLabel:SetTextColor(Color(200, 200, 255))
    refundLabel:SetFont("DermaDefaultBold")
    refundLabel:SetPos(20, y)
    refundLabel:SizeToContents()
    
    local refundSlider = vgui.Create("DNumSlider", parent)
    refundSlider:SetPos(20, y + 20)
    refundSlider:SetSize(400, 25)
    refundSlider:SetMin(0)
    refundSlider:SetMax(100)
    refundSlider:SetDecimals(0)
    refundSlider:SetValue(GetConVar("vein_door_refund_percent") and GetConVar("vein_door_refund_percent"):GetInt() or 50)
    refundSlider.OnValueChanged = function(self, value)
        RunConsoleCommand("vein_door_refund_percent", tostring(math.floor(value)))
    end
    VEIN.NewSettingsPanel.refundSlider = refundSlider
    
    -- Refund description
    local refundDesc = vgui.Create("DLabel", parent)
    refundDesc:SetText("How much money players get back when selling doors (0-100%)")
    refundDesc:SetTextColor(Color(180, 180, 180))
    refundDesc:SetFont("DermaDefault")
    refundDesc:SetPos(20, y + 48)
    refundDesc:SizeToContents()
    
    y = y + 80
    
    -- Enable Door Kicking
    local kickLabel = vgui.Create("DLabel", parent)
    kickLabel:SetText("Enable Door Kicking:")
    kickLabel:SetTextColor(Color(200, 200, 255))
    kickLabel:SetFont("DermaDefaultBold")
    kickLabel:SetPos(20, y)
    kickLabel:SizeToContents()
    
    local kickCheck = vgui.Create("DCheckBox", parent)
    kickCheck:SetPos(180, y)
    kickCheck:SetSize(25, 25)
    local kickConVar = GetConVar("vein_enable_door_kicking")
    kickCheck:SetChecked(kickConVar and kickConVar:GetBool() or false)
    kickCheck.OnChange = function(self, value)
        if VEIN.NewSettingsPanel.isRefreshing then return end
        RunConsoleCommand("vein_enable_door_kicking", value and "1" or "0")
        
        -- Force immediate save to prevent refresh from overwriting
        timer.Simple(0.05, function()
            local cv = GetConVar("vein_enable_door_kicking")
            if cv and IsValid(kickCheck) then
                kickCheck:SetChecked(cv:GetBool())
            end
        end)
    end
    VEIN.NewSettingsPanel.kickCheck = kickCheck
    
    -- Kick description
    local kickDesc = vgui.Create("DLabel", parent)
    kickDesc:SetText("Allow players to kick down locked doors (hold R on locked door)")
    kickDesc:SetTextColor(Color(180, 180, 180))
    kickDesc:SetFont("DermaDefault")
    kickDesc:SetPos(20, y + 28)
    kickDesc:SizeToContents()
    
    -- Position buttons at the bottom of the panel (panel is 460px tall, 600px wide)
    local buttonY = 390
    
    -- Save button (bottom left)
    local saveBtn = vgui.Create("DButton", parent)
    saveBtn:SetText("Apply Settings")
    saveBtn:SetPos(5, buttonY)
    saveBtn:SetSize(150, 30)
    saveBtn:SetTextColor(Color(255, 255, 255))
    saveBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(100, 150, 100) or Color(80, 120, 80)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
    end
    saveBtn.DoClick = function()
        VEIN.NewSettingsPanel.SendSettingsUpdate()
        chat.AddText(Color(100, 255, 100), "[VEIN] Settings saved!")
    end
    
    -- Reset to Defaults button (bottom center)
    local resetBtn = vgui.Create("DButton", parent)
    resetBtn:SetText("Reset to Defaults")
    resetBtn:SetPos(170, buttonY)
    resetBtn:SetSize(160, 30)
    resetBtn:SetTextColor(Color(255, 255, 255))
    resetBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(100, 100, 150) or Color(70, 70, 110)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
    end
    resetBtn.DoClick = function()
        -- Confirmation dialog
        Derma_Query(
            "Reset all General Settings to their default values?\n\nDefaults:\n• Lock/Unlock Time: 1 second\n• Default Door Limit: 3\n• Enable Door Limits: Yes\n• Refund Percentage: 50%\n• Enable Door Kicking: Yes",
            "Reset to Defaults",
            "Yes, Reset",
            function()
                -- Reset to defaults
                VEIN.NewSettingsPanel.lockTimeSlider:SetValue(1)
                VEIN.NewSettingsPanel.limitSlider:SetValue(3)
                VEIN.NewSettingsPanel.enableCheck:SetChecked(true)
                VEIN.NewSettingsPanel.refundSlider:SetValue(50)
                VEIN.NewSettingsPanel.kickCheck:SetChecked(true)
                
                -- Send update to server
                timer.Simple(0.1, function()
                    VEIN.NewSettingsPanel.SendSettingsUpdate()
                    chat.AddText(Color(150, 150, 255), "[VEIN] General settings reset to defaults!")
                end)
            end,
            "Cancel"
        )
    end
    
    -- Clear all doors button (bottom right)
    local clearBtnWidth = 200
    
    local clearBtn = vgui.Create("DButton", parent)
    clearBtn:SetText("CLEAR ALL DOORS")
    clearBtn:SetPos(380, buttonY)
    clearBtn:SetSize(clearBtnWidth, 30)
    clearBtn:SetTextColor(Color(255, 255, 255))
    clearBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(150, 40, 40) or Color(100, 30, 30)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(200, 60, 60)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end
    clearBtn.DoClick = function()
        -- Confirmation dialog
        Derma_Query(
            "Are you sure you want to CLEAR ALL VEIN doors?\nThis will remove ALL door configurations and cannot be undone!",
            "Clear All Doors",
            "Yes, Clear All",
            function()
                LocalPlayer():ConCommand("vein_clear_all_doors")
                chat.AddText(Color(255, 100, 100), "[VEIN] Clearing all doors...")
            end,
            "Cancel"
        )
    end
end

-- Create player limits controls
function VEIN.NewSettingsPanel.CreateLimitsControls(parent)
    -- Player list
    local listLabel = vgui.Create("DLabel", parent)
    listLabel:SetText("Online Players - Door Ownership:")
    listLabel:SetTextColor(Color(200, 200, 255))
    listLabel:SetFont("DermaDefaultBold")
    listLabel:SetPos(20, 20)
    listLabel:SizeToContents()
    
    local playerList = vgui.Create("DListView", parent)
    playerList:SetPos(20, 50)
    playerList:SetSize(540, 250)
    playerList:SetMultiSelect(true)
    playerList:AddColumn("Player Name"):SetFixedWidth(180)
    playerList:AddColumn("Owned Doors"):SetFixedWidth(90)
    playerList:AddColumn("Door Limit"):SetFixedWidth(90)
    playerList:AddColumn("SteamID"):SetFixedWidth(180)
    SetupAlphabeticalSorting(playerList)
    VEIN.NewSettingsPanel.playerListBox = playerList
    
    -- Allow selection without CTRL - override default behavior
    playerList.OnMousePressed = function(self, keyCode)
        if keyCode == MOUSE_LEFT then
            self.clickStartPos = {x = gui.MouseX(), y = gui.MouseY()}
        end
    end
    
    playerList.OnMouseReleased = function(self, keyCode)
        if keyCode == MOUSE_LEFT then
            -- Reset on mouse release to prevent stuck state
            self.clickStartPos = nil
        end
    end
    
    playerList.OnClickLine = function(self, line, isSelected)
        -- Check if this was a drag (mouse moved significantly from start position)
        if self.clickStartPos then
            local currentPos = {x = gui.MouseX(), y = gui.MouseY()}
            local dragDistance = math.sqrt(
                math.pow(currentPos.x - self.clickStartPos.x, 2) + 
                math.pow(currentPos.y - self.clickStartPos.y, 2)
            )
            
            -- If mouse moved more than 10 pixels, it's a drag - ignore it
            if dragDistance > 10 then
                self.clickStartPos = nil
                return
            end
        end
        
        -- Clear the start position after processing
        self.clickStartPos = nil
        
        -- CTRL+click for multi-selection
        if input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL) then
            line:SetSelected(not line:IsSelected())
        else
            -- Normal click: deselect all others first, then select this one
            for _, otherLine in ipairs(self:GetLines()) do
                otherLine:SetSelected(false)
            end
            line:SetSelected(true)
        end
    end
    
    -- Completely disable the default DListView multi-select behavior
    playerList.OnRowSelected = function(self, index, line)
        -- Do nothing - we handle selection in OnClickLine only
    end
    
    -- Style the list
    playerList.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 30, 200)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    -- Set Custom Limit Section
    local customLabel = vgui.Create("DLabel", parent)
    customLabel:SetText("Set Custom Limit for Selected Player(s):")
    customLabel:SetTextColor(Color(200, 200, 255))
    customLabel:SetFont("DermaDefaultBold")
    customLabel:SetPos(20, 320)
    customLabel:SizeToContents()
    
    -- Limit input
    local limitEntry = vgui.Create("DNumberWang", parent)
    limitEntry:SetPos(20, 345)
    limitEntry:SetSize(100, 30)
    limitEntry:SetMin(0)
    limitEntry:SetMax(100)
    limitEntry:SetValue(3)
    limitEntry.Paint = function(self, w, h)
        local bgColor = self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        local borderColor = self:HasFocus() and Color(120, 40, 40, 200) or Color(60, 60, 60, 150)
        surface.SetDrawColor(borderColor)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        self:DrawTextEntryText(Color(220, 220, 225), Color(120, 40, 40), Color(220, 220, 225))
    end
    VEIN.NewSettingsPanel.limitEntry = limitEntry
    
    -- Set Limit Button
    local setBtn = vgui.Create("DButton", parent)
    setBtn:SetPos(130, 345)
    setBtn:SetSize(120, 30)
    setBtn:SetText("Set Custom Limit")
    setBtn:SetTextColor(Color(255, 255, 255))
    setBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(100, 150, 100) or Color(80, 120, 80)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(120, 180, 120, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    setBtn.DoClick = function()
        local selected = playerList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select at least one player first!")
            return
        end
        
        local limit = math.floor(limitEntry:GetValue())
        
        if limit < 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Limit must be 0 or greater!")
            return
        end
        
        -- Send to server for each selected player
        local playerNames = {}
        for _, line in ipairs(selected) do
            local steamid = line:GetValue(4)
            local playerName = line:GetValue(1)
            table.insert(playerNames, playerName)
            
            net.Start("VEIN_SetPlayerLimit")
            net.WriteString(steamid)
            net.WriteInt(limit, 16)
            net.SendToServer()
        end
        
        -- Show success message
        if #selected == 1 then
            chat.AddText(Color(100, 255, 100), "[VEIN] Custom limit set to ", Color(255, 255, 100), tostring(limit), Color(100, 255, 100), " for ", Color(255, 255, 100), playerNames[1])
        else
            chat.AddText(Color(100, 255, 100), "[VEIN] Custom limit set to ", Color(255, 255, 100), tostring(limit), Color(100, 255, 100), " for ", Color(255, 255, 100), tostring(#selected), Color(100, 255, 100), " players")
        end
        
        -- Refresh after a moment
        timer.Simple(0.3, function()
            VEIN.NewSettingsPanel.RefreshPlayerList()
        end)
    end
    
    -- Reset to Default Button
    local resetBtn = vgui.Create("DButton", parent)
    resetBtn:SetPos(260, 345)
    resetBtn:SetSize(140, 30)
    resetBtn:SetText("Reset to Default")
    resetBtn:SetTextColor(Color(255, 255, 255))
    resetBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(120, 40, 40, 200) or Color(80, 30, 30, 150)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(160, 60, 60, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    resetBtn.DoClick = function()
        local selected = playerList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select at least one player first!")
            return
        end
        
        -- Send to server for each selected player
        local playerNames = {}
        for _, line in ipairs(selected) do
            local steamid = line:GetValue(4)
            local playerName = line:GetValue(1)
            table.insert(playerNames, playerName)
            
            net.Start("VEIN_ResetPlayerLimit")
            net.WriteString(steamid)
            net.SendToServer()
        end
        
        -- Show success message
        if #selected == 1 then
            chat.AddText(Color(100, 255, 100), "[VEIN] Reset ", Color(255, 255, 100), playerNames[1], Color(100, 255, 100), " to default limit")
        else
            chat.AddText(Color(100, 255, 100), "[VEIN] Reset ", Color(255, 255, 100), tostring(#selected), Color(100, 255, 100), " players to default limit")
        end
        
        -- Refresh after a moment
        timer.Simple(0.3, function()
            VEIN.NewSettingsPanel.RefreshPlayerList()
        end)
    end
    
    -- Refresh Button
    local refreshBtn = vgui.Create("DButton", parent)
    refreshBtn:SetPos(450, 345)
    refreshBtn:SetSize(120, 30)
    refreshBtn:SetText("Refresh List")
    refreshBtn:SetTextColor(Color(255, 255, 255))
    refreshBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 90, 120) or Color(40, 70, 100)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 120, 160, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    refreshBtn.DoClick = function()
        VEIN.NewSettingsPanel.RefreshPlayerList()
        chat.AddText(Color(100, 255, 100), "[VEIN] Player list refreshed!")
    end
    
    -- Help text
    local helpText = vgui.Create("DLabel", parent)
    helpText:SetPos(20, 385)
    helpText:SetSize(550, 40)
    helpText:SetText("Custom limits override the default limit. Set to 0 to prevent a player from owning any doors.\nReset to Default removes the custom limit and uses the global default.")
    helpText:SetTextColor(Color(150, 150, 155))
    helpText:SetWrap(true)
    
    -- Initial list request
    VEIN.NewSettingsPanel.RefreshPlayerList()
end

function VEIN.NewSettingsPanel.RequestDoorAdmins()
    net.Start("VEIN_RequestDoorAdmins")
    net.SendToServer()
end

local doorAdminPermDefs = {
    {id = "adminCreateDoor", label = "Create Doors"},
    {id = "adminModifyDoor", label = "Modify Doors"},
    {id = "adminDeleteDoor", label = "Delete Doors"},
    {id = "adminForceSellDoor", label = "Force Sell Doors"},
    {id = "adminEditGroupsDoor", label = "Edit Door Groups/Jobs"},
    {id = "adminDisableEnableDoor", label = "Disable/Enable Doors"},
    {id = "adminTeleportDoor", label = "Teleport To Door"},
}

local function GetDoorAdminKey(ply)
    if not IsValid(ply) then return "" end
    if ply:IsBot() then
        return "BOT_" .. ply:Nick()
    end
    return ply:SteamID()
end

function VEIN.NewSettingsPanel.RefreshDoorAdminList()
    if not VEIN.NewSettingsPanel.doorAdminList or not IsValid(VEIN.NewSettingsPanel.doorAdminList) then return end
    local listBox = VEIN.NewSettingsPanel.doorAdminList
    local admins = settingsCache.doorAdmins or {}

    listBox.m_isAddingLines = true
    listBox:Clear()
    if VEIN.NewSettingsPanel.doorAdminEditButton and IsValid(VEIN.NewSettingsPanel.doorAdminEditButton) then
        VEIN.NewSettingsPanel.doorAdminEditButton:SetEnabled(false)
    end

    for _, entry in ipairs(admins) do
        local name = entry.name ~= "" and entry.name or "Unknown"
        local line = listBox:AddLine(name, entry.steamid or "")
        line.steamid = entry.steamid
        line.perms = entry.perms or {}
        if line.Columns[1] then line.Columns[1]:SetTextColor(Color(200, 255, 200)) end
        if line.Columns[2] then line.Columns[2]:SetTextColor(Color(180, 180, 200)) end
    end

    listBox.m_isAddingLines = false
    if listBox.m_iSortColumn then
        timer.Simple(0, function()
            if IsValid(listBox) then
                listBox:SortByColumn(listBox.m_iSortColumn, listBox.m_bSortDescending)
            end
        end)
    end
end

function VEIN.NewSettingsPanel.RefreshDoorAdminCombo()
    if not VEIN.NewSettingsPanel.doorAdminCombo or not IsValid(VEIN.NewSettingsPanel.doorAdminCombo) then return end
    local combo = VEIN.NewSettingsPanel.doorAdminCombo
    combo:Clear()
    combo:SetValue("Select player...")

    for _, p in ipairs(player.GetAll()) do
        combo:AddChoice(p:Nick(), GetDoorAdminKey(p))
    end
end

function VEIN.NewSettingsPanel.OpenDoorAdminPermsDialog(steamID, name, perms)
    if not steamID then return end
    perms = perms or {}

    local dialog = vgui.Create("DFrame")
    local rowHeight = 28
    local baseHeight = 160
    local dialogHeight = baseHeight + (#doorAdminPermDefs * rowHeight) + 60
    local dialogW, dialogH = ClampFrameSize(dialog, 420, dialogHeight)
    dialog:Center()
    dialog:SetTitle("")
    dialog:SetDraggable(false)
    dialog:ShowCloseButton(false)
    dialog:MakePopup()

    dialog.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        surface.SetDrawColor(180, 60, 60, 120)
        surface.DrawRect(12, 12, w - 24, 2)
    end

    local content = vgui.Create("DPanel", dialog)
    content:SetPos(0, 0)
    content:SetSize(dialogW, dialogH)
    content.Paint = function() end

    local innerW = dialogW - 40
    local availableRows = math.max(120, dialogH - 160)
    rowHeight = math.min(28, math.max(20, math.floor(availableRows / math.max(1, #doorAdminPermDefs))))

    local title = vgui.Create("DLabel", content)
    title:SetPos(15, 18)
    title:SetText("Door Admin Permissions")
    title:SetFont("DermaLarge")
    title:SetTextColor(Color(220, 220, 225))
    title:SizeToContents()

    local subtitle = vgui.Create("DLabel", content)
    subtitle:SetPos(15, 48)
    subtitle:SetText(name ~= "" and name or steamID)
    subtitle:SetFont("DermaDefault")
    subtitle:SetTextColor(Color(180, 180, 200))
    subtitle:SizeToContents()

    local y = 80
    local checkboxes = {}
    for _, def in ipairs(doorAdminPermDefs) do
        local check = vgui.Create("DCheckBoxLabel", content)
        check:SetPos(20, y)
        check:SetText(def.label)
        check:SetTextColor(Color(200, 200, 205))
        check:SetValue(perms[def.id] == true)
        check:SizeToContents()
        checkboxes[def.id] = check
        y = y + rowHeight
    end

    local saveBtn = vgui.Create("DButton", content)
    saveBtn:SetPos(20, dialogH - 50)
    saveBtn:SetSize(math.floor((innerW - 10) / 2), 30)
    saveBtn:SetText("Save")
    saveBtn:SetTextColor(Color(255, 255, 255))
    saveBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(80, 130, 80) or Color(60, 110, 60)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(120, 180, 120, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    saveBtn.DoClick = function()
        local newPerms = {}
        for _, def in ipairs(doorAdminPermDefs) do
            newPerms[def.id] = checkboxes[def.id] and checkboxes[def.id]:GetChecked() or false
        end
        net.Start("VEIN_SetDoorAdminPerms")
        net.WriteString(steamID)
        Net.WriteStringBoolMap(newPerms)
        net.SendToServer()
        dialog:Close()
    end

    local cancelBtn = vgui.Create("DButton", content)
    cancelBtn:SetPos(20 + math.floor((innerW - 10) / 2) + 10, dialogH - 50)
    cancelBtn:SetSize(math.floor((innerW - 10) / 2), 30)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetTextColor(Color(255, 255, 255))
    cancelBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(150, 70, 70) or Color(120, 60, 60)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(180, 100, 100, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    cancelBtn.DoClick = function()
        dialog:Close()
    end
end

function VEIN.NewSettingsPanel.CreateDoorAdminControls(parent)
    local title = vgui.Create("DLabel", parent)
    title:SetText("Door Admins (door options only)")
    title:SetTextColor(Color(200, 200, 255))
    title:SetFont("DermaDefaultBold")
    title:SetPos(20, 20)
    title:SizeToContents()

    local info = vgui.Create("DLabel", parent)
    info:SetText("Door admins can open door options without owning the door.")
    info:SetTextColor(Color(180, 180, 200))
    info:SetFont("DermaDefault")
    info:SetPos(20, 40)
    info:SizeToContents()

    local adminList = vgui.Create("DListView", parent)
    adminList:SetPos(20, 65)
    adminList:SetSize(540, 230)
    adminList:SetMultiSelect(true)
    adminList:AddColumn("Player Name"):SetFixedWidth(240)
    adminList:AddColumn("SteamID"):SetFixedWidth(260)
    SetupAlphabeticalSorting(adminList)
    VEIN.NewSettingsPanel.doorAdminList = adminList

    adminList.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 30, 200)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end

    -- Add section
    local addLabel = vgui.Create("DLabel", parent)
    addLabel:SetText("Add Door Admin:")
    addLabel:SetTextColor(Color(200, 200, 255))
    addLabel:SetFont("DermaDefaultBold")
    addLabel:SetPos(20, 315)
    addLabel:SizeToContents()

    local playerCombo = vgui.Create("DComboBox", parent)
    playerCombo:SetPos(20, 340)
    playerCombo:SetSize(250, 28)
    playerCombo:SetValue("Select player...")
    playerCombo:SetTextColor(Color(220, 220, 225))
    playerCombo.Paint = function(self, w, h)
        local bgColor = self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        local borderColor = self:HasFocus() and Color(120, 40, 40, 200) or Color(60, 60, 60, 150)
        surface.SetDrawColor(borderColor)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    playerCombo.OnSelect = function(self, index, value, data)
        self.selectedSteamID = data
        self.selectedName = value
    end
    VEIN.NewSettingsPanel.doorAdminCombo = playerCombo
    VEIN.NewSettingsPanel.RefreshDoorAdminCombo()

    local addBtn = vgui.Create("DButton", parent)
    addBtn:SetPos(280, 340)
    addBtn:SetSize(120, 28)
    addBtn:SetText("Add")
    addBtn:SetTextColor(Color(255, 255, 255))
    addBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(80, 130, 80) or Color(60, 110, 60)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(120, 180, 120, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    addBtn.DoClick = function()
        local steamID = playerCombo.selectedSteamID
        local name = playerCombo.selectedName or ""
        if not steamID then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select a player first!")
            return
        end
        net.Start("VEIN_AddDoorAdmin")
        net.WriteString(steamID)
        net.WriteString(name)
        net.SendToServer()
    end

    local removeBtn = vgui.Create("DButton", parent)
    removeBtn:SetPos(410, 340)
    removeBtn:SetSize(150, 28)
    removeBtn:SetText("Remove Selected")
    removeBtn:SetTextColor(Color(255, 255, 255))
    removeBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(150, 70, 70) or Color(120, 60, 60)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(180, 100, 100, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    removeBtn.DoClick = function()
        local selected = adminList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select at least one entry to remove!")
            return
        end
        for _, line in ipairs(selected) do
            if line.steamid then
                net.Start("VEIN_RemoveDoorAdmin")
                net.WriteString(line.steamid)
                net.SendToServer()
            end
        end
    end

    local editBtn = vgui.Create("DButton", parent)
    editBtn:SetPos(170, 375)
    editBtn:SetSize(200, 26)
    editBtn:SetText("Edit Permissions")
    editBtn:SetTextColor(Color(255, 255, 255))
    editBtn:SetEnabled(false)
    editBtn.Paint = function(self, w, h)
        local disabled = not self:IsEnabled()
        local col
        if disabled then
            col = Color(60, 60, 65)
        else
            col = self:IsHovered() and Color(80, 110, 150) or Color(70, 90, 120)
        end
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(120, 140, 180, disabled and 40 or 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    editBtn.DoClick = function()
        local selected = adminList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select an entry to edit!")
            return
        end
        local line = selected[1]
        VEIN.NewSettingsPanel.OpenDoorAdminPermsDialog(line.steamid, line:GetValue(1), line.perms)
    end
    VEIN.NewSettingsPanel.doorAdminEditButton = editBtn

    local function UpdateEditButtonState()
        local selected = adminList:GetSelected()
        editBtn:SetEnabled(selected and #selected > 0)
    end

    adminList.OnRowSelected = function()
        UpdateEditButtonState()
    end
    adminList.OnRowDeselected = function()
        UpdateEditButtonState()
    end
    UpdateEditButtonState()

    local refreshBtn = vgui.Create("DButton", parent)
    refreshBtn:SetPos(20, 375)
    refreshBtn:SetSize(140, 26)
    refreshBtn:SetText("Refresh List")
    refreshBtn:SetTextColor(Color(255, 255, 255))
    refreshBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(80, 100, 140) or Color(70, 90, 120)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(120, 140, 180, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    refreshBtn.DoClick = function()
        VEIN.NewSettingsPanel.RequestDoorAdmins()
        VEIN.NewSettingsPanel.RefreshDoorAdminCombo()
    end
end

-- Create door management controls
function VEIN.NewSettingsPanel.CreateDoorManagementControls(parent)
    local y = 20
    
    -- Title
    local titleLabel = vgui.Create("DLabel", parent)
    titleLabel:SetPos(20, y)
    titleLabel:SetText("Door Management - All Doors on Map")
    titleLabel:SetFont("DermaLarge")
    titleLabel:SetTextColor(Color(255, 200, 200))
    titleLabel:SizeToContents()
    
    y = y + 35
    
    -- Description
    local descLabel = vgui.Create("DLabel", parent)
    descLabel:SetPos(20, y)
    descLabel:SetSize(550, 30)
    descLabel:SetText("Right-click a door for options: Teleport, Delete, or Disable/Enable")
    descLabel:SetTextColor(Color(180, 180, 180))
    descLabel:SetWrap(true)
    
    y = y + 40
    
    -- Door list
    local doorList = vgui.Create("DListView", parent)
    doorList:SetPos(20, y)
    doorList:SetSize(540, 280)
    doorList:SetMultiSelect(false)
    doorList:AddColumn("Door Name"):SetFixedWidth(180)
    doorList:AddColumn("Type"):SetFixedWidth(100)
    doorList:AddColumn("Owner"):SetFixedWidth(120)
    doorList:AddColumn("Status"):SetFixedWidth(140)
    SetupAlphabeticalSorting(doorList, 2) -- Default sort by Type (column 2)
    doorList.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 30, 200)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    -- Right-click menu
    doorList.OnRowRightClick = function(self, lineID, line)
        local doorName = line:GetValue(1)
        local status = line:GetValue(4)
        local isDisabled = string.find(status, "Disabled")
        local doorIdentifier = line.doorIdentifier
        
        if not doorIdentifier then
            print("[VEIN] Error: No door identifier found for line!")
            return
        end
        
        local menu = DermaMenu()
        
        -- Teleport option
        menu:AddOption("Teleport to Door", function()
            net.Start("VEIN_TeleportToDoor")
            net.WriteString(doorIdentifier)
            net.SendToServer()
        end):SetIcon("icon16/arrow_right.png")
        
        -- Disable/Enable option
        if isDisabled then
            menu:AddOption("Enable Door", function()
                net.Start("VEIN_EnableDoor")
                net.WriteString(doorIdentifier)
                net.SendToServer()
                
                timer.Simple(0.1, function()
                    VEIN.NewSettingsPanel.RefreshDoorList()
                end)
            end):SetIcon("icon16/accept.png")
        else
            local disableMenu, disableOption = menu:AddSubMenu("Disable Door")
            disableOption:SetIcon("icon16/lock.png")
            
            disableMenu:AddOption("Default State", function()
                net.Start("VEIN_DisableDoor")
                net.WriteString(doorIdentifier)
                net.WriteInt(0, 8) -- 0 = default state
                net.SendToServer()
                
                timer.Simple(0.1, function()
                    VEIN.NewSettingsPanel.RefreshDoorList()
                end)
            end):SetIcon("icon16/help.png")
            
            disableMenu:AddOption("Keep Locked", function()
                net.Start("VEIN_DisableDoor")
                net.WriteString(doorIdentifier)
                net.WriteInt(1, 8) -- 1 = locked
                net.SendToServer()
                
                timer.Simple(0.1, function()
                    VEIN.NewSettingsPanel.RefreshDoorList()
                end)
            end):SetIcon("icon16/lock.png")
            
            disableMenu:AddOption("Keep Unlocked", function()
                net.Start("VEIN_DisableDoor")
                net.WriteString(doorIdentifier)
                net.WriteInt(2, 8) -- 2 = unlocked
                net.SendToServer()
                
                timer.Simple(0.1, function()
                    VEIN.NewSettingsPanel.RefreshDoorList()
                end)
            end):SetIcon("icon16/lock_open.png")
        end
        
        menu:AddSpacer()
        
        -- Delete option
        menu:AddOption("Delete Door", function()
            Derma_Query(
                "Are you sure you want to DELETE this door?\n\nDoor: " .. doorName .. "\n\nThis action cannot be undone!",
                "Delete Door",
                "Yes, Delete",
                function()
                    net.Start("VEIN_DeleteDoor")
                    net.WriteString(doorIdentifier)
                    net.SendToServer()
                    
                    timer.Simple(0.1, function()
                        VEIN.NewSettingsPanel.RefreshDoorList()
                    end)
                end,
                "Cancel"
            )
        end):SetIcon("icon16/delete.png")
        
        menu:Open()
    end
    
    VEIN.NewSettingsPanel.doorListBox = doorList
    
    y = y + 290
    
    -- Refresh button
    local refreshBtn = vgui.Create("DButton", parent)
    refreshBtn:SetPos(20, y)
    refreshBtn:SetSize(150, 30)
    refreshBtn:SetText("Refresh Door List")
    refreshBtn:SetTextColor(Color(255, 255, 255))
    refreshBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60) or Color(40, 100, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    refreshBtn.DoClick = function()
        VEIN.NewSettingsPanel.RefreshDoorList()
    end
end

-- Refresh door list
function VEIN.NewSettingsPanel.RefreshDoorList()
    if not IsValid(VEIN.NewSettingsPanel.doorListBox) then return end
    
    net.Start("VEIN_RequestDoorList")
    net.SendToServer()
end

-- Create custom door types and materials controls
function VEIN.NewSettingsPanel.CreateCustomDoorControls(parent)
    -- Store references for refresh
    VEIN.NewSettingsPanel.customTypeList = nil
    VEIN.NewSettingsPanel.customMatList = nil
    VEIN.CustomDoors = VEIN.CustomDoors or {}
    VEIN.CustomDoors.Types = VEIN.CustomDoors.Types or {}
    VEIN.CustomDoors.Materials = VEIN.CustomDoors.Materials or {}
    
    -- Create scrollable panel
    local scrollPanel = vgui.Create("DScrollPanel", parent)
    scrollPanel:Dock(FILL)
    scrollPanel:DockMargin(5, 5, 5, 5)
    
    local y = 10
    
    -- Title
    local titleLabel = vgui.Create("DLabel", scrollPanel)
    titleLabel:SetPos(20, y)
    titleLabel:SetText("Custom Door Types & Materials")
    titleLabel:SetFont("DermaLarge")
    titleLabel:SetTextColor(Color(255, 200, 200))
    titleLabel:SizeToContents()
    
    y = y + 35
    
    -- Description
    local descLabel = vgui.Create("DLabel", scrollPanel)
    descLabel:SetPos(20, y)
    descLabel:SetSize(550, 50)
    descLabel:SetText("Create custom door types and materials for your server.\nDefault items (yellow text) cannot be removed. Custom items (blue text) can be removed.")
    descLabel:SetTextColor(Color(180, 180, 180))
    descLabel:SetWrap(true)
    descLabel:SetAutoStretchVertical(true)
    
    y = y + 60
    
    -- ===== DOOR TYPES SECTION =====
    local typeLabel = vgui.Create("DLabel", scrollPanel)
    typeLabel:SetPos(20, y)
    typeLabel:SetText("Door Types:")
    typeLabel:SetFont("DermaDefaultBold")
    typeLabel:SetTextColor(Color(200, 200, 255))
    typeLabel:SizeToContents()
    
    y = y + 25
    
    -- Door Types List (narrower to show scrollbar border)
    local typeList = vgui.Create("DListView", scrollPanel)
    typeList:SetPos(20, y)
    typeList:SetSize(540, 180)
    typeList:SetMultiSelect(false)
    typeList:AddColumn("Type Name"):SetFixedWidth(420)
    typeList:AddColumn("Color"):SetFixedWidth(120)
    SetupAlphabeticalSorting(typeList, 2) -- Default sort by Color (column 2)
    typeList.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 30, 200)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    VEIN.NewSettingsPanel.customTypeList = typeList
    
    -- Add Type Button
    local addTypeBtn = vgui.Create("DButton", scrollPanel)
    addTypeBtn:SetPos(20, y + 190)
    addTypeBtn:SetSize(180, 25)
    addTypeBtn:SetText("Add Type")
    addTypeBtn:SetTextColor(Color(255, 255, 255))
    addTypeBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60) or Color(40, 100, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    addTypeBtn.DoClick = function()
        VEIN.NewSettingsPanel.OpenAddTypeDialog()
    end
    
    -- Edit Type Button
    local editTypeBtn = vgui.Create("DButton", scrollPanel)
    editTypeBtn:SetPos(210, y + 190)
    editTypeBtn:SetSize(180, 25)
    editTypeBtn:SetText("Edit Type")
    editTypeBtn:SetTextColor(Color(255, 255, 255))
    editTypeBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 90, 120) or Color(40, 70, 100)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 120, 160, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    editTypeBtn.DoClick = function()
        local selected = typeList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select a door type first!")
            return
        end
        
        local typeName = selected[1]:GetValue(1)
        VEIN.NewSettingsPanel.OpenEditTypeDialog(typeName)
    end
    
    -- Remove Type Button
    local removeTypeBtn = vgui.Create("DButton", scrollPanel)
    removeTypeBtn:SetPos(400, y + 190)
    removeTypeBtn:SetSize(180, 25)
    removeTypeBtn:SetText("Remove Type")
    removeTypeBtn:SetTextColor(Color(255, 255, 255))
    removeTypeBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(120, 40, 40) or Color(80, 30, 30)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(160, 60, 60, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    removeTypeBtn.DoClick = function()
        local selected = typeList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select a door type first!")
            return
        end
        
        local typeName = selected[1]:GetValue(1)
        VEIN.NewSettingsPanel.RemoveCustomType(typeName)
    end
    
    -- ===== DOOR MATERIALS SECTION =====
    local matY = y + 230
    local matLabel = vgui.Create("DLabel", scrollPanel)
    matLabel:SetPos(20, matY)
    matLabel:SetText("Door Materials:")
    matLabel:SetFont("DermaDefaultBold")
    matLabel:SetTextColor(Color(200, 200, 255))
    matLabel:SizeToContents()
    
    matY = matY + 25
    
    -- Door Materials List (simplified with template buttons)
    local matList = vgui.Create("DListView", scrollPanel)
    matList:SetPos(20, matY)
    matList:SetSize(540, 150)
    matList:SetMultiSelect(false)
    matList:AddColumn("Material Name"):SetFixedWidth(265)
    matList:AddColumn("Kick Time"):SetFixedWidth(80)
    matList:AddColumn("Right-Click [➚] for template"):SetFixedWidth(195) -- Template button column
    SetupAlphabeticalSorting(matList, 2) -- Default sort by Kick Time (column 2)
    matList.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 30, 200)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    -- Override line painting to add clickable template buttons
    matList.OnRowRightClick = function(self, lineID, line)
        -- Get material name
        local matName = line:GetValue(1)
        
        -- Check if it's a default material
        local defaultMaterials = {"Wood Door", "Light Metal", "Glass Door", "Heavy Metal", "Steel Door"}
        local isDefault = false
        for _, defMat in ipairs(defaultMaterials) do
            if matName == defMat then
                isDefault = true
                break
            end
        end
        
        if isDefault then
            -- Open Add Material dialog with this default's sounds pre-filled
            VEIN.NewSettingsPanel.OpenAddMaterialDialogFromTemplate(matName)
        end
    end
    
    VEIN.NewSettingsPanel.customMatList = matList
    
    -- Add Material Button
    local addMatBtn = vgui.Create("DButton", scrollPanel)
    addMatBtn:SetPos(20, matY + 160)
    addMatBtn:SetSize(180, 25)
    addMatBtn:SetText("Add Material")
    addMatBtn:SetTextColor(Color(255, 255, 255))
    addMatBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60) or Color(40, 100, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    addMatBtn.DoClick = function()
        VEIN.NewSettingsPanel.OpenAddMaterialDialog()
    end
    
    -- Edit Material Button
    local editMatBtn = vgui.Create("DButton", scrollPanel)
    editMatBtn:SetPos(210, matY + 160)
    editMatBtn:SetSize(180, 25)
    editMatBtn:SetText("Edit Material")
    editMatBtn:SetTextColor(Color(255, 255, 255))
    editMatBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 90, 120) or Color(40, 70, 100)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 120, 160, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    editMatBtn.DoClick = function()
        local selected = matList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select a door material first!")
            return
        end
        
        local matName = selected[1]:GetValue(1)
        VEIN.NewSettingsPanel.OpenEditMaterialDialog(matName)
    end
    
    -- Remove Material Button
    local removeMatBtn = vgui.Create("DButton", scrollPanel)
    removeMatBtn:SetPos(400, matY + 160)
    removeMatBtn:SetSize(180, 25)
    removeMatBtn:SetText("Remove Material")
    removeMatBtn:SetTextColor(Color(255, 255, 255))
    removeMatBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(120, 40, 40) or Color(80, 30, 30)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(160, 60, 60, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    removeMatBtn.DoClick = function()
        local selected = matList:GetSelected()
        if not selected or #selected == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please select a door material first!")
            return
        end
        
        local matName = selected[1]:GetValue(1)
        VEIN.NewSettingsPanel.RemoveCustomMaterial(matName)
    end
    
    -- Initial data request
    VEIN.NewSettingsPanel.RequestCustomDoorData()
end

-- Request custom door data from server
function VEIN.NewSettingsPanel.RequestCustomDoorData()
    net.Start("VEIN_RequestCustomDoors")
    net.SendToServer()
end

-- Refresh custom door lists
function VEIN.NewSettingsPanel.RefreshCustomDoorLists()
    if not VEIN.NewSettingsPanel.customTypeList or not IsValid(VEIN.NewSettingsPanel.customTypeList) then return end
    if not VEIN.NewSettingsPanel.customMatList or not IsValid(VEIN.NewSettingsPanel.customMatList) then return end
    
    -- Clear lists
    VEIN.NewSettingsPanel.customTypeList:Clear()
    VEIN.NewSettingsPanel.customMatList:Clear()
    
    -- Define default type names for comparison
    local defaultTypeNames = {
        ["Residential"] = true,
        ["Commercial"] = true,
        ["Industrial"] = true,
        ["Government"] = true,
        ["Emergency"] = true
    }
    
    -- Define default material names for comparison
    local defaultMatNames = {
        ["Wood Door"] = true,
        ["Light Metal"] = true,
        ["Glass Door"] = true,
        ["Heavy Metal"] = true,
        ["Steel Door"] = true
    }
    
    -- Populate types with color coding
    for _, typeData in ipairs(VEIN.CustomDoors.Types or {}) do
        local colorStr = string.format("RGB(%d,%d,%d)", typeData.color.r, typeData.color.g, typeData.color.b)
        local line = VEIN.NewSettingsPanel.customTypeList:AddLine(typeData.name, colorStr)
        
        -- Use actual type color for name, white for RGB column
        local isDefault = defaultTypeNames[typeData.name]
        line.Columns[1]:SetTextColor(typeData.color)
        line.Columns[2]:SetTextColor(Color(255, 255, 255))
        line.isDefault = isDefault
    end
    
    -- Populate materials with color coding and template button indicator
    for _, matData in ipairs(VEIN.CustomDoors.Materials or {}) do
        local kickTimeStr = matData.kickTime == -1 and "Unkickable" or (matData.kickTime .. "s")
        local isDefault = defaultMatNames[matData.name]
        local templateBtn = isDefault and "➚" or "" -- Show button icon only for defaults
        
        local line = VEIN.NewSettingsPanel.customMatList:AddLine(matData.name, kickTimeStr, templateBtn)
        
        -- Color code: Yellow for defaults, Blue for custom
        line.Columns[1]:SetTextColor(isDefault and Color(255, 255, 100) or Color(100, 180, 255))
        line.Columns[2]:SetTextColor(Color(255, 255, 255))
        line.Columns[3]:SetTextColor(Color(150, 200, 255)) -- Template button in light blue
        line.isDefault = isDefault
        line.matData = matData -- Store material data for template access
    end
end

-- Open add type dialog
function VEIN.NewSettingsPanel.OpenAddTypeDialog()
    local frame = vgui.Create("DFrame")
    local frameW, frameH = ClampFrameSize(frame, 350, 250)
    frame:Center()
    frame:SetTitle("Add Custom Door Type")
    frame:SetDraggable(true)
    frame:ShowCloseButton(true)
    frame:MakePopup()
    frame.Paint = function(self, w, h)
        surface.SetDrawColor(35, 35, 40, 255)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end
    
    -- Type Name
    local innerW = frameW - 40
    local nameLabel = vgui.Create("DLabel", frame)
    nameLabel:SetPos(20, 40)
    nameLabel:SetText("Type Name:")
    nameLabel:SetTextColor(Color(200, 200, 200))
    nameLabel:SizeToContents()
    
    local nameEntry = vgui.Create("DTextEntry", frame)
    nameEntry:SetPos(20, 60)
    nameEntry:SetSize(innerW, 25)
    nameEntry:SetPlaceholderText("e.g., Warehouse, Military, Retail")
    
    -- Color Mixer
    local colorLabel = vgui.Create("DLabel", frame)
    colorLabel:SetPos(20, 95)
    colorLabel:SetText("Door Type Color:")
    colorLabel:SetTextColor(Color(200, 200, 200))
    colorLabel:SizeToContents()
    
    local previewSize = 70
    local mixerW = math.max(160, innerW - previewSize - 10)
    local colorMixer = vgui.Create("DColorMixer", frame)
    colorMixer:SetPos(20, 115)
    colorMixer:SetSize(mixerW, 70)
    colorMixer:SetPalette(false)
    colorMixer:SetAlphaBar(false)
    colorMixer:SetWangs(true) -- Enable RGB sliders instead of HSV
    local defaultColor = Color(100, 255, 120, 255)
    colorMixer:SetColor(defaultColor)
    
    -- Color Preview Box
    local previewBox = vgui.Create("DPanel", frame)
    previewBox:SetPos(20 + mixerW + 10, 115)
    previewBox:SetSize(previewSize, 70)
    previewBox.Paint = function(self, w, h)
        local col = colorMixer:GetColor()
        draw.RoundedBox(4, 0, 0, w, h, col)
        surface.SetDrawColor(255, 255, 255, 100)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        
        -- Show RGB values
        draw.SimpleText("R: " .. col.r, "DermaDefault", w/2, 10, Color(255, 255, 255), TEXT_ALIGN_CENTER)
        draw.SimpleText("G: " .. col.g, "DermaDefault", w/2, 25, Color(255, 255, 255), TEXT_ALIGN_CENTER)
        draw.SimpleText("B: " .. col.b, "DermaDefault", w/2, 40, Color(255, 255, 255), TEXT_ALIGN_CENTER)
    end
    
    -- Add Button
    local buttonW = math.floor((innerW - 10) / 2)
    local addBtn = vgui.Create("DButton", frame)
    addBtn:SetPos(20, 200)
    addBtn:SetSize(buttonW, 30)
    addBtn:SetText("Add Type")
    addBtn:SetTextColor(Color(255, 255, 255))
    addBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60) or Color(40, 100, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    addBtn.DoClick = function()
        local typeName = nameEntry:GetValue()
        if typeName == "" then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please enter a type name!")
            return
        end
        
        local color = colorMixer:GetColor()
        
        net.Start("VEIN_AddCustomType")
        net.WriteString(typeName)
        net.WriteUInt(color.r, 8)
        net.WriteUInt(color.g, 8)
        net.WriteUInt(color.b, 8)
        net.SendToServer()
        
        frame:Close()
    end
    
    -- Cancel Button
    local cancelBtn = vgui.Create("DButton", frame)
    cancelBtn:SetPos(20 + buttonW + 10, 200)
    cancelBtn:SetSize(buttonW, 30)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetTextColor(Color(255, 255, 255))
    cancelBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(100, 50, 50) or Color(70, 40, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(140, 70, 70, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    cancelBtn.DoClick = function()
        frame:Close()
    end
end

-- Open edit type dialog
function VEIN.NewSettingsPanel.OpenEditTypeDialog(typeName)
    -- Find the type data (VEIN.CustomDoors.Types already contains ALL types - defaults + custom)
    local typeData = nil
    for _, data in ipairs(VEIN.CustomDoors.Types or {}) do
        if data.name == typeName then
            typeData = data
            break
        end
    end
    
    if not typeData then
        chat.AddText(Color(255, 100, 100), "[VEIN] Could not find type data!")
        return
    end
    
    -- Check if this is a default type
    local defaultTypeNames = {
        ["Residential"] = true,
        ["Commercial"] = true,
        ["Industrial"] = true,
        ["Government"] = true,
        ["Emergency"] = true
    }
    local isDefault = defaultTypeNames[typeName]
    
    local frame = vgui.Create("DFrame")
    local frameW, frameH = ClampFrameSize(frame, 350, 250)
    frame:Center()
    frame:SetTitle((isDefault and "Edit Default Type: " or "Edit Door Type: ") .. typeName)
    frame:SetDraggable(true)
    frame:ShowCloseButton(true)
    frame:MakePopup()
    frame.Paint = function(self, w, h)
        surface.SetDrawColor(35, 35, 40, 255)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end
    
    -- Type Name
    local innerW = frameW - 40
    local nameLabel = vgui.Create("DLabel", frame)
    nameLabel:SetPos(20, 40)
    nameLabel:SetText("Type Name" .. (isDefault and " (Cannot rename defaults):" or ":"))
    nameLabel:SetTextColor(Color(200, 200, 200))
    nameLabel:SizeToContents()
    
    local nameEntry = vgui.Create("DTextEntry", frame)
    nameEntry:SetPos(20, 60)
    nameEntry:SetSize(innerW, 25)
    nameEntry:SetValue(typeData.name)
    nameEntry:SetEnabled(not isDefault) -- Disable name editing for defaults
    
    -- Color Mixer
    local colorLabel = vgui.Create("DLabel", frame)
    colorLabel:SetPos(20, 95)
    colorLabel:SetText("Door Type Color:")
    colorLabel:SetTextColor(Color(200, 200, 200))
    colorLabel:SizeToContents()
    
    local previewSize = 70
    local mixerW = math.max(160, innerW - previewSize - 10)
    local colorMixer = vgui.Create("DColorMixer", frame)
    colorMixer:SetPos(20, 115)
    colorMixer:SetSize(mixerW, 70)
    colorMixer:SetPalette(false)
    colorMixer:SetAlphaBar(false)
    colorMixer:SetWangs(true) -- Enable RGB sliders instead of HSV
    -- Force alpha to 255 before setting color
    local editColor = Color(typeData.color.r, typeData.color.g, typeData.color.b, 255)
    colorMixer:SetColor(editColor)
    
    -- Color Preview Box
    local previewBox = vgui.Create("DPanel", frame)
    previewBox:SetPos(20 + mixerW + 10, 115)
    previewBox:SetSize(previewSize, 70)
    previewBox.Paint = function(self, w, h)
        local col = colorMixer:GetColor()
        draw.RoundedBox(4, 0, 0, w, h, col)
        surface.SetDrawColor(255, 255, 255, 100)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        
        -- Show RGB values
        draw.SimpleText("R: " .. col.r, "DermaDefault", w/2, 10, Color(255, 255, 255), TEXT_ALIGN_CENTER)
        draw.SimpleText("G: " .. col.g, "DermaDefault", w/2, 25, Color(255, 255, 255), TEXT_ALIGN_CENTER)
        draw.SimpleText("B: " .. col.b, "DermaDefault", w/2, 40, Color(255, 255, 255), TEXT_ALIGN_CENTER)
    end
    
    -- Save Button
    local buttonW = math.floor((innerW - 10) / 2)
    local saveBtn = vgui.Create("DButton", frame)
    saveBtn:SetPos(20, 200)
    saveBtn:SetSize(buttonW, 30)
    saveBtn:SetText("Save Changes")
    saveBtn:SetTextColor(Color(255, 255, 255))
    saveBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60) or Color(40, 100, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    saveBtn.DoClick = function()
        local newName = nameEntry:GetValue()
        if newName == "" then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please enter a type name!")
            return
        end
        
        local newColor = colorMixer:GetColor()
        
        net.Start("VEIN_UpdateCustomType")
        net.WriteString(typeName) -- Original name
        net.WriteString(newName)  -- New name
        net.WriteUInt(newColor.r, 8)
        net.WriteUInt(newColor.g, 8)
        net.WriteUInt(newColor.b, 8)
        net.SendToServer()
        
        frame:Close()
    end
    
    -- Cancel Button
    local cancelBtn = vgui.Create("DButton", frame)
    cancelBtn:SetPos(20 + buttonW + 10, 200)
    cancelBtn:SetSize(buttonW, 30)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetTextColor(Color(255, 255, 255))
    cancelBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(100, 50, 50) or Color(70, 40, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(140, 70, 70, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    cancelBtn.DoClick = function()
        frame:Close()
    end
end

-- Open add material dialog
-- Open add material dialog from a default template (when clicking ➚ button)
function VEIN.NewSettingsPanel.OpenAddMaterialDialogFromTemplate(templateName)
    -- Find the template material data from the combined list
    local templateData = nil
    
    if VEIN.CustomDoors and VEIN.CustomDoors.Materials then
        for _, matData in ipairs(VEIN.CustomDoors.Materials) do
            if matData.name == templateName then
                templateData = {
                    name = matData.name,
                    kickTime = matData.kickTime,
                    lockSound = matData.lockSound or "doors/door_latch3.wav",
                    unlockSound = matData.unlockSound or "doors/door_latch1.wav",
                    kickSound = matData.kickSound or "physics/wood/wood_plank_break1.wav",
                    breakSound = matData.breakSound or "physics/wood/wood_crate_break1.wav"
                }
                print("[VEIN Template] Found material: " .. matData.name)
                print("[VEIN Template] Lock sound: " .. (templateData.lockSound or "nil"))
                print("[VEIN Template] Unlock sound: " .. (templateData.unlockSound or "nil"))
                print("[VEIN Template] Kick sound: " .. (templateData.kickSound or "nil"))
                print("[VEIN Template] Break sound: " .. (templateData.breakSound or "nil"))
                break
            end
        end
    end
    
    if not templateData then
        chat.AddText(Color(255, 100, 100), "[VEIN] Template not found: " .. tostring(templateName))
        return
    end
    
    -- Open the add material dialog with template data
    VEIN.NewSettingsPanel.OpenAddMaterialDialog(templateData)
end

function VEIN.NewSettingsPanel.OpenAddMaterialDialog(templateData)
    templateData = templateData or {} -- Empty if no template provided
    
    local frame = vgui.Create("DFrame")
    local baseW, baseH = 400, 620 -- Increased height for pitch sliders
    local frameW, frameH = ClampFrameSize(frame, baseW, baseH)
    frame:Center()
    frame:SetTitle(templateData.name and ("Add Material (Template: " .. templateData.name .. ")") or "Add Custom Door Material")
    frame:SetDraggable(true)
    frame:ShowCloseButton(true)
    frame:MakePopup()
    frame.Paint = function(self, w, h)
        surface.SetDrawColor(35, 35, 40, 255)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    local content = vgui.Create("DPanel", scroll)
    content:SetSize(frameW, baseH)
    content.Paint = function() end
    scroll:AddItem(content)

    local innerW = frameW - 40
    local testButtonW = 70
    local entryW = math.max(120, innerW - testButtonW - 10)
    
    local y = 40
    
    -- Material Name
    local nameLabel = vgui.Create("DLabel", content)
    nameLabel:SetPos(20, y)
    nameLabel:SetText("Material Name:")
    nameLabel:SetTextColor(Color(200, 200, 200))
    nameLabel:SizeToContents()
    
    local nameEntry = vgui.Create("DTextEntry", content)
    nameEntry:SetPos(20, y + 20)
    nameEntry:SetSize(innerW, 25)
    nameEntry:SetPlaceholderText("e.g., Reinforced Steel, Oak Wood")
    nameEntry:SetValue("") -- Always empty for new materials
    
    y = y + 55
    
    -- Kick Time
    local kickLabel = vgui.Create("DLabel", content)
    kickLabel:SetPos(20, y)
    kickLabel:SetText("Kick Time (seconds, -1 for unkickable):")
    kickLabel:SetTextColor(Color(200, 200, 200))
    kickLabel:SizeToContents()
    
    local kickSlider = vgui.Create("DNumSlider", content)
    kickSlider:SetPos(10, y + 15)
    kickSlider:SetSize(innerW, 25)
    kickSlider:SetText("")
    kickSlider:SetMin(-1)
    kickSlider:SetMax(120)
    kickSlider:SetDecimals(0)
    kickSlider:SetValue(templateData.kickTime or 15) -- Use template's kick time
    
    y = y + 50
    
    -- Lock Sound
    local lockLabel = vgui.Create("DLabel", content)
    lockLabel:SetPos(20, y)
    lockLabel:SetText("Lock Sound:")
    lockLabel:SetTextColor(Color(200, 200, 200))
    lockLabel:SizeToContents()
    
    local lockEntry = vgui.Create("DTextEntry", content)
    lockEntry:SetPos(20, y + 20)
    lockEntry:SetSize(entryW, 25)
    lockEntry:SetValue(templateData.lockSound or "doors/door_latch1.wav") -- Lock sound (higher pitch)
    
    local lockTestBtn = vgui.Create("DButton", content)
    lockTestBtn:SetPos(20 + entryW + 10, y + 20)
    lockTestBtn:SetSize(testButtonW, 25)
    lockTestBtn:SetText("Test")
    
    -- Lock Pitch Slider
    local lockPitchSlider = vgui.Create("DNumSlider", content)
    lockPitchSlider:SetPos(10, y + 45)
    lockPitchSlider:SetSize(innerW, 20)
    lockPitchSlider:SetText("Pitch:")
    lockPitchSlider:SetMin(50)
    lockPitchSlider:SetMax(150)
    lockPitchSlider:SetDecimals(0)
    lockPitchSlider:SetValue(templateData.lockPitch or 100)
    lockPitchSlider:SetDark(true)
    if lockPitchSlider.Label then
        lockPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    lockTestBtn.DoClick = function()
        EmitSound(lockEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, lockPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Unlock Sound
    local unlockLabel = vgui.Create("DLabel", content)
    unlockLabel:SetPos(20, y)
    unlockLabel:SetText("Unlock Sound:")
    unlockLabel:SetTextColor(Color(200, 200, 200))
    unlockLabel:SizeToContents()
    
    local unlockEntry = vgui.Create("DTextEntry", content)
    unlockEntry:SetPos(20, y + 20)
    unlockEntry:SetSize(entryW, 25)
    unlockEntry:SetValue(templateData.unlockSound or "doors/door_latch3.wav") -- Unlock sound (lower pitch)
    
    local unlockTestBtn = vgui.Create("DButton", content)
    unlockTestBtn:SetPos(20 + entryW + 10, y + 20)
    unlockTestBtn:SetSize(testButtonW, 25)
    unlockTestBtn:SetText("Test")
    
    -- Unlock Pitch Slider
    local unlockPitchSlider = vgui.Create("DNumSlider", content)
    unlockPitchSlider:SetPos(10, y + 45)
    unlockPitchSlider:SetSize(innerW, 20)
    unlockPitchSlider:SetText("Pitch:")
    unlockPitchSlider:SetMin(50)
    unlockPitchSlider:SetMax(150)
    unlockPitchSlider:SetDecimals(0)
    unlockPitchSlider:SetValue(templateData.unlockPitch or 100)
    unlockPitchSlider:SetDark(true)
    if unlockPitchSlider.Label then
        unlockPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    unlockTestBtn.DoClick = function()
        EmitSound(unlockEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, unlockPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Kick Sound
    local kickSoundLabel = vgui.Create("DLabel", content)
    kickSoundLabel:SetPos(20, y)
    kickSoundLabel:SetText("Kick Sound:")
    kickSoundLabel:SetTextColor(Color(200, 200, 200))
    kickSoundLabel:SizeToContents()
    
    local kickSoundEntry = vgui.Create("DTextEntry", content)
    kickSoundEntry:SetPos(20, y + 20)
    kickSoundEntry:SetSize(entryW, 25)
    kickSoundEntry:SetValue(templateData.kickSound or "physics/wood/wood_plank_break1.wav") -- Use template's kick sound
    
    local kickSoundTestBtn = vgui.Create("DButton", content)
    kickSoundTestBtn:SetPos(20 + entryW + 10, y + 20)
    kickSoundTestBtn:SetSize(testButtonW, 25)
    kickSoundTestBtn:SetText("Test")
    
    -- Kick Pitch Slider
    local kickPitchSlider = vgui.Create("DNumSlider", content)
    kickPitchSlider:SetPos(10, y + 45)
    kickPitchSlider:SetSize(innerW, 20)
    kickPitchSlider:SetText("Pitch:")
    kickPitchSlider:SetMin(50)
    kickPitchSlider:SetMax(150)
    kickPitchSlider:SetDecimals(0)
    kickPitchSlider:SetValue(templateData.kickPitch or 100)
    kickPitchSlider:SetDark(true)
    if kickPitchSlider.Label then
        kickPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    kickSoundTestBtn.DoClick = function()
        EmitSound(kickSoundEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, kickPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Break Sound
    local breakSoundLabel = vgui.Create("DLabel", content)
    breakSoundLabel:SetPos(20, y)
    breakSoundLabel:SetText("Break Sound:")
    breakSoundLabel:SetTextColor(Color(200, 200, 200))
    breakSoundLabel:SizeToContents()
    
    local breakSoundEntry = vgui.Create("DTextEntry", content)
    breakSoundEntry:SetPos(20, y + 20)
    breakSoundEntry:SetSize(entryW, 25)
    breakSoundEntry:SetValue(templateData.breakSound or "physics/wood/wood_crate_break1.wav") -- Use template's break sound
    
    local breakSoundTestBtn = vgui.Create("DButton", content)
    breakSoundTestBtn:SetPos(20 + entryW + 10, y + 20)
    breakSoundTestBtn:SetSize(testButtonW, 25)
    breakSoundTestBtn:SetText("Test")
    
    -- Break Pitch Slider
    local breakPitchSlider = vgui.Create("DNumSlider", content)
    breakPitchSlider:SetPos(10, y + 45)
    breakPitchSlider:SetSize(innerW, 20)
    breakPitchSlider:SetText("Pitch:")
    breakPitchSlider:SetMin(50)
    breakPitchSlider:SetMax(150)
    breakPitchSlider:SetDecimals(0)
    breakPitchSlider:SetValue(templateData.breakPitch or 100)
    breakPitchSlider:SetDark(true)
    if breakPitchSlider.Label then
        breakPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    breakSoundTestBtn.DoClick = function()
        EmitSound(breakSoundEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, breakPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Add Button
    local buttonW = math.floor((innerW - 10) / 2)
    local addBtn = vgui.Create("DButton", content)
    addBtn:SetPos(20, y)
    addBtn:SetSize(buttonW, 30)
    addBtn:SetText("Add Material")
    addBtn:SetTextColor(Color(255, 255, 255))
    addBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60) or Color(40, 100, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    addBtn.DoClick = function()
        local matName = nameEntry:GetValue()
        if matName == "" then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please enter a material name!")
            return
        end
        
        local kickTime = math.Round(kickSlider:GetValue())
        local lockSound = lockEntry:GetValue()
        local unlockSound = unlockEntry:GetValue()
        local kickSound = kickSoundEntry:GetValue()
        local breakSound = breakSoundEntry:GetValue()
        
        -- Get pitch values
        local lockPitch = math.Round(lockPitchSlider:GetValue())
        local unlockPitch = math.Round(unlockPitchSlider:GetValue())
        local kickPitch = math.Round(kickPitchSlider:GetValue())
        local breakPitch = math.Round(breakPitchSlider:GetValue())
        
        net.Start("VEIN_AddCustomMaterial")
        net.WriteString(matName)
        net.WriteInt(kickTime, 16)
        net.WriteString(lockSound)
        net.WriteString(unlockSound)
        net.WriteString(kickSound)
        net.WriteString(breakSound)
        net.WriteUInt(lockPitch, 8)
        net.WriteUInt(unlockPitch, 8)
        net.WriteUInt(kickPitch, 8)
        net.WriteUInt(breakPitch, 8)
        net.SendToServer()
        
        frame:Close()
    end
    
    -- Cancel Button
    local cancelBtn = vgui.Create("DButton", content)
    cancelBtn:SetPos(20 + buttonW + 10, y)
    cancelBtn:SetSize(buttonW, 30)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetTextColor(Color(255, 255, 255))
    cancelBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(100, 50, 50) or Color(70, 40, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(140, 70, 70, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    cancelBtn.DoClick = function()
        frame:Close()
    end
end

-- Open edit material dialog
function VEIN.NewSettingsPanel.OpenEditMaterialDialog(matName)
    -- Find the material data
    local matData = nil
    for _, data in ipairs(VEIN.CustomDoors.Materials or {}) do
        if data.name == matName then
            matData = data
            break
        end
    end
    
    if not matData then
        chat.AddText(Color(255, 100, 100), "[VEIN] Could not find material data!")
        return
    end
    
    local frame = vgui.Create("DFrame")
    local baseW, baseH = 400, 620 -- Increased height for pitch sliders
    local frameW, frameH = ClampFrameSize(frame, baseW, baseH)
    frame:Center()
    frame:SetTitle("Edit Door Material: " .. matName)
    frame:SetDraggable(true)
    frame:ShowCloseButton(true)
    frame:MakePopup()
    frame.Paint = function(self, w, h)
        surface.SetDrawColor(35, 35, 40, 255)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    local content = vgui.Create("DPanel", scroll)
    content:SetSize(frameW, baseH)
    content.Paint = function() end
    scroll:AddItem(content)

    local innerW = frameW - 40
    local testButtonW = 70
    local entryW = math.max(120, innerW - testButtonW - 10)
    
    local y = 40
    
    -- Material Name
    local nameLabel = vgui.Create("DLabel", content)
    nameLabel:SetPos(20, y)
    nameLabel:SetText("Material Name:")
    nameLabel:SetTextColor(Color(200, 200, 200))
    nameLabel:SizeToContents()
    
    local nameEntry = vgui.Create("DTextEntry", content)
    nameEntry:SetPos(20, y + 20)
    nameEntry:SetSize(innerW, 25)
    nameEntry:SetValue(matData.name)
    
    y = y + 55
    
    -- Kick Time
    local kickLabel = vgui.Create("DLabel", content)
    kickLabel:SetPos(20, y)
    kickLabel:SetText("Kick Time (seconds, -1 for unkickable):")
    kickLabel:SetTextColor(Color(200, 200, 200))
    kickLabel:SizeToContents()
    
    local kickSlider = vgui.Create("DNumSlider", content)
    kickSlider:SetPos(10, y + 15)
    kickSlider:SetSize(innerW, 25)
    kickSlider:SetText("")
    kickSlider:SetMin(-1)
    kickSlider:SetMax(120)
    kickSlider:SetDecimals(0)
    kickSlider:SetValue(matData.kickTime)
    
    y = y + 50
    
    -- Lock Sound
    local lockLabel = vgui.Create("DLabel", content)
    lockLabel:SetPos(20, y)
    lockLabel:SetText("Lock Sound:")
    lockLabel:SetTextColor(Color(200, 200, 200))
    lockLabel:SizeToContents()
    
    local lockEntry = vgui.Create("DTextEntry", content)
    lockEntry:SetPos(20, y + 20)
    lockEntry:SetSize(entryW, 25)
    lockEntry:SetValue(matData.lockSound)
    
    local lockTestBtn = vgui.Create("DButton", content)
    lockTestBtn:SetPos(20 + entryW + 10, y + 20)
    lockTestBtn:SetSize(testButtonW, 25)
    lockTestBtn:SetText("Test")
    
    -- Lock Pitch Slider
    local lockPitchSlider = vgui.Create("DNumSlider", content)
    lockPitchSlider:SetPos(10, y + 45)
    lockPitchSlider:SetSize(innerW, 20)
    lockPitchSlider:SetText("Pitch:")
    lockPitchSlider:SetMin(50)
    lockPitchSlider:SetMax(150)
    lockPitchSlider:SetDecimals(0)
    lockPitchSlider:SetValue(matData.lockPitch or 100)
    lockPitchSlider:SetDark(true)
    if lockPitchSlider.Label then
        lockPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    lockTestBtn.DoClick = function()
        EmitSound(lockEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, lockPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Unlock Sound
    local unlockLabel = vgui.Create("DLabel", content)
    unlockLabel:SetPos(20, y)
    unlockLabel:SetText("Unlock Sound:")
    unlockLabel:SetTextColor(Color(200, 200, 200))
    unlockLabel:SizeToContents()
    
    local unlockEntry = vgui.Create("DTextEntry", content)
    unlockEntry:SetPos(20, y + 20)
    unlockEntry:SetSize(entryW, 25)
    unlockEntry:SetValue(matData.unlockSound)
    
    local unlockTestBtn = vgui.Create("DButton", content)
    unlockTestBtn:SetPos(20 + entryW + 10, y + 20)
    unlockTestBtn:SetSize(testButtonW, 25)
    unlockTestBtn:SetText("Test")
    
    -- Unlock Pitch Slider
    local unlockPitchSlider = vgui.Create("DNumSlider", content)
    unlockPitchSlider:SetPos(10, y + 45)
    unlockPitchSlider:SetSize(innerW, 20)
    unlockPitchSlider:SetText("Pitch:")
    unlockPitchSlider:SetMin(50)
    unlockPitchSlider:SetMax(150)
    unlockPitchSlider:SetDecimals(0)
    unlockPitchSlider:SetValue(matData.unlockPitch or 100)
    unlockPitchSlider:SetDark(true)
    if unlockPitchSlider.Label then
        unlockPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    unlockTestBtn.DoClick = function()
        EmitSound(unlockEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, unlockPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Kick Sound
    local kickSoundLabel = vgui.Create("DLabel", content)
    kickSoundLabel:SetPos(20, y)
    kickSoundLabel:SetText("Kick Sound:")
    kickSoundLabel:SetTextColor(Color(200, 200, 200))
    kickSoundLabel:SizeToContents()
    
    local kickSoundEntry = vgui.Create("DTextEntry", content)
    kickSoundEntry:SetPos(20, y + 20)
    kickSoundEntry:SetSize(entryW, 25)
    kickSoundEntry:SetValue(matData.kickSound or "physics/wood/wood_plank_break1.wav")
    
    local kickSoundTestBtn = vgui.Create("DButton", content)
    kickSoundTestBtn:SetPos(20 + entryW + 10, y + 20)
    kickSoundTestBtn:SetSize(testButtonW, 25)
    kickSoundTestBtn:SetText("Test")
    
    -- Kick Pitch Slider
    local kickPitchSlider = vgui.Create("DNumSlider", content)
    kickPitchSlider:SetPos(10, y + 45)
    kickPitchSlider:SetSize(innerW, 20)
    kickPitchSlider:SetText("Pitch:")
    kickPitchSlider:SetMin(50)
    kickPitchSlider:SetMax(150)
    kickPitchSlider:SetDecimals(0)
    kickPitchSlider:SetValue(matData.kickPitch or 100)
    kickPitchSlider:SetDark(true)
    if kickPitchSlider.Label then
        kickPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    kickSoundTestBtn.DoClick = function()
        EmitSound(kickSoundEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, kickPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Break Sound
    local breakSoundLabel = vgui.Create("DLabel", content)
    breakSoundLabel:SetPos(20, y)
    breakSoundLabel:SetText("Break Sound:")
    breakSoundLabel:SetTextColor(Color(200, 200, 200))
    breakSoundLabel:SizeToContents()
    
    local breakSoundEntry = vgui.Create("DTextEntry", content)
    breakSoundEntry:SetPos(20, y + 20)
    breakSoundEntry:SetSize(entryW, 25)
    breakSoundEntry:SetValue(matData.breakSound or "physics/wood/wood_crate_break1.wav")
    
    local breakSoundTestBtn = vgui.Create("DButton", content)
    breakSoundTestBtn:SetPos(20 + entryW + 10, y + 20)
    breakSoundTestBtn:SetSize(testButtonW, 25)
    breakSoundTestBtn:SetText("Test")
    
    -- Break Pitch Slider
    local breakPitchSlider = vgui.Create("DNumSlider", content)
    breakPitchSlider:SetPos(10, y + 45)
    breakPitchSlider:SetSize(innerW, 20)
    breakPitchSlider:SetText("Pitch:")
    breakPitchSlider:SetMin(50)
    breakPitchSlider:SetMax(150)
    breakPitchSlider:SetDecimals(0)
    breakPitchSlider:SetValue(matData.breakPitch or 100)
    breakPitchSlider:SetDark(true)
    if breakPitchSlider.Label then
        breakPitchSlider.Label:SetTextColor(Color(200, 200, 200))
    end
    
    breakSoundTestBtn.DoClick = function()
        EmitSound(breakSoundEntry:GetValue(), Vector(0,0,0), -1, CHAN_AUTO, 1, 75, 0, breakPitchSlider:GetValue())
    end
    
    y = y + 75
    
    -- Save Button
    local buttonW = math.floor((innerW - 10) / 2)
    local saveBtn = vgui.Create("DButton", content)
    saveBtn:SetPos(20, y)
    saveBtn:SetSize(buttonW, 30)
    saveBtn:SetText("Save Changes")
    saveBtn:SetTextColor(Color(255, 255, 255))
    saveBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60) or Color(40, 100, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    saveBtn.DoClick = function()
        local newName = nameEntry:GetValue()
        if newName == "" then
            chat.AddText(Color(255, 100, 100), "[VEIN] Please enter a material name!")
            return
        end
        
        local kickTime = math.Round(kickSlider:GetValue())
        local lockSound = lockEntry:GetValue()
        local unlockSound = unlockEntry:GetValue()
        local kickSound = kickSoundEntry:GetValue()
        local breakSound = breakSoundEntry:GetValue()
        
        -- Get pitch values
        local lockPitch = math.Round(lockPitchSlider:GetValue())
        local unlockPitch = math.Round(unlockPitchSlider:GetValue())
        local kickPitch = math.Round(kickPitchSlider:GetValue())
        local breakPitch = math.Round(breakPitchSlider:GetValue())
        
        net.Start("VEIN_UpdateCustomMaterial")
        net.WriteString(matName) -- Original name
        net.WriteString(newName)  -- New name
        net.WriteInt(kickTime, 16)
        net.WriteString(lockSound)
        net.WriteString(unlockSound)
        net.WriteString(kickSound)
        net.WriteString(breakSound)
        net.WriteUInt(lockPitch, 8)
        net.WriteUInt(unlockPitch, 8)
        net.WriteUInt(kickPitch, 8)
        net.WriteUInt(breakPitch, 8)
        net.SendToServer()
        
        frame:Close()
    end
    
    -- Cancel Button
    local cancelBtn = vgui.Create("DButton", content)
    cancelBtn:SetPos(20 + buttonW + 10, y)
    cancelBtn:SetSize(buttonW, 30)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetTextColor(Color(255, 255, 255))
    cancelBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(100, 50, 50) or Color(70, 40, 40)
        surface.SetDrawColor(col)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(140, 70, 70, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    cancelBtn.DoClick = function()
        frame:Close()
    end
end

-- Remove custom type
function VEIN.NewSettingsPanel.RemoveCustomType(typeName)
    -- Check if it's a default type
    local defaultTypes = {"Residential", "Commercial", "Industrial", "Government", "Emergency"}
    for _, defType in ipairs(defaultTypes) do
        if typeName == defType then
            chat.AddText(Color(255, 100, 100), "[VEIN] Cannot remove default door types!")
            surface.PlaySound("buttons/button10.wav")
            return
        end
    end
    
    net.Start("VEIN_RemoveCustomType")
    net.WriteString(typeName)
    net.SendToServer()
end

-- Remove custom material
function VEIN.NewSettingsPanel.RemoveCustomMaterial(matName)
    -- Check if it's a default material
    local defaultMaterials = {"Wood Door", "Light Metal", "Glass Door", "Heavy Metal", "Steel Door"}
    for _, defMat in ipairs(defaultMaterials) do
        if matName == defMat then
            chat.AddText(Color(255, 100, 100), "[VEIN] Cannot remove default door materials!")
            surface.PlaySound("buttons/button10.wav")
            return
        end
    end
    
    net.Start("VEIN_RemoveCustomMaterial")
    net.WriteString(matName)
    net.SendToServer()
end

-- Network receiver for custom door data
net.Receive("VEIN_CustomDoorsData", function()
    VEIN.CustomDoors = VEIN.CustomDoors or {}
    VEIN.CustomDoors.Types = Net.ReadDoorTypes()
    VEIN.CustomDoors.Materials = Net.ReadDoorMaterials()
    
    VEIN.NewSettingsPanel.RefreshCustomDoorLists()
    
    print("[VEIN] Custom door data loaded: " .. #VEIN.CustomDoors.Types .. " types, " .. #VEIN.CustomDoors.Materials .. " materials")
end)

-- Auto-request custom door data when client loads (eliminates GUI delay)
hook.Add("InitPostEntity", "VEIN_RequestCustomDoorsData", function()
    timer.Simple(1, function()
        net.Start("VEIN_RequestCustomDoors")
        net.SendToServer()
    end)
end)

-- Network receiver for door list data
net.Receive("VEIN_DoorListData", function()
    local doorData = Net.ReadDoorList()
    
    if IsValid(VEIN.NewSettingsPanel.doorListBox) then
        -- Set flag to prevent auto-sorting during bulk add
        VEIN.NewSettingsPanel.doorListBox.m_isAddingLines = true
        VEIN.NewSettingsPanel.doorListBox:Clear()
        
        for _, door in ipairs(doorData) do
            local line = VEIN.NewSettingsPanel.doorListBox:AddLine(
                door.name ~= "" and door.name or "Unnamed Door",
                door.type,
                door.owner ~= "" and door.owner or "Unowned",
                door.status
            )
            
            -- Store door identifier for actions
            line.doorIdentifier = door.identifier
            
            -- Get door type color
            local typeColor = Color(255, 255, 255) -- Default white
            
            if door.disabled then
                -- Gray out disabled doors
                typeColor = Color(120, 120, 120)
            else
                -- Find color for this door type
                for _, typeData in ipairs(VEIN.CustomDoors.Types or {}) do
                    if typeData.name == door.type then
                        typeColor = typeData.color
                        break
                    end
                end
                
                -- Fallback colors if not found in custom types
                if typeColor == Color(255, 255, 255) then
                    local typeColors = {
                        ["Residential"] = Color(100, 200, 255),
                        ["Commercial"] = Color(255, 200, 100),
                        ["Government"] = Color(255, 100, 100),
                        ["Industrial"] = Color(200, 200, 200),
                        ["Luxury"] = Color(255, 215, 0),
                        ["Security"] = Color(255, 50, 50)
                    }
                    typeColor = typeColors[door.type] or Color(255, 255, 255)
                end
            end
            
            -- Apply color to each column in the line
            for i = 1, 4 do
                local column = line:GetColumnText(i)
                line.Columns[i]:SetTextColor(typeColor)
            end
        end
        
        -- Clear flag and trigger sort only if user has set a sort column
        VEIN.NewSettingsPanel.doorListBox.m_isAddingLines = false
        if VEIN.NewSettingsPanel.doorListBox.m_iSortColumn then
            timer.Simple(0, function()
                if IsValid(VEIN.NewSettingsPanel.doorListBox) then
                    VEIN.NewSettingsPanel.doorListBox:SortByColumn(
                        VEIN.NewSettingsPanel.doorListBox.m_iSortColumn,
                        VEIN.NewSettingsPanel.doorListBox.m_bSortDescending
                    )
                end
            end)
        end
    end
end)

-- Refresh player list with current data
function VEIN.NewSettingsPanel.RefreshPlayerList()
    if not IsValid(VEIN.NewSettingsPanel.playerListBox) then return end
    
    net.Start("VEIN_RequestPlayerList")
    net.SendToServer()
end

-- Refresh panel with current data
function VEIN.NewSettingsPanel.RefreshPanel()
    if not settingsCache.loaded then return end
    
    -- Set flag to prevent change callbacks from triggering during refresh
    VEIN.NewSettingsPanel.isRefreshing = true
    
    if VEIN.NewSettingsPanel.moneyCombo and IsValid(VEIN.NewSettingsPanel.moneyCombo) then
        local choice = settingsCache.useCustomMoney and 1 or 2
        VEIN.NewSettingsPanel.moneyCombo:ChooseOptionID(choice)
    end
    
    if VEIN.NewSettingsPanel.moneyStatus and IsValid(VEIN.NewSettingsPanel.moneyStatus) then
        VEIN.NewSettingsPanel.moneyStatus:SetText("(Currently: " .. (settingsCache.useCustomMoney and "VEIN Money" or "DarkRP Money") .. ")")
        VEIN.NewSettingsPanel.moneyStatus:SetTextColor(settingsCache.useCustomMoney and Color(150, 255, 150) or Color(255, 200, 100))
        VEIN.NewSettingsPanel.moneyStatus:SizeToContents()
    end
    
    if VEIN.NewSettingsPanel.limitSlider and IsValid(VEIN.NewSettingsPanel.limitSlider) then
        VEIN.NewSettingsPanel.limitSlider:SetValue(settingsCache.defaultDoorLimit)
    end
    
    if VEIN.NewSettingsPanel.enableCheck and IsValid(VEIN.NewSettingsPanel.enableCheck) then
        VEIN.NewSettingsPanel.enableCheck:SetChecked(settingsCache.enableDoorLimits)
    end
    
    if VEIN.NewSettingsPanel.lockTimeSlider and IsValid(VEIN.NewSettingsPanel.lockTimeSlider) then
        VEIN.NewSettingsPanel.lockTimeSlider:SetValue(GetConVar("vein_lock_time"):GetFloat())
    end
    
    if VEIN.NewSettingsPanel.kickCheck and IsValid(VEIN.NewSettingsPanel.kickCheck) then
        local kickConVar = GetConVar("vein_enable_door_kicking")
        if kickConVar then
            VEIN.NewSettingsPanel.kickCheck:SetChecked(kickConVar:GetBool())
        end
    end
    
    -- Clear the refresh flag after a short delay to allow UI to update
    timer.Simple(0.1, function()
        VEIN.NewSettingsPanel.isRefreshing = false
    end)
end

-- Send settings update to server
function VEIN.NewSettingsPanel.SendSettingsUpdate()
    if not VEIN.NewSettingsPanel.moneyCombo or not IsValid(VEIN.NewSettingsPanel.moneyCombo) or 
       not VEIN.NewSettingsPanel.limitSlider or not IsValid(VEIN.NewSettingsPanel.limitSlider) or 
       not VEIN.NewSettingsPanel.enableCheck or not IsValid(VEIN.NewSettingsPanel.enableCheck) then
        return
    end
    
    -- Prevent rapid-fire updates
    if VEIN.NewSettingsPanel.isRefreshing then
        return
    end
    
    local useCustomMoney = VEIN.NewSettingsPanel.moneyCombo:GetSelected() == "VEIN Custom Money"
    local defaultLimit = math.Round(VEIN.NewSettingsPanel.limitSlider:GetValue())
    local enableLimits = VEIN.NewSettingsPanel.enableCheck:GetChecked()
    
    net.Start("VEIN_UpdateSettingsData")
    net.WriteBool(useCustomMoney)
    net.WriteInt(defaultLimit, 16)
    net.WriteBool(enableLimits)
    net.SendToServer()
end

-- Add to Q menu - use existing VEIN tab
hook.Add("AddToolMenuTabs", "VEIN_AddSettingsTab", function()
    spawnmenu.AddToolTab("VEIN", "VEIN", "icon16/application_xp_terminal.png")
end)

hook.Add("AddToolMenuCategories", "VEIN_AddSettingsCategory", function()
    spawnmenu.AddToolCategory("VEIN", "Settings", "Door System Settings")
end)

hook.Add("PopulateToolMenu", "VEIN_NewSettingsPanel", function()
    spawnmenu.AddToolMenuOption("VEIN", "Settings", "VEIN_NewSettings", "VEIN Configuration", "", "", function(panel)
        panel:ClearControls()
        
        -- Dark background for the panel
        panel.Paint = function(self, w, h)
            surface.SetDrawColor(25, 25, 28, 255)
            surface.DrawRect(0, 0, w, h)
        end
        
        -- Header with VEIN branding
        local headerPanel = vgui.Create("DPanel")
        headerPanel:SetTall(80)
        headerPanel.Paint = function(self, w, h)
            -- Dark background with red accent
            surface.SetDrawColor(30, 30, 33, 255)
            surface.DrawRect(0, 0, w, h)
            
            -- Top red accent line
            surface.SetDrawColor(180, 60, 60, 200)
            surface.DrawRect(0, 0, w, 3)
            
            -- Bottom border
            surface.SetDrawColor(50, 50, 53, 255)
            surface.DrawRect(0, h - 1, w, 1)
        end
        panel:AddItem(headerPanel)
        
        local header = vgui.Create("DLabel", headerPanel)
        header:SetPos(15, 15)
        header:SetText("VEIN Door System")
        header:SetFont("DermaLarge")
        header:SetTextColor(Color(255, 200, 200))
        header:SizeToContents()
        
        local subheader = vgui.Create("DLabel", headerPanel)
        subheader:SetPos(15, 42)
        subheader:SetText("Property Management & Configuration")
        subheader:SetFont("DermaDefault")
        subheader:SetTextColor(Color(180, 180, 185))
        subheader:SizeToContents()
        
        -- Spacer
        local spacer1 = vgui.Create("DPanel")
        spacer1:SetTall(10)
        spacer1.Paint = function() end
        panel:AddItem(spacer1)
        
        -- Open Configuration Button (Admin only)
        if LocalPlayer():IsAdmin() then
            local openBtn = vgui.Create("DButton")
            openBtn:SetText("")
            openBtn:SetSize(200, 45)
            openBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                
                -- Background
                local bgColor = isHovered and Color(45, 45, 48, 255) or Color(35, 35, 38, 255)
                draw.RoundedBox(6, 0, 0, w, h, bgColor)
                
                -- Red accent border on hover
                if isHovered then
                    surface.SetDrawColor(140, 60, 60, 200)
                    surface.DrawOutlinedRect(0, 0, w, h, 2)
                else
                    surface.SetDrawColor(80, 80, 85, 150)
                    surface.DrawOutlinedRect(0, 0, w, h, 1)
                end
                
                -- Red left accent bar
                surface.SetDrawColor(180, 60, 60, isHovered and 200 or 150)
                surface.DrawRect(0, 0, 4, h)
                
                -- Text
                draw.SimpleText("⚙ Open Configuration Panel", "DermaDefaultBold", w/2, h/2, Color(220, 220, 225), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            openBtn.DoClick = function()
                VEIN.NewSettingsPanel.Create()
                surface.PlaySound("buttons/button15.wav")
            end
            panel:AddItem(openBtn)
        end
        
        -- Spacer
        local spacer2 = vgui.Create("DPanel")
        spacer2:SetTall(15)
        spacer2.Paint = function() end
        panel:AddItem(spacer2)
        
        -- Status panel
        local statusPanel = vgui.Create("DPanel")
        statusPanel:SetTall(60)
        statusPanel.Paint = function(self, w, h)
            -- Dark background
            surface.SetDrawColor(30, 30, 33, 255)
            surface.DrawRect(0, 0, w, h)
            
            -- Border
            surface.SetDrawColor(50, 50, 53, 255)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        panel:AddItem(statusPanel)
        
        local statusLabel = vgui.Create("DLabel", statusPanel)
        statusLabel:SetPos(15, 10)
        statusLabel:SetText("Access Level:")
        statusLabel:SetFont("DermaDefaultBold")
        statusLabel:SetTextColor(Color(180, 180, 185))
        statusLabel:SizeToContents()
        
        local adminNote = vgui.Create("DLabel", statusPanel)
        adminNote:SetPos(15, 30)
        if LocalPlayer():IsAdmin() then
            adminNote:SetText("✓ Administrator Access Granted")
            adminNote:SetTextColor(Color(100, 255, 100))
        else
            adminNote:SetText("✗ Administrator Access Required")
            adminNote:SetTextColor(Color(255, 100, 100))
        end
        adminNote:SetFont("DermaDefault")
        adminNote:SizeToContents()
        
        -- Spacer
        local spacer3 = vgui.Create("DPanel")
        spacer3:SetTall(15)
        spacer3.Paint = function(self, w, h)
            surface.SetDrawColor(25, 25, 28, 255)
            surface.DrawRect(0, 0, w, h)
        end
        panel:AddItem(spacer3)
        
        -- Quick Options Title
        local quickLabelPanel = vgui.Create("DPanel")
        quickLabelPanel:SetTall(25)
        quickLabelPanel.Paint = function(self, w, h)
            surface.SetDrawColor(25, 25, 28, 255)
            surface.DrawRect(0, 0, w, h)
        end
        panel:AddItem(quickLabelPanel)
        
        local quickLabel = vgui.Create("DLabel", quickLabelPanel)
        quickLabel:SetPos(0, 5)
        quickLabel:SetText("Quick Options:")
        quickLabel:SetFont("DermaDefaultBold")
        quickLabel:SetTextColor(Color(200, 200, 205))
        quickLabel:SizeToContents()
        
        -- Quick option spacer
        local spacer4 = vgui.Create("DPanel")
        spacer4:SetTall(8)
        spacer4.Paint = function(self, w, h)
            surface.SetDrawColor(25, 25, 28, 255)
            surface.DrawRect(0, 0, w, h)
        end
        panel:AddItem(spacer4)
        
        -- Toggle Door Limits (Admin only)
        if LocalPlayer():IsAdmin() then
            local toggleLimitsBtn = vgui.Create("DButton")
            toggleLimitsBtn:SetText("")
            toggleLimitsBtn:SetSize(200, 35)
            toggleLimitsBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                local bgColor = isHovered and Color(45, 45, 48, 255) or Color(35, 35, 38, 255)
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
                
                surface.SetDrawColor(80, 80, 85, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
                
                surface.SetDrawColor(100, 150, 100, isHovered and 150 or 100)
                surface.DrawRect(0, 0, 3, h)
                
                draw.SimpleText("Toggle Door Limits", "DermaDefault", w/2, h/2, Color(220, 220, 225), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            toggleLimitsBtn.DoClick = function()
                local currentValue = GetConVar("vein_enable_door_limits"):GetBool()
                RunConsoleCommand("vein_enable_door_limits", currentValue and "0" or "1")
                -- Show the NEW state (opposite of current)
                chat.AddText(Color(100, 255, 100), "[VEIN] Door limits ", Color(255, 255, 100), currentValue and "disabled" or "enabled")
                surface.PlaySound("buttons/button15.wav")
            end
            panel:AddItem(toggleLimitsBtn)
        end
        
        -- Quick spacer
        local spacer5 = vgui.Create("DPanel")
        spacer5:SetTall(5)
        spacer5.Paint = function(self, w, h)
            surface.SetDrawColor(25, 25, 28, 255)
            surface.DrawRect(0, 0, w, h)
        end
        panel:AddItem(spacer5)
        
        -- Toggle Money System (Admin only)
        if LocalPlayer():IsAdmin() then
            local toggleMoneyBtn = vgui.Create("DButton")
            toggleMoneyBtn:SetText("")
            toggleMoneyBtn:SetSize(200, 35)
            toggleMoneyBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                local bgColor = isHovered and Color(45, 45, 48, 255) or Color(35, 35, 38, 255)
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
                
                surface.SetDrawColor(80, 80, 85, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
                
                surface.SetDrawColor(100, 120, 150, isHovered and 150 or 100)
                surface.DrawRect(0, 0, 3, h)
                
                draw.SimpleText("Toggle Money System", "DermaDefault", w/2, h/2, Color(220, 220, 225), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            toggleMoneyBtn.DoClick = function()
                local currentValue = GetConVar("vein_use_custom_money"):GetBool()
                RunConsoleCommand("vein_use_custom_money", currentValue and "0" or "1")
                -- Show the NEW state (opposite of current)
                chat.AddText(Color(100, 255, 100), "[VEIN] Money system: ", Color(255, 255, 100), currentValue and "DarkRP" or "VEIN Custom")
                surface.PlaySound("buttons/button15.wav")
            end
            panel:AddItem(toggleMoneyBtn)
        end
        
        -- Quick spacer
        local spacer6 = vgui.Create("DPanel")
        spacer6:SetTall(5)
        spacer6.Paint = function(self, w, h)
            surface.SetDrawColor(25, 25, 28, 255)
            surface.DrawRect(0, 0, w, h)
        end
        panel:AddItem(spacer6)
        
        -- Open Tutorial Button (Admin only - contains server setup info)
        if LocalPlayer():IsAdmin() then
            local tutorialBtn = vgui.Create("DButton")
            tutorialBtn:SetText("")
            tutorialBtn:SetSize(200, 35)
            tutorialBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                local bgColor = isHovered and Color(65, 85, 125, 255) or Color(50, 65, 100, 255)
                draw.RoundedBox(4, 0, 0, w, h, bgColor)
                
                -- Blue border on hover
                if isHovered then
                    surface.SetDrawColor(100, 150, 255, 200)
                    surface.DrawOutlinedRect(0, 0, w, h, 1)
                else
                    surface.SetDrawColor(80, 80, 85, 150)
                    surface.DrawOutlinedRect(0, 0, w, h, 1)
                end
                
                -- Blue left accent bar
                surface.SetDrawColor(100, 150, 255, isHovered and 200 or 150)
                surface.DrawRect(0, 0, 3, h)
                
                draw.SimpleText("[?] Open Tutorial", "DermaDefaultBold", w/2, h/2, Color(230, 230, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            tutorialBtn.DoClick = function()
                surface.PlaySound("buttons/button14.wav")
                if VEIN.Tutorial and VEIN.Tutorial.Open then
                    VEIN.Tutorial.Open()
                else
                    chat.AddText(Color(255, 100, 100), "[VEIN] Tutorial system not loaded!")
                end
            end
            panel:AddItem(tutorialBtn)
        end
        
        -- Final spacer to fill remaining space and prevent white background
        local spacerFinal = vgui.Create("DPanel")
        spacerFinal:SetTall(2000) -- Very large to ensure it fills all remaining space
        spacerFinal.Paint = function(self, w, h)
            surface.SetDrawColor(25, 25, 28, 255)
            surface.DrawRect(0, 0, w, h)
        end
        panel:AddItem(spacerFinal)
    end)
end)


