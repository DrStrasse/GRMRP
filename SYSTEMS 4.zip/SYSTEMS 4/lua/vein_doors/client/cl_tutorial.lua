--[[
================================================================================
VEIN Door System - Tutorial
Short onboarding guide with section index and first-time auto prompt.
================================================================================
]]--

if SERVER then return end

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.Tutorial = VEIN.Tutorial or {}

surface.CreateFont("VEIN_TutorialTitle", { font = "Trebuchet MS", size = 28, weight = 900, antialias = true })
surface.CreateFont("VEIN_TutorialBody", { font = "Trebuchet MS", size = 21, weight = 700, antialias = true })
surface.CreateFont("VEIN_TutorialMeta", { font = "Trebuchet MS", size = 16, weight = 700, antialias = true })
surface.CreateFont("VEIN_TutorialIndexMain", { font = "Trebuchet MS", size = 17, weight = 900, antialias = true })
surface.CreateFont("VEIN_TutorialIndexSub", { font = "Trebuchet MS", size = 15, weight = 700, antialias = true })
surface.CreateFont("VEIN_TutorialButton", { font = "Trebuchet MS", size = 18, weight = 900, antialias = true })

local TUTORIAL_FILE = "vein_tutorial_seen.txt"
local tutorialFrame

local tutorialData = {
    currentStep = 1,
    visited = {},
    autoPrompted = false,
    totalSections = 0,
    ui = {},
}

local function ClampFrameSize(frame, baseW, baseH)
    local w = math.max(860, math.min(baseW, ScrW() - 80))
    local h = math.max(560, math.min(baseH, ScrH() - 80))
    if IsValid(frame) then frame:SetSize(w, h) end
    return w, h
end

local function HasSeenTutorial()
    return file.Exists(TUTORIAL_FILE, "DATA") and file.Read(TUTORIAL_FILE, "DATA") == "1"
end

local function SetTutorialSeen()
    file.Write(TUTORIAL_FILE, "1")
end

local function PlayTutorialClickSound()
    local ply = LocalPlayer()
    if IsValid(ply) then
        sound.Play("buttons/button15.wav", ply:GetPos(), 60, 100, 0.6)
    else
        surface.PlaySound("buttons/button15.wav")
    end
end

concommand.Add("vein_reset_tutorial", function()
    if file.Exists(TUTORIAL_FILE, "DATA") then
        file.Delete(TUTORIAL_FILE)
    end
    tutorialData.autoPrompted = false
    chat.AddText(Color(100, 255, 100), "[VEIN] ", Color(255, 255, 255), "Tutorial reset. It will auto-open again for first-time flow.")
end)

local steps = {
    { title = "Welcome", description = "Short guide for server owners and door admins.\n\nYou'll learn the core workflow, property setup, and access controls.\n\nUse the left index to jump between sections at any time.", isMainSection = true, hasImage = true, imagePath = "vein/tutorial/welcome.png" },
    { title = "Quick Setup", description = "Start with global defaults so every door behaves correctly.\n\nSet money source, door limits, lock timing, refund percent, and admin rules.\n\nOpen settings now, then resume here.", isMainSection = true, hasButton = true, buttonText = "Open General Settings", hasImage = true, imagePath = "vein/tutorial/quick_setup.png" },
    { title = "Door Manager Tool", description = "Main workflow tool in Q -> Tools -> VEIN Door System.\n\nUse it to create, modify, link, copy settings, and define properties.\n\nThis tool is the fastest way to build a full map setup.", isMainSection = true, hasImage = true, imagePath = "vein/tutorial/door_manager_tool.png" },
    { title = "Tool Controls", parentSection = "Door Manager Tool", description = "Left Click: Create\nRight Click: Modify\nShift + Left: Link doors\nReload: Group editor\nMiddle Click: Copy / Paste\n\nTip: copy from a good door and paste to speed up a full property.", isSubSection = true, hasImage = true, imagePath = "vein/tutorial/tool_controls.png" },
    { title = "Create / Modify / Copy", parentSection = "Door Manager Tool", description = "Set clear names, prices, types, and materials.\n\nFor property groups: give a group name and set a custom price if needed.\n\nCopy/paste lets you duplicate a full configuration instantly.", isSubSection = true, hasImage = true, imagePath = "vein/tutorial/creating_doors.png" },
    { title = "Access Systems", description = "VEIN supports two access models. Pick one per area:\n\n- Job-Controlled doors (strict, consistent behavior)\n- DarkRP-style groups (compatibility with other addons)", isMainSection = true, hasImage = true, imagePath = "vein/tutorial/door_group_editor.png" },
    { title = "Job-Controlled vs Groups", parentSection = "Access Systems", description = "Job-Controlled: door access is tied to jobs and VEIN rules.\nGroups: preset lists for classic DarkRP behavior.\n\nTry to keep a whole building consistent for fewer support tickets.", isSubSection = true, hasImage = true, imagePath = "vein/tutorial/groups_vs_job.png" },
    { title = "Configuration Panel", description = "Open: Q -> VEIN -> VEIN Configuration -> Open Configuration Panel.\n\nKey tabs: General, Limits, Custom Doors, Door Management.\n\nUse these to configure global defaults and admin tools.", isMainSection = true, hasImage = true, imagePath = "vein/tutorial/config_panel.png" },
    { title = "General + Limits", parentSection = "Configuration Panel", description = "General: economy, locking, refunds, admin restrictions.\nLimits: per-player overrides and exceptions.\n\nSet stable defaults first, then add exceptions only if needed.", isSubSection = true, hasImage = true, imagePath = "vein/tutorial/general_settings.png" },
    { title = "Custom + Management", parentSection = "Configuration Panel", description = "Custom Doors: define door types, materials, and icons.\nDoor Management: teleport, enable/disable, delete, and restore.\n\nUse teleport for fast support work.", isSubSection = true, hasImage = true, imagePath = "vein/tutorial/door_management_tab.png" },
    { title = "3D Door Menu", description = "The in-world door menu adapts by role and permissions.\n\nOwners see rename/permissions. Admins see force-sell and edits.\n\nHold keys and look at a door to open it.", isMainSection = true, hasImage = true, imagePath = "vein/tutorial/3d_door_menu.png" },
    { title = "Owner / Admin Actions", parentSection = "3D Door Menu", description = "Owner: rename, grant access, repair, sell.\nAdmin: force-sell, edit properties, delete, or disable.\n\nForce-sell is for support and dispute resolution.", isSubSection = true, hasImage = true, imagePath = "vein/tutorial/admin_options.png" },
    { title = "Best Practices", description = "Suggested order:\n1) Configure globals\n2) Build restricted doors\n3) Build buyable doors\n4) Validate in Door Management\n\nRun a quick test after map cleanup to confirm persistence.", isMainSection = true, hasImage = true, imagePath = "vein/tutorial/best_practices.png" },
    { title = "Done", description = "Tutorial complete.\n\nOpen anytime:\n- Q -> VEIN -> VEIN Configuration -> Open Tutorial\n- Console: vein_tutorial\n- Chat: /veinguide\n\nYou can reset tutorial status with: vein_reset_tutorial", isMainSection = true, hasImage = true, imagePath = "vein/tutorial/complete.png" },
}

steps[2].buttonAction = function()
    local tutFrame = VEIN.Tutorial.GetFrame()
    if IsValid(tutFrame) then tutFrame:SetVisible(false) end
    VEIN.Tutorial.OpenGeneralSettings(tutFrame)
end

local function CountSections()
    local n = 0
    for _, step in ipairs(steps) do
        if step.isMainSection then n = n + 1 end
    end
    return n
end

local function BuildSectionMap()
    local map = {}
    local sections = {}
    local sectionIndex = 0
    for i, step in ipairs(steps) do
        if step.isMainSection then
            sectionIndex = sectionIndex + 1
            sections[sectionIndex] = { title = step.title, mainIndex = i, subSteps = {} }
            map[i] = { section = sectionIndex, sectionTitle = step.title, subIndex = 0, subTotal = 0 }
        else
            local sec = sections[sectionIndex]
            if sec then table.insert(sec.subSteps, i) end
            map[i] = { section = sectionIndex, sectionTitle = sec and sec.title or "", subIndex = 0, subTotal = 0 }
        end
    end

    for _, sec in ipairs(sections) do
        local total = #sec.subSteps
        if sec.mainIndex and map[sec.mainIndex] then
            map[sec.mainIndex].subTotal = total
        end
        for idx, stepIdx in ipairs(sec.subSteps) do
            map[stepIdx].subIndex = idx
            map[stepIdx].subTotal = total
            map[stepIdx].sectionTitle = sec.title
        end
    end
    return map
end

local function FormatProgressText(stepNum)
    local entry = tutorialData.sectionMap and tutorialData.sectionMap[stepNum]
    if not entry then
        return "Step " .. stepNum .. "/" .. #steps
    end
    local txt = "Section " .. entry.section .. "/" .. tutorialData.totalSections
    if entry.subIndex and entry.subIndex > 0 then
        txt = txt .. "  -  Subsection " .. entry.subIndex .. "/" .. math.max(1, entry.subTotal or 1)
    elseif entry.subTotal and entry.subTotal > 0 then
        txt = txt .. "  -  " .. entry.subTotal .. " subsections"
    end
    return txt
end

local function ApplyButtonStyle(button, variant)
    button:SetFont("VEIN_TutorialButton")
    button:SetTextColor(Color(245, 245, 250))
    button.Paint = function(self, w, h)
        local enabled = self:IsEnabled()
        local hovered = self:IsHovered()
        local down = self:IsDown()
        local base

        if not enabled then
            base = Color(55, 55, 62, 160)
        elseif variant == "danger" then
            base = hovered and Color(160, 70, 70, 230) or Color(140, 60, 60, 220)
            if down then base = Color(120, 52, 52, 230) end
        elseif variant == "secondary" then
            base = hovered and Color(70, 76, 88, 225) or Color(58, 62, 72, 215)
            if down then base = Color(50, 54, 62, 225) end
        else
            base = hovered and Color(72, 124, 196, 230) or Color(56, 96, 168, 220)
            if down then base = Color(46, 80, 140, 230) end
        end

        draw.RoundedBox(6, 0, 0, w, h, base)
        surface.SetDrawColor(0, 0, 0, 110)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        surface.SetDrawColor(255, 255, 255, hovered and 28 or 18)
        surface.DrawRect(1, 1, w - 2, math.floor(h * 0.34))
    end
end

local function OpenSkipConfirm(onConfirm)
    local frame = vgui.Create("DFrame")
    local frameW, frameH = ClampFrameSize(frame, 420, 210)
    frame:Center()
    frame:SetTitle("")
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)
    frame:MakePopup()

    frame.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        draw.RoundedBoxEx(8, 0, 0, w, 48, Color(30, 30, 33, 255), true, true, false, false)
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end

    local title = vgui.Create("DLabel", frame)
    title:SetPos(0, 10)
    title:SetSize(frameW, 24)
    title:SetText("Skip Tutorial?")
    title:SetFont("VEIN_TutorialTitle")
    title:SetTextColor(Color(255, 170, 170))
    title:SetContentAlignment(5)

    local body = vgui.Create("DLabel", frame)
    body:SetPos(20, 62)
    body:SetSize(frameW - 40, 70)
    body:SetText("This will mark the tutorial as completed.\nYou can reopen it later from the settings menu.")
    body:SetFont("VEIN_TutorialBody")
    body:SetTextColor(Color(210, 210, 218))
    body:SetContentAlignment(5)

    local buttonY = frameH - 52
    local buttonW = math.floor((frameW - 60) / 2)
    local cancel = vgui.Create("DButton", frame)
    cancel:SetPos(20, buttonY)
    cancel:SetSize(buttonW, 32)
    cancel:SetText("Cancel")
    ApplyButtonStyle(cancel, "secondary")
    cancel.DoClick = function()
        PlayTutorialClickSound()
        frame:Close()
    end

    local confirm = vgui.Create("DButton", frame)
    confirm:SetPos(20 + buttonW + 20, buttonY)
    confirm:SetSize(buttonW, 32)
    confirm:SetText("Skip")
    ApplyButtonStyle(confirm, "danger")
    confirm.DoClick = function()
        PlayTutorialClickSound()
        if onConfirm then onConfirm() end
        frame:Close()
    end
end

local function CurrentSection(stepNum)
    local n = 0
    for i = 1, stepNum do
        if steps[i] and steps[i].isMainSection then n = n + 1 end
    end
    return math.max(1, n)
end

local function UpdateNavUI()
    local ui = tutorialData.ui
    local step = steps[tutorialData.currentStep]
    if IsValid(ui.progress) then
        ui.progress:SetText(FormatProgressText(tutorialData.currentStep))
    end
    if IsValid(ui.prev) then ui.prev:SetEnabled(tutorialData.currentStep > 1) end
    if IsValid(ui.next) then ui.next:SetText(tutorialData.currentStep >= #steps and "Finish" or "Next") end
end

local function DrawStepContent(panel, stepNum)
    panel:Clear()
    local step = steps[stepNum]
    if not step then return end

    local w, h = panel:GetWide(), panel:GetTall()
    local y = 8

    local entry = tutorialData.sectionMap and tutorialData.sectionMap[stepNum] or nil
    if entry then
        local meta = vgui.Create("DLabel", panel)
        meta:SetPos(0, y)
        meta:SetSize(w, 18)
        meta:SetFont("VEIN_TutorialMeta")
        meta:SetTextColor(Color(165, 175, 195))
        meta:SetText(FormatProgressText(stepNum))
        meta:SetContentAlignment(5)
        y = y + 20
    end

    if step.isSubSection and step.parentSection then
        local parent = vgui.Create("DLabel", panel)
        parent:SetPos(0, y)
        parent:SetSize(w, 20)
        parent:SetText("Section: " .. step.parentSection)
        parent:SetFont("DermaDefaultBold")
        parent:SetTextColor(Color(130, 160, 210))
        parent:SetContentAlignment(5)
        y = y + 22
    end

    local title = vgui.Create("DLabel", panel)
    title:SetPos(0, y)
    title:SetSize(w, 34)
    title:SetText(step.title)
    title:SetFont("VEIN_TutorialTitle")
    title:SetTextColor(Color(130, 188, 255))
    title:SetContentAlignment(5)
    y = y + 36

    local descBox = vgui.Create("DPanel", panel)
    local descH = math.min(240, math.max(140, math.floor(h * 0.42)))
    descBox:SetPos(12, y)
    descBox:SetSize(w - 24, descH)
    descBox.Paint = function(self, pw, ph)
        draw.RoundedBox(6, 0, 0, pw, ph, Color(28, 28, 32, 235))
        surface.SetDrawColor(120, 40, 40, 100)
        surface.DrawOutlinedRect(0, 0, pw, ph, 1)
    end

    local desc = vgui.Create("DLabel", descBox)
    desc:SetPos(16, 10)
    desc:SetSize(descBox:GetWide() - 32, descBox:GetTall() - 20)
    desc:SetText(step.description)
    desc:SetFont("VEIN_TutorialBody")
    desc:SetTextColor(Color(220, 220, 228))
    desc:SetWrap(true)
    desc:SetContentAlignment(7)
    y = y + descH + 8

    if step.hasButton and step.buttonText and step.buttonAction then
        local act = vgui.Create("DButton", panel)
        local bw = math.min(360, w - 80)
        act:SetPos(math.floor((w - bw) * 0.5), y)
        act:SetSize(bw, 38)
        act:SetText(step.buttonText)
        ApplyButtonStyle(act, "primary")
        act.DoClick = function()
            PlayTutorialClickSound()
            step.buttonAction()
        end
        y = y + 46
    end

    local rem = h - y - 8
    if step.hasImage and step.imagePath and rem >= 100 then
        local img = vgui.Create("DPanel", panel)
        img:SetPos(20, y)
        img:SetSize(w - 40, rem)
        img.Paint = function(self, pw, ph)
            local mat = Material(string.gsub(step.imagePath, "%.png$", ""), "smooth noclamp")
            if mat and not mat:IsError() then
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(mat)
                surface.DrawTexturedRect(0, 0, pw, ph)
            end
        end
    end
end

local function GoToStep(stepNum)
    tutorialData.currentStep = math.Clamp(stepNum, 1, #steps)
    tutorialData.visited[tutorialData.currentStep] = true
    DrawStepContent(tutorialData.ui.content, tutorialData.currentStep)
    UpdateNavUI()
end

local function BuildIndex(scroll)
    scroll:Clear()
    tutorialData.ui.indexButtons = {}
    local y = 8
    for i, step in ipairs(steps) do
        local isSub = step.isSubSection == true
        local h = isSub and 24 or 30
        local b = vgui.Create("DButton", scroll)
        b:SetPos(8, y)
        b:SetSize(scroll:GetWide() - 24, h)
        b:SetText("")
        b.Paint = function(self, w, ph)
            local isCurrent = tutorialData.currentStep == i
            local visited = tutorialData.visited[i] == true
            local bg, txt
            if isCurrent then
                bg, txt = Color(48, 78, 128, 220), Color(238, 244, 255)
            elseif visited then
                -- Visited entries are darker than unvisited entries.
                bg, txt = Color(28, 28, 32, 210), Color(145, 145, 152)
            else
                bg, txt = Color(40, 40, 46, 205), Color(208, 208, 216)
            end
            draw.RoundedBox(4, 0, 0, w, ph, bg)
            local entry = tutorialData.sectionMap and tutorialData.sectionMap[i] or nil
            local label
            if entry then
                if isSub then
                    label = string.format("%d.%d %s", entry.section, entry.subIndex or 1, step.title)
                else
                    label = string.format("%d. %s", entry.section, step.title)
                end
            else
                label = (isSub and "  - " or "") .. step.title
            end
            draw.SimpleText(label, isSub and "VEIN_TutorialIndexSub" or "VEIN_TutorialIndexMain", 9, ph * 0.5, txt, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        b.DoClick = function()
            PlayTutorialClickSound()
            GoToStep(i)
        end
        table.insert(tutorialData.ui.indexButtons, b)
        y = y + h + 4
    end
end

function VEIN.Tutorial.Open()
    if IsValid(tutorialFrame) then tutorialFrame:Remove() end

    tutorialData.currentStep = 1
    tutorialData.totalSections = CountSections()
    tutorialData.sectionMap = BuildSectionMap()
    tutorialData.visited = {}

    tutorialFrame = vgui.Create("DFrame")
    local frameW, frameH = ClampFrameSize(tutorialFrame, 1100, 720)
    tutorialFrame:Center()
    tutorialFrame:SetTitle("")
    tutorialFrame:SetDraggable(false)
    tutorialFrame:ShowCloseButton(false)
    tutorialFrame:MakePopup()

    tutorialFrame.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        draw.RoundedBoxEx(8, 0, 0, w, 66, Color(30, 30, 33, 255), true, true, false, false)
        draw.SimpleText("VEIN Tutorial", "VEIN_TutorialTitle", w * 0.5, 24, Color(126, 182, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Short and practical onboarding", "DermaDefaultBold", w * 0.5, 46, Color(185, 185, 198), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end

    local bodyY, bodyH = 76, frameH - 92
    local indexW = math.max(230, math.min(290, math.floor(frameW * 0.28)))
    local rightX = 20 + indexW + 12
    local rightW = frameW - rightX - 20

    local indexPanel = vgui.Create("DPanel", tutorialFrame)
    indexPanel:SetPos(20, bodyY)
    indexPanel:SetSize(indexW, bodyH)
    indexPanel.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(26, 26, 30, 240))
        draw.SimpleText("Index", "DermaLarge", 12, 20, Color(210, 210, 220), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end

    local indexScroll = vgui.Create("DScrollPanel", indexPanel)
    indexScroll:SetPos(8, 40)
    indexScroll:SetSize(indexW - 16, bodyH - 48)

    local contentH = bodyH - 84
    local content = vgui.Create("DPanel", tutorialFrame)
    content:SetPos(rightX, bodyY)
    content:SetSize(rightW, contentH)
    content.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(24, 24, 27, 235))
    end

    local progress = vgui.Create("DLabel", tutorialFrame)
    progress:SetPos(rightX, bodyY + contentH + 4)
    progress:SetSize(rightW, 18)
    progress:SetFont("DermaDefaultBold")
    progress:SetTextColor(Color(160, 160, 185))
    progress:SetContentAlignment(5)

    local buttons = vgui.Create("DPanel", tutorialFrame)
    buttons:SetPos(rightX, bodyY + contentH + 24)
    buttons:SetSize(rightW, 54)
    buttons.Paint = function() end

    local bw = math.min(170, math.floor((rightW - 34) / 3))
    local sp = math.max(8, math.floor((rightW - (bw * 3)) / 4))

    local prev = vgui.Create("DButton", buttons)
    prev:SetPos(sp, 10)
    prev:SetSize(bw, 34)
    prev:SetText("Previous")
    ApplyButtonStyle(prev, "secondary")
    prev.DoClick = function()
        PlayTutorialClickSound()
        VEIN.Tutorial.PreviousStep()
    end

    local skip = vgui.Create("DButton", buttons)
    skip:SetPos(sp * 2 + bw, 10)
    skip:SetSize(bw, 34)
    skip:SetText("Skip Tutorial")
    ApplyButtonStyle(skip, "danger")
    skip.DoClick = function()
        PlayTutorialClickSound()
        OpenSkipConfirm(function()
            SetTutorialSeen()
            if IsValid(tutorialFrame) then tutorialFrame:Close() end
        end)
    end

    local next = vgui.Create("DButton", buttons)
    next:SetPos(sp * 3 + bw * 2, 10)
    next:SetSize(bw, 34)
    next:SetText("Next")
    ApplyButtonStyle(next, "primary")
    next.DoClick = function()
        PlayTutorialClickSound()
        VEIN.Tutorial.NextStep()
    end

    tutorialData.ui = { content = content, progress = progress, prev = prev, next = next, indexButtons = {} }

    BuildIndex(indexScroll)
    GoToStep(1)
end

function VEIN.Tutorial.NextStep()
    if tutorialData.currentStep >= #steps then
        SetTutorialSeen()
        if IsValid(tutorialFrame) then tutorialFrame:Close() end
        return
    end
    GoToStep(tutorialData.currentStep + 1)
end

function VEIN.Tutorial.PreviousStep()
    if tutorialData.currentStep <= 1 then return end
    GoToStep(tutorialData.currentStep - 1)
end

function VEIN.Tutorial.GetFrame()
    return tutorialFrame
end

function VEIN.Tutorial.OpenGeneralSettings(tutFrame)
    if not VEIN.NewSettingsPanel or not VEIN.NewSettingsPanel.CreateGeneralControls then
        if IsValid(tutFrame) then tutFrame:SetVisible(true) end
        return
    end
    local frame = vgui.Create("DFrame")
    local w, h = ClampFrameSize(frame, 640, 540)
    frame:Center()
    frame:SetTitle("")
    frame:MakePopup()
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)

    frame.Paint = function(self, fw, fh)
        draw.RoundedBox(8, 0, 0, fw, fh, Color(22, 22, 24, 250))
        draw.RoundedBoxEx(8, 0, 0, fw, 60, Color(30, 30, 33, 255), true, true, false, false)
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, fw, fh, 2)
        draw.SimpleText("General Settings", "VEIN_TutorialTitle", fw * 0.5, 24, Color(255, 200, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("Quick defaults used by the tutorial", "DermaDefaultBold", fw * 0.5, 46, Color(180, 180, 190), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetPos(w - 44, 16)
    closeBtn:SetSize(28, 28)
    closeBtn:SetText("")
    closeBtn.Paint = function(self, bw, bh)
        local hovered = self:IsHovered()
        draw.RoundedBox(4, 0, 0, bw, bh, hovered and Color(160, 40, 40, 220) or Color(80, 20, 20, 180))
        draw.SimpleText("X", "DermaDefaultBold", bw * 0.5, bh * 0.5, Color(255, 235, 235), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    closeBtn.DoClick = function()
        PlayTutorialClickSound()
        frame:Close()
    end

    local panel = vgui.Create("DPanel", frame)
    panel:SetPos(14, 70)
    panel:SetSize(w - 28, h - 130)
    panel.Paint = function(self, pw, ph)
        draw.RoundedBox(6, 0, 0, pw, ph, Color(24, 24, 28, 235))
        surface.SetDrawColor(120, 40, 40, 100)
        surface.DrawOutlinedRect(0, 0, pw, ph, 1)
    end

    VEIN.NewSettingsPanel.CreateGeneralControls(panel)

    local close = vgui.Create("DButton", frame)
    close:SetPos(14, h - 48)
    close:SetSize(w - 28, 32)
    close:SetText("Close and Resume Tutorial")
    ApplyButtonStyle(close, "primary")
    close.DoClick = function()
        PlayTutorialClickSound()
        frame:Close()
    end
    frame.OnClose = function() if IsValid(tutFrame) then tutFrame:SetVisible(true) end end
end

function VEIN.Tutorial.CheckFirstTime(force)
    if tutorialData.autoPrompted and not force then return end
    local ply = LocalPlayer()
    if not IsValid(ply) or not ply:IsAdmin() then return end
    if HasSeenTutorial() then
        tutorialData.autoPrompted = true
        return
    end
    tutorialData.autoPrompted = true
    timer.Simple(0.6, function()
        if not IsValid(LocalPlayer()) or not LocalPlayer():IsAdmin() then return end
        if HasSeenTutorial() or IsValid(tutorialFrame) then return end
        VEIN.Tutorial.Open()
    end)
end

hook.Add("InitPostEntity", "VEIN_TutorialAutoPrompt", function()
    timer.Create("VEIN_TutorialAutoPromptTimer", 2, 8, function()
        if not IsValid(LocalPlayer()) then return end
        if LocalPlayer():IsAdmin() then
            VEIN.Tutorial.CheckFirstTime()
            timer.Remove("VEIN_TutorialAutoPromptTimer")
        end
    end)
end)

concommand.Add("vein_tutorial", function()
    if IsValid(LocalPlayer()) and LocalPlayer():IsAdmin() then
        VEIN.Tutorial.Open()
    else
        chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "Only administrators can access the tutorial.")
    end
end)

hook.Add("OnPlayerChat", "VEIN_TutorialCommand", function(ply, text)
    if ply ~= LocalPlayer() then return end
    local lower = string.lower(text or "")
    if lower ~= "!veinguide" and lower ~= "/veinguide" then return end
    if LocalPlayer():IsAdmin() then
        VEIN.Tutorial.Open()
        return true
    end
    chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "Only administrators can access the tutorial.")
end)


