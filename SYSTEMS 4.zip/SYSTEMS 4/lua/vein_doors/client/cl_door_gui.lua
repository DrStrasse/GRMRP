--[[
================================================================================
VEIN Door System - Client Side GUI and 3D Menu
================================================================================
]]--

if SERVER then return end

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.DoorSystem = VEIN.DoorSystem or {}
VEIN.DoorAdmin = VEIN.DoorAdmin or {isDoorAdmin = false, perms = {}}
VEIN.Net = VEIN.Net or {}
VEIN.DoorGUI = VEIN.DoorGUI or {}

local Net = VEIN.Net
local DoorGUI = VEIN.DoorGUI
local SMALL_CIRCLE = "\226\128\162"

local function ClampFrameSize(frame, baseW, baseH)
    local w = math.max(320, math.min(baseW, ScrW() - 80))
    local h = math.max(240, math.min(baseH, ScrH() - 80))
    frame:SetSize(w, h)
    return w, h
end

local function LocalHasDoorAdminPerm(perm)
    if not VEIN.DoorAdmin or not VEIN.DoorAdmin.isDoorAdmin then return false end
    return VEIN.DoorAdmin.perms and VEIN.DoorAdmin.perms[perm] == true
end

-- Job-controlled door hologram visibility tracking
VEIN.DoorSystem.JobDoorHolograms = VEIN.DoorSystem.JobDoorHolograms or {}
-- Structure: [doorEntIndex] = { showUntil = CurTime() + duration, alpha = 0 }

-- Helper function
local function IsValidDoor(ent)
    if not IsValid(ent) then return false end
    local class = ent:GetClass()
    return class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating"
end

-- 3D Menu System
local active3DMenu = nil
local selectedButton = 1

-- Store copied door template
VEIN.DoorSystem.CopiedTemplate = nil

-- Network receivers
net.Receive("VEIN_OpenDoorGUI", function()
    local door = net.ReadEntity()
    local copiedData = Net.ReadCopiedDoorData()
    if IsValid(door) and VEIN.DoorSystem and VEIN.DoorSystem.OpenCreateDoorGUI then
        VEIN.DoorSystem.OpenCreateDoorGUI(door, copiedData)
    end
end)

net.Receive("VEIN_OpenModifyDoorGUI", function()
    local door = net.ReadEntity()
    if IsValid(door) and VEIN.DoorSystem and VEIN.DoorSystem.OpenModifyDoorGUI then
        VEIN.DoorSystem.OpenModifyDoorGUI(door)
    end
end)

net.Receive("VEIN_DoorCopied", function()
    local copiedData = Net.ReadCopiedDoorData()
    VEIN.DoorSystem.CopiedTemplate = copiedData
    chat.AddText(Color(100, 255, 100), "[VEIN] ", Color(255, 255, 255), "Door settings copied! Middle-click on a new door to paste template.")
    surface.PlaySound("buttons/button15.wav")
end)

net.Receive("VEIN_ShowJobDoorHologram", function()
    local door = net.ReadEntity()
    if IsValid(door) then
        local entIndex = door:EntIndex()
        local existing = VEIN.DoorSystem.JobDoorHolograms[entIndex]
        
        -- Only restart animation if hologram is not currently visible or is fading out
        if not existing or existing.showUntil < CurTime() + 0.5 then
            VEIN.DoorSystem.JobDoorHolograms[entIndex] = {
                showUntil = CurTime() + 5, -- Show for 5 seconds
                alpha = 0, -- Start at 0 for fade in
                fadeInComplete = false
            }
        else
            -- If hologram is visible, just extend the duration
            existing.showUntil = CurTime() + 5
        end
    end
end)

net.Receive("VEIN_Show3DMenu", function()
    local door = net.ReadEntity()
    if IsValid(door) then
        DoorGUI.Create3DMenu(door)
    end
end)

-- Modify Door GUI (for existing doors)
function VEIN.DoorSystem.OpenModifyDoorGUI(door)
    if not IsValid(door) then return end
    
    -- Get current door settings
    local currentData = {
        name = door:GetNWString("VEIN_DoorName", ""),
        price = door:GetNWInt("VEIN_Price", 500),
        doorType = door:GetNWString("VEIN_DoorType", "Residential"),
        doorMaterial = door:GetNWString("VEIN_DoorMaterial", "Light Metal"),
        defaultLocked = door:GetNWBool("VEIN_Locked", false), -- Use current lock state, not default
        allowOwnership = door:GetNWBool("VEIN_AllowOwnership", true),
        jobControlled = door:GetNWBool("VEIN_JobControlled", false),
        controlJobs = util.JSONToTable(door:GetNWString("VEIN_ControlJobs", "[]")) or {},
        propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", ""),
        propertyCustomPrice = door:GetNWInt("VEIN_PropertyCustomPrice", 0),
        propertyGroupEnabled = door:GetNWInt("VEIN_PropertyGroup", 0) > 0 and door:GetNWString("VEIN_PropertyGroupName", "") ~= ""
    }
    
    -- Create modify frame (similar to create GUI)
    local frame = vgui.Create("DFrame")
    -- Start with taller frame to accommodate job controls + property group section
    local propertySectionHeight = 95
    local baseWidth = 500
    local baseHeight = (currentData.jobControlled and 765 or 615) + propertySectionHeight
    local frameW = math.max(360, math.min(baseWidth, ScrW() - 80))
    local frameH = math.max(420, math.min(baseHeight, ScrH() - 80))
    frame:SetSize(frameW, frameH)
    frame:Center()
    frame:SetTitle("")
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)
    frame:MakePopup()
    local window = frame
    
    frame.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 245))
        surface.SetDrawColor(120, 40, 40, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        surface.SetDrawColor(180, 60, 60, 100)
        surface.DrawRect(12, 12, w - 24, 2)
    end
    
    -- Close button
    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetPos(window:GetWide() - 40, 13)
    closeBtn:SetSize(28, 28)
    closeBtn:SetText("")
    closeBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        draw.RoundedBox(4, 0, 0, w, h, isHovered and Color(160, 40, 40, 200) or Color(80, 20, 20, 180))
        draw.SimpleText("✕", "DermaDefaultBold", w/2, h/2, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    closeBtn.DoClick = function()
        window:Close()
    end
    
    -- Title
    local title = vgui.Create("DLabel", frame)
    title:SetPos(20, 18)
    title:SetText("Modify Door Settings")
    title:SetFont("DermaLarge")
    title:SetTextColor(Color(255, 200, 200))
    title:SizeToContents()
    
    -- Door Name
    local nameLabel = vgui.Create("DLabel", frame)
    nameLabel:SetPos(15, 70)
    nameLabel:SetSize(470, 20)
    nameLabel:SetText("Door Name:")
    nameLabel:SetFont("DermaDefaultBold")
    nameLabel:SetTextColor(Color(200, 200, 205))
    
    local nameEntry = vgui.Create("DTextEntry", frame)
    nameEntry:SetPos(15, 95)
    nameEntry:SetSize(470, 30)
    nameEntry:SetValue(currentData.name)
    nameEntry:SetPlaceholderText("e.g., Police Station Entrance, Gun Shop Door")
    nameEntry.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 40, 255))
        draw.RoundedBox(4, 1, 1, w-2, h-2, Color(45, 45, 50, 255))
        self:DrawTextEntryText(Color(200, 200, 205), Color(100, 150, 255), Color(200, 200, 205))
    end
    
    -- Price
    local priceLabel = vgui.Create("DLabel", frame)
    priceLabel:SetPos(15, 130)
    priceLabel:SetSize(470, 20)
    priceLabel:SetText("Price:")
    priceLabel:SetFont("DermaDefaultBold")
    priceLabel:SetTextColor(Color(200, 200, 205))
    
    local priceEntry = vgui.Create("DNumberWang", frame)
    priceEntry:SetPos(15, 155)
    priceEntry:SetSize(200, 30)
    priceEntry:SetValue(currentData.price)
    priceEntry:SetMin(1)
    priceEntry:SetMax(2147483647)
    priceEntry.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 40, 255))
        draw.RoundedBox(4, 1, 1, w-2, h-2, Color(45, 45, 50, 255))
        self:DrawTextEntryText(Color(200, 200, 205), Color(100, 150, 255), Color(200, 200, 205))
    end
    
    -- Lock State Checkbox
    local lockCheck = vgui.Create("DCheckBoxLabel", frame)
    lockCheck:SetPos(15, 200)
    lockCheck:SetText("Lock door on server start")
    lockCheck:SetTextColor(Color(200, 200, 205))
    lockCheck:SetValue(currentData.defaultLocked)
    lockCheck:SizeToContents()
    
    -- Allow Ownership Checkbox
    local ownerCheck = vgui.Create("DCheckBoxLabel", frame)
    ownerCheck:SetPos(15, 225)
    ownerCheck:SetText("Allow player ownership (uncheck for static admin-only doors)")
    ownerCheck:SetTextColor(Color(200, 200, 205))
    ownerCheck:SetValue(currentData.allowOwnership)
    ownerCheck:SizeToContents()
    
    -- Disable ownership checkbox if job controlled is enabled
    if currentData.jobControlled then
        ownerCheck:SetEnabled(false)
    end
    
    -- Lock Name Checkbox
    local lockNameCheck = vgui.Create("DCheckBoxLabel", frame)
    lockNameCheck:SetPos(15, 250)
    lockNameCheck:SetText("Lock door name (prevent players from renaming)")
    lockNameCheck:SetTextColor(Color(200, 200, 205))
    lockNameCheck:SetValue(door:GetNWBool("VEIN_LockName", false))
    lockNameCheck:SizeToContents()
    
    -- Job Controlled Checkbox
    local jobCheck = vgui.Create("DCheckBoxLabel", frame)
    jobCheck:SetPos(15, 275)
    jobCheck:SetText("Job Controlled Door (only specific jobs can lock/unlock)")
    jobCheck:SetTextColor(Color(200, 255, 200))
    jobCheck:SetValue(currentData.jobControlled or false)
    jobCheck:SizeToContents()
    
    -- Job List Panel (initially hidden)
    local jobListPanel = vgui.Create("DPanel", frame)
    jobListPanel:SetPos(15, 300)
    jobListPanel:SetSize(470, 150)
    jobListPanel:SetVisible(currentData.jobControlled or false)
    jobListPanel.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(25, 25, 30, 200))
        draw.RoundedBox(4, 1, 1, w-2, h-2, Color(35, 35, 40, 200))
    end
    
    local jobLabel = vgui.Create("DLabel", jobListPanel)
    jobLabel:SetPos(5, 5)
    jobLabel:SetText("Select jobs that can lock/unlock this door:")
    jobLabel:SetTextColor(Color(180, 180, 185))
    jobLabel:SizeToContents()
    
    -- Job list with checkboxes
    local jobScroll = vgui.Create("DScrollPanel", jobListPanel)
    jobScroll:SetPos(5, 25)
    jobScroll:SetSize(460, 120)
    
    -- Store selected jobs
    local selectedJobs = currentData.controlJobs or {}
    
    -- Request job list from server
    local jobCheckboxes = {}
    net.Start("VEIN_RequestJobList")
    net.SendToServer()
    
    net.Receive("VEIN_JobListData", function()
        local jobs = Net.ReadJobList()
        
        for _, job in ipairs(jobs) do
            local jobPanel = vgui.Create("DPanel", jobScroll)
            jobPanel:SetSize(440, 20)
            jobPanel:Dock(TOP)
            jobPanel:DockMargin(0, 0, 0, 2)
            jobPanel.Paint = function(self, w, h)
                draw.RoundedBox(2, 0, 0, w, h, Color(45, 45, 50, 150))
            end
            
            local jobCheckBox = vgui.Create("DCheckBoxLabel", jobPanel)
            jobCheckBox:SetPos(5, 0)
            jobCheckBox:SetText(job.name)
            jobCheckBox:SetTextColor(job.color)
            jobCheckBox:SizeToContents()
            
            -- Check if this job was previously selected
            local isSelected = false
            for _, teamID in ipairs(selectedJobs) do
                if tonumber(teamID) == job.team then
                    isSelected = true
                    break
                end
            end
            jobCheckBox:SetValue(isSelected)
            
            -- Store checkbox with team ID
            table.insert(jobCheckboxes, {
                teamID = job.team,
                checkbox = jobCheckBox,
            })
        end
    end)
    
    -- Property Group (buy multiple doors together)
    local propertyGroupY = currentData.jobControlled and 465 or 315
    local propertyGroupCheck = vgui.Create("DCheckBoxLabel", frame)
    propertyGroupCheck:SetPos(15, propertyGroupY)
    propertyGroupCheck:SetText("Property Group (buy multiple doors together)")
    propertyGroupCheck:SetTextColor(Color(200, 220, 255))
    propertyGroupCheck:SetValue(currentData.propertyGroupEnabled or false)
    propertyGroupCheck:SizeToContents()
    if propertyGroupCheck.Button then
        propertyGroupCheck.Button.Paint = function(self, w, h)
            local enabled = self:IsEnabled()
            local checked = self:GetChecked()
            local bgColor = checked and Color(70, 110, 160, 200) or Color(30, 30, 35, 200)
            if not enabled then
                bgColor = Color(20, 20, 24, 200)
            end
            draw.RoundedBox(3, 0, 0, w, h, bgColor)
            local borderColor = enabled and Color(90, 120, 160, 150) or Color(60, 60, 70, 120)
            surface.SetDrawColor(borderColor)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            if checked then
                surface.SetDrawColor(Color(220, 220, 225))
                surface.DrawRect(4, 4, w - 8, h - 8)
            end
        end
    end

    local propertyGroupFields = vgui.Create("DPanel", frame)
    propertyGroupFields:SetPos(15, propertyGroupY + 25)
    propertyGroupFields:SetSize(470, 60)
    propertyGroupFields.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(25, 25, 30, 200))
        draw.RoundedBox(4, 1, 1, w - 2, h - 2, Color(35, 35, 40, 200))
    end

    local propertyNameLabel = vgui.Create("DLabel", propertyGroupFields)
    propertyNameLabel:SetPos(10, 6)
    propertyNameLabel:SetText("Group Name:")
    propertyNameLabel:SetTextColor(Color(180, 180, 185))
    propertyNameLabel:SizeToContents()

    local propertyNameEntry = vgui.Create("DTextEntry", propertyGroupFields)
    propertyNameEntry:SetPos(10, 28)
    propertyNameEntry:SetSize(170, 25)
    propertyNameEntry:SetValue(currentData.propertyGroupName or "")
    propertyNameEntry:SetPlaceholderText("Required (e.g., Lakeside House)")
    propertyNameEntry.Paint = function(self, w, h)
        local enabled = self:IsEnabled()
        local bgColor = enabled and Color(35, 35, 40, 255) or Color(25, 25, 30, 220)
        local innerColor = enabled and Color(45, 45, 50, 255) or Color(35, 35, 40, 220)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        draw.RoundedBox(4, 1, 1, w - 2, h - 2, innerColor)
        local textColor = enabled and Color(200, 200, 205) or Color(140, 140, 145)
        self:DrawTextEntryText(textColor, Color(100, 150, 255), textColor)
    end

    local propertyListButton = vgui.Create("DButton", propertyGroupFields)
    propertyListButton:SetPos(185, 28)
    propertyListButton:SetSize(85, 25)
    propertyListButton:SetText("Existing")
    propertyListButton:SetFont("DermaDefaultBold")
    propertyListButton:SetTextColor(Color(200, 200, 205))
    propertyListButton.Paint = function(self, w, h)
        local enabled = self:IsEnabled()
        local isHovered = enabled and self:IsHovered()
        local bgColor = enabled and (isHovered and Color(70, 90, 120, 200) or Color(50, 70, 90, 180)) or Color(35, 35, 40, 150)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        local borderColor = enabled and Color(90, 120, 160, 150) or Color(60, 60, 70, 120)
        surface.SetDrawColor(borderColor)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end

    local propertyPriceLabel = vgui.Create("DLabel", propertyGroupFields)
    propertyPriceLabel:SetPos(280, 6)
    propertyPriceLabel:SetText("Custom Price:")
    propertyPriceLabel:SetTextColor(Color(180, 180, 185))
    propertyPriceLabel:SizeToContents()

    local propertyPriceEntry = vgui.Create("DNumberWang", propertyGroupFields)
    propertyPriceEntry:SetPos(280, 28)
    propertyPriceEntry:SetSize(180, 25)
    propertyPriceEntry:SetMin(0)
    propertyPriceEntry:SetMax(2147483647)
    propertyPriceEntry:SetValue(currentData.propertyCustomPrice or 0)
    propertyPriceEntry.Paint = function(self, w, h)
        local enabled = self:IsEnabled()
        local bgColor = enabled and Color(35, 35, 40, 255) or Color(25, 25, 30, 220)
        local innerColor = enabled and Color(45, 45, 50, 255) or Color(35, 35, 40, 220)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        draw.RoundedBox(4, 1, 1, w - 2, h - 2, innerColor)
        local textColor = enabled and Color(200, 200, 205) or Color(140, 140, 145)
        self:DrawTextEntryText(textColor, Color(100, 150, 255), textColor)
    end

    local propertyPriceAutoSetting = false
    local propertyPriceAutoFromSum = false
    local propertyPriceAutoActive = false
    local propertyPriceManualOverride = false

    local function CollectPropertyGroupNames()
        local names = {}
        local list = {}
        for _, ent in ipairs(ents.GetAll()) do
            if IsValid(ent) then
                local name = ent:GetNWString("VEIN_PropertyGroupName", "")
                if name ~= "" and not names[name] then
                    names[name] = true
                    table.insert(list, name)
                end
            end
        end
        table.sort(list)
        return list
    end

    local function GetPropertyGroupInfoByName(name)
        name = string.Trim(name or "")
        if name == "" then return nil end
        for _, ent in ipairs(ents.GetAll()) do
            if IsValid(ent) then
                local entName = ent:GetNWString("VEIN_PropertyGroupName", "")
                if entName ~= "" and entName == name then
                    local customPrice = ent:GetNWInt("VEIN_PropertyCustomPrice", 0)
                    local totalPrice = ent:GetNWInt("VEIN_PropertyTotalPrice", ent:GetNWInt("VEIN_Price", 0))
                    return {customPrice = customPrice, totalPrice = totalPrice}
                end
            end
        end
        return nil
    end

    local function AutoFillPropertyPrice(name)
        local info = GetPropertyGroupInfoByName(name)
        if not info then return false end
        local value = info.customPrice > 0 and info.customPrice or info.totalPrice
        propertyPriceAutoSetting = true
        propertyPriceEntry:SetValue(value)
        propertyPriceAutoSetting = false
        propertyPriceAutoFromSum = info.customPrice <= 0
        propertyPriceAutoActive = true
        propertyPriceManualOverride = false
        return true
    end

    propertyListButton.DoClick = function()
        local names = CollectPropertyGroupNames()
        local menu = DermaMenu()
        if #names == 0 then
            local option = menu:AddOption("No properties found")
            option:SetEnabled(false)
        else
            for _, name in ipairs(names) do
                menu:AddOption(name, function()
                    if IsValid(propertyNameEntry) then
                        propertyNameEntry:SetValue(name)
                        AutoFillPropertyPrice(name)
                    end
                end)
            end
        end
        menu:Open()
    end

    propertyNameEntry.OnChange = function(self)
        if not propertyGroupCheck:GetChecked() then return end
        local name = string.Trim(self:GetValue() or "")
        if AutoFillPropertyPrice(name) then return end
        if propertyPriceAutoActive and not propertyPriceManualOverride then
            propertyPriceAutoSetting = true
            propertyPriceEntry:SetValue(0)
            propertyPriceAutoSetting = false
        end
        propertyPriceAutoFromSum = false
        propertyPriceAutoActive = false
        propertyPriceManualOverride = false
    end

    propertyPriceEntry.OnValueChanged = function(self, value)
        if propertyPriceAutoSetting then return end
        propertyPriceManualOverride = true
        propertyPriceAutoFromSum = false
        propertyPriceAutoActive = false
    end

    local propertyGroupUpdateLock = false

    local function SetPropertyGroupChecked(value)
        if propertyGroupCheck:GetChecked() == value then return end
        propertyGroupUpdateLock = true
        propertyGroupCheck:SetValue(value)
        propertyGroupUpdateLock = false
    end

    local function UpdatePropertyGroupControls()
        local canUse = ownerCheck:GetChecked() and not jobCheck:GetChecked()
        propertyGroupCheck:SetEnabled(canUse)
        if not canUse then
            SetPropertyGroupChecked(false)
        end
        local enableFields = canUse and propertyGroupCheck:GetChecked()
        propertyNameEntry:SetEnabled(enableFields)
        propertyPriceEntry:SetEnabled(enableFields)
        propertyListButton:SetEnabled(enableFields)
        local labelColor = enableFields and Color(180, 180, 185) or Color(100, 100, 110)
        propertyNameLabel:SetTextColor(labelColor)
        propertyPriceLabel:SetTextColor(labelColor)
        propertyNameLabel:SetEnabled(enableFields)
        propertyPriceLabel:SetEnabled(enableFields)
        propertyListButton:SetTextColor(enableFields and Color(200, 200, 205) or Color(120, 120, 130))

        if enableFields then
            local name = string.Trim(propertyNameEntry:GetValue() or "")
            AutoFillPropertyPrice(name)
        end
    end

    propertyGroupCheck.OnChange = function()
        if propertyGroupUpdateLock then return end
        UpdatePropertyGroupControls()
    end
    ownerCheck.OnChange = function()
        UpdatePropertyGroupControls()
    end

    UpdatePropertyGroupControls()

    -- Door Type (position will be adjusted by job control toggle)
    local typeLabel = vgui.Create("DLabel", frame)
    local startY = propertyGroupY + propertySectionHeight
    typeLabel:SetPos(15, startY)
    typeLabel:SetSize(230, 20)
    typeLabel:SetText("Door Type:")
    typeLabel:SetFont("DermaDefaultBold")
    typeLabel:SetTextColor(Color(200, 200, 205))
    
    local typeCombo = vgui.Create("DComboBox", frame)
    typeCombo:SetPos(15, startY + 25)
    typeCombo:SetSize(230, 30)
    -- Store type colors for lookup
    local typeColors = {}
    
    -- Add all door types (default + custom already combined by server)
    if VEIN.CustomDoors and VEIN.CustomDoors.Types then
        for _, typeData in ipairs(VEIN.CustomDoors.Types) do
            typeCombo:AddChoice(typeData.name)
            -- Store a NEW color object to avoid reference issues
            typeColors[typeData.name] = Color(typeData.color.r, typeData.color.g, typeData.color.b)
        end
    end
    
    -- Custom paint to show selected type in its color
    typeCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 40, 255))
        draw.RoundedBox(4, 1, 1, w-2, h-2, Color(45, 45, 50, 255))
        
        -- Apply text color dynamically based on current selection
        local currentValue = self:GetValue()
        local col = typeColors[currentValue]
        if col then
            self:SetTextColor(col)
        end
    end
    
    typeCombo.OnSelect = function(self, index, value)
        -- OnSelect kept for potential future use, Paint handles the color
    end
    
    -- Set value AFTER defining OnSelect
    typeCombo:SetValue(currentData.doorType)
    
    -- Set initial color using the typeColors table
    timer.Simple(0.01, function()
        if IsValid(typeCombo) then
            local currentValue = typeCombo:GetValue()
            local col = typeColors[currentValue]
            if col then
                typeCombo:SetTextColor(col)
            end
        end
    end)
    
    -- Door Material (position will be adjusted by OnChange)
    local materialLabel = vgui.Create("DLabel", frame)
    materialLabel:SetPos(255, startY)
    materialLabel:SetSize(230, 20)
    materialLabel:SetText("Door Material:")
    materialLabel:SetFont("DermaDefaultBold")
    materialLabel:SetTextColor(Color(200, 200, 205))
    
    local materialCombo = vgui.Create("DComboBox", frame)
    materialCombo:SetPos(255, startY + 25)
    materialCombo:SetSize(230, 30)
    materialCombo:SetValue(currentData.doorMaterial)
    
    -- Add all door materials (default + custom already combined by server)
    if VEIN.CustomDoors and VEIN.CustomDoors.Materials then
        for _, matData in ipairs(VEIN.CustomDoors.Materials) do
            materialCombo:AddChoice(matData.name)
        end
    end
    
    -- Custom paint for material dropdown
    materialCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 40, 255))
        draw.RoundedBox(4, 1, 1, w-2, h-2, Color(45, 45, 50, 255))
    end
    materialCombo:SetTextColor(Color(200, 200, 205))
    
    -- Save Changes Button (position will be adjusted by OnChange)
    local saveBtn = vgui.Create("DButton", frame)
    local btnY = (currentData.jobControlled and 560 or 410) + propertySectionHeight
    saveBtn:SetPos(15, btnY)
    saveBtn:SetSize(200, 35)
    saveBtn:SetText("Save Changes")
    saveBtn:SetFont("DermaDefaultBold")
    saveBtn:SetTextColor(Color(255, 255, 255))
    saveBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 120, 60, 255) or Color(40, 100, 40, 255)
        draw.RoundedBox(6, 0, 0, w, h, col)
        surface.SetDrawColor(80, 160, 80, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end
    saveBtn.DoClick = function()
        local doorName = nameEntry:GetValue()
        -- Name is optional, empty is allowed
        
        local price = priceEntry:GetValue()
        local isLocked = lockCheck:GetChecked()
        local allowOwnership = ownerCheck:GetChecked()
        local lockName = lockNameCheck:GetChecked()
        local doorType = typeCombo:GetValue()
        local doorMaterial = materialCombo:GetValue()
        local jobControlled = jobCheck:GetChecked()
        local usePropertyGroup = propertyGroupCheck:GetChecked()
        local propertyGroupName = usePropertyGroup and string.Trim(propertyNameEntry:GetValue() or "") or ""
        local propertyCustomPrice = usePropertyGroup and propertyPriceEntry:GetValue() or 0
        if usePropertyGroup and propertyPriceAutoFromSum and not propertyPriceManualOverride then
            propertyCustomPrice = 0
        end
        
        -- Collect selected jobs
        local controlJobs = {}
        if jobCheckboxes then
            for _, entry in ipairs(jobCheckboxes) do
                if entry.checkbox:GetChecked() then
                    table.insert(controlJobs, entry.teamID)
                end
            end
        end
        
        -- Validate: If job controlled is enabled, at least one job must be selected
        if jobControlled and #controlJobs == 0 then
            chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "You must select at least one job for job-controlled doors!")
            surface.PlaySound("buttons/button10.wav")
            return
        end
        if usePropertyGroup and propertyGroupName == "" then
            chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "Property group name is required!")
            surface.PlaySound("buttons/button10.wav")
            return
        end
        
        net.Start("VEIN_ModifyDoor")
        net.WriteEntity(door)
        net.WriteString(doorName)
        net.WriteInt(price, 32)
        net.WriteBool(isLocked)
        net.WriteString(doorType)
        net.WriteString(doorMaterial)
        net.WriteBool(allowOwnership)
        net.WriteBool(lockName)
        net.WriteBool(jobControlled)
        Net.WriteTeamList(controlJobs)
        net.WriteString(propertyGroupName)
        net.WriteInt(propertyCustomPrice, 32)
        net.SendToServer()
        
        window:Close()
        chat.AddText(Color(100, 255, 100), "[VEIN] ", Color(255, 255, 255), "Door updated!")
    end
    
    -- Remove Door Button (position will be adjusted by OnChange)
    local removeBtn = vgui.Create("DButton", frame)
    removeBtn:SetPos(225, btnY)
    removeBtn:SetSize(260, 35)
    removeBtn:SetText("Remove Door")
    removeBtn:SetFont("DermaDefaultBold")
    removeBtn:SetTextColor(Color(255, 255, 255))
    removeBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(140, 40, 40, 255) or Color(100, 30, 30, 255)
        draw.RoundedBox(6, 0, 0, w, h, col)
        surface.SetDrawColor(180, 60, 60, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
    end
    removeBtn.DoClick = function()
        -- Keep mouse enabled when switching GUIs
        gui.EnableScreenClicker(true)
        timer.Simple(0, function()
            window:Close()
            -- Open remove confirmation dialog
            net.Start("VEIN_OpenRemoveConfirm")
            net.WriteEntity(door)
            net.SendToServer()
        end)
    end

    -- Door Group/Jobs Editor Button
    local groupBtn = vgui.Create("DButton", frame)
    groupBtn:SetPos(15, btnY + 45)
    groupBtn:SetSize(470, 35)
    groupBtn:SetText("Edit Door Group/Jobs")
    groupBtn:SetFont("DermaDefaultBold")
    groupBtn:SetTextColor(Color(200, 220, 255))
    groupBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(50, 80, 120, 220) or Color(40, 70, 100, 200)
        draw.RoundedBox(6, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(120, 180, 255, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
        surface.SetDrawColor(90, 140, 200, isHovered and 180 or 140)
        surface.DrawRect(0, 0, 4, h)
    end
    groupBtn.DoClick = function()
        if VEIN.DoorGroups and VEIN.DoorGroups.OpenEditor then
            window:Close()
            VEIN.DoorGroups.OpenEditor(door)
        else
            chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "Door group system not loaded!")
        end
    end
    
    -- Handle job checkbox toggle (AFTER all elements are created)
    if jobCheck then
        jobCheck.OnChange = function(self, val)
            if jobListPanel then
                jobListPanel:SetVisible(val)
            end
            
            -- If job controlled is enabled, disable ownership checkbox
            if val then
                ownerCheck:SetValue(false)
                ownerCheck:SetEnabled(false)
            else
                ownerCheck:SetEnabled(true)
                ownerCheck:SetValue(true)  -- Re-enable ownership when disabling job control
            end
            
            -- Adjust frame height and positions based on visibility
            local propertyGroupY = val and 465 or 315
            propertyGroupCheck:SetPos(15, propertyGroupY)
            propertyGroupFields:SetPos(15, propertyGroupY + 25)

            local typeStartY = propertyGroupY + propertySectionHeight

            if val then
                window:SetTall(math.min(765 + propertySectionHeight, ScrH() - 80))
                typeLabel:SetPos(15, typeStartY)
                typeCombo:SetPos(15, typeStartY + 25)
                materialLabel:SetPos(255, typeStartY)
                materialCombo:SetPos(255, typeStartY + 25)
                saveBtn:SetPos(15, 560 + propertySectionHeight)
                removeBtn:SetPos(225, 560 + propertySectionHeight)
                groupBtn:SetPos(15, 605 + propertySectionHeight)
            else
                window:SetTall(math.min(615 + propertySectionHeight, ScrH() - 80))
                typeLabel:SetPos(15, typeStartY)
                typeCombo:SetPos(15, typeStartY + 25)
                materialLabel:SetPos(255, typeStartY)
                materialCombo:SetPos(255, typeStartY + 25)
                saveBtn:SetPos(15, 410 + propertySectionHeight)
                removeBtn:SetPos(225, 410 + propertySectionHeight)
                groupBtn:SetPos(15, 455 + propertySectionHeight)
            end

            UpdatePropertyGroupControls()
        end
    end
end

-- Create Screen GUI for owned doors
DoorGUI.Create3DMenu = function(door)
    if not IsValid(door) then return end
    
    local owner = door:GetNWString("VEIN_OwnerName", "")
    local isOwner = (owner == LocalPlayer():Nick())
    local allowOwnership = door:GetNWBool("VEIN_AllowOwnership", true)
    local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
    local isStaticDoor = (not allowOwnership) and (not isJobControlled)
    local isAdmin = LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin()
    
    -- Check access level permissions
    local myNick = LocalPlayer():Nick()
    local canManagePermissions = false
    local canRenameDoor = false
    local canSellDoor = false
    
    if VEIN and VEIN.AccessLevels then
        canManagePermissions = VEIN.AccessLevels.CanManagePermissions(door, myNick)
        canRenameDoor = VEIN.AccessLevels.CanRenameDoor(door, myNick)
        canSellDoor = VEIN.AccessLevels.CanSellDoor(door, myNick)
    else
        -- Fallback to old system if access levels not loaded
        canManagePermissions = isOwner
        canRenameDoor = isOwner
        canSellDoor = isOwner
    end
    
    -- Create modern styled GUI
    local frame = vgui.Create("DFrame")
    local frameW, frameH = ClampFrameSize(frame, 350, 315)  -- Made taller for repair button
    frame:Center()
    frame:SetTitle("")
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)
    frame:MakePopup()
    
    -- Q key to close menu
    frame.OnKeyCodePressed = function(self, keyCode)
        if keyCode == KEY_Q then
            self:Close()
            return true
        end
        return false
    end
    
    -- DARK MINIMALISTIC DESIGN
    frame.Paint = function(self, w, h)
        -- Dark background
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 245))
        
        -- Subtle red accent border
        surface.SetDrawColor(120, 40, 40, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        
        -- Minimal top accent line
        surface.SetDrawColor(180, 60, 60, 100)
        surface.DrawRect(12, 12, w - 24, 2)
        
        -- Bottom shadow for depth
        surface.SetDrawColor(12, 12, 14, 120)
        draw.RoundedBox(0, 2, h - 6, w - 4, 6, Color(12, 12, 14, 120))
    end
    
    -- MINIMALISTIC CLOSE BUTTON
    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetPos(frameW - 40, 13)
    closeBtn:SetSize(28, 28)
    closeBtn:SetText("")
    closeBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local isPressed = self:IsDown()
        
        -- Simple dark background
        local bgColor = isPressed and Color(180, 60, 60, 200) or (isHovered and Color(140, 50, 50, 150) or Color(40, 40, 42, 120))
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        
        -- Red border on hover
        if isHovered then
            surface.SetDrawColor(180, 60, 60, 200)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        -- Clean X symbol
        local centerX, centerY = w/2, h/2
        local size = 6
        local lineColor = isHovered and Color(255, 200, 200, 255) or Color(180, 180, 185, 200)
        
        surface.SetDrawColor(lineColor)
        surface.DrawLine(centerX - size, centerY - size, centerX + size, centerY + size)
        surface.DrawLine(centerX + size, centerY - size, centerX - size, centerY + size)
    end
    closeBtn.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        frame:Close()
    end
    
    -- Clean Title
    local doorName = door:GetNWString("VEIN_DoorName", "")
    local title
    
    if isJobControlled then
        title = doorName ~= "" and doorName or "Job-Controlled Door"
    elseif isStaticDoor then
        title = "[ADMIN] Static Door"
    else
        title = doorName ~= "" and doorName or (owner .. "'s Door")
    end
    
    local titleLabel = vgui.Create("DLabel", frame)
    titleLabel:SetPos(15, 20)
    titleLabel:SetSize(300, 30)
    titleLabel:SetText(title)
    titleLabel:SetFont("DermaLarge")
    titleLabel:SetTextColor(isJobControlled and Color(150, 255, 150) or (isStaticDoor and Color(200, 200, 255) or Color(220, 220, 225)))
    titleLabel:SetContentAlignment(4) -- Left aligned
    
    -- Lock status with red accent (or broken status)
    local isLocked = door:GetNWBool("VEIN_Locked", false)
    local isBroken = door:GetNWBool("VEIN_Broken", false)
    
    local statusText, statusColor
    if isJobControlled then
        statusText = "JOB CONTROLLED"
        statusColor = Color(150, 255, 150)
    elseif isStaticDoor then
        statusText = "NOT PURCHASABLE"
        statusColor = Color(180, 180, 220)
    elseif isBroken then
        statusText = "BROKEN"
        statusColor = Color(200, 200, 80) -- Yellow color for broken
    else
        statusText = isLocked and "LOCKED" or "UNLOCKED"
        statusColor = isLocked and Color(200, 80, 80) or Color(120, 180, 120)
    end
    
    local statusLabel = vgui.Create("DLabel", frame)
    statusLabel:SetPos(15, 48)
    statusLabel:SetSize(300, 18)
    statusLabel:SetText(statusText)
    statusLabel:SetFont("DermaDefaultBold")
    statusLabel:SetTextColor(statusColor)
    statusLabel:SetContentAlignment(4) -- Left aligned
    
    -- Minimal separator line with red accent
    local separator = vgui.Create("DPanel", frame)
    separator:SetPos(15, 75)
    separator:SetSize(320, 1)
    separator.Paint = function(self, w, h)
        surface.SetDrawColor(120, 40, 40, 80)
        surface.DrawRect(0, 0, w, h)
    end
    
    -- Clean instructions
    local instructLabel = vgui.Create("DLabel", frame)
    instructLabel:SetPos(0, 85)
    instructLabel:SetSize(350, 18)
    instructLabel:SetText("Use left-click with Keys to lock/unlock")
    instructLabel:SetFont("DermaDefault")
    instructLabel:SetTextColor(Color(160, 160, 165))
    instructLabel:SetContentAlignment(5)
    
    local yPos = 115
    
    -- Check if door name is locked
    local nameLocked = door:GetNWBool("VEIN_LockName", false)
    
    -- MINIMALISTIC NAME CHANGE BUTTON (use new permission system)
    if canRenameDoor and not nameLocked then
        local nameBtn = vgui.Create("DButton", frame)
        nameBtn:SetPos(25, yPos)
        nameBtn:SetSize(300, 35)
        nameBtn:SetText("Change Door Name")
        nameBtn:SetFont("DermaDefaultBold")
        nameBtn:SetTextColor(Color(200, 200, 205))
        nameBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local isPressed = self:IsDown()
            
            -- Dark background
            local bgColor = isPressed and Color(45, 45, 48, 220) or (isHovered and Color(40, 40, 43, 200) or Color(35, 35, 38, 180))
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            
            -- Red accent border on hover
            if isHovered then
                surface.SetDrawColor(140, 60, 60, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            
            -- Subtle red left accent
            surface.SetDrawColor(120, 50, 50, isHovered and 120 or 80)
            surface.DrawRect(0, 0, 3, h)
        end
        nameBtn.DoClick = function()
            surface.PlaySound("buttons/button9.wav")
            frame:Close()
            DoorGUI.OpenChangeNameGUI(door)
        end
        yPos = yPos + 45
    end
    
    -- MINIMALISTIC PERMISSIONS BUTTON (use new permission system)
    if canManagePermissions then
        local permBtn = vgui.Create("DButton", frame)
        permBtn:SetPos(25, yPos)
        permBtn:SetSize(300, 35)
        permBtn:SetText("Manage Permissions")
        permBtn:SetFont("DermaDefaultBold")
        permBtn:SetTextColor(Color(200, 200, 205))
        permBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local isPressed = self:IsDown()
            
            -- Dark background
            local bgColor = isPressed and Color(45, 45, 48, 220) or (isHovered and Color(40, 40, 43, 200) or Color(35, 35, 38, 180))
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            
            -- Red accent border on hover
            if isHovered then
                surface.SetDrawColor(140, 60, 60, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            
            -- Subtle red left accent
            surface.SetDrawColor(120, 50, 50, isHovered and 120 or 80)
            surface.DrawRect(0, 0, 3, h)
        end
        permBtn.DoClick = function()
            surface.PlaySound("buttons/button15.wav")
            frame:Close()
            DoorGUI.OpenPermissionsGUI(door)
        end
        yPos = yPos + 45
        
        -- REPAIR BUTTON (only if door is broken and player can sell)
        if door:GetNWBool("VEIN_Broken", false) and canSellDoor then
            local repairBtn = vgui.Create("DButton", frame)
            repairBtn:SetPos(25, yPos)
            repairBtn:SetSize(300, 35)
            local doorPrice = door:GetNWInt("VEIN_Price", 500)
            local repairCost = math.floor(doorPrice * 0.1)
            repairBtn:SetText("✘ Repair Door ($" .. string.Comma(repairCost) .. ")")
            repairBtn:SetFont("DermaDefaultBold")
            repairBtn:SetTextColor(Color(200, 200, 205))
            repairBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                local isPressed = self:IsDown()
                
                -- Orange repair accent
                local bgColor = isPressed and Color(60, 45, 25, 220) or (isHovered and Color(50, 40, 20, 200) or Color(45, 35, 15, 180))
                draw.RoundedBox(6, 0, 0, w, h, bgColor)
                
                -- Orange border on hover
                if isHovered then
                    surface.SetDrawColor(180, 120, 60, 150)
                    surface.DrawOutlinedRect(0, 0, w, h, 1)
                end
                
                -- Orange left accent
                surface.SetDrawColor(160, 100, 40, isHovered and 140 or 100)
                surface.DrawRect(0, 0, 3, h)
            end
            repairBtn.DoClick = function()
                surface.PlaySound("buttons/button9.wav")
                frame:Close()
                net.Start("VEIN_RepairDoor")
                net.WriteEntity(door)
                net.SendToServer()
            end
            yPos = yPos + 45
        end
    end
    
    -- MINIMALISTIC SELL BUTTON (use new permission system)
    if canSellDoor then
        local sellBtn = vgui.Create("DButton", frame)
        sellBtn:SetPos(25, yPos)
        sellBtn:SetSize(300, 35)
        local refundPercent = GetConVar("vein_door_refund_percent") and GetConVar("vein_door_refund_percent"):GetInt() or 50
        sellBtn:SetText("Sell Door (" .. refundPercent .. "% refund)")
        sellBtn:SetFont("DermaDefaultBold")
        sellBtn:SetTextColor(Color(200, 200, 205))
        sellBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local isPressed = self:IsDown()
            
            -- Dark background with danger accent
            local bgColor = isPressed and Color(60, 35, 35, 220) or (isHovered and Color(50, 30, 30, 200) or Color(40, 25, 25, 180))
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            
            -- Danger red border on hover
            if isHovered then
                surface.SetDrawColor(180, 80, 80, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            
            -- Red left accent (stronger for danger)
            surface.SetDrawColor(160, 60, 60, isHovered and 140 or 100)
            surface.DrawRect(0, 0, 3, h)
        end
        sellBtn.DoClick = function()
            surface.PlaySound("buttons/button10.wav")
            frame:Close()
            local refundPercent = GetConVar("vein_door_refund_percent") and GetConVar("vein_door_refund_percent"):GetInt() or 50
            Derma_Query("Are you sure you want to sell this door? You'll get " .. refundPercent .. "% of the original price back.",
                "Sell Door",
                "Yes, Sell", function()
                    net.Start("VEIN_SellDoor")
                    net.WriteEntity(door)
                    net.SendToServer()
                end,
                "Cancel", function() end)
        end
        yPos = yPos + 45
    end
    
    -- ADMIN / DOOR ADMIN BUTTONS
    local isRealAdmin = LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin()
    local canForceSell = isRealAdmin or LocalHasDoorAdminPerm("adminForceSellDoor")
    local canEditGroups = isRealAdmin or LocalHasDoorAdminPerm("adminEditGroupsDoor")

    if canForceSell or canEditGroups then
        if canForceSell then
            -- ADMIN FORCE SELL BUTTON
            local adminForceSellBtn = vgui.Create("DButton", frame)
            adminForceSellBtn:SetPos(25, yPos)
            adminForceSellBtn:SetSize(300, 35)
            adminForceSellBtn:SetText("[ADMIN] Force Sell Door")
            adminForceSellBtn:SetFont("DermaDefaultBold")
            adminForceSellBtn:SetTextColor(Color(255, 220, 180))
            adminForceSellBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                local isPressed = self:IsDown()
                
                -- Red admin background
                local bgColor = isPressed and Color(80, 30, 30, 240) or (isHovered and Color(70, 25, 25, 220) or Color(60, 20, 20, 200))
                draw.RoundedBox(6, 0, 0, w, h, bgColor)
                
                -- Orange admin border on hover
                if isHovered then
                    surface.SetDrawColor(255, 140, 60, 180)
                    surface.DrawOutlinedRect(0, 0, w, h, 2)
                end
                
                -- Orange left admin accent (thicker)
                surface.SetDrawColor(255, 120, 40, isHovered and 200 or 160)
                surface.DrawRect(0, 0, 5, h)
            end
            adminForceSellBtn.DoClick = function()
                surface.PlaySound("buttons/button10.wav")
                frame:Close()
                frame:Close() -- Close menu first
                Derma_Query("ADMIN: Force sell this door? Owner will get 100% refund and door will be available for purchase again.",
                    "Admin Force Sell",
                    "Yes, Force Sell", function()
                        -- Use admin force sell network message
                        net.Start("VEIN_AdminForceSell")
                        net.WriteEntity(door)
                        net.SendToServer()
                    end,
                    "Cancel", function() end)
            end
            yPos = yPos + 45
        end

        if canEditGroups then
            -- ADMIN EDIT DOOR PROPERTIES BUTTON
            local adminEditBtn = vgui.Create("DButton", frame)
            adminEditBtn:SetPos(25, yPos)
            adminEditBtn:SetSize(300, 35)
            adminEditBtn:SetText("[ADMIN] Edit Door Properties")
            adminEditBtn:SetFont("DermaDefaultBold")
            adminEditBtn:SetTextColor(Color(180, 220, 255))
            adminEditBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                local isPressed = self:IsDown()
                
                -- Blue admin background
                local bgColor = isPressed and Color(30, 50, 80, 240) or (isHovered and Color(25, 45, 70, 220) or Color(20, 40, 60, 200))
                draw.RoundedBox(6, 0, 0, w, h, bgColor)
                
                -- Blue admin border on hover
                if isHovered then
                    surface.SetDrawColor(100, 160, 255, 180)
                    surface.DrawOutlinedRect(0, 0, w, h, 2)
                end
                
                -- Blue left admin accent (thicker)
                surface.SetDrawColor(80, 140, 255, isHovered and 200 or 160)
                surface.DrawRect(0, 0, 5, h)
            end
            adminEditBtn.DoClick = function()
                surface.PlaySound("buttons/button9.wav")
                frame:Close()
                -- Open VEIN door group editor
                if VEIN.DoorGroups and VEIN.DoorGroups.OpenEditor then
                    VEIN.DoorGroups.OpenEditor(door)
                else
                    chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "Door group system not loaded!")
                end
            end
            yPos = yPos + 45
        end
    end
    
    -- Adjust frame height based on final yPos
    frame:SetTall(math.max(315, yPos + 30))
    
    local isDoorAdmin = VEIN.DoorAdmin and VEIN.DoorAdmin.isDoorAdmin
    if not isOwner and not (LocalPlayer():IsAdmin() or LocalPlayer():IsSuperAdmin() or isDoorAdmin) then
        -- Stylish access info for non-owners who aren't admins
        local accessPanel = vgui.Create("DPanel", frame)
        accessPanel:SetPos(25, yPos)
        accessPanel:SetSize(300, 60)
        accessPanel.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(50, 80, 50, 120))
            surface.SetDrawColor(100, 150, 100, 80)
            surface.DrawOutlinedRect(0, 0, w, h)
        end
        
        local accessLabel = vgui.Create("DLabel", accessPanel)
        accessLabel:SetPos(0, 10)
        accessLabel:SetSize(300, 40)
        accessLabel:SetText("♦ You have access to this door\n   Use left-click with Keys to lock/unlock")
        accessLabel:SetFont("DermaDefault")
        accessLabel:SetTextColor(Color(180, 220, 180))
        accessLabel:SetContentAlignment(5)
    end
    
    -- Close when clicking outside or pressing ESC
    frame.OnFocusChanged = function(self, gained)
        if not gained then
            timer.Simple(0.1, function()
                if IsValid(frame) then frame:Close() end
            end)
        end
    end
end

-- Screen GUI handles everything now, no need for 3D menu functions

local function GetDoorDisplayNameForPermissions(door)
    if not IsValid(door) then return "Unknown Door" end
    local name = string.Trim(door:GetNWString("VEIN_DoorName", ""))
    if name ~= "" then
        return name
    end
    return "Door #" .. door:EntIndex()
end

local function GetConnectedDoorsForPermissions(door)
    if not IsValid(door) then return {} end

    local connected = {}
    local seen = {}

    local function addDoor(ent)
        if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) and not seen[ent] then
            seen[ent] = true
            table.insert(connected, ent)
        end
    end

    addDoor(door)

    local propertyGroupId = door:GetNWInt("VEIN_PropertyGroup", 0)
    local propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", "")
    if propertyGroupId > 0 and propertyGroupName ~= "" then
        for _, ent in ipairs(ents.GetAll()) do
            if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false)
                and ent:GetNWInt("VEIN_PropertyGroup", 0) == propertyGroupId
                and ent:GetNWString("VEIN_PropertyGroupName", "") == propertyGroupName then
                addDoor(ent)
            end
        end
    end

    if #connected <= 1 then
        local linkGroupId = door:GetNWInt("VEIN_LinkGroup", 0)
        if linkGroupId > 0 then
            for _, ent in ipairs(ents.GetAll()) do
                if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) and ent:GetNWInt("VEIN_LinkGroup", 0) == linkGroupId then
                    addDoor(ent)
                end
            end
        else
            local legacyLinkedDoor = door:GetNWEntity("VEIN_LinkedDoor", NULL)
            if IsValid(legacyLinkedDoor) then
                addDoor(legacyLinkedDoor)
            end
        end
    end

    table.sort(connected, function(a, b)
        return a:EntIndex() < b:EntIndex()
    end)

    return connected
end

local function GetConnectedDoorsWithAccess(door, targetKey, targetName)
    local result = {}

    for _, connectedDoor in ipairs(GetConnectedDoorsForPermissions(door)) do
        local resolvedKey
        if VEIN.AccessLevels.ResolveAccessEntry then
            resolvedKey = select(1, VEIN.AccessLevels.ResolveAccessEntry(connectedDoor, targetKey, targetName))
        end
        if resolvedKey then
            table.insert(result, connectedDoor)
        end
    end

    return result
end

local function OpenRemoveAccessDialog(door, member, parentFrame)
    if not IsValid(door) or not member then return end

    local affectedDoors = GetConnectedDoorsWithAccess(door, member.key, member.nick)
    local canSync = #affectedDoors > 1
    local baseW = 520
    local baseH = canSync and 420 or 280

    local frame = vgui.Create("DFrame")
    local frameW, frameH = ClampFrameSize(frame, baseW, baseH)
    frame:Center()
    frame:SetTitle("")
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)
    frame:MakePopup()

    frame.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        surface.SetDrawColor(180, 60, 60, 120)
        surface.DrawRect(12, 12, w - 24, 2)
    end

    local title = vgui.Create("DLabel", frame)
    title:SetPos(20, 18)
    title:SetSize(frameW - 40, 26)
    title:SetText("Remove Access")
    title:SetFont("DermaLarge")
    title:SetTextColor(Color(220, 220, 225))

    local question = vgui.Create("DLabel", frame)
    question:SetPos(20, 55)
    question:SetSize(frameW - 40, 38)
    question:SetText("Remove " .. member.nick .. "'s access from this door?")
    question:SetFont("DermaDefaultBold")
    question:SetTextColor(Color(210, 210, 215))

    local syncCheck
    local affectedInfoY = 100
    if canSync then
        syncCheck = vgui.Create("DCheckBoxLabel", frame)
        syncCheck:SetPos(20, 95)
        syncCheck:SetText("Sync with connected doors (" .. #affectedDoors .. " total)")
        syncCheck:SetTextColor(Color(200, 200, 205))
        syncCheck:SetValue(false)
        syncCheck:SizeToContents()

        affectedInfoY = 130
        local affectedTitle = vgui.Create("DLabel", frame)
        affectedTitle:SetPos(20, affectedInfoY)
        affectedTitle:SetSize(frameW - 40, 20)
        affectedTitle:SetText("Connected doors that currently grant access:")
        affectedTitle:SetFont("DermaDefaultBold")
        affectedTitle:SetTextColor(Color(180, 180, 185))

        local lineY = affectedInfoY + 24
        for _, affectedDoor in ipairs(affectedDoors) do
            local line = vgui.Create("DLabel", frame)
            line:SetPos(28, lineY)
            line:SetSize(frameW - 56, 18)
            line:SetText(SMALL_CIRCLE .. " " .. GetDoorDisplayNameForPermissions(affectedDoor))
            line:SetFont("DermaDefault")
            line:SetTextColor(Color(170, 170, 175))
            lineY = lineY + 18
        end
    end

    local buttonY = frameH - 52
    local buttonW = math.floor((frameW - 50) / 2)

    local confirmBtn = vgui.Create("DButton", frame)
    confirmBtn:SetPos(20, buttonY)
    confirmBtn:SetSize(buttonW, 34)
    confirmBtn:SetText("Remove")
    confirmBtn:SetFont("DermaDefaultBold")
    confirmBtn:SetTextColor(Color(200, 200, 205))
    confirmBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(140, 40, 40, 220) or Color(100, 30, 30, 190)
        draw.RoundedBox(6, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(180, 60, 60, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
    end
    confirmBtn.DoClick = function()
        local syncConnected = IsValid(syncCheck) and syncCheck:GetChecked() or false
        net.Start("VEIN_AL_RemoveAccess")
        net.WriteEntity(door)
        net.WriteString(member.key or member.nick or "")
        net.WriteString(member.nick or "")
        net.WriteString(member.steamID or "")
        net.WriteString(member.steamID64 or "")
        net.WriteBool(syncConnected)
        net.SendToServer()

        surface.PlaySound("buttons/button10.wav")
        frame:Close()

        timer.Simple(0.3, function()
            if IsValid(parentFrame) and parentFrame.RefreshPermissions then
                parentFrame.RefreshPermissions()
            end
        end)
    end

    local cancelBtn = vgui.Create("DButton", frame)
    cancelBtn:SetPos(30 + buttonW, buttonY)
    cancelBtn:SetSize(buttonW, 34)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetFont("DermaDefaultBold")
    cancelBtn:SetTextColor(Color(200, 200, 205))
    cancelBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(60, 35, 35, 220) or Color(40, 25, 25, 200)
        draw.RoundedBox(6, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(180, 80, 80, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
    end
    cancelBtn.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        frame:Close()
    end
end

-- Modern VEIN Permissions GUI
DoorGUI.OpenPermissionsGUI = function(door)
    if not IsValid(door) then return end
    
    -- Create modern styled frame with access level categories
    local frame = vgui.Create("DFrame")
    local frameW, frameH = ClampFrameSize(frame, 550, 550)
    frame:Center()
    frame:SetTitle("")
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)
    frame:MakePopup()
    
    -- VEIN styling
    frame.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        surface.SetDrawColor(180, 60, 60, 120)
        surface.DrawRect(12, 12, w - 24, 2)
    end
    
    -- Close button
    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetPos(frameW - 40, 13)
    closeBtn:SetSize(28, 28)
    closeBtn:SetText("")
    closeBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(180, 60, 60, 220) or Color(40, 40, 42, 150)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(180, 60, 60, 220)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        local centerX, centerY = w/2, h/2
        local size = 6
        local lineColor = isHovered and Color(255, 200, 200) or Color(180, 180, 185)
        surface.SetDrawColor(lineColor)
        surface.DrawLine(centerX - size, centerY - size, centerX + size, centerY + size)
        surface.DrawLine(centerX + size, centerY - size, centerX - size, centerY + size)
    end
    closeBtn.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        frame:Close()
    end
    
    -- Title with door name
    local doorName = door:GetNWString("VEIN_DoorName", "Door")
    local title = vgui.Create("DLabel", frame)
    title:SetPos(15, 20)
    title:SetSize(480, 30)
    title:SetText("Manage Access: " .. doorName)
    title:SetFont("DermaLarge")
    title:SetTextColor(Color(220, 220, 225))
    
    -- Scroll panel for all content
    local scrollPanel = vgui.Create("DScrollPanel", frame)
    scrollPanel:SetPos(15, 60)
    scrollPanel:SetSize(frameW - 30, frameH - 120)
    
    -- Scrollbar styling
    local vbar = scrollPanel:GetVBar()
    vbar:SetWide(8)
    vbar.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(30, 30, 33, 180))
    end
    vbar.btnGrip.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local color = isHovered and Color(120, 40, 40, 220) or Color(80, 80, 85, 200)
        draw.RoundedBox(4, 0, 0, w, h, color)
    end
    vbar.btnUp.Paint = function() end
    vbar.btnDown.Paint = function() end
    
    local yOffset = 0
    
    -- Function to refresh the entire panel
    frame.RefreshPermissions = function()
        scrollPanel:Clear()
        yOffset = 0
        
        -- Get all access data from door
        local accessDataJSON = door:GetNWString("VEIN_AccessData", "{}")
        local accessData = util.JSONToTable(accessDataJSON) or {}
        local ownerNick = door:GetNWString("VEIN_OwnerName", "")
        local myNick = LocalPlayer():Nick()
        
        -- Organize by access level
        local coOwners = {}
        local residents = {}
        local guests = {}
        
        for accessKey, data in pairs(accessData) do
            local entryData = istable(data) and data or {level = VEIN.AccessLevels.RESIDENT}
            local displayName = VEIN.AccessLevels.GetAccessDisplayName and VEIN.AccessLevels.GetAccessDisplayName(accessKey, entryData) or accessKey
            local memberData = {
                key = accessKey,
                nick = displayName,
                data = entryData,
                steamID = entryData.steamid or "",
                steamID64 = entryData.steamid64 or "",
            }

            if entryData.level == VEIN.AccessLevels.CO_OWNER then
                table.insert(coOwners, memberData)
            elseif entryData.level == VEIN.AccessLevels.RESIDENT then
                table.insert(residents, memberData)
            elseif entryData.level == VEIN.AccessLevels.GUEST then
                table.insert(guests, memberData)
            end
        end
        
        -- Helper function to create section
        local function CreateSection(title, icon, color, members, level)
            local sectionLabel = vgui.Create("DLabel", scrollPanel)
            sectionLabel:SetPos(0, yOffset)
            sectionLabel:SetSize(500, 25)
            sectionLabel:SetText(icon .. " " .. title .. " (" .. #members .. ")")
            sectionLabel:SetFont("DermaDefaultBold")
            sectionLabel:SetTextColor(color)
            yOffset = yOffset + 30
            
            if #members == 0 then
                local emptyLabel = vgui.Create("DLabel", scrollPanel)
                emptyLabel:SetPos(20, yOffset)
                emptyLabel:SetSize(480, 20)
                emptyLabel:SetText("No players")
                emptyLabel:SetFont("DermaDefault")
                emptyLabel:SetTextColor(Color(120, 120, 125))
                yOffset = yOffset + 25
            else
                for _, member in ipairs(members) do
                    local memberPanel = vgui.Create("DPanel", scrollPanel)
                    memberPanel:SetPos(10, yOffset)
                    memberPanel:SetSize(490, 35)
                    memberPanel.Paint = function(self, w, h)
                        local bgColor = Color(35, 35, 38, 200)
                        draw.RoundedBox(4, 0, 0, w, h, bgColor)
                        surface.SetDrawColor(color.r * 0.5, color.g * 0.5, color.b * 0.5, 150)
                        surface.DrawOutlinedRect(0, 0, w, h, 1)
                        surface.DrawRect(0, 0, 4, h) -- Accent bar
                    end
                    
                    -- Player name
                    local nameLabel = vgui.Create("DLabel", memberPanel)
                    nameLabel:SetPos(15, 0)
                    nameLabel:SetSize(200, 35)
                    nameLabel:SetText(member.nick)
                    nameLabel:SetFont("DermaDefault")
                    nameLabel:SetTextColor(Color(220, 220, 225))
                    nameLabel:SetContentAlignment(4)
                    
                    -- Expiration timer for guests
                    if level == VEIN.AccessLevels.GUEST and member.data.expiresAt then
                        local timeLeft = member.data.expiresAt - os.time()
                        if timeLeft > 0 then
                            local minutes = math.floor(timeLeft / 60)
                            local seconds = timeLeft % 60
                            local timeLabel = vgui.Create("DLabel", memberPanel)
                            timeLabel:SetPos(220, 0)
                            timeLabel:SetSize(120, 35)
                            timeLabel:SetText(string.format("⏰ %dm %ds", minutes, seconds))
                            timeLabel:SetFont("DermaDefault")
                            timeLabel:SetTextColor(Color(255, 200, 100))
                            timeLabel:SetContentAlignment(4)
                        end
                    end
                    
                    -- Change Level button
                    local canManage = VEIN.AccessLevels.CanManagePermissions(door, myNick)
                    if canManage and member.nick ~= myNick then -- Can't change own level
                        local changeBtn = vgui.Create("DButton", memberPanel)
                        changeBtn:SetPos(350, 7)
                        changeBtn:SetSize(60, 21)
                        changeBtn:SetText("Change")
                        changeBtn:SetFont("DermaDefault")
                        changeBtn:SetTextColor(Color(200, 200, 205))
                        changeBtn.Paint = function(self, w, h)
                            local isHovered = self:IsHovered()
                            local bgColor = isHovered and Color(60, 100, 160, 220) or Color(40, 80, 140, 180)
                            draw.RoundedBox(3, 0, 0, w, h, bgColor)
                            if isHovered then
                                surface.SetDrawColor(100, 140, 200, 180)
                                surface.DrawOutlinedRect(0, 0, w, h, 1)
                            end
                        end
                        changeBtn.DoClick = function()
                            surface.PlaySound("buttons/button15.wav")
                            DoorGUI.OpenChangeLevelDialog(door, member.key, member.nick, level, frame, member.steamID, member.steamID64)
                        end
                    end
                    
                    -- Remove button
                    if canManage and member.nick ~= myNick then -- Can't remove yourself
                        local removeBtn = vgui.Create("DButton", memberPanel)
                        removeBtn:SetPos(420, 7)
                        removeBtn:SetSize(60, 21)
                        removeBtn:SetText("Remove")
                        removeBtn:SetFont("DermaDefault")
                        removeBtn:SetTextColor(Color(200, 200, 205))
                        removeBtn.Paint = function(self, w, h)
                            local isHovered = self:IsHovered()
                            local bgColor = isHovered and Color(140, 40, 40, 220) or Color(100, 30, 30, 180)
                            draw.RoundedBox(3, 0, 0, w, h, bgColor)
                            if isHovered then
                                surface.SetDrawColor(180, 60, 60, 180)
                                surface.DrawOutlinedRect(0, 0, w, h, 1)
                            end
                        end
                        removeBtn.DoClick = function()
                            surface.PlaySound("buttons/button15.wav")
                            OpenRemoveAccessDialog(door, member, frame)
                        end
                    end
                    
                    yOffset = yOffset + 40
                end
            end
            
            yOffset = yOffset + 10 -- Spacing between sections
        end
        
        -- Create all sections
        CreateSection("Co-Owners", VEIN.AccessLevels.Info[VEIN.AccessLevels.CO_OWNER].icon, 
                     VEIN.AccessLevels.Info[VEIN.AccessLevels.CO_OWNER].color, coOwners, VEIN.AccessLevels.CO_OWNER)
        
        CreateSection("Residents", VEIN.AccessLevels.Info[VEIN.AccessLevels.RESIDENT].icon,
                     VEIN.AccessLevels.Info[VEIN.AccessLevels.RESIDENT].color, residents, VEIN.AccessLevels.RESIDENT)
        
        CreateSection("Guests", VEIN.AccessLevels.Info[VEIN.AccessLevels.GUEST].icon,
                     VEIN.AccessLevels.Info[VEIN.AccessLevels.GUEST].color, guests, VEIN.AccessLevels.GUEST)
        
        -- Add Player button at bottom
        local canManage = VEIN.AccessLevels.CanManagePermissions(door, myNick)
        if canManage then
            yOffset = yOffset + 10
            
            local addBtn = vgui.Create("DButton", scrollPanel)
            addBtn:SetPos(10, yOffset)
            addBtn:SetSize(490, 40)
            addBtn:SetText("➕ Add Player")
            addBtn:SetFont("DermaDefaultBold")
            addBtn:SetTextColor(Color(200, 200, 205))
            addBtn.Paint = function(self, w, h)
                local isHovered = self:IsHovered()
                local bgColor = isHovered and Color(60, 120, 60, 220) or Color(40, 80, 40, 200)
                draw.RoundedBox(6, 0, 0, w, h, bgColor)
                if isHovered then
                    surface.SetDrawColor(120, 180, 120, 180)
                    surface.DrawOutlinedRect(0, 0, w, h, 2)
                end
                surface.SetDrawColor(100, 150, 100, isHovered and 160 or 120)
                surface.DrawRect(0, 0, 5, h)
            end
            addBtn.DoClick = function()
                surface.PlaySound("buttons/button15.wav")
                DoorGUI.OpenAddPlayerDialog(door, frame)
            end
        end
    end
    
    -- Initial load
    frame.RefreshPermissions()
    
    -- Auto-refresh every 2 seconds for guest timers
    local timerID = "VEIN_RefreshPermissions_" .. tostring(frame)
    timer.Create(timerID, 2, 0, function()
        if IsValid(frame) then
            frame.RefreshPermissions()
        else
            timer.Remove(timerID)
        end
    end)
end

-- Change Door Name GUI
DoorGUI.OpenChangeNameGUI = function(door)
    local frame = vgui.Create("DFrame")
    ClampFrameSize(frame, 400, 180)
    frame:Center()
    frame:SetTitle("Change Door Name")
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)
    frame:MakePopup()
    
    -- Q key to close menu
    frame.OnKeyCodePressed = function(self, keyCode)
        if keyCode == KEY_Q then
            self:Close()
            return true
        end
        return false
    end
    
    -- Dark minimalistic frame
    frame.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 245))
        surface.SetDrawColor(120, 40, 40, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        surface.SetDrawColor(180, 60, 60, 100)
        surface.DrawRect(12, 12, w - 24, 2)
    end
    
    local currentName = door:GetNWString("VEIN_DoorName", "")
    
    local label = vgui.Create("DLabel", frame)
    label:SetPos(20, 35)
    label:SetSize(360, 20)
    label:SetText("Enter new door name (leave blank for default):")
    label:SetTextColor(Color(200, 200, 205))
    
    local nameEntry = vgui.Create("DTextEntry", frame)
    nameEntry:SetPos(20, 65)
    nameEntry:SetSize(360, 30)
    nameEntry:SetText(currentName)
    nameEntry:SetPlaceholderText("Door name...")
    nameEntry:RequestFocus()
    nameEntry.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 38, 200))
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        self:DrawTextEntryText(Color(220, 220, 225), Color(120, 50, 50), Color(220, 220, 225))
    end
    
    local changeBtn = vgui.Create("DButton", frame)
    changeBtn:SetPos(100, 120)
    changeBtn:SetSize(80, 30)
    changeBtn:SetText("Change")
    changeBtn:SetTextColor(Color(200, 200, 205))
    changeBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(40, 40, 43, 200) or Color(35, 35, 38, 180)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(140, 60, 60, 150)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        surface.SetDrawColor(120, 50, 50, isHovered and 120 or 80)
        surface.DrawRect(0, 0, 3, h)
    end
    changeBtn.DoClick = function()
        local newName = nameEntry:GetValue()
        net.Start("VEIN_ChangeDoorName")
        net.WriteEntity(door)
        net.WriteString(newName)
        net.SendToServer()
        frame:Close()
    end
    
    local cancelBtn = vgui.Create("DButton", frame)
    cancelBtn:SetPos(220, 120)
    cancelBtn:SetSize(80, 30)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetTextColor(Color(200, 200, 205))
    cancelBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(60, 35, 35, 200) or Color(40, 25, 25, 180)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(180, 80, 80, 150)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
    end
    cancelBtn.DoClick = function()
        frame:Close()
    end
    
    -- Enter key submits
    nameEntry.OnEnter = function()
        changeBtn:DoClick()
    end
end

-- Handle 3D menu input
-- Input handling no longer needed - screen GUI handles everything

-- Draw 3D Menu with PROPER orientation
-- 3D Menu replaced with screen GUI

-- Global GUI visibility (independent of weapon) - DEFAULT TO TRUE (ON)
VEIN.DoorGUIVisible = VEIN.DoorGUIVisible == nil and true or VEIN.DoorGUIVisible

-- COMPLETELY NEW 3D HOLOGRAM SYSTEM - SIMPLE AND CLEAN
local function DrawDoorHolograms()
    local ply = LocalPlayer()

    -- Respect global visibility toggle: hide all holograms when disabled
    if not VEIN.DoorGUIVisible then
        return
    end
    
    -- Check GUI visibility toggle (press middle mouse with keys weapon to toggle)
    local guiEnabled = VEIN.DoorGUIVisible
    local showOwnedDoors = guiEnabled
    
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and IsValidDoor(door) then
            local isBuyable = door:GetNWBool("VEIN_Buyable", false)
            local owner = door:GetNWString("VEIN_OwnerName", "")
            local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
            local allowOwnership = door:GetNWBool("VEIN_AllowOwnership", true)
            local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
            local isAdminOnly = door:GetNWBool("VEIN_AdminOnly", false)
            
            if isVEINDoor then
                local allowWhenDisabled = isJobControlled or isAdminOnly
                if guiEnabled or allowWhenDisabled then
                    -- Check visibility permissions
                    local shouldShow = false
                    local isStaticDoor = (not allowOwnership) and (not isJobControlled) -- Static admin-only door
                    
                    if isJobControlled or isAdminOnly then
                        -- Job-controlled or Admin-only door - only show when triggered (interaction)
                        local entIndex = door:EntIndex()
                        local hologramData = VEIN.DoorSystem.JobDoorHolograms[entIndex]
                        
                        if hologramData and CurTime() < hologramData.showUntil then
                            shouldShow = true
                        else
                            shouldShow = false
                        end
                    elseif isStaticDoor then
                        -- Static door - only visible to admins
                        shouldShow = ply:IsAdmin()
                    elseif guiEnabled and isBuyable and owner == "" then
                        -- FOR SALE doors - obey global visibility toggle
                        shouldShow = true
                    elseif guiEnabled and owner ~= "" and showOwnedDoors then
                        -- Owned door - only show if GUI visibility is enabled
                        if owner == ply:Nick() then
                            -- Owner can see their own door when GUI enabled
                            shouldShow = true
                        else
                            -- Check if player has been given access using new Access Levels system
                            if VEIN and VEIN.AccessLevels and VEIN.AccessLevels.HasAccess then
                                if VEIN.AccessLevels.HasAccess(door, ply:Nick()) then
                                    -- Granted access - can see when GUI enabled
                                    shouldShow = true
                                end
                            end
                            -- If no access, shouldShow remains false (complete privacy)
                        end
                    end
                    
                    if shouldShow then
                -- Position hologram using door-local anchors so it follows door movement/open/close.
                local useLocalHologram = door:GetNWBool("VEIN_UseLocalHologram", false)
                local visualCenter
                local clickNormal
                local clickPos

                if useLocalHologram then
                    local visualCenterLocal = door:GetNWVector("VEIN_VisualCenterLocal", door:OBBCenter())
                    local clickPosLocal = door:GetNWVector("VEIN_ClickPosLocal", visualCenterLocal)
                    local clickNormalLocal = door:GetNWVector("VEIN_ClickNormalLocal", Vector(1, 0, 0))

                    visualCenter = door:LocalToWorld(visualCenterLocal)
                    clickPos = door:LocalToWorld(clickPosLocal)

                    local normalEndWorld = door:LocalToWorld(clickPosLocal + clickNormalLocal)
                    clickNormal = normalEndWorld - clickPos
                    if clickNormal:LengthSqr() <= 0.0001 then
                        clickNormal = door:GetNWVector("VEIN_ClickNormal", door:GetForward())
                    else
                        clickNormal:Normalize()
                    end
                else
                    visualCenter = door:GetNWVector("VEIN_VisualCenter", door:LocalToWorld(door:OBBCenter()))
                    clickNormal = door:GetNWVector("VEIN_ClickNormal", door:GetForward())
                    clickPos = door:GetNWVector("VEIN_ClickPos", visualCenter)
                    if clickNormal:LengthSqr() <= 0.0001 then
                        clickNormal = door:GetForward()
                    else
                        clickNormal:Normalize()
                    end
                end
                
                -- Calculate distance from click surface to visual center (door thickness in that direction)
                local surfaceToCenterDist = math.abs(clickNormal:Dot(visualCenter - clickPos))
                
                -- Position hologram: surface distance + buffer to ensure it's outside the door
                -- Use at least 5 units buffer, or more for thick doors
                local hologramOffset = surfaceToCenterDist + math.max(2.5, surfaceToCenterDist * 0.3)
                local hologramPos = visualCenter + clickNormal * hologramOffset + Vector(0, 0, 15)
                
                local distance = ply:GetPos():Distance(hologramPos)
                local maxDistance = 400
                
                if distance < maxDistance then
                    -- Calculate fade alpha based on distance (fade in/out animation)
                    local fadeDistance = 80  -- Start fading 80 units before max distance
                    local alpha = 1.0
                    if distance > (maxDistance - fadeDistance) then
                        alpha = 1.0 - ((distance - (maxDistance - fadeDistance)) / fadeDistance)
                    end
                    alpha = math.Clamp(alpha, 0, 1)
                    
                    -- Job-controlled or Admin-only doors: Apply fade in/out animation
                    if isJobControlled or isAdminOnly then
                        local entIndex = door:EntIndex()
                        local hologramData = VEIN.DoorSystem.JobDoorHolograms[entIndex]
                        
                        if hologramData then
                            local timeRemaining = hologramData.showUntil - CurTime()
                            local fadeInDuration = 0.3 -- 0.3 seconds to fade in
                            local fadeOutDuration = 0.5 -- 0.5 seconds to fade out
                            
                            if not hologramData.fadeInComplete then
                                -- Fade in animation
                                local fadeInProgress = (5 - timeRemaining) / fadeInDuration
                                if fadeInProgress >= 1 then
                                    hologramData.alpha = 1
                                    hologramData.fadeInComplete = true
                                else
                                    hologramData.alpha = math.Clamp(fadeInProgress, 0, 1)
                                end
                            elseif timeRemaining <= fadeOutDuration then
                                -- Fade out animation
                                hologramData.alpha = timeRemaining / fadeOutDuration
                            else
                                -- Fully visible
                                hologramData.alpha = 1
                            end
                            
                            -- Apply hologram fade to distance alpha
                            alpha = alpha * hologramData.alpha
                            
                            -- Clean up expired holograms
                            if timeRemaining <= 0 then
                                VEIN.DoorSystem.JobDoorHolograms[entIndex] = nil
                            end
                        end
                    end
                    
                    -- Check which side of the door the player is on
                    local playerPos = ply:GetPos()
                    local centerToPlayer = (playerPos - visualCenter):GetNormalized()
                    local dot = clickNormal:Dot(centerToPlayer)
                    
                    -- If player is on the opposite side (dot < 0), flip hologram 180 degrees and reverse position
                    local shouldFlip = dot < 0
                    
                    -- Recalculate hologram position with corrected offset (use negative for opposite side)
                    local finalOffset = shouldFlip and -hologramOffset or hologramOffset
                    hologramPos = visualCenter + clickNormal * finalOffset + Vector(0, 0, 15)
                    
                    -- SBS-built doors can inherit slight pitch/roll from the supporting structure.
                    -- Keep the panel position tied to the true door face, but render the 3D2D panel upright.
                    local angleNormal = clickNormal
                    if door:GetNWBool("VEIN_SBSManaged", false) then
                        local flatNormal = Vector(clickNormal.x, clickNormal.y, 0)
                        if flatNormal:LengthSqr() > 0.0001 then
                            flatNormal:Normalize()
                            angleNormal = flatNormal
                        end
                    end

                    -- Convert surface normal to angle and make hologram face outward
                    local normalAngle = angleNormal:Angle()
                    local hologramAngle = Angle(normalAngle.p, normalAngle.y + 90, 90)
                    
                    -- Apply 180 degree rotation if player is on opposite side
                    if shouldFlip then
                        hologramAngle.y = hologramAngle.y + 180
                    end
                    
                    -- Advanced rendering fix for transparency issues
                    render.OverrideDepthEnable(true, false)
                    render.SetBlend(alpha)
                    cam.Start3D2D(hologramPos, hologramAngle, 0.1)
                    
                        if isJobControlled then
                            -- JOB-CONTROLLED DOOR HOLOGRAM (visible to everyone)
                            local bgAlpha = math.floor(150 * alpha)
                            local borderAlpha = math.floor(200 * alpha)
                            local textAlpha = math.floor(255 * alpha)
                            
                            -- Check if player has access
                            local controlJobs = util.JSONToTable(door:GetNWString("VEIN_ControlJobs", "[]")) or {}
                            local hasAccess = false
                            local teamId = ply:Team()
                            for _, jobId in ipairs(controlJobs) do
                                if jobId == teamId then
                                    hasAccess = true
                                    break
                                end
                            end
                            
                            if hasAccess then
                                surface.SetDrawColor(30, 80, 30, bgAlpha)  -- Green for access
                                surface.DrawRect(-180, -75, 360, 150)
                                surface.SetDrawColor(70, 150, 70, borderAlpha)  -- Green border
                                surface.DrawOutlinedRect(-180, -75, 360, 150, 4)
                                draw.SimpleText("JOB CONTROLLED", "DermaLarge", 0, -35, Color(150, 255, 150, textAlpha), TEXT_ALIGN_CENTER)
                                draw.SimpleText("You have access", "DermaDefaultBold", 0, 0, Color(150, 255, 150, textAlpha), TEXT_ALIGN_CENTER)
                            else
                                surface.SetDrawColor(80, 60, 30, bgAlpha)  -- Yellow/orange for no access
                                surface.DrawRect(-180, -75, 360, 150)
                                surface.SetDrawColor(150, 120, 50, borderAlpha)  -- Yellow border
                                surface.DrawOutlinedRect(-180, -75, 360, 150, 4)
                                draw.SimpleText("JOB CONTROLLED", "DermaLarge", 0, -35, Color(255, 200, 100, textAlpha), TEXT_ALIGN_CENTER)
                                draw.SimpleText("Your job cannot access", "DermaDefaultBold", 0, 0, Color(255, 200, 100, textAlpha), TEXT_ALIGN_CENTER)
                            end
                            
                            local doorName = door:GetNWString("VEIN_DoorName", "")
                            if doorName ~= "" then
                                draw.SimpleText(doorName, "DermaDefault", 0, 30, Color(200, 200, 200, textAlpha), TEXT_ALIGN_CENTER)
                            else
                                draw.SimpleText("Use left-click with keys to lock/unlock", "DermaDefault", 0, 30, Color(180, 180, 180, textAlpha), TEXT_ALIGN_CENTER)
                            end
                            
                        elseif isAdminOnly then
                            -- ADMIN-ONLY DOOR HOLOGRAM (timer display when unlocked)
                            local bgAlpha = math.floor(150 * alpha)
                            local borderAlpha = math.floor(200 * alpha)
                            local textAlpha = math.floor(255 * alpha)
                            
                            -- Check if player is admin
                            local hasAccess = ply:IsAdmin()
                            
                            if hasAccess then
                                surface.SetDrawColor(50, 50, 100, bgAlpha)  -- Blue for admin access
                                surface.DrawRect(-180, -75, 360, 150)
                                surface.SetDrawColor(100, 100, 180, borderAlpha)  -- Blue border
                                surface.DrawOutlinedRect(-180, -75, 360, 150, 4)
                                draw.SimpleText("ADMIN DOOR", "DermaLarge", 0, -35, Color(150, 150, 255, textAlpha), TEXT_ALIGN_CENTER)
                                
                                local autoLock = door:GetNWBool("VEIN_AutoLockOnClose", false)
                                local isLocked = door:GetNWBool("VEIN_Locked", false)
                                if autoLock and not isLocked then
                                    draw.SimpleText("Auto-locks when closed", "DermaDefaultBold", 0, 0, Color(255, 255, 100, textAlpha), TEXT_ALIGN_CENTER)
                                else
                                    draw.SimpleText("You have access", "DermaDefaultBold", 0, 0, Color(200, 200, 255, textAlpha), TEXT_ALIGN_CENTER)
                                end
                            else
                                surface.SetDrawColor(100, 50, 50, bgAlpha)  -- Red for no access
                                surface.DrawRect(-180, -75, 360, 150)
                                surface.SetDrawColor(180, 100, 100, borderAlpha)  -- Red border
                                surface.DrawOutlinedRect(-180, -75, 360, 150, 4)
                                draw.SimpleText("ADMIN DOOR", "DermaLarge", 0, -35, Color(255, 150, 150, textAlpha), TEXT_ALIGN_CENTER)
                                draw.SimpleText("Admin access required", "DermaDefaultBold", 0, 0, Color(255, 150, 150, textAlpha), TEXT_ALIGN_CENTER)
                            end
                            
                            local doorName = door:GetNWString("VEIN_DoorName", "")
                            if doorName ~= "" then
                                draw.SimpleText(doorName, "DermaDefault", 0, 30, Color(200, 200, 200, textAlpha), TEXT_ALIGN_CENTER)
                            else
                                draw.SimpleText("Use left-click with keys to lock/unlock", "DermaDefault", 0, 30, Color(180, 180, 180, textAlpha), TEXT_ALIGN_CENTER)
                            end
                            
                        elseif isStaticDoor then
                            -- STATIC ADMIN-ONLY DOOR HOLOGRAM (only admins see this)
                            local bgAlpha = math.floor(150 * alpha)
                            local borderAlpha = math.floor(200 * alpha)
                            local textAlpha = math.floor(255 * alpha)
                            
                            surface.SetDrawColor(60, 60, 80, bgAlpha)  -- Blue-gray for static doors
                            surface.DrawRect(-180, -75, 360, 150)
                            
                            surface.SetDrawColor(100, 100, 140, borderAlpha)  -- Blue-gray border
                            surface.DrawOutlinedRect(-180, -75, 360, 150, 4)
                            
                            draw.SimpleText("[ADMIN] STATIC DOOR", "DermaLarge", 0, -35, Color(200, 200, 255, textAlpha), TEXT_ALIGN_CENTER)
                            draw.SimpleText("Not purchasable", "DermaDefaultBold", 0, 0, Color(180, 180, 220, textAlpha), TEXT_ALIGN_CENTER)
                            draw.SimpleText("Right-click with keys to manage", "DermaDefault", 0, 30, Color(160, 160, 200, textAlpha), TEXT_ALIGN_CENTER)
                            
                        elseif isBuyable then
                            -- COLOR-CODED FOR SALE HOLOGRAM by door type with fade
                            local bgAlpha = math.floor(180 * alpha)
                            local borderAlpha = math.floor(220 * alpha)
                            local textAlpha = math.floor(255 * alpha)
                            
                            -- Get door type and find its color
                            local doorType = door:GetNWString("VEIN_DoorType", "Residential")
                            local typeColor = Color(20, 80, 30) -- Default green fallback
                            
                            if VEIN.CustomDoors and VEIN.CustomDoors.Types then
                                for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                                    if typeData.name == doorType then
                                        typeColor = Color(typeData.color.r, typeData.color.g, typeData.color.b)
                                        break
                                    end
                                end
                            end
                            
                            -- Apply darker background with type color (30% brightness, maintains color ratio)
                            local bgColor = Color(
                                math.floor(typeColor.r * 0.3),
                                math.floor(typeColor.g * 0.3),
                                math.floor(typeColor.b * 0.3),
                                bgAlpha
                            )
                            surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgAlpha)
                            surface.DrawRect(-180, -90, 360, 180)  -- Bigger panel
                            
                            -- Apply brighter border with type color (60% brightness, maintains color ratio)
                            local borderColor = Color(
                                math.floor(typeColor.r * 0.6),
                                math.floor(typeColor.g * 0.6),
                                math.floor(typeColor.b * 0.6),
                                borderAlpha
                            )
                            surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderAlpha)
                            surface.DrawOutlinedRect(-180, -90, 360, 180, 4)
                            
                            -- Bigger text with fade and BLACK OUTLINE for readability
                            draw.SimpleTextOutlined("FOR SALE", "DermaLarge", 0, -50, Color(220, 255, 220, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, textAlpha))
                            
                            local price = door:GetNWInt("VEIN_Price", 500)
                            local propertyGroupId = door:GetNWInt("VEIN_PropertyGroup", 0)
                            local propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", "")
                            local propertyCount = door:GetNWInt("VEIN_PropertyCount", 1)
                            local propertyTotal = door:GetNWInt("VEIN_PropertyTotalPrice", price)
                            local displayPrice = (propertyGroupId > 0 and propertyGroupName ~= "") and propertyTotal or price
                            draw.SimpleTextOutlined("$" .. string.Comma(displayPrice), "DermaLarge", 0, -10, Color(255, 220, 120, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, textAlpha))  -- Bigger price

                            local linkCount = door:GetNWInt("VEIN_LinkCount", 1)
                            local linkTotal = door:GetNWInt("VEIN_LinkTotalPrice", price)
                            if propertyGroupId > 0 and propertyGroupName ~= "" and propertyCount > 1 then
                                draw.SimpleTextOutlined("Property Doors: " .. propertyCount .. " " .. SMALL_CIRCLE .. " Total $" .. string.Comma(propertyTotal), "DermaDefault", 0, 10, Color(180, 240, 180, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))
                            elseif linkCount > 1 then
                                draw.SimpleTextOutlined("Linked Doors: " .. linkCount .. " " .. SMALL_CIRCLE .. " Total $" .. string.Comma(linkTotal), "DermaDefault", 0, 10, Color(180, 240, 180, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))
                            end
                            
                            local doorName = door:GetNWString("VEIN_DoorName", "")
                            if doorName ~= "" then
                                draw.SimpleTextOutlined(doorName, "DermaDefaultBold", 0, 25, Color(200, 220, 200, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))
                            end
                            
                            -- F2 menu DISABLED - always show right-click message
                            local purchaseText = (propertyGroupId > 0 and propertyGroupName ~= "") and "Buy this property?" or "Right-click to purchase"
                            draw.SimpleTextOutlined(purchaseText, "DermaDefault", 0, 50, Color(180, 200, 180, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))
                            
                        else
                            -- Check if player has access to this owned door
                            local hasAccess = false
                            if owner == ply:Nick() then
                                hasAccess = true
                            else
                                -- Check network data for access (simplified client-side check)
                                local doorAccess = door:GetNWString("VEIN_AccessList", "")
                                hasAccess = string.find(doorAccess, ply:Nick()) ~= nil
                            end
                            
                            if hasAccess then
                                -- COLOR-CODED OWNED HOLOGRAM by door type with fade - only show if player has access
                                local bgAlpha = math.floor(180 * alpha)
                                local borderAlpha = math.floor(220 * alpha)
                                local textAlpha = math.floor(255 * alpha)
                                
                                -- Get door type and find its color
                                local doorType = door:GetNWString("VEIN_DoorType", "Residential")
                                local typeColor = Color(80, 20, 20) -- Default red fallback
                                
                                if VEIN.CustomDoors and VEIN.CustomDoors.Types then
                                    for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                                        if typeData.name == doorType then
                                            typeColor = Color(typeData.color.r, typeData.color.g, typeData.color.b)
                                            break
                                        end
                                    end
                                end
                                
                                -- Apply darker background with type color (30% brightness, maintains color ratio)
                                local bgColor = Color(
                                    math.floor(typeColor.r * 0.3),
                                    math.floor(typeColor.g * 0.3),
                                    math.floor(typeColor.b * 0.3),
                                    bgAlpha
                                )
                                surface.SetDrawColor(bgColor.r, bgColor.g, bgColor.b, bgAlpha)
                                surface.DrawRect(-150, -75, 300, 150)  -- Bigger panel
                                
                                -- Apply brighter border with type color (55% brightness, maintains color ratio)
                                local borderColor = Color(
                                    math.floor(typeColor.r * 0.55),
                                    math.floor(typeColor.g * 0.55),
                                    math.floor(typeColor.b * 0.55),
                                    borderAlpha
                                )
                                surface.SetDrawColor(borderColor.r, borderColor.g, borderColor.b, borderAlpha)
                                surface.DrawOutlinedRect(-150, -75, 300, 150, 3)
                                
                                local doorName = door:GetNWString("VEIN_DoorName", "")
                                local displayName = doorName ~= "" and doorName or (owner .. "'s Door")
                                draw.SimpleTextOutlined(displayName, "DermaDefaultBold", 0, -35, Color(220, 200, 200, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))  -- Bigger text with outline
                                
                                draw.SimpleTextOutlined("OWNED", "DermaDefault", 0, -5, Color(180, 160, 160, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))

                                -- Check if door is broken
                                local isBroken = door:GetNWBool("VEIN_Broken", false)
                                local isLocked = door:GetNWBool("VEIN_Locked", false)
                                local lockText, lockColor
                                
                                if isBroken then
                                    lockText = "[BROKEN]"
                                    lockColor = Color(200, 200, 80, textAlpha) -- Yellow for broken
                                else
                                    lockText = isLocked and "[LOCKED]" or "[UNLOCKED]"
                                    lockColor = isLocked and Color(200, 120, 120, textAlpha) or Color(120, 200, 120, textAlpha)
                                end
                                
                                draw.SimpleTextOutlined(lockText, "DermaDefault", 0, 20, lockColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))
                                
                                -- F2 menu disabled - always show right-click instruction
                                draw.SimpleTextOutlined("Right-click with keys to manage", "DermaDefault", 0, 45, Color(160, 140, 140, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, textAlpha))
                            end
                            -- If no access, don't show anything (hologram is invisible to unauthorized players)
                        end
                    
                    cam.End3D2D()
                    
                    -- Restore rendering state
                    render.OverrideDepthEnable(false)
                    render.SetBlend(1)
                end -- End distance/fade check
                end -- End shouldShow check
            end -- End isBuyable/owner check
        end -- End IsValidDoor check
    end -- End for loop
end
end -- End DrawDoorHolograms

--[[
================================================================================
ACCESS LEVEL SYSTEM - NEW UI FUNCTIONS
================================================================================
]]--

-- Add Player Dialog (with access level selection and guest time)
DoorGUI.OpenAddPlayerDialog = function(door, parentFrame)
    local dialog = vgui.Create("DFrame")
    local baseW, baseH = 450, 420
    local dialogW = math.max(320, math.min(baseW, ScrW() - 80))
    local dialogH = math.max(320, math.min(baseH, ScrH() - 80))
    dialog:SetSize(dialogW, dialogH)
    dialog:Center()
    dialog:SetTitle("")
    dialog:SetDraggable(false)
    dialog:ShowCloseButton(false)
    dialog:MakePopup()
    
    dialog.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        surface.SetDrawColor(180, 60, 60, 120)
        surface.DrawRect(12, 12, w - 24, 2)
    end

    local content = vgui.Create("DPanel", dialog)
    content:SetPos(0, 0)
    content:SetSize(dialogW, dialogH)
    content.Paint = function() end

    local innerW = dialogW - 40
    
    -- Title
    local title = vgui.Create("DLabel", content)
    title:SetPos(15, 20)
    title:SetSize(dialogW - 30, 30)
    title:SetText("Add Player to Door")
    title:SetFont("DermaLarge")
    title:SetTextColor(Color(220, 220, 225))
    
    -- Player selection
    local playerLabel = vgui.Create("DLabel", content)
    playerLabel:SetPos(20, 60)
    playerLabel:SetSize(innerW, 20)
    playerLabel:SetText("Select Player:")
    playerLabel:SetFont("DermaDefaultBold")
    playerLabel:SetTextColor(Color(200, 200, 205))
    
    local playerCombo = vgui.Create("DComboBox", content)
    playerCombo:SetPos(20, 85)
    playerCombo:SetSize(innerW, 30)
    playerCombo:SetValue("Choose a player...")
    playerCombo:SetFont("DermaDefault")
    playerCombo:SetTextColor(Color(220, 220, 225))
    playerCombo.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 38, 220))
        surface.SetDrawColor(80, 80, 85, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    
    local function GetAccessKeyForPlayer(ply)
        if not IsValid(ply) then return "" end
        if ply:IsBot() then
            local nick = ply:Nick()
            if string.StartWith(nick, "BOT_") then
                return nick
            end
            return "BOT_" .. nick
        end
        local sid64 = ply:SteamID64() or ""
        if sid64 ~= "" and sid64 ~= "0" then return sid64 end
        local sid = ply:SteamID() or ""
        if sid ~= "" then return sid end
        return ply:Nick()
    end

    -- Add all online players (exclude players who already have access)
    local existingAccess = VEIN.AccessLevels.GetAllAccess(door)
    local selectedPlayerData = nil

    local function PlayerAlreadyHasAccess(targetPly)
        if not IsValid(targetPly) then return true end

        local playerNick = targetPly:Nick()
        if existingAccess[playerNick] then
            return true
        end

        if VEIN.AccessLevels.ResolveAccessEntry then
            if select(1, VEIN.AccessLevels.ResolveAccessEntry(door, playerNick, playerNick)) then
                return true
            end

            -- Bots share the same SteamID ("BOT"), so use nickname-only matching for bots.
            if not targetPly:IsBot() then
                local steamID = targetPly:SteamID() or ""
                if steamID ~= "" and select(1, VEIN.AccessLevels.ResolveAccessEntry(door, steamID, playerNick)) then
                    return true
                end

                local steamID64 = targetPly:SteamID64() or ""
                if steamID64 ~= "" and select(1, VEIN.AccessLevels.ResolveAccessEntry(door, steamID64, playerNick)) then
                    return true
                end
            end
        end

        return false
    end
    
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply ~= LocalPlayer() then
            local playerNick = ply:Nick()
            -- Only add if they don't already have access
            if not PlayerAlreadyHasAccess(ply) then
                playerCombo:AddChoice(playerNick, {
                    key = GetAccessKeyForPlayer(ply),
                    name = playerNick,
                    steamID = ply:SteamID() or "",
                    steamID64 = ply:SteamID64() or "",
                })
            end
        end
    end

    playerCombo.OnSelect = function(_, _, _, data)
        selectedPlayerData = data
    end
    
    -- Access level selection
    local levelLabel = vgui.Create("DLabel", content)
    levelLabel:SetPos(20, 130)
    levelLabel:SetSize(innerW, 20)
    levelLabel:SetText("Access Level:")
    levelLabel:SetFont("DermaDefaultBold")
    levelLabel:SetTextColor(Color(200, 200, 205))
    
    local selectedLevel = nil -- NO DEFAULT - user must select!
    local guestTimeEnabled = false
    
    -- Check if player can add co-owners
    local myNick = LocalPlayer():Nick()
    local canAddCoOwner = VEIN.AccessLevels.CanAddCoOwner(door, myNick)
    
    local yPos = 155
    local levels = {
        {level = VEIN.AccessLevels.CO_OWNER, enabled = canAddCoOwner},
        {level = VEIN.AccessLevels.RESIDENT, enabled = true},
        {level = VEIN.AccessLevels.GUEST, enabled = true},
    }
    
    local levelButtons = {}
    
    for _, levelData in ipairs(levels) do
        local level = levelData.level
        local enabled = levelData.enabled
        
        local levelBtn = vgui.Create("DButton", content)
        levelBtn:SetPos(20, yPos)
        levelBtn:SetSize(innerW, 40) -- Increased from 35 to 40 for more space
        
        local info = VEIN.AccessLevels.Info[level]
        local levelColor = info.color
        local levelName = info.name
        local levelIcon = info.icon
        local levelDesc = info.description
        
        levelBtn:SetText("")
        levelBtn.Paint = function(self, w, h)
            local isSelected = (selectedLevel == level)
            local isHovered = self:IsHovered() and enabled
            
            local bgColor
            if not enabled then
                bgColor = Color(30, 30, 33, 150)
            elseif isSelected then
                bgColor = Color(levelColor.r * 0.3, levelColor.g * 0.3, levelColor.b * 0.3, 220)
            elseif isHovered then
                bgColor = Color(50, 50, 55, 200)
            else
                bgColor = Color(40, 40, 43, 180)
            end
            
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            
            if isSelected then
                surface.SetDrawColor(levelColor.r, levelColor.g, levelColor.b, 200)
                surface.DrawOutlinedRect(0, 0, w, h, 2)
                surface.DrawRect(0, 0, 5, h)
            elseif isHovered and enabled then
                surface.SetDrawColor(levelColor.r, levelColor.g, levelColor.b, 100)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            
            -- Text
            local textColor = enabled and (isSelected and levelColor or Color(200, 200, 205)) or Color(100, 100, 105)
            draw.SimpleText(levelIcon .. " " .. levelName, "DermaDefaultBold", 15, 8, textColor, TEXT_ALIGN_LEFT)
            draw.SimpleText(levelDesc, "DermaDefault", 15, 20, Color(textColor.r * 0.8, textColor.g * 0.8, textColor.b * 0.8), TEXT_ALIGN_LEFT)
        end
        
        levelButtons[level] = levelBtn
        yPos = yPos + 40
    end
    
    -- Guest time input (only for guests)
    local timeLabel = vgui.Create("DLabel", content)
    timeLabel:SetPos(20, yPos)
    timeLabel:SetSize(innerW, 20)
    timeLabel:SetText("Guest Duration (minutes):")
    timeLabel:SetFont("DermaDefaultBold")
    timeLabel:SetTextColor(Color(200, 200, 205))
    timeLabel:SetVisible(false)
    
    local timeEntry = vgui.Create("DTextEntry", content)
    timeEntry:SetPos(20, yPos + 25)
    timeEntry:SetSize(math.min(180, innerW), 30)
    timeEntry:SetPlaceholderText("30")
    timeEntry:SetNumeric(true) -- Only accept numbers!
    timeEntry:SetFont("DermaDefault")
    timeEntry:SetVisible(false)
    timeEntry.Paint = function(self, w, h)
        local bgColor = self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        local borderColor = self:HasFocus() and Color(255, 200, 100, 200) or Color(60, 60, 60, 150)
        surface.SetDrawColor(borderColor)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        self:DrawTextEntryText(Color(220, 220, 225), Color(255, 200, 100), Color(220, 220, 225))
    end
    
    -- Show/hide guest time based on selection
    local function UpdateGuestTimeVisibility()
        local isGuest = (selectedLevel == VEIN.AccessLevels.GUEST)
        timeLabel:SetVisible(isGuest)
        timeEntry:SetVisible(isGuest)
    end
    
    -- Now hook up the button clicks to update visibility
    for _, levelData in ipairs(levels) do
        local level = levelData.level
        local enabled = levelData.enabled
        
        if enabled then
            local btn = levelButtons[level]
            btn.DoClick = function()
                selectedLevel = level
                guestTimeEnabled = (level == VEIN.AccessLevels.GUEST)
                UpdateGuestTimeVisibility() -- Update immediately!
            end
        end
    end

    -- Optional one-time sync to linked/property doors
    local connectedDoorCount = #GetConnectedDoorsForPermissions(door)
    local canSyncConnected = connectedDoorCount > 1

    local syncCheck = vgui.Create("DCheckBoxLabel", content)
    syncCheck:SetPos(20, yPos + 65)
    syncCheck:SetSize(innerW, 20)
    syncCheck:SetText("Sync with connected doors (" .. connectedDoorCount .. " doors)")
    syncCheck:SetTextColor(canSyncConnected and Color(200, 200, 205) or Color(120, 120, 125))
    syncCheck:SetValue(false)
    syncCheck:SetEnabled(canSyncConnected)
    syncCheck:SizeToContents()
    
    -- Add/Cancel buttons
    local buttonY = dialogH - 50
    local buttonW = math.floor((innerW - 10) / 2)
    local addBtn = vgui.Create("DButton", content)
    addBtn:SetPos(20, buttonY)
    addBtn:SetSize(buttonW, 35)
    addBtn:SetText("Add Player")
    addBtn:SetFont("DermaDefaultBold")
    addBtn:SetTextColor(Color(200, 200, 205))
    addBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(60, 120, 60, 220) or Color(40, 80, 40, 200)
        draw.RoundedBox(6, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(120, 180, 120, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
        surface.SetDrawColor(100, 150, 100, isHovered and 160 or 120)
        surface.DrawRect(0, 0, 5, h)
    end
    addBtn.DoClick = function()
        local targetNick = playerCombo:GetValue()
        if targetNick == "Choose a player..." or targetNick == "" then
            VEIN.Notifications.Warning("No Player Selected", "Please choose a player first")
            return
        end

        local targetData = selectedPlayerData
        if not istable(targetData) then
            for _, ply in ipairs(player.GetAll()) do
                if IsValid(ply) and ply:Nick() == targetNick then
                    targetData = {
                        key = GetAccessKeyForPlayer(ply),
                        name = targetNick,
                        steamID = ply:SteamID() or "",
                        steamID64 = ply:SteamID64() or "",
                    }
                    break
                end
            end
        end
        targetData = targetData or {
            key = targetNick,
            name = targetNick,
            steamID = "",
            steamID64 = "",
        }
        
        -- Validate access level selection
        if not selectedLevel then
            VEIN.Notifications.Warning("No Level Selected", "Please select an access level first")
            return
        end
        
        -- Validate guest time if needed
        local expirationMinutes = 0
        if selectedLevel == VEIN.AccessLevels.GUEST then
            expirationMinutes = tonumber(timeEntry:GetValue())
            if not expirationMinutes or expirationMinutes <= 0 then
                VEIN.Notifications.Warning("Invalid Time", "Please enter a positive number of minutes")
                return
            end
        end
        
        -- Send to server
        net.Start("VEIN_AL_SetAccessLevel")
        net.WriteEntity(door)
        net.WriteString(targetData.key or targetNick)
        net.WriteString(targetData.name or targetNick)
        net.WriteString(targetData.steamID or "")
        net.WriteString(targetData.steamID64 or "")
        net.WriteString(selectedLevel)
        net.WriteUInt(expirationMinutes, 16)
        net.WriteBool(canSyncConnected and syncCheck:GetChecked())
        net.WriteBool(false)
        net.SendToServer()
        
        surface.PlaySound("buttons/button15.wav")
        dialog:Close()
        
        -- Refresh parent
        timer.Simple(0.3, function()
            if IsValid(parentFrame) and parentFrame.RefreshPermissions then
                parentFrame.RefreshPermissions()
            end
        end)
    end
    
    local cancelBtn = vgui.Create("DButton", content)
    cancelBtn:SetPos(20 + buttonW + 10, buttonY)
    cancelBtn:SetSize(buttonW, 35)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetFont("DermaDefaultBold")
    cancelBtn:SetTextColor(Color(200, 200, 205))
    cancelBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(60, 35, 35, 220) or Color(40, 25, 25, 200)
        draw.RoundedBox(6, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(180, 80, 80, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
    end
    cancelBtn.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        dialog:Close()
    end
end

-- Change Access Level Dialog
DoorGUI.OpenChangeLevelDialog = function(door, targetKey, targetName, currentLevel, parentFrame, targetSteamID, targetSteamID64)
    local dialog = vgui.Create("DFrame")
    local baseW, baseH = 450, 430
    local dialogW = math.max(320, math.min(baseW, ScrW() - 80))
    local dialogH = math.max(320, math.min(baseH, ScrH() - 80))
    dialog:SetSize(dialogW, dialogH)
    dialog:Center()
    dialog:SetTitle("")
    dialog:SetDraggable(false)
    dialog:ShowCloseButton(false)
    dialog:MakePopup()
    
    dialog.Paint = function(self, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
        surface.SetDrawColor(120, 40, 40, 180)
        surface.DrawOutlinedRect(0, 0, w, h, 2)
        surface.SetDrawColor(180, 60, 60, 120)
        surface.DrawRect(12, 12, w - 24, 2)
    end

    local content = vgui.Create("DPanel", dialog)
    content:SetPos(0, 0)
    content:SetSize(dialogW, dialogH)
    content.Paint = function() end

    local innerW = dialogW - 40
    local connectedDoorCount = #GetConnectedDoorsForPermissions(door)
    local canSyncConnected = connectedDoorCount > 1
    
    -- Title
    local title = vgui.Create("DLabel", content)
    title:SetPos(15, 20)
    title:SetSize(dialogW - 30, 30)
    title:SetText("Change Access Level: " .. (targetName or targetKey or "Unknown"))
    title:SetFont("DermaLarge")
    title:SetTextColor(Color(220, 220, 225))
    
    -- Current level display
    local currentInfo = VEIN.AccessLevels.Info[currentLevel]
    local currentLabel = vgui.Create("DLabel", content)
    currentLabel:SetPos(20, 60)
    currentLabel:SetSize(innerW, 20)
    currentLabel:SetText("Current Level: " .. currentInfo.icon .. " " .. currentInfo.name)
    currentLabel:SetFont("DermaDefaultBold")
    currentLabel:SetTextColor(currentInfo.color)
    
    -- New level selection
    local newLabel = vgui.Create("DLabel", content)
    newLabel:SetPos(20, 90)
    newLabel:SetSize(innerW, 20)
    newLabel:SetText("New Access Level:")
    newLabel:SetFont("DermaDefaultBold")
    newLabel:SetTextColor(Color(200, 200, 205))
    
    local selectedLevel = currentLevel
    
    -- Check permissions
    local myNick = LocalPlayer():Nick()
    local canAddCoOwner = VEIN.AccessLevels.CanAddCoOwner(door, myNick)
    
    local yPos = 115
    local levels = {
        {level = VEIN.AccessLevels.CO_OWNER, enabled = canAddCoOwner},
        {level = VEIN.AccessLevels.RESIDENT, enabled = true},
        {level = VEIN.AccessLevels.GUEST, enabled = true},
    }
    
    local levelButtons = {}
    
    for _, levelData in ipairs(levels) do
        local level = levelData.level
        local enabled = levelData.enabled and (level ~= currentLevel) -- Can't change to same level
        
        local levelBtn = vgui.Create("DButton", content)
        levelBtn:SetPos(20, yPos)
        levelBtn:SetSize(innerW, 35)
        
        local info = VEIN.AccessLevels.Info[level]
        local levelColor = info.color
        local levelName = info.name
        local levelIcon = info.icon
        
        levelBtn:SetText("")
        levelBtn.Paint = function(self, w, h)
            local isSelected = (selectedLevel == level and level ~= currentLevel)
            local isHovered = self:IsHovered() and enabled
            local isCurrent = (level == currentLevel)
            
            local bgColor
            if isCurrent then
                bgColor = Color(30, 30, 33, 150)
            elseif not enabled then
                bgColor = Color(30, 30, 33, 150)
            elseif isSelected then
                bgColor = Color(levelColor.r * 0.3, levelColor.g * 0.3, levelColor.b * 0.3, 220)
            elseif isHovered then
                bgColor = Color(50, 50, 55, 200)
            else
                bgColor = Color(40, 40, 43, 180)
            end
            
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            
            if isSelected then
                surface.SetDrawColor(levelColor.r, levelColor.g, levelColor.b, 200)
                surface.DrawOutlinedRect(0, 0, w, h, 2)
                surface.DrawRect(0, 0, 5, h)
            elseif isHovered and enabled then
                surface.SetDrawColor(levelColor.r, levelColor.g, levelColor.b, 100)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            
            -- Text
            local textColor = enabled and (isSelected and levelColor or Color(200, 200, 205)) or Color(100, 100, 105)
            local suffix = isCurrent and " (Current)" or ""
            draw.SimpleText(levelIcon .. " " .. levelName .. suffix, "DermaDefaultBold", 15, 10, textColor, TEXT_ALIGN_LEFT)
        end
        
        levelButtons[level] = levelBtn
        yPos = yPos + 40
    end
    
    -- Guest time input (only for guests)
    local timeLabel = vgui.Create("DLabel", content)
    timeLabel:SetPos(20, yPos)
    timeLabel:SetSize(innerW, 20)
    timeLabel:SetText("Guest Duration (minutes):")
    timeLabel:SetFont("DermaDefaultBold")
    timeLabel:SetTextColor(Color(200, 200, 205))
    timeLabel:SetVisible(false)
    
    local timeEntry = vgui.Create("DTextEntry", content)
    timeEntry:SetPos(20, yPos + 25)
    timeEntry:SetSize(math.min(180, innerW), 30)
    timeEntry:SetPlaceholderText("30")
    timeEntry:SetNumeric(true)
    timeEntry:SetFont("DermaDefault")
    timeEntry:SetVisible(false)
    timeEntry.Paint = function(self, w, h)
        local bgColor = self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)
        draw.RoundedBox(4, 0, 0, w, h, bgColor)
        local borderColor = self:HasFocus() and Color(255, 200, 100, 200) or Color(60, 60, 60, 150)
        surface.SetDrawColor(borderColor)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        self:DrawTextEntryText(Color(220, 220, 225), Color(255, 200, 100), Color(220, 220, 225))
    end
    
    -- Show/hide guest time based on selection
    local function UpdateGuestTimeVisibility()
        local isGuest = (selectedLevel == VEIN.AccessLevels.GUEST)
        timeLabel:SetVisible(isGuest)
        timeEntry:SetVisible(isGuest)
    end
    
    -- Hook up button clicks to update visibility
    for _, levelData in ipairs(levels) do
        local level = levelData.level
        local enabled = levelData.enabled and (level ~= currentLevel)
        
        if enabled then
            local btn = levelButtons[level]
            btn.DoClick = function()
                selectedLevel = level
                UpdateGuestTimeVisibility()
            end
        end
    end

    local syncCheck = vgui.Create("DCheckBoxLabel", content)
    syncCheck:SetPos(20, yPos + 60)
    syncCheck:SetSize(innerW, 20)
    syncCheck:SetText("Sync with connected doors (" .. connectedDoorCount .. " doors)")
    syncCheck:SetTextColor(canSyncConnected and Color(200, 200, 205) or Color(120, 120, 125))
    syncCheck:SetValue(false)
    syncCheck:SetEnabled(canSyncConnected)
    syncCheck:SizeToContents()

    local unsyncCheck = vgui.Create("DCheckBoxLabel", content)
    unsyncCheck:SetPos(20, yPos + 84)
    unsyncCheck:SetSize(innerW, 20)
    unsyncCheck:SetText("Unsync from connected doors (remove from others)")
    unsyncCheck:SetTextColor(canSyncConnected and Color(200, 200, 205) or Color(120, 120, 125))
    unsyncCheck:SetValue(false)
    unsyncCheck:SetEnabled(canSyncConnected)
    unsyncCheck:SizeToContents()

    if canSyncConnected then
        syncCheck.OnChange = function(_, checked)
            if checked and unsyncCheck:GetChecked() then
                unsyncCheck:SetValue(false)
            end
        end
        unsyncCheck.OnChange = function(_, checked)
            if checked and syncCheck:GetChecked() then
                syncCheck:SetValue(false)
            end
        end
    end
    
    -- Save/Cancel buttons
    local buttonY = dialogH - 50
    local buttonW = math.floor((innerW - 10) / 2)
    local saveBtn = vgui.Create("DButton", content)
    saveBtn:SetPos(20, buttonY)
    saveBtn:SetSize(buttonW, 35)
    saveBtn:SetText("Save Changes")
    saveBtn:SetFont("DermaDefaultBold")
    saveBtn:SetTextColor(Color(200, 200, 205))
    saveBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(60, 120, 60, 220) or Color(40, 80, 40, 200)
        draw.RoundedBox(6, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(120, 180, 120, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
        surface.SetDrawColor(100, 150, 100, isHovered and 160 or 120)
        surface.DrawRect(0, 0, 5, h)
    end
    saveBtn.DoClick = function()
        local doSyncConnected = canSyncConnected and syncCheck:GetChecked()
        local doUnsyncConnected = canSyncConnected and unsyncCheck:GetChecked()

        if selectedLevel == currentLevel and not doSyncConnected and not doUnsyncConnected then
            VEIN.Notifications.Warning("No Change", "Please select a different access level")
            return
        end
        
        -- Validate guest time if needed
        local expirationMinutes = 0
        local needsGuestDuration = selectedLevel == VEIN.AccessLevels.GUEST and (selectedLevel ~= currentLevel or doSyncConnected)
        if needsGuestDuration then
            expirationMinutes = tonumber(timeEntry:GetValue())
            if not expirationMinutes or expirationMinutes <= 0 then
                VEIN.Notifications.Warning("Invalid Time", "Please enter a positive number of minutes for guest access")
                return
            end
        end
        
        -- Send to server
        net.Start("VEIN_AL_SetAccessLevel")
        net.WriteEntity(door)
        net.WriteString(targetKey or targetName or "")
        net.WriteString(targetName or targetKey or "")
        net.WriteString(targetSteamID or "")
        net.WriteString(targetSteamID64 or "")
        net.WriteString(selectedLevel)
        net.WriteUInt(expirationMinutes, 16)
        net.WriteBool(doSyncConnected)
        net.WriteBool(doUnsyncConnected)
        net.SendToServer()
        
        surface.PlaySound("buttons/button15.wav")
        dialog:Close()
        
        -- Refresh parent
        timer.Simple(0.3, function()
            if IsValid(parentFrame) and parentFrame.RefreshPermissions then
                parentFrame.RefreshPermissions()
            end
        end)
    end
    
    local cancelBtn = vgui.Create("DButton", content)
    cancelBtn:SetPos(20 + buttonW + 10, buttonY)
    cancelBtn:SetSize(buttonW, 35)
    cancelBtn:SetText("Cancel")
    cancelBtn:SetFont("DermaDefaultBold")
    cancelBtn:SetTextColor(Color(200, 200, 205))
    cancelBtn.Paint = function(self, w, h)
        local isHovered = self:IsHovered()
        local bgColor = isHovered and Color(60, 35, 35, 220) or Color(40, 25, 25, 200)
        draw.RoundedBox(6, 0, 0, w, h, bgColor)
        if isHovered then
            surface.SetDrawColor(180, 80, 80, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
    end
    cancelBtn.DoClick = function()
        surface.PlaySound("buttons/button15.wav")
        dialog:Close()
    end
end

-- Hooks - Only need hologram rendering now
hook.Add("PostDrawTranslucentRenderables", "VEIN_DrawDoorHolograms", DrawDoorHolograms)


