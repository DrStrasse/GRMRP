--[[
================================================================================
VEIN Door System - Linked Door Groups
Supports linking multiple doors and keeps group stats in sync.
================================================================================
]]--

if CLIENT then return end

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.DoorSystem = VEIN.DoorSystem or {}

VEIN.DoorSystem.LinkedGroups = VEIN.DoorSystem.LinkedGroups or {}
VEIN.DoorSystem.NextLinkGroupId = VEIN.DoorSystem.NextLinkGroupId or 1

local function setDoorLinkStats(door, count, totalPrice)
    if not IsValid(door) then return end
    door:SetNWInt("VEIN_LinkCount", count or 1)
    door:SetNWInt("VEIN_LinkTotalPrice", totalPrice or door:GetNWInt("VEIN_Price", 0))
end

local function normalizeGroup(groupId)
    local group = VEIN.DoorSystem.LinkedGroups[groupId]
    if not group then return end

    local valid = {}
    local total = 0
    for _, ent in ipairs(group) do
        if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) then
            table.insert(valid, ent)
            total = total + ent:GetNWInt("VEIN_Price", 0)
        end
    end

    if #valid < 2 then
        for _, ent in ipairs(valid) do
            ent:SetNWInt("VEIN_LinkGroup", 0)
            setDoorLinkStats(ent, 1, ent:GetNWInt("VEIN_Price", 0))
        end
        VEIN.DoorSystem.LinkedGroups[groupId] = nil
        return
    end

    VEIN.DoorSystem.LinkedGroups[groupId] = valid
    for _, ent in ipairs(valid) do
        ent:SetNWInt("VEIN_LinkGroup", groupId)
        ent:SetNWEntity("VEIN_LinkedDoor", NULL)
        setDoorLinkStats(ent, #valid, total)
    end
end

function VEIN.DoorSystem.GetLinkedGroupId(door)
    if not IsValid(door) then return 0 end
    return door:GetNWInt("VEIN_LinkGroup", 0)
end

function VEIN.DoorSystem.GetLinkedDoors(door)
    if not IsValid(door) then return {} end
    local groupId = VEIN.DoorSystem.GetLinkedGroupId(door)
    if groupId <= 0 then return {} end

    local group = VEIN.DoorSystem.LinkedGroups[groupId] or {}
    local linked = {}
    for _, ent in ipairs(group) do
        if IsValid(ent) and ent ~= door then
            table.insert(linked, ent)
        end
    end
    return linked
end

function VEIN.DoorSystem.GetLinkedGroup(door)
    if not IsValid(door) then return {} end
    local groupId = VEIN.DoorSystem.GetLinkedGroupId(door)
    if groupId <= 0 then return {door} end
    return VEIN.DoorSystem.LinkedGroups[groupId] or {door}
end

function VEIN.DoorSystem.UpdateLinkGroupStats(groupId)
    if not groupId or groupId <= 0 then return end
    normalizeGroup(groupId)
end

function VEIN.DoorSystem.UpdateDoorLinkStats(door)
    if not IsValid(door) then return end
    local groupId = VEIN.DoorSystem.GetLinkedGroupId(door)
    if groupId > 0 then
        normalizeGroup(groupId)
    else
        setDoorLinkStats(door, 1, door:GetNWInt("VEIN_Price", 0))
    end
end

function VEIN.DoorSystem.LinkDoors(firstDoor, secondDoor)
    if not IsValid(firstDoor) or not IsValid(secondDoor) then return false, "Invalid door" end
    if firstDoor == secondDoor then return false, "Same door" end
    if not firstDoor:GetNWBool("VEIN_IsVEINDoor", false) or not secondDoor:GetNWBool("VEIN_IsVEINDoor", false) then
        return false, "Both doors must be VEIN doors"
    end

    -- Clear legacy single-link to avoid conflicts
    if IsValid(firstDoor:GetNWEntity("VEIN_LinkedDoor", NULL)) then
        firstDoor:SetNWEntity("VEIN_LinkedDoor", NULL)
    end
    if IsValid(secondDoor:GetNWEntity("VEIN_LinkedDoor", NULL)) then
        secondDoor:SetNWEntity("VEIN_LinkedDoor", NULL)
    end

    local groupA = VEIN.DoorSystem.GetLinkedGroupId(firstDoor)
    local groupB = VEIN.DoorSystem.GetLinkedGroupId(secondDoor)

    if groupA > 0 and groupA == groupB then
        return false, "Already linked"
    end

    -- No groups yet: create new
    if groupA <= 0 and groupB <= 0 then
        local newId = VEIN.DoorSystem.NextLinkGroupId
        VEIN.DoorSystem.NextLinkGroupId = VEIN.DoorSystem.NextLinkGroupId + 1
        VEIN.DoorSystem.LinkedGroups[newId] = {firstDoor, secondDoor}
        normalizeGroup(newId)
        return true, newId
    end

    -- Add one door to existing group
    if groupA > 0 and groupB <= 0 then
        VEIN.DoorSystem.LinkedGroups[groupA] = VEIN.DoorSystem.LinkedGroups[groupA] or {}
        table.insert(VEIN.DoorSystem.LinkedGroups[groupA], secondDoor)
        normalizeGroup(groupA)
        return true, groupA
    end

    if groupB > 0 and groupA <= 0 then
        VEIN.DoorSystem.LinkedGroups[groupB] = VEIN.DoorSystem.LinkedGroups[groupB] or {}
        table.insert(VEIN.DoorSystem.LinkedGroups[groupB], firstDoor)
        normalizeGroup(groupB)
        return true, groupB
    end

    -- Merge groups
    if groupA > 0 and groupB > 0 and groupA ~= groupB then
        VEIN.DoorSystem.LinkedGroups[groupA] = VEIN.DoorSystem.LinkedGroups[groupA] or {}
        for _, ent in ipairs(VEIN.DoorSystem.LinkedGroups[groupB] or {}) do
            table.insert(VEIN.DoorSystem.LinkedGroups[groupA], ent)
        end
        VEIN.DoorSystem.LinkedGroups[groupB] = nil
        normalizeGroup(groupA)
        return true, groupA
    end

    return false, "Unknown"
end

function VEIN.DoorSystem.UnlinkDoor(door)
    if not IsValid(door) then return end
    door:SetNWEntity("VEIN_LinkedDoor", NULL)
    local groupId = VEIN.DoorSystem.GetLinkedGroupId(door)
    if groupId <= 0 then
        setDoorLinkStats(door, 1, door:GetNWInt("VEIN_Price", 0))
        return
    end

    local group = VEIN.DoorSystem.LinkedGroups[groupId]
    if not group then
        door:SetNWInt("VEIN_LinkGroup", 0)
        setDoorLinkStats(door, 1, door:GetNWInt("VEIN_Price", 0))
        return
    end

    for i = #group, 1, -1 do
        if group[i] == door or not IsValid(group[i]) then
            table.remove(group, i)
        end
    end

    door:SetNWInt("VEIN_LinkGroup", 0)
    setDoorLinkStats(door, 1, door:GetNWInt("VEIN_Price", 0))

    normalizeGroup(groupId)
end

function VEIN.DoorSystem.RebuildLinkGroupsFromDoors()
    VEIN.DoorSystem.LinkedGroups = {}
    local maxId = 0

    local doorsById = {}
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
            local groupId = door:GetNWInt("VEIN_LinkGroup", 0)
            if groupId > 0 then
                VEIN.DoorSystem.LinkedGroups[groupId] = VEIN.DoorSystem.LinkedGroups[groupId] or {}
                table.insert(VEIN.DoorSystem.LinkedGroups[groupId], door)
                if groupId > maxId then maxId = groupId end
            end
        end
    end

    VEIN.DoorSystem.NextLinkGroupId = maxId + 1

    -- Migrate legacy single-link data (if any)
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
            local groupId = door:GetNWInt("VEIN_LinkGroup", 0)
            if groupId <= 0 then
                local legacy = door:GetNWEntity("VEIN_LinkedDoor", NULL)
                if IsValid(legacy) and legacy:GetNWBool("VEIN_IsVEINDoor", false) then
                    VEIN.DoorSystem.LinkDoors(door, legacy)
                end
            end
        end
    end

    for groupId, _ in pairs(VEIN.DoorSystem.LinkedGroups) do
        normalizeGroup(groupId)
    end

    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
            VEIN.DoorSystem.UpdateDoorLinkStats(door)
        end
    end
end

hook.Add("VEIN_DoorCreated", "VEIN_UpdateLinkStatsOnCreate", function(door)
    if IsValid(door) then
        VEIN.DoorSystem.UpdateDoorLinkStats(door)
    end
end)

hook.Add("VEIN_DoorModified", "VEIN_UpdateLinkStatsOnModify", function(door)
    if IsValid(door) then
        VEIN.DoorSystem.UpdateDoorLinkStats(door)
    end
end)

hook.Add("VEIN_OnDoorModified", "VEIN_UpdateLinkStatsOnModify2", function(door)
    if IsValid(door) then
        VEIN.DoorSystem.UpdateDoorLinkStats(door)
    end
end)


