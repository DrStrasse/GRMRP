--[[
================================================================================
VEIN Door System - Server Settings Management
Handles configuration, door limits, data persistence
================================================================================
]]--

if CLIENT then return end

-- Initialize VEIN namespace
VEIN = VEIN or {}
local VEIN = VEIN
VEIN.Settings = VEIN.Settings or {}
VEIN.Settings.PlayerDoorLimits = VEIN.Settings.PlayerDoorLimits or {}
VEIN.Net = VEIN.Net or {}

local Net = VEIN.Net

-- Server ConVars for settings (ADMIN ONLY - Protected from player changes)
-- AUTO-DETECT DARKRP: Default to 0 if DarkRP loaded, 1 otherwise
local defaultMoneySystem = DarkRP and "0" or "1"
CreateConVar("vein_use_custom_money", defaultMoneySystem, bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY), "Use VEIN custom money system (1) or DarkRP money (0) [ADMIN ONLY]")
CreateConVar("vein_default_door_limit", "3", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY), "Default number of doors a player can own [ADMIN ONLY]")
CreateConVar("vein_enable_door_limits", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY), "Enable door ownership limits (1) or unlimited (0) [ADMIN ONLY]")
CreateConVar("vein_lock_time", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY), "Time in seconds to lock/unlock a door (0 = instant) [ADMIN ONLY]")
CreateConVar("vein_enable_door_kicking", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_NOTIFY), "Enable door kicking (1) or disable completely (0) [ADMIN ONLY]")

-- Data file paths
local DATA_FOLDER = "vein_door_system"
local SETTINGS_FILE = DATA_FOLDER .. "/settings.txt"
local DOOR_LIMITS_FILE = DATA_FOLDER .. "/door_limits.txt"

-- Ensure data folder exists
if not file.Exists(DATA_FOLDER, "DATA") then
    file.CreateDir(DATA_FOLDER)
end

-- Save settings to file (defined early so it can be used in CheckAndFixMoneySystem)
local function SaveSettings()
    local settingsData = {
        use_custom_money = GetConVar("vein_use_custom_money"):GetBool(),
        default_door_limit = GetConVar("vein_default_door_limit"):GetInt(),
        enable_door_limits = GetConVar("vein_enable_door_limits"):GetBool(),
        lock_time = GetConVar("vein_lock_time"):GetFloat(),
        enable_door_kicking = GetConVar("vein_enable_door_kicking"):GetBool()
    }
    
    file.Write(SETTINGS_FILE, util.TableToJSON(settingsData, true))
end

-- Force override based on gamemode (runs on startup and gamemode changes)
local function CheckAndFixMoneySystem()
    local cv = GetConVar("vein_use_custom_money")
    if not cv then return end
    
    if DarkRP and cv:GetInt() ~= 0 then
        print("[VEIN] DarkRP detected! Force-setting money system to DarkRP (0)")
        cv:SetInt(0)
        SaveSettings() -- Save the change
    elseif not DarkRP and cv:GetInt() == 0 then
        print("[VEIN] Non-DarkRP gamemode detected! Force-setting money system to VEIN Custom (1)")
        cv:SetInt(1)
        SaveSettings() -- Save the change
    end
end

-- Block non-admins from changing VEIN ConVars
local protectedCVarLookup = {
    vein_use_custom_money = true,
    vein_default_door_limit = true,
    vein_enable_door_limits = true,
    vein_lock_time = true,
    vein_enable_door_kicking = true,
}

hook.Add("CanChangeConvar", "VEIN_ProtectSettings", function(ply, cvarName, oldValue, newValue)
    -- Check if this is a VEIN ConVar
    if protectedCVarLookup[cvarName] then
        -- Allow if player is admin or if being changed by server/console
        if not IsValid(ply) or ply:IsAdmin() or ply:IsSuperAdmin() then
            return true -- Allow change
        else
            -- Block non-admin players
            if IsValid(ply) then
                VEIN.Chat(ply, "Only administrators can change VEIN settings!")
            end
            return false -- Block change
        end
    end
end)

-- Run check on initialization
timer.Simple(0.1, CheckAndFixMoneySystem)

-- Also check when settings are loaded (in case of gamemode change)
hook.Add("Initialize", "VEIN_CheckMoneySystem", function()
    timer.Simple(1, CheckAndFixMoneySystem)
end)

-- Check periodically for gamemode changes (DarkRP might load late)
timer.Create("VEIN_MoneySystemCheck", 5, 0, function()
    CheckAndFixMoneySystem()
end)

-- Load settings from file
local function LoadSettings()
    if file.Exists(SETTINGS_FILE, "DATA") then
        local settingsJSON = file.Read(SETTINGS_FILE, "DATA")
        local settingsData = util.JSONToTable(settingsJSON)
        
        if settingsData then
            RunConsoleCommand("vein_use_custom_money", settingsData.use_custom_money and "1" or "0")
            RunConsoleCommand("vein_default_door_limit", tostring(settingsData.default_door_limit or 3))
            RunConsoleCommand("vein_enable_door_limits", settingsData.enable_door_limits and "1" or "0")
            RunConsoleCommand("vein_lock_time", tostring(settingsData.lock_time or 1))
            
            -- Handle enable_door_kicking with backward compatibility (defaults to true if not in file)
            if settingsData.enable_door_kicking ~= nil then
                RunConsoleCommand("vein_enable_door_kicking", settingsData.enable_door_kicking and "1" or "0")
            end
            
            print("[VEIN] Settings loaded from data file")
        end
    else
        print("[VEIN] No settings file found, using defaults")
    end
end

-- Save player door limits to file
local function SaveDoorLimits()
    file.Write(DOOR_LIMITS_FILE, util.TableToJSON(VEIN.Settings.PlayerDoorLimits, true))
    print("[VEIN] Player door limits saved")
end

-- Load player door limits from file
local function LoadDoorLimits()
    if file.Exists(DOOR_LIMITS_FILE, "DATA") then
        local limitsJSON = file.Read(DOOR_LIMITS_FILE, "DATA")
        local limitsData = util.JSONToTable(limitsJSON)
        
        if limitsData then
            VEIN.Settings.PlayerDoorLimits = limitsData
            print("[VEIN] Player door limits loaded: " .. table.Count(limitsData) .. " custom limits")
        end
    else
        print("[VEIN] No door limits file found, using defaults")
    end
end

-- Get door limit for specific player
function VEIN.Settings.GetPlayerDoorLimit(ply)
    if not GetConVar("vein_enable_door_limits"):GetBool() then
        return 999999 -- Unlimited
    end
    
    -- Get unique ID (different for bots vs players)
    local uniqueID
    if ply:IsBot() then
        uniqueID = "BOT_" .. ply:Nick() -- Unique per bot name
    else
        uniqueID = ply:SteamID() -- Normal SteamID
    end
    
    local customLimit = VEIN.Settings.PlayerDoorLimits[uniqueID]
    
    if customLimit then
        return customLimit
    else
        return GetConVar("vein_default_door_limit"):GetInt()
    end
end

-- Set door limit for specific player
function VEIN.Settings.SetPlayerDoorLimit(uniqueID, limit)
    VEIN.Settings.PlayerDoorLimits[uniqueID] = limit
    SaveDoorLimits()
    
    -- Notify online player if they're connected
    local ply
    if string.StartWith(uniqueID, "BOT_") then
        -- For bots, find by name
        local botName = string.sub(uniqueID, 5) -- Remove "BOT_" prefix
        for _, p in ipairs(player.GetAll()) do
            if p:IsBot() and p:Nick() == botName then
                ply = p
                break
            end
        end
    else
        -- For players, find by SteamID
        ply = player.GetBySteamID(uniqueID)
    end
    
    if IsValid(ply) then
        VEIN.Chat(ply, "Your door limit has been set to " .. limit .. " doors")
    end
end

-- Remove custom door limit (revert to default)
function VEIN.Settings.RemovePlayerDoorLimit(uniqueID)
    VEIN.Settings.PlayerDoorLimits[uniqueID] = nil
    SaveDoorLimits()
    
    -- Notify online player if they're connected
    local ply
    if string.StartWith(uniqueID, "BOT_") then
        -- For bots, find by name
        local botName = string.sub(uniqueID, 5) -- Remove "BOT_" prefix
        for _, p in ipairs(player.GetAll()) do
            if p:IsBot() and p:Nick() == botName then
                ply = p
                break
            end
        end
    else
        -- For players, find by SteamID
        ply = player.GetBySteamID(uniqueID)
    end
    
    if IsValid(ply) then
        local defaultLimit = GetConVar("vein_default_door_limit"):GetInt()
        VEIN.Chat(ply, "Your door limit reverted to default: " .. defaultLimit .. " doors")
    end
end

-- Count how many doors a player owns
function VEIN.Settings.CountPlayerDoors(ply)
    local count = 0
    local playerSteamID = ply:SteamID()
    
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetNWString("VEIN_Owner", "") == playerSteamID then
            count = count + 1
        end
    end
    
    return count
end

-- Check if player can own more doors
function VEIN.Settings.CanPlayerOwnMoreDoors(ply)
    local currentDoors = VEIN.Settings.CountPlayerDoors(ply)
    local maxDoors = VEIN.Settings.GetPlayerDoorLimit(ply)
    
    return currentDoors < maxDoors
end

-- Network strings for client communication
util.AddNetworkString("VEIN_UpdateSettings")
util.AddNetworkString("VEIN_UpdateDoorLimit")
util.AddNetworkString("VEIN_RequestSettings")
util.AddNetworkString("VEIN_GetPlayerList")

-- Handle settings updates from client (admin only)
net.Receive("VEIN_UpdateSettings", function(len, ply)
    if not ply:IsAdmin() then
        VEIN.Chat(ply, "Access denied - Admin required")
        return
    end
    
    local useCustomMoney = net.ReadBool()
    local defaultLimit = net.ReadInt(16)
    local enableLimits = net.ReadBool()
    
    -- Update ConVars
    RunConsoleCommand("vein_use_custom_money", useCustomMoney and "1" or "0")
    RunConsoleCommand("vein_default_door_limit", tostring(defaultLimit))
    RunConsoleCommand("vein_enable_door_limits", enableLimits and "1" or "0")
    
    SaveSettings()
    
    VEIN.Chat(ply, "Settings updated successfully")
end)

-- Handle door limit updates from client (admin only)
net.Receive("VEIN_UpdateDoorLimit", function(len, ply)
    if not ply:IsAdmin() then
        VEIN.Chat(ply, "Access denied - Admin required")
        return
    end
    
    local targetSteamID = net.ReadString()
    local newLimit = net.ReadInt(16)
    local remove = net.ReadBool()
    
    if remove then
        VEIN.Settings.RemovePlayerDoorLimit(targetSteamID)
        VEIN.Chat(ply, "Door limit removed for " .. targetSteamID)
    else
        VEIN.Settings.SetPlayerDoorLimit(targetSteamID, newLimit)
        VEIN.Chat(ply, "Door limit set to " .. newLimit .. " for " .. targetSteamID)
    end
end)

-- Send current settings to requesting client (admin only)
net.Receive("VEIN_RequestSettings", function(len, ply)
    if not ply:IsAdmin() then
        return
    end
    
    net.Start("VEIN_UpdateSettings")
        net.WriteBool(GetConVar("vein_use_custom_money"):GetBool())
        net.WriteInt(GetConVar("vein_default_door_limit"):GetInt(), 16)
        net.WriteBool(GetConVar("vein_enable_door_limits"):GetBool())
        
        -- Send player door limits
        Net.WriteStringIntMap(VEIN.Settings.PlayerDoorLimits, 16)
    net.Send(ply)
end)

-- Send player list to requesting client (admin only)
net.Receive("VEIN_GetPlayerList", function(len, ply)
    if not ply:IsAdmin() then
        return
    end
    
    local playerData = {}
    for _, p in ipairs(player.GetAll()) do
        -- Use unique ID for bots (BOT + name) since all bots share SteamID "BOT"
        local uniqueID
        if p:IsBot() then
            uniqueID = "BOT_" .. p:Nick() -- Unique per bot name
        else
            uniqueID = p:SteamID() -- Normal SteamID for players
        end
        
        table.insert(playerData, {
            name = p:Nick(),
            steamid = uniqueID, -- Now unique even for bots
            doors = VEIN.Settings.CountPlayerDoors(p),
            limit = VEIN.Settings.GetPlayerDoorLimit(p),
            isBot = p:IsBot() -- Flag so client knows it's a bot
        })
    end
    
    local list = {}
    for _, entry in ipairs(playerData) do
        table.insert(list, {
            name = entry.name,
            steamid = entry.steamid,
            ownedDoors = entry.doors,
            defaultLimit = entry.limit,
            customLimit = nil
        })
    end
    
    net.Start("VEIN_GetPlayerList")
        Net.WritePlayerList(list)
    net.Send(ply)
end)

-- ConVar change callbacks to auto-save
cvars.AddChangeCallback("vein_use_custom_money", SaveSettings)
cvars.AddChangeCallback("vein_default_door_limit", SaveSettings)
cvars.AddChangeCallback("vein_enable_door_limits", SaveSettings)
cvars.AddChangeCallback("vein_lock_time", SaveSettings)
cvars.AddChangeCallback("vein_enable_door_kicking", SaveSettings)

-- Load settings on server start
hook.Add("Initialize", "VEIN_LoadSettings", function()
    LoadSettings()
    LoadDoorLimits()
end)

-- Clean up auto-lock timers when doors are removed
hook.Add("EntityRemoved", "VEIN_CleanupAutoLock", function(ent)
    if IsValid(ent) then
        local class = ent:GetClass()
        local isDoor = (class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating")
        
        if isDoor then
            local timerName = "VEIN_AutoLock_" .. ent:EntIndex()
            if timer.Exists(timerName) then
                timer.Remove(timerName)
            end
        end
    end
end)


