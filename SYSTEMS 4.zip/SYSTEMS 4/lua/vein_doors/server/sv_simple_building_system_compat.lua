--[[
================================================================================
VEIN Door System - Simple Building System compatibility
Converts SBS-built doors into VEIN doors when the SBS addon is actually loaded
================================================================================
]]--

if CLIENT then return end

VEIN = VEIN or {}
VEIN.DoorSystem = VEIN.DoorSystem or {}
VEIN.SBSCompat = VEIN.SBSCompat or {}

local cvEnabled = CreateConVar(
    "vein_sbs_compat_enabled",
    "1",
    FCVAR_ARCHIVE,
    "Enable automatic VEIN compatibility for Simple Building System doors"
)

local cvDefaultPrice = CreateConVar(
    "vein_sbs_default_price",
    "150",
    FCVAR_ARCHIVE,
    "Default VEIN price for Simple Building System doors"
)

local cvDefaultType = CreateConVar(
    "vein_sbs_default_type",
    "Residential",
    FCVAR_ARCHIVE,
    "Default VEIN door type for Simple Building System doors"
)

local cvDefaultMaterial = CreateConVar(
    "vein_sbs_default_material",
    "Wood Door",
    FCVAR_ARCHIVE,
    "Default VEIN door material for Simple Building System doors"
)

local cvStartLocked = CreateConVar(
    "vein_sbs_start_locked",
    "0",
    FCVAR_ARCHIVE,
    "Whether Simple Building System doors start locked when converted to VEIN"
)

local function IsValidPlayer(ent)
    return IsValid(ent) and ent:IsPlayer()
end

local function IsSBSAvailable()
    if not cvEnabled:GetBool() then return false end
    if not GetConVar("build_use_normal_props") then return false end
    if not istable(BuildConf) or not istable(BuildConf.DoorAllowed) then return false end
    if not scripted_ents.GetStored or not scripted_ents.GetStored("build_prop") then return false end
    if weapons.GetStored and weapons.GetStored("builder") then return true end
    if weapons.Get and weapons.Get("builder") then return true end
    return false
end

local function IsSBSBuildPiece(ent)
    if not IsValid(ent) then return false end
    local class = ent:GetClass()
    if class == "build_prop" then return true end
    return class == "prop_physics" and ent:GetNWBool("CreatedByBuilder", false)
end

local function ResolveOwner(ent)
    if not IsValid(ent) then return nil end

    if ent.CPPIGetOwner then
        local ok, owner = pcall(ent.CPPIGetOwner, ent)
        if ok and IsValidPlayer(owner) then
            return owner
        end
    end

    if IsValidPlayer(ent.Owner) then
        return ent.Owner
    end

    local nwOwner = ent.GetNWEntity and ent:GetNWEntity("Owner", NULL) or NULL
    if IsValidPlayer(nwOwner) then
        return nwOwner
    end

    if ent.GetCreator then
        local creator = ent:GetCreator()
        if IsValidPlayer(creator) then
            return creator
        end
    end

    if ent.GetOwner then
        local owner = ent:GetOwner()
        if IsValidPlayer(owner) then
            return owner
        end
    end

    return nil
end

local function FindSBSAnchor(door)
    if not IsValid(door) then return nil end

    local nearby = ents.FindInSphere(door:GetPos(), 128)

    for _, ent in ipairs(nearby) do
        if IsSBSBuildPiece(ent) and ent.Door == door then
            return ent
        end
    end

    local best, bestDist
    for _, ent in ipairs(nearby) do
        if IsSBSBuildPiece(ent) and BuildConf.DoorAllowed[ent:GetModel()] then
            local dist = door:GetPos():DistToSqr(ent:GetPos())
            if not bestDist or dist < bestDist then
                best = ent
                bestDist = dist
            end
        end
    end

    return best
end

local function SetFallbackHologramAnchor(door)
    local worldCenter = door:LocalToWorld(door:OBBCenter())
    local worldNormal = door:GetForward()
    local localClickPos = door:WorldToLocal(worldCenter)
    local localCenter = door:WorldToLocal(worldCenter)
    local localNormal = door:WorldToLocal(worldCenter + worldNormal) - localClickPos

    if localNormal:LengthSqr() <= 0.0001 then
        localNormal = Vector(1, 0, 0)
    else
        localNormal:Normalize()
    end

    door:SetNWVector("VEIN_ClickNormal", worldNormal)
    door:SetNWVector("VEIN_ClickPos", worldCenter)
    door:SetNWVector("VEIN_VisualCenter", worldCenter)
    door:SetNWVector("VEIN_ClickPosLocal", localClickPos)
    door:SetNWVector("VEIN_VisualCenterLocal", localCenter)
    door:SetNWVector("VEIN_ClickNormalLocal", localNormal)
    door:SetNWBool("VEIN_UseLocalHologram", true)
end

local function ApplyFallbackDoorSetup(door, ply, doorName, price, isLocked, doorType, doorMaterial)
    if not IsValid(door) or not IsValidPlayer(ply) then return false end

    door:SetNWFloat("VEIN_InitialYaw", door:GetAngles().y)
    SetFallbackHologramAnchor(door)

    door:SetNWBool("VEIN_AllowOwnership", true)
    door:SetNWBool("VEIN_Buyable", true)
    door:SetNWBool("VEIN_AdminOnly", false)
    door:SetNWBool("VEIN_IsVEINDoor", true)
    door:SetNWBool("VEIN_IsSetup", true)
    door:SetNWString("VEIN_DoorName", doorName)
    door:SetNWInt("VEIN_Price", price)
    door:SetNWBool("VEIN_LockName", false)
    door:SetNWString("VEIN_Creator", ply:Nick())
    door:SetNWBool("VEIN_AutoLockOnClose", false)
    door:SetNWInt("VEIN_LinkGroup", 0)
    door:SetNWEntity("VEIN_LinkedDoor", NULL)
    door:SetNWBool("VEIN_JobControlled", false)
    door:SetNWString("VEIN_ControlJobs", "[]")
    door:SetNWString("VEIN_DoorGroup", "")
    door:SetNWString("VEIN_AllowedJobs", "[]")
    door:SetNWString("VEIN_DoorType", doorType)
    door:SetNWString("VEIN_DoorMaterial", doorMaterial)
    door:SetNWInt("VEIN_PropertyGroup", 0)
    door:SetNWString("VEIN_PropertyGroupName", "")
    door:SetNWInt("VEIN_PropertyCustomPrice", 0)
    door:SetNWBool("VEIN_DefaultLocked", isLocked)

    local matData = VEIN.CustomDoors and VEIN.CustomDoors.GetMaterialData and VEIN.CustomDoors.GetMaterialData(doorMaterial) or nil
    matData = matData or {
        kickTime = 15,
        lockSound = "doors/door_latch1.wav",
        unlockSound = "doors/door_latch3.wav",
        kickSound = "physics/wood/wood_plank_break1.wav",
        breakSound = "physics/wood/wood_crate_break1.wav",
        lockPitch = 100,
        unlockPitch = 100,
        kickPitch = 100,
        breakPitch = 100
    }

    door:SetNWInt("VEIN_KickTime", matData.kickTime or 15)
    door:SetNWString("VEIN_LockSound", matData.lockSound or "doors/door_latch1.wav")
    door:SetNWString("VEIN_UnlockSound", matData.unlockSound or "doors/door_latch3.wav")
    door:SetNWString("VEIN_KickSound", matData.kickSound or "physics/wood/wood_plank_break1.wav")
    door:SetNWString("VEIN_BreakSound", matData.breakSound or "physics/wood/wood_crate_break1.wav")
    door:SetNWInt("VEIN_LockPitch", matData.lockPitch or 100)
    door:SetNWInt("VEIN_UnlockPitch", matData.unlockPitch or 100)
    door:SetNWInt("VEIN_KickPitch", matData.kickPitch or 100)
    door:SetNWInt("VEIN_BreakPitch", matData.breakPitch or 100)

    if isLocked then
        door:Fire("Close")
        timer.Simple(0.5, function()
            if IsValid(door) then
                door:Fire("Lock")
                door:SetNWBool("VEIN_Locked", true)
            end
        end)
    else
        door:Fire("Unlock")
        door:SetNWBool("VEIN_Locked", false)
    end

    hook.Run("VEIN_DoorCreated", door)
    return true
end

local function ConvertSBSDoor(door, ply)
    local doorType = string.Trim(cvDefaultType:GetString())
    if doorType == "" then
        doorType = "Residential"
    end

    local doorMaterial = string.Trim(cvDefaultMaterial:GetString())
    if doorMaterial == "" then
        doorMaterial = "Wood Door"
    end

    local doorName = "Built Door"
    local price = math.max(0, cvDefaultPrice:GetInt())
    local isLocked = cvStartLocked:GetBool()

    local created = false
    if VEIN.DoorSystem and isfunction(VEIN.DoorSystem.CreateDoor) then
        created = VEIN.DoorSystem.CreateDoor(
            door,
            ply,
            doorName,
            price,
            isLocked,
            doorType,
            doorMaterial,
            true,
            false,
            false,
            {}
        ) == true
    end

    if not created then
        created = ApplyFallbackDoorSetup(door, ply, doorName, price, isLocked, doorType, doorMaterial)
    end

    if not created then
        return false
    end

    door.VEIN_SBSCompatProcessed = true
    door:SetNWBool("VEIN_SBSManaged", true)

    if VEIN.DoorSystem.UpdateDoorPropertyStats then
        VEIN.DoorSystem.UpdateDoorPropertyStats(door)
    end

    if VEIN.DoorSystem.UpdateDoorLinkStats then
        VEIN.DoorSystem.UpdateDoorLinkStats(door)
    end

    return true
end

hook.Add("OnEntityCreated", "VEIN_SBSCompat_CreateDoors", function(ent)
    if not IsValid(ent) or ent:GetClass() ~= "prop_door_rotating" then return end

    timer.Simple(0, function()
        if not IsValid(ent) then return end
        if ent.VEIN_SBSCompatProcessed then return end
        if ent:GetNWBool("VEIN_IsVEINDoor", false) then return end
        if not ent.IsBuildDoor then return end
        if not IsSBSAvailable() then return end

        local anchor = FindSBSAnchor(ent)
        if not IsValid(anchor) then return end

        local owner = ResolveOwner(anchor)
        if not IsValidPlayer(owner) then return end

        ConvertSBSDoor(ent, owner)
    end)
end)
