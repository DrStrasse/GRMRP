﻿--[[
================================================================================
VEIN Door System - DarkRP integration (server)
Scoped to VEIN doors only, avoids touching third-party hooks.
================================================================================
]]--

if CLIENT then return end

local function isVeinDoor(ent)
    return IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false)
end

local function isDoor(ent)
    if not IsValid(ent) then return false end
    local class = ent:GetClass()
    return class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating"
end

local cvOverrideDarkRP = CreateConVar("vein_override_darkrp_doors", "1", bit.bor(FCVAR_ARCHIVE, FCVAR_REPLICATED), "Override DarkRP door system for all doors (1) or only VEIN doors (0)")

local function shouldOverrideDoor(ent)
    if not isDoor(ent) then return false end
    if isVeinDoor(ent) then return true end
    return cvOverrideDarkRP:GetBool()
end

local function getLinkedGroupDoors(door)
    if not IsValid(door) then return {} end
    if VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedGroup then
        local group = {}
        for _, linked in ipairs(VEIN.DoorSystem.GetLinkedGroup(door)) do
            if IsValid(linked) and isVeinDoor(linked) then
                table.insert(group, linked)
            end
        end
        if #group > 0 then return group end
    end

    local group = {door}
    local linkedDoor = door:GetNWEntity("VEIN_LinkedDoor", NULL)
    if IsValid(linkedDoor) and linkedDoor ~= door and isVeinDoor(linkedDoor) then
        table.insert(group, linkedDoor)
    end
    return group
end

local function getPropertyGroupDoors(door)
    if not IsValid(door) then return nil end
    if VEIN.DoorSystem and VEIN.DoorSystem.GetPropertyGroupDoors then
        local groupId = door:GetNWInt("VEIN_PropertyGroup", 0)
        local groupName = door:GetNWString("VEIN_PropertyGroupName", "")
        if groupId > 0 and groupName ~= "" then
            local group = {}
            for _, ent in ipairs(VEIN.DoorSystem.GetPropertyGroupDoors(door) or {}) do
                if IsValid(ent) and isVeinDoor(ent) then
                    table.insert(group, ent)
                end
            end
            if #group > 0 then
                return group
            end
        end
    end
    return nil
end

-- Allow admins to use the VEIN tool even if other protection hooks run.
hook.Add("CanTool", "VEIN_AllowDoorToolgun", function(ply, trace, tool)
    if tool ~= "vein_door_manager" then return end
    if not IsValid(ply) or not IsValid(trace.Entity) then return end

    local ent = trace.Entity
    local class = ent:GetClass()
    local isDoor = class:find("door") or class == "prop_dynamic" or class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating"
    if not isDoor then return end

    if ply:IsAdmin() or ply:IsSuperAdmin() then
        return true -- explicitly allow admins
    end
end, HOOK_MONITOR_LOW)

-- Integrate with DarkRP once it is available.
hook.Add("InitPostEntity", "VEIN_DisableDarkRPDoors", function()
    timer.Simple(0.5, function()
        if not DarkRP then return end

        local ENTITY = FindMetaTable("Entity")
        if not ENTITY then return end

        -- Cache original functions once
        ENTITY.VEIN_OriginalKeysOwnable = ENTITY.VEIN_OriginalKeysOwnable or ENTITY.isKeysOwnable
        ENTITY.VEIN_OriginalKeysOwned = ENTITY.VEIN_OriginalKeysOwned or ENTITY.isKeysOwned
        ENTITY.VEIN_OriginalKeysOwn = ENTITY.VEIN_OriginalKeysOwn or ENTITY.keysOwn
        ENTITY.VEIN_OriginalKeysUnOwn = ENTITY.VEIN_OriginalKeysUnOwn or ENTITY.keysUnOwn
        ENTITY.VEIN_OriginalGetKeysNonOwnable = ENTITY.VEIN_OriginalGetKeysNonOwnable or ENTITY.getKeysNonOwnable
        ENTITY.VEIN_OriginalSetKeysNonOwnable = ENTITY.VEIN_OriginalSetKeysNonOwnable or ENTITY.setKeysNonOwnable
        ENTITY.VEIN_OriginalGetDoorOwner = ENTITY.VEIN_OriginalGetDoorOwner or ENTITY.getDoorOwner
        ENTITY.VEIN_OriginalIsMasterOwner = ENTITY.VEIN_OriginalIsMasterOwner or ENTITY.isMasterOwner
        ENTITY.VEIN_OriginalIsKeysOwnedBy = ENTITY.VEIN_OriginalIsKeysOwnedBy or ENTITY.isKeysOwnedBy
        ENTITY.VEIN_OriginalGetKeysDoorGroup = ENTITY.VEIN_OriginalGetKeysDoorGroup or ENTITY.getKeysDoorGroup
        ENTITY.VEIN_OriginalGetKeysDoorTeams = ENTITY.VEIN_OriginalGetKeysDoorTeams or ENTITY.getKeysDoorTeams

        function ENTITY:isKeysOwnable()
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                return self:GetNWBool("VEIN_AllowOwnership", true)
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalKeysOwnable then
                return ENTITY.VEIN_OriginalKeysOwnable(self)
            end
            return false
        end

        function ENTITY:isKeysOwned()
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                return self:GetNWString("VEIN_Owner", "") ~= ""
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalKeysOwned then
                return ENTITY.VEIN_OriginalKeysOwned(self)
            end
            return false
        end

        function ENTITY:keysOwn(ply)
            if not IsValid(ply) then return false end
            if not shouldOverrideDoor(self) then
                return ENTITY.VEIN_OriginalKeysOwn and ENTITY.VEIN_OriginalKeysOwn(self, ply) or false
            end
            if not isVeinDoor(self) then return false end

            local isBuyable = self:GetNWBool("VEIN_Buyable", false)
            local owner = self:GetNWString("VEIN_Owner", "")
            if not isBuyable or owner ~= "" then return false end

            local groupDoors = getPropertyGroupDoors(self) or getLinkedGroupDoors(self)
            local totalPrice = 0
            if self:GetNWInt("VEIN_PropertyGroup", 0) > 0 and self:GetNWString("VEIN_PropertyGroupName", "") ~= "" then
                totalPrice = self:GetNWInt("VEIN_PropertyTotalPrice", 0)
                if totalPrice <= 0 and VEIN.DoorSystem and VEIN.DoorSystem.GetPropertyGroupTotalPrice then
                    totalPrice = VEIN.DoorSystem.GetPropertyGroupTotalPrice(self)
                end
            end
            for _, groupDoor in ipairs(groupDoors) do
                if not groupDoor:GetNWBool("VEIN_AllowOwnership", true) then return false end
                if not groupDoor:GetNWBool("VEIN_Buyable", false) then return false end
                if groupDoor:GetNWString("VEIN_Owner", "") ~= "" then return false end
                if totalPrice <= 0 then
                    totalPrice = totalPrice + groupDoor:GetNWInt("VEIN_Price", 0)
                end
            end

            if DarkRP and not ply:canAfford(totalPrice) then
                DarkRP.notify(ply, 1, 4, DarkRP.getPhrase("cant_afford", DarkRP.formatMoney(totalPrice)))
                return false
            end

            if DarkRP then
                ply:addMoney(-totalPrice)
                DarkRP.notify(ply, 0, 4, DarkRP.getPhrase("you_purchased", DarkRP.getPhrase("door"), DarkRP.formatMoney(totalPrice)))
            end

            for _, groupDoor in ipairs(groupDoors) do
                if VEIN.DoorSystem then
                    VEIN.DoorSystem.OwnedDoors[groupDoor:EntIndex()] = ply:SteamID()
                end
                groupDoor:SetNWString("VEIN_Owner", ply:SteamID())
                groupDoor:SetNWString("VEIN_OwnerName", ply:Nick())
                groupDoor:SetNWString("VEIN_OwnerSteamID", ply:SteamID())
                groupDoor:SetNWBool("VEIN_Locked", false)
            end

            hook.Call("playerBoughtDoor", nil, ply, self, totalPrice)
            return true
        end

        function ENTITY:keysUnOwn(ply)
            if not IsValid(ply) then return false end
            if not shouldOverrideDoor(self) then
                return ENTITY.VEIN_OriginalKeysUnOwn and ENTITY.VEIN_OriginalKeysUnOwn(self, ply) or false
            end
            if not isVeinDoor(self) then return false end

            local groupDoors = getPropertyGroupDoors(self) or getLinkedGroupDoors(self)
            for _, groupDoor in ipairs(groupDoors) do
                if groupDoor:GetNWString("VEIN_Owner", "") ~= ply:SteamID() then return false end
            end

            local refundPercent = (GetConVar("vein_door_refund_percent") and GetConVar("vein_door_refund_percent"):GetInt() or 50) / 100
            local totalPrice = 0
            if self:GetNWInt("VEIN_PropertyGroup", 0) > 0 and self:GetNWString("VEIN_PropertyGroupName", "") ~= "" then
                totalPrice = self:GetNWInt("VEIN_PropertyTotalPrice", 0)
                if totalPrice <= 0 and VEIN.DoorSystem and VEIN.DoorSystem.GetPropertyGroupTotalPrice then
                    totalPrice = VEIN.DoorSystem.GetPropertyGroupTotalPrice(self)
                end
            end
            for _, groupDoor in ipairs(groupDoors) do
                if totalPrice <= 0 then
                    totalPrice = totalPrice + groupDoor:GetNWInt("VEIN_Price", 0)
                end
            end
            local refund = math.floor(totalPrice * refundPercent)

            if DarkRP then
                ply:addMoney(refund)
                DarkRP.notify(ply, 0, 4, DarkRP.getPhrase("you_sold", DarkRP.getPhrase("door"), DarkRP.formatMoney(refund)))
            end

            for _, groupDoor in ipairs(groupDoors) do
                if VEIN.DoorSystem then
                    VEIN.DoorSystem.OwnedDoors[groupDoor:EntIndex()] = nil
                    VEIN.DoorSystem.DoorAccess[groupDoor:EntIndex()] = nil
                end
                groupDoor:SetNWString("VEIN_Owner", "")
                groupDoor:SetNWString("VEIN_OwnerName", "")
                groupDoor:SetNWString("VEIN_OwnerSteamID", "")
                groupDoor:SetNWString("VEIN_AccessData", "{}")
                local defaultLocked = groupDoor:GetNWBool("VEIN_DefaultLocked", false)
                groupDoor:SetNWBool("VEIN_Locked", defaultLocked)
                if defaultLocked then
                    groupDoor:Fire("Close")
                    timer.Simple(0.5, function()
                        if IsValid(groupDoor) then
                            groupDoor:Fire("Lock")
                        end
                    end)
                else
                    groupDoor:Fire("Unlock")
                end
            end

            hook.Call("playerSoldDoor", nil, ply, self, refund)
            return true
        end

        function ENTITY:getKeysNonOwnable()
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                return not self:GetNWBool("VEIN_AllowOwnership", true)
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalGetKeysNonOwnable then
                return ENTITY.VEIN_OriginalGetKeysNonOwnable(self)
            end
            return true
        end

        function ENTITY:setKeysNonOwnable(nonOwnable)
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                self:SetNWBool("VEIN_AllowOwnership", not nonOwnable)
                if nonOwnable and self:GetNWString("VEIN_Owner", "") ~= "" then
                    self:SetNWString("VEIN_Owner", "")
                    self:SetNWBool("VEIN_Locked", false)
                    self:Fire("Unlock")
                end
                return
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalSetKeysNonOwnable then
                return ENTITY.VEIN_OriginalSetKeysNonOwnable(self, nonOwnable)
            end
            return
        end

        function ENTITY:getDoorOwner()
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                local ownerName = self:GetNWString("VEIN_Owner", "")
                if ownerName ~= "" then
                    for _, ply in ipairs(player.GetAll()) do
                        if ply:Nick() == ownerName then return ply end
                    end
                end
                return nil
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalGetDoorOwner then
                return ENTITY.VEIN_OriginalGetDoorOwner(self)
            end
            return nil
        end

        function ENTITY:isMasterOwner(ply)
            if not IsValid(ply) then return false end
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                return self:GetNWString("VEIN_Owner", "") == ply:Nick()
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalIsMasterOwner then
                return ENTITY.VEIN_OriginalIsMasterOwner(self, ply)
            end
            return false
        end

        function ENTITY:isKeysOwnedBy(ply)
            if not IsValid(ply) then return false end
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                local nick = ply:Nick()
                if self:GetNWString("VEIN_Owner", "") == nick then return true end
                local doorAccess = VEIN.DoorSystem and VEIN.DoorSystem.DoorAccess and VEIN.DoorSystem.DoorAccess[self:EntIndex()] or {}
                if doorAccess[nick] then return true end
                if ply:IsBot() and doorAccess["BOT_" .. nick] then return true end
                local sid = ply:SteamID()
                if sid and sid ~= "" and doorAccess[sid] then return true end
                local sid64 = ply:SteamID64()
                if sid64 and sid64 ~= "" and doorAccess[sid64] then return true end
                return false
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalIsKeysOwnedBy then
                return ENTITY.VEIN_OriginalIsKeysOwnedBy(self, ply)
            end
            return false
        end

        function ENTITY:getKeysDoorGroup()
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                local doorGroup = self:GetNWString("VEIN_DoorGroup", "")
                return doorGroup ~= "" and doorGroup or nil
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalGetKeysDoorGroup then
                return ENTITY.VEIN_OriginalGetKeysDoorGroup(self)
            end
            return nil
        end

        function ENTITY:getKeysDoorTeams()
            if shouldOverrideDoor(self) and isVeinDoor(self) then
                local doorGroup = self:GetNWString("VEIN_DoorGroup", "")
                if doorGroup ~= "" and VEIN and VEIN.DoorGroups and VEIN.DoorGroups.Groups then
                    for _, group in ipairs(VEIN.DoorGroups.Groups) do
                        if group.name == doorGroup and group.jobs then
                            local teamOwn = {}
                            local jobLookup = {}
                            for _, jobName in ipairs(group.jobs) do
                                jobLookup[jobName] = true
                            end
                            if RPExtraTeams then
                                for teamID, teamData in ipairs(RPExtraTeams) do
                                    if jobLookup[teamData.name] then
                                        teamOwn[teamID] = true
                                    end
                                end
                            end
                            if not table.IsEmpty(teamOwn) then return teamOwn end
                        end
                    end
                end
                return nil
            end
            if not shouldOverrideDoor(self) and ENTITY.VEIN_OriginalGetKeysDoorTeams then
                return ENTITY.VEIN_OriginalGetKeysDoorTeams(self)
            end
            return nil
        end

        -- Prevent DarkRP double-charging on VEIN doors only
        hook.Add("playerBuyDoor", "VEIN_BlockDarkRPBuy", function(ply, ent)
            if shouldOverrideDoor(ent) then return false end
        end)

        hook.Add("playerSellDoor", "VEIN_BlockDarkRPSell", function(ply, ent)
            if shouldOverrideDoor(ent) then return false end
        end)
    end)
end)
