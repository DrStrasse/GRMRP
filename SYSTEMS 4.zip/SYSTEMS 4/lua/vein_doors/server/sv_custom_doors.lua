--[[
================================================================================
VEIN Door System - Custom Door Types & Materials Management
Handles custom door types and materials with persistence
================================================================================
]]--

if CLIENT then return end

-- Initialize VEIN namespace
VEIN = VEIN or {}
local VEIN = VEIN
VEIN.CustomDoors = VEIN.CustomDoors or {}
VEIN.Net = VEIN.Net or {}

local Net = VEIN.Net

local DATA_FOLDER = "vein_door_system"
local TYPES_FILE = DATA_FOLDER .. "/custom_types.txt"
local MATERIALS_FILE = DATA_FOLDER .. "/custom_materials.txt"

-- Default door types (alpha forced to 255 for full opacity)
VEIN.CustomDoors.DefaultTypes = {
    {name = "Residential", color = Color(100, 255, 120, 255), desc = "Houses, apartments, private living spaces"},
    {name = "Commercial", color = Color(80, 150, 255, 255), desc = "Shops, businesses, retail stores"},
    {name = "Industrial", color = Color(255, 200, 60, 255), desc = "Warehouses, factories, production facilities"},
    {name = "Government", color = Color(255, 80, 80, 255), desc = "Police stations, government buildings, official areas"},
    {name = "Emergency", color = Color(255, 165, 0, 255), desc = "Fire stations, hospitals, emergency services"}
}

-- Default door materials
VEIN.CustomDoors.DefaultMaterials = {
    {name = "Wood Door", kickTime = 15, lockSound = "doors/door_latch1.wav", unlockSound = "doors/door_latch3.wav", kickSound = "physics/wood/wood_plank_break1.wav", breakSound = "physics/wood/wood_crate_break1.wav", lockPitch = 100, unlockPitch = 100, kickPitch = 100, breakPitch = 100},
    {name = "Light Metal", kickTime = 25, lockSound = "doors/door_latch1.wav", unlockSound = "doors/door_latch3.wav", kickSound = "physics/metal/metal_sheet_impact_hard6.wav", breakSound = "physics/metal/metal_box_break1.wav", lockPitch = 100, unlockPitch = 100, kickPitch = 100, breakPitch = 100},
    {name = "Glass Door", kickTime = 10, lockSound = "doors/door_latch1.wav", unlockSound = "doors/door_latch3.wav", kickSound = "physics/glass/glass_impact_bullet1.wav", breakSound = "physics/glass/glass_largesheet_break1.wav", lockPitch = 100, unlockPitch = 100, kickPitch = 100, breakPitch = 100},
    {name = "Heavy Metal", kickTime = -1, lockSound = "doors/door_latch1.wav", unlockSound = "doors/door_latch3.wav", kickSound = "physics/metal/metal_solid_impact_hard1.wav", breakSound = "physics/metal/metal_solid_strain3.wav", lockPitch = 100, unlockPitch = 100, kickPitch = 100, breakPitch = 100},
    {name = "Steel Door", kickTime = -1, lockSound = "doors/door_latch1.wav", unlockSound = "doors/door_latch3.wav", kickSound = "physics/metal/metal_solid_impact_hard1.wav", breakSound = "physics/metal/metal_solid_strain5.wav", lockPitch = 100, unlockPitch = 100, kickPitch = 100, breakPitch = 100}
}

-- Storage for custom types and materials
VEIN.CustomDoors.Types = {}
VEIN.CustomDoors.Materials = {}

-- Network strings
util.AddNetworkString("VEIN_RequestCustomDoors")
util.AddNetworkString("VEIN_CustomDoorsData")
util.AddNetworkString("VEIN_AddCustomType")
util.AddNetworkString("VEIN_UpdateCustomType")
util.AddNetworkString("VEIN_RemoveCustomType")
util.AddNetworkString("VEIN_AddCustomMaterial")
util.AddNetworkString("VEIN_UpdateCustomMaterial")
util.AddNetworkString("VEIN_RemoveCustomMaterial")

-- Save custom types to file (including modified default types)
local function SaveCustomTypes()
    local data = {
        defaults = {},
        custom = {}
    }
    
    -- Save default types (in case colors were changed)
    for _, typeData in ipairs(VEIN.CustomDoors.DefaultTypes) do
        table.insert(data.defaults, {
            name = typeData.name,
            color = {r = typeData.color.r, g = typeData.color.g, b = typeData.color.b}
        })
    end
    
    -- Save custom types
    for _, typeData in ipairs(VEIN.CustomDoors.Types) do
        table.insert(data.custom, {
            name = typeData.name,
            color = {r = typeData.color.r, g = typeData.color.g, b = typeData.color.b}
        })
    end
    
    file.Write(TYPES_FILE, util.TableToJSON(data, true))
    print("[VEIN] Saved " .. #data.defaults .. " default and " .. #data.custom .. " custom door type(s)")
end

-- Load custom types from file
local function LoadCustomTypes()
    if file.Exists(TYPES_FILE, "DATA") then
        local json = file.Read(TYPES_FILE, "DATA")
        local data = util.JSONToTable(json)
        
        if data then
            -- Handle new format with defaults and custom
            if data.defaults and data.custom then
                -- Load modified default type colors
                for _, savedDefault in ipairs(data.defaults) do
                    for i, defaultType in ipairs(VEIN.CustomDoors.DefaultTypes) do
                        if defaultType.name == savedDefault.name then
                            -- Restore modified color (force alpha to 255)
                            VEIN.CustomDoors.DefaultTypes[i].color = Color(savedDefault.color.r, savedDefault.color.g, savedDefault.color.b, 255)
                            break
                        end
                    end
                end
                
                -- Load custom types
                VEIN.CustomDoors.Types = {}
                for _, typeData in ipairs(data.custom) do
                    table.insert(VEIN.CustomDoors.Types, {
                        name = typeData.name,
                        color = Color(typeData.color.r, typeData.color.g, typeData.color.b, 255)
                    })
                end
                print("[VEIN] Loaded " .. #data.defaults .. " default (modified) and " .. #VEIN.CustomDoors.Types .. " custom door type(s)")
            else
                -- Handle old format (just array of types)
                VEIN.CustomDoors.Types = {}
                for _, typeData in ipairs(data) do
                    table.insert(VEIN.CustomDoors.Types, {
                        name = typeData.name,
                        color = Color(typeData.color.r, typeData.color.g, typeData.color.b, 255)
                    })
                end
                print("[VEIN] Loaded " .. #VEIN.CustomDoors.Types .. " custom door type(s) (old format)")
            end
        end
    end
end

-- Save custom materials to file
local function SaveCustomMaterials()
    local data = {}
    for _, matData in ipairs(VEIN.CustomDoors.Materials) do
        table.insert(data, {
            name = matData.name,
            kickTime = matData.kickTime,
            lockSound = matData.lockSound,
            unlockSound = matData.unlockSound,
            kickSound = matData.kickSound or "physics/wood/wood_plank_break1.wav",
            breakSound = matData.breakSound or "physics/wood/wood_crate_break1.wav",
            lockPitch = matData.lockPitch or 100,
            unlockPitch = matData.unlockPitch or 100,
            kickPitch = matData.kickPitch or 100,
            breakPitch = matData.breakPitch or 100
        })
    end
    
    file.Write(MATERIALS_FILE, util.TableToJSON(data, true))
    print("[VEIN] Saved " .. #data .. " custom door material(s)")
end

-- Load custom materials from file
local function LoadCustomMaterials()
    if file.Exists(MATERIALS_FILE, "DATA") then
        local json = file.Read(MATERIALS_FILE, "DATA")
        local data = util.JSONToTable(json)
        
        if data then
            VEIN.CustomDoors.Materials = {}
            for _, matData in ipairs(data) do
                table.insert(VEIN.CustomDoors.Materials, {
                    name = matData.name,
                    kickTime = matData.kickTime,
                    lockSound = matData.lockSound,
                    unlockSound = matData.unlockSound,
                    kickSound = matData.kickSound or "physics/wood/wood_plank_break1.wav",
                    breakSound = matData.breakSound or "physics/wood/wood_crate_break1.wav",
                    lockPitch = matData.lockPitch or 100,
                    unlockPitch = matData.unlockPitch or 100,
                    kickPitch = matData.kickPitch or 100,
                    breakPitch = matData.breakPitch or 100
                })
            end
            print("[VEIN] Loaded " .. #VEIN.CustomDoors.Materials .. " custom door material(s)")
        end
    end
end

-- Get all door types (default + custom)
function VEIN.CustomDoors.GetAllTypes()
    local allTypes = {}
    
    -- Add default types
    for _, typeData in ipairs(VEIN.CustomDoors.DefaultTypes) do
        table.insert(allTypes, typeData)
    end
    
    -- Add custom types
    for _, typeData in ipairs(VEIN.CustomDoors.Types) do
        table.insert(allTypes, typeData)
    end
    
    return allTypes
end

-- Get all door materials (default + custom)
function VEIN.CustomDoors.GetAllMaterials()
    local allMaterials = {}
    
    -- Add default materials
    for _, matData in ipairs(VEIN.CustomDoors.DefaultMaterials) do
        table.insert(allMaterials, matData)
    end
    
    -- Add custom materials
    for _, matData in ipairs(VEIN.CustomDoors.Materials) do
        table.insert(allMaterials, matData)
    end
    
    return allMaterials
end

-- Get material data by name (helper function for door creation)
function VEIN.CustomDoors.GetMaterialData(materialName)
    local allMaterials = VEIN.CustomDoors.GetAllMaterials()
    
    for _, matData in ipairs(allMaterials) do
        if matData.name == materialName then
            return matData
        end
    end
    
    -- Return default if not found
    return {
        name = "Light Metal",
        kickTime = 25,
        lockSound = "doors/door_latch3.wav",
        unlockSound = "doors/door_latch1.wav",
        kickSound = "physics/metal/metal_sheet_impact_hard6.wav",
        breakSound = "physics/metal/metal_box_break1.wav",
        lockPitch = 100,
        unlockPitch = 100,
        kickPitch = 100,
        breakPitch = 100
    }
end

-- Network: Send all custom door data to client
net.Receive("VEIN_RequestCustomDoors", function(len, ply)
    if not ply:IsAdmin() then return end
    
    net.Start("VEIN_CustomDoorsData")
    Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
    Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
    net.Send(ply)
end)

-- Network: Add custom type
net.Receive("VEIN_AddCustomType", function(len, ply)
    if not ply:IsAdmin() then return end
    
    local typeName = net.ReadString()
    local colorR = net.ReadUInt(8)
    local colorG = net.ReadUInt(8)
    local colorB = net.ReadUInt(8)
    
    -- Check if type already exists
    for _, typeData in ipairs(VEIN.CustomDoors.GetAllTypes()) do
        if typeData.name == typeName then
            VEIN.Chat(ply, "A door type with that name already exists!")
            return
        end
    end
    
    -- Add custom type (force alpha to 255 for full opacity)
    table.insert(VEIN.CustomDoors.Types, {
        name = typeName,
        color = Color(colorR, colorG, colorB, 255)
    })
    
    SaveCustomTypes()
    VEIN.Chat(ply, "Custom door type '" .. typeName .. "' added!")
    
    -- Send updated data back
    net.Start("VEIN_CustomDoorsData")
    Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
    Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
    net.Send(ply)
end)

-- Network: Remove custom type
net.Receive("VEIN_RemoveCustomType", function(len, ply)
    if not ply:IsAdmin() then return end
    
    local typeName = net.ReadString()
    
    -- Check if it's a default type
    for _, typeData in ipairs(VEIN.CustomDoors.DefaultTypes) do
        if typeData.name == typeName then
            VEIN.Chat(ply, "Cannot remove default door types!")
            return
        end
    end
    
    -- Remove custom type
    for i, typeData in ipairs(VEIN.CustomDoors.Types) do
        if typeData.name == typeName then
            table.remove(VEIN.CustomDoors.Types, i)
            SaveCustomTypes()
            VEIN.Chat(ply, "Custom door type '" .. typeName .. "' removed!")
            
            -- Send updated data back
            net.Start("VEIN_CustomDoorsData")
            Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
            Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
            net.Send(ply)
            return
        end
    end
    
    VEIN.Chat(ply, "Door type not found!")
end)

-- Network: Update custom type
net.Receive("VEIN_UpdateCustomType", function(len, ply)
    if not ply:IsAdmin() then return end
    
    local oldName = net.ReadString()
    local newName = net.ReadString()
    local r = net.ReadUInt(8)
    local g = net.ReadUInt(8)
    local b = net.ReadUInt(8)
    
    -- Check if it's a default type - allow color edits but not name changes
    local isDefault = false
    for i, typeData in ipairs(VEIN.CustomDoors.DefaultTypes) do
        if typeData.name == oldName then
            isDefault = true
            
            -- Prevent renaming default types
            if newName ~= oldName then
                VEIN.Chat(ply, "Cannot rename default door types! You can only change their color.")
                return
            end
            
            -- Update the default type's color (force alpha to 255)
            VEIN.CustomDoors.DefaultTypes[i] = {
                name = oldName,
                color = Color(r, g, b, 255)
            }
            SaveCustomTypes() -- This will save the default type changes
            VEIN.Chat(ply, "Default door type '" .. oldName .. "' color updated!")
            
            -- Send updated data back
            net.Start("VEIN_CustomDoorsData")
            Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
            Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
            net.Send(ply)
            return
        end
    end
    
    -- Find and update custom type
    for i, typeData in ipairs(VEIN.CustomDoors.Types) do
        if typeData.name == oldName then
            -- Check if new name conflicts with existing type
            if newName ~= oldName then
                for _, checkData in ipairs(VEIN.CustomDoors.GetAllTypes()) do
                    if checkData.name == newName then
                        VEIN.Chat(ply, "A door type with that name already exists!")
                        return
                    end
                end
            end
            
            -- Update the custom type (force alpha to 255)
            VEIN.CustomDoors.Types[i] = {
                name = newName,
                color = Color(r, g, b, 255)
            }
            SaveCustomTypes()
            VEIN.Chat(ply, "Custom door type '" .. oldName .. "' updated!")
            
            -- Send updated data back
            net.Start("VEIN_CustomDoorsData")
            Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
            Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
            net.Send(ply)
            return
        end
    end
    
    VEIN.Chat(ply, "Door type not found!")
end)

-- Network: Add custom material
net.Receive("VEIN_AddCustomMaterial", function(len, ply)
    if not ply:IsAdmin() then return end
    
    local matName = net.ReadString()
    local kickTime = net.ReadInt(16)
    local lockSound = net.ReadString()
    local unlockSound = net.ReadString()
    local kickSound = net.ReadString()
    local breakSound = net.ReadString()
    
    -- Read pitch values (default to 100 if not sent)
    local lockPitch = net.ReadUInt(8) or 100
    local unlockPitch = net.ReadUInt(8) or 100
    local kickPitch = net.ReadUInt(8) or 100
    local breakPitch = net.ReadUInt(8) or 100
    
    -- Check if material already exists
    for _, matData in ipairs(VEIN.CustomDoors.GetAllMaterials()) do
        if matData.name == matName then
            VEIN.Chat(ply, "A door material with that name already exists!")
            return
        end
    end
    
    -- Add custom material
    table.insert(VEIN.CustomDoors.Materials, {
        name = matName,
        kickTime = kickTime,
        lockSound = lockSound,
        unlockSound = unlockSound,
        kickSound = kickSound,
        breakSound = breakSound,
        lockPitch = lockPitch,
        unlockPitch = unlockPitch,
        kickPitch = kickPitch,
        breakPitch = breakPitch
    })
    
    SaveCustomMaterials()
    VEIN.Chat(ply, "Custom door material '" .. matName .. "' added!")
    
    -- Send updated data back
    net.Start("VEIN_CustomDoorsData")
    Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
    Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
    net.Send(ply)
end)

-- Network: Update custom material
net.Receive("VEIN_UpdateCustomMaterial", function(len, ply)
    if not ply:IsAdmin() then return end
    
    local oldName = net.ReadString()
    local newName = net.ReadString()
    local kickTime = net.ReadInt(16)
    local lockSound = net.ReadString()
    local unlockSound = net.ReadString()
    local kickSound = net.ReadString()
    local breakSound = net.ReadString()
    
    -- Read pitch values (default to 100 if not sent)
    local lockPitch = net.ReadUInt(8) or 100
    local unlockPitch = net.ReadUInt(8) or 100
    local kickPitch = net.ReadUInt(8) or 100
    local breakPitch = net.ReadUInt(8) or 100
    
    -- Check if it's a default material
    for _, matData in ipairs(VEIN.CustomDoors.DefaultMaterials) do
        if matData.name == oldName then
            VEIN.Chat(ply, "Cannot edit default door materials!")
            return
        end
    end
    
    -- Find and update the material
    for i, matData in ipairs(VEIN.CustomDoors.Materials) do
        if matData.name == oldName then
            -- Check if new name conflicts with existing material
            if newName ~= oldName then
                for _, checkData in ipairs(VEIN.CustomDoors.GetAllMaterials()) do
                    if checkData.name == newName then
                        VEIN.Chat(ply, "A door material with that name already exists!")
                        return
                    end
                end
            end
            
            -- Update the material
            VEIN.CustomDoors.Materials[i] = {
                name = newName,
                kickTime = kickTime,
                lockSound = lockSound,
                unlockSound = unlockSound,
                kickSound = kickSound,
                breakSound = breakSound,
                lockPitch = lockPitch,
                unlockPitch = unlockPitch,
                kickPitch = kickPitch,
                breakPitch = breakPitch
            }
            SaveCustomMaterials()
            
            -- Update all doors that use this material
            local updatedCount = 0
            for _, door in ipairs(ents.GetAll()) do
                if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
                    local doorMaterial = door:GetNWString("VEIN_DoorMaterial", "")
                    
                    -- If door uses the old material name, update it to new name and apply new properties
                    if doorMaterial == oldName then
                        -- Update material name if it changed
                        if newName ~= oldName then
                            door:SetNWString("VEIN_DoorMaterial", newName)
                        end
                        
                        -- Update all sound and kick properties
                        door:SetNWInt("VEIN_KickTime", kickTime)
                        door:SetNWString("VEIN_LockSound", lockSound)
                        door:SetNWString("VEIN_UnlockSound", unlockSound)
                        door:SetNWString("VEIN_KickSound", kickSound)
                        door:SetNWString("VEIN_BreakSound", breakSound)
                        door:SetNWInt("VEIN_LockPitch", lockPitch)
                        door:SetNWInt("VEIN_UnlockPitch", unlockPitch)
                        door:SetNWInt("VEIN_KickPitch", kickPitch)
                        door:SetNWInt("VEIN_BreakPitch", breakPitch)
                        
                        updatedCount = updatedCount + 1
                    end
                end
            end
            
            VEIN.Chat(ply, "Door material '" .. oldName .. "' updated! (" .. updatedCount .. " doors updated)")
            
            -- Send updated data back
            net.Start("VEIN_CustomDoorsData")
            Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
            Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
            net.Send(ply)
            return
        end
    end
    
    VEIN.Chat(ply, "Door material not found!")
end)

-- Network: Remove custom material
net.Receive("VEIN_RemoveCustomMaterial", function(len, ply)
    if not ply:IsAdmin() then return end
    
    local matName = net.ReadString()
    
    -- Check if it's a default material
    for _, matData in ipairs(VEIN.CustomDoors.DefaultMaterials) do
        if matData.name == matName then
            VEIN.Chat(ply, "Cannot remove default door materials!")
            return
        end
    end
    
    -- Remove custom material
    for i, matData in ipairs(VEIN.CustomDoors.Materials) do
        if matData.name == matName then
            table.remove(VEIN.CustomDoors.Materials, i)
            SaveCustomMaterials()
            VEIN.Chat(ply, "Custom door material '" .. matName .. "' removed!")
            
            -- Send updated data back
            net.Start("VEIN_CustomDoorsData")
            Net.WriteDoorTypes(VEIN.CustomDoors.GetAllTypes())
            Net.WriteDoorMaterials(VEIN.CustomDoors.GetAllMaterials())
            net.Send(ply)
            return
        end
    end
    
    VEIN.Chat(ply, "Door material not found!")
end)

-- Load custom types and materials on server start
hook.Add("Initialize", "VEIN_LoadCustomDoors", function()
    LoadCustomTypes()
    LoadCustomMaterials()
end)



