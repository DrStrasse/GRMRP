--[[
================================================================================
VEIN Door System - Door Persistence
Handles saving and loading door data across server restarts
================================================================================
]]--

if CLIENT then return end

-- Initialize VEIN namespace
VEIN = VEIN or {}
local VEIN = VEIN
VEIN.DoorPersistence = VEIN.DoorPersistence or {}

local DATA_FOLDER = "vein_door_system"

-- Get the current map name for per-map door storage
local function GetDoorsFile()
    local mapName = game.GetMap()
    return DATA_FOLDER .. "/doors_" .. mapName .. ".txt"
end

-- Ensure data folder exists
if not file.Exists(DATA_FOLDER, "DATA") then
    file.CreateDir(DATA_FOLDER)
end

-- Generate a unique identifier for a door based on its position and model
local function GetDoorIdentifier(door)
    if not IsValid(door) then return nil end
    
    local pos = door:GetPos()
    local model = door:GetModel()
    
    -- Create a unique key based on position (rounded to avoid floating point issues) and model
    return string.format("%s_%.0f_%.0f_%.0f", model, pos.x, pos.y, pos.z)
end

-- Save all VEIN doors to file
function VEIN.DoorPersistence.SaveAllDoors()
    local doorData = {}
    
    -- Iterate through all entities and find VEIN doors
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
            local identifier = GetDoorIdentifier(door)
            if identifier then
                -- Get door angles for 3D panel rotation
                local angles = door:GetAngles()
                
                -- Get click normal, click position, and visual center (legacy world-space data)
                local clickNormal = door:GetNWVector("VEIN_ClickNormal", door:GetForward())
                local clickPos = door:GetNWVector("VEIN_ClickPos", door:LocalToWorld(door:OBBCenter()))
                local visualCenter = door:GetNWVector("VEIN_VisualCenter", door:LocalToWorld(door:OBBCenter()))

                -- Local-space hologram anchor (preferred, follows moving/rotating doors)
                local useLocalHologram = door:GetNWBool("VEIN_UseLocalHologram", false)
                local clickPosLocal = door:GetNWVector("VEIN_ClickPosLocal", Vector(0, 0, 0))
                local visualCenterLocal = door:GetNWVector("VEIN_VisualCenterLocal", Vector(0, 0, 0))
                local clickNormalLocal = door:GetNWVector("VEIN_ClickNormalLocal", Vector(1, 0, 0))

                if not useLocalHologram then
                    -- Migrate old doors on save by deriving local-space anchor from current world-space data.
                    clickPosLocal = door:WorldToLocal(clickPos)
                    visualCenterLocal = door:WorldToLocal(visualCenter)
                    clickNormalLocal = door:WorldToLocal(clickPos + clickNormal) - clickPosLocal
                    if clickNormalLocal:LengthSqr() <= 0.0001 then
                        clickNormalLocal = Vector(1, 0, 0)
                    else
                        clickNormalLocal:Normalize()
                    end
                    useLocalHologram = true
                end
                
                -- Store all relevant door properties
                doorData[identifier] = {
                    -- Core properties
                    name = door:GetNWString("VEIN_DoorName", ""),
                    lockName = door:GetNWBool("VEIN_LockName", false),
                    price = door:GetNWInt("VEIN_Price", 500),
                    buyable = door:GetNWBool("VEIN_Buyable", true),
                    allowOwnership = door:GetNWBool("VEIN_AllowOwnership", true),
                    adminOnly = door:GetNWBool("VEIN_AdminOnly", false),
                    defaultLocked = door:GetNWBool("VEIN_DefaultLocked", false),
                    locked = door:GetNWBool("VEIN_Locked", false),
                    
                    -- Door type and material
                    doorType = door:GetNWString("VEIN_DoorType", "Residential"),
                    doorMaterial = door:GetNWString("VEIN_DoorMaterial", "Light Metal"),
                    kickTime = door:GetNWInt("VEIN_KickTime", 25),
                    
                    -- Material sound properties
                    lockSound = door:GetNWString("VEIN_LockSound", "doors/door_latch3.wav"),
                    unlockSound = door:GetNWString("VEIN_UnlockSound", "doors/door_latch1.wav"),
                    kickSound = door:GetNWString("VEIN_KickSound", "physics/wood/wood_plank_break1.wav"),
                    breakSound = door:GetNWString("VEIN_BreakSound", "physics/wood/wood_crate_break1.wav"),
                    lockPitch = door:GetNWInt("VEIN_LockPitch", 100),
                    unlockPitch = door:GetNWInt("VEIN_UnlockPitch", 100),
                    kickPitch = door:GetNWInt("VEIN_KickPitch", 100),
                    breakPitch = door:GetNWInt("VEIN_BreakPitch", 100),
                    
                    -- Job/group restrictions
                    doorGroup = door:GetNWString("VEIN_DoorGroup", ""),
                    allowedJobs = door:GetNWString("VEIN_AllowedJobs", ""),
                    
                    -- Job controlled doors
                    jobControlled = door:GetNWBool("VEIN_JobControlled", false),
                    controlJobs = door:GetNWString("VEIN_ControlJobs", "[]"),
                    
                    -- Creator info
                    creator = door:GetNWString("VEIN_Creator", ""),
                    
                    -- Ownership data (NEW - persist across cleanup)
                    owner = door:GetNWString("VEIN_Owner", ""),
                    ownerName = door:GetNWString("VEIN_OwnerName", ""),
                    ownerSteamID = door:GetNWString("VEIN_OwnerSteamID", ""),
                    accessData = door:GetNWString("VEIN_AccessData", "{}"),
                    
                    -- Linked door group
                    linkGroup = door:GetNWInt("VEIN_LinkGroup", 0),
                    
                    -- Property group
                    propertyGroup = door:GetNWInt("VEIN_PropertyGroup", 0),
                    propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", ""),
                    propertyCustomPrice = door:GetNWInt("VEIN_PropertyCustomPrice", 0),
                    
                    -- Position and rotation data
                    position = {x = door:GetPos().x, y = door:GetPos().y, z = door:GetPos().z},
                    angles = {p = angles.p, y = angles.y, r = angles.r},
                    clickNormal = {x = clickNormal.x, y = clickNormal.y, z = clickNormal.z},
                    clickPos = {x = clickPos.x, y = clickPos.y, z = clickPos.z},
                    visualCenter = {x = visualCenter.x, y = visualCenter.y, z = visualCenter.z},
                    useLocalHologram = useLocalHologram,
                    clickNormalLocal = {x = clickNormalLocal.x, y = clickNormalLocal.y, z = clickNormalLocal.z},
                    clickPosLocal = {x = clickPosLocal.x, y = clickPosLocal.y, z = clickPosLocal.z},
                    visualCenterLocal = {x = visualCenterLocal.x, y = visualCenterLocal.y, z = visualCenterLocal.z},
                    model = door:GetModel(),
                    initialYaw = door:GetNWFloat("VEIN_InitialYaw", angles.y),
                }
                
            end
        end
    end
    
    -- Save to file (per-map)
    local doorsFile = GetDoorsFile()
    local success = pcall(function()
        file.Write(doorsFile, util.TableToJSON(doorData, true))
    end)
    
    if success then
        -- Silently save - no spam
        return true
    else
        print("[VEIN] ERROR: Failed to save doors to file!")
        return false
    end
end

-- Load all doors from file and apply them to map entities
-- restoreOwnership: If true, restores owner/permissions (for cleanup). If false, clears them (for map load).
function VEIN.DoorPersistence.LoadAllDoors(restoreOwnership)
    restoreOwnership = restoreOwnership or false -- Default to NOT restoring ownership
    
    local doorsFile = GetDoorsFile()
    if not file.Exists(doorsFile, "DATA") then
        print("[VEIN] No saved doors found for map: " .. game.GetMap())
        return false
    end
    
    local success, doorData = pcall(function()
        local json = file.Read(doorsFile, "DATA")
        return util.JSONToTable(json)
    end)
    
    if not success or not doorData then
        print("[VEIN] ERROR: Failed to load doors from file!")
        return false
    end
    
    local loadedCount = 0
    local failedCount = 0
    
    -- Clear the owned doors table to prevent conflicts
    if VEIN.DoorSystem and VEIN.DoorSystem.OwnedDoors then
        VEIN.DoorSystem.OwnedDoors = {}
    end
    
    -- Clear door access table
    if VEIN.DoorSystem and VEIN.DoorSystem.DoorAccess then
        VEIN.DoorSystem.DoorAccess = {}
    end
    
    local doorByIdentifier = {}
    local legacyLinks = {}
    
    -- Iterate through all entities and match them with saved data
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():find("door") then
            local identifier = GetDoorIdentifier(door)
            
            if identifier and doorData[identifier] then
                local data = doorData[identifier]
                doorByIdentifier[identifier] = door
                
                -- Mark as VEIN door and setup
                door:SetNWBool("VEIN_IsVEINDoor", true)
                door:SetNWBool("VEIN_IsSetup", true)
                door:SetNWInt("VEIN_LinkGroup", data.linkGroup or 0)
                door:SetNWInt("VEIN_PropertyGroup", data.propertyGroup or 0)
                door:SetNWString("VEIN_PropertyGroupName", data.propertyGroupName or "")
                door:SetNWInt("VEIN_PropertyCustomPrice", data.propertyCustomPrice or 0)
                
                -- Core door info
                door:SetNWString("VEIN_DoorName", data.name or "")
                door:SetNWBool("VEIN_LockName", data.lockName or false)
                door:SetNWInt("VEIN_Price", data.price or 500)
                
                -- Ownership restoration logic (only restore if restoreOwnership is true)
                local hasOwner = restoreOwnership and data.owner and data.owner ~= ""
                if hasOwner then
                    -- CLEANUP MODE: Restore ownership and permissions
                    door:SetNWString("VEIN_Owner", data.owner)
                    door:SetNWString("VEIN_OwnerName", data.ownerName or "")
                    door:SetNWString("VEIN_OwnerSteamID", data.ownerSteamID or data.owner)
                    door:SetNWString("VEIN_AccessData", data.accessData or "{}")
                    
                -- Update internal ownership tracking table
                if VEIN.DoorSystem and VEIN.DoorSystem.OwnedDoors then
                    VEIN.DoorSystem.OwnedDoors[door:EntIndex()] = data.owner
                end
                else
                    -- NORMAL LOAD MODE: Clear all ownership data (reset to FOR SALE)
                    door:SetNWString("VEIN_Owner", "")
                    door:SetNWString("VEIN_OwnerName", "")
                    door:SetNWString("VEIN_OwnerSteamID", "")
                    door:SetNWString("VEIN_AccessData", "{}")
                end
                door:SetNWString("VEIN_AccessList", "")
                
                -- Apply ownership and buyable settings
                local allowOwn = data.allowOwnership ~= false
                door:SetNWBool("VEIN_AllowOwnership", allowOwn)
                
                -- AdminOnly should ONLY be true if allowOwnership is false AND it's NOT job-controlled
                -- Job-controlled doors have allowOwnership=false but are NOT admin-only
                local isJobControlled = data.jobControlled or false
                local isAdminOnly = (not allowOwn) and (not isJobControlled)
                door:SetNWBool("VEIN_AdminOnly", isAdminOnly)
                
                -- Buyable should be TRUE (for sale) unless:
                -- 1. It's a static admin door or job-controlled
                -- 2. OR the door is owned (has owner after restoration)
                local isBuyable = allowOwn and not isAdminOnly and not isJobControlled and not hasOwner
                door:SetNWBool("VEIN_Buyable", isBuyable)
                
                -- Door type and material
                door:SetNWString("VEIN_DoorType", data.doorType or "Residential")
                door:SetNWString("VEIN_DoorMaterial", data.doorMaterial or "Light Metal")
                door:SetNWInt("VEIN_KickTime", data.kickTime or 25)
                
                -- Material sound properties
                door:SetNWString("VEIN_LockSound", data.lockSound or "doors/door_latch3.wav")
                door:SetNWString("VEIN_UnlockSound", data.unlockSound or "doors/door_latch1.wav")
                door:SetNWString("VEIN_KickSound", data.kickSound or "physics/wood/wood_plank_break1.wav")
                door:SetNWString("VEIN_BreakSound", data.breakSound or "physics/wood/wood_crate_break1.wav")
                door:SetNWInt("VEIN_LockPitch", data.lockPitch or 100)
                door:SetNWInt("VEIN_UnlockPitch", data.unlockPitch or 100)
                door:SetNWInt("VEIN_KickPitch", data.kickPitch or 100)
                door:SetNWInt("VEIN_BreakPitch", data.breakPitch or 100)
                
                -- Job/group restrictions - IMPORTANT: Save these properly
                door:SetNWString("VEIN_DoorGroup", data.doorGroup or "")
                door:SetNWString("VEIN_AllowedJobs", data.allowedJobs or "")
                
                -- Job controlled doors
                door:SetNWBool("VEIN_JobControlled", data.jobControlled or false)
                door:SetNWString("VEIN_ControlJobs", data.controlJobs or "[]")
                
                -- Creator info
                door:SetNWString("VEIN_Creator", data.creator or "")
                
                -- Default locked state - IMPORTANT: This is the DEFAULT, not current state
                door:SetNWBool("VEIN_DefaultLocked", data.defaultLocked or false)
                
                -- Apply DEFAULT lock state on load (not saved locked state)
                if data.defaultLocked then
                    door:Fire("Lock")
                    door:SetNWBool("VEIN_Locked", true)
                else
                    door:Fire("Unlock")
                    door:SetNWBool("VEIN_Locked", false)
                end
                
                -- Store initial angles for 3D panel rotation
                if data.angles then
                    door:SetNWFloat("VEIN_InitialYaw", data.angles.y)
                    door:SetNWFloat("VEIN_InitialPitch", data.angles.p)
                    door:SetNWFloat("VEIN_InitialRoll", data.angles.r)
                else
                    door:SetNWFloat("VEIN_InitialYaw", data.initialYaw or 0)
                end
                
                -- Restore click normal, click position, and visual center for 3D panel positioning
                if data.clickNormal then
                    door:SetNWVector("VEIN_ClickNormal", Vector(data.clickNormal.x, data.clickNormal.y, data.clickNormal.z))
                else
                    -- Default to door's forward if not saved
                    door:SetNWVector("VEIN_ClickNormal", door:GetForward())
                end
                
                if data.clickPos then
                    door:SetNWVector("VEIN_ClickPos", Vector(data.clickPos.x, data.clickPos.y, data.clickPos.z))
                else
                    -- Default to door center if not saved
                    door:SetNWVector("VEIN_ClickPos", door:LocalToWorld(door:OBBCenter()))
                end
                
                if data.visualCenter then
                    door:SetNWVector("VEIN_VisualCenter", Vector(data.visualCenter.x, data.visualCenter.y, data.visualCenter.z))
                else
                    -- Calculate visual center for old doors
                    local mins, maxs = door:OBBMins(), door:OBBMaxs()
                    local localCenter = (mins + maxs) / 2
                    door:SetNWVector("VEIN_VisualCenter", door:LocalToWorld(localCenter))
                end

                -- Restore preferred local-space hologram anchor; migrate old saves automatically.
                local useLocalHologram = data.useLocalHologram or false
                local clickPosLocal
                local visualCenterLocal
                local clickNormalLocal

                if data.clickPosLocal and data.visualCenterLocal and data.clickNormalLocal then
                    clickPosLocal = Vector(data.clickPosLocal.x, data.clickPosLocal.y, data.clickPosLocal.z)
                    visualCenterLocal = Vector(data.visualCenterLocal.x, data.visualCenterLocal.y, data.visualCenterLocal.z)
                    clickNormalLocal = Vector(data.clickNormalLocal.x, data.clickNormalLocal.y, data.clickNormalLocal.z)
                    if clickNormalLocal:LengthSqr() <= 0.0001 then
                        clickNormalLocal = Vector(1, 0, 0)
                    else
                        clickNormalLocal:Normalize()
                    end
                    useLocalHologram = true
                else
                    local worldClickPos = door:GetNWVector("VEIN_ClickPos", door:LocalToWorld(door:OBBCenter()))
                    local worldVisualCenter = door:GetNWVector("VEIN_VisualCenter", door:LocalToWorld(door:OBBCenter()))
                    local worldClickNormal = door:GetNWVector("VEIN_ClickNormal", door:GetForward())
                    if worldClickNormal:LengthSqr() <= 0.0001 then
                        worldClickNormal = door:GetForward()
                    else
                        worldClickNormal:Normalize()
                    end

                    clickPosLocal = door:WorldToLocal(worldClickPos)
                    visualCenterLocal = door:WorldToLocal(worldVisualCenter)
                    clickNormalLocal = door:WorldToLocal(worldClickPos + worldClickNormal) - clickPosLocal
                    if clickNormalLocal:LengthSqr() <= 0.0001 then
                        clickNormalLocal = Vector(1, 0, 0)
                    else
                        clickNormalLocal:Normalize()
                    end
                    useLocalHologram = true
                end

                door:SetNWVector("VEIN_ClickPosLocal", clickPosLocal)
                door:SetNWVector("VEIN_VisualCenterLocal", visualCenterLocal)
                door:SetNWVector("VEIN_ClickNormalLocal", clickNormalLocal)
                door:SetNWBool("VEIN_UseLocalHologram", useLocalHologram)
                
                loadedCount = loadedCount + 1
                
                if data.linkedDoor and (not data.linkGroup or data.linkGroup == 0) then
                    table.insert(legacyLinks, {
                        identifier = identifier,
                        linkedIdentifier = data.linkedDoor,
                    })
                end
            end
        end
    end
    
    print("[VEIN] Loaded " .. loadedCount .. " door(s) from data file")
    
    if loadedCount == 0 and table.Count(doorData) > 0 then
        print("[VEIN] WARNING: " .. table.Count(doorData) .. " door(s) saved but none found on map!")
    end
    
    -- Second pass: Restore linked door groups (and migrate legacy single-link data)
    if VEIN.DoorSystem and VEIN.DoorSystem.RebuildLinkGroupsFromDoors then
        for _, link in ipairs(legacyLinks) do
            local door = doorByIdentifier[link.identifier]
            local linkedDoor = doorByIdentifier[link.linkedIdentifier]
            if IsValid(door) and IsValid(linkedDoor) then
                door:SetNWEntity("VEIN_LinkedDoor", linkedDoor)
                linkedDoor:SetNWEntity("VEIN_LinkedDoor", door)
            end
        end
        
        VEIN.DoorSystem.RebuildLinkGroupsFromDoors()
    else
        -- Fallback: restore legacy single-link if present
        local linkedCount = 0
        for _, door in ipairs(ents.GetAll()) do
            if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
                local identifier = GetDoorIdentifier(door)
                if identifier and doorData[identifier] and doorData[identifier].linkedDoor then
                    for _, linkedDoor in ipairs(ents.GetAll()) do
                        if IsValid(linkedDoor) and linkedDoor:GetNWBool("VEIN_IsVEINDoor", false) then
                            local linkedIdentifier = GetDoorIdentifier(linkedDoor)
                            if linkedIdentifier == doorData[identifier].linkedDoor then
                                door:SetNWEntity("VEIN_LinkedDoor", linkedDoor)
                                linkedCount = linkedCount + 1
                                break
                            end
                        end
                    end
                end
            end
        end
        
        if linkedCount > 0 then
            print("[VEIN] Restored " .. linkedCount .. " door link(s)")
        end
    end

    if VEIN.DoorSystem and VEIN.DoorSystem.RebuildPropertyGroupsFromDoors then
        VEIN.DoorSystem.RebuildPropertyGroupsFromDoors()
    end
    
    return true
end

-- Hook into door creation to auto-save
hook.Add("VEIN_DoorCreated", "VEIN_AutoSaveDoors", function()
    timer.Simple(0.5, function()
        VEIN.DoorPersistence.SaveAllDoors()
    end)
end)

-- Hook into door removal to auto-save
hook.Add("VEIN_DoorRemoved", "VEIN_AutoSaveDoors", function()
    timer.Simple(0.5, function()
        VEIN.DoorPersistence.SaveAllDoors()
    end)
end)

-- Hook into door modification to auto-save
-- Hook for auto-saving doors when modified (used by door manager tool)
hook.Add("VEIN_DoorModified", "VEIN_AutoSaveDoors", function()
    timer.Simple(0.5, function()
        VEIN.DoorPersistence.SaveAllDoors()
    end)
end)

-- Hook for auto-saving doors when modified (used by keys weapon)
hook.Add("VEIN_OnDoorModified", "VEIN_AutoSaveDoors2", function()
    timer.Simple(0.5, function()
        VEIN.DoorPersistence.SaveAllDoors()
    end)
end)

-- Load doors when server starts (WITHOUT ownership - fresh start)
hook.Add("InitPostEntity", "VEIN_LoadDoors", function()
    timer.Simple(2, function() -- Wait a bit for all entities to spawn
        VEIN.DoorPersistence.LoadAllDoors(false) -- false = clear ownership
    end)
end)

-- Save before cleanup and restore after cleanup (map clean doesn't always remove entities)
hook.Add("PreCleanupMap", "VEIN_SaveDoorsBeforeCleanup", function()
    VEIN.DoorPersistence.SaveAllDoors()
end)

hook.Add("PostCleanupMap", "VEIN_RestoreDoorsAfterCleanup", function()
    timer.Simple(0.5, function()
        VEIN.DoorPersistence.LoadAllDoors(true) -- restore ownership + configuration
    end)
end)

-- Save doors when server shuts down
hook.Add("ShutDown", "VEIN_SaveDoors", function()
    VEIN.DoorPersistence.SaveAllDoors()
end)

-- Detect when VEIN doors are removed (e.g., by cleanup commands) and reload all doors
hook.Add("EntityRemoved", "VEIN_RestoreDoorsOnCleanup", function(ent)
    if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) then
        -- A VEIN door was removed - schedule a restore
        print("[VEIN] Detected VEIN door removal: " .. (ent:GetNWString("VEIN_DoorName", "Unnamed")))
        
        -- Use a timer to batch multiple door removals (cleanup removes many at once)
        timer.Create("VEIN_RestoreDoorsAfterCleanup", 1, 1, function()
            print("[VEIN] Restoring doors after cleanup/removal...")
            
            -- Reload all doors from saved data WITH ownership restoration
            VEIN.DoorPersistence.LoadAllDoors(true) -- true = restore ownership
            
            -- Notify admins
            for _, ply in ipairs(player.GetAll()) do
                local isDoorAdmin = VEIN.Settings and VEIN.Settings.IsDoorAdmin and VEIN.Settings.IsDoorAdmin(ply)
                if ply:IsAdmin() or ply:IsSuperAdmin() or isDoorAdmin then
                    ply:ChatPrint("[VEIN] Door system detected cleanup - doors have been restored!")
                end
            end
        end)
    end
end)

-- Admin command to manually save doors
concommand.Add("vein_save_doors", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then
        ply:ChatPrint("[VEIN] You must be an admin to use this command!")
        return
    end
    
    if VEIN.DoorPersistence.SaveAllDoors() then
        if IsValid(ply) then
            ply:ChatPrint("[VEIN] Doors saved successfully!")
        end
    else
        if IsValid(ply) then
            ply:ChatPrint("[VEIN] Failed to save doors!")
        end
    end
end)

-- Admin command to manually load doors
-- Usage: vein_load_doors [1/0] - 1 to restore ownership (cleanup mode), 0 to clear it (default)
concommand.Add("vein_load_doors", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsAdmin() then
        ply:ChatPrint("[VEIN] You must be an admin to use this command!")
        return
    end
    
    local restoreOwnership = args[1] == "1"
    
    if VEIN.DoorPersistence.LoadAllDoors(restoreOwnership) then
        if IsValid(ply) then
            if restoreOwnership then
                ply:ChatPrint("[VEIN] Doors loaded WITH ownership restored!")
            else
                ply:ChatPrint("[VEIN] Doors loaded (ownership cleared - fresh start)!")
            end
        end
    else
        if IsValid(ply) then
            ply:ChatPrint("[VEIN] Failed to load doors!")
        end
    end
end)


