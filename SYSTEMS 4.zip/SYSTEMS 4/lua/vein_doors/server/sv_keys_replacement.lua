--[[
================================================================================
VEIN Door System - Replace DarkRP Keys with VEIN Keys
Automatically gives players VEIN keys instead of DarkRP keys
================================================================================
]]--

if CLIENT then return end

-- Wait for DarkRP to load
hook.Add("InitPostEntity", "VEIN_ReplaceKeysWeapon", function()
    timer.Simple(1, function()
        if not DarkRP then 
            return 
        end
        
        -- Override DarkRP's default weapons table
        if GAMEMODE and GAMEMODE.Config and GAMEMODE.Config.DefaultWeapons then
            local found = false
            for k, v in ipairs(GAMEMODE.Config.DefaultWeapons) do
                if v == "keys" then
                    GAMEMODE.Config.DefaultWeapons[k] = "vein_keys"
                    found = true
                end
            end
            
            if not found then
                -- Add VEIN keys if not present
                table.insert(GAMEMODE.Config.DefaultWeapons, "vein_keys")
            end
        end
        
        -- Also check the global DarkRP config
        if DarkRP and DarkRP.Config and DarkRP.Config.DefaultWeapons then
            for k, v in ipairs(DarkRP.Config.DefaultWeapons) do
                if v == "keys" then
                    DarkRP.Config.DefaultWeapons[k] = "vein_keys"
                end
            end
        end
        
        -- Hook into player spawn to give VEIN keys
        hook.Add("PlayerLoadout", "VEIN_GiveKeysOnSpawn", function(ply)
            -- Remove DarkRP keys if they have them
            if ply:HasWeapon("keys") then
                ply:StripWeapon("keys")
            end
            
            -- Give VEIN keys
            if not ply:HasWeapon("vein_keys") then
                ply:Give("vein_keys")
            end
        end)
        
        -- Replace any existing keys with VEIN keys
        hook.Add("PlayerSpawn", "VEIN_ReplaceKeysOnSpawn", function(ply)
            timer.Simple(0.1, function()
                if not IsValid(ply) then return end
                
                -- Remove DarkRP keys
                if ply:HasWeapon("keys") then
                    ply:StripWeapon("keys")
                end
                
                -- Give VEIN keys
                if not ply:HasWeapon("vein_keys") then
                    ply:Give("vein_keys")
                end
            end)
        end)
        
        -- Replace keys for all current players
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                if ply:HasWeapon("keys") then
                    ply:StripWeapon("keys")
                end
                
                if not ply:HasWeapon("vein_keys") then
                    ply:Give("vein_keys")
                end
            end
        end
    end)
end)

-- Prevent DarkRP from giving keys weapon
hook.Add("canDropWeapon", "VEIN_PreventKeysPickup", function(ply, weapon)
    if not IsValid(weapon) then return end
    if weapon:GetClass() == "keys" then
        return false -- Don't allow picking up DarkRP keys
    end
end)

-- Hook to replace any keys weapon spawned
hook.Add("OnEntityCreated", "VEIN_RemoveDarkRPKeys", function(ent)
    timer.Simple(0, function()
        if IsValid(ent) and ent:GetClass() == "keys" then
            -- Don't allow DarkRP keys to exist
            ent:Remove()
        end
    end)
end)
