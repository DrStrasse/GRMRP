--[[
================================================================================
VEIN Door System - Clear All Doors Command
Allows admins to remove all VEIN door configurations
================================================================================
]]--

if CLIENT then return end

-- Console command to clear all doors
concommand.Add("vein_clear_all_doors", function(ply, cmd, args)
    -- Check admin permission
    if IsValid(ply) and not ply:IsAdmin() then
        if VEIN and VEIN.Chat then
            VEIN.Chat(ply, "You must be an admin to use this command!")
        else
            ply:ChatPrint("[VEIN] You must be an admin to use this command!")
        end
        return
    end
    
    local clearedCount = 0
    
    -- Find all VEIN doors and clear their data
    for _, ent in ipairs(ents.GetAll()) do
        if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) then
            -- Clear all VEIN network variables
            ent:SetNWBool("VEIN_IsVEINDoor", false)
            ent:SetNWBool("VEIN_IsSetup", false)
            ent:SetNWString("VEIN_DoorName", "")
            ent:SetNWInt("VEIN_Price", 0)
            ent:SetNWString("VEIN_DoorMaterial", "")
            ent:SetNWInt("VEIN_KickTime", 0)
            ent:SetNWString("VEIN_DoorType", "")
            ent:SetNWBool("VEIN_Buyable", false)
            ent:SetNWBool("VEIN_DefaultLocked", false)
            ent:SetNWBool("VEIN_Locked", false)
            ent:SetNWString("VEIN_Owner", "")
            ent:SetNWBool("VEIN_AllowOwnership", false)
            ent:SetNWString("VEIN_Creator", "")
            ent:SetNWString("VEIN_AccessList", "")
            ent:SetNWString("VEIN_DoorGroup", "")
            ent:SetNWString("VEIN_AllowedJobs", "[]")
            ent:SetNWBool("VEIN_JobControlled", false)
            ent:SetNWString("VEIN_ControlJobs", "[]")
            ent:SetNWInt("VEIN_LinkGroup", 0)
            ent:SetNWInt("VEIN_LinkCount", 1)
            ent:SetNWInt("VEIN_LinkTotalPrice", 0)
            ent:SetNWInt("VEIN_PropertyGroup", 0)
            ent:SetNWString("VEIN_PropertyGroupName", "")
            ent:SetNWInt("VEIN_PropertyCustomPrice", 0)
            ent:SetNWInt("VEIN_PropertyCount", 1)
            ent:SetNWInt("VEIN_PropertyTotalPrice", 0)
            ent:SetNWBool("VEIN_AutoLockOnClose", false)
            
            -- Unlock the door
            ent:Fire("Unlock")
            
            clearedCount = clearedCount + 1
        end
    end
    
    -- Clear saved door data files
    if file.Exists("vein_doors.json", "DATA") then
        file.Delete("vein_doors.json")
        print("[VEIN] Deleted vein_doors.json")
    end
    
    if file.Exists("vein_auto_detected_doors.json", "DATA") then
        file.Delete("vein_auto_detected_doors.json")
        print("[VEIN] Deleted vein_auto_detected_doors.json")
    end
    
    -- Clear door access data
    if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.DoorAccess then
        VEIN.DoorSystem.DoorAccess = {}
    end

    if VEIN and VEIN.DoorSystem then
        VEIN.DoorSystem.PropertyGroups = {}
        VEIN.DoorSystem.PropertyGroupNameToId = {}
    end
    
    -- Clear door ownership data
    if VEIN and VEIN.DoorOwnership then
        VEIN.DoorOwnership = {}
    end
    
    -- Notify
    local adminName = IsValid(ply) and ply:Nick() or "Console"
    print("[VEIN] " .. adminName .. " cleared " .. clearedCount .. " VEIN doors")
    
    if IsValid(ply) then
        if VEIN and VEIN.Chat then
            VEIN.Chat(ply, "Successfully cleared " .. clearedCount .. " VEIN doors!")
        else
            ply:ChatPrint("[VEIN] Successfully cleared " .. clearedCount .. " VEIN doors!")
        end
    else
        print("[VEIN] Successfully cleared " .. clearedCount .. " VEIN doors from console")
    end
    
    -- Broadcast to all players
    for _, p in ipairs(player.GetAll()) do
        if p:IsAdmin() and p ~= ply then
            if VEIN and VEIN.Chat then
                VEIN.Chat(p, adminName .. " cleared all VEIN doors (" .. clearedCount .. " doors)")
            else
                p:ChatPrint("[VEIN] " .. adminName .. " cleared all VEIN doors (" .. clearedCount .. " doors)")
            end
        end
    end
end)
