--[[
================================================================================
VEIN Door System - NEW Server Settings Handler  
Completely rewritten for reliability
================================================================================
]]--

if CLIENT then return end

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.Net = VEIN.Net or {}

local Net = VEIN.Net

-- Network strings for new system
util.AddNetworkString("VEIN_RequestSettingsData")
util.AddNetworkString("VEIN_SettingsData")
util.AddNetworkString("VEIN_UpdateSettingsData") 
util.AddNetworkString("VEIN_RequestPlayerList")
util.AddNetworkString("VEIN_PlayerListData")
util.AddNetworkString("VEIN_SetPlayerLimit")
util.AddNetworkString("VEIN_ResetPlayerLimit")
util.AddNetworkString("VEIN_RequestDoorAdmins")
util.AddNetworkString("VEIN_DoorAdminList")
util.AddNetworkString("VEIN_AddDoorAdmin")
util.AddNetworkString("VEIN_RemoveDoorAdmin")
util.AddNetworkString("VEIN_SetDoorAdminPerms")
util.AddNetworkString("VEIN_DoorAdminSelf")

-- ConVars (create if they don't exist)
-- Default to DarkRP money if DarkRP is detected, otherwise use VEIN custom money
local defaultMoneySystem = DarkRP and "0" or "1"
local cvUseCustomMoney = GetConVar("vein_use_custom_money") or CreateConVar("vein_use_custom_money", defaultMoneySystem, FCVAR_ARCHIVE, "Use VEIN custom money system")
local cvDefaultLimit = GetConVar("vein_default_door_limit") or CreateConVar("vein_default_door_limit", "3", FCVAR_ARCHIVE, "Default door limit")
local cvEnableLimits = GetConVar("vein_enable_door_limits") or CreateConVar("vein_enable_door_limits", "1", FCVAR_ARCHIVE, "Enable door limits")
local cvRefundPercent = GetConVar("vein_door_refund_percent") or CreateConVar("vein_door_refund_percent", "50", FCVAR_ARCHIVE, "Percentage of door price refunded when selling (0-100)")
local cvEnableKicking = GetConVar("vein_enable_door_kicking") or CreateConVar("vein_enable_door_kicking", "1", FCVAR_ARCHIVE + FCVAR_REPLICATED, "Enable door kicking (1) or disable completely (0)")

-- Notify about money system
if DarkRP then
    print("[VEIN] DarkRP detected! Using DarkRP money system.")
else
    print("[VEIN] No DarkRP detected. Using VEIN custom money system.")
end

-- Player door limits storage
VEIN.NewSettings = VEIN.NewSettings or {}
VEIN.NewSettings.PlayerLimits = VEIN.NewSettings.PlayerLimits or {}

-- Door admin list (door-only permissions)
VEIN.Settings = VEIN.Settings or {}
VEIN.Settings.DoorAdmins = VEIN.Settings.DoorAdmins or {}

local defaultDoorAdminPerms = {
    adminDeleteDoor = false,
    adminCreateDoor = false,
    adminModifyDoor = false,
    adminForceSellDoor = false,
    adminEditGroupsDoor = false,
    adminDisableEnableDoor = true,
    adminTeleportDoor = false,
}

local function CopyPerms(src)
    local perms = {}
    for key, value in pairs(src) do
        perms[key] = value and true or false
    end
    return perms
end

local function IsValidSteamID(steamID)
    return isstring(steamID) and steamID ~= ""
end

local function IsBotKey(steamID)
    return isstring(steamID) and string.StartWith(steamID, "BOT_")
end

local function NormalizeDoorAdminKey(steamID, entry)
    local key = isstring(steamID) and string.Trim(steamID) or ""
    if key == "" then return "" end
    if key == "BOT" then
        local name = istable(entry) and entry.name or ""
        name = isstring(name) and string.Trim(name) or ""
        if name ~= "" then
            return "BOT_" .. name
        end
    end
    return key
end

local function GetDoorAdminKeyForPlayer(ply)
    if not IsValid(ply) then return "" end
    if ply:IsBot() then
        return "BOT_" .. ply:Nick()
    end
    return ply:SteamID()
end

local function FindBotByKey(botKey)
    if not IsBotKey(botKey) then return nil end
    local botName = string.sub(botKey, 5)
    for _, p in ipairs(player.GetAll()) do
        if p:IsBot() and p:Nick() == botName then
            return p
        end
    end
    return nil
end

local function NormalizeDoorAdminEntry(entry, fallbackName)
    if entry == nil then return nil end
    if isstring(entry) or entry == true then
        return {name = isstring(entry) and entry or (fallbackName or ""), perms = CopyPerms(defaultDoorAdminPerms)}
    end
    if istable(entry) then
        entry.name = isstring(entry.name) and entry.name or (fallbackName or "")
        if not istable(entry.perms) then
            entry.perms = CopyPerms(defaultDoorAdminPerms)
        else
            if entry.perms.adminDisableDoor or entry.perms.adminEnableDoor then
                entry.perms.adminDisableEnableDoor = true
            end
            entry.perms.adminDisableDoor = nil
            entry.perms.adminEnableDoor = nil
            for key, _ in pairs(defaultDoorAdminPerms) do
                if entry.perms[key] == nil then
                    entry.perms[key] = false
                end
            end
        end
        return entry
    end
    return nil
end

local function NormalizeDoorAdminTable()
    local normalized = {}
    for steamID, entry in pairs(VEIN.Settings.DoorAdmins or {}) do
        local key = NormalizeDoorAdminKey(steamID, entry)
        if key ~= "" then
            entry = NormalizeDoorAdminEntry(entry)
            if entry then
                if IsBotKey(key) then
                    local botName = string.sub(key, 5)
                    if entry.name == "" then
                        entry.name = botName
                    end
                end
                normalized[key] = entry
            end
        end
    end
    VEIN.Settings.DoorAdmins = normalized
end

local function GetDoorAdminPerms(steamID)
    local entry = VEIN.Settings.DoorAdmins[steamID]
    entry = NormalizeDoorAdminEntry(entry)
    if not entry then return {} end
    VEIN.Settings.DoorAdmins[steamID] = entry
    return entry.perms or {}
end

function VEIN.Settings.IsDoorAdmin(ply)
    if not IsValid(ply) then return false end
    local steamID = GetDoorAdminKeyForPlayer(ply)
    return VEIN.Settings.DoorAdmins and VEIN.Settings.DoorAdmins[steamID] ~= nil
end

function VEIN.Settings.HasDoorAdminPermission(ply, perm)
    if not IsValid(ply) then return false end
    if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
    local steamID = GetDoorAdminKeyForPlayer(ply)
    if not VEIN.Settings.DoorAdmins or not VEIN.Settings.DoorAdmins[steamID] then return false end
    local perms = GetDoorAdminPerms(steamID)
    return perms[perm] == true
end

local function SaveDoorAdmins()
    file.Write("vein_door_admins.json", util.TableToJSON(VEIN.Settings.DoorAdmins, true))
end

local function BuildDoorAdminList()
    NormalizeDoorAdminTable()
    local list = {}
    for steamID, entry in pairs(VEIN.Settings.DoorAdmins) do
        entry = NormalizeDoorAdminEntry(entry)
        if entry then
            VEIN.Settings.DoorAdmins[steamID] = entry
            local displayName = entry.name or ""
            local ply = player.GetBySteamID(steamID)
            if IsValid(ply) then
                displayName = ply:Nick()
            elseif IsBotKey(steamID) then
                local botPly = FindBotByKey(steamID)
                if IsValid(botPly) then
                    displayName = botPly:Nick()
                elseif displayName == "" then
                    displayName = string.sub(steamID, 5)
                end
            end
            table.insert(list, {steamid = steamID, name = displayName, perms = entry.perms or {}})
        end
    end
    return list
end

local function SendDoorAdminSelf(ply)
    if not IsValid(ply) then return end
    local steamID = GetDoorAdminKeyForPlayer(ply)
    local entry = NormalizeDoorAdminEntry(VEIN.Settings.DoorAdmins[steamID], ply:Nick())
    if entry then
        VEIN.Settings.DoorAdmins[steamID] = entry
    end
    net.Start("VEIN_DoorAdminSelf")
    net.WriteBool(entry ~= nil)
    Net.WriteStringBoolMap(entry and (entry.perms or {}) or {})
    net.Send(ply)
end

local function BroadcastDoorAdminList()
    local list = BuildDoorAdminList()
    for _, p in ipairs(player.GetAll()) do
        if p:IsAdmin() then
            net.Start("VEIN_DoorAdminList")
            Net.WriteDoorAdminList(list)
            net.Send(p)
        end
        SendDoorAdminSelf(p)
    end
end

hook.Add("PlayerInitialSpawn", "VEIN_SendDoorAdminSelf", function(ply)
    timer.Simple(2, function()
        if IsValid(ply) then
            SendDoorAdminSelf(ply)
        end
    end)
end)

-- Handle settings data request
net.Receive("VEIN_RequestSettingsData", function(len, ply)
    if not ply:IsAdmin() then 
        return 
    end
    
    net.Start("VEIN_SettingsData")
    net.WriteBool(cvUseCustomMoney:GetBool())
    net.WriteInt(cvDefaultLimit:GetInt(), 16)
    net.WriteBool(cvEnableLimits:GetBool())
    Net.WriteStringIntMap(VEIN.NewSettings.PlayerLimits, 16)
    net.Send(ply)
end)

-- Handle door admin list request
net.Receive("VEIN_RequestDoorAdmins", function(len, ply)
    if not ply:IsAdmin() then return end
    net.Start("VEIN_DoorAdminList")
    Net.WriteDoorAdminList(BuildDoorAdminList())
    net.Send(ply)
end)

-- Add door admin (door-only permissions)
net.Receive("VEIN_AddDoorAdmin", function(len, ply)
    if not ply:IsAdmin() then return end
    local steamID = net.ReadString()
    local name = net.ReadString()
    local keyEntry = {name = name}
    steamID = NormalizeDoorAdminKey(steamID, keyEntry)
    if not IsValidSteamID(steamID) then return end
    local entry = NormalizeDoorAdminEntry(VEIN.Settings.DoorAdmins[steamID], name)
    if not entry then
        local newEntry = {name = name or "", perms = CopyPerms(defaultDoorAdminPerms)}
        entry = newEntry
    end
    entry.name = name ~= "" and name or entry.name or ""
    VEIN.Settings.DoorAdmins[steamID] = entry
    NormalizeDoorAdminTable()
    SaveDoorAdmins()
    BroadcastDoorAdminList()
end)

-- Remove door admin
net.Receive("VEIN_RemoveDoorAdmin", function(len, ply)
    if not ply:IsAdmin() then return end
    local steamID = net.ReadString()
    steamID = NormalizeDoorAdminKey(steamID, VEIN.Settings.DoorAdmins[steamID])
    if not IsValidSteamID(steamID) then return end
    VEIN.Settings.DoorAdmins[steamID] = nil
    SaveDoorAdmins()
    BroadcastDoorAdminList()
end)

-- Update door admin permissions
net.Receive("VEIN_SetDoorAdminPerms", function(len, ply)
    if not ply:IsAdmin() then return end
    local steamID = net.ReadString()
    local perms = Net.ReadStringBoolMap()
    steamID = NormalizeDoorAdminKey(steamID, VEIN.Settings.DoorAdmins[steamID])
    if not IsValidSteamID(steamID) then return end

    local entry = NormalizeDoorAdminEntry(VEIN.Settings.DoorAdmins[steamID])
    if not entry then return end

    entry.perms = entry.perms or {}
    for key, _ in pairs(defaultDoorAdminPerms) do
        entry.perms[key] = perms[key] == true
    end
    VEIN.Settings.DoorAdmins[steamID] = entry
    SaveDoorAdmins()
    BroadcastDoorAdminList()
end)

-- Handle settings update
net.Receive("VEIN_UpdateSettingsData", function(len, ply)
    if not ply:IsAdmin() then 
        return 
    end
    
    local useCustomMoney = net.ReadBool()
    local defaultLimit = net.ReadInt(16)
    local enableLimits = net.ReadBool()
    
    -- Update ConVars
    RunConsoleCommand("vein_use_custom_money", useCustomMoney and "1" or "0")
    RunConsoleCommand("vein_default_door_limit", tostring(defaultLimit))
    RunConsoleCommand("vein_enable_door_limits", enableLimits and "1" or "0")
    
    -- Settings updated (no broadcast message needed)
    
    -- Send updated settings back to all admin clients
    timer.Simple(0.1, function()
        for _, p in ipairs(player.GetAll()) do
            if p:IsAdmin() then
                net.Start("VEIN_SettingsData")
                net.WriteBool(cvUseCustomMoney:GetBool())
                net.WriteInt(cvDefaultLimit:GetInt(), 16)
                net.WriteBool(cvEnableLimits:GetBool())
                Net.WriteStringIntMap(VEIN.NewSettings.PlayerLimits, 16)
                net.Send(p)
            end
        end
    end)
end)

-- Handle player list request
net.Receive("VEIN_RequestPlayerList", function(len, ply)
    if not ply:IsAdmin() then return end
    
    local playerData = {}
    for _, p in ipairs(player.GetAll()) do
        -- Count doors owned by this player
        local ownedDoors = 0
        for _, door in ipairs(ents.GetAll()) do
            if IsValid(door) and door:GetClass():match("door") then
                local doorOwner = door:GetNWString("VEIN_Owner", "")
                if doorOwner == p:Nick() then
                    ownedDoors = ownedDoors + 1
                end
            end
        end
        
        -- Get unique ID (different for bots vs players)
        local uniqueID
        if p:IsBot() then
            uniqueID = "BOT_" .. p:Nick() -- Unique per bot name
        else
            uniqueID = p:SteamID() -- Normal SteamID
        end
        
        -- Ensure table exists
        VEIN.Settings = VEIN.Settings or {}
        VEIN.Settings.PlayerDoorLimits = VEIN.Settings.PlayerDoorLimits or {}
        
        -- Get custom limit from the CORRECT table
        local customLimit = VEIN.Settings.PlayerDoorLimits[uniqueID]
        local defaultLimit = cvDefaultLimit:GetInt()
        
        table.insert(playerData, {
            name = p:Nick(),
            steamid = uniqueID,  -- Send unique ID (works for both players and bots)
            ownedDoors = ownedDoors,
            customLimit = customLimit,
            defaultLimit = defaultLimit
        })
    end
    
    net.Start("VEIN_PlayerListData")
    Net.WritePlayerList(playerData)
    net.Send(ply)
end)

-- Handle setting custom player limit
net.Receive("VEIN_SetPlayerLimit", function(len, ply)
    if not ply:IsAdmin() then 
        return 
    end
    
    local uniqueID = net.ReadString()
    local limit = net.ReadInt(16)
    
    -- Ensure table exists
    VEIN.Settings = VEIN.Settings or {}
    VEIN.Settings.PlayerDoorLimits = VEIN.Settings.PlayerDoorLimits or {}
    
    -- Set the custom limit in the CORRECT table
    VEIN.Settings.PlayerDoorLimits[uniqueID] = limit
    
    -- Save immediately to file
    file.Write("vein_player_limits.json", util.TableToJSON(VEIN.Settings.PlayerDoorLimits, true))
    
    -- Notify the affected player if online
    local targetPly
    if string.StartWith(uniqueID, "BOT_") then
        -- For bots, find by name
        local botName = string.sub(uniqueID, 5) -- Remove "BOT_" prefix
        for _, p in ipairs(player.GetAll()) do
            if p:IsBot() and p:Nick() == botName then
                targetPly = p
                break
            end
        end
    else
        -- For players, find by SteamID
        targetPly = player.GetBySteamID(uniqueID)
    end
    
    if IsValid(targetPly) then
        VEIN.Chat(targetPly, "Your door limit has been set to " .. limit .. " by an administrator")
    end
end)

-- Handle resetting player limit to default
net.Receive("VEIN_ResetPlayerLimit", function(len, ply)
    if not ply:IsAdmin() then 
        return 
    end
    
    local uniqueID = net.ReadString()
    
    -- Ensure table exists
    VEIN.Settings = VEIN.Settings or {}
    VEIN.Settings.PlayerDoorLimits = VEIN.Settings.PlayerDoorLimits or {}
    
    -- Remove the custom limit from the CORRECT table
    VEIN.Settings.PlayerDoorLimits[uniqueID] = nil
    
    -- Save immediately to file
    file.Write("vein_player_limits.json", util.TableToJSON(VEIN.Settings.PlayerDoorLimits, true))
    
    -- Notify the affected player if online
    local targetPly
    if string.StartWith(uniqueID, "BOT_") then
        -- For bots, find by name
        local botName = string.sub(uniqueID, 5) -- Remove "BOT_" prefix
    for _, p in ipairs(player.GetAll()) do
            if p:IsBot() and p:Nick() == botName then
                targetPly = p
                break
            end
        end
    else
        -- For players, find by SteamID
        targetPly = player.GetBySteamID(uniqueID)
    end
    
    if IsValid(targetPly) then
        local defaultLimit = cvDefaultLimit:GetInt()
        VEIN.Chat(targetPly, "Your door limit has been reset to default (" .. defaultLimit .. ") by an administrator")
    end
end)

-- Load player limits on server start
hook.Add("Initialize", "VEIN_LoadNewSettings", function()
    -- Load from file if it exists
    local data = file.Read("vein_player_limits.json", "DATA")
    if data then
        local success, decoded = pcall(util.JSONToTable, data)
        if success and decoded then
            VEIN.NewSettings.PlayerLimits = decoded
        end
    end

    local adminData = file.Read("vein_door_admins.json", "DATA")
    if adminData then
        local success, decoded = pcall(util.JSONToTable, adminData)
        if success and decoded then
            VEIN.Settings.DoorAdmins = decoded
            NormalizeDoorAdminTable()
        end
    end
end)

-- Save player limits periodically
timer.Create("VEIN_SaveNewSettings", 300, 0, function()
    local data = util.TableToJSON(VEIN.NewSettings.PlayerLimits)
    file.Write("vein_player_limits.json", data)
    local adminData = util.TableToJSON(VEIN.Settings.DoorAdmins)
    file.Write("vein_door_admins.json", adminData)
end)

-- Save on server shutdown
hook.Add("ShutDown", "VEIN_SaveNewSettingsShutdown", function()
    local data = util.TableToJSON(VEIN.NewSettings.PlayerLimits)
    file.Write("vein_player_limits.json", data)
    local adminData = util.TableToJSON(VEIN.Settings.DoorAdmins)
    file.Write("vein_door_admins.json", adminData)
end)

-- Helper functions to integrate with the existing system
-- These ensure the new settings system works with the old VEIN.Settings calls
if not VEIN.Settings then
    VEIN.Settings = {}
end

-- Get door limit for a specific player (integrates new system with old calls)
function VEIN.Settings.GetPlayerDoorLimit(ply)
    if not IsValid(ply) then return 3 end
    
    -- Check if limits are enabled
    if not cvEnableLimits:GetBool() then
        return 999999 -- Unlimited
    end
    
    -- Ensure table exists
    VEIN.Settings = VEIN.Settings or {}
    VEIN.Settings.PlayerDoorLimits = VEIN.Settings.PlayerDoorLimits or {}
    
    -- Get unique ID (different for bots vs players)
    local uniqueID
    if ply:IsBot() then
        uniqueID = "BOT_" .. ply:Nick() -- Unique per bot name
    else
        uniqueID = ply:SteamID() -- Normal SteamID for players
    end
    
    local customLimit = VEIN.Settings.PlayerDoorLimits[uniqueID]
    
    if customLimit then
        return customLimit
    else
        return cvDefaultLimit:GetInt()
    end
end

-- Check if player can own more doors
function VEIN.Settings.CanPlayerOwnMoreDoors(ply)
    if not IsValid(ply) then return false end
    
    -- Count current doors
    local currentDoors = 0
    local playerName = ply:Nick()
    
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():match("door") then
            local doorOwner = door:GetNWString("VEIN_Owner", "")
            if doorOwner == playerName then
                currentDoors = currentDoors + 1
            end
        end
    end
    
    local maxDoors = VEIN.Settings.GetPlayerDoorLimit(ply)
    return currentDoors < maxDoors
end

-- Count how many doors a player owns
function VEIN.Settings.CountPlayerDoors(ply)
    if not IsValid(ply) then return 0 end
    
    local count = 0
    local playerName = ply:Nick()
    
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():match("door") then
            local doorOwner = door:GetNWString("VEIN_Owner", "")
            if doorOwner == playerName then
                count = count + 1
            end
        end
    end
    
    return count
end

--[[
================================================================================
Door Management Tab Handlers
================================================================================
]]--

-- Function to get door identifier
local function GetDoorIdentifier(door)
    local model = door:GetModel() or "unknown"
    local pos = door:GetPos()
    return string.format("%s_%.0f_%.0f_%.0f", model, pos.x, pos.y, pos.z)
end

-- Function to find door by identifier
local function FindDoorByIdentifier(identifier)
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():match("door") then
            local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
            -- Only check VEIN doors
            if isVEINDoor then
                if GetDoorIdentifier(door) == identifier then
                    return door
                end
            end
        end
    end
    return nil
end

-- Handle door list request
net.Receive("VEIN_RequestDoorList", function(len, ply)
    if not ply:IsAdmin() then 
        return 
    end
    
    local doorList = {}
    
    -- Gather all VEIN doors
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():match("door") then
            -- Use correct variable names: VEIN_DoorName, VEIN_DoorType
            local doorName = door:GetNWString("VEIN_DoorName", "")
            local doorType = door:GetNWString("VEIN_DoorType", "")
            local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
            
            -- Only include VEIN doors (check for VEIN_IsVEINDoor flag)
            if isVEINDoor or doorName ~= "" then
                local owner = door:GetNWString("VEIN_Owner", "")
                local ownerName = door:GetNWString("VEIN_OwnerName", "")
                local adminOnly = door:GetNWBool("VEIN_AdminOnly", false)
                local allowOwnership = door:GetNWBool("VEIN_AllowOwnership", true)
                local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
                
                -- Determine status
                local status = "Available"
                if owner ~= "" then
                    status = "Owned"
                elseif isJobControlled then
                    status = "Job Controlled"
                elseif adminOnly or not allowOwnership then
                    status = "Disabled"
                end
                
                -- Determine if disabled (admin-only static door, but NOT job-controlled)
                local isDisabled = (adminOnly or not allowOwnership) and not isJobControlled
                
                -- Display name
                local displayName = doorName ~= "" and doorName or "Unnamed Door"
                
                local identifier = GetDoorIdentifier(door)
                
                local ownerDisplay = ownerName ~= "" and ownerName or (owner ~= "" and owner or "None")
                table.insert(doorList, {
                    name = displayName,
                    type = doorType ~= "" and doorType or "Standard",
                    owner = ownerDisplay,
                    status = status,
                    disabled = isDisabled,
                    identifier = identifier
                })
            end
        end
    end
    
    -- Send door list to client
    net.Start("VEIN_DoorListData")
    Net.WriteDoorList(doorList)
    net.Send(ply)
end)

-- Handle teleport to door
net.Receive("VEIN_TeleportToDoor", function(len, ply)
    if not VEIN.Settings.HasDoorAdminPermission(ply, "adminTeleportDoor") then 
        return 
    end
    
    local identifier = net.ReadString()
    local door = FindDoorByIdentifier(identifier)
    
    if IsValid(door) then
        -- Teleport player just in front of the door (use door center + forward)
        local doorCenter = door:LocalToWorld(door:OBBCenter())
        local doorForward = door:GetForward()
        local targetPos = doorCenter + doorForward * 70
        
        -- Trace down to place the player on the floor (avoid ceiling/side placement)
        local mins = ply:OBBMins()
        local maxs = ply:OBBMaxs()
        local trace = util.TraceHull({
            start = targetPos + Vector(0, 0, 32),
            endpos = targetPos - Vector(0, 0, 128),
            mins = mins,
            maxs = maxs,
            filter = ply
        })
        
        local teleportPos = trace.HitPos + Vector(0, 0, 5)
        
        ply:SetPos(teleportPos)
        ply:SetEyeAngles((doorCenter - teleportPos):Angle())
        
        local doorName = door:GetNWString("VEIN_DoorName", "Unnamed Door")
        VEIN.Chat(ply, "Teleported to door: " .. doorName)
    else
        VEIN.Chat(ply, "Door not found!")
    end
end)

-- Handle disable door
net.Receive("VEIN_DisableDoor", function(len, ply)
    if not VEIN.Settings.HasDoorAdminPermission(ply, "adminDisableEnableDoor") then 
        return 
    end
    
    local identifier = net.ReadString()
    local lockState = net.ReadInt(8) -- 0 = default, 1 = locked, 2 = unlocked
    local door = FindDoorByIdentifier(identifier)
    
    if IsValid(door) then
        local doorName = door:GetNWString("VEIN_DoorName", "Unnamed Door")
        local owner = door:GetNWString("VEIN_Owner", "")
        local ownerName = door:GetNWString("VEIN_OwnerName", "")
        local ownerSteamID = door:GetNWString("VEIN_OwnerSteamID", "")
        local accessList = door:GetNWString("VEIN_AccessList", "")
        
        -- Store job-controlled settings before disabling
        local wasJobControlled = door:GetNWBool("VEIN_JobControlled", false)
        local controlJobs = door:GetNWString("VEIN_ControlJobs", "[]")
        local allowOwnership = door:GetNWBool("VEIN_AllowOwnership", true)
        local buyable = door:GetNWBool("VEIN_Buyable", true)
        
        -- Store ALL settings so they can be restored when enabled again
        door:SetNWBool("VEIN_WasJobControlled", wasJobControlled)
        door:SetNWString("VEIN_StoredControlJobs", controlJobs)
        door:SetNWBool("VEIN_StoredAllowOwnership", allowOwnership)
        door:SetNWBool("VEIN_StoredBuyable", buyable)
        door:SetNWString("VEIN_StoredOwner", owner)
        door:SetNWString("VEIN_StoredOwnerName", ownerName)
        door:SetNWString("VEIN_StoredOwnerSteamID", ownerSteamID)
        door:SetNWString("VEIN_StoredAccessList", accessList)
        
        -- Refund owner if door is owned
        if owner ~= "" then
            local price = door:GetNWInt("VEIN_Price", 0)
            local refundPercent = cvRefundPercent:GetInt() / 100
            local refund = math.floor(price * refundPercent)
            
            -- Find owner player and refund them
            for _, p in ipairs(player.GetAll()) do
                if p:Nick() == ownerName then
                    if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.AddPlayerMoney then
                        VEIN.DoorSystem.AddPlayerMoney(p, refund)
                        VEIN.Chat(p, "Your door '" .. doorName .. "' was disabled by an admin. Refund: $" .. refund)
                    elseif p.addMoney then
                        p:addMoney(refund)
                        VEIN.Chat(p, "Your door '" .. doorName .. "' was disabled by an admin. Refund: $" .. refund)
                    end
                    break
                end
            end
        end
        
        -- Disable the door (make it admin-only and static, clear job control)
        door:SetNWBool("VEIN_AdminOnly", true)
        door:SetNWBool("VEIN_AllowOwnership", false)
        door:SetNWBool("VEIN_JobControlled", false)
        door:SetNWBool("VEIN_Buyable", false)
        
        -- Set lock state based on selection
        local lockStateText = "default state"
        if lockState == 0 then
            -- Default state - don't change the door's current lock state
            lockStateText = "default state"
        elseif lockState == 1 then
            -- Keep locked
            door:Fire("Lock")
            lockStateText = "locked"
        elseif lockState == 2 then
            -- Keep unlocked
            door:Fire("Unlock")
            lockStateText = "unlocked"
        end
        
        -- Clear ownership
        local previousOwner = door:GetNWString("VEIN_OwnerName", "")
        local previousOwnerSteamID = door:GetNWString("VEIN_Owner", "")
        local doorPrice = door:GetNWInt("VEIN_Price", 0)
        
        door:SetNWString("VEIN_Owner", "")
        door:SetNWString("VEIN_OwnerName", "")
        door:SetNWString("VEIN_OwnerSteamID", "")
        door:SetNWString("VEIN_AccessList", "")
        
        -- Notify previous owner if they had the door
        if previousOwner ~= "" then
            for _, targetPly in ipairs(player.GetAll()) do
                if targetPly:Nick() == previousOwner then
                    -- Give 100% refund
                    local refund = math.floor(doorPrice)
                    if refund > 0 then
                        if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.AddPlayerMoney then
                            VEIN.DoorSystem.AddPlayerMoney(targetPly, refund)
                        elseif targetPly.addMoney then
                            targetPly:addMoney(refund)
                        else
                            local currentMoney = targetPly:GetNWInt("VEIN_Money", 0)
                            targetPly:SetNWInt("VEIN_Money", currentMoney + refund)
                        end
                    end
                    
                    if VEIN and VEIN.AccessLevels and VEIN.AccessLevels.SendNotification then
                        VEIN.AccessLevels.SendNotification(targetPly, "Door Force Sold", "Admin disabled your door '" .. doorName .. "'. Refund: $" .. refund, "warning", 7)
                    end
                    break
                end
            end
        end
        
        VEIN.Chat(ply, "Disabled door '" .. doorName .. "' and set to " .. lockStateText)
        
        -- Save doors
        if VEIN.SaveAllDoors then
            VEIN.SaveAllDoors()
        end
    else
        VEIN.Chat(ply, "Door not found!")
    end
end)

-- Handle enable door
net.Receive("VEIN_EnableDoor", function(len, ply)
    if not VEIN.Settings.HasDoorAdminPermission(ply, "adminDisableEnableDoor") then 
        return 
    end
    
    local identifier = net.ReadString()
    local door = FindDoorByIdentifier(identifier)
    
    if IsValid(door) then
        -- Restore stored settings
        local wasJobControlled = door:GetNWBool("VEIN_WasJobControlled", false)
        local storedControlJobs = door:GetNWString("VEIN_StoredControlJobs", "[]")
        local storedOwner = door:GetNWString("VEIN_StoredOwner", "")
        local storedOwnerName = door:GetNWString("VEIN_StoredOwnerName", "")
        local storedOwnerSteamID = door:GetNWString("VEIN_StoredOwnerSteamID", "")
        local storedAccessList = door:GetNWString("VEIN_StoredAccessList", "")
        local storedAllowOwnership = door:GetNWBool("VEIN_StoredAllowOwnership", true)
        local storedBuyable = door:GetNWBool("VEIN_StoredBuyable", true)
        
        -- Enable the door (mark as VEIN door)
        door:SetNWBool("VEIN_IsVEINDoor", true)
        door:SetNWBool("VEIN_IsSetup", true)
        door:SetNWBool("VEIN_AdminOnly", false)
        
        if wasJobControlled then
            -- Restore as job-controlled door
            door:SetNWBool("VEIN_JobControlled", true)
            door:SetNWString("VEIN_ControlJobs", storedControlJobs)
            door:SetNWBool("VEIN_AllowOwnership", false)
            door:SetNWBool("VEIN_Buyable", false)
            door:Fire("Lock")
        else
            -- Restore original settings
            door:SetNWBool("VEIN_JobControlled", false)
            door:SetNWBool("VEIN_AllowOwnership", storedAllowOwnership)
            door:SetNWBool("VEIN_Buyable", storedBuyable)
        end
        
        -- Restore ownership if there was an owner
        if storedOwner ~= "" then
            door:SetNWString("VEIN_Owner", storedOwner)
            door:SetNWString("VEIN_OwnerName", storedOwnerName)
            door:SetNWString("VEIN_OwnerSteamID", storedOwnerSteamID)
            door:SetNWString("VEIN_AccessList", storedAccessList)
        else
            -- Clear ownership (was for sale)
            door:SetNWString("VEIN_Owner", "")
            door:SetNWString("VEIN_OwnerName", "")
            door:SetNWString("VEIN_OwnerSteamID", "")
            door:SetNWString("VEIN_AccessList", "")
        end
        
        -- Clear stored settings
        door:SetNWBool("VEIN_WasJobControlled", false)
        door:SetNWString("VEIN_StoredControlJobs", "[]")
        door:SetNWString("VEIN_StoredOwner", "")
        door:SetNWString("VEIN_StoredOwnerName", "")
        door:SetNWString("VEIN_StoredOwnerSteamID", "")
        door:SetNWString("VEIN_StoredAccessList", "")
        door:SetNWBool("VEIN_StoredAllowOwnership", true)
        door:SetNWBool("VEIN_StoredBuyable", true)
        
        local doorName = door:GetNWString("VEIN_DoorName", "Unnamed Door")
        local statusText = wasJobControlled and "job-controlled" or (storedOwner ~= "" and "owned by " .. storedOwnerName or "for sale")
        VEIN.Chat(ply, "Enabled door '" .. doorName .. "' - now " .. statusText)
        
        -- Save doors
        if VEIN.SaveAllDoors then
            VEIN.SaveAllDoors()
        end
    else
        VEIN.Chat(ply, "Door not found!")
    end
end)

-- Handle delete door
net.Receive("VEIN_DeleteDoor", function(len, ply)
    if not VEIN.Settings.HasDoorAdminPermission(ply, "adminDeleteDoor") then 
        return 
    end
    
    local identifier = net.ReadString()
    local door = FindDoorByIdentifier(identifier)
    
    if IsValid(door) then
        local doorName = door:GetNWString("VEIN_DoorName", "Unnamed Door")
        local previousOwner = door:GetNWString("VEIN_OwnerName", "")
        local previousOwnerSteamID = door:GetNWString("VEIN_Owner", "")
        local doorPrice = door:GetNWInt("VEIN_Price", 0)
        
        -- Notify previous owner if they had the door
        if previousOwner ~= "" then
            for _, targetPly in ipairs(player.GetAll()) do
                if targetPly:Nick() == previousOwner then
                    -- Give 50% refund
                    local refund = math.floor(doorPrice * 0.5)
                    if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.AddPlayerMoney then
                        VEIN.DoorSystem.AddPlayerMoney(targetPly, refund)
                    elseif targetPly.addMoney then
                        targetPly:addMoney(refund)
                    else
                        local currentMoney = targetPly:GetNWInt("VEIN_Money", 0)
                        targetPly:SetNWInt("VEIN_Money", currentMoney + refund)
                    end
                    
                    if VEIN and VEIN.AccessLevels and VEIN.AccessLevels.SendNotification then
                        VEIN.AccessLevels.SendNotification(targetPly, "Door Removed", "Admin deleted your door '" .. doorName .. "'. Refund: $" .. refund, "error", 7)
                    end
                    break
                end
            end
        end
        
        -- Clear all VEIN data (use correct variable names)
        door:SetNWBool("VEIN_IsVEINDoor", false)
        door:SetNWBool("VEIN_IsSetup", false)
        door:SetNWString("VEIN_DoorName", "")
        door:SetNWString("VEIN_DoorType", "")
        door:SetNWString("VEIN_DoorMaterial", "")
        door:SetNWString("VEIN_Owner", "")
        door:SetNWString("VEIN_OwnerName", "")
        door:SetNWString("VEIN_OwnerSteamID", "")
        door:SetNWString("VEIN_AccessList", "")
        door:SetNWBool("VEIN_AdminOnly", false)
        door:SetNWBool("VEIN_AllowOwnership", false)
        door:SetNWInt("VEIN_Price", 0)
        door:SetNWInt("VEIN_KickTime", 0)
        door:SetNWInt("VEIN_LockTime", 0)
        door:SetNWInt("VEIN_LockPitch", 100)
        door:SetNWInt("VEIN_UnlockPitch", 100)
        door:SetNWString("VEIN_LockSound", "")
        door:SetNWString("VEIN_UnlockSound", "")
        door:SetNWString("VEIN_KickSound", "")
        door:SetNWString("VEIN_BreakSound", "")
        door:SetNWBool("VEIN_AutoLockOnClose", false)
        -- Unlink from any linked groups before clearing link fields
        if VEIN.DoorSystem and VEIN.DoorSystem.UnlinkDoor then
            VEIN.DoorSystem.UnlinkDoor(door)
        end
        if VEIN.DoorSystem and VEIN.DoorSystem.ClearPropertyGroup then
            VEIN.DoorSystem.ClearPropertyGroup(door)
        end

        door:SetNWString("VEIN_DoorGroup", "")
        door:SetNWString("VEIN_AllowedJobs", "[]")
        door:SetNWBool("VEIN_JobControlled", false)
        door:SetNWString("VEIN_ControlJobs", "[]")
        door:SetNWInt("VEIN_LinkGroup", 0)
        door:SetNWInt("VEIN_LinkCount", 1)
        door:SetNWInt("VEIN_LinkTotalPrice", 0)
        door:SetNWInt("VEIN_PropertyGroup", 0)
        door:SetNWString("VEIN_PropertyGroupName", "")
        door:SetNWInt("VEIN_PropertyCustomPrice", 0)
        door:SetNWInt("VEIN_PropertyCount", 1)
        door:SetNWInt("VEIN_PropertyTotalPrice", 0)
        
        -- Unlock the door
        door:Fire("Unlock")

        
        VEIN.Chat(ply, "Deleted door '" .. doorName .. "'")
        
        -- Save doors
        if VEIN.SaveAllDoors then
            VEIN.SaveAllDoors()
        end
    else
        VEIN.Chat(ply, "Door not found!")
    end
end)

-- ============================================================================
-- Server Startup Complete
-- ============================================================================
timer.Simple(1, function()
    local version = "1.5.1"
    local hostname = GetHostName()
    local map = game.GetMap()
    local timestamp = os.date("%d/%m/%Y, %H:%M:%S")
    
    print("\n" .. string.rep("=", 60))
    print("Server Initialization Complete")
    print("Version: " .. version)
    print("Hostname: " .. hostname)
    print("Map: " .. map)
    print("IP: (hidden)")
    print("Timestamp: " .. timestamp)
    print(string.rep("=", 60))
    print("\nAll systems online. Door system successfully loaded!")
    print(string.rep("=", 60) .. "\n")
    
    -- Broadcast hook for tracking (does nothing without listener)
    hook.Run("VEIN_DoorSystem_Loaded", {
        version = version,
        hostname = hostname,
        map = map,
        timestamp = os.time()
    })
end)


