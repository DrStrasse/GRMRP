--[[
================================================================================
VEIN Keys - DarkRP Compatibility Layer
Makes VEIN keys work seamlessly with DarkRP
================================================================================
]]--

-- Register VEIN keys as the "keys" weapon for DarkRP
if SERVER then
    -- Add weapon alias so DarkRP recognizes vein_keys as keys
    hook.Add("Initialize", "VEIN_KeysAlias", function()
        -- Make sure weapon is registered
        weapons.Register({
            Base = "vein_keys",
            ClassName = "keys",
            PrintName = "Keys (VEIN)",
            Category = "DarkRP"
        }, "keys")
    end)
end

-- Make VEIN keys fully compatible with any DarkRP systems
if SERVER then
    local PLAYER = FindMetaTable("Player")
    
    -- Override DarkRP's keys functions if they exist
    if PLAYER.getDoorKeys then
        PLAYER.VEIN_OriginalGetDoorKeys = PLAYER.VEIN_OriginalGetDoorKeys or PLAYER.getDoorKeys
        
        function PLAYER:getDoorKeys()
            -- Return VEIN keys weapon instead
            local keysWeapon = self:GetWeapon("vein_keys")
            if IsValid(keysWeapon) then
                return keysWeapon
            end
            
            -- Fallback to original
            return self:VEIN_OriginalGetDoorKeys()
        end
    end
end
