--[[
================================================================================
VEIN Door System - Property Groups
Allows grouping doors into properties that can be purchased together.
================================================================================
]]--

if CLIENT then return end

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.DoorSystem = VEIN.DoorSystem or {}

VEIN.DoorSystem.PropertyGroups = VEIN.DoorSystem.PropertyGroups or {}
VEIN.DoorSystem.PropertyGroupNameToId = VEIN.DoorSystem.PropertyGroupNameToId or {}
VEIN.DoorSystem.NextPropertyGroupId = VEIN.DoorSystem.NextPropertyGroupId or 1

local function setDoorPropertyStats(door, count, totalPrice, groupName, customPrice, groupId)
    if not IsValid(door) then return end
    door:SetNWInt("VEIN_PropertyGroup", groupId or 0)
    door:SetNWString("VEIN_PropertyGroupName", groupName or "")
    door:SetNWInt("VEIN_PropertyCustomPrice", customPrice or 0)
    door:SetNWInt("VEIN_PropertyCount", count or 1)
    door:SetNWInt("VEIN_PropertyTotalPrice", totalPrice or door:GetNWInt("VEIN_Price", 0))
end

local function normalizeGroup(groupId)
    local group = VEIN.DoorSystem.PropertyGroups[groupId]
    if not group then return end

    local valid = {}
    local sum = 0
    for _, ent in ipairs(group.doors or {}) do
        if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) then
            table.insert(valid, ent)
            sum = sum + ent:GetNWInt("VEIN_Price", 0)
        end
    end

    if #valid == 0 then
        if group.name and group.name ~= "" then
            VEIN.DoorSystem.PropertyGroupNameToId[group.name] = nil
        end
        VEIN.DoorSystem.PropertyGroups[groupId] = nil
        return
    end

    group.doors = valid
    local customPrice = tonumber(group.customPrice) or 0
    if customPrice < 0 then customPrice = 0 end
    local total = customPrice > 0 and customPrice or sum

    for _, ent in ipairs(valid) do
        setDoorPropertyStats(ent, #valid, total, group.name or "", customPrice, groupId)
    end
end

local function removeDoorFromGroup(groupId, door)
    local group = VEIN.DoorSystem.PropertyGroups[groupId]
    if not group then return end

    local remaining = {}
    for _, ent in ipairs(group.doors or {}) do
        if IsValid(ent) and ent ~= door then
            table.insert(remaining, ent)
        end
    end
    group.doors = remaining

    if #remaining == 0 then
        if group.name and group.name ~= "" then
            VEIN.DoorSystem.PropertyGroupNameToId[group.name] = nil
        end
        VEIN.DoorSystem.PropertyGroups[groupId] = nil
    else
        normalizeGroup(groupId)
    end

    setDoorPropertyStats(door, 1, door:GetNWInt("VEIN_Price", 0), "", 0, 0)
end

local function GetOwnedGroupInfo(group, excludeDoor)
    if not group or not group.doors then return nil end
    for _, ent in ipairs(group.doors) do
        if IsValid(ent) and ent ~= excludeDoor then
            local owner = ent:GetNWString("VEIN_Owner", "")
            if owner ~= "" then
                return {
                    owner = owner,
                    ownerName = ent:GetNWString("VEIN_OwnerName", ""),
                    ownerSteamID = ent:GetNWString("VEIN_OwnerSteamID", owner),
                }
            end
        end
    end
    return nil
end

local function ApplyGroupOwner(door, ownerInfo)
    if not IsValid(door) or not ownerInfo then return end
    if door:GetNWString("VEIN_Owner", "") ~= "" then return end

    door:SetNWString("VEIN_Owner", ownerInfo.owner or "")
    door:SetNWString("VEIN_OwnerName", ownerInfo.ownerName or "")
    door:SetNWString("VEIN_OwnerSteamID", ownerInfo.ownerSteamID or ownerInfo.owner or "")
    door:SetNWBool("VEIN_Buyable", false)
    door:SetNWBool("VEIN_Locked", door:GetNWBool("VEIN_DefaultLocked", false))

    if VEIN.DoorSystem and VEIN.DoorSystem.OwnedDoors then
        VEIN.DoorSystem.OwnedDoors[door:EntIndex()] = ownerInfo.owner
    end

    if door:GetNWString("VEIN_AccessData", "") == "" then
        door:SetNWString("VEIN_AccessData", "{}")
    end

    hook.Run("VEIN_DoorModified", door)
end

function VEIN.DoorSystem.GetPropertyGroupId(door)
    if not IsValid(door) then return 0 end
    return door:GetNWInt("VEIN_PropertyGroup", 0)
end

function VEIN.DoorSystem.GetPropertyGroupDoors(door)
    if not IsValid(door) then return {} end
    local groupId = VEIN.DoorSystem.GetPropertyGroupId(door)
    if groupId <= 0 then return {door} end
    local group = VEIN.DoorSystem.PropertyGroups[groupId]
    return group and group.doors or {door}
end

function VEIN.DoorSystem.GetPropertyGroupTotalPrice(door)
    if not IsValid(door) then return 0 end
    local groupId = VEIN.DoorSystem.GetPropertyGroupId(door)
    if groupId <= 0 then return door:GetNWInt("VEIN_Price", 0) end
    local group = VEIN.DoorSystem.PropertyGroups[groupId]
    if not group then return door:GetNWInt("VEIN_Price", 0) end

    local customPrice = tonumber(group.customPrice) or 0
    if customPrice > 0 then return customPrice end

    local sum = 0
    for _, ent in ipairs(group.doors or {}) do
        if IsValid(ent) then
            sum = sum + ent:GetNWInt("VEIN_Price", 0)
        end
    end
    return sum
end

function VEIN.DoorSystem.ClearPropertyGroup(door)
    if not IsValid(door) then return end
    local groupId = VEIN.DoorSystem.GetPropertyGroupId(door)
    if groupId <= 0 then
        setDoorPropertyStats(door, 1, door:GetNWInt("VEIN_Price", 0), "", 0, 0)
        return
    end
    removeDoorFromGroup(groupId, door)
end

function VEIN.DoorSystem.SetPropertyGroup(door, name, customPrice)
    if not IsValid(door) then return end

    name = isstring(name) and string.Trim(name) or ""
    if name == "" then
        VEIN.DoorSystem.ClearPropertyGroup(door)
        return
    end

    local groupId = VEIN.DoorSystem.PropertyGroupNameToId[name]
    if not groupId then
        groupId = VEIN.DoorSystem.NextPropertyGroupId
        VEIN.DoorSystem.NextPropertyGroupId = VEIN.DoorSystem.NextPropertyGroupId + 1
        VEIN.DoorSystem.PropertyGroups[groupId] = {name = name, doors = {}, customPrice = 0}
        VEIN.DoorSystem.PropertyGroupNameToId[name] = groupId
    end

    local oldGroupId = VEIN.DoorSystem.GetPropertyGroupId(door)
    if oldGroupId > 0 and oldGroupId ~= groupId then
        removeDoorFromGroup(oldGroupId, door)
    end

    local group = VEIN.DoorSystem.PropertyGroups[groupId]
    group.name = name
    group.doors = group.doors or {}

    local exists = false
    for _, ent in ipairs(group.doors) do
        if ent == door then
            exists = true
            break
        end
    end
    if not exists then
        table.insert(group.doors, door)
    end

    if customPrice ~= nil then
        local value = tonumber(customPrice) or 0
        if value < 0 then value = 0 end
        group.customPrice = math.floor(value)
    end

    normalizeGroup(groupId)

    local ownerInfo = GetOwnedGroupInfo(group, door)
    if ownerInfo then
        ApplyGroupOwner(door, ownerInfo)
    end
end

function VEIN.DoorSystem.UpdatePropertyGroupStats(groupId)
    if not groupId or groupId <= 0 then return end
    normalizeGroup(groupId)
end

function VEIN.DoorSystem.UpdateDoorPropertyStats(door)
    if not IsValid(door) then return end
    local groupId = VEIN.DoorSystem.GetPropertyGroupId(door)
    if groupId > 0 then
        normalizeGroup(groupId)
    else
        setDoorPropertyStats(door, 1, door:GetNWInt("VEIN_Price", 0), "", 0, 0)
    end
end

function VEIN.DoorSystem.RebuildPropertyGroupsFromDoors()
    VEIN.DoorSystem.PropertyGroups = {}
    VEIN.DoorSystem.PropertyGroupNameToId = {}

    local maxId = 0
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
            local groupId = door:GetNWInt("VEIN_PropertyGroup", 0)
            local groupName = door:GetNWString("VEIN_PropertyGroupName", "")
            if groupId > 0 and groupName ~= "" then
                local group = VEIN.DoorSystem.PropertyGroups[groupId]
                if not group then
                    group = {name = groupName, doors = {}, customPrice = 0}
                    VEIN.DoorSystem.PropertyGroups[groupId] = group
                end
                if group.name == "" and groupName ~= "" then
                    group.name = groupName
                end
                local cp = door:GetNWInt("VEIN_PropertyCustomPrice", 0)
                if cp > 0 then
                    group.customPrice = cp
                end
                table.insert(group.doors, door)
                VEIN.DoorSystem.PropertyGroupNameToId[group.name] = groupId
                if groupId > maxId then
                    maxId = groupId
                end
            end
        end
    end

    VEIN.DoorSystem.NextPropertyGroupId = maxId + 1

    for groupId, _ in pairs(VEIN.DoorSystem.PropertyGroups) do
        normalizeGroup(groupId)
    end

    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetNWBool("VEIN_IsVEINDoor", false) then
            VEIN.DoorSystem.UpdateDoorPropertyStats(door)
        end
    end
end

hook.Add("VEIN_DoorCreated", "VEIN_UpdatePropertyStatsOnCreate", function(door)
    if IsValid(door) then
        VEIN.DoorSystem.UpdateDoorPropertyStats(door)
    end
end)

hook.Add("VEIN_DoorModified", "VEIN_UpdatePropertyStatsOnModify", function(door)
    if IsValid(door) then
        VEIN.DoorSystem.UpdateDoorPropertyStats(door)
    end
end)

hook.Add("VEIN_OnDoorModified", "VEIN_UpdatePropertyStatsOnModify2", function(door)
    if IsValid(door) then
        VEIN.DoorSystem.UpdateDoorPropertyStats(door)
    end
end)


