--[[
================================================================================
VEIN Access Levels - Server Management
================================================================================
Server-side access level management and notification system
]]--

if not SERVER then return end

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.AccessLevels = VEIN.AccessLevels or {}

-- Network strings
util.AddNetworkString("VEIN_Notification")
util.AddNetworkString("VEIN_AL_SetAccessLevel")
util.AddNetworkString("VEIN_AL_RemoveAccess")
util.AddNetworkString("VEIN_AL_RequestAccessList")
util.AddNetworkString("VEIN_AL_SendAccessList")

-- Send notification to player(s)
function VEIN.AccessLevels.SendNotification(ply, title, message, notifType, duration)
    notifType = notifType or "info"
    duration = duration or 5
    
    net.Start("VEIN_Notification")
    net.WriteString(title)
    net.WriteString(message)
    net.WriteString(notifType)
    net.WriteFloat(duration)
    
    if ply then
        net.Send(ply)
    else
        net.Broadcast()
    end
end

-- Grant or change access level for a player on a door
local function FindOnlinePlayer(identifier, fallbackName, steamID, steamID64)
    identifier = isstring(identifier) and string.Trim(identifier) or ""
    fallbackName = isstring(fallbackName) and string.Trim(fallbackName) or ""
    steamID = isstring(steamID) and string.Trim(steamID) or ""
    steamID64 = isstring(steamID64) and string.Trim(steamID64) or ""

    for _, targetPly in ipairs(player.GetAll()) do
        if IsValid(targetPly) then
            if string.StartWith(steamID, "BOT_") then
                local botName = string.sub(steamID, 5)
                if targetPly:IsBot() and targetPly:Nick() == botName then
                    return targetPly
                end
            end
            if string.StartWith(identifier, "BOT_") then
                local botName = string.sub(identifier, 5)
                if targetPly:IsBot() and targetPly:Nick() == botName then
                    return targetPly
                end
            end
            if steamID64 ~= "" and targetPly:SteamID64() == steamID64 then
                return targetPly
            end
            if steamID ~= "" and steamID ~= "BOT" and targetPly:SteamID() == steamID then
                return targetPly
            end
            if identifier ~= "" and (targetPly:Nick() == identifier or targetPly:SteamID() == identifier or targetPly:SteamID64() == identifier) then
                return targetPly
            end
            if fallbackName ~= "" and targetPly:Nick() == fallbackName then
                return targetPly
            end
        end
    end

    return nil
end

local function NormalizeBotAccessIdentifier(identifier, name, steamID, steamID64)
    local id = isstring(identifier) and string.Trim(identifier) or ""
    local nm = isstring(name) and string.Trim(name) or ""
    local sid = isstring(steamID) and string.Trim(steamID) or ""
    local sid64 = isstring(steamID64) and string.Trim(steamID64) or ""

    local isBot = (sid == "BOT" or sid64 == "0" or string.StartWith(id, "BOT_"))
    if not isBot then
        return nil, nil
    end

    local botName = ""
    if string.StartWith(id, "BOT_") then
        botName = string.sub(id, 5)
    elseif string.StartWith(nm, "BOT_") then
        botName = string.sub(nm, 5)
    elseif nm ~= "" then
        botName = nm
    elseif id ~= "" and id ~= "BOT" then
        botName = id
    end

    if botName == "" then return nil, nil end

    return "BOT_" .. botName, botName
end

local function GetConnectedDoorsForAccessSync(door)
    local doors = {}
    local seen = {}

    local function addDoor(ent)
        if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) and not seen[ent] then
            seen[ent] = true
            table.insert(doors, ent)
        end
    end

    addDoor(door)

    local hasPropertyGroup = false
    if VEIN.DoorSystem and VEIN.DoorSystem.GetPropertyGroupId and VEIN.DoorSystem.GetPropertyGroupDoors then
        local propertyGroupId = VEIN.DoorSystem.GetPropertyGroupId(door)
        local propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", "")
        if propertyGroupId > 0 and propertyGroupName ~= "" then
            for _, groupDoor in ipairs(VEIN.DoorSystem.GetPropertyGroupDoors(door) or {}) do
                addDoor(groupDoor)
            end
            hasPropertyGroup = #doors > 1
        end
    end

    if not hasPropertyGroup then
        if VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedGroup then
            for _, linkedDoor in ipairs(VEIN.DoorSystem.GetLinkedGroup(door) or {}) do
                addDoor(linkedDoor)
            end
        elseif VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedDoors then
            for _, linkedDoor in ipairs(VEIN.DoorSystem.GetLinkedDoors(door) or {}) do
                addDoor(linkedDoor)
            end
        else
            local linkedDoor = door:GetNWEntity("VEIN_LinkedDoor", NULL)
            if IsValid(linkedDoor) then
                addDoor(linkedDoor)
            end
        end
    end

    return doors
end

local function ResolveAccessKeyForSet(door, targetIdentifier, targetName, targetSteamID, targetSteamID64)
    local botKey, botName = NormalizeBotAccessIdentifier(targetIdentifier, targetName, targetSteamID, targetSteamID64)
    if botKey then
        targetIdentifier = botKey
        targetName = botName
        targetSteamID = botKey
        targetSteamID64 = ""
    end

    local resolvedKey = VEIN.AccessLevels.ResolveAccessEntry and select(1, VEIN.AccessLevels.ResolveAccessEntry(door, targetIdentifier, targetName)) or nil
    if isstring(resolvedKey) and resolvedKey ~= "" then
        return resolvedKey
    end

    targetSteamID64 = isstring(targetSteamID64) and string.Trim(targetSteamID64) or ""
    if targetSteamID64 ~= "" and targetSteamID64 ~= "BOT" and targetSteamID64 ~= "0" then
        return targetSteamID64
    end

    targetSteamID = isstring(targetSteamID) and string.Trim(targetSteamID) or ""
    if targetSteamID ~= "" and targetSteamID ~= "BOT" then
        return targetSteamID
    end

    targetIdentifier = isstring(targetIdentifier) and string.Trim(targetIdentifier) or ""
    if targetIdentifier ~= "" then
        return targetIdentifier
    end

    targetName = isstring(targetName) and string.Trim(targetName) or ""
    if targetName ~= "" then
        return targetName
    end

    return nil
end

local function ResolveExistingAccessKey(door, targetIdentifier, targetName)
    local resolvedKey = VEIN.AccessLevels.ResolveAccessEntry and select(1, VEIN.AccessLevels.ResolveAccessEntry(door, targetIdentifier, targetName)) or nil
    if isstring(resolvedKey) and resolvedKey ~= "" then
        return resolvedKey
    end
    return nil
end

local function SaveDoorAccess(door, access)
    door:SetNWString("VEIN_AccessData", util.TableToJSON(access))
    VEIN.AccessLevels.UpdateAccessList(door)
    if VEIN.DoorSystem and VEIN.DoorSystem.SaveDoorData then
        VEIN.DoorSystem.SaveDoorData(door)
    end
end

local function NormalizeBotAccessData(access)
    if not istable(access) then return false end
    local moved = {}
    local changed = false

    for accessKey, data in pairs(access) do
        if isstring(accessKey) then
            if string.StartWith(accessKey, "BOT_") then
                if istable(data) then
                    if not isstring(data.name) or data.name == "" then
                        data.name = string.sub(accessKey, 5)
                        changed = true
                    end
                    if not isstring(data.steamid) or data.steamid == "" or data.steamid == "BOT" then
                        data.steamid = accessKey
                        changed = true
                    end
                end
            elseif accessKey == "BOT" then
                local botKey = ""
                if istable(data) then
                    local name = isstring(data.name) and string.Trim(data.name) or ""
                    local sid = isstring(data.steamid) and string.Trim(data.steamid) or ""
                    if string.StartWith(sid, "BOT_") then
                        botKey = sid
                    elseif name ~= "" then
                        botKey = "BOT_" .. name
                    end
                    if botKey ~= "" then
                        if not isstring(data.name) or data.name == "" then
                            data.name = string.sub(botKey, 5)
                        end
                        data.steamid = botKey
                    end
                end
                if botKey ~= "" then
                    moved[botKey] = data
                    access[accessKey] = nil
                    changed = true
                end
            end
        end
    end

    for key, data in pairs(moved) do
        access[key] = data
    end

    return changed
end

local function SetLevelSingleDoor(door, targetIdentifier, level, grantedByNick, expirationMinutes, targetName, targetSteamID, targetSteamID64)
    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    local access = util.JSONToTable(accessData) or {}
    if NormalizeBotAccessData(access) then
        door:SetNWString("VEIN_AccessData", util.TableToJSON(access))
    end
    if NormalizeBotAccessData(access) then
        door:SetNWString("VEIN_AccessData", util.TableToJSON(access))
    end
    local accessKey = ResolveAccessKeyForSet(door, targetIdentifier, targetName, targetSteamID, targetSteamID64)
    if not accessKey then return false end

    local entry = istable(access[accessKey]) and access[accessKey] or {}
    entry.level = level
    entry.grantedBy = grantedByNick
    entry.grantedAt = os.time()
    entry.expiresAt = nil

    local displayName = isstring(targetName) and string.Trim(targetName) or ""
    if displayName ~= "" then
        entry.name = displayName
    elseif not isstring(entry.name) or entry.name == "" then
        if isstring(accessKey) and string.StartWith(accessKey, "BOT_") then
            entry.name = string.sub(accessKey, 5)
        else
            entry.name = accessKey
        end
    end

    targetSteamID = isstring(targetSteamID) and string.Trim(targetSteamID) or ""
    targetSteamID64 = isstring(targetSteamID64) and string.Trim(targetSteamID64) or ""
    if targetSteamID ~= "" and targetSteamID ~= "BOT" then
        entry.steamid = targetSteamID
    end
    if targetSteamID64 ~= "" and targetSteamID64 ~= "BOT" and targetSteamID64 ~= "0" then
        entry.steamid64 = targetSteamID64
    end

    if level == VEIN.AccessLevels.GUEST and expirationMinutes and expirationMinutes > 0 then
        entry.expiresAt = os.time() + (expirationMinutes * 60)
    end

    access[accessKey] = entry
    SaveDoorAccess(door, access)
    return true
end

local function RemoveAccessSingleDoor(door, targetIdentifier, targetName)
    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    local access = util.JSONToTable(accessData) or {}
    local accessKey = ResolveExistingAccessKey(door, targetIdentifier, targetName)
    if not accessKey or access[accessKey] == nil then
        return false
    end

    access[accessKey] = nil
    SaveDoorAccess(door, access)
    return true
end

-- Grant or change access level for a player on a door
function VEIN.AccessLevels.SetLevel(door, targetIdentifier, level, grantedByNick, expirationMinutes, syncConnected, targetName, targetSteamID, targetSteamID64, unsyncConnected)
    if not IsValid(door) then return false, "Invalid door" end

    if syncConnected then
        unsyncConnected = false
    end

    local targetDoors = {door}
    if syncConnected then
        targetDoors = GetConnectedDoorsForAccessSync(door)
    end

    local updatedAny = false
    for _, targetDoor in ipairs(targetDoors) do
        if SetLevelSingleDoor(targetDoor, targetIdentifier, level, grantedByNick, expirationMinutes, targetName, targetSteamID, targetSteamID64) then
            updatedAny = true
        end
    end

    if not updatedAny then
        return false, "Unable to resolve access target"
    end

    local unsyncedCount = 0
    if unsyncConnected then
        for _, connectedDoor in ipairs(GetConnectedDoorsForAccessSync(door)) do
            if connectedDoor ~= door and RemoveAccessSingleDoor(connectedDoor, targetIdentifier, targetName) then
                unsyncedCount = unsyncedCount + 1
            end
        end
    end

    return true, nil, #targetDoors, unsyncedCount
end

-- Remove access for a player
function VEIN.AccessLevels.RemoveAccess(door, targetIdentifier, syncConnected, targetName)
    if not IsValid(door) then return false, 0 end

    local targetDoors = {door}
    if syncConnected then
        targetDoors = GetConnectedDoorsForAccessSync(door)
    end

    local removedCount = 0
    for _, targetDoor in ipairs(targetDoors) do
        if RemoveAccessSingleDoor(targetDoor, targetIdentifier, targetName) then
            removedCount = removedCount + 1
        end
    end

    return removedCount > 0, removedCount
end

-- Update the quick access list (comma-separated string for backward compatibility)
function VEIN.AccessLevels.UpdateAccessList(door)
    if not IsValid(door) then return end
    
    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    local access = util.JSONToTable(accessData) or {}
    
    local names = {}
    local accessSet = {}
    local seen = {}
    for accessKey, data in pairs(access) do
        local displayName = VEIN.AccessLevels.GetAccessDisplayName and VEIN.AccessLevels.GetAccessDisplayName(accessKey, data) or accessKey
        displayName = isstring(displayName) and string.Trim(displayName) or ""
        if displayName ~= "" and not seen[displayName] then
            seen[displayName] = true
            table.insert(names, displayName)
            table.insert(accessSet, displayName)
            accessSet[displayName] = true
        end

        if isstring(accessKey) and accessKey ~= "" then
            accessSet[accessKey] = true
        end

        if istable(data) then
            local sid = isstring(data.steamid) and data.steamid or ""
            local sid64 = isstring(data.steamid64) and data.steamid64 or ""
            if sid ~= "" then accessSet[sid] = true end
            if sid64 ~= "" then accessSet[sid64] = true end
        end
    end
    
    door:SetNWString("VEIN_AccessList", table.concat(names, ","))
    
    -- Update server-side table for backward compatibility
    if VEIN.DoorSystem and VEIN.DoorSystem.DoorAccess then
        VEIN.DoorSystem.DoorAccess[door:EntIndex()] = accessSet
    end
end

-- Check and remove expired guest access
function VEIN.AccessLevels.CheckExpiredGuests()
    for _, door in ipairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():match("door") and door:GetNWBool("VEIN_IsVEINDoor", false) then
            local accessData = door:GetNWString("VEIN_AccessData", "{}")
            local access = util.JSONToTable(accessData) or {}
            local modified = false
            local expiredEntries = {}
            
            for accessKey, data in pairs(access) do
                if istable(data) and data.level == VEIN.AccessLevels.GUEST and data.expiresAt and os.time() >= data.expiresAt then
                    table.insert(expiredEntries, {
                        key = accessKey,
                        data = data,
                    })
                end
            end

            for _, expired in ipairs(expiredEntries) do
                access[expired.key] = nil
                modified = true

                local displayName = VEIN.AccessLevels.GetAccessDisplayName and VEIN.AccessLevels.GetAccessDisplayName(expired.key, expired.data) or expired.key
                local targetPly = FindOnlinePlayer(expired.key, displayName, expired.data.steamid, expired.data.steamid64)
                if IsValid(targetPly) then
                    local doorName = door:GetNWString("VEIN_DoorName", "Door")
                    VEIN.AccessLevels.SendNotification(targetPly, "Guest Access Expired", "Your access to " .. doorName .. " has expired", "warning", 5)
                end
            end
            
            if modified then
                SaveDoorAccess(door, access)
            end
        end
    end
end

-- Check expired guests every 30 seconds
timer.Create("VEIN_CheckExpiredGuests", 30, 0, function()
    VEIN.AccessLevels.CheckExpiredGuests()
end)

-- Network receiver: Set access level
net.Receive("VEIN_AL_SetAccessLevel", function(len, ply)
    local door = net.ReadEntity()
    local targetIdentifier = net.ReadString()
    local targetName = net.ReadString()
    local targetSteamID = net.ReadString()
    local targetSteamID64 = net.ReadString()
    local level = net.ReadString()
    local expirationMinutes = net.ReadUInt(16)
    local syncConnected = net.ReadBool()
    local unsyncConnected = net.ReadBool()
    
    if not IsValid(door) then return end
    if not IsValid(ply) then return end
    if not door:GetNWBool("VEIN_IsVEINDoor", false) then return end
    if ply:GetPos():DistToSqr(door:GetPos()) > (250 * 250) then return end
    
    local playerNick = ply:Nick()
    local botKey, botName = NormalizeBotAccessIdentifier(targetIdentifier, targetName, targetSteamID, targetSteamID64)
    if botKey then
        targetIdentifier = botKey
        targetSteamID = botKey
        targetSteamID64 = ""
        if targetName == "" then
            targetName = botName
        end
    end
    local targetDisplayName = string.Trim(targetName ~= "" and targetName or targetIdentifier)
    if targetDisplayName == "" then
        VEIN.AccessLevels.SendNotification(ply, "Invalid Target", "Unable to resolve player for this permission change", "error", 3)
        return
    end
    
    -- Permission check
    if not VEIN.AccessLevels.CanChangeLevel(door, playerNick, level) then
        VEIN.AccessLevels.SendNotification(ply, "Permission Denied", "You cannot grant this access level", "error", 3)
        return
    end
    
    -- Set the level
    local previousLevel = VEIN.AccessLevels.GetPlayerLevel(door, targetIdentifier)
    if not previousLevel and targetName ~= "" then
        previousLevel = VEIN.AccessLevels.GetPlayerLevel(door, targetName)
    end

    local success, err, affectedDoors, unsyncedCount = VEIN.AccessLevels.SetLevel(
        door,
        targetIdentifier,
        level,
        playerNick,
        expirationMinutes > 0 and expirationMinutes or nil,
        syncConnected,
        targetDisplayName,
        targetSteamID,
        targetSteamID64,
        unsyncConnected
    )
    
    if success then
        -- Notify granter
        local levelName = VEIN.AccessLevels.GetLevelName(level)
        local grantMsg = previousLevel and "Changed " .. targetDisplayName .. "'s access to " .. levelName or "Gave " .. targetDisplayName .. " " .. levelName .. " access"
        if syncConnected and affectedDoors and affectedDoors > 1 then
            grantMsg = grantMsg .. " on " .. affectedDoors .. " connected doors"
        end
        if unsyncConnected and unsyncedCount and unsyncedCount > 0 then
            grantMsg = grantMsg .. " and unsynced from " .. unsyncedCount .. " connected doors"
        end
        VEIN.AccessLevels.SendNotification(ply, previousLevel and "Access Level Changed" or "Access Granted", grantMsg, "success", 3)
        
        -- Notify target if online
        local targetPly = FindOnlinePlayer(targetIdentifier, targetDisplayName, targetSteamID, targetSteamID64)
        if IsValid(targetPly) then
            local doorName = door:GetNWString("VEIN_DoorName", "Door")
            local message

            if previousLevel then
                local oldLevelName = VEIN.AccessLevels.GetLevelName(previousLevel)
                message = "Access changed from " .. oldLevelName .. " to " .. levelName
            else
                message = "You now have " .. levelName .. " access"
            end

            if level == VEIN.AccessLevels.GUEST and expirationMinutes > 0 then
                message = message .. " for " .. expirationMinutes .. " minutes"
            end

            local title = previousLevel and "Access Level Changed: " .. doorName or "Access Granted: " .. doorName
            VEIN.AccessLevels.SendNotification(targetPly, title, message, "success", 5)
        end
        
        -- Notify co-owners when someone is added/removed (if granter is co-owner, not owner)
        local granterLevel = VEIN.AccessLevels.GetPlayerLevel(door, playerNick)
        if granterLevel == VEIN.AccessLevels.CO_OWNER then
            -- Get all co-owners and owner
            local accessData = door:GetNWString("VEIN_AccessData", "{}")
            local access = util.JSONToTable(accessData) or {}
            
            for accessKey, data in pairs(access) do
                local notifyName = VEIN.AccessLevels.GetAccessDisplayName and VEIN.AccessLevels.GetAccessDisplayName(accessKey, data) or accessKey
                if notifyName ~= playerNick and notifyName ~= targetDisplayName then -- Don't notify the granter or target
                    if istable(data) and (data.level == VEIN.AccessLevels.CO_OWNER or data.level == VEIN.AccessLevels.OWNER) then
                        for _, notifyPly in ipairs(player.GetAll()) do
                            if notifyPly:Nick() == notifyName or notifyPly:SteamID() == accessKey or notifyPly:SteamID64() == accessKey then
                                local doorName = door:GetNWString("VEIN_DoorName", "Door")
                                local msg = playerNick .. " gave " .. targetDisplayName .. " " .. levelName .. " access"
                                if previousLevel then
                                    local oldLevelName = VEIN.AccessLevels.GetLevelName(previousLevel)
                                    msg = playerNick .. " changed " .. targetDisplayName .. "'s access from " .. oldLevelName .. " to " .. levelName
                                end
                                VEIN.AccessLevels.SendNotification(notifyPly, "Door Permission Update: " .. doorName, msg, "info", 4)
                                break
                            end
                        end
                    end
                end
            end
        end
    else
        VEIN.AccessLevels.SendNotification(ply, "Access Update Failed", err or "Unable to update access level", "error", 3)
    end
end)

-- Network receiver: Remove access
net.Receive("VEIN_AL_RemoveAccess", function(len, ply)
    local door = net.ReadEntity()
    local targetIdentifier = net.ReadString()
    local targetName = net.ReadString()
    local targetSteamID = net.ReadString()
    local targetSteamID64 = net.ReadString()
    local syncConnected = net.ReadBool()
    
    if not IsValid(door) then return end
    if not IsValid(ply) then return end
    if not door:GetNWBool("VEIN_IsVEINDoor", false) then return end
    if ply:GetPos():DistToSqr(door:GetPos()) > (250 * 250) then return end
    
    local playerNick = ply:Nick()
    local targetDisplayName = string.Trim(targetName ~= "" and targetName or targetIdentifier)
    local botKey, botName = NormalizeBotAccessIdentifier(targetIdentifier, targetName, targetSteamID, targetSteamID64)
    if botKey then
        targetIdentifier = botKey
        targetSteamID = botKey
        targetSteamID64 = ""
        if targetDisplayName == "" then
            targetDisplayName = botName
        end
    end
    if targetDisplayName == "" then
        VEIN.AccessLevels.SendNotification(ply, "Invalid Target", "Unable to resolve player for this removal", "error", 3)
        return
    end
    
    -- Check if player can manage permissions
    if not VEIN.AccessLevels.CanManagePermissions(door, playerNick) then
        VEIN.AccessLevels.SendNotification(ply, "Permission Denied", "You cannot manage permissions on this door", "error", 3)
        return
    end
    
    -- Get target's current level
    local targetLevel = VEIN.AccessLevels.GetPlayerLevel(door, targetIdentifier)
    if not targetLevel and targetName ~= "" then
        targetLevel = VEIN.AccessLevels.GetPlayerLevel(door, targetName)
    end
    
    -- Check if target even has access
    if not targetLevel then
        VEIN.AccessLevels.SendNotification(ply, "Not Found", "Player '" .. targetDisplayName .. "' does not have access!", "error", 3)
        return
    end
    
    -- Check if player can remove this level (can't remove higher or equal levels)
    local playerLevel = VEIN.AccessLevels.GetPlayerLevel(door, playerNick)
    local playerHierarchy = VEIN.AccessLevels.Hierarchy[playerLevel] or 0
    local targetHierarchy = VEIN.AccessLevels.Hierarchy[targetLevel] or 0
    
    if targetHierarchy >= playerHierarchy then
        VEIN.AccessLevels.SendNotification(ply, "Permission Denied", "You cannot remove access from players with equal or higher level", "error", 3)
        return
    end
    
    -- Remove access
    local success, removedCount = VEIN.AccessLevels.RemoveAccess(door, targetIdentifier, syncConnected, targetDisplayName)
    if not success then
        VEIN.AccessLevels.SendNotification(ply, "Not Found", "Player '" .. targetDisplayName .. "' does not have access!", "error", 3)
        return
    end
    
    -- Notify remover
    local removedMsg = "Removed " .. targetDisplayName .. "'s access"
    if syncConnected and removedCount and removedCount > 1 then
        removedMsg = removedMsg .. " on " .. removedCount .. " connected doors"
    end
    VEIN.AccessLevels.SendNotification(ply, "Access Removed", removedMsg, "success", 3)
    
    -- Notify target if online
    local targetPly = FindOnlinePlayer(targetIdentifier, targetDisplayName, targetSteamID, targetSteamID64)
    if IsValid(targetPly) then
        local doorName = door:GetNWString("VEIN_DoorName", "Door")
        VEIN.AccessLevels.SendNotification(targetPly, "Access Removed: " .. doorName, "Your access has been removed", "warning", 5)
    end
    
    -- Notify co-owners when someone is removed (if remover is co-owner, not owner)
    local removerLevel = VEIN.AccessLevels.GetPlayerLevel(door, playerNick)
    if removerLevel == VEIN.AccessLevels.CO_OWNER then
        -- Get all co-owners and owner
        local accessData = door:GetNWString("VEIN_AccessData", "{}")
        local access = util.JSONToTable(accessData) or {}
        
        for accessKey, data in pairs(access) do
            local notifyName = VEIN.AccessLevels.GetAccessDisplayName and VEIN.AccessLevels.GetAccessDisplayName(accessKey, data) or accessKey
            if notifyName ~= playerNick and notifyName ~= targetDisplayName then -- Don't notify the remover or target
                if istable(data) and (data.level == VEIN.AccessLevels.CO_OWNER or data.level == VEIN.AccessLevels.OWNER) then
                    for _, notifyPly in ipairs(player.GetAll()) do
                        if notifyPly:Nick() == notifyName or notifyPly:SteamID() == accessKey or notifyPly:SteamID64() == accessKey then
                            local doorName = door:GetNWString("VEIN_DoorName", "Door")
                            VEIN.AccessLevels.SendNotification(notifyPly, "Door Permission Update: " .. doorName, playerNick .. " removed " .. targetDisplayName .. "'s access", "info", 4)
                            break
                        end
                    end
                end
            end
        end
    end
end)

-- Network receiver: Request access list
net.Receive("VEIN_AL_RequestAccessList", function(len, ply)
    local door = net.ReadEntity()
    
    if not IsValid(door) then return end
    if not IsValid(ply) then return end
    if not door:GetNWBool("VEIN_IsVEINDoor", false) then return end
    if ply:GetPos():DistToSqr(door:GetPos()) > (250 * 250) then return end
    
    -- Permission check
    if not VEIN.AccessLevels.CanManagePermissions(door, ply:Nick()) then
        return
    end
    
    -- Send access list
    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    
    net.Start("VEIN_AL_SendAccessList")
    net.WriteEntity(door)
    net.WriteString(accessData)
    net.Send(ply)
end)

--[[
================================================================================
DATA MIGRATION SYSTEM
================================================================================
Converts old VEIN_AccessList format to new VEIN_AccessData format
]]--

-- Migrate a single door from old format to new format
function VEIN.AccessLevels.MigrateDoor(door)
    if not IsValid(door) then return false end
    
    -- Check if already migrated (has VEIN_AccessData)
    local existingData = door:GetNWString("VEIN_AccessData", "")
    if existingData ~= "" and existingData ~= "{}" then
        -- Already has new format data
        return false
    end
    
    -- Get old access list
    local oldAccessList = door:GetNWString("VEIN_AccessList", "")
    if oldAccessList == "" then
        -- No old data to migrate
        return false
    end
    
    -- Parse old access list (comma-separated names)
    local players = string.Split(oldAccessList, ",")
    if #players == 0 then
        return false
    end
    
    -- Create new access data structure
    local doorIndex = door:EntIndex()
    VEIN.DoorSystem.DoorAccess[doorIndex] = VEIN.DoorSystem.DoorAccess[doorIndex] or {}
    
    local migrationTime = os.time()
    local migrationCount = 0
    
    for _, playerNick in ipairs(players) do
        playerNick = string.Trim(playerNick)
        if playerNick ~= "" then
            -- Default all old access list players to "resident" level
            VEIN.DoorSystem.DoorAccess[doorIndex][playerNick] = {
                level = VEIN.AccessLevels.RESIDENT,
                grantedBy = "System Migration",
                grantedAt = migrationTime,
                expiresAt = nil
            }
            migrationCount = migrationCount + 1
        end
    end
    
    -- Update door network vars
    VEIN.AccessLevels.UpdateAccessList(door)
    
    return true
end

-- Migrate all doors on the map
function VEIN.AccessLevels.MigrateAllDoors()
    local doorCount = 0
    local migratedCount = 0
    
    -- Find all VEIN doors
    for _, ent in ipairs(ents.GetAll()) do
        if IsValid(ent) and ent:GetNWBool("VEIN_IsVEINDoor", false) then
            doorCount = doorCount + 1
            
            if VEIN.AccessLevels.MigrateDoor(ent) then
                migratedCount = migratedCount + 1
            end
        end
    end
    
    -- Save migrated data
    if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.SaveDoors then
        timer.Simple(1, function()
            VEIN.DoorSystem.SaveDoors()
        end)
    end
end

-- Auto-migrate on server start (delayed to ensure all systems loaded)
hook.Add("Initialize", "VEIN_AutoMigrateDoors", function()
    timer.Simple(5, function()
        VEIN.AccessLevels.MigrateAllDoors()
    end)
end)

-- Console command for manual migration
concommand.Add("vein_migrate_access", function(ply, cmd, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[VEIN] Only super admins can run this command")
        return
    end
    
    VEIN.AccessLevels.MigrateAllDoors()
    
    if IsValid(ply) then
        ply:ChatPrint("[VEIN] Door access migration complete! Check console for details")
    end
end)


