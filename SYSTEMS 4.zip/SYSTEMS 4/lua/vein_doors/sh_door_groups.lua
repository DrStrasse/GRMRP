--[[
================================================================================
VEIN Door System - DarkRP Groups & Jobs Integration
Allows setting door groups and job restrictions like DarkRP
================================================================================
]]--

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.DoorGroups = VEIN.DoorGroups or {}
VEIN.Net = VEIN.Net or {}

local Net = VEIN.Net

if SERVER then
    util.AddNetworkString("VEIN_SetDoorGroup")
    util.AddNetworkString("VEIN_SetDoorJobs")
    util.AddNetworkString("VEIN_RequestDoorGroupData")
    util.AddNetworkString("VEIN_DoorGroupData")
end

-- Default door groups (like DarkRP)
VEIN.DoorGroups.Groups = {
    ["Cops and Mayor only"] = {
        jobs = {"TEAM_POLICE", "TEAM_CHIEF", "TEAM_MAYOR"},
        displayName = "Cops and Mayor only"
    },
    ["Gundealer only"] = {
        jobs = {"TEAM_GUN"},
        displayName = "Gundealer only"
    },
    ["Custom"] = {
        jobs = {},
        displayName = "Custom Job Selection"
    }
}

if SERVER then
    -- Get all DarkRP teams/jobs
    local function HasDoorAdminPermission(ply, perm)
        return VEIN.Settings and VEIN.Settings.HasDoorAdminPermission and VEIN.Settings.HasDoorAdminPermission(ply, perm)
    end

    function VEIN.DoorGroups.GetAllJobs()
        if not DarkRP then
            -- Fallback if not DarkRP
            return {
                {name = "Citizen", command = "citizen", team = 1},
                {name = "Police Officer", command = "cp", team = 2},
            }
        end
        
        local jobs = {}
        for k, v in ipairs(RPExtraTeams) do
            table.insert(jobs, {
                name = v.name,
                command = v.command,
                team = k,
                color = v.color
            })
        end
        return jobs
    end
    
    -- Check if player's job can access door
    function VEIN.DoorGroups.CanPlayerAccessDoor(ply, door)
        if not IsValid(door) or not IsValid(ply) then return false end
        
        -- Check if door has job restrictions
        local doorJobs = door:GetNWString("VEIN_AllowedJobs", "")
        if doorJobs == "" or doorJobs == "[]" then
            return true -- No restrictions
        end
        
        local allowedJobs = util.JSONToTable(doorJobs)
        if not allowedJobs or #allowedJobs == 0 then
            return true
        end
        
        -- Check if player's current team is allowed
        local playerTeam = ply:Team()
        for _, jobTeam in ipairs(allowedJobs) do
            if tonumber(jobTeam) == playerTeam then
                return true
            end
        end
        
        return false
    end
    
    -- Set door group
    net.Receive("VEIN_SetDoorGroup", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminEditGroupsDoor") then return end
        
        local door = net.ReadEntity()
        local groupName = net.ReadString()
        
        if not IsValid(door) then return end
        if ply:GetPos():DistToSqr(door:GetPos()) > (250 * 250) then return end
        
        -- Verify this is a VEIN door
        if not door:GetNWBool("VEIN_IsVEINDoor", false) then
            VEIN.Chat(ply, "This is not a VEIN door!")
            return
        end
        
        local group = VEIN.DoorGroups.Groups[groupName]
        if not group then return end
        
        -- Set the door group (this does NOT remove ownership or other VEIN data)
        door:SetNWString("VEIN_DoorGroup", groupName)
        
        -- Convert job names to team numbers
        local teamNumbers = {}
        if DarkRP and group.jobs then
            for _, jobName in ipairs(group.jobs) do
                for k, v in ipairs(RPExtraTeams) do
                    local teamName = team.GetName and team.GetName(k) or ""
                    if v.command == jobName or v.name == jobName or teamName == jobName then
                        table.insert(teamNumbers, k)
                    end
                end
            end
        end
        
        door:SetNWString("VEIN_AllowedJobs", util.TableToJSON(teamNumbers))
        
        -- Call hook for persistence system
        hook.Run("VEIN_DoorModified", door)
        
        VEIN.Chat(ply, "Door group set to: " .. groupName)
    end)
    
    -- Set custom door jobs
    net.Receive("VEIN_SetDoorJobs", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminEditGroupsDoor") then return end
        
        local door = net.ReadEntity()
        local jobs = Net.ReadTeamList()
        
        if not IsValid(door) then return end
        if ply:GetPos():DistToSqr(door:GetPos()) > (250 * 250) then return end
        
        -- Verify this is a VEIN door
        if not door:GetNWBool("VEIN_IsVEINDoor", false) then
            VEIN.Chat(ply, "This is not a VEIN door!")
            return
        end
        
        -- Set custom jobs (this does NOT remove ownership or other VEIN data)
        door:SetNWString("VEIN_DoorGroup", "Custom")
        door:SetNWString("VEIN_AllowedJobs", util.TableToJSON(jobs))
        
        -- Call hook for persistence system
        hook.Run("VEIN_DoorModified", door)
    end)
    
    -- Send door group data to client
    net.Receive("VEIN_RequestDoorGroupData", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminEditGroupsDoor") then return end
        
        local door = net.ReadEntity()
        if not IsValid(door) then return end
        if ply:GetPos():DistToSqr(door:GetPos()) > (250 * 250) then return end
        
        -- Verify this is a VEIN door
        if not door:GetNWBool("VEIN_IsVEINDoor", false) then
            VEIN.Chat(ply, "This is not a VEIN door!")
            return
        end
        
        net.Start("VEIN_DoorGroupData")
        net.WriteEntity(door)
        net.WriteString(door:GetNWString("VEIN_DoorGroup", ""))
        net.WriteString(door:GetNWString("VEIN_AllowedJobs", "[]"))
        Net.WriteJobList(VEIN.DoorGroups.GetAllJobs())
        net.Send(ply)
    end)
    
    -- Hook into door purchase to check job restrictions
    hook.Add("VEIN_CanBuyDoor", "VEIN_CheckDoorJobs", function(ply, door)
        if not VEIN.DoorGroups.CanPlayerAccessDoor(ply, door) then
            return false, "Your job cannot access this door!"
        end
    end)
end

if CLIENT then
    local function ListHasValue(list, value)
        for _, v in ipairs(list or {}) do
            if v == value then return true end
        end
        return false
    end

    local function ClearList(list)
        for i = #list, 1, -1 do
            list[i] = nil
        end
    end
    -- Open door group editor
    function VEIN.DoorGroups.OpenEditor(door)
        if not IsValid(door) then return end
        
        -- Request door data
        net.Start("VEIN_RequestDoorGroupData")
        net.WriteEntity(door)
        net.SendToServer()
    end
    
    -- Receive door group data and open editor
    net.Receive("VEIN_DoorGroupData", function()
        local door = net.ReadEntity()
        local currentGroup = net.ReadString()
        local currentJobs = net.ReadString()
        local allJobs = Net.ReadJobList()
        
        if not IsValid(door) then return end
        
        local allowedJobs = util.JSONToTable(currentJobs) or {}
        
        -- Create editor frame
        local frame = vgui.Create("DFrame")
        local baseW, baseH = 500, 600
        local frameW = math.max(360, math.min(baseW, ScrW() - 80))
        local frameH = math.max(420, math.min(baseH, ScrH() - 80))
        frame:SetSize(frameW, frameH)
        frame:SetTitle("")
        frame:Center()
        frame:MakePopup()
        frame:ShowCloseButton(false)
        local innerW = frame:GetWide() - 40
        
        -- VEIN dark theme
        frame.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 250))
            surface.SetDrawColor(120, 40, 40, 180)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
        end
        
        -- Title
        local titleLabel = vgui.Create("DLabel", frame)
        titleLabel:SetPos(20, 15)
        titleLabel:SetText("Edit Door Group & Jobs")
        titleLabel:SetFont("DermaLarge")
        titleLabel:SetTextColor(Color(255, 200, 200))
        titleLabel:SizeToContents()
        
        -- Close button
        local closeBtn = vgui.Create("DButton", frame)
        closeBtn:SetPos(frame:GetWide() - 50, 15)
        closeBtn:SetSize(30, 30)
        closeBtn:SetText("X")
        closeBtn:SetTextColor(Color(255, 255, 255))
        closeBtn.Paint = function(self, w, h)
            local col = self:IsHovered() and Color(180, 60, 60) or Color(80, 30, 30)
            draw.RoundedBox(4, 0, 0, w, h, col)
        end
        closeBtn.DoClick = function()
            frame:Close()
        end
        
        -- Door group section
        local groupLabel = vgui.Create("DLabel", frame)
        groupLabel:SetPos(20, 60)
        groupLabel:SetText("Door Group:")
        groupLabel:SetFont("DermaDefaultBold")
        groupLabel:SetTextColor(Color(200, 200, 255))
        groupLabel:SizeToContents()
        
        local groupCombo = vgui.Create("DComboBox", frame)
        groupCombo:SetPos(20, 85)
        groupCombo:SetSize(innerW, 30)
        groupCombo:SetValue(currentGroup ~= "" and currentGroup or "None")
        groupCombo:SetTextColor(Color(255, 255, 255))
        groupCombo:SetSortItems(false)
        
        -- Dark theme for dropdown
        groupCombo.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(40, 40, 45, 230))
            surface.SetDrawColor(100, 50, 50, 150)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        local groupNames = table.GetKeys(VEIN.DoorGroups.Groups)
        table.sort(groupNames)
        for _, groupName in ipairs(groupNames) do
            groupCombo:AddChoice(groupName)
        end
        groupCombo:AddChoice("None")
        
        -- Custom jobs section
        local jobsLabel = vgui.Create("DLabel", frame)
        jobsLabel:SetPos(20, 130)
        jobsLabel:SetText("Allowed Jobs (Custom):")
        jobsLabel:SetFont("DermaDefaultBold")
        jobsLabel:SetTextColor(Color(200, 200, 255))
        jobsLabel:SizeToContents()
        
        -- Job list
        local jobList = vgui.Create("DListView", frame)
        jobList:SetPos(20, 160)
        local listHeight = math.max(200, frame:GetTall() - 240)
        jobList:SetSize(innerW, listHeight)
        jobList:SetMultiSelect(false)
        jobList:AddColumn("Job Name")
        jobList:AddColumn("Allowed"):SetFixedWidth(80)
        
        jobList.Paint = function(self, w, h)
            surface.SetDrawColor(30, 30, 30, 200)
            surface.DrawRect(0, 0, w, h)
        end
        
        -- Style the list to have white text
        jobList:SetHeaderHeight(25)
        jobList:SetDataHeight(20)
        
        -- Override line paint to make text white
        local oldOnRowRightClick = jobList.OnRowRightClick
        jobList.OnRowRightClick = function(self, lineID, line)
            if oldOnRowRightClick then oldOnRowRightClick(self, lineID, line) end
        end
        
        local selectedJobs = {}
        for _, job in ipairs(allJobs) do
            local isAllowed = ListHasValue(allowedJobs, job.team)
            local line = jobList:AddLine(job.name, isAllowed and "Yes" or "No")
            line.jobTeam = job.team
            line.isAllowed = isAllowed
            
            -- Set column text colors: white for job name, green/red for Yes/No
            line.Columns[1]:SetTextColor(Color(255, 255, 255))
            line.Columns[2]:SetTextColor(isAllowed and Color(100, 255, 100) or Color(255, 100, 100))
            
            -- Override the line paint for selection/hover background only
            line.Paint = function(self, w, h)
                if self:IsSelected() then
                    surface.SetDrawColor(80, 40, 40, 150)
                    surface.DrawRect(0, 0, w, h)
                elseif self:IsHovered() then
                    surface.SetDrawColor(60, 30, 30, 100)
                    surface.DrawRect(0, 0, w, h)
                end
                -- Return false to let default text rendering happen (now in white/green/red)
                return false
            end
            
            if isAllowed then
                table.insert(selectedJobs, job.team)
            end
        end
        
        -- Create Apply button first (needs to exist before callbacks reference it)
        local applyBtn = vgui.Create("DButton", frame)
        applyBtn:SetPos(20, frame:GetTall() - 60)
        applyBtn:SetSize(innerW, 40)
        applyBtn:SetText("Apply Custom Jobs & Close")
        applyBtn:SetTextColor(Color(255, 255, 255))
        applyBtn:SetVisible(currentGroup == "Custom") -- Only visible if already on Custom
        applyBtn.Paint = function(self, w, h)
            local col = self:IsHovered() and Color(100, 150, 100) or Color(80, 120, 80)
            draw.RoundedBox(6, 0, 0, w, h, col)
        end
        applyBtn.DoClick = function()
            -- Only set to "Custom" if user actually modified jobs manually
            net.Start("VEIN_SetDoorJobs")
            net.WriteEntity(door)
            Net.WriteTeamList(selectedJobs)
            net.SendToServer()
            
            chat.AddText(Color(100, 255, 100), "[VEIN] Custom job restrictions applied")
            frame:Close()
        end
        
        -- Toggle job on click
        jobList.OnRowSelected = function(self, index, line)
            line.isAllowed = not line.isAllowed
            line:SetColumnText(2, line.isAllowed and "Yes" or "No")
            
            -- Update color: green for Yes, red for No
            line.Columns[2]:SetTextColor(line.isAllowed and Color(100, 255, 100) or Color(255, 100, 100))
            
            if line.isAllowed then
                if not ListHasValue(selectedJobs, line.jobTeam) then
                    table.insert(selectedJobs, line.jobTeam)
                end
            else
                table.RemoveByValue(selectedJobs, line.jobTeam)
            end
            
            -- Manual job change - switch to "Custom" mode and show Apply button
            local wasCustom = (groupCombo:GetValue() == "Custom")
            groupCombo:SetValue("Custom")
            applyBtn:SetVisible(true)
            
            -- Only show message if we just switched FROM a preset TO custom
            if not wasCustom then
                chat.AddText(Color(200, 200, 255), "[VEIN] Switched to Custom mode - click Apply to save")
            end
        end
        
        -- Now set up combo box OnSelect (needs access to jobList and selectedJobs)
        groupCombo.OnSelect = function(self, index, value)
            if value == "Custom" then
                -- Just switch to custom mode, show Apply button
                applyBtn:SetVisible(true)
                chat.AddText(Color(200, 200, 255), "[VEIN] Configure jobs below and click 'Apply Custom Jobs'")
            elseif value == "None" then
                -- Clear all restrictions and update live (preset - hide Apply button)
                applyBtn:SetVisible(false)
                
                net.Start("VEIN_SetDoorJobs")
                net.WriteEntity(door)
                Net.WriteTeamList({})
                net.SendToServer()
                
                -- Clear selectedJobs table
                ClearList(selectedJobs)
                
                -- Update list live - set all to "No"
                for _, line in ipairs(jobList:GetLines()) do
                    line.isAllowed = false
                    line:SetColumnText(2, "No")
                    line.Columns[2]:SetTextColor(Color(255, 100, 100))
                end
                
                chat.AddText(Color(100, 255, 100), "[VEIN] Door restrictions cleared")
            else
                -- Apply preset group and update live (preset - hide Apply button)
                applyBtn:SetVisible(false)
                
                net.Start("VEIN_SetDoorGroup")
                net.WriteEntity(door)
                net.WriteString(value)
                net.SendToServer()
                
                -- Get the preset's allowed teams
                local group = VEIN.DoorGroups.Groups[value]
                if group and group.jobs then
                    local allowedTeams = {}
                    for _, jobName in ipairs(group.jobs) do
                        for k, v in ipairs(RPExtraTeams or {}) do
                            local teamName = team.GetName and team.GetName(k) or ""
                            if v.command == jobName or v.name == jobName or teamName == jobName then
                                table.insert(allowedTeams, k)
                            end
                        end
                    end
                    
                    -- Update selectedJobs table
                    ClearList(selectedJobs)
                    for _, team in ipairs(allowedTeams) do
                        table.insert(selectedJobs, team)
                    end
                    
                    -- Update list live - mark allowed jobs
                    for _, line in ipairs(jobList:GetLines()) do
                        line.isAllowed = ListHasValue(allowedTeams, line.jobTeam)
                        line:SetColumnText(2, line.isAllowed and "Yes" or "No")
                        line.Columns[2]:SetTextColor(line.isAllowed and Color(100, 255, 100) or Color(255, 100, 100))
                    end
                end
                
                chat.AddText(Color(100, 255, 100), "[VEIN] Door group set to: " .. value)
            end
        end
    end)
end


