--[[
================================================================================
VEIN Door System - DarkRP Door Text Suppression
Disable DarkRP's default door text without aggressive detours.
================================================================================
]]--

if SERVER then return end

local attempts = 0
local maxAttempts = 12

local function DisableDarkRPDoorText()
    if not DarkRP then return false end

    local changed = false
    local hooks = hook.GetTable().HUDDrawDoorData
    if hooks and hooks.DarkRP_DrawDoorData then
        hook.Remove("HUDDrawDoorData", "DarkRP_DrawDoorData")
        changed = true
    end

    if DarkRP.drawDoorOwnableInformation then
        DarkRP.drawDoorOwnableInformation = function() end
        changed = true
    end

    return changed
end

local function TryDisable()
    attempts = attempts + 1
    if DisableDarkRPDoorText() then return end
    if attempts < maxAttempts then
        timer.Simple(0.5, TryDisable)
    end
end

hook.Add("InitPostEntity", "VEIN_DisableDarkRPDoorText", function()
    attempts = 0
    TryDisable()
end)
