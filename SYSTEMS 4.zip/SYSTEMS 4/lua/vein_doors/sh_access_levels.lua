--[[
================================================================================
VEIN Access Levels System - Shared
================================================================================
Manages door access permissions with tiered levels
]]--

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.AccessLevels = VEIN.AccessLevels or {}

-- Access level constants
VEIN.AccessLevels.OWNER = "owner"
VEIN.AccessLevels.CO_OWNER = "co-owner"
VEIN.AccessLevels.RESIDENT = "resident"
VEIN.AccessLevels.GUEST = "guest"

-- Access level hierarchy (higher number = more permissions)
VEIN.AccessLevels.Hierarchy = {
    [VEIN.AccessLevels.OWNER] = 4,
    [VEIN.AccessLevels.CO_OWNER] = 3,
    [VEIN.AccessLevels.RESIDENT] = 2,
    [VEIN.AccessLevels.GUEST] = 1,
}

-- Access level display info
VEIN.AccessLevels.Info = {
    [VEIN.AccessLevels.OWNER] = {
        name = "Owner",
        icon = "✰",
        color = Color(255, 81, 0),
        description = "Full control over the door",
    },
    [VEIN.AccessLevels.CO_OWNER] = {
        name = "Co-Owner",
        icon = "❖",
        color = Color(255, 142, 13),
        description = "Can manage permissions and rename door",
    },
    [VEIN.AccessLevels.RESIDENT] = {
        name = "Resident",
        icon = "☎",
        color = Color(125, 118, 224),
        description = "Can lock/unlock and invite guests",
    },
    [VEIN.AccessLevels.GUEST] = {
        name = "Guest",
        icon = "  ♦ ",
        color = Color(128, 128, 128), -- Gray
        description = "Temporary access with time limit",
    },
}

local function normalizeLookupValue(value)
    if not isstring(value) then return "" end
    return string.lower(string.Trim(value))
end

local function findPlayerByIdentifier(identifier)
    if not isstring(identifier) then return nil end
    identifier = string.Trim(identifier)
    if identifier == "" then return nil end

    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            local sid = ply:SteamID() or ""
            local sid64 = ply:SteamID64() or ""
            if ply:Nick() == identifier or sid == identifier or sid64 == identifier then
                return ply
            end
        end
    end

    return nil
end

local function resolveAccessEntryFromTable(access, identifier, fallbackName)
    if not istable(access) then return nil, nil end

    identifier = isstring(identifier) and string.Trim(identifier) or ""
    fallbackName = isstring(fallbackName) and string.Trim(fallbackName) or ""

    if identifier ~= "" and access[identifier] ~= nil then
        return identifier, access[identifier]
    end

    local normalizedIdentifier = normalizeLookupValue(identifier)
    local normalizedFallbackName = normalizeLookupValue(fallbackName)
    local matchedPlayer = findPlayerByIdentifier(identifier) or findPlayerByIdentifier(fallbackName)
    local matchedSid = ""
    local matchedSid64 = ""
    if IsValid(matchedPlayer) and not matchedPlayer:IsBot() then
        matchedSid = matchedPlayer:SteamID() or ""
        matchedSid64 = matchedPlayer:SteamID64() or ""
    end
    local normalizedMatchedSid = normalizeLookupValue(matchedSid)
    local normalizedMatchedSid64 = normalizeLookupValue(matchedSid64)

    for accessKey, data in pairs(access) do
        local normalizedKey = normalizeLookupValue(accessKey)
        if normalizedIdentifier ~= "" and normalizedKey == normalizedIdentifier then
            return accessKey, data
        end

        local entryName = istable(data) and data.name or accessKey
        local normalizedEntryName = normalizeLookupValue(entryName)
        if normalizedFallbackName ~= "" and normalizedEntryName == normalizedFallbackName then
            return accessKey, data
        end
        if normalizedIdentifier ~= "" and normalizedEntryName == normalizedIdentifier then
            return accessKey, data
        end
        if isstring(entryName) and string.StartWith(entryName, "BOT_") then
            local botName = string.sub(entryName, 5)
            local normalizedBotName = normalizeLookupValue(botName)
            if normalizedFallbackName ~= "" and normalizedBotName == normalizedFallbackName then
                return accessKey, data
            end
            if normalizedIdentifier ~= "" and normalizedBotName == normalizedIdentifier then
                return accessKey, data
            end
        end

        local dataSid = istable(data) and normalizeLookupValue(data.steamid or "") or ""
        local dataSid64 = istable(data) and normalizeLookupValue(data.steamid64 or "") or ""
        if normalizedIdentifier ~= "" and (dataSid == normalizedIdentifier or dataSid64 == normalizedIdentifier) then
            return accessKey, data
        end
        if normalizedMatchedSid ~= "" and (normalizedKey == normalizedMatchedSid or dataSid == normalizedMatchedSid) then
            return accessKey, data
        end
        if normalizedMatchedSid64 ~= "" and (normalizedKey == normalizedMatchedSid64 or dataSid64 == normalizedMatchedSid64) then
            return accessKey, data
        end
    end

    return nil, nil
end

function VEIN.AccessLevels.ResolveAccessEntry(door, identifier, fallbackName)
    if not IsValid(door) then return nil, nil, {} end

    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    local access = util.JSONToTable(accessData) or {}
    local key, data = resolveAccessEntryFromTable(access, identifier, fallbackName)

    return key, data, access
end

function VEIN.AccessLevels.GetAccessDisplayName(accessKey, data)
    if istable(data) and isstring(data.name) and string.Trim(data.name) ~= "" then
        return string.Trim(data.name)
    end

    if isstring(accessKey) then
        local key = string.Trim(accessKey)
        if key ~= "" then
            if string.StartWith(key, "BOT_") then
                local botName = string.sub(key, 5)
                if botName ~= "" then
                    return botName
                end
            end
            local playerMatch = findPlayerByIdentifier(key)
            if IsValid(playerMatch) then
                return playerMatch:Nick()
            end
            return key
        end
    end

    return "Unknown"
end

-- Get access level for a player on a door
function VEIN.AccessLevels.GetPlayerLevel(door, playerNick)
    if not IsValid(door) then return nil end
    
    -- Check if player is the owner (VEIN_Owner is SteamID, compare against OwnerName)
    local ownerName = door:GetNWString("VEIN_OwnerName", "")
    if ownerName == playerNick then
        return VEIN.AccessLevels.OWNER
    end
    
    -- Check access data
    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    local access = util.JSONToTable(accessData) or {}
    
    local _, data = resolveAccessEntryFromTable(access, playerNick, playerNick)
    if istable(data) then
        return data.level
    end
    
    return nil
end

-- Check if player has at least a certain access level
function VEIN.AccessLevels.HasLevel(door, playerNick, requiredLevel)
    local playerLevel = VEIN.AccessLevels.GetPlayerLevel(door, playerNick)
    if not playerLevel then return false end
    
    local playerHierarchy = VEIN.AccessLevels.Hierarchy[playerLevel] or 0
    local requiredHierarchy = VEIN.AccessLevels.Hierarchy[requiredLevel] or 0
    
    return playerHierarchy >= requiredHierarchy
end

-- Check if player has any access to door
function VEIN.AccessLevels.HasAccess(door, playerNick)
    return VEIN.AccessLevels.GetPlayerLevel(door, playerNick) ~= nil
end

-- Permission checks
function VEIN.AccessLevels.CanLockUnlock(door, playerNick)
    return VEIN.AccessLevels.HasLevel(door, playerNick, VEIN.AccessLevels.RESIDENT)
end

function VEIN.AccessLevels.CanManagePermissions(door, playerNick)
    return VEIN.AccessLevels.HasLevel(door, playerNick, VEIN.AccessLevels.CO_OWNER)
end

function VEIN.AccessLevels.CanRenameDoor(door, playerNick)
    return VEIN.AccessLevels.HasLevel(door, playerNick, VEIN.AccessLevels.CO_OWNER)
end

function VEIN.AccessLevels.CanSellDoor(door, playerNick)
    return VEIN.AccessLevels.GetPlayerLevel(door, playerNick) == VEIN.AccessLevels.OWNER
end

function VEIN.AccessLevels.CanAddCoOwner(door, playerNick)
    return VEIN.AccessLevels.GetPlayerLevel(door, playerNick) == VEIN.AccessLevels.OWNER
end

function VEIN.AccessLevels.CanInviteGuests(door, playerNick)
    return VEIN.AccessLevels.HasLevel(door, playerNick, VEIN.AccessLevels.RESIDENT)
end

function VEIN.AccessLevels.CanChangeLevel(door, playerNick, targetLevel)
    local playerLevel = VEIN.AccessLevels.GetPlayerLevel(door, playerNick)
    
    -- Only owner can add/remove co-owners
    if targetLevel == VEIN.AccessLevels.CO_OWNER or targetLevel == VEIN.AccessLevels.OWNER then
        return playerLevel == VEIN.AccessLevels.OWNER
    end
    
    -- Co-owners and owners can manage residents and guests
    return VEIN.AccessLevels.HasLevel(door, playerNick, VEIN.AccessLevels.CO_OWNER)
end

-- Get all players with access to a door (returns table with levels)
function VEIN.AccessLevels.GetAllAccess(door)
    if not IsValid(door) then return {} end
    
    local result = {}
    
    -- Add owner
    local ownerName = door:GetNWString("VEIN_OwnerName", "")
    if ownerName ~= "" then
        result[ownerName] = {
            level = VEIN.AccessLevels.OWNER,
            grantedBy = "System",
            grantedAt = 0,
            name = ownerName,
        }
    end
    
    -- Add all other players
    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    local access = util.JSONToTable(accessData) or {}
    
    for playerNick, data in pairs(access) do
        result[playerNick] = data
    end
    
    return result
end

-- Get display name for access level
function VEIN.AccessLevels.GetLevelName(level)
    local info = VEIN.AccessLevels.Info[level]
    return info and info.name or "Unknown"
end

-- Get color for access level
function VEIN.AccessLevels.GetLevelColor(level)
    local info = VEIN.AccessLevels.Info[level]
    return info and info.color or Color(255, 255, 255)
end

-- Get icon for access level
function VEIN.AccessLevels.GetLevelIcon(level)
    local info = VEIN.AccessLevels.Info[level]
    return info and info.icon or "?"
end

-- Check if guest access has expired
function VEIN.AccessLevels.IsGuestExpired(door, playerNick)
    if not IsValid(door) then return true end
    
    local accessData = door:GetNWString("VEIN_AccessData", "{}")
    local access = util.JSONToTable(accessData) or {}
    
    local _, playerAccess = resolveAccessEntryFromTable(access, playerNick, playerNick)
    if not istable(playerAccess) then return true end
    if playerAccess.level ~= VEIN.AccessLevels.GUEST then return false end
    
    local expiresAt = playerAccess.expiresAt
    if not expiresAt then return false end -- No expiration set
    
    return os.time() >= expiresAt
end

if CLIENT then
    -- Client-side helper to get local player's level
    function VEIN.AccessLevels.GetMyLevel(door)
        local ply = LocalPlayer()
        return VEIN.AccessLevels.GetPlayerLevel(door, ply:Nick())
    end
    
    -- Client-side permission checks for local player
    function VEIN.AccessLevels.CanI(door, permission)
        local ply = LocalPlayer()
        local playerNick = ply:Nick()
        
        if permission == "lock" then
            return VEIN.AccessLevels.CanLockUnlock(door, playerNick)
        elseif permission == "manage" then
            return VEIN.AccessLevels.CanManagePermissions(door, playerNick)
        elseif permission == "rename" then
            return VEIN.AccessLevels.CanRenameDoor(door, playerNick)
        elseif permission == "sell" then
            return VEIN.AccessLevels.CanSellDoor(door, playerNick)
        elseif permission == "invite" then
            return VEIN.AccessLevels.CanInviteGuests(door, playerNick)
        end
        
        return false
    end
end


