--[[
================================================================================
VEIN Door System - Net Serialization Helpers
Avoid net.WriteTable for performance and guideline compliance.
================================================================================
]]--

VEIN = VEIN or {}
local VEIN = VEIN
VEIN.Net = VEIN.Net or {}

local Net = VEIN.Net

function Net.WriteColor(color)
    local col = color or Color(255, 255, 255, 255)
    net.WriteUInt(col.r or 255, 8)
    net.WriteUInt(col.g or 255, 8)
    net.WriteUInt(col.b or 255, 8)
    net.WriteUInt(col.a or 255, 8)
end

function Net.ReadColor()
    local r = net.ReadUInt(8)
    local g = net.ReadUInt(8)
    local b = net.ReadUInt(8)
    local a = net.ReadUInt(8)
    return Color(r, g, b, a)
end

function Net.WriteTeamList(list)
    local teams = list or {}
    net.WriteUInt(#teams, 16)
    for _, teamId in ipairs(teams) do
        net.WriteUInt(tonumber(teamId) or 0, 16)
    end
end

function Net.ReadTeamList()
    local count = net.ReadUInt(16)
    local teams = {}
    for i = 1, count do
        teams[i] = net.ReadUInt(16)
    end
    return teams
end

function Net.WriteJobList(jobs)
    local list = jobs or {}
    net.WriteUInt(#list, 16)
    for _, job in ipairs(list) do
        net.WriteString(job.name or "")
        net.WriteString(job.command or "")
        net.WriteUInt(tonumber(job.team) or 0, 16)
        Net.WriteColor(job.color)
    end
end

function Net.ReadJobList()
    local count = net.ReadUInt(16)
    local list = {}
    for i = 1, count do
        local name = net.ReadString()
        local command = net.ReadString()
        local teamId = net.ReadUInt(16)
        local color = Net.ReadColor()
        list[i] = {name = name, command = command, team = teamId, color = color}
    end
    return list
end

function Net.WriteDoorTypes(types)
    local list = types or {}
    net.WriteUInt(#list, 16)
    for _, typeData in ipairs(list) do
        net.WriteString(typeData.name or "")
        Net.WriteColor(typeData.color)
        net.WriteString(typeData.desc or "")
    end
end

function Net.ReadDoorTypes()
    local count = net.ReadUInt(16)
    local list = {}
    for i = 1, count do
        local name = net.ReadString()
        local color = Net.ReadColor()
        local desc = net.ReadString()
        list[i] = {name = name, color = color, desc = desc}
    end
    return list
end

function Net.WriteDoorMaterials(materials)
    local list = materials or {}
    net.WriteUInt(#list, 16)
    for _, mat in ipairs(list) do
        net.WriteString(mat.name or "")
        net.WriteInt(tonumber(mat.kickTime) or 0, 16)
        net.WriteString(mat.lockSound or "")
        net.WriteString(mat.unlockSound or "")
        net.WriteString(mat.kickSound or "")
        net.WriteString(mat.breakSound or "")
        net.WriteUInt(tonumber(mat.lockPitch) or 100, 8)
        net.WriteUInt(tonumber(mat.unlockPitch) or 100, 8)
        net.WriteUInt(tonumber(mat.kickPitch) or 100, 8)
        net.WriteUInt(tonumber(mat.breakPitch) or 100, 8)
    end
end

function Net.ReadDoorMaterials()
    local count = net.ReadUInt(16)
    local list = {}
    for i = 1, count do
        local name = net.ReadString()
        local kickTime = net.ReadInt(16)
        local lockSound = net.ReadString()
        local unlockSound = net.ReadString()
        local kickSound = net.ReadString()
        local breakSound = net.ReadString()
        local lockPitch = net.ReadUInt(8)
        local unlockPitch = net.ReadUInt(8)
        local kickPitch = net.ReadUInt(8)
        local breakPitch = net.ReadUInt(8)
        list[i] = {
            name = name,
            kickTime = kickTime,
            lockSound = lockSound,
            unlockSound = unlockSound,
            kickSound = kickSound,
            breakSound = breakSound,
            lockPitch = lockPitch,
            unlockPitch = unlockPitch,
            kickPitch = kickPitch,
            breakPitch = breakPitch
        }
    end
    return list
end

function Net.WriteStringIntMap(map, bits)
    local count = table.Count(map or {})
    net.WriteUInt(count, 16)
    for key, value in pairs(map or {}) do
        net.WriteString(tostring(key))
        net.WriteInt(tonumber(value) or 0, bits or 16)
    end
end

function Net.ReadStringIntMap(bits)
    local count = net.ReadUInt(16)
    local map = {}
    for i = 1, count do
        local key = net.ReadString()
        local value = net.ReadInt(bits or 16)
        map[key] = value
    end
    return map
end

function Net.WriteStringBoolMap(map)
    local count = table.Count(map or {})
    net.WriteUInt(count, 16)
    for key, value in pairs(map or {}) do
        net.WriteString(tostring(key))
        net.WriteBool(value == true)
    end
end

function Net.ReadStringBoolMap()
    local count = net.ReadUInt(16)
    local map = {}
    for i = 1, count do
        local key = net.ReadString()
        local value = net.ReadBool()
        map[key] = value
    end
    return map
end

function Net.WriteDoorAdminList(list)
    local entries = list or {}
    net.WriteUInt(#entries, 16)
    for _, entry in ipairs(entries) do
        net.WriteString(entry.steamid or "")
        net.WriteString(entry.name or "")
        Net.WriteStringBoolMap(entry.perms or {})
    end
end

function Net.ReadDoorAdminList()
    local count = net.ReadUInt(16)
    local list = {}
    for i = 1, count do
        local steamid = net.ReadString()
        local name = net.ReadString()
        local perms = Net.ReadStringBoolMap()
        list[i] = {steamid = steamid, name = name, perms = perms}
    end
    return list
end

function Net.WritePlayerList(list)
    local entries = list or {}
    net.WriteUInt(#entries, 16)
    for _, entry in ipairs(entries) do
        net.WriteString(entry.name or "")
        net.WriteString(entry.steamid or "")
        net.WriteUInt(tonumber(entry.ownedDoors) or 0, 16)
        net.WriteInt(tonumber(entry.defaultLimit) or 0, 16)
        local hasCustom = entry.customLimit ~= nil
        net.WriteBool(hasCustom)
        if hasCustom then
            net.WriteInt(tonumber(entry.customLimit) or 0, 16)
        end
    end
end

function Net.ReadPlayerList()
    local count = net.ReadUInt(16)
    local list = {}
    for i = 1, count do
        local name = net.ReadString()
        local steamid = net.ReadString()
        local ownedDoors = net.ReadUInt(16)
        local defaultLimit = net.ReadInt(16)
        local hasCustom = net.ReadBool()
        local customLimit = nil
        if hasCustom then
            customLimit = net.ReadInt(16)
        end
        list[i] = {
            name = name,
            steamid = steamid,
            ownedDoors = ownedDoors,
            defaultLimit = defaultLimit,
            customLimit = customLimit
        }
    end
    return list
end

function Net.WriteDoorList(list)
    local entries = list or {}
    net.WriteUInt(#entries, 16)
    for _, entry in ipairs(entries) do
        net.WriteString(entry.name or "")
        net.WriteString(entry.type or "")
        net.WriteString(entry.owner or "")
        net.WriteString(entry.status or "")
        net.WriteBool(entry.disabled == true)
        net.WriteString(entry.identifier or "")
    end
end

function Net.ReadDoorList()
    local count = net.ReadUInt(16)
    local list = {}
    for i = 1, count do
        local name = net.ReadString()
        local typeName = net.ReadString()
        local owner = net.ReadString()
        local status = net.ReadString()
        local disabled = net.ReadBool()
        local identifier = net.ReadString()
        list[i] = {
            name = name,
            type = typeName,
            owner = owner,
            status = status,
            disabled = disabled,
            identifier = identifier
        }
    end
    return list
end

function Net.WriteCopiedDoorData(data)
    local hasData = data and next(data) ~= nil
    net.WriteBool(hasData)
    if not hasData then return end
    net.WriteString(data.name or "")
    net.WriteInt(tonumber(data.price) or 0, 32)
    net.WriteString(data.doorType or "")
    net.WriteString(data.doorMaterial or "")
    net.WriteInt(tonumber(data.kickTime) or 0, 16)
    net.WriteString(data.doorGroup or "")
    net.WriteString(data.allowedJobs or "")
    net.WriteString(data.controlJobs or "")
    net.WriteBool(data.defaultLocked == true)
    net.WriteString(data.lockSound or "")
    net.WriteString(data.unlockSound or "")
    net.WriteString(data.kickSound or "")
    net.WriteString(data.breakSound or "")
    net.WriteInt(tonumber(data.lockPitch) or 100, 16)
    net.WriteInt(tonumber(data.unlockPitch) or 100, 16)
    net.WriteInt(tonumber(data.kickPitch) or 100, 16)
    net.WriteInt(tonumber(data.breakPitch) or 100, 16)
    net.WriteBool(data.wasStatic == true)
    net.WriteBool(data.wasJobControlled == true)
    net.WriteBool(data.allowOwnership == true)
    net.WriteBool(data.buyable == true)
    net.WriteBool(data.adminOnly == true)
    net.WriteString(data.propertyGroupName or "")
    net.WriteInt(tonumber(data.propertyCustomPrice) or 0, 32)
end

function Net.ReadCopiedDoorData()
    local hasData = net.ReadBool()
    if not hasData then
        return {}
    end
    local data = {}
    data.name = net.ReadString()
    data.price = net.ReadInt(32)
    data.doorType = net.ReadString()
    data.doorMaterial = net.ReadString()
    data.kickTime = net.ReadInt(16)
    data.doorGroup = net.ReadString()
    data.allowedJobs = net.ReadString()
    data.controlJobs = net.ReadString()
    data.defaultLocked = net.ReadBool()
    data.lockSound = net.ReadString()
    data.unlockSound = net.ReadString()
    data.kickSound = net.ReadString()
    data.breakSound = net.ReadString()
    data.lockPitch = net.ReadInt(16)
    data.unlockPitch = net.ReadInt(16)
    data.kickPitch = net.ReadInt(16)
    data.breakPitch = net.ReadInt(16)
    data.wasStatic = net.ReadBool()
    data.wasJobControlled = net.ReadBool()
    data.allowOwnership = net.ReadBool()
    data.buyable = net.ReadBool()
    data.adminOnly = net.ReadBool()
    data.propertyGroupName = net.ReadString()
    data.propertyCustomPrice = net.ReadInt(32)
    return data
end


