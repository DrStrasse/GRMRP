--[[
================================================================================
VEIN Property Management System - Property Sale Effect
================================================================================
Visual effect for property sale status changes made via toolgun.
================================================================================
]]--

EFFECT.Mat = Material("effects/select_ring")

function EFFECT:Init(data)
    local pos = data:GetOrigin()
    local normal = data:GetNormal()
    local magnitude = data:GetMagnitude() -- 1 = for sale, 0 = removed from sale
    local scale = data:GetScale()
    
    self.Position = pos
    self.Normal = normal
    self.LifeTime = 2.0
    self.DieTime = CurTime() + self.LifeTime
    self.Size = scale * 50
    self.ForSale = magnitude == 1
    
    -- Create particles
    local emitter = ParticleEmitter(pos)
    if not emitter then return end
    
    -- Color based on sale status
    local color = self.ForSale and Color(46, 204, 113) or Color(149, 165, 166)
    
    -- Ring particles
    for i = 1, 16 do
        local particle = emitter:Add("effects/yellowflare", pos)
        if particle then
            local angle = (i / 16) * math.pi * 2
            local radius = self.Size
            
            particle:SetPos(pos + Vector(math.cos(angle) * radius, math.sin(angle) * radius, 0))
            particle:SetVelocity(Vector(math.cos(angle) * 50, math.sin(angle) * 50, math.Rand(10, 30)))
            particle:SetDieTime(1.5)
            particle:SetStartAlpha(255)
            particle:SetEndAlpha(0)
            particle:SetStartSize(8)
            particle:SetEndSize(0)
            particle:SetColor(color.r, color.g, color.b)
            particle:SetGravity(Vector(0, 0, -100))
        end
    end
    
    -- Center burst
    for i = 1, 8 do
        local particle = emitter:Add("effects/yellowflare", pos)
        if particle then
            particle:SetPos(pos)
            particle:SetVelocity(VectorRand() * 80)
            particle:SetDieTime(1.0)
            particle:SetStartAlpha(255)
            particle:SetEndAlpha(0)
            particle:SetStartSize(12)
            particle:SetEndSize(2)
            particle:SetColor(color.r, color.g, color.b)
            particle:SetGravity(Vector(0, 0, -50))
        end
    end
    
    emitter:Finish()
    
    -- Sound
    local soundFile = self.ForSale and "buttons/button14.wav" or "buttons/button15.wav"
    sound.Play(soundFile, pos, 60, self.ForSale and 120 or 80)
end

function EFFECT:Think()
    return CurTime() < self.DieTime
end

function EFFECT:Render()
    local alpha = math.Clamp((self.DieTime - CurTime()) / self.LifeTime, 0, 1)
    local size = self.Size * (1 - alpha) + self.Size * 0.5
    
    if alpha <= 0 then return end
    
    -- Ring effect
    render.SetMaterial(self.Mat)
    
    local color = self.ForSale and Color(46, 204, 113, 255 * alpha) or Color(149, 165, 166, 255 * alpha)
    
    render.DrawSprite(self.Position, size, size, color)
    
    -- Pulsing inner ring
    local pulseAlpha = math.sin(CurTime() * 8) * 0.5 + 0.5
    local innerColor = Color(color.r, color.g, color.b, 128 * alpha * pulseAlpha)
    render.DrawSprite(self.Position, size * 0.6, size * 0.6, innerColor)
end