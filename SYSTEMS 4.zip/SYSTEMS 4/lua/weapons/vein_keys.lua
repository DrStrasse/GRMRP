--[[
================================================================================
VEIN Keys Weapon - Required for all door interactions
================================================================================
]]--

-- Network string for lock/unlock animation
if SERVER then
    util.AddNetworkString("VEIN_LockAnimation")
end

-- Initialize config (shared)
VEIN = VEIN or {}
local VEIN = VEIN
VEIN.Config = VEIN.Config or {}
local SMALL_CIRCLE = "\226\128\162"

local function HasTeamAccess(controlJobs, teamId)
    if not istable(controlJobs) then return false end
    for _, jobTeam in ipairs(controlJobs) do
        if tonumber(jobTeam) == teamId then
            return true
        end
    end
    return false
end

local function DoorAccessHas(doorAccess, ply)
    if not istable(doorAccess) or not IsValid(ply) then return false end
    local nick = ply:Nick()
    if doorAccess[nick] then return true end
    if ply:IsBot() and doorAccess["BOT_" .. nick] then return true end
    local sid = ply:SteamID()
    if sid and sid ~= "" and doorAccess[sid] then return true end
    local sid64 = ply:SteamID64()
    if sid64 and sid64 ~= "" and doorAccess[sid64] then return true end
    for _, v in ipairs(doorAccess) do
        if v == nick or v == sid or v == sid64 then
            return true
        end
    end
    return false
end

-- Function to get current money system setting (always fresh)
local function UseCustomMoney()
    local cv = GetConVar("vein_use_custom_money")
    if cv then
        return cv:GetBool()
    end
    -- If ConVar doesn't exist yet, check for DarkRP
    return not DarkRP -- Use custom money if no DarkRP
end

-- Get money system setting from ConVar
local vein_use_custom_money = GetConVar("vein_use_custom_money")
if vein_use_custom_money then
    VEIN.Config.UseCustomMoney = vein_use_custom_money:GetBool()
    
    -- Add callback to update when ConVar changes (only once)
    if not VEIN.MoneySystemCallbackAdded then
        VEIN.MoneySystemCallbackAdded = true
        cvars.AddChangeCallback("vein_use_custom_money", function(name, old, new)
            VEIN.Config.UseCustomMoney = tobool(new)
        end)
    end
else
    VEIN.Config.UseCustomMoney = UseCustomMoney() -- Default fallback
end

SWEP.PrintName = "Keys"
-- Use custom icon from addon materials folder for Q menu
SWEP.IconOverride = "VGUI/entities/vein_keys.png"
-- Use a built-in icon for the Q menu to avoid missing texture
SWEP.Author = "VEIN"
SWEP.Instructions = "Right-click doors to buy or manage them"

-- SWEP Icon
SWEP.Spawnable = true
SWEP.AdminOnly = false
SWEP.Category = "VEIN"
-- Force Q menu icon to use PNG


if CLIENT then
end

-- Inventory/Hotbar Icon - SLOT 2 (second weapon slot)
SWEP.Slot = 1  -- 0=slot1, 1=slot2, 2=slot3
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.BounceWeaponIcon = false

-- GUI visibility toggle (client-side only)
if CLIENT then
    VEIN.DoorGUIVisible = VEIN.DoorGUIVisible == nil and true or VEIN.DoorGUIVisible
    SWEP.ShowGUI = false

    VEIN.DoorSystem = VEIN.DoorSystem or {}
    VEIN.DoorSystem.LinkedDoorCache = VEIN.DoorSystem.LinkedDoorCache or {}
    VEIN.DoorSystem.PropertyDoorCache = VEIN.DoorSystem.PropertyDoorCache or {}
    VEIN.DoorSystem.PropertyDoorHighlights = VEIN.DoorSystem.PropertyDoorHighlights or {}

    local function getLinkedGroupDoorsCached(groupId)
        if not groupId or groupId <= 0 then return {} end
        local cache = VEIN.DoorSystem.LinkedDoorCache[groupId]
        if cache and cache.expires > CurTime() then
            return cache.doors
        end
        local doors = {}
        for _, ent in ipairs(ents.GetAll()) do
            if IsValid(ent)
                and ent:GetNWBool("VEIN_IsVEINDoor", false)
                and ent:GetNWInt("VEIN_LinkGroup", 0) == groupId then
                table.insert(doors, ent)
            end
        end
        VEIN.DoorSystem.LinkedDoorCache[groupId] = {doors = doors, expires = CurTime() + 1}
        return doors
    end

    function VEIN.DoorSystem.GetLinkedGroupDoorsClient(door)
        if not IsValid(door) then return {} end
        local groupId = door:GetNWInt("VEIN_LinkGroup", 0)
        if groupId > 0 then
            return getLinkedGroupDoorsCached(groupId)
        end
        local linked = door:GetNWEntity("VEIN_LinkedDoor", NULL)
        if IsValid(linked) then
            return {door, linked}
        end
        return {door}
    end

    local function getPropertyGroupDoorsCached(groupId)
        if not groupId or groupId <= 0 then return {} end
        local cache = VEIN.DoorSystem.PropertyDoorCache[groupId]
        if cache and cache.expires > CurTime() then
            return cache.doors
        end
        local doors = {}
        for _, ent in ipairs(ents.GetAll()) do
            if IsValid(ent)
                and ent:GetNWBool("VEIN_IsVEINDoor", false)
                and ent:GetNWInt("VEIN_PropertyGroup", 0) == groupId then
                table.insert(doors, ent)
            end
        end
        VEIN.DoorSystem.PropertyDoorCache[groupId] = {doors = doors, expires = CurTime() + 1}
        return doors
    end

    function VEIN.DoorSystem.GetPropertyGroupDoorsClient(door)
        if not IsValid(door) then return {} end
        local groupId = door:GetNWInt("VEIN_PropertyGroup", 0)
        local groupName = door:GetNWString("VEIN_PropertyGroupName", "")
        if groupId > 0 and groupName ~= "" then
            return getPropertyGroupDoorsCached(groupId)
        end
        return {door}
    end

    function VEIN.DoorSystem.HighlightPropertyDoors(door, duration)
        if not IsValid(door) then return false end
        local groupId = door:GetNWInt("VEIN_PropertyGroup", 0)
        local groupName = door:GetNWString("VEIN_PropertyGroupName", "")
        if groupId <= 0 or groupName == "" then return false end
        local doors = VEIN.DoorSystem.GetPropertyGroupDoorsClient(door)
        if #doors <= 1 then return false end

        VEIN.DoorSystem.PropertyDoorHighlights[groupId] = {
            doors = doors,
            start = CurTime(),
            finish = CurTime() + (duration or 3)
        }
        return true
    end

    function VEIN.DoorSystem.GetLinkedLockProgress(door)
        if not IsValid(door) then return -1, "Processing" end
        local progress = door:GetNWFloat("VEIN_LockProgress", -1)
        local actionText = door:GetNWString("VEIN_LockAction", "Processing")
        if progress >= 0 then return progress, actionText end
        
        local groupDoors = VEIN.DoorSystem.GetLinkedGroupDoorsClient(door)
        for _, linkedDoor in ipairs(groupDoors) do
            if IsValid(linkedDoor) and linkedDoor ~= door then
                local linkedProgress = linkedDoor:GetNWFloat("VEIN_LockProgress", -1)
                if linkedProgress >= 0 then
                    return linkedProgress, linkedDoor:GetNWString("VEIN_LockAction", "Processing")
                end
            end
        end
        
        return -1, actionText
    end

    hook.Add("PreDrawHalos", "VEIN_PropertyDoorHighlight", function()
        if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.PropertyDoorHighlights then
            local now = CurTime()
            for key, data in pairs(VEIN.DoorSystem.PropertyDoorHighlights) do
                if not data or now >= data.finish then
                    VEIN.DoorSystem.PropertyDoorHighlights[key] = nil
                else
                    local validDoors = {}
                    for _, ent in ipairs(data.doors or {}) do
                        if IsValid(ent) then
                            table.insert(validDoors, ent)
                        end
                    end
                    if #validDoors == 0 then
                        VEIN.DoorSystem.PropertyDoorHighlights[key] = nil
                    else
                        local t = (now - data.start) / (data.finish - data.start)
                        local pulse = 0.5 + 0.5 * math.sin(now * 6)
                        local alpha = math.Clamp((1 - t) * pulse, 0, 1)
                        local color = Color(60, 255, 120, math.floor(200 * alpha))
                        halo.Add(validDoors, color, 2, 2, 2, true, true)
                    end
                end
            end
        end
    end)
    
    -- Create pixel-perfect fonts for the radial menu
    surface.CreateFont("VEIN_MenuFont", {
        font = "Tahoma",
        size = 14,
        weight = 500,
        antialias = false -- Disable antialiasing for pixel-perfect rendering
    })
    
    surface.CreateFont("VEIN_MenuFontSmall", {
        font = "Tahoma", 
        size = 12,
        weight = 400,
        antialias = false -- Disable antialiasing for pixel-perfect rendering
    })
end

-- Note: Main SWEP properties are defined above, including icon

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.Weight = 1
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

-- Completely disable viewmodel and animations (like DarkRP keys)
SWEP.ViewModel = ""
SWEP.WorldModel = ""
SWEP.UseHands = false
SWEP.ViewModelFOV = 0
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true

-- Initialize hold-to-kick variables and weapon
function SWEP:Initialize()
    self:SetHoldType("normal")
    self.HoldingR = false
    self.KickStartTime = 0
    self.LastBangTime = 0
    
    -- Set weapon select icon for inventory/hotbar
    if CLIENT then
        -- Clear any cached materials and reload
        local iconPath = "VGUI/entities/vein_door_keys"
        local materialPath = "materials/" .. iconPath .. ".png"
        
        -- Force clear material cache for this specific material
        if Material then
            local testMat = Material(iconPath)
            if testMat then testMat:Recompute() end
        end
        
        -- Use default WeaponSelector icon (no custom assignment)
    end
    
    -- UI fade animation variables
    if CLIENT then
        self.UIAlpha = 0
        self.LastDoorCheck = 0
        -- Sync with global GUI visibility
        self.ShowGUI = VEIN.DoorGUIVisible or false
        self.LookingAtDoor = false
    end
end

-- Reset UI state when weapon is deployed
function SWEP:Deploy()
    if CLIENT then
        self.UIAlpha = 0
        self.LastDoorInfo = nil
    end
    
    -- Weapon is immediately usable (no animation, no delay)
    return true
end

-- Reset UI state when weapon is holstered
function SWEP:Holster()
    if CLIENT then
        self.UIAlpha = 0
        self.LastDoorInfo = nil
    end
    return true
end

function SWEP:Reload()
    if CLIENT then return end
    
    local ply = self:GetOwner()
    local trace = ply:GetEyeTrace()
    local door = trace.Entity
    
    -- Check if it's a valid door
    if not IsValid(door) then return end
    local class = door:GetClass()
    if not (class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating") then
        return
    end
    
    -- Check distance to the actual door surface (where player is looking), not door center
    if trace.HitPos:Distance(ply:GetShootPos()) > 100 then
        return
    end
    
    -- Initialize if not set
    if not self.LastBangTime then
        self.LastBangTime = 0
        self.LastKickSound = 0
        self.LastKickComplete = 0
    end
    
    -- Prevent actions shortly after a kick completes
    if self.LastKickComplete and CurTime() - self.LastKickComplete < 2.0 then
        return
    end
    
    -- Prevent R spam by checking cooldown
    if CurTime() - self.LastBangTime < 0.5 then
        return
    end
    
    -- Start R hold immediately (no bang/knock first)
    if not self.HoldingR then
        self.HoldingR = true
        self.RHoldStartTime = CurTime()
        self.ShowingMenu = false
        self.MenuSelected = false
        self.ReleasedEarly = false -- Track if R was released early
        self.LastBangTime = CurTime() -- Set cooldown to prevent spam
    end
end

-- Handle R key release and hold-to-kick logic
function SWEP:Think()
    -- Handle client-side middle mouse for GUI toggle
    if CLIENT then
        -- Cooldown to prevent rapid toggling
        if not self.NextGUIToggle then self.NextGUIToggle = 0 end
        if not self.LastMiddleMouseState then self.LastMiddleMouseState = false end
        
        local middleMouseDown = input.IsMouseDown(MOUSE_MIDDLE)
        
        -- Detect rising edge (button just pressed)
        if middleMouseDown and not self.LastMiddleMouseState and CurTime() > self.NextGUIToggle then
            -- Toggle global GUI visibility
            VEIN.DoorGUIVisible = not VEIN.DoorGUIVisible
            self.ShowGUI = VEIN.DoorGUIVisible -- Keep weapon sync for compatibility
            self.NextGUIToggle = CurTime() + 0.2 -- 200ms cooldown (reduced from 300ms)
            
            local status = VEIN.DoorGUIVisible and "ON" or "OFF"
            VEIN.Chat(LocalPlayer(), "Door GUI visibility: " .. status)
            surface.PlaySound("buttons/button15.wav")
        end
        
        self.LastMiddleMouseState = middleMouseDown
        return 
    end
    
    local ply = self:GetOwner()
    
    -- Check if player is holding R key for menu/kick system
    if self.HoldingR then
        local trace = ply:GetEyeTrace()
        local door = trace.Entity
        
        local holdTime = CurTime() - self.RHoldStartTime
        
        -- Check if R was released
        if not ply:KeyDown(IN_RELOAD) then
            -- If released within 0.5 seconds, it was a quick tap - play bang/knock
            if holdTime < 0.5 and not self.ReleasedEarly then
                self.ReleasedEarly = true
                self.LastBangTime = CurTime() -- Set cooldown to prevent spam
                
                -- Play bang/knock sound
                local bangSounds = {
                    "physics/wood/wood_crate_impact_hard2.wav", 
                    "physics/wood/wood_crate_impact_hard3.wav"
                }
                
                local sound = table.Random(bangSounds)
                door:EmitSound(sound, 75, math.random(80, 120))
            end
            
            self:StopRHold(door)
            return
        end
        
        -- Stop R hold if conditions change (but not for R release, handled above)
        -- Check distance to trace hit position instead of door center (for large doors/gates)
        local newTrace = ply:GetEyeTrace()
        if not IsValid(door) or 
           not door:GetClass():match("door") or
           not IsValid(newTrace.Entity) or newTrace.Entity ~= door or
           newTrace.HitPos:Distance(ply:GetShootPos()) > 100 then
            
            self:StopRHold(door)
            return
        end
        
        local isLocked = door:GetNWBool("VEIN_Locked", false)
        
        -- OLD MENU SYSTEM DISABLED - Using client-side animation system instead
        -- Show menu after holding R long enough (only for locked doors)
        -- if holdTime >= 0.5 and isLocked and not self.ShowingMenu and not self.ReleasedEarly then
        --     self.ShowingMenu = true
        -- end
        
        -- If we're in kicking mode (menu was used to select kick)
        if self.KickingDoor then
            -- Play kicking sounds and effects
            if not self.LastKickSound then self.LastKickSound = 0 end
            
            if CurTime() - self.LastKickSound >= 1.3 then
                -- Get custom kick sound and pitch from door
                local kickSound = door:GetNWString("VEIN_KickSound", "physics/wood/wood_plank_break1.wav")
                local kickPitch = door:GetNWInt("VEIN_KickPitch", 100)
                
                -- Add random variation to pitch (±10%)
                local pitchVariation = kickPitch + math.random(-10, 10)
                door:EmitSound(kickSound, 85, pitchVariation)
                self.LastKickSound = CurTime()
                
                -- Add lighter screen shake for the kicker
                if CLIENT then
                    util.ScreenShake(ply:GetPos(), 1.5, 5, 0.2, 80)
                else
                    util.ScreenShake(ply:GetPos(), 1.5, 5, 0.2, 80)
                end
                
                -- Create sparks particles at the exact center of the door
                local effectdata = EffectData()
                local doorCenter = door:GetPos() + door:OBBCenter()
                effectdata:SetOrigin(doorCenter)
                effectdata:SetNormal(door:GetForward() * -1)
                effectdata:SetMagnitude(5)
                effectdata:SetScale(1)
                effectdata:SetRadius(5)
                util.Effect("MetalSpark", effectdata)
            end
            
            -- Check if kick time reached (based on door material)
            local kickTime = door:GetNWInt("VEIN_KickTime", 25) -- Default to 25 seconds if not set
            if kickTime == -1 then
                -- Cannot be kicked - Heavy Metal or Steel doors
                VEIN.Chat(ply, "This door is too reinforced to kick down!")
                self:StopRHold(door)
                return
            end
            
            if CurTime() - self.KickStartTime >= kickTime then
                self:ExecuteKick(door, ply)
                return -- Exit to prevent repeated calls
            end
        end
    end
end

-- Stop the R hold process (menu or kicking)
function SWEP:StopRHold(door)
    self.HoldingR = false
    self.ShowingMenu = false -- Keep this false (old system disabled)
    self.MenuSelected = false
    self.KickingDoor = false
    self.SentKickMessage = false
    self.ReleasedEarly = false
    if IsValid(door) then
        door:SetNWBool("VEIN_BeingKicked", false)
        door:SetNWFloat("VEIN_KickStartTime", 0)
        door:SetNWBool("VEIN_LockedKick", false)
    end
end

-- Start the kicking process (called from menu selection)
function SWEP:StartKicking(door, ply)
    if not IsValid(door) then return end
    
    -- Check if door kicking is globally disabled
    local kickingEnabled = GetConVar("vein_enable_door_kicking")
    if kickingEnabled and kickingEnabled:GetBool() == false then
        VEIN.Chat(ply, "Door kicking is currently disabled on this server.")
        return
    end
    
    local isLocked = door:GetNWBool("VEIN_Locked", false)
    
    -- Only allow kicking locked doors
    if not isLocked then return end
    
    self.KickingDoor = true
    self.KickStartTime = CurTime()
    self.LastKickSound = 0
    door:SetNWBool("VEIN_BeingKicked", true)
    door:SetNWFloat("VEIN_KickStartTime", CurTime())
    door:SetNWBool("VEIN_LockedKick", true)
end

-- Execute the door kick
function SWEP:ExecuteKick(door, ply)
    -- Get custom break sound and pitch from door
    local breakSound = door:GetNWString("VEIN_BreakSound", "physics/wood/wood_plank_break1.wav")
    local breakPitch = door:GetNWInt("VEIN_BreakPitch", 100)
    
    -- Add random variation to pitch (±10%)
    local pitchVariation = breakPitch + math.random(-10, 10)
    door:EmitSound(breakSound, 100, pitchVariation)
    
    -- Unlock and open the door
    door:SetNWBool("VEIN_Locked", false)
    door:Fire("Unlock")
    door:Fire("Open")
    
    -- Mark door as broken (needs repair before it can be locked again)
    door:SetNWBool("VEIN_Broken", true)
    
    -- Reset kick state immediately
    door:SetNWBool("VEIN_BeingKicked", false)
    door:SetNWFloat("VEIN_KickStartTime", 0)
    door:SetNWBool("VEIN_LockedKick", false)
    
    -- Reset weapon kick state
    self.KickingDoor = false
    self.KickStartTime = nil
    self.LastKickComplete = CurTime()
    
    -- Messages removed for cleaner experience
end

function SWEP:PrimaryAttack()
    if CLIENT then
        if not IsFirstTimePredicted() then return end
        local ply = LocalPlayer()
        if not IsValid(ply) then return end
        local trace = ply:GetEyeTrace()
        local door = trace.Entity
        
        if IsValid(door) and trace.HitPos and trace.HitPos:Distance(ply:GetShootPos()) <= 100 then
            local class = door:GetClass()
            if class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating" then
                if door:GetNWBool("VEIN_IsVEINDoor", false) then
                    local ownerName = door:GetNWString("VEIN_OwnerName", "")
                    local isBuyable = door:GetNWBool("VEIN_Buyable", false)
                    local propertyGroupId = door:GetNWInt("VEIN_PropertyGroup", 0)
                    local propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", "")
                    local propertyCount = door:GetNWInt("VEIN_PropertyCount", 1)
                    
                    if ownerName == "" and isBuyable and propertyGroupId > 0 and propertyGroupName ~= "" and propertyCount > 1 then
                        if not self.NextPropertyHighlight or CurTime() >= self.NextPropertyHighlight then
                            if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.HighlightPropertyDoors then
                                if VEIN.DoorSystem.HighlightPropertyDoors(door, 3) then
                                    self.NextPropertyHighlight = CurTime() + 3
                                end
                            end
                        end
                    end
                end
            end
        end
        return
    end
    
    local ply = self:GetOwner()
    local trace = ply:GetEyeTrace()
    local door = trace.Entity
    
    -- Check if it's a valid door
    if not IsValid(door) then return end
    local class = door:GetClass()
    if not (class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating") then
        return
    end
    
    -- Check distance to the actual door surface (where player is looking), not door center
    -- This allows interaction with large gates/doors regardless of where the center is
    if trace.HitPos:Distance(ply:GetShootPos()) > 100 then
        return
    end
    
    -- Check if player owns this door or has access
    local owner = door:GetNWString("VEIN_Owner", "")
    local isAdminOnly = door:GetNWBool("VEIN_AdminOnly", false)
    local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
    
    -- Allow admins to lock/unlock admin-only (static) doors
    -- Allow job players to lock/unlock job-controlled doors
    if owner == "" and not isAdminOnly and not isJobControlled then
        return
    end
    
    local hasAccess = false
    
    -- Admin-only doors: Only admins can access
    if isAdminOnly and owner == "" then
        hasAccess = ply:IsAdmin()
    -- Job-controlled doors: Check job access (even if owner is set somehow)
    elseif isJobControlled then
        local controlJobs = util.JSONToTable(door:GetNWString("VEIN_ControlJobs", "[]")) or {}
        hasAccess = HasTeamAccess(controlJobs, ply:Team())
    -- Owned doors: Use new access level system
    elseif owner ~= "" then
        -- Use new access level permission check
        if VEIN and VEIN.AccessLevels and VEIN.AccessLevels.CanLockUnlock then
            hasAccess = VEIN.AccessLevels.CanLockUnlock(door, ply:Nick())
        else
            -- Fallback to old system if access levels not loaded
            if owner == ply:Nick() then
                hasAccess = true
            else
                local doorAccess = VEIN.DoorSystem.DoorAccess[door:EntIndex()] or {}
                hasAccess = DoorAccessHas(doorAccess, ply)
            end
        end
    end
    
    if not hasAccess then
        return
    end
    
    -- Get lock time from ConVar
    local lockTime = GetConVar("vein_lock_time"):GetFloat()
    
    -- Helper function to sync linked door's lock state
    local function SyncLinkedDoor(door, newLockState)
        local linkedDoors = {}
        if VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedDoors then
            linkedDoors = VEIN.DoorSystem.GetLinkedDoors(door)
        else
            local legacy = door:GetNWEntity("VEIN_LinkedDoor", NULL)
            if IsValid(legacy) then
                linkedDoors = {legacy}
            end
        end
        
        for _, linkedDoor in ipairs(linkedDoors) do
            if IsValid(linkedDoor) and linkedDoor:GetNWBool("VEIN_IsVEINDoor", false) then
                linkedDoor:SetNWBool("VEIN_Locked", newLockState)
                
                if newLockState then
                    linkedDoor:Fire("Lock")
                    local lockSound = linkedDoor:GetNWString("VEIN_LockSound", "doors/door_latch3.wav")
                    local lockPitch = linkedDoor:GetNWInt("VEIN_LockPitch", 100)
                    linkedDoor:EmitSound(lockSound, 75, lockPitch)
                else
                    linkedDoor:Fire("Unlock")
                    local unlockSound = linkedDoor:GetNWString("VEIN_UnlockSound", "doors/door_latch1.wav")
                    local unlockPitch = linkedDoor:GetNWInt("VEIN_UnlockPitch", 100)
                    linkedDoor:EmitSound(unlockSound, 75, unlockPitch)
                end
            end
        end
    end

    local function ClearAutoLockOnClose(door)
        local timerName = "VEIN_AutoLockOnClose_" .. door:EntIndex()
        if timer.Exists(timerName) then
            timer.Remove(timerName)
        end
        door.VEIN_OpenSince = nil
        door:SetNWBool("VEIN_AutoLockOnClose", false)
    end

    local function StartAutoLockOnClose(door)
        if not IsValid(door) then return end
        local autoCloseDelay = 5
        local timerName = "VEIN_AutoLockOnClose_" .. door:EntIndex()

        if timer.Exists(timerName) then
            timer.Remove(timerName)
        end

        door.VEIN_WasOpenedAfterUnlock = false
        door.VEIN_OpenSince = nil
        door:SetNWBool("VEIN_AutoLockOnClose", true)

        timer.Create(timerName, 0.2, 0, function()
            if not IsValid(door) then
                ClearAutoLockOnClose(door)
                return
            end
            if door:GetNWBool("VEIN_Locked", false) then
                ClearAutoLockOnClose(door)
                return
            end
            if door:GetNWBool("VEIN_Broken", false) then
                ClearAutoLockOnClose(door)
                return
            end

            local doorOpen = door:GetInternalVariable("m_toggle_state")
            if doorOpen and doorOpen ~= 0 then
                door.VEIN_WasOpenedAfterUnlock = true
                if not door.VEIN_OpenSince then
                    door.VEIN_OpenSince = CurTime()
                elseif CurTime() - door.VEIN_OpenSince >= autoCloseDelay then
                    door:Fire("Close")
                end
                return
            end
            door.VEIN_OpenSince = nil

            if door.VEIN_WasOpenedAfterUnlock then
                door:SetNWBool("VEIN_Locked", true)
                door:Fire("Lock")
                SyncLinkedDoor(door, true)
                local lockSound = door:GetNWString("VEIN_LockSound", "doors/door_latch3.wav")
                local lockPitch = door:GetNWInt("VEIN_LockPitch", 100)
                door:EmitSound(lockSound, 75, lockPitch)
                ClearAutoLockOnClose(door)
                hook.Call("VEIN_OnDoorModified", nil, door)
            end
        end)
    end
    
    -- Static doors (admin-only) are instant for admins
    local instantLock = (lockTime <= 0) or (isAdminOnly and ply:IsAdmin())
    
    -- Prevent spam clicking
    if self.NextLockToggle and self.NextLockToggle > CurTime() then
        return
    end
    self.NextLockToggle = CurTime() + (instantLock and 0.5 or math.max(lockTime, 0.5)) -- Cooldown based on lock time (minimum 0.5s)
    
    -- Get current lock state
    local isLocked = door:GetNWBool("VEIN_Locked", false)
    
    -- Check if door is broken before locking
    if not isLocked and door:GetNWBool("VEIN_Broken", false) then
        -- Don't allow locking broken doors
        VEIN.Chat(ply, "This door is damaged and needs repair before it can be locked!")
        return
    end
    
    -- If lock time is 0 or it's a static door with admin, instantly lock/unlock
    if instantLock then
        -- Play gear sound and animation (like DarkRP keys)
        ply:EmitSound("npc/metropolice/gear" .. math.floor(math.Rand(1,7)) .. ".wav", 75, 100)
        
        -- Send animation to all clients
        net.Start("VEIN_LockAnimation")
        net.WriteEntity(ply)
        net.Broadcast()
        
        -- Toggle the lock instantly
        local newLockState = not isLocked
        door:SetNWBool("VEIN_Locked", newLockState)
        
        -- Sync linked door
        SyncLinkedDoor(door, newLockState)
        
        -- Trigger hologram display for job-controlled doors AND admin-only doors
        if (isJobControlled and owner == "") or (isAdminOnly and owner == "") then
            net.Start("VEIN_ShowJobDoorHologram")
            net.WriteEntity(door)
            net.Send(ply)
        end
        
        if newLockState then
            door:Fire("Lock")
            -- Use custom lock sound and pitch from door
            local lockSound = door:GetNWString("VEIN_LockSound", "doors/door_latch3.wav")
            local lockPitch = door:GetNWInt("VEIN_LockPitch", 100)
            door:EmitSound(lockSound, 75, lockPitch)
            
            -- Cancel auto-lock-on-close if door is manually locked
            ClearAutoLockOnClose(door)
            local legacyTimer = "VEIN_AutoLock_" .. door:EntIndex()
            if timer.Exists(legacyTimer) then
                timer.Remove(legacyTimer)
            end
            if VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedDoors then
                for _, linkedDoor in ipairs(VEIN.DoorSystem.GetLinkedDoors(door)) do
                    ClearAutoLockOnClose(linkedDoor)
                    local linkedLegacy = "VEIN_AutoLock_" .. linkedDoor:EntIndex()
                    if timer.Exists(linkedLegacy) then
                        timer.Remove(linkedLegacy)
                    end
                end
            end
        else
            door:Fire("Unlock")
            -- Use custom unlock sound and pitch from door
            local unlockSound = door:GetNWString("VEIN_UnlockSound", "doors/door_latch1.wav")
            local unlockPitch = door:GetNWInt("VEIN_UnlockPitch", 100)
            door:EmitSound(unlockSound, 75, unlockPitch)

            -- Auto-lock job-controlled doors AND admin-only doors when closed
            if (isJobControlled and owner == "") or (isAdminOnly and owner == "") then
                StartAutoLockOnClose(door)
                local legacyTimer = "VEIN_AutoLock_" .. door:EntIndex()
                if timer.Exists(legacyTimer) then
                    timer.Remove(legacyTimer)
                end
                if VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedDoors then
                    for _, linkedDoor in ipairs(VEIN.DoorSystem.GetLinkedDoors(door)) do
                        StartAutoLockOnClose(linkedDoor)
                        local linkedLegacy = "VEIN_AutoLock_" .. linkedDoor:EntIndex()
                        if timer.Exists(linkedLegacy) then
                            timer.Remove(linkedLegacy)
                        end
                    end
                end
            end
        end
        
        return
    end
    
    -- Start realistic lock/unlock process with progress bar
    local actionText = isLocked and "Unlocking" or "Locking"
    
    -- Set lock progress for visual feedback
    door:SetNWFloat("VEIN_LockProgress", 0)
    door:SetNWString("VEIN_LockAction", actionText)
    door:SetNWFloat("VEIN_LockStartTime", CurTime())
    
    -- Store player's starting position for movement detection
    local startPos = ply:GetPos()
    
    -- Play gear sound and animation (like DarkRP keys)
    ply:EmitSound("npc/metropolice/gear" .. math.floor(math.Rand(1,7)) .. ".wav", 75, 100)
    
    -- Send animation to all clients
    net.Start("VEIN_LockAnimation")
    net.WriteEntity(ply)
    net.Broadcast()
    
    -- Progress timer (updates every 0.1 seconds for smooth progress bar)
    local progressTimer = "VEIN_LockProgress_" .. door:EntIndex()
    local completionTimer = "VEIN_LockComplete_" .. door:EntIndex()
    local cancelled = false
    
    local tickCount = math.ceil(lockTime / 0.1)
    timer.Create(progressTimer, 0.1, tickCount, function()
        if IsValid(door) and IsValid(ply) and not cancelled then
            -- Check if player moved too far away
            local currentPos = ply:GetPos()
            local distance = startPos:Distance(currentPos)
            
            if distance > 50 then -- If player moved more than 50 units
                -- Cancel the locking process
                cancelled = true
                door:SetNWFloat("VEIN_LockProgress", -1)
                door:SetNWString("VEIN_LockAction", "")
                timer.Remove(progressTimer)
                timer.Remove(completionTimer)
                return
            end
            
            local elapsed = CurTime() - door:GetNWFloat("VEIN_LockStartTime", 0)
            local progress = math.Clamp(elapsed / lockTime, 0, 1)
            door:SetNWFloat("VEIN_LockProgress", progress)
        end
    end)
    
    -- Completion timer
    timer.Create(completionTimer, lockTime, 1, function()
        if IsValid(door) and IsValid(ply) and not cancelled then
            -- Check one final time if player is still close enough
            local currentPos = ply:GetPos()
            local finalDistance = startPos:Distance(currentPos)
            
            if finalDistance > 50 then
                -- Cancel at the last second if player moved
                cancelled = true
                door:SetNWFloat("VEIN_LockProgress", -1)
                door:SetNWString("VEIN_LockAction", "")
                timer.Remove(progressTimer)
                return
            end
            
            -- Clean up progress
            door:SetNWFloat("VEIN_LockProgress", -1) -- -1 means no progress
            door:SetNWString("VEIN_LockAction", "")
            timer.Remove(progressTimer)
            
            -- Check if door is broken before locking
            if not isLocked and door:GetNWBool("VEIN_Broken", false) then
                -- Don't allow locking broken doors
                VEIN.Chat(ply, "This door is damaged and needs repair before it can be locked!")
                return
            end
            
            -- Toggle the lock
            local newLockState = not isLocked
            door:SetNWBool("VEIN_Locked", newLockState)
            
            -- Sync linked door
            SyncLinkedDoor(door, newLockState)
            
            -- Trigger hologram display for job-controlled doors AND admin-only doors
            local jobControlled = door:GetNWBool("VEIN_JobControlled", false)
            local adminOnly = door:GetNWBool("VEIN_AdminOnly", false)
            local doorOwner = door:GetNWString("VEIN_Owner", "")
            if (jobControlled and doorOwner == "") or (adminOnly and doorOwner == "") then
                net.Start("VEIN_ShowJobDoorHologram")
                net.WriteEntity(door)
                net.Send(ply)
            end
            
            if newLockState then
                door:Fire("Lock")
                -- Use custom lock sound and pitch from door
                local lockSound = door:GetNWString("VEIN_LockSound", "doors/door_latch3.wav")
                local lockPitch = door:GetNWInt("VEIN_LockPitch", 100)
                door:EmitSound(lockSound, 75, lockPitch)
                
                -- Cancel auto-lock-on-close if door is manually locked
                ClearAutoLockOnClose(door)
                local legacyTimer = "VEIN_AutoLock_" .. door:EntIndex()
                if timer.Exists(legacyTimer) then
                    timer.Remove(legacyTimer)
                end
            else
                door:Fire("Unlock")
                -- Use custom unlock sound and pitch from door
                local unlockSound = door:GetNWString("VEIN_UnlockSound", "doors/door_latch1.wav")
                local unlockPitch = door:GetNWInt("VEIN_UnlockPitch", 100)
                door:EmitSound(unlockSound, 75, unlockPitch)
                
                -- Auto-lock job-controlled and admin-only doors when closed
                local jobControlled = door:GetNWBool("VEIN_JobControlled", false)
                local adminOnly = door:GetNWBool("VEIN_AdminOnly", false)
                local doorOwner = door:GetNWString("VEIN_Owner", "")
                if (jobControlled and doorOwner == "") or (adminOnly and doorOwner == "") then
                    StartAutoLockOnClose(door)
                    local legacyTimer = "VEIN_AutoLock_" .. door:EntIndex()
                    if timer.Exists(legacyTimer) then
                        timer.Remove(legacyTimer)
                    end
                end
            end
        end
    end)
end

function SWEP:SecondaryAttack()
    if CLIENT then return end
    
    local ply = self:GetOwner()
    local trace = ply:GetEyeTrace()
    local door = trace.Entity
    
    -- Check if it's a valid door
    if not IsValid(door) then return end
    local class = door:GetClass()
    if not (class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating") then
        return
    end
    
    -- Check distance to the actual door surface (where player is looking), not door center
    if trace.HitPos:Distance(ply:GetShootPos()) > 100 then
        return
    end
    
    -- Handle door interaction
    VEIN.DoorSystem.HandleDoorInteraction(ply, door)
end

-- Draw persistent lock progress UI
function SWEP:DrawPersistentLockProgress(scrW, scrH)
    local ply = LocalPlayer()
    
    -- Find any door with active lock progress
    for _, door in pairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():match("door") then
            local lockProgress = door:GetNWFloat("VEIN_LockProgress", -1)
            local lockAction = door:GetNWString("VEIN_LockAction", "")
            local startTime = door:GetNWFloat("VEIN_LockStartTime", 0)
            
            if lockProgress >= 0 and lockAction ~= "" and startTime > 0 then
                -- Check if player is currently looking at this door OR its linked door
                local trace = ply:GetEyeTrace()
                -- Check distance to trace hit position (where player is looking), not door center
                local lookingAtDoor = IsValid(trace.Entity) and trace.Entity == door and trace.HitPos and trace.HitPos:Distance(ply:GetShootPos()) <= 100
                
                -- Also check if looking at any linked door in the group
                local lookingAtLinkedDoor = false
                local groupId = door:GetNWInt("VEIN_LinkGroup", 0)
                if groupId > 0 then
                    lookingAtLinkedDoor = IsValid(trace.Entity)
                        and trace.Entity:GetNWInt("VEIN_LinkGroup", 0) == groupId
                        and trace.HitPos
                        and trace.HitPos:Distance(ply:GetShootPos()) <= 100
                else
                    local linkedDoor = door:GetNWEntity("VEIN_LinkedDoor", NULL)
                    if IsValid(linkedDoor) then
                        lookingAtLinkedDoor = IsValid(trace.Entity) and trace.Entity == linkedDoor and trace.HitPos and trace.HitPos:Distance(ply:GetShootPos()) <= 100
                    end
                end
                
                -- Calculate alpha based on whether looking at door or linked door (fade when looking away)
                local targetAlpha = (lookingAtDoor or lookingAtLinkedDoor) and 0 or 255
                if not door.persistentAlpha then door.persistentAlpha = (lookingAtDoor or lookingAtLinkedDoor) and 0 or 255 end
                door.persistentAlpha = math.Approach(door.persistentAlpha, targetAlpha, FrameTime() * 255 * 3)
                
                -- Only show if we have some alpha and NOT looking at door or linked door
                if door.persistentAlpha > 5 and not lookingAtDoor and not lookingAtLinkedDoor then
                    local distance = ply:GetPos():Distance(door:GetPos())
                local maxDistance = 120 -- Maximum range for lock/unlock
                
                -- Calculate progress based on time - use actual lock time from ConVar
                local lockTimeConvar = GetConVar("vein_lock_time")
                local totalTime = lockTimeConvar and lockTimeConvar:GetFloat() or 1.0
                local elapsed = CurTime() - startTime
                local timeProgress = math.Clamp(elapsed / totalTime, 0, 1)
                
                -- Draw persistent progress panel following door position
                local panelW, panelH = 300, 135
                
                -- Calculate door position on screen (use simpler method that works with door rotation)
                local doorScreenPos
                -- Get the door's current world matrix to account for rotation
                local doorMatrix = door:GetWorldTransformMatrix()
                if doorMatrix then
                    -- Use the transformed center point
                    local localCenter = door:OBBCenter()
                    local worldCenter = doorMatrix * localCenter
                    doorScreenPos = worldCenter:ToScreen()
                else
                    -- Fallback to basic positioning
                    doorScreenPos = door:GetPos():ToScreen()
                end
                
                -- Position panel to the right of the door, but keep it on screen
                local panelX = math.max(10, math.min(scrW - panelW - 10, doorScreenPos.x + 50))
                local panelY = math.max(10, math.min(scrH - panelH - 10, doorScreenPos.y - panelH/2))
                
                -- Background
                surface.SetDrawColor(30, 30, 30, 220 * door.persistentAlpha / 255)
                surface.DrawRect(panelX, panelY, panelW, panelH)
                
                surface.SetDrawColor(80, 20, 20, 180 * door.persistentAlpha / 255)
                surface.DrawOutlinedRect(panelX, panelY, panelW, panelH, 2)
                
                -- Title
                local doorName = door:GetNWString("VEIN_DoorName", "Door")
                draw.SimpleText(lockAction .. " " .. doorName, "DermaDefaultBold", panelX + panelW/2, panelY + 15, Color(255, 200, 200, door.persistentAlpha), TEXT_ALIGN_CENTER)
                
                -- Door Type Display (with color coding)
                local doorType = door:GetNWString("VEIN_DoorType", "Residential")
                -- Use custom door type colors if available
                local typeColor = Color(200, 200, 200, door.persistentAlpha)
                if VEIN and VEIN.CustomDoors and VEIN.CustomDoors.Types then
                    for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                        if typeData.name == doorType then
                            typeColor = Color(typeData.color.r, typeData.color.g, typeData.color.b, door.persistentAlpha)
                            break
                        end
                    end
                else
                    local typeColors = {
                        ["Government"] = Color(255, 80, 80, door.persistentAlpha),
                        ["Emergency"] = Color(255, 165, 0, door.persistentAlpha),
                        ["Commercial"] = Color(80, 150, 255, door.persistentAlpha),
                        ["Industrial"] = Color(255, 200, 60, door.persistentAlpha),
                        ["Residential"] = Color(100, 255, 120, door.persistentAlpha)
                    }
                    typeColor = typeColors[doorType] or typeColor
                end
                draw.SimpleText(SMALL_CIRCLE .. " " .. doorType .. " Building", "DermaDefault", panelX + panelW/2, panelY + 33, typeColor, TEXT_ALIGN_CENTER)
                
                -- Progress bar
                local barW, barH = panelW - 40, 20
                local barX, barY = panelX + 20, panelY + 55
                
                surface.SetDrawColor(50, 50, 50, 200 * door.persistentAlpha / 255)
                surface.DrawRect(barX, barY, barW, barH)
                
                local progressWidth = barW * timeProgress
                local progressColor = lockAction == "Locking" and Color(255, 100, 100) or Color(100, 255, 100)
                surface.SetDrawColor(progressColor.r, progressColor.g, progressColor.b, 200 * door.persistentAlpha / 255)
                surface.DrawRect(barX, barY, progressWidth, barH)
                
                surface.SetDrawColor(255, 255, 255, 150 * door.persistentAlpha / 255)
                surface.DrawOutlinedRect(barX, barY, barW, barH)
                
                -- Distance/Range indicator
                local rangeY = panelY + 85
                draw.SimpleText("Range: " .. math.floor(distance) .. "/" .. maxDistance .. " units", "DermaDefault", panelX + 20, rangeY, Color(200, 200, 200, door.persistentAlpha), TEXT_ALIGN_LEFT)
                
                -- Range bar
                local rangeBarW, rangeBarH = panelW - 40, 8
                local rangeBarX, rangeBarY = panelX + 20, rangeY + 18
                
                surface.SetDrawColor(50, 50, 50, 180 * door.persistentAlpha / 255)
                surface.DrawRect(rangeBarX, rangeBarY, rangeBarW, rangeBarH)
                
                local distancePercent = math.Clamp(distance / maxDistance, 0, 1)
                local rangeWidth = rangeBarW * distancePercent
                
                -- Color coding: Green = close, Yellow = medium, Red = far/breaking
                local rangeColor
                if distancePercent < 0.7 then
                    rangeColor = Color(100, 255, 100) -- Green - safe
                elseif distancePercent < 0.9 then
                    rangeColor = Color(255, 200, 100) -- Yellow - warning
                else
                    rangeColor = Color(255, 100, 100) -- Red - danger
                end
                
                surface.SetDrawColor(rangeColor.r, rangeColor.g, rangeColor.b, 200 * door.persistentAlpha / 255)
                surface.DrawRect(rangeBarX, rangeBarY, rangeWidth, rangeBarH)
                
                surface.SetDrawColor(255, 255, 255, 150)
                surface.DrawOutlinedRect(rangeBarX, rangeBarY, rangeBarW, rangeBarH)
                
                -- Warning text if close to breaking range
                if distancePercent > 0.9 then
                    draw.SimpleText("⚠ MOVE CLOSER OR ACTION WILL CANCEL!", "DermaDefault", panelX + panelW/2, rangeBarY + 15, Color(255, 100, 100, door.persistentAlpha), TEXT_ALIGN_CENTER)
                end
                
                break -- Only show one progress at a time
            end
            end
        end
    end
end

-- Draw 3D door information panels for nearby doors
function SWEP:DrawDoorInfo3D(scrW, scrH)
    local ply = LocalPlayer()
    
    -- Find nearby VEIN doors (within reasonable range)
    for _, door in pairs(ents.GetAll()) do
        if IsValid(door) and door:GetClass():match("door") then
            local distance = ply:GetPos():Distance(door:GetPos())
            
            -- Only show for doors within range and that are VEIN doors
            if distance <= 400 then -- Reasonable 3D info range
                local isBuyable = door:GetNWBool("VEIN_Buyable", false)
                local owner = door:GetNWString("VEIN_Owner", "")
                local hasLockProgress = door:GetNWFloat("VEIN_LockProgress", -1) >= 0
                
                -- Only show for VEIN doors (buyable or owned) and not during lock progress
                if (isBuyable or owner ~= "") and not hasLockProgress then
                    -- Check if player is currently looking directly at this door
                    local trace = ply:GetEyeTrace()
                    local lookingAtDoor = IsValid(trace.Entity) and trace.Entity == door and distance <= 100
                    
                    -- Calculate alpha based on distance and whether looking at door
                    local targetAlpha = lookingAtDoor and 0 or math.Clamp(255 - (distance - 100) * 2, 50, 255)
                    if not door.infoAlpha then door.infoAlpha = 0 end
                    door.infoAlpha = math.Approach(door.infoAlpha, targetAlpha, FrameTime() * 255 * 2)
                    
                    -- Only show if we have some alpha
                    if door.infoAlpha > 10 then
                        -- Draw compact 3D info panel
                        local panelW, panelH = 200, 60
                        
                        -- Calculate door position on screen
                        local doorScreenPos
                        local doorMatrix = door:GetWorldTransformMatrix()
                        if doorMatrix then
                            local worldCenter = doorMatrix:GetTranslation() + Vector(0, 0, 50) -- Slightly above door
                            doorScreenPos = worldCenter:ToScreen()
                        else
                            local doorPos = door:GetPos() + Vector(0, 0, 50)
                            doorScreenPos = doorPos:ToScreen()
                        end
                        
                        -- Only draw if door is on screen
                        if doorScreenPos.visible then
                            -- Position panel centered above the door
                            local panelX = doorScreenPos.x - panelW/2
                            local panelY = doorScreenPos.y - panelH - 20
                            
                            -- Only apply screen boundaries if panel would go completely off-screen
                            if panelX < -panelW/2 then panelX = 10 end
                            if panelX > scrW - panelW/2 then panelX = scrW - panelW - 10 end
                            if panelY < 0 then panelY = 10 end
                            
                            -- Background with distance-based alpha
                            surface.SetDrawColor(25, 25, 30, 180 * door.infoAlpha / 255)
                            surface.DrawRect(panelX, panelY, panelW, panelH)
                            
                            -- Door type color-coded border
                            local doorType = door:GetNWString("VEIN_DoorType", "Residential")
                            -- Use custom door type colors if available
                            local typeColor = Color(200, 200, 200, door.infoAlpha)
                            if VEIN and VEIN.CustomDoors and VEIN.CustomDoors.Types then
                                for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                                    if typeData.name == doorType then
                                        typeColor = Color(typeData.color.r, typeData.color.g, typeData.color.b, door.infoAlpha)
                                        break
                                    end
                                end
                            else
                                local typeColors = {
                                    ["Government"] = Color(255, 80, 80, door.infoAlpha),
                                    ["Emergency"] = Color(255, 165, 0, door.infoAlpha),
                                    ["Commercial"] = Color(80, 150, 255, door.infoAlpha),
                                    ["Industrial"] = Color(255, 200, 60, door.infoAlpha),
                                    ["Residential"] = Color(100, 255, 120, door.infoAlpha)
                                }
                                typeColor = typeColors[doorType] or typeColor
                            end
                            surface.SetDrawColor(typeColor.r, typeColor.g, typeColor.b, 120 * door.infoAlpha / 255)
                            surface.DrawOutlinedRect(panelX, panelY, panelW, panelH, 2)
                            
                            -- Door name/owner
                            local doorName = door:GetNWString("VEIN_DoorName", "")
                            local displayText = ""
                            if isBuyable and owner == "" then
                                displayText = doorName ~= "" and doorName or "For Sale"
                            else
                                displayText = doorName ~= "" and doorName or (owner .. "'s Door")
                            end
                            draw.SimpleText(displayText, "DermaDefault", panelX + panelW/2, panelY + 12, Color(255, 255, 255, door.infoAlpha), TEXT_ALIGN_CENTER)
                            
                            -- Door Type Display (prominent and color-coded)
                            draw.SimpleText(SMALL_CIRCLE .. " " .. doorType .. " Building", "DermaDefaultBold", panelX + panelW/2, panelY + 28, typeColor, TEXT_ALIGN_CENTER)
                            
                            -- Status or price
                            if isBuyable and owner == "" then
                                local price = door:GetNWInt("VEIN_Price", 0)
                                draw.SimpleText("$" .. string.Comma(price), "DermaDefault", panelX + panelW/2, panelY + 44, Color(100, 255, 100, door.infoAlpha), TEXT_ALIGN_CENTER)
                            else
                                local isLocked = door:GetNWBool("VEIN_Locked", false)
                                local isBroken = door:GetNWBool("VEIN_Broken", false)
                                local statusText = isBroken and "BROKEN" or (isLocked and "LOCKED" or "UNLOCKED")
                                local statusColor = isBroken and Color(255, 200, 50, door.infoAlpha) or (isLocked and Color(255, 100, 100, door.infoAlpha) or Color(100, 255, 100, door.infoAlpha))
                                draw.SimpleText(statusText, "DermaDefault", panelX + panelW/2, panelY + 44, statusColor, TEXT_ALIGN_CENTER)
                            end
                        end
                    end
                end
            end
        end
    end
end

function SWEP:DrawHUD()
    if CLIENT then
        local ply = LocalPlayer()
        local scrW, scrH = ScrW(), ScrH()
        
        -- R menu system - Client-side R hold detection for menu
        if input.IsKeyDown(KEY_R) then
            local trace = ply:GetEyeTrace()
            local door = trace.Entity
            
            -- Check if currently looking at a valid LOCKED VEIN door
            local lookingAtValidDoor = false
            if IsValid(door) and door:GetClass():match("door") then
                -- Only work on VEIN doors that are LOCKED
                local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
                local isBuyable = door:GetNWBool("VEIN_Buyable", false)
                local owner = door:GetNWString("VEIN_Owner", "")
                local isLocked = door:GetNWBool("VEIN_Locked", false)
                lookingAtValidDoor = isVEINDoor and (isBuyable or owner ~= "") and isLocked
            end
            
                    -- Count hold time while actively looking at locked VEIN door
            if lookingAtValidDoor then
                -- Start timer only when looking at door and menu not already showing and hasn't been clicked
                if clientRHoldStart == 0 and not clientShowingMenu and not menuWasClicked then
                    clientRHoldStart = CurTime()
                elseif clientRHoldStart > 0 and not clientShowingMenu and not menuWasClicked then
                    local holdTime = CurTime() - clientRHoldStart
                    if holdTime >= 0.5 then
                        clientShowingMenu = true
                        menuOpenTime = CurTime()
                        gui.EnableScreenClicker(true)
                        LocalPlayer():EmitSound("buttons/blip1.wav", 30, 100, 0.3)
                    end
                end
                -- If menu is already showing, don't reset timer or restart logic
            else
                -- Don't immediately close menu when not looking at door - let R key release handle it
            end
        else
            -- Only close menu when R key is released, not every frame
            clientRHoldStart = 0
            menuWasClicked = false -- Reset the clicked flag when R is released
            if clientShowingMenu then
                clientShowingMenu = false
                gui.EnableScreenClicker(false)
                LocalPlayer():EmitSound("buttons/blip2.wav", 30, 100, 0.2)
            end
        end
        
        -- Menu fade animation system (stable version)
        if clientShowingMenu then
            if menuOpenTime and menuOpenTime > 0 then
                local menuAge = CurTime() - menuOpenTime
                menuAlpha = math.min(255, menuAge * 600) -- Fade in over ~0.4 seconds
            else
                menuAlpha = 255
            end
        else
            menuAlpha = math.max(0, menuAlpha - FrameTime() * 800) -- Fade out
        end
        
        -- Radial R Menu (with fade animation)
        if clientShowingMenu or menuAlpha > 0 then
            local centerX, centerY = scrW/2, scrH/2
            local radius = 80
            
            -- Helper function for drawing circles
            local function DrawCircleInline(x, y, r, color)
                local segmentCount = math.max(16, math.min(64, r * 2))
                local poly = {}
                for i = 0, segmentCount do
                    local angle = (i / segmentCount) * math.pi * 2
                    local px = x + math.cos(angle) * r
                    local py = y + math.sin(angle) * r
                    table.insert(poly, {x = px, y = py})
                end
                surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
                draw.NoTexture()
                surface.DrawPoly(poly)
            end
            
            -- Draw radial menu circles with animated opacity
            local bgAlpha = math.floor(200 * (menuAlpha / 255))
            local ringAlpha = math.floor(150 * (menuAlpha / 255))
            local centerAlpha = math.floor(220 * (menuAlpha / 255))
            
            DrawCircleInline(centerX, centerY, radius + 10, Color(30, 30, 35, bgAlpha))
            DrawCircleInline(centerX, centerY, radius, Color(60, 60, 70, ringAlpha))
            DrawCircleInline(centerX, centerY, 35, Color(45, 45, 50, centerAlpha))
            
            -- Kick button positioned at bottom
            local buttonAngle = math.rad(90)
            local buttonX = centerX + math.cos(buttonAngle) * (radius - 15)
            local buttonY = centerY + math.sin(buttonAngle) * (radius - 15)
            local buttonSize = 25
            
            -- Simple hover detection (no caching to keep it simple)
            local mouseX, mouseY = gui.MouseX(), gui.MouseY()
            local buttonDist = math.sqrt((mouseX - buttonX)^2 + (mouseY - buttonY)^2)
            local isHovering = buttonDist <= buttonSize
            
            -- Draw kick button with animated alpha
            local buttonAlpha = math.floor((isHovering and 220 or 180) * (menuAlpha / 255))
            local buttonColor = isHovering and Color(255, 120, 120, buttonAlpha) or Color(180, 80, 80, buttonAlpha)
            DrawCircleInline(buttonX, buttonY, buttonSize, buttonColor)
            
            -- Pixel-perfect text with animated alpha
            local textAlpha = math.floor(255 * (menuAlpha / 255))
            local absoluteButtonX = math.floor(buttonX + 0.5)
            local absoluteButtonY = math.floor(buttonY + 0.5)
            local absoluteCenterX = math.floor(centerX + 0.5)
            local absoluteCenterY = math.floor(centerY + 0.5)
            
            draw.SimpleText("KICK", "DermaDefaultBold", absoluteButtonX, absoluteButtonY, Color(255, 255, 255, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            
            -- Display door information in center of R menu
            local trace = ply:GetEyeTrace()
            local door = trace.Entity
            if IsValid(door) and door:GetClass():match("door") and door:GetNWBool("VEIN_IsVEINDoor", false) then
                local doorName = door:GetNWString("VEIN_DoorName", "Door")
                local doorType = door:GetNWString("VEIN_DoorType", "Residential")
                
                -- Color-coded door type with same colors as other displays
                -- Use custom door type colors if available
                local typeColor = Color(255, 255, 255, textAlpha)
                if VEIN and VEIN.CustomDoors and VEIN.CustomDoors.Types then
                    for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                        if typeData.name == doorType then
                            typeColor = Color(typeData.color.r, typeData.color.g, typeData.color.b, textAlpha)
                            break
                        end
                    end
                else
                    local typeColors = {
                        ["Government"] = Color(255, 80, 80, textAlpha),
                        ["Emergency"] = Color(255, 165, 0, textAlpha),
                        ["Commercial"] = Color(80, 150, 255, textAlpha),
                        ["Industrial"] = Color(255, 200, 60, textAlpha),
                        ["Residential"] = Color(100, 255, 120, textAlpha)
                    }
                    typeColor = typeColors[doorType] or typeColor
                end
                
                draw.SimpleText(doorName, "DermaDefaultBold", absoluteCenterX, absoluteCenterY - 12, Color(255, 255, 255, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText(doorType, "DermaDefaultBold", absoluteCenterX, absoluteCenterY, typeColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            else
                draw.SimpleText("R Menu", "DermaDefaultBold", absoluteCenterX, absoluteCenterY, Color(255, 255, 255, textAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            
            -- Store hover state for click detection
            VEIN.KeysUI = VEIN.KeysUI or {hoveringKickButton = false, menuAlpha = 0}
            if isHovering then
                VEIN.KeysUI.hoveringKickButton = true
                VEIN.KeysUI.menuAlpha = menuAlpha
            else
                VEIN.KeysUI.hoveringKickButton = false
            end
        end
        
        -- Hide crosshair when radial menu is open
        if clientShowingMenu then
            return false
        end
        
        -- Display player money in top-right corner
        -- Check money system in real-time (not cached)
        local useCustom = UseCustomMoney()
        if useCustom then
            local money = ply:GetNWInt("VEIN_Money", 0)
            draw.SimpleTextOutlined("VEIN Money: $" .. string.Comma(money), "DermaDefaultBold", scrW - 20, 20, Color(100, 255, 100), TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP, 2, Color(0, 0, 0))
        end
        -- If using DarkRP money, don't show anything (DarkRP has its own HUD)
        
        -- Draw persistent lock progress for any ongoing lock/unlock actions (only when using keys weapon)
        local currentWep = ply:GetActiveWeapon()
        if IsValid(currentWep) and currentWep:GetClass() == "vein_keys" then
            self:DrawPersistentLockProgress(scrW, scrH)
            -- self:DrawDoorInfo3D(scrW, scrH) -- Disabled: Floating panels removed per user request
        end
        
        local trace = ply:GetEyeTrace()
        local door = trace.Entity
        
        -- Handle UI fade animation
        local lookingAtValidDoor = false
        -- Check distance to where player is looking (trace hit), not door center (for large doors/gates)
        if IsValid(door) and trace.HitPos and trace.HitPos:Distance(ply:GetShootPos()) <= 100 then
            local class = door:GetClass()
            if class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating" then
                -- Only show UI for doors that are VEIN doors
                local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
                if isVEINDoor then
                    lookingAtValidDoor = true
                    -- Store current door info for fade out
                    -- Calculate job access for caching
                    local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
                    local hasJobAccess = false
                    if isJobControlled then
                        local controlJobs = util.JSONToTable(door:GetNWString("VEIN_ControlJobs", "[]")) or {}
                        hasJobAccess = HasTeamAccess(controlJobs, ply:Team())
                    end
                    
                    self.LastDoorInfo = {
                        door = door,
                        isBuyable = door:GetNWBool("VEIN_Buyable", false),
                        isAdminOnly = door:GetNWBool("VEIN_AdminOnly", false),
                        isJobControlled = isJobControlled,
                        hasJobAccess = hasJobAccess,
                        owner = door:GetNWString("VEIN_OwnerName", ""),
                        doorName = door:GetNWString("VEIN_DoorName", ""),
                        doorType = door:GetNWString("VEIN_DoorType", "Residential"),
                        price = door:GetNWInt("VEIN_Price", 0)
                    }
                end
            end
        end
        
        -- Smooth fade in/out animation
        local fadeSpeed = 1.5 -- Slower fade for better effect
        if lookingAtValidDoor then
            self.UIAlpha = math.Approach(self.UIAlpha, 255, FrameTime() * 255 * fadeSpeed)
        else
            self.UIAlpha = math.Approach(self.UIAlpha, 0, FrameTime() * 255 * fadeSpeed)
        end
        
        -- Only draw door UI if we have some alpha (allow fade out rendering)
        if self.UIAlpha <= 5 then return end
        
        -- Draw door UI if we have alpha (either looking at door or fading out)
        if self.UIAlpha > 5 then
            -- Use current door info if looking at door, otherwise use stored info for fade out
            local doorInfo = self.LastDoorInfo or {}
            local currentDoor = lookingAtValidDoor and door or doorInfo.door
            local isBuyable = lookingAtValidDoor and door:GetNWBool("VEIN_Buyable", false) or doorInfo.isBuyable or false
            local isAdminOnly = lookingAtValidDoor and door:GetNWBool("VEIN_AdminOnly", false) or doorInfo.isAdminOnly or false
            local isJobControlled = lookingAtValidDoor and door:GetNWBool("VEIN_JobControlled", false) or doorInfo.isJobControlled or false
            local owner = lookingAtValidDoor and door:GetNWString("VEIN_OwnerName", "") or doorInfo.owner or ""
            local doorName = lookingAtValidDoor and door:GetNWString("VEIN_DoorName", "") or doorInfo.doorName or ""
            local doorType = lookingAtValidDoor and door:GetNWString("VEIN_DoorType", "Residential") or doorInfo.doorType or "Residential"
            local price = lookingAtValidDoor and door:GetNWInt("VEIN_Price", 0) or doorInfo.price or 0

                if isJobControlled and owner == "" then
                    -- Job-controlled door
                    local displayName = doorName ~= "" and doorName or "Job Door"

                    local hasAccess
                    if lookingAtValidDoor then
                        local controlJobs = util.JSONToTable(door:GetNWString("VEIN_ControlJobs", "[]")) or {}
                        hasAccess = HasTeamAccess(controlJobs, ply:Team())
                    else
                        hasAccess = doorInfo.hasJobAccess or false
                    end

                    local titleColor = hasAccess and Color(150, 255, 150, self.UIAlpha) or Color(255, 200, 100, self.UIAlpha)
                    draw.SimpleTextOutlined(displayName .. " (Job Controlled)", "DermaLarge", scrW/2, scrH/2 + 50, titleColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, self.UIAlpha * 0.8))
                    draw.SimpleTextOutlined(SMALL_CIRCLE .. " " .. doorType .. " Building", "DermaDefault", scrW/2, scrH/2 + 80, titleColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))

                    local isLocked = IsValid(currentDoor) and currentDoor:GetNWBool("VEIN_Locked", false) or false
                    local lockText = isLocked and "[LOCKED]" or "[UNLOCKED]"
                    local lockColor = isLocked and Color(255, 100, 100, self.UIAlpha) or Color(100, 255, 100, self.UIAlpha)
                    draw.SimpleTextOutlined(lockText, "DermaDefault", scrW/2, scrH/2 + 105, lockColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))

                    if hasAccess then
                        local lockProgress, actionText = -1, "Processing"
                        if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedLockProgress and IsValid(currentDoor) then
                            lockProgress, actionText = VEIN.DoorSystem.GetLinkedLockProgress(currentDoor)
                        elseif IsValid(currentDoor) then
                            lockProgress = currentDoor:GetNWFloat("VEIN_LockProgress", -1)
                            actionText = currentDoor:GetNWString("VEIN_LockAction", "Processing")
                        end

                        if lockProgress >= 0 and lockProgress <= 1 then
                            draw.SimpleTextOutlined(actionText .. "...", "DermaDefaultBold", scrW/2, scrH/2 + 130, Color(255, 255, 100, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                            local barWidth = 200
                            local barHeight = 8
                            local barX = scrW/2 - barWidth/2
                            local barY = scrH/2 + 150
                            surface.SetDrawColor(50, 50, 50, 200 * self.UIAlpha / 255)
                            surface.DrawRect(barX, barY, barWidth, barHeight)
                            surface.SetDrawColor(100, 255, 100, 200 * self.UIAlpha / 255)
                            surface.DrawRect(barX, barY, barWidth * lockProgress, barHeight)
                            surface.SetDrawColor(255, 255, 255, 150 * self.UIAlpha / 255)
                            surface.DrawOutlinedRect(barX, barY, barWidth, barHeight)
                        else
                            draw.SimpleTextOutlined("Left-click: Lock/Unlock", "DermaDefault", scrW/2, scrH/2 + 130, Color(255, 255, 255, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                        end
                    else
                        draw.SimpleTextOutlined("Your job cannot access", "DermaDefault", scrW/2, scrH/2 + 130, Color(255, 200, 100, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                    end

                elseif isAdminOnly and owner == "" then
                    local displayName = doorName ~= "" and doorName or "Admin Door"
                    local hasAccess = ply:IsAdmin() or ply:IsSuperAdmin()
                    local titleColor = hasAccess and Color(150, 150, 255, self.UIAlpha) or Color(255, 150, 150, self.UIAlpha)
                    draw.SimpleTextOutlined(displayName .. " (Admin Only)", "DermaLarge", scrW/2, scrH/2 + 50, titleColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, self.UIAlpha * 0.8))
                    draw.SimpleTextOutlined(SMALL_CIRCLE .. " " .. doorType .. " Building", "DermaDefault", scrW/2, scrH/2 + 80, titleColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                    if hasAccess then
                        local lockProgress, actionText = -1, "Processing"
                        if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedLockProgress and IsValid(currentDoor) then
                            lockProgress, actionText = VEIN.DoorSystem.GetLinkedLockProgress(currentDoor)
                        elseif IsValid(currentDoor) then
                            lockProgress = currentDoor:GetNWFloat("VEIN_LockProgress", -1)
                            actionText = currentDoor:GetNWString("VEIN_LockAction", "Processing")
                        end

                        if lockProgress >= 0 and lockProgress <= 1 then
                            draw.SimpleTextOutlined(actionText .. "...", "DermaDefaultBold", scrW/2, scrH/2 + 105, Color(255, 255, 100, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                            local barWidth = 200
                            local barHeight = 8
                            local barX = scrW/2 - barWidth/2
                            local barY = scrH/2 + 125
                            surface.SetDrawColor(50, 50, 50, 200 * self.UIAlpha / 255)
                            surface.DrawRect(barX, barY, barWidth, barHeight)
                            surface.SetDrawColor(100, 255, 100, 200 * self.UIAlpha / 255)
                            surface.DrawRect(barX, barY, barWidth * lockProgress, barHeight)
                            surface.SetDrawColor(255, 255, 255, 150 * self.UIAlpha / 255)
                            surface.DrawOutlinedRect(barX, barY, barWidth, barHeight)
                        else
                            draw.SimpleTextOutlined("Left-click: Lock/Unlock", "DermaDefault", scrW/2, scrH/2 + 105, Color(255, 255, 255, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                        end
                    else
                        draw.SimpleTextOutlined("Admin access required", "DermaDefault", scrW/2, scrH/2 + 105, Color(255, 150, 150, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                    end

                elseif isBuyable and owner == "" then
                    -- Buyable door
                    local displayName = doorName ~= "" and doorName or "Door"
                    local linkCount = IsValid(currentDoor) and currentDoor:GetNWInt("VEIN_LinkCount", 1) or 1
                    local linkTotal = IsValid(currentDoor) and currentDoor:GetNWInt("VEIN_LinkTotalPrice", price) or price
                    local propertyGroupId = IsValid(currentDoor) and currentDoor:GetNWInt("VEIN_PropertyGroup", 0) or 0
                    local propertyGroupName = IsValid(currentDoor) and currentDoor:GetNWString("VEIN_PropertyGroupName", "") or ""
                    local propertyCount = IsValid(currentDoor) and currentDoor:GetNWInt("VEIN_PropertyCount", 1) or 1
                    local propertyTotal = IsValid(currentDoor) and currentDoor:GetNWInt("VEIN_PropertyTotalPrice", price) or price
                    local displayPrice = (propertyGroupId > 0 and propertyGroupName ~= "") and propertyTotal or price

                    -- Get door type and its color
                    local nameColor = Color(200, 200, 200, self.UIAlpha)
                    if VEIN and VEIN.CustomDoors and VEIN.CustomDoors.Types then
                        for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                            if typeData.name == doorType then
                                nameColor = Color(typeData.color.r, typeData.color.g, typeData.color.b, self.UIAlpha)
                                break
                            end
                        end
                    else
                        local typeColors = {
                            ["Government"] = Color(255, 120, 120, self.UIAlpha),
                            ["Commercial"] = Color(120, 180, 255, self.UIAlpha),
                            ["Emergency"] = Color(255, 100, 100, self.UIAlpha),
                            ["Industrial"] = Color(255, 200, 60, self.UIAlpha),
                            ["Residential"] = Color(100, 255, 120, self.UIAlpha)
                        }
                        nameColor = typeColors[doorType] or nameColor
                    end

                    local forSaleText = displayName .. " - $" .. displayPrice
                    surface.SetFont("DermaLarge")
                    local nameWidth = surface.GetTextSize(displayName)
                    local dashWidth = surface.GetTextSize(" - ")
                    local priceText = "$" .. displayPrice
                    local priceWidth = surface.GetTextSize(priceText)
                    local totalWidth = nameWidth + dashWidth + priceWidth
                    local startX = scrW/2 - totalWidth/2

                    draw.SimpleTextOutlined(displayName, "DermaLarge", startX, scrH/2 + 50, nameColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, self.UIAlpha * 0.8))
                    draw.SimpleTextOutlined(" - ", "DermaLarge", startX + nameWidth, scrH/2 + 50, Color(255, 255, 255, self.UIAlpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, self.UIAlpha * 0.8))
                    draw.SimpleTextOutlined(priceText, "DermaLarge", startX + nameWidth + dashWidth, scrH/2 + 50, Color(0, 255, 0, self.UIAlpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, self.UIAlpha * 0.8))
                    draw.SimpleTextOutlined(SMALL_CIRCLE .. " " .. doorType .. " Building", "DermaDefault", scrW/2, scrH/2 + 80, nameColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))

                    local purchaseText = (propertyGroupId > 0 and propertyGroupName ~= "") and "Buy this property?" or "Right-click to purchase"
                    draw.SimpleTextOutlined(purchaseText, "DermaDefault", scrW/2, scrH/2 + 105, Color(255, 255, 255, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))

                    if propertyGroupId > 0 and propertyGroupName ~= "" and propertyCount > 1 then
                        draw.SimpleTextOutlined("Property Doors: " .. propertyCount .. " " .. SMALL_CIRCLE .. " Total $" .. string.Comma(propertyTotal), "DermaDefault", scrW/2, scrH/2 + 125, Color(160, 255, 160, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                        draw.SimpleTextOutlined("Left-click to see all property doors", "DermaDefault", scrW/2, scrH/2 + 145, Color(200, 255, 200, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                    elseif linkCount > 1 then
                        draw.SimpleTextOutlined("Linked Doors: " .. linkCount .. " " .. SMALL_CIRCLE .. " Total $" .. string.Comma(linkTotal), "DermaDefault", scrW/2, scrH/2 + 125, Color(160, 255, 160, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                    end
                elseif owner ~= "" then
                    -- Check if player has access to this door
                    local hasAccess = false
                    if owner == ply:Nick() then
                        hasAccess = true
                    else
                        -- Check network data for access (simplified client-side check)
                        local doorAccess = IsValid(currentDoor) and currentDoor:GetNWString("VEIN_AccessList", "") or ""
                        hasAccess = string.find(doorAccess, ply:Nick()) ~= nil
                    end
                    
                    -- Show basic door info for all owned doors (access or no access)
                    local displayName
                    if hasAccess then
                        displayName = doorName ~= "" and doorName or (owner .. "'s Door")
                    else
                        displayName = "Door" -- Generic name for players without access
                    end
                    
                    -- Get door type color (from custom doors or default colors)
                    local typeColor = Color(200, 200, 200, self.UIAlpha)
                    if VEIN and VEIN.CustomDoors and VEIN.CustomDoors.Types then
                        -- Search for the door type in custom doors data
                        for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                            if typeData.name == doorType then
                                typeColor = Color(typeData.color.r, typeData.color.g, typeData.color.b, self.UIAlpha)
                                break
                            end
                        end
                    else
                        -- Fallback to hardcoded colors if custom doors not loaded
                        local typeColors = {
                            ["Government"] = Color(255, 80, 80, self.UIAlpha),
                            ["Emergency"] = Color(255, 165, 0, self.UIAlpha),
                            ["Commercial"] = Color(80, 150, 255, self.UIAlpha),
                            ["Industrial"] = Color(255, 200, 60, self.UIAlpha),
                            ["Residential"] = Color(100, 255, 120, self.UIAlpha)
                        }
                        typeColor = typeColors[doorType] or Color(200, 200, 200, self.UIAlpha)
                    end
                    
                    -- Use type color for door name
                    draw.SimpleTextOutlined(displayName, "DermaLarge", scrW/2, scrH - 200, typeColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0, self.UIAlpha * 0.8))
                    
                    -- Door Type Display (always show for all doors)
                    draw.SimpleTextOutlined(SMALL_CIRCLE .. " " .. doorType .. " Building", "DermaDefault", scrW/2, scrH - 175, typeColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                    
                    -- Lock Status Display (always show for all doors)
                    local isLocked = IsValid(currentDoor) and currentDoor:GetNWBool("VEIN_Locked", false) or false
                    local isBroken = IsValid(currentDoor) and currentDoor:GetNWBool("VEIN_Broken", false) or false
                    
                    local lockText, lockColor
                    if isBroken then
                        lockText = "[BROKEN]"
                        lockColor = Color(200, 200, 80, self.UIAlpha) -- Yellow color for broken
                    else
                        lockText = isLocked and "[LOCKED]" or "[UNLOCKED]"
                        lockColor = isLocked and Color(255, 100, 100, self.UIAlpha) or Color(100, 255, 100, self.UIAlpha)
                    end
                    draw.SimpleTextOutlined(lockText, "DermaDefault", scrW/2, scrH - 150, lockColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))

                    if hasAccess then
                        -- Show lock/unlock progress (linked-aware)
                        local lockProgress, actionText = -1, "Processing"
                        if VEIN and VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedLockProgress and IsValid(currentDoor) then
                            lockProgress, actionText = VEIN.DoorSystem.GetLinkedLockProgress(currentDoor)
                        elseif IsValid(currentDoor) then
                            lockProgress = currentDoor:GetNWFloat("VEIN_LockProgress", -1)
                            actionText = currentDoor:GetNWString("VEIN_LockAction", "Processing")
                        end
                        
                        if lockProgress >= 0 and lockProgress <= 1 then
                            -- Progress text - moved much lower to avoid overlap with door status
                            draw.SimpleTextOutlined(actionText .. "...", "DermaDefaultBold", scrW/2, scrH - 110, Color(255, 255, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0))
                            
                            -- Progress bar - moved lower
                            local barWidth = 200
                            local barHeight = 8
                            local barX = scrW/2 - barWidth/2
                            local barY = scrH - 90
                            
                            -- Background
                            surface.SetDrawColor(50, 50, 50, 200)
                            surface.DrawRect(barX, barY, barWidth, barHeight)
                            
                            -- Progress fill
                            local progressWidth = barWidth * lockProgress
                            surface.SetDrawColor(100, 255, 100, 200)
                            surface.DrawRect(barX, barY, progressWidth, barHeight)
                            
                            -- Border
                            surface.SetDrawColor(255, 255, 255, 150)
                            surface.DrawOutlinedRect(barX, barY, barWidth, barHeight)
                        else
                            draw.SimpleTextOutlined("Left-click: Lock/Unlock • Right-click: Manage • R: Bang • Middle-click: Toggle GUI", "DermaDefault", scrW/2, scrH - 70, Color(255, 255, 255, self.UIAlpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, self.UIAlpha * 0.8))
                        end
                end
            end
        end
    end
    
    -- Kick Progress Display (restored from commented hook)
    local kickTrace = self:GetOwner():GetEyeTrace()
    local kickDoor = kickTrace.Entity
    
    if IsValid(kickDoor) and kickDoor:GetClass():match("door") then
        local isBeingKicked = kickDoor:GetNWBool("VEIN_BeingKicked", false)
        local kickStartTime = kickDoor:GetNWFloat("VEIN_KickStartTime", 0)
        
        if isBeingKicked and kickStartTime > 0 then
            local isLockedKick = kickDoor:GetNWBool("VEIN_LockedKick", false)
            local kickTime = kickDoor:GetNWFloat("VEIN_KickTime", 15) -- Get material-based kick time
            local kickDuration = isLockedKick and kickTime or 3.0 -- Use material time for locked doors, 3 for unlocked
            local progress = math.Clamp((CurTime() - kickStartTime) / kickDuration, 0, 1)
            
            -- Show kick progress in corner
            local scrH = ScrH()
            local text = isLockedKick and "Breaking down locked door..." or "Kicking down door..."
            draw.SimpleTextOutlined(text, "DermaDefaultBold", 115, scrH - 170, Color(255, 110, 53), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0))
            
            -- Progress bar
            local barWidth = 200
            local barHeight = 8
            local barX = 100
            local barY = scrH - 160
            
            -- Background
            surface.SetDrawColor(141, 141, 141, 200)
            surface.DrawRect(barX, barY, barWidth, barHeight)
            
            -- Progress fill
            local progressWidth = barWidth * progress
            surface.SetDrawColor(255, 100, 100, 200)
            surface.DrawRect(barX, barY, progressWidth, barHeight)
            
            -- Border
            surface.SetDrawColor(0, 0, 0, 150)
            surface.DrawOutlinedRect(barX, barY, barWidth, barHeight)
        end
    end
    

end-- Hide crosshair when radial menu is active
function SWEP:DoDrawCrosshair(x, y)
    if CLIENT then
        -- Don't draw crosshair if radial menu is open or fading
        if clientShowingMenu or (menuAlpha and menuAlpha > 0) then
            return true -- Return true to prevent default crosshair drawing
        end
    end
    return false -- Return false to allow default crosshair drawing
end

-- Middle mouse button to toggle GUI visibility (client-side only)
function SWEP:OnRemove()
    -- Reset GUI toggle when weapon is removed
    if CLIENT then
        self.ShowGUI = false
    end
end

if CLIENT then
    -- Client-side variables for R hold tracking (moved from hook to weapon)
    clientRHoldStart = 0
    clientShowingMenu = false
    menuAlpha = 0
    menuOpenTime = 0
    lastMenuState = false
    tooltipAlpha = 0
    tooltipText = ""
    lastHoverTime = 0

    -- Helper function to draw circles
    local function DrawCircle(x, y, radius, color, outline)
        local segmentCount = math.max(16, math.min(64, radius * 2))
        local poly = {}
        
        for i = 0, segmentCount do
            local angle = (i / segmentCount) * math.pi * 2
            local px = x + math.cos(angle) * radius
            local py = y + math.sin(angle) * radius
            table.insert(poly, {x = px, y = py})
        end
        
        surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
        if outline then
            for i = 1, #poly do
                local next_i = i == #poly and 1 or i + 1
                surface.DrawLine(poly[i].x, poly[i].y, poly[next_i].x, poly[next_i].y)
            end
        else
            draw.NoTexture()
            surface.DrawPoly(poly)
        end
    end

    -- Remove any existing hooks to prevent duplicates
    hook.Remove("PostDrawHUD", "VEIN_KickProgress")
    hook.Remove("HUDPaint", "VEIN_KickProgress")
    
    -- Add kick progress display to HUD (PostDrawHUD for top layer) - R menu moved to weapon DrawHUD
    hook.Add("PostDrawHUD", "VEIN_KickProgress", function()
        local ply = LocalPlayer()
        local wep = ply:GetActiveWeapon()

        -- Only show when holding keys weapon
        if IsValid(wep) and wep:GetClass() == "vein_keys" then
            -- R menu moved to weapon DrawHUD function for proper rendering context

            -- Only show progress when NOT looking directly at the door (as requested)
            local trace = ply:GetEyeTrace()
            local door = trace.Entity

            if IsValid(door) and door:GetClass():match("door") then
                local isBeingKicked = door:GetNWBool("VEIN_BeingKicked", false)
                local kickStartTime = door:GetNWFloat("VEIN_KickStartTime", 0)

                if isBeingKicked and kickStartTime > 0 then
                    local isLockedKick = door:GetNWBool("VEIN_LockedKick", false)
                    local kickTime = door:GetNWFloat("VEIN_KickTime", 15) -- Get material-based kick time
                    local kickDuration = isLockedKick and kickTime or 3.0 -- Use material time for locked doors, 3 for unlocked
                    local progress = math.Clamp((CurTime() - kickStartTime) / kickDuration, 0, 1)

                    local scrW, scrH = ScrW(), ScrH()

                    -- Show kick progress in corner (not center since they're not looking at door)
                    local isLockedKick = door:GetNWBool("VEIN_LockedKick", false)
                    local text = isLockedKick and "Breaking down locked door..." or "Kicking down door..."
                    draw.SimpleTextOutlined(text, "DermaDefaultBold", 115, scrH - 170, Color(255, 110, 53), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER, 2, Color(0, 0, 0))

                    -- Progress bar
                    local barWidth = 200
                    local barHeight = 8
                    local barX = 100
                    local barY = scrH - 160

                    -- Background
                    surface.SetDrawColor(141, 141, 141, 200)
                    surface.DrawRect(barX, barY, barWidth, barHeight)

                    -- Progress fill
                    local progressWidth = barWidth * progress
                    surface.SetDrawColor(255, 100, 100, 200)
                    surface.DrawRect(barX, barY, progressWidth, barHeight)

                    -- Border
                    surface.SetDrawColor(0, 0, 0, 150)
                    surface.DrawOutlinedRect(barX, barY, barWidth, barHeight)
                end
            end
        end
    end)
end

-- Middle mouse button to toggle GUI visibility (client-side only)
function SWEP:OnRemove()
    -- Reset GUI toggle when weapon is removed
    if CLIENT then
        self.ShowGUI = false
    end
end

-- Handle middle mouse button input and kick progress display
if CLIENT then
    -- Client-side variables for R hold tracking (moved from hook to weapon)
    clientRHoldStart = 0
    clientShowingMenu = false
    menuAlpha = 0
    menuOpenTime = 0
    lastMenuState = false
    tooltipAlpha = 0
    tooltipText = ""
    lastHoverTime = 0

    -- Helper function to draw circles
    local function DrawCircle(x, y, radius, color, outline)
        local segmentCount = math.max(16, math.min(64, radius * 2))
        local poly = {}
        
        for i = 0, segmentCount do
            local angle = (i / segmentCount) * math.pi * 2
            local px = x + math.cos(angle) * radius
            local py = y + math.sin(angle) * radius
            table.insert(poly, {x = px, y = py})
        end
        
        surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
        if outline then
            for i = 1, #poly do
                local next_i = i == #poly and 1 or i + 1
                surface.DrawLine(poly[i].x, poly[i].y, poly[next_i].x, poly[next_i].y)
            end
        else
            draw.NoTexture()
            surface.DrawPoly(poly)
        end
    end
    
    -- Client-side variables for R hold tracking
    local clientRHoldStart = 0
    local clientShowingMenu = false
    
    -- Helper function to draw circles
    local function DrawCircle(x, y, radius, color, outline)
        local segmentCount = math.max(16, math.min(64, radius * 2))
        local poly = {}
        
        for i = 0, segmentCount do
            local angle = (i / segmentCount) * math.pi * 2
            local px = x + math.cos(angle) * radius
            local py = y + math.sin(angle) * radius
            table.insert(poly, {x = px, y = py})
        end
        
        surface.SetDrawColor(color.r, color.g, color.b, color.a or 255)
        if outline then
            for i = 1, #poly do
                local next_i = i == #poly and 1 or i + 1
                surface.DrawLine(poly[i].x, poly[i].y, poly[next_i].x, poly[next_i].y)
            end
        else
            draw.NoTexture()
            surface.DrawPoly(poly)
        end
    end
    
    -- Animation and tooltip system
    local tooltipAlpha = 0
    local tooltipText = ""
    local lastHoverTime = 0
    local menuAlpha = 0
    local menuOpenTime = 0
    local lastMenuState = false
    
    -- Remove any existing hooks to prevent duplicates
    hook.Remove("PostDrawHUD", "VEIN_KickProgress")
    hook.Remove("HUDPaint", "VEIN_KickProgress")

end -- Close CLIENT block

-- Console command to start kicking from client
concommand.Add("vein_start_kicking", function(ply, cmd, args)
    if not IsValid(ply) then return end
    
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "vein_keys" then return end
    
    local trace = ply:GetEyeTrace()
    local door = trace.Entity
    
    if IsValid(door) and door:GetClass():match("door") then
        local isLocked = door:GetNWBool("VEIN_Locked", false)
        -- Check distance to where player is looking (trace hit), not door center
        if isLocked and trace.HitPos:Distance(ply:GetShootPos()) <= 100 then
            wep:StartKicking(door, ply)
        end
    end
end)

-- Mouse input hook for kick button clicking (CLIENT-side only)
if CLIENT then
    menuWasClicked = menuWasClicked or false -- Initialize if not already defined
    hook.Add("GUIMousePressed", "VEIN_KickButtonClick", function(mouseCode, aimVector)
        VEIN.KeysUI = VEIN.KeysUI or {hoveringKickButton = false, menuAlpha = 0}
        if mouseCode == MOUSE_LEFT and VEIN.KeysUI.hoveringKickButton and clientShowingMenu and (VEIN.KeysUI.menuAlpha or 0) >= 200 then
            LocalPlayer():EmitSound("buttons/button3.wav", 40, 100, 0.4)
            clientShowingMenu = false
            gui.EnableScreenClicker(false)
            clientRHoldStart = 0
            menuAlpha = 0
            menuWasClicked = true -- Prevent reopening until R is released
            VEIN.KeysUI.hoveringKickButton = false
            RunConsoleCommand("vein_start_kicking")
            return true -- Consume the click
        end
    end)
end

-- CLIENT: Receive and play lock/unlock animation
if CLIENT then
    net.Receive("VEIN_LockAnimation", function()
        local ply = net.ReadEntity()
        if IsValid(ply) then
            ply:AnimRestartGesture(GESTURE_SLOT_ATTACK_AND_RELOAD, ACT_GMOD_GESTURE_ITEM_PLACE, true)
        end
    end)
end


