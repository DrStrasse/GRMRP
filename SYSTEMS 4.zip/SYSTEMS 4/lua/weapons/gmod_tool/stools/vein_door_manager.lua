--[[
================================================================================
VEIN Door Manager Tool - Creates buyable doors with GUI setup
================================================================================
]]--

TOOL.Category = "VEIN Door System"
TOOL.Name = "Door Manager"
TOOL.Command = nil
TOOL.ConfigName = ""
TOOL.ClientConVar = {}
TOOL.Information = {
    { name = "left", stage = 0 },
    { name = "right", stage = 0 },
    { name = "reload", stage = 0 },
    { name = "middle", stage = 0 }
}

-- Table to store first linked door per player (SERVER-SIDE)
if SERVER then
    TOOL.FirstLinkedDoors = TOOL.FirstLinkedDoors or {}
    TOOL.LinkModes = TOOL.LinkModes or {}
end

-- OVERRIDE: Allow tool to work on doors (bypass FPP/DarkRP client-side checks)
function TOOL:Allowed()
    return true -- Always allow this tool client-side
end

-- Check for first-time tutorial when tool is equipped
if CLIENT then
    function TOOL:Equip()
        print("[VEIN] Door Manager tool equipped")
        
        -- Delay check to ensure tutorial system is loaded
        timer.Simple(0.1, function()
            if VEIN and VEIN.Tutorial and VEIN.Tutorial.CheckFirstTime then
                print("[VEIN] Tutorial system found, checking if first time")
                VEIN.Tutorial.CheckFirstTime()
            else
                print("[VEIN] Tutorial system not loaded yet!")
                print("[VEIN] VEIN table exists: " .. tostring(VEIN ~= nil))
                print("[VEIN] VEIN.Tutorial exists: " .. tostring(VEIN and VEIN.Tutorial ~= nil))
                print("[VEIN] CheckFirstTime exists: " .. tostring(VEIN and VEIN.Tutorial and VEIN.Tutorial.CheckFirstTime ~= nil))
            end
        end)
    end
end

-- Fix the tool name localization
if CLIENT then
    language.Add("tool.vein_door_manager.name", "Door Manager")
    language.Add("tool.vein_door_manager.desc", "Create and manage buyable doors")
    language.Add("tool.vein_door_manager.0", "Left-click: Create | Right-click: Modify | R: Job Menu | MMB: Copy")
    language.Add("tool.vein_door_manager.left", "Left-click to create a new door | Shift + Left-click to link doors")
    language.Add("tool.vein_door_manager.right", "Right-click to modify an existing door")
    language.Add("tool.vein_door_manager.reload", "Press R to open job permission menu")
    language.Add("tool.vein_door_manager.middle", "Middle mouse button to copy door settings")
end

-- Initialize system
VEIN = VEIN or {}
local VEIN = VEIN
VEIN.DoorSystem = VEIN.DoorSystem or {}
VEIN.DoorSystem.CopiedDoorData = VEIN.DoorSystem.CopiedDoorData or {} -- Store copied door settings per player
VEIN.Net = VEIN.Net or {}

local Net = VEIN.Net
local DoorSystem = VEIN.DoorSystem
local SetDoorHologramAnchor

local function HasDoorAdminPermission(ply, perm)
    if not IsValid(ply) then return false end
    if ply:IsAdmin() or ply:IsSuperAdmin() then return true end
    if SERVER then
        return VEIN.Settings and VEIN.Settings.HasDoorAdminPermission and VEIN.Settings.HasDoorAdminPermission(ply, perm)
    end
    return VEIN.DoorAdmin and VEIN.DoorAdmin.isDoorAdmin and VEIN.DoorAdmin.perms and VEIN.DoorAdmin.perms[perm] == true
end

-- VEIN themed chat message function
local function VEINChat(ply, message)
    if CLIENT then
        chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), message)
    else
        VEIN.Chat(ply, message)
    end
end

-- Money system configuration
VEIN.Config = VEIN.Config or {}

-- AUTO-DETECT DARKRP: Default to 0 (DarkRP money) if DarkRP is loaded, otherwise 1 (custom money)
local defaultMoneySystem = DarkRP and "0" or "1"

-- ConVar for easy toggling (1 = custom money, 0 = DarkRP money)
local vein_use_custom_money = CreateConVar("vein_use_custom_money", defaultMoneySystem, FCVAR_ARCHIVE + FCVAR_REPLICATED, "Use VEIN custom money system (1) or DarkRP money system (0)")

-- Force set to 0 if DarkRP is loaded (override any saved value)
if DarkRP and vein_use_custom_money:GetInt() ~= 0 then
    print("[VEIN] DarkRP detected! Auto-setting money system to DarkRP (0)")
    vein_use_custom_money:SetInt(0)
end

-- Update config based on ConVar
VEIN.Config.UseCustomMoney = vein_use_custom_money:GetBool()

-- Update config when ConVar changes
cvars.AddChangeCallback("vein_use_custom_money", function(name, old, new)
    VEIN.Config.UseCustomMoney = tobool(new)
end)

if SERVER then
    -- Utility function
    local function IsValidDoor(ent)
        if not IsValid(ent) then return false end
        local class = ent:GetClass()
        return class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating"
    end

    -- Save hologram anchor in both world/local space so it remains aligned while doors rotate.
    SetDoorHologramAnchor = function(door, hitNormal, hitPos, visualCenter)
        if not IsValid(door) then return end

        local worldNormal = (isvector(hitNormal) and hitNormal or door:GetForward())
        if worldNormal:LengthSqr() <= 0.0001 then
            worldNormal = door:GetForward()
        else
            worldNormal:Normalize()
        end

        local worldCenter = (isvector(visualCenter) and visualCenter) or door:LocalToWorld(door:OBBCenter())
        local worldClickPos = (isvector(hitPos) and hitPos) or worldCenter

        -- Legacy world-space values (kept for compatibility)
        door:SetNWVector("VEIN_ClickNormal", worldNormal)
        door:SetNWVector("VEIN_ClickPos", worldClickPos)
        door:SetNWVector("VEIN_VisualCenter", worldCenter)

        -- New local-space values (used for stable dynamic placement)
        local localClickPos = door:WorldToLocal(worldClickPos)
        local localCenter = door:WorldToLocal(worldCenter)
        local localNormal = door:WorldToLocal(worldClickPos + worldNormal) - localClickPos
        if localNormal:LengthSqr() <= 0.0001 then
            localNormal = Vector(1, 0, 0)
        else
            localNormal:Normalize()
        end

        door:SetNWVector("VEIN_ClickPosLocal", localClickPos)
        door:SetNWVector("VEIN_VisualCenterLocal", localCenter)
        door:SetNWVector("VEIN_ClickNormalLocal", localNormal)
        door:SetNWBool("VEIN_UseLocalHologram", true)
    end
    
    -- Helper function to trigger hologram display for job-controlled doors
    local function TriggerJobDoorHologram(door, ply)
        if IsValid(door) and door:GetNWBool("VEIN_JobControlled", false) then
            net.Start("VEIN_ShowJobDoorHologram")
            net.WriteEntity(door)
            if IsValid(ply) then
                net.Send(ply) -- Send to specific player
            else
                net.Broadcast() -- Send to all players (for right-click menu)
            end
        end
    end
    
    -- Network strings
    util.AddNetworkString("VEIN_OpenDoorGUI")
    util.AddNetworkString("VEIN_OpenModifyDoorGUI")
    util.AddNetworkString("VEIN_CreateDoor")
    util.AddNetworkString("VEIN_ModifyDoor")
    util.AddNetworkString("VEIN_BuyDoor")
    util.AddNetworkString("VEIN_ToggleLock")
    util.AddNetworkString("VEIN_SellDoor")
    util.AddNetworkString("VEIN_GiveAccess")
    util.AddNetworkString("VEIN_RemoveAccess")
    util.AddNetworkString("VEIN_RemoveDoor")
    util.AddNetworkString("VEIN_AdminForceSell")
    util.AddNetworkString("VEIN_Show3DMenu")
    util.AddNetworkString("VEIN_ChangeDoorName")
    util.AddNetworkString("VEIN_OpenRemoveConfirm")
    util.AddNetworkString("VEIN_RepairDoor")
    util.AddNetworkString("VEIN_DoorCopied")
    util.AddNetworkString("VEIN_RequestJobList")
    util.AddNetworkString("VEIN_JobListData")
    
    -- Money System Functions
    function VEIN.DoorSystem.GetPlayerMoney(ply)
        -- Check ConVar in real-time, not cached value
        local useCustomMoney = GetConVar("vein_use_custom_money"):GetBool()
        
        local money = 0
        if useCustomMoney then
            money = ply:GetNWInt("VEIN_Money", 0)
        else
            -- Use DarkRP money system (proper method)
            if ply.getDarkRPVar then
                money = ply:getDarkRPVar("money") or 0
            else
                -- Fallback to custom if DarkRP not loaded
                money = ply:GetNWInt("VEIN_Money", 0)
            end
        end
        return money
    end
    
    function VEIN.DoorSystem.SetPlayerMoney(ply, amount)
        -- Check ConVar in real-time, not cached value
        local useCustomMoney = GetConVar("vein_use_custom_money"):GetBool()
        
        if useCustomMoney then
            ply:SetNWInt("VEIN_Money", amount)
        else
            -- Use DarkRP money system (proper method)
            if ply.setDarkRPVar then
                ply:setDarkRPVar("money", amount)
            else
                -- Fallback to custom if DarkRP not loaded
                ply:SetNWInt("VEIN_Money", amount)
            end
        end
    end
    
    function VEIN.DoorSystem.AddPlayerMoney(ply, amount)
        -- Check ConVar in real-time, not cached value
        local useCustomMoney = GetConVar("vein_use_custom_money"):GetBool()
        
        if useCustomMoney then
            local currentMoney = ply:GetNWInt("VEIN_Money", 0)
            ply:SetNWInt("VEIN_Money", currentMoney + amount)
        else
            -- Use DarkRP addMoney method (proper method)
            if ply.addMoney then
                ply:addMoney(amount)
            else
                -- Fallback
                local currentMoney = ply:GetNWInt("VEIN_Money", 0)
                ply:SetNWInt("VEIN_Money", currentMoney + amount)
            end
        end
    end
    
    function VEIN.DoorSystem.CanAfford(ply, amount)
        -- Check ConVar in real-time, not cached value
        local useCustomMoney = GetConVar("vein_use_custom_money"):GetBool()
        
        if useCustomMoney then
            return ply:GetNWInt("VEIN_Money", 0) >= amount
        else
            -- Use DarkRP canAfford method (proper method)
            if ply.canAfford then
                return ply:canAfford(amount)
            else
                -- Fallback
                return ply:GetNWInt("VEIN_Money", 0) >= amount
            end
        end
    end
    
    -- Simple Money System - Give players starting money (only if using custom system)
    hook.Add("PlayerInitialSpawn", "VEIN_GiveStartMoney", function(ply)
        -- Check ConVar in real-time, not cached value
        local useCustomMoney = GetConVar("vein_use_custom_money"):GetBool()
        if not useCustomMoney then return end
        
        -- Set starting money immediately on spawn
        ply:SetNWInt("VEIN_Money", 5000) -- Starting money: $5000
        
        -- Notify after a delay to ensure player is ready
        timer.Simple(2, function()
            if IsValid(ply) then
                VEIN.Chat(ply, "You received $5000 starting money!")
            end
        end)
    end)
    
    -- Storage
    VEIN.DoorSystem.OwnedDoors = VEIN.DoorSystem.OwnedDoors or {}
    VEIN.DoorSystem.DoorAccess = VEIN.DoorSystem.DoorAccess or {}
    
    -- Config
    -- Door limits now handled by VEIN.Settings system
    
    -- Core functions
    function VEIN.DoorSystem.GetOwner(door)
        if not IsValid(door) then return nil end
        return VEIN.DoorSystem.OwnedDoors[door:EntIndex()]
    end
    
    function VEIN.DoorSystem.IsOwner(door, ply)
        return VEIN.DoorSystem.GetOwner(door) == ply:SteamID()
    end
    
    -- Save door data (triggers persistence system)
    function VEIN.DoorSystem.SaveDoorData(door)
        if not IsValid(door) then return end
        hook.Run("VEIN_DoorModified", door)
    end
    
    function VEIN.DoorSystem.HasAccess(door, ply)
        -- Job-controlled doors can only be accessed by players with the correct job
        if door:GetNWBool("VEIN_JobControlled", false) then
            local controlJobsJSON = door:GetNWString("VEIN_ControlJobs", "[]")
            local controlJobs = util.JSONToTable(controlJobsJSON) or {}
            
            -- If no jobs selected, only admins can access
            if #controlJobs == 0 then
                return ply:IsAdmin()
            end
            
            -- Check if player's current job is in the allowed list
            local playerTeam = ply:Team()
            for _, teamID in ipairs(controlJobs) do
                if tonumber(teamID) == playerTeam then
                    return true
                end
            end
            
            -- If not in allowed jobs list, deny access
            return false
        end
        
        -- Admin-only doors can only be accessed by admins (even if unowned)
        if door:GetNWBool("VEIN_AdminOnly", false) then
            return ply:IsAdmin()
        end
        
        if VEIN.DoorSystem.IsOwner(door, ply) then return true end
        
        local doorAccess = VEIN.DoorSystem.DoorAccess[door:EntIndex()] or {}
        local steamID = ply:SteamID()
        if doorAccess[steamID] ~= nil then return true end
        local nick = ply:Nick()
        if doorAccess[nick] ~= nil then return true end
        if ply:IsBot() and doorAccess["BOT_" .. nick] ~= nil then return true end
        return false
    end
    
    function VEIN.DoorSystem.CreateDoor(door, ply, doorName, price, isLocked, doorType, doorMaterial, allowOwnership, lockName, jobControlled, controlJobs)
        if not IsValid(door) or not IsValid(ply) then return false end
        
        -- Store the door's initial yaw angle for consistent hologram positioning
        local doorAngle = door:GetAngles()
        door:SetNWFloat("VEIN_InitialYaw", doorAngle.y)
        
        -- Ensure hologram anchor exists even when door is created without a fresh click trace.
        if not door:GetNWBool("VEIN_UseLocalHologram", false) then
            local worldCenter = door:LocalToWorld(door:OBBCenter())
            SetDoorHologramAnchor(door, door:GetForward(), worldCenter, worldCenter)
        end
        
        -- If job controlled, force ownership off
        if jobControlled then
            allowOwnership = false
        end
        
        -- Calculate admin only status
        local adminOnly = (allowOwnership == false) and (not jobControlled)
        
        -- Set door properties
        door:SetNWBool("VEIN_AllowOwnership", allowOwnership ~= false) -- Default true
        door:SetNWBool("VEIN_Buyable", allowOwnership ~= false) -- Only buyable if ownership allowed
        door:SetNWBool("VEIN_AdminOnly", adminOnly) -- Static doors are admin-only (but not job-controlled)
        door:SetNWBool("VEIN_IsVEINDoor", true) -- Mark as VEIN door
        door:SetNWBool("VEIN_IsSetup", true) -- Mark as setup
        door:SetNWString("VEIN_DoorName", doorName or "")
        door:SetNWInt("VEIN_Price", price or 500)
        door:SetNWBool("VEIN_LockName", lockName or false) -- Lock door name from changes
        door:SetNWString("VEIN_Creator", ply:Nick())
        door:SetNWBool("VEIN_AutoLockOnClose", false)
        door:SetNWInt("VEIN_LinkGroup", 0)
        door:SetNWEntity("VEIN_LinkedDoor", NULL)
        
        -- Set job control properties
        door:SetNWBool("VEIN_JobControlled", jobControlled or false)
        door:SetNWString("VEIN_ControlJobs", util.TableToJSON(controlJobs or {}))
        door:SetNWString("VEIN_DoorGroup", "")
        door:SetNWString("VEIN_AllowedJobs", "[]")
        
        -- Set new door type and material properties
        door:SetNWString("VEIN_DoorType", doorType or "Residential")
        door:SetNWString("VEIN_DoorMaterial", doorMaterial or "Light Metal")
        
        -- Get material data and store all sound properties on the door
        local matData = VEIN.CustomDoors.GetMaterialData(doorMaterial or "Light Metal")
        door:SetNWInt("VEIN_KickTime", matData.kickTime)
        door:SetNWString("VEIN_LockSound", matData.lockSound)
        door:SetNWString("VEIN_UnlockSound", matData.unlockSound)
        door:SetNWString("VEIN_KickSound", matData.kickSound)
        door:SetNWString("VEIN_BreakSound", matData.breakSound)
        door:SetNWInt("VEIN_LockPitch", matData.lockPitch or 100)
        door:SetNWInt("VEIN_UnlockPitch", matData.unlockPitch or 100)
        door:SetNWInt("VEIN_KickPitch", matData.kickPitch or 100)
        door:SetNWInt("VEIN_BreakPitch", matData.breakPitch or 100)
        
        -- Job-controlled doors and admin-only doors are ALWAYS locked when created
        if jobControlled or adminOnly then
            isLocked = true
        end
        
        -- IMPORTANT: Set DefaultLocked AFTER the force-lock logic above
        -- This ensures admin/job doors always save as locked=true
        door:SetNWBool("VEIN_DefaultLocked", isLocked or false)
        
        -- Apply initial lock state immediately when door is created
        if isLocked then
            door:Fire("Close") -- Close door first
            timer.Simple(0.5, function()
                if IsValid(door) then
                    door:Fire("Lock")
                    door:SetNWBool("VEIN_Locked", true)
                end
            end)
        else
            door:Fire("Unlock")
            door:SetNWBool("VEIN_Locked", false)
        end
        
        door:EmitSound("buttons/button14.wav")
        
        -- Call hook for persistence system
        hook.Run("VEIN_DoorCreated", door)
        
        return true
    end

    function VEIN.DoorSystem.ClearAutoLockOnClose(door)
        if not IsValid(door) then return end
        local timerName = "VEIN_AutoLockOnClose_" .. door:EntIndex()
        if timer.Exists(timerName) then
            timer.Remove(timerName)
        end
        door.VEIN_OpenSince = nil
        door:SetNWBool("VEIN_AutoLockOnClose", false)
    end

    function VEIN.DoorSystem.StartAutoLockOnClose(door)
        if not IsValid(door) then return end
        local autoCloseDelay = 5
        local timerName = "VEIN_AutoLockOnClose_" .. door:EntIndex()
        
        if timer.Exists(timerName) then
            timer.Remove(timerName)
        end
        
        door.VEIN_WasOpenedAfterUnlock = false
        door.VEIN_OpenSince = nil
        door:SetNWBool("VEIN_AutoLockOnClose", true)
        
        timer.Create(timerName, 0.2, 0, function()
            if not IsValid(door) then
                VEIN.DoorSystem.ClearAutoLockOnClose(door)
                return
            end
            if door:GetNWBool("VEIN_Locked", false) then
                VEIN.DoorSystem.ClearAutoLockOnClose(door)
                return
            end
            if door:GetNWBool("VEIN_Broken", false) then
                VEIN.DoorSystem.ClearAutoLockOnClose(door)
                return
            end
            
            local doorOpen = door:GetInternalVariable("m_toggle_state")
            if doorOpen and doorOpen ~= 0 then
                door.VEIN_WasOpenedAfterUnlock = true
                if not door.VEIN_OpenSince then
                    door.VEIN_OpenSince = CurTime()
                elseif CurTime() - door.VEIN_OpenSince >= autoCloseDelay then
                    door:Fire("Close")
                end
                return
            end
            door.VEIN_OpenSince = nil
            
            if door.VEIN_WasOpenedAfterUnlock then
                door:SetNWBool("VEIN_Locked", true)
                door:Fire("Lock")
                local lockSound = door:GetNWString("VEIN_LockSound", "doors/door_latch3.wav")
                local lockPitch = door:GetNWInt("VEIN_LockPitch", 100)
                door:EmitSound(lockSound, 75, lockPitch)
                
                -- Sync linked doors if part of a group
                if VEIN.DoorSystem.GetLinkedDoors then
                    for _, linkedDoor in ipairs(VEIN.DoorSystem.GetLinkedDoors(door)) do
                        if IsValid(linkedDoor) then
                            linkedDoor:SetNWBool("VEIN_Locked", true)
                            linkedDoor:Fire("Lock")
                            local linkedLockSound = linkedDoor:GetNWString("VEIN_LockSound", "doors/door_latch3.wav")
                            local linkedLockPitch = linkedDoor:GetNWInt("VEIN_LockPitch", 100)
                            linkedDoor:EmitSound(linkedLockSound, 75, linkedLockPitch)
                        end
                    end
                end
                VEIN.DoorSystem.ClearAutoLockOnClose(door)
                hook.Run("VEIN_DoorModified", door)
            end
        end)
    end

    local function ShouldAutoManageDoor(ent)
        if not IsValid(ent) or not ent:GetClass():find("door") then return false end
        if not ent:GetNWBool("VEIN_IsVEINDoor", false) then return false end
        if ent:GetNWString("VEIN_Owner", "") ~= "" then return false end
        return ent:GetNWBool("VEIN_JobControlled", false) or ent:GetNWBool("VEIN_AdminOnly", false)
    end

    local function ScheduleAutoClose(ent)
        if not IsValid(ent) then return end
        if VEIN.DoorSystem.StartAutoLockOnClose then
            VEIN.DoorSystem.StartAutoLockOnClose(ent)
        end
        local timerName = "VEIN_AutoClose_" .. ent:EntIndex()
        if timer.Exists(timerName) then
            timer.Remove(timerName)
        end
        timer.Create(timerName, 5, 1, function()
            if not IsValid(ent) then return end
            if ent:GetNWBool("VEIN_Locked", false) then return end
            ent:Fire("Close")
        end)
    end

    local function TryLockAfterClose(ent)
        if not IsValid(ent) then return end
        if ent:GetNWBool("VEIN_Locked", false) then return end
        if ent:GetNWBool("VEIN_Broken", false) then return end
        if ent:GetNWString("VEIN_Owner", "") ~= "" then return end
        if not (ent:GetNWBool("VEIN_JobControlled", false) or ent:GetNWBool("VEIN_AdminOnly", false)) then return end

        ent:SetNWBool("VEIN_Locked", true)
        ent:Fire("Lock")
        local lockSound = ent:GetNWString("VEIN_LockSound", "doors/door_latch3.wav")
        local lockPitch = ent:GetNWInt("VEIN_LockPitch", 100)
        ent:EmitSound(lockSound, 75, lockPitch)
        if VEIN.DoorSystem.ClearAutoLockOnClose then
            VEIN.DoorSystem.ClearAutoLockOnClose(ent)
        else
            ent:SetNWBool("VEIN_AutoLockOnClose", false)
        end
        hook.Run("VEIN_DoorModified", ent)
    end

    hook.Add("AcceptInput", "VEIN_AutoCloseJobAdminDoors", function(ent, input, activator, caller, value)
        if not ShouldAutoManageDoor(ent) then return end
        local cmd = string.lower(tostring(input or ""))
        if cmd == "open" or cmd == "openawayfrom" or cmd == "openaway" or cmd == "toggle" then
            ScheduleAutoClose(ent)
        elseif cmd == "close" then
            timer.Simple(0.1, function()
                if IsValid(ent) then
                    TryLockAfterClose(ent)
                end
            end)
        end
    end)
    
    local function GetPurchaseGroup(door)
        if not IsValid(door) then return {door}, false end

        if VEIN.DoorSystem and VEIN.DoorSystem.GetPropertyGroupDoors then
            local groupId = door:GetNWInt("VEIN_PropertyGroup", 0)
            local groupName = door:GetNWString("VEIN_PropertyGroupName", "")
            if groupId > 0 and groupName ~= "" then
                local groupDoors = VEIN.DoorSystem.GetPropertyGroupDoors(door) or {}
                if #groupDoors > 0 then
                    return groupDoors, true
                end
            end
        end

        local linked = VEIN.DoorSystem.GetLinkedGroup and VEIN.DoorSystem.GetLinkedGroup(door) or {door}
        return linked, false
    end

    local function GetPurchaseTotalPrice(door, groupDoors, usePropertyGroup)
        if usePropertyGroup and VEIN.DoorSystem and VEIN.DoorSystem.GetPropertyGroupTotalPrice then
            local total = VEIN.DoorSystem.GetPropertyGroupTotalPrice(door)
            if total > 0 then
                return total
            end
        end

        local total = 0
        for _, groupDoor in ipairs(groupDoors or {}) do
            if IsValid(groupDoor) then
                total = total + groupDoor:GetNWInt("VEIN_Price", 500)
            end
        end
        return total
    end

    function VEIN.DoorSystem.BuyDoor(door, ply)
        if not IsValid(door) or not IsValid(ply) then return false end
        
        -- Check if ownership is allowed
        if not door:GetNWBool("VEIN_AllowOwnership", true) then
            VEIN.Chat(ply, "This door is not available for purchase!")
            return false
        end
        
        -- Check door group/job restrictions
        if VEIN.DoorGroups then
            local canAccess, reason = hook.Run("VEIN_CanBuyDoor", ply, door)
            if canAccess == false then
                VEIN.Chat(ply, reason or "Your job cannot access this door!")
                return false
            end
        end
        
        -- Check if buyable
        if not door:GetNWBool("VEIN_Buyable", false) then
            VEIN.Chat(ply, "This door is not for sale!")
            return false
        end
        
        -- Check if owned
        if VEIN.DoorSystem.GetOwner(door) then
            VEIN.Chat(ply, "This door is already owned!")
            return false
        end
        
        -- Gather property or linked group (buy as a group)
        local groupDoors, usePropertyGroup = GetPurchaseGroup(door)
        local totalPrice = GetPurchaseTotalPrice(door, groupDoors, usePropertyGroup)
        for _, groupDoor in ipairs(groupDoors) do
            -- Check door group/job restrictions per door
            if VEIN.DoorGroups then
                local canAccess, reason = hook.Run("VEIN_CanBuyDoor", ply, groupDoor)
                if canAccess == false then
                    VEIN.Chat(ply, reason or "Your job cannot access this door!")
                    return false
                end
            end
            
            if not groupDoor:GetNWBool("VEIN_AllowOwnership", true) then
                VEIN.Chat(ply, "One of the linked doors is not for sale!")
                return false
            end
            if not groupDoor:GetNWBool("VEIN_Buyable", false) then
                VEIN.Chat(ply, "One of the linked doors is not for sale!")
                return false
            end
            if VEIN.DoorSystem.GetOwner(groupDoor) then
                VEIN.Chat(ply, "One of the linked doors is already owned!")
                return false
            end
        end
        
        -- Check money using universal money system
        local playerMoney = VEIN.DoorSystem.GetPlayerMoney(ply)
        if not VEIN.DoorSystem.CanAfford(ply, totalPrice) then
            VEIN.Chat(ply, "You need $" .. totalPrice .. "! You have $" .. playerMoney)
            return false
        end
        
        -- Check door limit using new settings system
        if VEIN.Settings then
            local currentDoors = VEIN.Settings.CountPlayerDoors(ply)
            local maxDoors = VEIN.Settings.GetPlayerDoorLimit(ply)
            if currentDoors + #groupDoors > maxDoors then
                VEIN.Chat(ply, "You can't own more than " .. maxDoors .. " doors! (Currently own " .. currentDoors .. ")")
                return false
            end
        end
        
        -- Purchase (deduct money using proper method)
        -- Check ConVar in real-time, not cached value
        local useCustomMoney = GetConVar("vein_use_custom_money"):GetBool()
        
        if useCustomMoney then
            local newMoney = playerMoney - totalPrice
            ply:SetNWInt("VEIN_Money", newMoney)
        else
            -- Use DarkRP addMoney with negative amount (proper method)
            if ply.addMoney then
                ply:addMoney(-totalPrice)
            else
                -- Fallback to VEIN money if DarkRP not available
                local newMoney = playerMoney - totalPrice
                ply:SetNWInt("VEIN_Money", newMoney)
            end
        end

        -- Apply ownership to the entire linked group
        for _, groupDoor in ipairs(groupDoors) do
            VEIN.DoorSystem.OwnedDoors[groupDoor:EntIndex()] = ply:SteamID()
            groupDoor:SetNWString("VEIN_Owner", ply:SteamID())
            groupDoor:SetNWString("VEIN_OwnerName", ply:Nick())
            groupDoor:SetNWString("VEIN_OwnerSteamID", ply:SteamID())
            groupDoor:SetNWBool("VEIN_Buyable", false)
            
            local defaultLocked = groupDoor:GetNWBool("VEIN_DefaultLocked", false)
            groupDoor:SetNWBool("VEIN_Locked", defaultLocked)
            if defaultLocked then
                groupDoor:Fire("Lock")
            else
                groupDoor:Fire("Unlock")
            end
            
            -- Save door data (ownership changed)
            hook.Run("VEIN_DoorModified", groupDoor)
        end
        
        door:EmitSound("buttons/button14.wav")
        
        return true
    end
    
    function VEIN.DoorSystem.ToggleLock(door, ply)
        if not VEIN.DoorSystem.HasAccess(door, ply) then
            -- Show specific message for job-controlled doors
            if door:GetNWBool("VEIN_JobControlled", false) then
                VEIN.Chat(ply, "This door is job-controlled! Only specific jobs can lock/unlock it.")
            else
                VEIN.Chat(ply, "You don't have access to this door!")
            end
            return false
        end
        
        -- Check if door is broken and needs repair
        if door:GetNWBool("VEIN_Broken", false) then
            VEIN.Chat(ply, "This door is damaged and needs repair before it can be locked!")
            return false
        end
        
        local isLocked = door:GetNWBool("VEIN_Locked", false)
        local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
        local isAdminOnly = door:GetNWBool("VEIN_AdminOnly", false)
        
        if isLocked then
            door:Fire("Unlock")
            door:SetNWBool("VEIN_Locked", false)
            VEIN.Chat(ply, "Door unlocked!")
            door:EmitSound("buttons/button15.wav")
            
            -- Auto-lock job-controlled/admin-only doors when closed
            if (isJobControlled or isAdminOnly) and door:GetNWString("VEIN_Owner", "") == "" then
                if VEIN.DoorSystem.StartAutoLockOnClose then
                    VEIN.DoorSystem.StartAutoLockOnClose(door)
                    if VEIN.DoorSystem.GetLinkedDoors then
                        for _, linkedDoor in ipairs(VEIN.DoorSystem.GetLinkedDoors(door)) do
                            VEIN.DoorSystem.StartAutoLockOnClose(linkedDoor)
                        end
                    end
                end
                local legacyTimer = "VEIN_AutoLock_" .. door:EntIndex()
                if timer.Exists(legacyTimer) then
                    timer.Remove(legacyTimer)
                end
            end
        else
            door:Fire("Lock")
            door:SetNWBool("VEIN_Locked", true)
            VEIN.Chat(ply, "Door locked!")
            door:EmitSound("buttons/button14.wav")
            
            -- Cancel auto-lock-on-close if door is manually locked
            if VEIN.DoorSystem.ClearAutoLockOnClose then
                VEIN.DoorSystem.ClearAutoLockOnClose(door)
                if VEIN.DoorSystem.GetLinkedDoors then
                    for _, linkedDoor in ipairs(VEIN.DoorSystem.GetLinkedDoors(door)) do
                        VEIN.DoorSystem.ClearAutoLockOnClose(linkedDoor)
                    end
                end
            end
            local legacyTimer = "VEIN_AutoLock_" .. door:EntIndex()
            if timer.Exists(legacyTimer) then
                timer.Remove(legacyTimer)
            end
        end
        
        -- Call hook for persistence system
        hook.Run("VEIN_DoorModified", door)
        
        return true
    end
    
    function VEIN.DoorSystem.RepairDoor(door, ply)
        if not VEIN.DoorSystem.IsOwner(door, ply) then
            VEIN.Chat(ply, "You must own this door to repair it!")
            return false
        end
        
        if not door:GetNWBool("VEIN_Broken", false) then
            VEIN.Chat(ply, "This door doesn't need repair!")
            return false
        end
        
        local doorPrice = door:GetNWInt("VEIN_Price", 500)
        local repairCost = math.floor(doorPrice * 0.1) -- 10% of door price
        
        if not VEIN.DoorSystem.CanAfford(ply, repairCost) then
            local playerMoney = VEIN.DoorSystem.GetPlayerMoney(ply)
            VEIN.Chat(ply, "You need $" .. string.Comma(repairCost) .. " to repair this door! You have $" .. string.Comma(playerMoney))
            return false
        end
        
        -- Charge the player (using proper method)
        -- Check ConVar in real-time, not cached value
        local useCustomMoney = GetConVar("vein_use_custom_money"):GetBool()
        
        if useCustomMoney then
            local playerMoney = ply:GetNWInt("VEIN_Money", 0)
            ply:SetNWInt("VEIN_Money", playerMoney - repairCost)
        else
            if ply.addMoney then
                ply:addMoney(-repairCost)
            else
                local playerMoney = ply:GetNWInt("VEIN_Money", 0)
                ply:SetNWInt("VEIN_Money", playerMoney - repairCost)
            end
        end
        
        -- Repair the door
        door:SetNWBool("VEIN_Broken", false)
        door:EmitSound("buttons/button9.wav")
        
        VEIN.Chat(ply, "Door repaired for $" .. string.Comma(repairCost) .. "!")
        
        return true
    end
    
    local function ResolveAccessKeyFromTarget(targetPly, targetName)
        if IsValid(targetPly) then
            if targetPly:IsBot() then
                local nick = targetPly:Nick()
                if string.StartWith(nick, "BOT_") then
                    return nick, nick
                end
                return "BOT_" .. nick, nick
            end
            return targetPly:SteamID(), targetPly:Nick()
        end
        return targetName or "", targetName or ""
    end

    local function BuildAccessNames(doorIndex)
        local accessNames = {}
        local seen = {}
        local accessTable = VEIN.DoorSystem.DoorAccess[doorIndex] or {}
        for accessKey, _ in pairs(accessTable) do
            if isnumber(accessKey) then
                local name = tostring(accessTable[accessKey] or "")
                if not seen[name] then
                    seen[name] = true
                    table.insert(accessNames, name)
                end
            else
                local key = tostring(accessKey)
                local accessPly = player.GetBySteamID(key)
                if IsValid(accessPly) then
                    local name = accessPly:Nick()
                    if not seen[name] then
                        seen[name] = true
                        table.insert(accessNames, name)
                    end
                else
                    local name = key
                    if string.StartWith(key, "BOT_") then
                        name = string.sub(key, 5)
                    end
                    if name ~= "" and not seen[name] then
                        seen[name] = true
                        table.insert(accessNames, name)
                    end
                end
            end
        end
        return accessNames
    end

    function VEIN.DoorSystem.GiveAccess(door, owner, targetName)
        if not VEIN.DoorSystem.IsOwner(door, owner) then
            VEIN.Chat(owner, "You don't own this door!")
            return false
        end
        
        local target = nil
        for _, ply in pairs(player.GetAll()) do
            if string.lower(ply:Nick()) == string.lower(targetName) then
                target = ply
                break
            end
        end
        
        if not target then
            VEIN.Chat(owner, "Player '" .. targetName .. "' not found!")
            return false
        end
        
        local doorIndex = door:EntIndex()
        VEIN.DoorSystem.DoorAccess[doorIndex] = VEIN.DoorSystem.DoorAccess[doorIndex] or {}
        local accessKey = ResolveAccessKeyFromTarget(target, targetName)
        if accessKey == "" then return false end
        VEIN.DoorSystem.DoorAccess[doorIndex][accessKey] = true
        
        -- Sync access list to clients for UI purposes
        local accessNames = BuildAccessNames(doorIndex)
        door:SetNWString("VEIN_AccessList", table.concat(accessNames, ","))
        
        VEIN.Chat(owner, "Gave access to " .. target:Nick())
        VEIN.Chat(target, owner:Nick() .. " gave you door access!")
        
        return true
    end
    
    function VEIN.DoorSystem.RemoveAccess(door, owner, targetName)
        if not VEIN.DoorSystem.IsOwner(door, owner) then
            VEIN.Chat(owner, "You don't own this door!")
            return false
        end
        
        local doorIndex = door:EntIndex()
        if not VEIN.DoorSystem.DoorAccess[doorIndex] then
            VEIN.Chat(owner, "No access list for this door!")
            return false
        end
        
        -- Find target by name in current access list
        local targetKey = nil
        local targetLower = string.lower(targetName or "")
        for accessKey, _ in pairs(VEIN.DoorSystem.DoorAccess[doorIndex]) do
            local accessPly = player.GetBySteamID(tostring(accessKey))
            if IsValid(accessPly) and string.lower(accessPly:Nick()) == targetLower then
                targetKey = tostring(accessKey)
                break
            end
            local keyStr = tostring(accessKey)
            local displayName = keyStr
            if string.StartWith(keyStr, "BOT_") then
                displayName = string.sub(keyStr, 5)
            end
            if string.lower(displayName) == targetLower then
                targetKey = keyStr
                break
            end
        end
        
        if not targetKey then
            VEIN.Chat(owner, "Player '" .. targetName .. "' does not have access!")
            return false
        end
        
        -- Remove access
        VEIN.DoorSystem.DoorAccess[doorIndex][targetKey] = nil
        
        -- Sync updated access list to clients
        local accessNames = BuildAccessNames(doorIndex)
        door:SetNWString("VEIN_AccessList", table.concat(accessNames, ","))
        
        VEIN.Chat(owner, "Removed access from " .. targetName)
        
        -- Notify target if they're online
        local targetPly = player.GetBySteamID(targetKey)
        if IsValid(targetPly) then
            VEIN.Chat(targetPly, owner:Nick() .. " removed your door access!")
        end
        
        return true
    end
    
    function VEIN.DoorSystem.SellDoor(door, ply)
        if not VEIN.DoorSystem.IsOwner(door, ply) then
            VEIN.Chat(ply, "You don't own this door!")
            return false
        end
        
        -- Check if door is broken
        if door:GetNWBool("VEIN_Broken", false) then
            VEIN.Chat(ply, "This door is broken! Repair it before selling.")
            return false
        end
        
        -- Gather property or linked group (sell as a group)
        local groupDoors, usePropertyGroup = GetPurchaseGroup(door)
        
        -- Verify ownership for all doors in the group
        for _, groupDoor in ipairs(groupDoors) do
            if groupDoor:GetNWString("VEIN_Owner", "") ~= ply:SteamID() then
                VEIN.Chat(ply, "You must own all linked doors to sell them.")
                return false
            end
        end
        
        -- Get refund percentage from ConVar
        local refundPercent = GetConVar("vein_door_refund_percent"):GetInt() / 100
        local totalPrice = GetPurchaseTotalPrice(door, groupDoors, usePropertyGroup)
        local sellPrice = math.floor(totalPrice * refundPercent)
        
        -- Sell door group (add money back using proper method)
        VEIN.DoorSystem.AddPlayerMoney(ply, sellPrice)
        
        for _, groupDoor in ipairs(groupDoors) do
            VEIN.DoorSystem.OwnedDoors[groupDoor:EntIndex()] = nil
            VEIN.DoorSystem.DoorAccess[groupDoor:EntIndex()] = nil
            
            -- Reset door to default locked state
            groupDoor:SetNWString("VEIN_Owner", "")
            groupDoor:SetNWString("VEIN_OwnerName", "")
            groupDoor:SetNWString("VEIN_OwnerSteamID", "")
            groupDoor:SetNWString("VEIN_AccessData", "{}")
            local defaultLocked = groupDoor:GetNWBool("VEIN_DefaultLocked", false)
            groupDoor:SetNWBool("VEIN_Locked", defaultLocked)
            groupDoor:SetNWBool("VEIN_Buyable", true)
            
            if defaultLocked then
                groupDoor:Fire("Close")
                timer.Simple(0.5, function()
                    if IsValid(groupDoor) then
                        groupDoor:Fire("Lock")
                    end
                end)
            else
                groupDoor:Fire("Unlock")
            end
            
            -- Save door data (ownership cleared)
            hook.Run("VEIN_DoorModified", groupDoor)
        end
        
        VEIN.Chat(ply, "Doors sold for $" .. sellPrice .. "!")
        door:EmitSound("buttons/button15.wav")
        
        return true
    end

    local function ResetDoorOwnershipState(groupDoor)
        VEIN.DoorSystem.OwnedDoors[groupDoor:EntIndex()] = nil
        VEIN.DoorSystem.DoorAccess[groupDoor:EntIndex()] = nil
        groupDoor:SetNWString("VEIN_Owner", "")
        groupDoor:SetNWString("VEIN_OwnerName", "")
        groupDoor:SetNWString("VEIN_OwnerSteamID", "")
        groupDoor:SetNWString("VEIN_AccessData", "{}")
        groupDoor:SetNWString("VEIN_AccessList", "")
        local defaultLocked = groupDoor:GetNWBool("VEIN_DefaultLocked", false)
        groupDoor:SetNWBool("VEIN_Locked", defaultLocked)
        groupDoor:SetNWBool("VEIN_Buyable", true)

        if defaultLocked then
            groupDoor:Fire("Close")
            timer.Simple(0.5, function()
                if IsValid(groupDoor) then
                    groupDoor:Fire("Lock")
                end
            end)
        else
            groupDoor:Fire("Unlock")
        end

        hook.Run("VEIN_DoorModified", groupDoor)
    end

    function VEIN.DoorSystem.AutoSellOwnedDoors(ply)
        if not IsValid(ply) then return end

        local steamID = ply:SteamID()
        local refundPercent = GetConVar("vein_door_refund_percent"):GetInt() / 100
        local totalRefund = 0
        local processed = {}

        for _, door in ipairs(ents.GetAll()) do
            if IsValid(door) and door:GetClass():find("door") and door:GetNWString("VEIN_Owner", "") == steamID then
                local doorIndex = door:EntIndex()
                if processed[doorIndex] then
                    -- already handled
                else
                    local groupDoors, usePropertyGroup = GetPurchaseGroup(door)
                    local ownedGroup = true
                    for _, groupDoor in ipairs(groupDoors) do
                        if groupDoor:GetNWString("VEIN_Owner", "") ~= steamID then
                            ownedGroup = false
                            break
                        end
                    end

                    local sellDoors = {}
                    if ownedGroup then
                        sellDoors = groupDoors
                    else
                        sellDoors = {door}
                        usePropertyGroup = false
                    end

                    local refundBase = usePropertyGroup and GetPurchaseTotalPrice(door, sellDoors, true) or GetPurchaseTotalPrice(door, sellDoors, false)
                    local refund = math.floor(refundBase * refundPercent)
                    totalRefund = totalRefund + refund

                    for _, groupDoor in ipairs(sellDoors) do
                        if IsValid(groupDoor) then
                            processed[groupDoor:EntIndex()] = true
                            ResetDoorOwnershipState(groupDoor)
                        end
                    end
                end
            end
        end

        if totalRefund > 0 then
            VEIN.DoorSystem.AddPlayerMoney(ply, totalRefund)
        end
    end

    hook.Add("PlayerDisconnected", "VEIN_AutoSellDoorsOnDisconnect", function(ply)
        if not IsValid(ply) then return end
        VEIN.DoorSystem.AutoSellOwnedDoors(ply)
    end)
    
    -- Handle door interactions (called from Keys weapon)
    function VEIN.DoorSystem.HandleDoorInteraction(ply, door)
        local owner = VEIN.DoorSystem.GetOwner(door)
        local isBuyable = door:GetNWBool("VEIN_Buyable", false)
        local allowOwnership = door:GetNWBool("VEIN_AllowOwnership", true)
        local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
        local isStaticDoor = (not allowOwnership) and (not isJobControlled)
        local isDoorAdmin = VEIN.Settings and VEIN.Settings.IsDoorAdmin and VEIN.Settings.IsDoorAdmin(ply)
        
        if not owner and isBuyable then
            -- Buy door
            VEIN.DoorSystem.BuyDoor(door, ply)
        elseif isJobControlled and owner == "" then
            -- Job-controlled doors cannot be managed by players, only admins
            if ply:IsAdmin() or ply:IsSuperAdmin() or isDoorAdmin then
                net.Start("VEIN_Show3DMenu")
                net.WriteEntity(door)
                net.Send(ply)
            else
                VEIN.Chat(ply, "Job-controlled doors cannot be managed!")
            end
            
            -- Trigger hologram display for job-controlled doors
            TriggerJobDoorHologram(door, ply)
        elseif owner then
            -- Only owners or admins can open the options menu
            if ply:IsAdmin() or ply:IsSuperAdmin() or isDoorAdmin or owner == ply:SteamID() then
                net.Start("VEIN_Show3DMenu")
                net.WriteEntity(door)
                net.Send(ply)
            else
                VEIN.Chat(ply, "You don't own this door!")
            end
        elseif isStaticDoor and (ply:IsAdmin() or ply:IsSuperAdmin() or isDoorAdmin) then
            -- Static admin-only door - show menu to admins
            net.Start("VEIN_Show3DMenu")
            net.WriteEntity(door)
            net.Send(ply)
        else
            VEIN.Chat(ply, "This door is not for sale!")
        end
    end
    
    -- Anti-spam storage for door messages
    VEIN.DoorSystem.MessageCooldowns = VEIN.DoorSystem.MessageCooldowns or {}
    
    -- Hook to detect when players try to use doors
    hook.Add("PlayerUse", "VEIN_CheckLockedDoors", function(ply, ent)
        if not IsValidDoor(ent) then return end
        
        -- Check if this door is managed by our system
        local owner = ent:GetNWString("VEIN_Owner", "")
        local isBuyable = ent:GetNWBool("VEIN_Buyable", false)
        local isJobControlled = ent:GetNWBool("VEIN_JobControlled", false)
        local isAdminOnly = ent:GetNWBool("VEIN_AdminOnly", false)
        
        -- Only give feedback for doors in our system
        if owner ~= "" or isBuyable then
            local isLocked = ent:GetNWBool("VEIN_Locked", false)
            if not isLocked and owner == "" and (isJobControlled or isAdminOnly) then
                if VEIN.DoorSystem.StartAutoLockOnClose then
                    VEIN.DoorSystem.StartAutoLockOnClose(ent)
                end
            end
            
            if isLocked then
                -- Create unique key for this player and door
                local cooldownKey = ply:SteamID() .. "_" .. ent:EntIndex()
                local currentTime = CurTime()
                
                -- Check cooldown (2 second cooldown per player per door for both sound and message)
                local lastMessageTime = VEIN.DoorSystem.MessageCooldowns[cooldownKey] or 0
                if currentTime - lastMessageTime >= 2 then
                    -- Play door handle sound with cooldown
                    ent:EmitSound("doors/handle_pushbar_locked1.wav", 75, 100, 0.8)
                    -- Show the locked message in red
                    VEIN.Chat(ply, "The door is locked and requires a key.")
                    VEIN.DoorSystem.MessageCooldowns[cooldownKey] = currentTime
                    
                    -- Trigger hologram display for job-controlled doors
                    TriggerJobDoorHologram(ent, ply)
                end
                
                -- Check if player has access to allow opening
                local hasAccess = false
                if owner ~= "" then
                    -- Door is owned - check if player is owner or has access
                    if owner == ply:Nick() then
                        hasAccess = true
                    else
                        -- Check if player has been given access
                        local doorAccess = VEIN.DoorSystem.DoorAccess[ent:EntIndex()] or {}
                        hasAccess = doorAccess[ply:Nick()] == true
                    end
                else
                    -- Door is for sale but locked - no one has access
                    hasAccess = false
                end
                
                if not hasAccess then
                    return false -- Prevent door from opening
                end
            end
        end
        
        -- Allow normal door usage if not locked or player has access
        return
    end)
    
    -- Network handlers
    local function IsDoorEntity(ent)
        return IsValid(ent) and isstring(ent:GetClass()) and ent:GetClass():find("door")
    end

    local function IsWithinDoorRange(ply, door, maxDist)
        if not IsValid(ply) or not IsValid(door) then return false end
        if not maxDist then return true end
        return ply:GetPos():DistToSqr(door:GetPos()) <= (maxDist * maxDist)
    end

    local function ValidateDoorRequest(ply, door, requireVein, maxDist)
        if not IsDoorEntity(door) then return false end
        if requireVein and not door:GetNWBool("VEIN_IsVEINDoor", false) then return false end
        if maxDist and not IsWithinDoorRange(ply, door, maxDist) then return false end
        return true
    end

    net.Receive("VEIN_CreateDoor", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminCreateDoor") then return end
        local door = net.ReadEntity()
        local doorName = net.ReadString()
        local price = net.ReadUInt(32)
        local isLocked = net.ReadBool()
        local doorType = net.ReadString()
        local doorMaterial = net.ReadString()
        local allowOwnership = net.ReadBool()
        local lockName = net.ReadBool()
        local jobControlled = net.ReadBool()
        local controlJobs = Net.ReadTeamList()
        local propertyGroupName = net.ReadString()
        local propertyCustomPrice = net.ReadInt(32)
        if not ValidateDoorRequest(ply, door, false, 250) then return end

        VEIN.DoorSystem.CreateDoor(door, ply, doorName, price, isLocked, doorType, doorMaterial, allowOwnership, lockName, jobControlled, controlJobs)
        if VEIN.DoorSystem and VEIN.DoorSystem.SetPropertyGroup then
            VEIN.DoorSystem.SetPropertyGroup(door, propertyGroupName, propertyCustomPrice)
        end
    end)
    
    net.Receive("VEIN_ModifyDoor", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminModifyDoor") then return end
        
        local door = net.ReadEntity()
        local doorName = net.ReadString()
        local price = net.ReadInt(32)
        local isLocked = net.ReadBool()
        local doorType = net.ReadString()
        local doorMaterial = net.ReadString()
        local allowOwnership = net.ReadBool()
        local lockName = net.ReadBool()
        local jobControlled = net.ReadBool()
        local controlJobs = Net.ReadTeamList()
        local propertyGroupName = net.ReadString()
        local propertyCustomPrice = net.ReadInt(32)
        
        if not ValidateDoorRequest(ply, door, true, 250) then return end
        
        -- If job controlled, force ownership off and handle existing ownership
        if jobControlled then
            allowOwnership = false
            
            -- Check if door is currently owned
            local currentOwner = door:GetNWString("VEIN_Owner", "")
            if currentOwner ~= "" then
                -- Find the owner player and give full refund
                local doorPrice = door:GetNWInt("VEIN_Price", 500)
                for _, p in pairs(player.GetAll()) do
                    if p:Nick() == currentOwner then
                        VEIN.DoorSystem.AddPlayerMoney(p, doorPrice)
                        VEIN.Chat(p, "Your door was converted to a job-controlled door. You received a full refund of $" .. doorPrice)
                        break
                    end
                end
                
                -- Remove ownership
                VEIN.DoorSystem.OwnedDoors[door:EntIndex()] = nil
                VEIN.DoorSystem.DoorAccess[door:EntIndex()] = nil
                door:SetNWString("VEIN_Owner", "")
                door:SetNWBool("VEIN_Buyable", false)
            end
            
            -- Job doors are always locked when created/modified
            isLocked = true
        end
        
        -- Update door settings
        door:SetNWString("VEIN_DoorName", doorName)
        door:SetNWInt("VEIN_Price", price)
        door:SetNWBool("VEIN_DefaultLocked", isLocked)
        door:SetNWString("VEIN_DoorType", doorType)
        door:SetNWString("VEIN_DoorMaterial", doorMaterial)
        door:SetNWBool("VEIN_AllowOwnership", allowOwnership)
        door:SetNWBool("VEIN_LockName", lockName or false)
        
        -- Only set buyable if ownership is allowed AND door has no owner
        local currentOwner = door:GetNWString("VEIN_Owner", "")
        door:SetNWBool("VEIN_Buyable", allowOwnership and currentOwner == "")
        
        door:SetNWBool("VEIN_AdminOnly", (not allowOwnership) and not jobControlled)
        
        -- Update job control settings
        door:SetNWBool("VEIN_JobControlled", jobControlled or false)
        door:SetNWString("VEIN_ControlJobs", util.TableToJSON(controlJobs or {}))
        
        -- Get material data and update all sound properties
        local matData = VEIN.CustomDoors.GetMaterialData(doorMaterial)
        door:SetNWInt("VEIN_KickTime", matData.kickTime)
        door:SetNWString("VEIN_LockSound", matData.lockSound)
        door:SetNWString("VEIN_UnlockSound", matData.unlockSound)
        door:SetNWString("VEIN_KickSound", matData.kickSound)
        door:SetNWString("VEIN_BreakSound", matData.breakSound)
        door:SetNWInt("VEIN_LockPitch", matData.lockPitch or 100)
        door:SetNWInt("VEIN_UnlockPitch", matData.unlockPitch or 100)
        door:SetNWInt("VEIN_KickPitch", matData.kickPitch or 100)
        door:SetNWInt("VEIN_BreakPitch", matData.breakPitch or 100)
        
        -- Apply lock state
        if isLocked then
            door:Fire("Lock")
            door:SetNWBool("VEIN_Locked", true)
        else
            door:Fire("Unlock")
            door:SetNWBool("VEIN_Locked", false)
        end
        
        -- Client message is sent from GUI, don't send duplicate from server
        door:EmitSound("buttons/button14.wav")
        
        if VEIN.DoorSystem and VEIN.DoorSystem.SetPropertyGroup then
            VEIN.DoorSystem.SetPropertyGroup(door, propertyGroupName, propertyCustomPrice)
        end

        -- Call hook for persistence system
        hook.Run("VEIN_DoorModified", door)
    end)
    
    net.Receive("VEIN_BuyDoor", function(len, ply)
        local door = net.ReadEntity()
        if not ValidateDoorRequest(ply, door, true, 200) then return end
        VEIN.DoorSystem.BuyDoor(door, ply)
    end)
    
    net.Receive("VEIN_ToggleLock", function(len, ply)
        local door = net.ReadEntity()
        if not ValidateDoorRequest(ply, door, true, 200) then return end
        VEIN.DoorSystem.ToggleLock(door, ply)
    end)
    
    net.Receive("VEIN_RepairDoor", function(len, ply)
        local door = net.ReadEntity()
        if not ValidateDoorRequest(ply, door, true, 200) then return end
        VEIN.DoorSystem.RepairDoor(door, ply)
    end)
    
    net.Receive("VEIN_SellDoor", function(len, ply)
        local door = net.ReadEntity()
        if not ValidateDoorRequest(ply, door, true, 200) then return end
        VEIN.DoorSystem.SellDoor(door, ply)
    end)
    
    net.Receive("VEIN_GiveAccess", function(len, ply)
        local door = net.ReadEntity()
        local targetName = net.ReadString()
        if not ValidateDoorRequest(ply, door, true, 200) then return end
        VEIN.DoorSystem.GiveAccess(door, ply, targetName)
    end)
    
    net.Receive("VEIN_RemoveAccess", function(len, ply)
        local door = net.ReadEntity()
        local targetName = net.ReadString()
        if not ValidateDoorRequest(ply, door, true, 200) then return end
        VEIN.DoorSystem.RemoveAccess(door, ply, targetName)
    end)
    
    net.Receive("VEIN_RequestJobList", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminModifyDoor") and not HasDoorAdminPermission(ply, "adminCreateDoor") then return end
        
        -- Get all DarkRP jobs
        local jobs = {}
        if DarkRP and RPExtraTeams then
            for k, v in pairs(RPExtraTeams) do
                table.insert(jobs, {
                    name = v.name,
                    command = v.command,
                    team = k,
                    color = v.color or Color(255, 255, 255)
                })
            end
        else
            -- Fallback if not DarkRP
            table.insert(jobs, {name = "Citizen", command = "citizen", team = 1, color = Color(255, 255, 255)})
        end
        
        -- Send to client
        net.Start("VEIN_JobListData")
        Net.WriteJobList(jobs)
        net.Send(ply)
    end)
    
    net.Receive("VEIN_ChangeDoorName", function(len, ply)
        local door = net.ReadEntity()
        local newName = net.ReadString()
        if not ValidateDoorRequest(ply, door, true, 200) then return end
        
        -- Check if player owns this door
        if not VEIN.DoorSystem.IsOwner(door, ply) then
            VEIN.Chat(ply, "You don't own this door!")
            return
        end
        
        -- Update door name
        door:SetNWString("VEIN_DoorName", newName)
        
        -- Call hook for persistence system
        hook.Run("VEIN_DoorModified", door)
        
        if newName == "" then
            VEIN.Chat(ply, "Door name reset to default")
        else
            VEIN.Chat(ply, "Door name changed to: " .. newName)
        end
    end)
    
    net.Receive("VEIN_AdminForceSell", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminForceSellDoor") then return end
        
        local door = net.ReadEntity()
        if not ValidateDoorRequest(ply, door, true, 250) then return end

        local groupDoors, usePropertyGroup = GetPurchaseGroup(door)
        local ownerSteamID = ""
        local ownerName = ""
        for _, groupDoor in ipairs(groupDoors) do
            if IsValid(groupDoor) then
                local groupOwner = groupDoor:GetNWString("VEIN_Owner", "")
                if groupOwner ~= "" then
                    ownerSteamID = groupDoor:GetNWString("VEIN_OwnerSteamID", groupOwner)
                    ownerName = groupDoor:GetNWString("VEIN_OwnerName", "")
                    break
                end
            end
        end
        
        if ownerSteamID == "" then
            VEIN.Chat(ply, "This door is not owned!")
            return
        end
        
        -- Give 100% refund to owner for all group doors
        local totalPrice = GetPurchaseTotalPrice(door, groupDoors, usePropertyGroup)
        
        local ownerPly = player.GetBySteamID(ownerSteamID)
        if not IsValid(ownerPly) and ownerName ~= "" then
            for _, p in pairs(player.GetAll()) do
                if p:Nick() == ownerName then
                    ownerPly = p
                    break
                end
            end
        end
        
        if IsValid(ownerPly) and totalPrice > 0 then
            VEIN.DoorSystem.AddPlayerMoney(ownerPly, totalPrice)
            VEIN.Chat(ownerPly, "[ADMIN] Your door group was force sold! You received a full refund of $" .. totalPrice)
        end
        
        -- Reset ownership for all linked doors but keep them buyable
        for _, groupDoor in ipairs(groupDoors) do
            if IsValid(groupDoor) then
                VEIN.DoorSystem.OwnedDoors[groupDoor:EntIndex()] = nil
                VEIN.DoorSystem.DoorAccess[groupDoor:EntIndex()] = nil
                
                groupDoor:SetNWString("VEIN_Owner", "")
                groupDoor:SetNWString("VEIN_OwnerName", "")
                groupDoor:SetNWString("VEIN_OwnerSteamID", "")
                groupDoor:SetNWString("VEIN_AccessData", "{}")
                groupDoor:SetNWString("VEIN_AccessList", "")
                  local defaultLocked = groupDoor:GetNWBool("VEIN_DefaultLocked", false)
                  groupDoor:SetNWBool("VEIN_Locked", defaultLocked)
                  groupDoor:SetNWBool("VEIN_Buyable", true)
                  if defaultLocked then
                      groupDoor:Fire("Close")
                      timer.Simple(0.5, function()
                          if IsValid(groupDoor) then
                              groupDoor:Fire("Lock")
                          end
                      end)
                  else
                      groupDoor:Fire("Unlock")
                  end
                
                hook.Run("VEIN_DoorModified", groupDoor)
            end
        end
        
        VEIN.Chat(ply, "[ADMIN] Door group force sold! It is now available for purchase again.")
        door:EmitSound("buttons/button15.wav")
        
        print("[VEIN] Admin " .. ply:Nick() .. " force sold door group owned by " .. ownerSteamID)
    end)
    
    net.Receive("VEIN_RemoveDoor", function(len, ply)
        if not HasDoorAdminPermission(ply, "adminDeleteDoor") then return end
        local door = net.ReadEntity()
        if not ValidateDoorRequest(ply, door, true, 250) then return end
        
        -- If owned, force-sell first (refund percent) before removal
        local owner = door:GetNWString("VEIN_Owner", "")
        if owner ~= "" then
            local ownerPly = player.GetBySteamID(owner)
            if not IsValid(ownerPly) then
                local ownerName = door:GetNWString("VEIN_OwnerName", "")
                if ownerName ~= "" then
                    for _, p in pairs(player.GetAll()) do
                        if p:Nick() == ownerName then
                            ownerPly = p
                            break
                        end
                    end
                end
            end

            local groupDoors, usePropertyGroup = GetPurchaseGroup(door)
            local ownedGroupDoors = {}
            for _, groupDoor in ipairs(groupDoors) do
                if IsValid(groupDoor) and groupDoor:GetNWString("VEIN_Owner", "") == owner then
                    table.insert(ownedGroupDoors, groupDoor)
                end
            end

            local refundBase = 0
            if #ownedGroupDoors > 0 then
                refundBase = GetPurchaseTotalPrice(door, ownedGroupDoors, usePropertyGroup)
            end
            local refund = math.floor(refundBase)
            if IsValid(ownerPly) and refund > 0 then
                VEIN.DoorSystem.AddPlayerMoney(ownerPly, refund)
                VEIN.Chat(ownerPly, "Door removed! Refund: $" .. refund)
            end

            for _, groupDoor in ipairs(ownedGroupDoors) do
                if IsValid(groupDoor) then
                    ResetDoorOwnershipState(groupDoor)
                end
            end
        end
        
        -- Reset door completely - REMOVE ALL VEIN DATA
        VEIN.DoorSystem.OwnedDoors[door:EntIndex()] = nil
        VEIN.DoorSystem.DoorAccess[door:EntIndex()] = nil
        
        -- Remove auto-lock timer if it exists
        local timerName = "VEIN_AutoLock_" .. door:EntIndex()
        if timer.Exists(timerName) then
            timer.Remove(timerName)
        end
        
        door:SetNWBool("VEIN_Buyable", false)
        door:SetNWString("VEIN_Owner", "")
        door:SetNWString("VEIN_OwnerName", "")
        door:SetNWString("VEIN_OwnerSteamID", "")
        door:SetNWString("VEIN_DoorName", "")
        door:SetNWString("VEIN_AccessData", "{}")
        door:SetNWInt("VEIN_Price", 0)
        door:SetNWBool("VEIN_Locked", false)
        door:SetNWBool("VEIN_DefaultLocked", false)
        door:SetNWString("VEIN_Creator", "")
        door:SetNWString("VEIN_DoorGroup", "") -- Clear door group
        door:SetNWString("VEIN_AllowedJobs", "[]") -- Clear door group jobs
        door:SetNWBool("VEIN_JobControlled", false)
        door:SetNWString("VEIN_ControlJobs", "[]")
        door:SetNWBool("VEIN_AllowOwnership", true) -- Reset to default
        door:SetNWBool("VEIN_AdminOnly", false) -- Reset admin-only flag
        door:SetNWBool("VEIN_Broken", false) -- Clear broken state
        door:SetNWBool("VEIN_AutoLockOnClose", false)
        door:SetNWBool("VEIN_IsVEINDoor", false) -- CRITICAL: Mark as NOT a VEIN door anymore
        
        -- Clean up door linking (group-based)
        if VEIN.DoorSystem and VEIN.DoorSystem.UnlinkDoor then
            VEIN.DoorSystem.UnlinkDoor(door)
        else
            door:SetNWEntity("VEIN_LinkedDoor", NULL)
        end
        
        -- Clean up property group membership
        if VEIN.DoorSystem and VEIN.DoorSystem.ClearPropertyGroup then
            VEIN.DoorSystem.ClearPropertyGroup(door)
        else
            door:SetNWInt("VEIN_PropertyGroup", 0)
            door:SetNWString("VEIN_PropertyGroupName", "")
            door:SetNWInt("VEIN_PropertyCustomPrice", 0)
            door:SetNWInt("VEIN_PropertyCount", 1)
            door:SetNWInt("VEIN_PropertyTotalPrice", 0)
        end
        
        -- Clean up broken door client-side effects (particles, sounds)
        door.NextSparkTime = nil
        
        door:Fire("Unlock")
        
        -- Call hook for persistence system
        hook.Run("VEIN_DoorRemoved", door)
        
        VEIN.Chat(ply, "Door removed from system!")
        door:EmitSound("buttons/button15.wav")
    end)
    
    -- Network handler for remove confirmation GUI
    net.Receive("VEIN_OpenRemoveConfirm", function(len, ply)
        local door = net.ReadEntity()
        if not IsValid(door) then return end
        
        -- Send back to client to open GUI
        net.Start("VEIN_OpenRemoveConfirm")
        net.WriteEntity(door)
        net.Send(ply)
    end)
end

-- Utility function for tool (outside SERVER block)
local function IsValidDoor(ent)
    if not IsValid(ent) then return false end
    local class = ent:GetClass()
    return class == "func_door" or class == "func_door_rotating" or class == "prop_door_rotating"
end

-- Tool functions
function TOOL:LeftClick(trace)
    local ply = self:GetOwner()
    local door = trace.Entity
    
    -- ADMIN / DOOR ADMIN CHECK
    if SERVER then
        local linkingMode = ply:KeyDown(IN_SPEED)
        local requiredPerm = linkingMode and "adminModifyDoor" or "adminCreateDoor"
        if not HasDoorAdminPermission(ply, requiredPerm) then
            VEIN.Chat(ply, "You don't have permission to use the Door Manager tool!")
            return false
        end
    end
    
    if not IsValidDoor(door) then
        if SERVER then
            VEIN.Chat(ply, "Target must be a door!")
        end
        return false
    end
    
    -- LINKING MODE: Hold Shift + Left Click to link two doors
    if ply:KeyDown(IN_SPEED) then
        if CLIENT then return true end -- Let server handle it
        
        -- Check if door is a VEIN door
        if not door:GetNWBool("VEIN_IsVEINDoor", false) then
            VEIN.Chat(ply, "Both doors must be VEIN doors to link them!")
            return false
        end
        
        -- Store first door or link/unlink with stored door
        local steamID = ply:SteamID()
        local firstDoor = self.FirstLinkedDoors[steamID]

        local function GetGroupId(ent)
            return VEIN.DoorSystem.GetLinkedGroupId and VEIN.DoorSystem.GetLinkedGroupId(ent) or ent:GetNWInt("VEIN_LinkGroup", 0)
        end

        if not IsValid(firstDoor) or firstDoor == door then
            -- This is the first door selected
            self.FirstLinkedDoors[steamID] = door
            if GetGroupId(door) > 0 then
                self.LinkModes[steamID] = "unlink"
                VEIN.Chat(ply, "Unlinking mode: Shift + Left Click a linked door to remove it from this group.")
            else
                self.LinkModes[steamID] = "link"
                VEIN.Chat(ply, "First door selected! Hold Shift + Left Click on the second door to link them.")
            end
            ply:EmitSound("buttons/button14.wav")
            return true
        else
            local mode = self.LinkModes[steamID] or "link"
            if mode == "unlink" then
                local groupA = GetGroupId(firstDoor)
                local groupB = GetGroupId(door)
                if groupA <= 0 or groupA ~= groupB then
                    VEIN.Chat(ply, "That door is not linked to the first door.")
                else
                    if VEIN.DoorSystem and VEIN.DoorSystem.UnlinkDoor then
                        VEIN.DoorSystem.UnlinkDoor(door)
                    end
                    VEIN.Chat(ply, "Door unlinked from the group.")
                    ply:EmitSound("buttons/button14.wav")

                    if VEIN.DoorSystem and VEIN.DoorSystem.GetLinkedGroup then
                        for _, ent in ipairs(VEIN.DoorSystem.GetLinkedGroup(firstDoor) or {}) do
                            if IsValid(ent) then
                                hook.Run("VEIN_DoorModified", ent)
                            end
                        end
                    else
                        if IsValid(firstDoor) then
                            hook.Run("VEIN_DoorModified", firstDoor)
                        end
                    end
                    if IsValid(door) then
                        hook.Run("VEIN_DoorModified", door)
                    end
                end

                self.FirstLinkedDoors[steamID] = nil
                self.LinkModes[steamID] = nil
                return true
            end

            -- LINK MODE: This is the second door - link groups
            local ok, groupId = VEIN.DoorSystem.LinkDoors(firstDoor, door)
            if not ok then
                if groupId == "Already linked" then
                    VEIN.Chat(ply, "These doors are already linked.")
                else
                    VEIN.Chat(ply, "Failed to link doors.")
                end
            else
                local linkCount = door:GetNWInt("VEIN_LinkCount", 2)
                VEIN.Chat(ply, "Doors linked! Total linked: " .. linkCount)
                ply:EmitSound("buttons/button14.wav")
                
                -- Call hook for persistence system to save all doors in the group
                local group = VEIN.DoorSystem.LinkedGroups[groupId] or {door, firstDoor}
                for _, ent in ipairs(group) do
                    if IsValid(ent) then
                        hook.Run("VEIN_DoorModified", ent)
                    end
                end
            end
            
            -- Reset stored door/mode
            self.FirstLinkedDoors[steamID] = nil
            self.LinkModes[steamID] = nil
            return true
        end
    else
        -- Reset linking mode if not holding shift
        if SERVER then
            local steamID = ply:SteamID()
            self.FirstLinkedDoors[steamID] = nil
            self.LinkModes[steamID] = nil
        end
    end
    
    if SERVER then
        -- Check if door is already a VEIN door
        local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
        local owner = door:GetNWString("VEIN_Owner", "")
        local ownerName = door:GetNWString("VEIN_OwnerName", "")
        local ownerDisplay = ownerName ~= "" and ownerName or owner
        
        if isVEINDoor and owner ~= "" then
            VEIN.Chat(ply, "This door is already owned by " .. ownerDisplay .. "!")
            return false
        end
        
        if isVEINDoor then
            VEIN.Chat(ply, "This door is already setup! Use right-click to modify it.")
            return false
        end
        
        -- Get the surface normal of the clicked face (like weld tool)
        local hitNormal = trace.HitNormal
        local hitPos = trace.HitPos
        
        -- Calculate proper visual center for different door types
        local doorClass = door:GetClass()
        local visualCenter
        
        -- ALL rotating doors (func and prop) have origin at hinge point
        -- We need to transform local bounding box center to world space
        local mins, maxs = door:OBBMins(), door:OBBMaxs()
        local localCenter = (mins + maxs) / 2
        visualCenter = door:LocalToWorld(localCenter)
        
        -- Store hologram anchor in local space so it follows door movement/opening.
        SetDoorHologramAnchor(door, hitNormal, hitPos, visualCenter)
        
        -- Check if player has copied door data and send it to client
        local copiedData = VEIN.DoorSystem.CopiedDoorData[ply:SteamID()] or {}
        
        -- Send GUI with optional copied data
        net.Start("VEIN_OpenDoorGUI")
        net.WriteEntity(door)
        Net.WriteCopiedDoorData(copiedData)
        net.Send(ply)
    end
    
    return true
end

function TOOL:RightClick(trace)
    local ply = self:GetOwner()
    local door = trace.Entity
    
    -- ADMIN / DOOR ADMIN CHECK
    if SERVER and not HasDoorAdminPermission(ply, "adminModifyDoor") then
        VEIN.Chat(ply, "You don't have permission to use the Door Manager tool!")
        return false
    end
    
    if not IsValidDoor(door) then
        if SERVER then
            VEIN.Chat(ply, "Target must be a door!")
        end
        return false
    end
    
    if SERVER then
        -- Check if door is in the VEIN system
        local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
        
        if not isVEINDoor then
            VEIN.Chat(ply, "This door is not managed by VEIN system! Create it first with left-click.")
            return false
        end
        
        -- Send network message to client to open modify GUI
        net.Start("VEIN_OpenModifyDoorGUI")
        net.WriteEntity(door)
        net.Send(ply)
    end
    
    return true
end

function TOOL:Reload(trace)
    -- RELOAD MUST RUN CLIENT-SIDE to open GUI
    if SERVER then return true end -- Let client handle it
    
    local ply = self:GetOwner()
    local door = trace.Entity
    
    local canEditGroups = ply:IsAdmin() or ply:IsSuperAdmin()
        or (VEIN.DoorAdmin and VEIN.DoorAdmin.isDoorAdmin and VEIN.DoorAdmin.perms and VEIN.DoorAdmin.perms.adminEditGroupsDoor)

    -- ADMIN / DOOR ADMIN CHECK (client-side)
    if not canEditGroups then
        VEIN.Chat(ply, "You don't have permission to edit door groups!")
        return false
    end
    
    if not IsValidDoor(door) then
        VEIN.Chat(ply, "Target must be a door!")
        return false
    end
    
    -- Check if door is in the VEIN system
    local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
    
    if not isVEINDoor then
        VEIN.Chat(ply, "This door is not managed by VEIN system! Create it first with left-click.")
        return false
    end
    
    -- Check if door is job-controlled (prevent editing with R key)
    local isJobControlled = door:GetNWBool("VEIN_JobControlled", false)
    if isJobControlled then
        VEIN.Chat(ply, "This is a job-controlled door! Use right-click modify menu to change job restrictions.")
        surface.PlaySound("buttons/button10.wav")
        return false
    end
    
    -- Open the door group/jobs editor
    if VEIN.DoorGroups and VEIN.DoorGroups.OpenEditor then
        VEIN.DoorGroups.OpenEditor(door)
        surface.PlaySound("buttons/button9.wav")
    else
        VEIN.Chat(ply, "Door group system not loaded!")
    end
    
    return true
end

function TOOL:Deploy(trace)
    -- Deploy = Middle Mouse Button
    -- Note: Deploy() is called when switching to this tool (trace will be nil)
    -- It's also called manually in Think with a proper trace when middle mouse is pressed
    
    -- If no trace provided (switching to tool), just return true
    if not trace or type(trace) ~= "table" or not trace.Entity then 
        return true 
    end
    
    local ply = self:GetOwner()
    if not IsValid(ply) then return false end
    
    -- ADMIN ONLY CHECK
    if SERVER and not (ply:IsAdmin() or ply:IsSuperAdmin()) then
        VEIN.Chat(ply, "Only admins can use the Door Manager tool!")
        return false
    end
    
    local door = trace.Entity
    
    if not IsValidDoor(door) then
        if SERVER then
            VEIN.Chat(ply, "Target must be a door!")
        end
        return false
    end
    
    if SERVER then
        -- Check if door is in the VEIN system
        local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
        
        if not isVEINDoor then
            VEIN.Chat(ply, "This door is not managed by VEIN system! Create it first with left-click.")
            return false
        end
        
        -- Copy door settings (exclude owner info)
        local copiedData = {
            name = door:GetNWString("VEIN_DoorName", ""),
            price = door:GetNWInt("VEIN_Price", 500),
            doorType = door:GetNWString("VEIN_DoorType", "Residential"),
            doorMaterial = door:GetNWString("VEIN_DoorMaterial", "Light Metal"),
            propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", ""),
            propertyCustomPrice = door:GetNWInt("VEIN_PropertyCustomPrice", 0),
            kickTime = door:GetNWInt("VEIN_KickTime", 25),
            doorGroup = door:GetNWString("VEIN_DoorGroup", ""),
            allowedJobs = door:GetNWString("VEIN_AllowedJobs", ""), -- DarkRP door groups
            controlJobs = door:GetNWString("VEIN_ControlJobs", ""), -- Job-controlled doors
            defaultLocked = door:GetNWBool("VEIN_DefaultLocked", false),
            
            -- Handle ownership settings:
            -- If door was static (adminOnly=true) OR job-controlled, keep job settings
            -- If door was owned or for sale, make it FOR SALE (allowOwnership=true, buyable=true)
            wasStatic = door:GetNWBool("VEIN_AdminOnly", false),
            wasJobControlled = door:GetNWBool("VEIN_JobControlled", false)
        }
        
        -- If it was static OR job-controlled, keep job-controlled status
        -- Otherwise, make it buyable
        if copiedData.wasJobControlled then
            -- Keep as job-controlled door
            copiedData.allowOwnership = false
            copiedData.buyable = false
            copiedData.adminOnly = false -- Not admin-only, just job-restricted
        elseif copiedData.wasStatic then
            -- Keep as static admin door
            copiedData.allowOwnership = false
            copiedData.buyable = false
            copiedData.adminOnly = true
        else
            -- Make buyable
            copiedData.allowOwnership = true
            copiedData.buyable = true
            copiedData.adminOnly = false
        end
        
        -- Store copied data for this player
        VEIN.DoorSystem.CopiedDoorData[ply:SteamID()] = copiedData
        
        -- Send copy notification to client for HUD display
        net.Start("VEIN_DoorCopied")
        Net.WriteCopiedDoorData(copiedData)
        net.Send(ply)
    end
    
    return true
end

-- Think hook to handle middle mouse button manually (Deploy doesn't always work)
function TOOL:Think()
    local ply = self:GetOwner()
    if not IsValid(ply) then return end
    
    -- Check for middle mouse button press (MOUSE3 = 107 in GMod)
    if CLIENT and input.IsMouseDown(MOUSE_MIDDLE) then
        -- Check if we haven't processed this click yet
        if not self.MiddleMouseHeld then
            self.MiddleMouseHeld = true
            -- Send to server to copy door
            local trace = ply:GetEyeTrace()
            if IsValid(trace.Entity) and IsValidDoor(trace.Entity) then
                net.Start("VEIN_CopyDoorSettings")
                net.WriteEntity(trace.Entity)
                net.SendToServer()
            end
        end
    else
        self.MiddleMouseHeld = false
    end
end

-- Server-side network receiver for middle mouse copy
if SERVER then
    util.AddNetworkString("VEIN_CopyDoorSettings")
    
    net.Receive("VEIN_CopyDoorSettings", function(len, ply)
        local door = net.ReadEntity()
        
        if not IsValid(door) or not IsValidDoor(door) then
            VEIN.Chat(ply, "Target must be a door!")
            return
        end
        
        -- Check if door is in the VEIN system
        local isVEINDoor = door:GetNWBool("VEIN_IsVEINDoor", false)
        
        -- If door is NOT in VEIN system, paste the copied data
        if not isVEINDoor then
            local copiedData = VEIN.DoorSystem.CopiedDoorData[ply:SteamID()]
            if not copiedData then
                VEIN.Chat(ply, "Can only copy existing doors.")
                return
            end
            
            -- Get the trace for proper rotation (like left-click does)
            local trace = ply:GetEyeTrace()
            if trace.Entity ~= door then
                VEIN.Chat(ply, "Invalid door target!")
                return
            end
            
            -- Store the surface normal, hit position, and visual center for hologram positioning (same as left-click)
            local hitNormal = trace.HitNormal
            local hitPos = trace.HitPos
            
            -- ALL rotating doors (both HL2 and prop) have origin at hinge - use LocalToWorld for universal support
            local mins, maxs = door:OBBMins(), door:OBBMaxs()
            local localCenter = (mins + maxs) / 2
            local visualCenter = door:LocalToWorld(localCenter)
            
            SetDoorHologramAnchor(door, hitNormal, hitPos, visualCenter)
            
            -- Paste the copied settings onto this new door
            VEIN.DoorSystem.CreateDoor(
                door, 
                ply, 
                copiedData.name, 
                copiedData.price, 
                copiedData.defaultLocked, 
                copiedData.doorType, 
                copiedData.doorMaterial, 
                copiedData.allowOwnership
            )
            
            -- Apply job-controlled status if it was a job door
            if copiedData.wasJobControlled then
                door:SetNWBool("VEIN_JobControlled", true)
                -- Apply control jobs for job-controlled doors
                if copiedData.controlJobs and copiedData.controlJobs ~= "" then
                    door:SetNWString("VEIN_ControlJobs", copiedData.controlJobs)
                end
            end
            
            -- Apply job restrictions if any (DarkRP door groups)
            if copiedData.doorGroup and copiedData.doorGroup ~= "" then
                door:SetNWString("VEIN_DoorGroup", copiedData.doorGroup)
            end
            if copiedData.allowedJobs and copiedData.allowedJobs ~= "" then
                door:SetNWString("VEIN_AllowedJobs", copiedData.allowedJobs)
            end

            -- Apply property group if copied and this door is buyable
            if copiedData.propertyGroupName and copiedData.propertyGroupName ~= "" and copiedData.allowOwnership then
                if VEIN.DoorSystem and VEIN.DoorSystem.SetPropertyGroup then
                    VEIN.DoorSystem.SetPropertyGroup(door, copiedData.propertyGroupName, copiedData.propertyCustomPrice)
                end
            end
            
            -- Notify user about door type
            if copiedData.wasJobControlled then
                VEIN.Chat(ply, "Job-controlled door pasted successfully!")
            elseif copiedData.wasStatic then
                VEIN.Chat(ply, "Static door pasted successfully!")
            else
                VEIN.Chat(ply, "Door settings pasted successfully!")
            end
            return
        end
        
        -- If door IS in VEIN system, copy its settings
        -- Copy door settings (exclude owner info)
        local copiedData = {
            name = door:GetNWString("VEIN_DoorName", ""),
            price = door:GetNWInt("VEIN_Price", 500),
            doorType = door:GetNWString("VEIN_DoorType", "Residential"),
            doorMaterial = door:GetNWString("VEIN_DoorMaterial", "Light Metal"),
            propertyGroupName = door:GetNWString("VEIN_PropertyGroupName", ""),
            propertyCustomPrice = door:GetNWInt("VEIN_PropertyCustomPrice", 0),
            kickTime = door:GetNWInt("VEIN_KickTime", 25),
            doorGroup = door:GetNWString("VEIN_DoorGroup", ""),
            allowedJobs = door:GetNWString("VEIN_AllowedJobs", ""), -- DarkRP door groups
            controlJobs = door:GetNWString("VEIN_ControlJobs", ""), -- Job-controlled doors
            defaultLocked = door:GetNWBool("VEIN_DefaultLocked", false),
            
            -- Material sound properties
            lockSound = door:GetNWString("VEIN_LockSound", "doors/door_latch3.wav"),
            unlockSound = door:GetNWString("VEIN_UnlockSound", "doors/door_latch1.wav"),
            kickSound = door:GetNWString("VEIN_KickSound", "physics/wood/wood_plank_break1.wav"),
            breakSound = door:GetNWString("VEIN_BreakSound", "physics/wood/wood_crate_break1.wav"),
            lockPitch = door:GetNWInt("VEIN_LockPitch", 100),
            unlockPitch = door:GetNWInt("VEIN_UnlockPitch", 100),
            kickPitch = door:GetNWInt("VEIN_KickPitch", 100),
            breakPitch = door:GetNWInt("VEIN_BreakPitch", 100),
            
            -- Handle ownership settings:
            -- If door was static (adminOnly=true) OR job-controlled, keep job settings
            -- If door was owned or for sale, make it FOR SALE (allowOwnership=true, buyable=true)
            wasStatic = door:GetNWBool("VEIN_AdminOnly", false),
            wasJobControlled = door:GetNWBool("VEIN_JobControlled", false)
        }
        
        -- If it was static OR job-controlled, keep job-controlled status
        -- Otherwise, make it buyable
        if copiedData.wasJobControlled then
            -- Keep as job-controlled door
            copiedData.allowOwnership = false
            copiedData.buyable = false
            copiedData.adminOnly = false -- Not admin-only, just job-restricted
        elseif copiedData.wasStatic then
            -- Keep as static admin door
            copiedData.allowOwnership = false
            copiedData.buyable = false
            copiedData.adminOnly = true
        else
            -- Make buyable
            copiedData.allowOwnership = true
            copiedData.buyable = true
            copiedData.adminOnly = false
        end
        
        -- Store copied data for this player
        VEIN.DoorSystem.CopiedDoorData[ply:SteamID()] = copiedData
        
        -- Send copy notification to client for HUD display
        net.Start("VEIN_DoorCopied")
        Net.WriteCopiedDoorData(copiedData)
        net.Send(ply)
    end)
end

-- Tool panel
if CLIENT then
    function TOOL.BuildCPanel(panel)
        panel:AddControl("Header", {Description = "VEIN Door Manager"})
        panel:AddControl("Label", {Text = "Create and manage buyable doors"})
        panel:AddControl("Label", {Text = ""})
        panel:AddControl("Label", {Text = "Left Click: Create door (opens GUI)"})
        panel:AddControl("Label", {Text = "Shift + Left Click: Link two doors (sync locks)"})
        panel:AddControl("Label", {Text = "Right Click: Modify door (edit settings)"})
        panel:AddControl("Label", {Text = "Middle Mouse (VEIN door): Copy settings"})
        panel:AddControl("Label", {Text = "Middle Mouse (empty door): Paste template"})
        panel:AddControl("Label", {Text = "R (Reload): Edit job/group permissions [ADMIN]"})
        panel:AddControl("Label", {Text = ""})
        panel:AddControl("Label", {Text = "Players need 'Keys' weapon to:"})
        panel:AddControl("Label", {Text = "- Buy doors (right-click)"})
        panel:AddControl("Label", {Text = "- Manage owned doors (right-click)"})
        panel:AddControl("Label", {Text = "- Toggle locks and permissions"})
    end
end

-- Client-side GUI function
-- OpenCreateDoorGUI is now defined in cl_door_gui.lua with full custom doors support
-- Create Door GUI (this is the CORRECT updated version with custom doors support)
if CLIENT then
    function VEIN.DoorSystem.OpenCreateDoorGUI(door)
        if not IsValid(door) then return end
        -- Create modern VEIN-styled frame
        local frame = vgui.Create("DFrame")
        local baseWidth, baseHeight = 500, 705
        local frameW = math.max(360, math.min(baseWidth, ScrW() - 80))
        local frameH = math.max(420, math.min(baseHeight, ScrH() - 80))
        frame:SetSize(frameW, frameH)  -- Start smaller, expands when job checkbox is checked
        frame:Center()
        frame:SetTitle("")
        frame:SetDraggable(false)
        frame:ShowCloseButton(false)
        frame:MakePopup()
        local window = frame
        
        -- VEIN styling
        frame.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 245))
            surface.SetDrawColor(120, 40, 40, 150)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
            surface.SetDrawColor(180, 60, 60, 100)
            surface.DrawRect(12, 12, w - 24, 2)
        end
        
        -- Close button
        local closeBtn = vgui.Create("DButton", frame)
        closeBtn:SetPos(window:GetWide() - 40, 13)
        closeBtn:SetSize(28, 28)
        closeBtn:SetText("")
        closeBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local bgColor = isHovered and Color(180, 60, 60, 200) or Color(40, 40, 42, 120)
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            if isHovered then
                surface.SetDrawColor(180, 60, 60, 200)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            local centerX, centerY = w/2, h/2
            local size = 6
            local lineColor = isHovered and Color(255, 200, 200, 255) or Color(180, 180, 185, 200)
            surface.SetDrawColor(lineColor)
            surface.DrawLine(centerX - size, centerY - size, centerX + size, centerY + size)
            surface.DrawLine(centerX + size, centerY - size, centerX - size, centerY + size)
        end
        closeBtn.DoClick = function() surface.PlaySound("buttons/button15.wav"); window:Close() end
        
        -- Q key to close menu
        frame.OnKeyCodePressed = function(self, keyCode)
            if keyCode == KEY_Q then
                self:Close()
                return true
            end
            return false
        end

        -- Title
        local title = vgui.Create("DLabel", frame)
        title:SetPos(15, 20)
        title:SetSize(400, 30)
        title:SetText("Create Buyable Door")
        title:SetFont("DermaLarge")
        title:SetTextColor(Color(220, 220, 225))
        
        -- Door Name Section
        local nameLabel = vgui.Create("DLabel", frame)
        nameLabel:SetPos(15, 60)
        nameLabel:SetSize(470, 20)
        nameLabel:SetText("Door Name:")
        nameLabel:SetFont("DermaDefaultBold")
        nameLabel:SetTextColor(Color(200, 200, 205))
        
        local nameEntry = vgui.Create("DTextEntry", frame)
        nameEntry:SetPos(15, 85)
        nameEntry:SetSize(470, 30)
        nameEntry:SetPlaceholderText("Optional - Leave blank for default")
        nameEntry:SetFont("DermaDefault")
        nameEntry:SetDrawBorder(false)
        nameEntry:SetDrawBackground(false)
        nameEntry.Paint = function(self, w, h)
            -- Dark background with red highlight like door rename
            local bgColor = self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            local borderColor = self:HasFocus() and Color(120, 40, 40, 200) or Color(60, 60, 60, 150)
            surface.SetDrawColor(borderColor)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            self:DrawTextEntryText(Color(220, 220, 225), Color(120, 40, 40), Color(220, 220, 225))
        end
        
        -- Price Section
        local priceLabel = vgui.Create("DLabel", frame)
        priceLabel:SetPos(15, 130)
        priceLabel:SetSize(470, 20)
        priceLabel:SetText("Price:")
        priceLabel:SetFont("DermaDefaultBold")
        priceLabel:SetTextColor(Color(200, 200, 205))
        
        local priceEntry = vgui.Create("DNumberWang", frame)
        priceEntry:SetPos(15, 155)
        priceEntry:SetSize(200, 30)
        priceEntry:SetValue(30) -- Default to DarkRP door price
        priceEntry:SetMin(1)
        priceEntry:SetMax(2147483647)
        priceEntry.Paint = function(self, w, h)
            -- Dark background with red highlight like other inputs
            local bgColor = self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            local borderColor = self:HasFocus() and Color(120, 40, 40, 200) or Color(60, 60, 60, 150)
            surface.SetDrawColor(borderColor)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            self:DrawTextEntryText(Color(220, 220, 225), Color(120, 40, 40), Color(220, 220, 225))
        end
        
        -- Lock State Section
        local lockLabel = vgui.Create("DLabel", frame)
        lockLabel:SetPos(15, 200)
        lockLabel:SetSize(470, 20)
        lockLabel:SetText("Default State:")
        lockLabel:SetFont("DermaDefaultBold")
        lockLabel:SetTextColor(Color(200, 200, 205))
        
        local lockPanel = vgui.Create("DPanel", frame)
        lockPanel:SetPos(15, 225)
        lockPanel:SetSize(470, 30)
        lockPanel.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 38, 180))
            surface.SetDrawColor(120, 40, 40, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        local lockCheck = vgui.Create("DCheckBox", lockPanel)
        lockCheck:SetPos(10, 5)
        lockCheck:SetSize(20, 20)
        lockCheck:SetValue(false)
        
        local lockText = vgui.Create("DLabel", lockPanel)
        lockText:SetPos(40, 0)
        lockText:SetSize(420, 30)
        lockText:SetText("Start locked (buyers must unlock with keys)")
        lockText:SetFont("DermaDefault")
        lockText:SetTextColor(Color(200, 200, 205))
        lockText:SetContentAlignment(4)
        
        -- Door Type Section
        local typeLabel = vgui.Create("DLabel", frame)
        typeLabel:SetPos(15, 270)
        typeLabel:SetSize(470, 20)
        typeLabel:SetText("Door Type:")
        typeLabel:SetFont("DermaDefaultBold")
        typeLabel:SetTextColor(Color(200, 200, 205))
        
        local typeCombo = vgui.Create("DComboBox", frame)
        typeCombo:SetPos(15, 295)
        typeCombo:SetSize(230, 30)
        
        -- Store type colors for lookup
        local typeColors = {}
        
        -- Add all door types (default + custom from server)
        if VEIN.CustomDoors and VEIN.CustomDoors.Types then
            for _, typeData in ipairs(VEIN.CustomDoors.Types) do
                typeCombo:AddChoice(typeData.name, typeData) -- Pass typeData so desc is available
                -- Store a NEW color object to avoid reference issues
                typeColors[typeData.name] = Color(typeData.color.r, typeData.color.g, typeData.color.b)
            end
        end
        
        typeCombo.Paint = function(self, w, h)
            -- Dark dropdown styling
            draw.RoundedBox(4, 0, 0, w, h, Color(25, 25, 25, 255))
            surface.SetDrawColor(60, 60, 60, 150)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            
            -- Apply text color dynamically based on current selection
            local currentValue = self:GetValue()
            local col = typeColors[currentValue]
            if col then
                self:SetTextColor(col)
            end
        end
        
        typeCombo.OnSelect = function(self, index, value)
            -- Color is handled in Paint function
        end
        
        -- Set default value AFTER populating choices and defining OnSelect
        typeCombo:SetValue("Residential")
        
        -- Door Material Section  
        local materialLabel = vgui.Create("DLabel", frame)
        materialLabel:SetPos(255, 270)
        materialLabel:SetSize(230, 20)
        materialLabel:SetText("Door Material:")
        materialLabel:SetFont("DermaDefaultBold")
        materialLabel:SetTextColor(Color(200, 200, 205))
        
        local materialCombo = vgui.Create("DComboBox", frame)
        materialCombo:SetPos(255, 295)
        materialCombo:SetSize(230, 30)
        materialCombo:SetValue("Light Metal")
        
        -- Add all door materials (default + custom from server)
        if VEIN.CustomDoors and VEIN.CustomDoors.Materials then
            for _, matData in ipairs(VEIN.CustomDoors.Materials) do
                local kickDesc = matData.kickTime == -1 and "Cannot be kicked down" or ("Kick time: " .. matData.kickTime .. "s")
                materialCombo:AddChoice(matData.name, { kickTime = matData.kickTime, desc = kickDesc })
            end
        end
        
        materialCombo.Paint = function(self, w, h)
            -- Dark dropdown styling
            draw.RoundedBox(4, 0, 0, w, h, Color(25, 25, 25, 255))
            surface.SetDrawColor(60, 60, 60, 150)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        materialCombo:SetTextColor(Color(200, 200, 205))
        
        -- Description panel
        local descPanel = vgui.Create("DPanel", frame)
        descPanel:SetPos(15, 335)
        descPanel:SetSize(470, 40)
        descPanel.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(25, 25, 28, 120))
            surface.SetDrawColor(80, 80, 85, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        local descText = vgui.Create("DLabel", descPanel)
        descText:SetPos(10, 5)
        descText:SetSize(450, 30)
        descText:SetText("Residential: Houses, apartments, private living spaces | Light Metal: Medium difficulty (25s)")
        descText:SetFont("DermaDefault")
        descText:SetTextColor(Color(170, 170, 175))
        descText:SetWrap(true)
        descText:SetContentAlignment(7)
        
        -- Update descriptions when selections change
        local function updateDescription()
            local typeText, typeData = typeCombo:GetSelected()
            local matText, matData = materialCombo:GetSelected()
            
            typeText = typeText or "Residential"
            matText = matText or "Light Metal"
            
            local typeDesc = typeData and typeData.desc or "Houses, apartments, private living spaces"
            local matDesc = matData and matData.desc or "Medium difficulty (25s)"
            
            descText:SetText(typeText .. ": " .. typeDesc .. " | " .. matText .. ": " .. matDesc)
        end
        
        typeCombo.OnSelect = function(self, index, value, data)
            updateDescription()
        end
        
        materialCombo.OnSelect = function(self, index, value, data)
            updateDescription()
        end
        
        -- Allow Ownership Section
        local ownershipLabel = vgui.Create("DLabel", frame)
        ownershipLabel:SetPos(15, 385)
        ownershipLabel:SetSize(470, 20)
        ownershipLabel:SetText("Ownership Settings:")
        ownershipLabel:SetFont("DermaDefaultBold")
        ownershipLabel:SetTextColor(Color(200, 200, 205))
        
        local ownershipPanel = vgui.Create("DPanel", frame)
        ownershipPanel:SetPos(15, 410)
        ownershipPanel:SetSize(470, 30)
        ownershipPanel.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 38, 180))
            surface.SetDrawColor(120, 40, 40, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        local allowOwnershipCheck = vgui.Create("DCheckBox", ownershipPanel)
        allowOwnershipCheck:SetPos(10, 5)
        allowOwnershipCheck:SetSize(20, 20)
        allowOwnershipCheck:SetValue(true)
        
        local ownershipText = vgui.Create("DLabel", ownershipPanel)
        ownershipText:SetPos(40, 0)
        ownershipText:SetSize(420, 30)
        ownershipText:SetText("Allow players to buy this door (uncheck to make it admin-only)")
        ownershipText:SetFont("DermaDefault")
        ownershipText:SetTextColor(Color(200, 200, 205))
        ownershipText:SetContentAlignment(4)
        
        -- Lock Name Change Panel
        local lockNamePanel = vgui.Create("DPanel", frame)
        lockNamePanel:SetPos(15, 445)
        lockNamePanel:SetSize(470, 30)
        lockNamePanel.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 38, 180))
            surface.SetDrawColor(120, 40, 40, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        local lockNameCheck = vgui.Create("DCheckBox", lockNamePanel)
        lockNameCheck:SetPos(10, 5)
        lockNameCheck:SetSize(20, 20)
        lockNameCheck:SetValue(false)
        
        local lockNameText = vgui.Create("DLabel", lockNamePanel)
        lockNameText:SetPos(40, 0)
        lockNameText:SetSize(420, 30)
        lockNameText:SetText("Lock door name (prevent players from renaming this door)")
        lockNameText:SetFont("DermaDefault")
        lockNameText:SetTextColor(Color(200, 200, 205))
        lockNameText:SetContentAlignment(4)
        
        -- Job Controlled Panel
        local jobControlPanel = vgui.Create("DPanel", frame)
        jobControlPanel:SetPos(15, 480)
        jobControlPanel:SetSize(470, 30)
        jobControlPanel.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(35, 38, 35, 180))
            surface.SetDrawColor(40, 120, 40, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end
        
        local jobControlCheck = vgui.Create("DCheckBox", jobControlPanel)
        jobControlCheck:SetPos(10, 5)
        jobControlCheck:SetSize(20, 20)
        jobControlCheck:SetValue(false)
        
        local jobControlText = vgui.Create("DLabel", jobControlPanel)
        jobControlText:SetPos(40, 0)
        jobControlText:SetSize(420, 30)
        jobControlText:SetText("Job Controlled Door (only specific jobs can lock/unlock)")
        jobControlText:SetFont("DermaDefault")
        jobControlText:SetTextColor(Color(200, 255, 200))
        jobControlText:SetContentAlignment(4)

        -- Property Group Panel (buy multiple doors as one property)
        local propertyGroupPanel = vgui.Create("DPanel", frame)
        propertyGroupPanel:SetPos(15, 515)
        propertyGroupPanel:SetSize(470, 30)
        propertyGroupPanel.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(35, 35, 38, 180))
            surface.SetDrawColor(60, 90, 120, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        local propertyGroupCheck = vgui.Create("DCheckBox", propertyGroupPanel)
        propertyGroupCheck:SetPos(10, 5)
        propertyGroupCheck:SetSize(20, 20)
        propertyGroupCheck:SetValue(false)
        propertyGroupCheck.Paint = function(self, w, h)
            local enabled = self:IsEnabled()
            local checked = self:GetChecked()
            local bgColor = checked and Color(70, 110, 160, 200) or Color(30, 30, 35, 200)
            if not enabled then
                bgColor = Color(20, 20, 24, 200)
            end
            draw.RoundedBox(3, 0, 0, w, h, bgColor)
            local borderColor = enabled and Color(90, 120, 160, 150) or Color(60, 60, 70, 120)
            surface.SetDrawColor(borderColor)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            if checked then
                surface.SetDrawColor(Color(220, 220, 225))
                surface.DrawRect(4, 4, w - 8, h - 8)
            end
        end

        local propertyGroupText = vgui.Create("DLabel", propertyGroupPanel)
        propertyGroupText:SetPos(40, 0)
        propertyGroupText:SetSize(420, 30)
        propertyGroupText:SetText("Property Group (buy multiple doors together)")
        propertyGroupText:SetFont("DermaDefault")
        propertyGroupText:SetTextColor(Color(200, 220, 255))
        propertyGroupText:SetContentAlignment(4)

        local propertyGroupFields = vgui.Create("DPanel", frame)
        propertyGroupFields:SetPos(15, 550)
        propertyGroupFields:SetSize(470, 60)
        propertyGroupFields.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(25, 25, 28, 160))
            surface.SetDrawColor(70, 90, 120, 100)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        local propertyNameLabel = vgui.Create("DLabel", propertyGroupFields)
        propertyNameLabel:SetPos(10, 6)
        propertyNameLabel:SetSize(150, 20)
        propertyNameLabel:SetText("Group Name:")
        propertyNameLabel:SetFont("DermaDefault")
        propertyNameLabel:SetTextColor(Color(180, 180, 185))

        local propertyNameEntry = vgui.Create("DTextEntry", propertyGroupFields)
        propertyNameEntry:SetPos(10, 28)
        propertyNameEntry:SetSize(170, 25)
        propertyNameEntry:SetPlaceholderText("Required (e.g., Lakeside House)")
        propertyNameEntry.Paint = function(self, w, h)
            local enabled = self:IsEnabled()
            local bgColor = enabled and (self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)) or Color(18, 18, 20, 220)
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            local borderColor = enabled and (self:HasFocus() and Color(100, 130, 170, 200) or Color(60, 60, 60, 150)) or Color(50, 50, 55, 120)
            surface.SetDrawColor(borderColor)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            local textColor = enabled and Color(220, 220, 225) or Color(140, 140, 145)
            self:DrawTextEntryText(textColor, Color(120, 40, 40), textColor)
        end

        local propertyListButton = vgui.Create("DButton", propertyGroupFields)
        propertyListButton:SetPos(185, 28)
        propertyListButton:SetSize(85, 25)
        propertyListButton:SetText("Existing")
        propertyListButton:SetFont("DermaDefaultBold")
        propertyListButton:SetTextColor(Color(200, 200, 205))
        propertyListButton.Paint = function(self, w, h)
            local enabled = self:IsEnabled()
            local isHovered = enabled and self:IsHovered()
            local bgColor = enabled and (isHovered and Color(70, 90, 120, 200) or Color(50, 70, 90, 180)) or Color(35, 35, 40, 150)
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            local borderColor = enabled and Color(90, 120, 160, 150) or Color(60, 60, 70, 120)
            surface.SetDrawColor(borderColor)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
        end

        local propertyPriceLabel = vgui.Create("DLabel", propertyGroupFields)
        propertyPriceLabel:SetPos(280, 6)
        propertyPriceLabel:SetSize(180, 20)
        propertyPriceLabel:SetText("Custom Price:")
        propertyPriceLabel:SetFont("DermaDefault")
        propertyPriceLabel:SetTextColor(Color(180, 180, 185))

        local propertyPriceEntry = vgui.Create("DNumberWang", propertyGroupFields)
        propertyPriceEntry:SetPos(280, 28)
        propertyPriceEntry:SetSize(180, 25)
        propertyPriceEntry:SetMin(0)
        propertyPriceEntry:SetMax(2147483647)
        propertyPriceEntry:SetValue(0)
        propertyPriceEntry.Paint = function(self, w, h)
            local enabled = self:IsEnabled()
            local bgColor = enabled and (self:HasFocus() and Color(25, 25, 25, 255) or Color(20, 20, 20, 255)) or Color(18, 18, 20, 220)
            draw.RoundedBox(4, 0, 0, w, h, bgColor)
            local borderColor = enabled and (self:HasFocus() and Color(100, 130, 170, 200) or Color(60, 60, 60, 150)) or Color(50, 50, 55, 120)
            surface.SetDrawColor(borderColor)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            local textColor = enabled and Color(220, 220, 225) or Color(140, 140, 145)
            self:DrawTextEntryText(textColor, Color(120, 40, 40), textColor)
        end

        local propertyPriceAutoSetting = false
        local propertyPriceAutoFromSum = false
        local propertyPriceAutoActive = false
        local propertyPriceManualOverride = false

        local function CollectPropertyGroupNames()
            local names = {}
            for _, ent in ipairs(ents.GetAll()) do
                if IsValid(ent) then
                    local name = ent:GetNWString("VEIN_PropertyGroupName", "")
                    if name ~= "" then
                        names[name] = true
                    end
                end
            end
            local list = {}
            for name in pairs(names) do
                table.insert(list, name)
            end
            table.sort(list)
            return list
        end

        local function GetPropertyGroupInfoByName(name)
            name = string.Trim(name or "")
            if name == "" then return nil end
            for _, ent in ipairs(ents.GetAll()) do
                if IsValid(ent) then
                    local entName = ent:GetNWString("VEIN_PropertyGroupName", "")
                    if entName ~= "" and entName == name then
                        local customPrice = ent:GetNWInt("VEIN_PropertyCustomPrice", 0)
                        local totalPrice = ent:GetNWInt("VEIN_PropertyTotalPrice", ent:GetNWInt("VEIN_Price", 0))
                        return {customPrice = customPrice, totalPrice = totalPrice}
                    end
                end
            end
            return nil
        end

        local function AutoFillPropertyPrice(name)
            local info = GetPropertyGroupInfoByName(name)
            if not info then return false end
            local value = info.customPrice > 0 and info.customPrice or info.totalPrice
            propertyPriceAutoSetting = true
            propertyPriceEntry:SetValue(value)
            propertyPriceAutoSetting = false
            propertyPriceAutoFromSum = info.customPrice <= 0
            propertyPriceAutoActive = true
            propertyPriceManualOverride = false
            return true
        end

        propertyListButton.DoClick = function()
            local names = CollectPropertyGroupNames()
            local menu = DermaMenu()
            if #names == 0 then
                local option = menu:AddOption("No properties found")
                option:SetEnabled(false)
            else
                for _, name in ipairs(names) do
                    menu:AddOption(name, function()
                        if IsValid(propertyNameEntry) then
                            propertyNameEntry:SetValue(name)
                            AutoFillPropertyPrice(name)
                        end
                    end)
                end
            end
            menu:Open()
        end

        propertyNameEntry.OnChange = function(self)
            if not propertyGroupCheck:GetChecked() then return end
            local name = string.Trim(self:GetValue() or "")
            if AutoFillPropertyPrice(name) then return end
            if propertyPriceAutoActive and not propertyPriceManualOverride then
                propertyPriceAutoSetting = true
                propertyPriceEntry:SetValue(0)
                propertyPriceAutoSetting = false
            end
            propertyPriceAutoFromSum = false
            propertyPriceAutoActive = false
            propertyPriceManualOverride = false
        end

        propertyPriceEntry.OnValueChanged = function(self, value)
            if propertyPriceAutoSetting then return end
            propertyPriceManualOverride = true
            propertyPriceAutoFromSum = false
            propertyPriceAutoActive = false
        end

        local propertyGroupUpdateLock = false

        local function SetPropertyGroupChecked(value)
            if propertyGroupCheck:GetChecked() == value then return end
            propertyGroupUpdateLock = true
            propertyGroupCheck:SetValue(value)
            propertyGroupUpdateLock = false
        end

        local function UpdatePropertyGroupControls()
            local jobControlled = jobControlCheck:GetChecked()
            local canShow = not jobControlled
            propertyGroupPanel:SetVisible(canShow)
            propertyGroupFields:SetVisible(canShow)

            local canUse = allowOwnershipCheck:GetChecked() and not jobControlled
            propertyGroupCheck:SetEnabled(canUse)
            if not canUse then
                SetPropertyGroupChecked(false)
            end

            local enableFields = canUse and propertyGroupCheck:GetChecked()
            propertyNameEntry:SetEnabled(enableFields)
            propertyPriceEntry:SetEnabled(enableFields)
            propertyListButton:SetEnabled(enableFields)
            local labelColor = enableFields and Color(180, 180, 185) or Color(100, 100, 110)
            propertyNameLabel:SetTextColor(labelColor)
            propertyPriceLabel:SetTextColor(labelColor)
            propertyNameLabel:SetEnabled(enableFields)
            propertyPriceLabel:SetEnabled(enableFields)
            propertyListButton:SetTextColor(enableFields and Color(200, 200, 205) or Color(120, 120, 130))

            if enableFields then
                local name = string.Trim(propertyNameEntry:GetValue() or "")
                AutoFillPropertyPrice(name)
            end
        end

        propertyGroupCheck.OnChange = function()
            if propertyGroupUpdateLock then return end
            UpdatePropertyGroupControls()
        end
        allowOwnershipCheck.OnChange = function()
            UpdatePropertyGroupControls()
        end
        
        -- Job List Panel (initially hidden)
        local jobListPanel = vgui.Create("DPanel", frame)
        jobListPanel:SetPos(15, 515)
        jobListPanel:SetSize(470, 160)
        jobListPanel:SetVisible(false)
        
        jobListPanel.Paint = function(self, w, h)
            draw.RoundedBox(4, 0, 0, w, h, Color(25, 25, 30, 200))
            draw.RoundedBox(4, 1, 1, w-2, h-2, Color(35, 35, 40, 200))
        end
        
        local jobListLabel = vgui.Create("DLabel", jobListPanel)
        jobListLabel:SetPos(5, 5)
        jobListLabel:SetText("Select jobs that can lock/unlock this door:")
        jobListLabel:SetTextColor(Color(180, 180, 185))
        jobListLabel:SizeToContents()
        
        -- Job list with checkboxes
        local jobScroll = vgui.Create("DScrollPanel", jobListPanel)
        jobScroll:SetPos(5, 25)
        jobScroll:SetSize(460, 120)
        
        -- Store job checkboxes
        local jobCheckboxes = {}
        
        -- Request job list from server
        net.Start("VEIN_RequestJobList")
        net.SendToServer()
        
        -- Receive job list data
        net.Receive("VEIN_JobListData", function()
            local jobs = Net.ReadJobList()
            
            for _, job in ipairs(jobs) do
                local jobPanel = vgui.Create("DPanel", jobScroll)
                jobPanel:SetSize(440, 20)
                jobPanel:Dock(TOP)
                jobPanel:DockMargin(0, 0, 0, 2)
                jobPanel.Paint = function(self, w, h)
                    draw.RoundedBox(2, 0, 0, w, h, Color(45, 45, 50, 150))
                end
                
                local jobCheckBox = vgui.Create("DCheckBoxLabel", jobPanel)
                jobCheckBox:SetPos(5, 0)
                jobCheckBox:SetText(job.name)
                jobCheckBox:SetTextColor(job.color)
                jobCheckBox:SizeToContents()
                jobCheckBox:SetValue(false)
                
                -- Store checkbox with team ID
                jobCheckboxes[job.team] = jobCheckBox
            end
        end)
        
        -- Edit Door Group Button (position adjusts when job list is visible)
        local groupBtn = vgui.Create("DButton", frame)
        groupBtn:SetPos(15, 615)  -- Initial position (frame is small)
        groupBtn:SetSize(230, 35)
        groupBtn:SetText("Edit Door Group/Jobs")
        groupBtn:SetFont("DermaDefaultBold")
        groupBtn:SetTextColor(Color(200, 200, 205))
        groupBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local bgColor = isHovered and Color(60, 90, 120, 200) or Color(40, 60, 80, 180)
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            if isHovered then
                surface.SetDrawColor(100, 140, 180, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            surface.SetDrawColor(80, 120, 160, isHovered and 140 or 100)
            surface.DrawRect(0, 0, 3, h)
        end
        groupBtn.DoClick = function()
            -- First create the door, then open group editor
            local doorName = nameEntry:GetValue()
            local price = priceEntry:GetValue()
            local isLocked = lockCheck:GetChecked()
            local doorType, typeData = typeCombo:GetSelected()
            local doorMaterial, materialData = materialCombo:GetSelected()
            local allowOwnership = allowOwnershipCheck:GetChecked()
            local lockName = lockNameCheck:GetChecked()
            local jobControlled = jobControlCheck:GetChecked()
            local usePropertyGroup = propertyGroupCheck:GetChecked()
            local propertyGroupName = usePropertyGroup and string.Trim(propertyNameEntry:GetValue() or "") or ""
            local propertyCustomPrice = usePropertyGroup and propertyPriceEntry:GetValue() or 0
            if usePropertyGroup and propertyPriceAutoFromSum and not propertyPriceManualOverride then
                propertyCustomPrice = 0
            end
            
            -- Collect selected jobs
            local controlJobs = {}
            if jobCheckboxes then
                for teamID, checkbox in pairs(jobCheckboxes) do
                    if checkbox:GetChecked() then
                        table.insert(controlJobs, teamID)
                    end
                end
            end

            if jobControlled and #controlJobs == 0 then
                chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "You must select at least one job for job-controlled doors!")
                surface.PlaySound("buttons/button10.wav")
                return
            end
            if usePropertyGroup and propertyGroupName == "" then
                chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "Property group name is required!")
                surface.PlaySound("buttons/button10.wav")
                return
            end
            
            -- Send to server
            net.Start("VEIN_CreateDoor")
            net.WriteEntity(door)
            net.WriteString(doorName)
            net.WriteUInt(price, 32)
            net.WriteBool(isLocked)
            net.WriteString(doorType or "Residential")
            net.WriteString(doorMaterial or "Light Metal")
            net.WriteBool(allowOwnership)
            net.WriteBool(lockName)
            net.WriteBool(jobControlled)
            Net.WriteTeamList(controlJobs)
            net.WriteString(propertyGroupName)
            net.WriteInt(propertyCustomPrice, 32)
            net.SendToServer()
            
            window:Close()
            
            -- Wait for door to be created, then open group editor
            timer.Simple(0.2, function()
                if IsValid(door) and VEIN.DoorGroups then
                    VEIN.DoorGroups.OpenEditor(door)
                end
            end)
        end
        
        -- Buttons
        local createBtn = vgui.Create("DButton", frame)
        createBtn:SetPos(15, 660)  -- Initial position (frame is small)
        createBtn:SetSize(120, 35)
        createBtn:SetText("Create Door")
        createBtn:SetFont("DermaDefaultBold")
        createBtn:SetTextColor(Color(200, 200, 205))
        createBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local bgColor = isHovered and Color(60, 120, 60, 200) or Color(40, 80, 40, 180)
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            if isHovered then
                surface.SetDrawColor(120, 180, 120, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            surface.SetDrawColor(100, 150, 100, isHovered and 140 or 100)
            surface.DrawRect(0, 0, 3, h)
        end
        createBtn.DoClick = function()
            local doorName = nameEntry:GetValue()
            local price = priceEntry:GetValue()
            local isLocked = lockCheck:GetChecked()
            local doorType, typeData = typeCombo:GetSelected()
            local doorMaterial, materialData = materialCombo:GetSelected()
            local allowOwnership = allowOwnershipCheck:GetChecked()
            local lockName = lockNameCheck:GetChecked()
            local jobControlled = jobControlCheck:GetChecked()
            local usePropertyGroup = propertyGroupCheck:GetChecked()
            local propertyGroupName = usePropertyGroup and string.Trim(propertyNameEntry:GetValue() or "") or ""
            local propertyCustomPrice = usePropertyGroup and propertyPriceEntry:GetValue() or 0
            if usePropertyGroup and propertyPriceAutoFromSum and not propertyPriceManualOverride then
                propertyCustomPrice = 0
            end
            
            -- Collect selected jobs
            local controlJobs = {}
            if jobCheckboxes then
                for teamID, checkbox in pairs(jobCheckboxes) do
                    if checkbox:GetChecked() then
                        table.insert(controlJobs, teamID)
                    end
                end
            end
            
            -- Validation: If job-controlled, must have at least one job selected
            if jobControlled and #controlJobs == 0 then
                chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "You must select at least one job for job-controlled doors!")
                surface.PlaySound("buttons/button10.wav")
                return
            end
            if usePropertyGroup and propertyGroupName == "" then
                chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), "Property group name is required!")
                surface.PlaySound("buttons/button10.wav")
                return
            end
            
            -- Send to server
            net.Start("VEIN_CreateDoor")
            net.WriteEntity(door)
            net.WriteString(doorName)
            net.WriteUInt(price, 32)
            net.WriteBool(isLocked)
            net.WriteString(doorType or "Residential")
            net.WriteString(doorMaterial or "Light Metal")
            net.WriteBool(allowOwnership)
            net.WriteBool(lockName)
            net.WriteBool(jobControlled)
            Net.WriteTeamList(controlJobs)
            net.WriteString(propertyGroupName)
            net.WriteInt(propertyCustomPrice, 32)
            net.SendToServer()
            
            window:Close()
            surface.PlaySound("buttons/button15.wav")
            
            if jobControlled then
                VEIN.Chat(LocalPlayer(), "Job-controlled door created successfully!")
            elseif allowOwnership then
                VEIN.Chat(LocalPlayer(), "Buyable door created successfully!")
            else
                VEIN.Chat(LocalPlayer(), "Static admin-only door created!")
            end
        end
        
        local cancelBtn = vgui.Create("DButton", frame)
        cancelBtn:SetPos(365, 660)  -- Initial position (frame is small)
        cancelBtn:SetSize(120, 35)
        cancelBtn:SetText("Cancel")
        cancelBtn:SetFont("DermaDefaultBold")
        cancelBtn:SetTextColor(Color(200, 200, 205))
        cancelBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local bgColor = isHovered and Color(120, 40, 40, 200) or Color(80, 30, 30, 150)
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            if isHovered then
                surface.SetDrawColor(160, 60, 60, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
        end
        cancelBtn.DoClick = function()
            surface.PlaySound("buttons/button10.wav")
            window:Close()
        end
        
        -- Set up job control checkbox toggle behavior (AFTER all elements are created)
        jobControlCheck.OnChange = function(self, val)
            jobListPanel:SetVisible(val)
            
            if val then
                -- Job-controlled mode
                allowOwnershipCheck:SetValue(false)
                allowOwnershipCheck:SetEnabled(false)
                propertyGroupCheck:SetValue(false)
                
                -- Hide door group button (job-controlled uses different system)
                groupBtn:SetVisible(false)
                
                window:SetTall(math.min(770, ScrH() - 80))
                createBtn:SetPos(15, 720)
                cancelBtn:SetPos(365, 720)
            else
                -- Normal mode
                allowOwnershipCheck:SetEnabled(true)
                allowOwnershipCheck:SetValue(true) -- Re-enable ownership when disabling job control
                
                -- Show door group button
                groupBtn:SetVisible(true)
                
                window:SetTall(math.min(705, ScrH() - 80))
                groupBtn:SetPos(15, 615)
                createBtn:SetPos(15, 660)
                cancelBtn:SetPos(365, 660)
            end
            
            UpdatePropertyGroupControls()
        end
        
        UpdatePropertyGroupControls()
    end
    
    -- Network receiver for opening remove confirmation
    net.Receive("VEIN_OpenRemoveConfirm", function()
        local door = net.ReadEntity()
        DoorSystem.OpenRemoveDoorGUI(door)
    end)
    
    -- Remove Door Confirmation GUI
    function DoorSystem.OpenRemoveDoorGUI(door)
        if not IsValid(door) then 
            return 
        end
        
        local owner = door:GetNWString("VEIN_OwnerName", "")
        local doorName = door:GetNWString("VEIN_DoorName", "")
        local price = door:GetNWInt("VEIN_Price", 0)
        local isBuyable = door:GetNWBool("VEIN_Buyable", false)
        
        local frame = vgui.Create("DFrame")
        local baseW, baseH = 450, 220
        local frameW = math.max(320, math.min(baseW, ScrW() - 80))
        local frameH = math.max(200, math.min(baseH, ScrH() - 80))
        frame:SetSize(frameW, frameH)
        frame:Center()
        frame:SetTitle("Remove Door - Confirmation")
        frame:SetDraggable(false)
        frame:ShowCloseButton(false)
        frame:MakePopup()
        
        -- Restore input when frame closes
        frame.OnClose = function(self)
            gui.EnableScreenClicker(false)
        end
        
        -- Dark minimalistic frame
        frame.Paint = function(self, w, h)
            draw.RoundedBox(8, 0, 0, w, h, Color(22, 22, 24, 245))
            surface.SetDrawColor(120, 40, 40, 150)
            surface.DrawOutlinedRect(0, 0, w, h, 2)
            surface.SetDrawColor(180, 60, 60, 100)
            surface.DrawRect(12, 12, w - 24, 2)
        end
        
        -- Warning message
        local innerW = frameW - 40
        local warningLabel = vgui.Create("DLabel", frame)
        warningLabel:SetPos(20, 40)
        warningLabel:SetSize(innerW, 25)
        warningLabel:SetText("⚠ WARNING: This will permanently remove the door from VEIN system!")
        warningLabel:SetFont("DermaDefaultBold")
        warningLabel:SetTextColor(Color(255, 150, 150))
        warningLabel:SetContentAlignment(5)
        
        -- Door info
        local doorInfo = ""
        if owner ~= "" then
            local displayName = doorName ~= "" and doorName or (owner .. "'s Door")
            doorInfo = "Owned Door: " .. displayName .. " (Owner will receive $" .. price .. " refund)"
        elseif isBuyable then
            local displayName = doorName ~= "" and doorName or "Unnamed Door"
            doorInfo = "Buyable Door: " .. displayName .. " ($" .. price .. ")"
        else
            doorInfo = "Unmanaged Door"
        end
        
        local infoLabel = vgui.Create("DLabel", frame)
        infoLabel:SetPos(20, 75)
        infoLabel:SetSize(innerW, 40)
        infoLabel:SetText(doorInfo)
        infoLabel:SetTextColor(Color(200, 200, 205))
        infoLabel:SetContentAlignment(5)
        infoLabel:SetWrap(false)
        
        local confirmLabel = vgui.Create("DLabel", frame)
        confirmLabel:SetPos(20, 120)
        confirmLabel:SetSize(innerW, 20)
        confirmLabel:SetText("Are you sure you want to remove this door?")
        confirmLabel:SetTextColor(Color(220, 220, 225))
        confirmLabel:SetContentAlignment(5)
        
        -- Remove button (danger style)
        local buttonW = math.min(140, math.floor((innerW - 10) / 2))
        local buttonY = frameH - 55
        local buttonGap = 10
        local buttonRowW = (buttonW * 2) + buttonGap
        local buttonStartX = math.floor((frameW - buttonRowW) / 2)
        local removeBtn = vgui.Create("DButton", frame)
        removeBtn:SetPos(buttonStartX, buttonY)
        removeBtn:SetSize(buttonW, 35)
        removeBtn:SetText("YES, REMOVE")
        removeBtn:SetTextColor(Color(255, 200, 200))
        removeBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local bgColor = isHovered and Color(80, 35, 35, 220) or Color(60, 25, 25, 180)
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            if isHovered then
                surface.SetDrawColor(200, 80, 80, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            surface.SetDrawColor(180, 60, 60, isHovered and 140 or 100)
            surface.DrawRect(0, 0, 3, h)
        end
        removeBtn.DoClick = function()
            net.Start("VEIN_RemoveDoor")
            net.WriteEntity(door)
            net.SendToServer()
            frame:Close()
        end
        
        -- Cancel button
        local cancelBtn = vgui.Create("DButton", frame)
        cancelBtn:SetPos(buttonStartX + buttonW + buttonGap, buttonY)
        cancelBtn:SetSize(buttonW, 35)
        cancelBtn:SetText("Cancel")
        cancelBtn:SetTextColor(Color(200, 200, 205))
        cancelBtn.Paint = function(self, w, h)
            local isHovered = self:IsHovered()
            local bgColor = isHovered and Color(40, 40, 43, 200) or Color(35, 35, 38, 180)
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            if isHovered then
                surface.SetDrawColor(140, 60, 60, 150)
                surface.DrawOutlinedRect(0, 0, w, h, 1)
            end
            surface.SetDrawColor(120, 50, 50, isHovered and 120 or 80)
            surface.DrawRect(0, 0, 3, h)
        end
        cancelBtn.DoClick = function()
            frame:Close()
        end
    end
end -- Close if CLIENT then block



