﻿--[[
================================================================================
VEIN Door System - Single entry point
================================================================================
Only responsibilities:
- register shared chat channel
- wire up networking strings
- include/load the actual modules under lua/vein_doors/
]]--

VEIN = VEIN or {}
local VEIN = VEIN

-- Lightweight chat helper used across modules
if SERVER then
    util.AddNetworkString("VEIN_ChatMessage")
end

function VEIN.Chat(ply, message)
    if CLIENT then
        chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), message)
        return
    end

    if IsValid(ply) then
        net.Start("VEIN_ChatMessage")
        net.WriteString(message)
        net.Send(ply)
    else
        print("[VEIN] " .. message)
    end
end

if CLIENT then
    net.Receive("VEIN_ChatMessage", function()
        local message = net.ReadString()
        chat.AddText(Color(255, 100, 100), "[VEIN] ", Color(255, 255, 255), message)
    end)
end

-- Files grouped by execution realm
local sharedFiles = {
    "vein_doors/sh_net_utils.lua",
    "vein_doors/sh_access_levels.lua",
    "vein_doors/sh_door_groups.lua",
}

local clientFiles = {
    "vein_doors/client/cl_door_gui.lua",
    "vein_doors/client/cl_settings_panel_new.lua",
    "vein_doors/client/cl_tutorial.lua",
    "vein_doors/client/cl_notifications.lua",
    "vein_doors/client/cl_admin_menu.lua",
    "vein_doors/client/cl_darkrp_override.lua",
    "vein_doors/client/cl_broken_door_effects.lua",
}

local serverFiles = {
    "vein_doors/server/sv_settings.lua",
    "vein_doors/server/sv_settings_new.lua",
    "vein_doors/server/sv_property_groups.lua",
    "vein_doors/server/sv_linked_doors.lua",
    "vein_doors/server/sv_door_persistence.lua",
    "vein_doors/server/sv_custom_doors.lua",
    "vein_doors/server/sv_access_levels.lua",
    "vein_doors/server/sv_clear_doors.lua",
    "vein_doors/server/sv_darkrp_override.lua",
    "vein_doors/server/sv_simple_building_system_compat.lua",
    "vein_doors/server/sv_keys_replacement.lua",
    "vein_doors/server/sv_keys_compat.lua",
}

if SERVER then
    -- Network strings used across modules
    util.AddNetworkString("VEIN_UpdateSettings")
    util.AddNetworkString("VEIN_UpdateDoorLimit")
    util.AddNetworkString("VEIN_RequestSettings")
    util.AddNetworkString("VEIN_GetPlayerList")
    util.AddNetworkString("VEIN_RequestDoorList")
    util.AddNetworkString("VEIN_DoorListData")
    util.AddNetworkString("VEIN_TeleportToDoor")
    util.AddNetworkString("VEIN_EnableDoor")
    util.AddNetworkString("VEIN_DisableDoor")
    util.AddNetworkString("VEIN_DeleteDoor")
    util.AddNetworkString("VEIN_ShowJobDoorHologram")

    -- Make shared + client files available to clients
    for _, path in ipairs(sharedFiles) do
        AddCSLuaFile(path)
        include(path)
    end

    for _, path in ipairs(clientFiles) do
        AddCSLuaFile(path)
    end

    AddCSLuaFile("weapons/vein_keys.lua")

    -- Load server-only modules
    for _, path in ipairs(serverFiles) do
        include(path)
    end
else -- CLIENT
    for _, path in ipairs(sharedFiles) do
        include(path)
    end

    for _, path in ipairs(clientFiles) do
        include(path)
    end
end
