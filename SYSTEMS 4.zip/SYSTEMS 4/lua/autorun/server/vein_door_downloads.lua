-- Ensure required VEIN assets are sent to clients
if SERVER then
    resource.AddFile("materials/VGUI/entities/vein_keys.png")
    resource.AddFile("materials/vein/tutorial/config_panel.png")
end
