if SERVER then
	CreateConVar("sv_minimap_minareasize", "300", {FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE}, "Error size for rects")
	CreateConVar("sv_minimap_chunksize", "25", {FCVAR_ARCHIVE, FCVAR_REPLICATED, FCVAR_SERVER_CAN_EXECUTE}, "Chunk size for sending nav areas")

	util.AddNetworkString("SendNavAreas")
	util.AddNetworkString("SendNavAreasChunk")

	local navAreas = {}
	local chunks = {}
	local delay = 0.01  -- Delay in seconds between each chunk

	-- Function to load all nav areas
	local function LoadNavAreas()
		navAreas = navmesh.GetAllNavAreas()
		print("Loaded " .. #navAreas .. " nav areas.")
	end

	-- Function to get the loaded nav areas
	function GetNavAreas()
		LoadNavAreas()

		if #navAreas == 0 then
			print("No nav areas found, you need to generate the Navmesh.")
			return
		end

		local rects = {}
		for _, area in ipairs(navAreas) do        
			local center = area:GetCenter()
			local width = area:GetSizeX()
			local height = area:GetSizeY()

			if width * height < GetConVar("sv_minimap_minareasize"):GetInt() then  -- Adjust the minimum area threshold as needed
				continue
			end

			local elevation = area:GetZ(center)
			local corners = {area:GetCorner(0), area:GetCorner(1), area:GetCorner(2), area:GetCorner(3)}
			local function calculateSlope(corner1, corner2)
				local dx = corner2.x - corner1.x
				local dy = corner2.y - corner1.y
				local dz = corner2.z - corner1.z
				return math.deg(math.atan(dz / math.sqrt(dx * dx + dy * dy)))
			end

			local slopes = {
				calculateSlope(corners[1], corners[2]),
				calculateSlope(corners[2], corners[3]),
				calculateSlope(corners[3], corners[4]),
				calculateSlope(corners[4], corners[1])
			}

			local isFlat = true
			for _, slope in ipairs(slopes) do
				if math.abs(slope) > 0 then  -- Adjust the degree threshold as needed
					isFlat = false
					break
				end
			end
			local rect = {
				x = center.x - width / 2,
				y = center.y - height / 2,
				z = elevation,
				width = width,
				height = height,
				isFlat = isFlat,
				corners = {
					area:GetCorner(3),
					area:GetCorner(2),
					area:GetCorner(1),
					area:GetCorner(0)
				}
			}

			rects[area:GetID()] = rect
		end

		-- Split the rects table into chunks and send each chunk to clients with a delay
		local chunk = {}
		local count = 0
		local index = 0
		for id, rect in pairs(rects) do
			chunk[id] = rect
			count = count + 1
			index = index + 1
			if count >= GetConVar("sv_minimap_chunksize"):GetInt() then
				table.insert(chunks, chunk)
				chunk = {}
				count = 0
			end
		end
	end

	-- Function to send chunks to a specific client
	function SendChunksToClient(ply)
		if ply.recievingChunks == true then
			print("The client is already recieving chunks.")
			return
		end

		if #chunks == 0 then
			print("There are no chunks to send.")
			return
		end

		ply.recievingChunks = true

		local function SendChunks(index)
			if index > #chunks then
				-- Notify the client that all chunks have been sent
				net.Start("SendNavAreas")
				net.Send(ply)
				return
			end

			ply.recievingChunks = false
			net.Start("SendNavAreasChunk")
			net.WriteTable(chunks[index])
			net.Send(ply)

			timer.Simple(delay, function()
				SendChunks(index + 1)
			end)
		end

		-- Start sending chunks to the client
		SendChunks(1)
	end

	util.AddNetworkString("RequestNavAreas")

	net.Receive("RequestNavAreas", function(len, ply)
		SendChunksToClient(ply)
	end)

	hook.Add("Initialize", "LoadNavAreasOnMapLoad", function()
		timer.Simple(2, function()
			GetNavAreas()
		end)
	end)

	concommand.Add("sv_minimapsystem_regenerate", function(ply)
		if not ply:IsAdmin() then return end
		GetNavAreas()
	end)
end
if CLIENT then
	CreateClientConVar( "local_enable_minimap", "1", true, false )

	local enable = GetConVar( "local_enable_minimap" ) --GetConVar( "enable_minimap" )
	
	local normalMapx = CreateClientConVar("cl_minimap_normalmap_x", "50", true, false, "Map X position"):GetInt()
	local normalMapy = CreateClientConVar("cl_minimap_normalmap_y", "50", true, false, "Map Y position"):GetInt()
	local normalMapSizeX = CreateClientConVar("cl_minimap_normalmapsize_x", "300", true, false, "Map width"):GetInt()
	local normalMapSizeY = CreateClientConVar("cl_minimap_normalmapsize_y", "300", true, false, "Map height"):GetInt()
	local fullMapx, fullMapy, fullMapSizeX, fullMapSizeY = normalMapx, normalMapy, ScrW() - normalMapy*2, ScrH() - normalMapx*2

	CreateClientConVar("cl_minimap_drawplayertrail", "1", true, false, "Draw player trail on minimap")
	CreateClientConVar("cl_minimap_playertraillength", "1000", true, false, "Player trail length")
	CreateClientConVar("cl_minimap_drawprops", "1", true, false, "Draw physics props on minimap")
	CreateClientConVar("cl_minimap_rainbowtrail", "0", true, false, "Rainbow player trail")
	CreateClientConVar("cl_minimap_transparency", "250", true, false, "minimap transparency")
	CreateClientConVar("cl_minimap_iconsize", "50", true, false, "Size of icons on the minimap")
	CreateClientConVar("cl_minimap_fadetype", "1", true, false, "Fade type for minimap, 1 = map relative, 0 = player relative")
	CreateClientConVar("cl_minimap_fadedistance", "300", true, false, "Fading distance if player relative")
	CreateClientConVar("cl_minimap_drawnames", "1", true, false, "Draw NPC and Player names on minimap")
	CreateClientConVar("cl_minimap_ceilingculling", "1", true, false, "Culls rects above the ceiling")
	CreateClientConVar("cl_minimap_drawcones", "1", true, false, "Draw cones for NPCs and Players")
	CreateClientConVar("cl_minimap_entitydistance", "1500", true, false, "Maximum distance to render entities on the minimap")
	CreateClientConVar("cl_minimap_bgcolour_r", "0", true, false, "Background color red component")
	CreateClientConVar("cl_minimap_bgcolour_g", "0", true, false, "Background color green component")
	CreateClientConVar("cl_minimap_bgcolour_b", "0", true, false, "Background color blue component")
	CreateClientConVar("cl_minimap_fgcolour_r", "200", true, false, "Foreground color red component")
	CreateClientConVar("cl_minimap_fgcolour_g", "200", true, false, "Foreground color green component")
	CreateClientConVar("cl_minimap_fgcolour_b", "200", true, false, "Foreground color blue component")
	CreateClientConVar("cl_minimap_propcolor_r", "255", true, false, "Prop color red component")
	CreateClientConVar("cl_minimap_propcolor_g", "255", true, false, "Prop color green component")
	CreateClientConVar("cl_minimap_propcolor_b", "255", true, false, "Prop color blue component")
	CreateClientConVar("cl_minimap_textcolour_r", "255", true, false, "Text color red component")
	CreateClientConVar("cl_minimap_textcolour_g", "255", true, false, "Text color green component")
	CreateClientConVar("cl_minimap_textcolour_b", "255", true, false, "Text color blue component")
	CreateClientConVar("cl_minimap_drawborder", "0", true, false, "Draw border around the minimap")
	CreateClientConVar("cl_minimap_transparentcullthreshold", "5", true, false, "Cull rects with transparency below this threshold")
	CreateClientConVar("cl_minimap_showonhud", "1", true, false, "Show minimap on HUD")
	CreateClientConVar("cl_minimap_key", "M", true, false, "Key to toggle fullscreen minimap")
	CreateClientConVar("cl_minimap_drawinfotext", "1", true, false, "Draw information text on the minimap")
	CreateClientConVar("cl_minimap_drawplayers", "1", true, false, "Draw players on the minimap")
	CreateClientConVar("cl_minimap_drawcompass", "1", true, false, "Draw compass on minimap")
	
	local mapx, mapy, mapSizeX, mapSizeY = normalMapx, normalMapy, normalMapSizeX, normalMapSizeY
	local scale = 0.25 -- Adjust the scale factor as needed

	local fullscreenMap = false
	local mapRotation = 0
	local fullscreenMapPosition = Vector(0, 0, 0)

	local dragging = false
	local lastMouseX, lastMouseY = 0, 0
	local rotating = false

	local renderedRectsCount = 0

	local enemyNPCs = {
		"npc_combine_s",
		"npc_metropolice",
		"npc_gunship",
		"npc_helicopter",
		"npc_combinegunship",
		"npc_strider",
		"npc_manhack",
		"npc_cscanner",
		"npc_turret_floor",
		"npc_rollermine",
		"npc_turret_ground",
		"npc_zombie",
		"npc_fastzombie",
		"npc_poisonzombie",
		"npc_headcrab",
		"npc_headcrab_fast",
		"npc_headcrab_black",
		"npc_antlion",
		"npc_antlionguard",
		"npc_antlion_worker",
		"npc_antlion_grub",
		"npc_antlionguardian",
		"npc_barnacle"
	}

	local function IsFriendEntityName( name )
		for _, v in ipairs( enemyNPCs ) do
			if name == v then return false end
		end
		return true
	end

	local entityIcons = {
		["prop_ragdoll"] = Material("minimap/prop_ragdoll.png"),
		["npc_citizen"] = Material("minimap/npc_citizen.png"), 
		["npc_combine_s"] = Material("minimap/combine.png"), 
		["npc_metropolice"] = Material("minimap/combine.png"), 
		["func_button"] = Material("minimap/button.png"), 
		["gmod_button"] = Material("minimap/button.png"), 
		["func_rot_button"] = Material("minimap/button.png"), 
		["momentary_rot_button"] = Material("minimap/button.png"), 
		["npc_helicopter"] = Material("minimap/helikopterhelikopter.png"),
		["npc_combinegunship"] = Material("minimap/gunship.png"),
		["npc_gunship"] = Material("minimap/gunship.png"),
		["npc_cscanner"] = Material("minimap/scanner.png"),
		["npc_manhack"] = Material("minimap/manhack.png"),
		["npc_antlion"] = Material("minimap/antlion.png"),
		["npc_antlionguard"] = Material("minimap/antlionguard.png"),
		["npc_headcrab"] = Material("minimap/headcrab.png"),
		["item_healthkit"] = Material("minimap/health.png"),
		["item_healthcharger"] = Material("minimap/health.png"),
		["item_battery"] = Material("minimap/electric.png"),
		["item_suitcharger"] = Material("minimap/electric.png"),
		["prop_door_rotating"] = Material("minimap/door.png"),
		["func_door_rotating"] = Material("minimap/door.png"),
		["prop_thumper"] = Material("minimap/thumper.png"),
		["func_door"] = Material("minimap/door.png")
	}
	
	local mapReady = false

	local blur = Material( "pp/blurscreen" )
	function Blur( x, y, w, h, layers, density, alpha )
		--create a scissor rect to clip the blur effect
		render.SetScissorRect( x, y, x + w, y + h, true )
		
		surface.SetDrawColor( 255, 255, 255, alpha )
		surface.SetMaterial( blur )

		for i = 1, layers do
			blur:SetFloat( "$blur", ( i / layers ) * density )
			blur:Recompute()

			render.UpdateScreenEffectTexture()
			render.SetScissorRect( x, y, x + w, y + h, true )
			surface.DrawTexturedRect( 0, 0, ScrW(), ScrH() )
			render.SetScissorRect( 0, 0, 0, 0, false )
		end
	end

	local rects = {}
	local lines = {}
	local lastPlayerPos = {}

	hook.Add("PlayerSpawn", "ClearLinesOnSpawn", function(ply)
		lines[ply] = {}
		lastPlayerPos[ply] = ply:GetPos()
		table.insert(lines[ply], ply:GetPos())
	end)

	-- Function to check if the minimap rects file exists and load the file to the rects table
	local function LoadminimapRects()
		rects = {}

		local mapName = game.GetMap()
		local fileName = "minimap_rects_" .. mapName .. ".txt"
		if file.Exists(fileName, "DATA") then
			local fileContents = file.Read(fileName, "DATA")
			rects = util.JSONToTable(fileContents) or {}

			local sortedRects = {}
			for _, rect in pairs(rects) do
				table.insert(sortedRects, rect)
			end
	
			for i = 1, #sortedRects - 1 do
				for j = 1, #sortedRects - i do
					if sortedRects[j].z > sortedRects[j + 1].z then
						sortedRects[j], sortedRects[j + 1] = sortedRects[j + 1], sortedRects[j]
					end
				end
			end
	
			rects = sortedRects

			mapReady = true
			print("Loaded rects from " .. fileName)
		else
			print("Minimap rects file not found, asking server for rect data.")
			-- Request nav areas data from the server
			net.Start("RequestNavAreas")
			net.SendToServer()
		end
	end

	-- Call the function to load minimap rects
	hook.Add("Initialize", "LoadminimapRectsOnInitialize", function()
		timer.Simple(5, function()
			LoadminimapRects()
		end)
	end)

	LoadminimapRects()

	local maxElevationDifference = 0

	local function DrawRects()
		renderedRectsCount = 0

		local mapCentreX, mapCentreY = mapx + (mapSizeX / 2), mapy + (mapSizeY / 2)
		local player = LocalPlayer()
		local playerPos = fullscreenMapPosition
		local mapRotation = mapRotation

		if GetConVar("cl_minimap_fadetype"):GetInt() == 1 then
			local minElevation = math.huge
			local maxElevation = -math.huge

			for _, rect in pairs(rects) do
				if rect.z < minElevation then
					minElevation = rect.z
				end
				if rect.z > maxElevation then
					maxElevation = rect.z
				end
			end
	
			maxElevationDifference = maxElevation - minElevation
		else
			maxElevationDifference = GetConVar("cl_minimap_fadedistance"):GetInt()
		end

		local trace = {}
		trace.start = player:GetPos()
		trace.endpos = player:GetPos() + Vector(0, 0, 100000)
		trace.filter = player

		local traceResult = util.TraceLine(trace)
		local heightAbovePlayer = traceResult.HitPos.z

		local sortedRects = {}
		for _, rect in pairs(rects) do
			table.insert(sortedRects, rect)
		end

		local propRects = {}
		local checkRadius = GetConVar("cl_minimap_entitydistance"):GetInt()
		if GetConVar("cl_minimap_drawprops"):GetBool() then
			for _, prop in ipairs(ents.FindInSphere(player:GetPos(), checkRadius)) do
				if prop:GetClass():find("prop_physics") then
					local propPos = prop:GetPos()
					local propScreenPosX = (propPos.x - player:GetPos().x) * scale + mapx + mapSizeX / 2
					local propScreenPosY = (propPos.y - player:GetPos().y) * scale + mapy + mapSizeY / 2

					if propScreenPosX < mapx or propScreenPosX > mapx + mapSizeX or propScreenPosY < mapy or propScreenPosY > mapy + mapSizeY then
						continue
					end

					local propMin, propMax = prop:GetCollisionBounds()
					local propWidth = propMax.x - propMin.x
					local propHeight = propMax.y - propMin.y
					local propYaw = prop:GetAngles().yaw
					local propRect = {
						x = propPos.x - propWidth / 2,
						y = propPos.y - propHeight / 2,
						z = propPos.z,
						width = propWidth,
						height = propHeight,
						isFlat = true,
						yaw = propYaw,
						tint = Color(GetConVar("cl_minimap_propcolor_r"):GetInt(), GetConVar("cl_minimap_propcolor_g"):GetInt(), GetConVar("cl_minimap_propcolor_b"):GetInt())
					}
					table.insert(propRects, propRect)
				end
			end

			table.sort(propRects, function(a, b)
				return a.z < b.z
			end)

			local mergedRects = {}
			local i, j = 1, 1

			while i <= #sortedRects and j <= #propRects do
				if sortedRects[i].z <= propRects[j].z then
					table.insert(mergedRects, sortedRects[i])
					i = i + 1
				else
					table.insert(mergedRects, propRects[j])
					j = j + 1
				end
			end

			while i <= #sortedRects do
				table.insert(mergedRects, sortedRects[i])
				i = i + 1
			end

			while j <= #propRects do
				table.insert(mergedRects, propRects[j])
				j = j + 1
			end

			sortedRects = mergedRects
		end

		for _, rect in ipairs(sortedRects) do
			draw.NoTexture()
			if GetConVar("cl_minimap_ceilingculling"):GetBool() then
				if rect.z >= heightAbovePlayer and not fullscreenMap then
					continue
				end
			end

			local rectCenterX = rect.x + rect.width / 2
			local rectCenterY = rect.y + rect.height / 2

			local offsetX = (rectCenterX - playerPos.x) * scale
			local offsetY = (rectCenterY - playerPos.y) * scale
			local offsetZ = (rect.z - playerPos.z) * (scale * 0.5)
			
			local rotatedX = offsetX * math.cos(math.rad(mapRotation)) - offsetY * math.sin(math.rad(mapRotation))
			local rotatedY = offsetX * math.sin(math.rad(mapRotation)) + offsetY * math.cos(math.rad(mapRotation))
			
			local drawX = mapCentreX + rotatedX - (rect.width * scale) / 2
			local drawY = mapCentreY - rotatedY - (rect.height * scale) / 2 - offsetZ
			
			local drawWidth = rect.width * scale
			local drawHeight = rect.height * scale
			
			if drawX + drawWidth < mapx or drawX > mapx + mapSizeX or drawY + drawHeight < mapy or drawY > mapy + mapSizeY then
				continue
			end
			
			local elevationDifference = math.abs(rect.z - playerPos.z)
			local alpha = math.Clamp(255 - (math.log(elevationDifference + 1) / math.log(maxElevationDifference + 1)) * 255, 1, 255)
			local colour = Color(GetConVar("cl_minimap_fgcolour_r"):GetInt(), GetConVar("cl_minimap_fgcolour_g"):GetInt(), GetConVar("cl_minimap_fgcolour_b"):GetInt(), alpha)

			if alpha < GetConVar("cl_minimap_transparentcullthreshold"):GetInt() then
				continue
			end

			if rect.tint then
				surface.SetDrawColor(rect.tint.r, rect.tint.g, rect.tint.b, alpha)
			else
				surface.SetDrawColor(colour, colour, colour, alpha)
			end
			
			render.SetScissorRect(mapx, mapy, mapSizeX + mapx, mapSizeY + mapy, true)

			local angle = 0
			if rect.yaw then
				angle = rect.yaw
			end

			if not rect.isFlat then
				local poly = {}
				for i = 1, 4 do
					local corner = rect.corners[i]
					local cornerOffsetX = (corner.x - playerPos.x) * scale
					local cornerOffsetY = (corner.y - playerPos.y) * scale
					local cornerOffsetZ = (corner.z - playerPos.z) * (scale * 0.5)

					local cornerRotatedX = cornerOffsetX * math.cos(math.rad(mapRotation)) - cornerOffsetY * math.sin(math.rad(mapRotation))
					local cornerRotatedY = cornerOffsetX * math.sin(math.rad(mapRotation)) + cornerOffsetY * math.cos(math.rad(mapRotation))

					local cornerDrawX = mapCentreX + cornerRotatedX
					local cornerDrawY = mapCentreY - cornerRotatedY - cornerOffsetZ

					table.insert(poly, {x = cornerDrawX, y = cornerDrawY})
				end

				draw.NoTexture()
				surface.DrawPoly(poly)
			else
				surface.DrawTexturedRectRotated(drawX + drawWidth / 2 - 0.5, drawY + drawHeight / 2 - 1, drawWidth + 1, drawHeight + 1, mapRotation + angle)
			end
			render.SetScissorRect(0, 0, 0, 0, false)

			renderedRectsCount = renderedRectsCount + 1
		end
    end

local function DrawText()
	local LocalPlayer = LocalPlayer()

	local bgColor = Color(GetConVar("cl_minimap_bgcolour_r"):GetInt(), GetConVar("cl_minimap_bgcolour_g"):GetInt(), GetConVar("cl_minimap_bgcolour_b"):GetInt(), GetConVar("cl_minimap_transparency"):GetInt() )
	local fgColor = Color(GetConVar("cl_minimap_fgcolour_r"):GetInt(), GetConVar("cl_minimap_fgcolour_g"):GetInt(), GetConVar("cl_minimap_fgcolour_b"):GetInt(), GetConVar("cl_minimap_transparency"):GetInt() )
	local textColor = Color(GetConVar("cl_minimap_textcolour_r"):GetInt(), GetConVar("cl_minimap_textcolour_g"):GetInt(), GetConVar("cl_minimap_textcolour_b"):GetInt(), 255)

	local mapName = string.upper(game.GetMap())
	surface.SetFont("MinimapFontLarge")
	local textWidth, textHeight = surface.GetTextSize(mapName)
	local textX, textY = mapx, mapy - textHeight - 7
	surface.SetDrawColor(bgColor)
	surface.DrawRect(textX, textY - 5, textWidth + 10, textHeight + 10)
	surface.SetTextColor(textColor)
	surface.SetTextPos(textX + 5, textY)
	surface.DrawText(mapName)

	if GetConVar("cl_minimap_drawborder"):GetBool() then
		surface.SetDrawColor(fgColor)
		surface.DrawOutlinedRect(textX, textY - 5, textWidth + 10, textHeight + 10)
	end

	local gamemodeName = string.upper(engine.ActiveGamemode())
	local gmTextX = textX + textWidth + 20
	surface.SetFont("MinimapFontLarge")
	local gmTextWidth, gmTextHeight = surface.GetTextSize(gamemodeName)
	surface.SetDrawColor(bgColor)
	surface.DrawRect(gmTextX - 5, textY - 5, gmTextWidth + 10, gmTextHeight + 10)
	surface.SetTextColor(textColor)
	surface.SetTextPos(gmTextX, textY)
	surface.DrawText(gamemodeName)

	if GetConVar("cl_minimap_drawborder"):GetBool() then
		surface.SetDrawColor(fgColor)
		surface.DrawOutlinedRect(gmTextX - 5, textY - 5, gmTextWidth + 10, gmTextHeight + 10)
	end

	local playerPos = LocalPlayer:GetPos()
	local coordText = string.format("X: %.1f - Y: %.1f - Z: %.1f", playerPos.x, playerPos.y, playerPos.z)
	surface.SetFont("MinimapFont")
	local coordWidth, coordHeight = surface.GetTextSize(coordText)
	local coordX, coordY = mapx, mapy + mapSizeY + 2
	surface.SetDrawColor(bgColor)
	surface.DrawRect(coordX, coordY, coordWidth + 10, coordHeight + 10)
	surface.SetTextColor(textColor)
	surface.SetTextPos(coordX + 5, coordY + 5)
	surface.DrawText(coordText)

	if GetConVar("cl_minimap_drawborder"):GetBool() then
		surface.SetDrawColor(fgColor)
		surface.DrawOutlinedRect(coordX, coordY, coordWidth + 10, coordHeight + 10)
	end

	local playerAngleText = string.format("Angle: %.0f", LocalPlayer:EyeAngles().y)
	surface.SetFont("MinimapFont")
	local angleWidth, angleHeight = surface.GetTextSize(playerAngleText)
	local angleX, angleY = mapx + coordWidth + 15, mapy + mapSizeY + 2
	surface.SetDrawColor(bgColor)
	surface.DrawRect(angleX, angleY, angleWidth + 10, angleHeight + 10)
	surface.SetTextColor(textColor)
	surface.SetTextPos(angleX + 5, angleY + 5)
	surface.DrawText(playerAngleText)

	if GetConVar("cl_minimap_drawborder"):GetBool() then
		surface.SetDrawColor(fgColor)
		surface.DrawOutlinedRect(angleX, angleY, angleWidth + 10, angleHeight + 10)
	end

	local rectCountText = "Rects: " .. renderedRectsCount .. "/" .. tostring(table.Count(rects))
	local rectCountWidth, rectCountHeight = surface.GetTextSize(rectCountText)
	local rectCountX, rectCountY = mapx + (angleWidth + coordWidth) + 30, mapy + mapSizeY + 2
	surface.SetDrawColor(bgColor)
	surface.DrawRect(rectCountX, rectCountY, rectCountWidth + 10, rectCountHeight + 10)
	surface.SetTextColor(textColor)
	surface.SetTextPos(rectCountX + 5, rectCountY + 5)
	surface.DrawText(rectCountText)

	if GetConVar("cl_minimap_drawborder"):GetBool() then
		surface.SetDrawColor(fgColor)
		surface.DrawOutlinedRect(rectCountX, rectCountY, rectCountWidth + 10, rectCountHeight + 10)
	end
end

function Paintminimap()
	if not enable:GetBool() then
		return
	end

	if not GetConVar("cl_minimap_showonhud"):GetBool() and not fullscreenMap then
		return
	end

	local LocalPlayer = LocalPlayer()

	if IsValid(LocalPlayer) then
		if GetConVar("cl_minimap_drawinfotext"):GetBool() then
			DrawText()
		end

		Blur(mapx, mapy, mapSizeX, mapSizeY, 3, 6, 255)
		surface.SetDrawColor( GetConVar("cl_minimap_bgcolour_r"):GetInt(), GetConVar("cl_minimap_bgcolour_g"):GetInt(), GetConVar("cl_minimap_bgcolour_b"):GetInt(), GetConVar("cl_minimap_transparency"):GetInt() )
		draw.NoTexture()
		surface.DrawRect(mapx, mapy, mapSizeX, mapSizeY)

		if mapReady then
			DrawRects()
			surface.SetDrawColor(255, 255, 255, 255)
		else
			surface.SetTextColor(255, 255, 255, 255)
			local text = "Loading Map"
			surface.SetFont('MinimapFontLarge')
			local textWidth, textHeight = surface.GetTextSize(text)
			surface.SetTextPos(mapx + (mapSizeX - textWidth) / 2, mapy + (mapSizeY - textHeight) / 2)
			surface.DrawText(text)
		end

		local PlayerAngle = EyeAngles()

		if GetConVar("cl_minimap_drawplayertrail"):GetBool() then
			-- Draw lines for each player
			for ply, plyLines in pairs(lines) do
				local color = ply:GetPlayerColor()
				color.r = color.r * 255
				color.g = color.g * 255
				color.b = color.b * 255

				if color.r < 50 and color.g < 50 and color.b < 50 then
					color.r = math.min(color.r + 255, 255)
					color.g = math.min(color.g + 255, 255)
					color.b = math.min(color.b + 255, 255)
				end

				for i = 1, #plyLines - 1 do
					local startPos = (fullscreenMapPosition - plyLines[i]) * scale
					local endPos = (fullscreenMapPosition - plyLines[i + 1]) * scale

					startPos:Rotate(Angle(0, mapRotation, 0))
					endPos:Rotate(Angle(0, mapRotation, 0))

					local startX = mapx + (mapSizeX / 2) - startPos.x
					local startY = mapy + (mapSizeY / 2) + startPos.y + startPos.z / 2
					local endX = mapx + (mapSizeX / 2) - endPos.x
					local endY = mapy + (mapSizeY / 2) + endPos.y + endPos.z / 2

					local alpha = 255 * (i / #plyLines)
					if GetConVar("cl_minimap_rainbowtrail"):GetBool() then
						local hue = (i / #plyLines) * 360
						color = HSVToColor(hue, 1, 1)
					end

					surface.SetDrawColor(color.r, color.g, color.b, alpha)
					render.SetScissorRect(mapx, mapy, mapx + mapSizeX, mapy + mapSizeY, true)
					surface.DrawLine(startX, startY, endX, endY)
					render.SetScissorRect(0, 0, 0, 0, false)
				end
			end
		end

		if GetConVar("cl_minimap_drawborder"):GetBool() then
			surface.SetDrawColor(GetConVar("cl_minimap_fgcolour_r"):GetInt(), GetConVar("cl_minimap_fgcolour_g"):GetInt(), GetConVar("cl_minimap_fgcolour_b"):GetInt(), 255)
			surface.DrawOutlinedRect(mapx, mapy, mapSizeX, mapSizeY)
		end

		local PlayerPos = LocalPlayer:GetPos()
		local checkRadius = GetConVar("cl_minimap_entitydistance"):GetInt()

		for i, v in pairs( ents.FindInSphere( PlayerPos, checkRadius ) ) do
				if !IsValid( v ) then continue end

				if not GetConVar("cl_minimap_drawplayers"):GetBool() and v:IsPlayer() and not v == LocalPlayer then
					continue
				end

				local pos
				if fullscreenMap then
					pos = (fullscreenMapPosition - v:GetPos()) * scale
					pos:Rotate(Angle(0, mapRotation, 0))
				else
					pos = (PlayerPos - v:GetPos()) * scale
					pos:Rotate(Angle(0, -PlayerAngle.y + 90, 0))
				end

				local elevationDifference = math.abs(v:GetPos().z - PlayerPos.z)
				local distance = v:GetPos():Distance(PlayerPos)
				local alpha = math.Clamp(255 - (elevationDifference / maxElevationDifference) * 255, 1, 255)
				alpha = alpha * math.Clamp(1 - (distance / checkRadius), 0, 1)
				
				local iconSize = GetConVar("cl_minimap_iconsize"):GetFloat() * scale
				local verticalOffset = pos.z / 2
				local iconOrigin = Vector(mapx + (mapSizeX / 2) - pos.x + (scale / 2), mapy + (mapSizeY / 2) + pos.y - (scale / 2), 0)
				local clampedOrigin = Vector(math.Clamp(iconOrigin.x, mapx, mapx + mapSizeX), math.Clamp(iconOrigin.y, mapy - verticalOffset, mapy + mapSizeY - verticalOffset), 0)
				local icon = entityIcons[v:GetClass()]

				if not icon and v:IsNPC() or v:IsPlayer() or v:IsNextBot()  then
					icon = entityIcons["npc_citizen"]
				end
				
				if icon then
					local name = ""
					if v:IsPlayer() then
						name = v:Nick()
					elseif v:IsNPC() or v:IsNextBot() then
						name = v:GetClass()
					end

					local color
					if v:IsNPC() then
						if IsFriendEntityName(v:GetClass()) then
							color = Color(0, 255, 0, alpha)  -- Green for friendly NPCs
						else
							color = Color(255, 0, 0, alpha)  -- Red for enemy NPCs
						end
					else
						color = Color(255, 255, 255, alpha)  -- White for other entities
					end

					if v:IsPlayer() or v:IsNPC() or v:IsNextBot()  then
						-- Draw segmented cone for each player
						local function DrawSegmentedCone(origin, angle, fov, segments, length, color)
							local step = fov / segments
							local halfFov = fov / 2
							local poly = {}
	
							table.insert(poly, {x = origin.x, y = origin.y})
	
							for i = -halfFov, halfFov, step do
								local rad = math.rad(i + angle)
								local endPos = origin + Vector(math.cos(rad) * length, math.sin(rad) * length, 0)
								table.insert(poly, {x = endPos.x, y = endPos.y})
							end
	
							surface.SetDrawColor(color.r, color.g, color.b, color.a)
							draw.NoTexture()
							render.SetScissorRect(mapx, mapy, mapx + mapSizeX, mapy + mapSizeY, true)
							surface.DrawPoly(poly)
							render.SetScissorRect(0, 0, 0, 0, false)
						end
	
						if GetConVar("cl_minimap_drawcones"):GetBool() then
							local vAngle = -v:EyeAngles().y
							local coneLength = 500 * scale  -- Adjust the length as needed
							local coneFov = 90  -- 90 degrees field of view
							if v == LocalPlayer then
								coneFov = LocalPlayer:GetFOV()
							end
							local coneSegments = 10  -- Number of segments in the cone
							local coneColor = Color(255, 255, 255, alpha * 0.05)  -- Yellow color with some transparency
		
							local coneOrigin = Vector(iconOrigin.x, iconOrigin.y + verticalOffset, 0)
		
							DrawSegmentedCone(coneOrigin, vAngle - mapRotation, coneFov, coneSegments, coneLength, coneColor)
						end
					end

					surface.SetDrawColor(255, 255, 255, alpha)
					if v:IsNPC() or v:IsNextBot() then
						if IsFriendEntityName( v:GetClass() ) then
							surface.SetDrawColor( Color(255,255,255,alpha) )
							surface.SetTextColor( Color(255 * alpha, 255 * alpha, 255 * alpha, alpha))
						else
							surface.SetDrawColor( Color(255,0,0,alpha) )
							surface.SetTextColor( Color(255 * alpha, 0, 0 , alpha))
						end
					end

					if v:IsPlayer() then
						local plyColour = v:GetPlayerColor()
						plyColour.r = plyColour.r * 255
						plyColour.g = plyColour.g * 255
						plyColour.b = plyColour.b * 255
						
						if plyColour.r < 50 and plyColour.g < 50 and plyColour.b < 50 then
							plyColour.r = math.min(plyColour.r + 255, 255)
							plyColour.g = math.min(plyColour.g + 255, 255)
							plyColour.b = math.min(plyColour.b + 255, 255)
						end
						
						color = plyColour
					end

					if GetConVar("cl_minimap_drawnames"):GetBool() and #name > 0 then
						local textWidth, textHeight = surface.GetTextSize(name)
						surface.SetDrawColor(0, 0, 0, alpha * 0.5)
						surface.DrawRect(clampedOrigin.x - textWidth / 2 - 2, clampedOrigin.y + verticalOffset - iconSize / 2 - textHeight - 2, textWidth + 4, textHeight + 4)
						surface.SetFont("MinimapFont")
						surface.SetTextPos(clampedOrigin.x - textWidth / 2, clampedOrigin.y + verticalOffset - iconSize / 2 - textHeight)
						surface.SetTextColor(color.r, color.g, color.b, alpha)
						surface.DrawText(name)
					end
					
					if v:IsNPC() or v:IsPlayer() or v:IsNextBot() then
						surface.SetDrawColor(color.r, color.g, color.b, alpha)
						surface.DrawLine(clampedOrigin.x, clampedOrigin.y, clampedOrigin.x, clampedOrigin.y + verticalOffset)
					end

					surface.SetDrawColor(color.r, color.g, color.b, alpha)
					surface.SetMaterial(icon)
					local halfSize = iconSize * 0.5
					surface.DrawTexturedRect(clampedOrigin.x - halfSize, clampedOrigin.y + verticalOffset - halfSize, iconSize, iconSize)
				end

				if v == LocalPlayer and fullscreenMap then
					surface.SetDrawColor(255, 255, 255, 20)
					surface.DrawLine(ScrW() / 2, ScrH() / 2, iconOrigin.x, iconOrigin.y + verticalOffset)
				end
			end

			if GetConVar("cl_minimap_drawcompass"):GetBool() then
				local compassX = mapx + mapSizeX / 2
				local compassY = mapy + mapSizeY / 2
				local squareSize = 20
				local radius = math.sqrt((mapSizeX / 2) ^ 2 + (mapSizeY / 2) ^ 2)

				local directions = {
					{angle = 0, label = "N"},
					{angle = 90, label = "E"},
					{angle = 180, label = "S"},
					{angle = 270, label = "W"}
				}

				for _, dir in ipairs(directions) do
					local angle = math.rad(-mapRotation + dir.angle)
					local rotatedX = compassX + radius * math.cos(angle)
					local rotatedY = compassY + radius * math.sin(angle)
					local clampedX = math.Clamp(rotatedX, mapx + squareSize / 2, mapx + mapSizeX - squareSize / 2)
					local clampedY = math.Clamp(rotatedY, mapy, mapy + mapSizeY - squareSize)
					local textColor = Color(255, 255, 255, 255)
					local bgColor = Color(0, 0, 0, 255)
					if dir.label == "N" then
						textColor = Color(0, 0, 0, 255)
						bgColor = Color(255, 255, 255, 255)
					end
					surface.SetDrawColor(bgColor)
					surface.DrawRect(clampedX - squareSize / 2, clampedY, squareSize, squareSize)
					draw.DrawText(dir.label, "MinimapFontLarge", clampedX, clampedY, textColor, TEXT_ALIGN_CENTER)
				end
			end
		end

		if rotating and fullscreenMap then
			local halfSizeX = normalMapSizeX / 2
			local halfSizeY = normalMapSizeY / 2
			local centerX, centerY = ScrW() / 2, ScrH() / 2

			surface.SetDrawColor(255, 255, 255, 50)
			surface.DrawOutlinedRect(centerX - halfSizeX, centerY - halfSizeY, normalMapSizeX, normalMapSizeY)
		end
	end
	
	local lastToggleTime = 0
	local toggleDelay = 0.4  -- Delay in seconds

	hook.Add("Think", "ToggleFullMap", function()
		for _, ply in ipairs(player.GetAll()) do
			local playerPos = ply:GetPos()
			if not lines[ply] then
				lines[ply] = {}
				lastPlayerPos[ply] = playerPos
			end

			if playerPos:Distance(lastPlayerPos[ply]) > 100 then
				lines[ply] = {}
				lastPlayerPos[ply] = playerPos
			end

			if playerPos:Distance(lastPlayerPos[ply]) > 10 then  -- Adjust the distance threshold as needed
				table.insert(lines[ply], playerPos)
				lastPlayerPos[ply] = playerPos
				if #lines[ply] > GetConVar("cl_minimap_playertraillength"):GetInt() then  -- Adjust the limit as needed
					table.remove(lines[ply], 1)
				end
			end
		end

		if input.IsKeyDown(input.GetKeyCode(cvars.String("cl_minimap_key", "M"))) and CurTime() > lastToggleTime + toggleDelay then
			fullscreenMap = not fullscreenMap
			if fullscreenMap then
				mapx, mapy, mapSizeX, mapSizeY = fullMapx, fullMapy, fullMapSizeX, fullMapSizeY
				gui.EnableScreenClicker(true)
			else
				mapx, mapy, mapSizeX, mapSizeY = normalMapx, normalMapy, normalMapSizeX, normalMapSizeY
				gui.EnableScreenClicker(false)
			end
			lastToggleTime = CurTime()
		end

		if fullscreenMap then
			if input.IsMouseDown(MOUSE_LEFT) then
				local mx, my = gui.MouseX(), gui.MouseY()
				if not dragging then
					dragging = true
					lastMouseX, lastMouseY = mx, my
				else
					local dx, dy = mx - lastMouseX, my - lastMouseY
					dx = -dx / scale
					dy = dy / scale
					local r = math.rad(-mapRotation)
					local c, s = math.cos(r), math.sin(r)
					local ndx = dx * c - dy * s
					local ndy = dx * s + dy * c
					fullscreenMapPosition = fullscreenMapPosition + Vector(ndx, ndy, 0)
					lastMouseX, lastMouseY = mx, my
				end
			else
				dragging = false
			end

			if input.IsMouseDown(MOUSE_RIGHT) then
				local mx, my = gui.MouseX(), gui.MouseY()
				if not rotating then
					rotating = true
					lastMouseX, lastMouseY = mx, my
				else
					local dx = mx - lastMouseX
					local dy = my - lastMouseY
					mapRotation = mapRotation + dx * 0.2
					if input.IsKeyDown(KEY_LSHIFT) or input.IsKeyDown(KEY_RSHIFT) then
						fullscreenMapPosition.z = fullscreenMapPosition.z + dy / scale  -- Adjust the Z position using vertical mouse delta
					else
						scale = math.Clamp(scale - dy * 0.001, 0.1, 4)  -- Adjust the scale factor as needed
					end
					lastMouseX, lastMouseY = mx, my
				end
			else
				rotating = false
			end
		else
			dragging = false
			rotating = false

			fullscreenMapPosition = LocalPlayer():GetPos()
			mapRotation = -LocalPlayer():EyeAngles().y + 90
		end
	end)

	hook.Add("HUDPaint","minimap", Paintminimap)

	surface.CreateFont( 'MinimapFont', {
		font = 'Borda Regular 9',
		size = 12,
		weight = 1000,
		blursize = 0,
		scanlines = 0,
		antialias = true
	} )

	surface.CreateFont( 'MinimapFontLarge', {
		font = 'Borda Regular 9',
		size = 21,
		weight = 0,
		blursize = 0,
		scanlines = 0,
		antialias = true
	} )

	net.Receive("SendNavAreasChunk", function()
        local chunk = net.ReadTable()
        for id, rect in pairs(chunk) do
            rects[id] = rect
        end
    end)

    -- Function to handle the end of nav areas transmission
    net.Receive("SendNavAreas", function()
        surface.PlaySound("buttons/button14.wav")
        print("All nav areas received.")
		notification.AddLegacy("All nav areas received and saved.", NOTIFY_GENERIC, 5)

		for _, prop in ipairs(ents.FindByClass("prop_dynamic")) do
			local propPos = prop:GetPos()
			local propMin, propMax = prop:GetCollisionBounds()
			local propWidth = propMax.x - propMin.x
			local propHeight = propMax.y - propMin.y
			local propYaw = prop:GetAngles().yaw
			local propRect = {
				x = propPos.x - propWidth / 2,
				y = propPos.y - propHeight / 2,
				z = propPos.z,
				width = propWidth,
				height = propHeight,
				isFlat = true,
				yaw = propYaw,
				tint = Color(GetConVar("cl_minimap_propcolor_r"):GetInt(), GetConVar("cl_minimap_propcolor_g"):GetInt(), GetConVar("cl_minimap_propcolor_b"):GetInt())
			}
			table.insert(rects, propRect)
		end

		local sortedRects = {}
		for _, rect in pairs(rects) do
			table.insert(sortedRects, rect)
		end

		for i = 1, #sortedRects - 1 do
			for j = 1, #sortedRects - i do
				if sortedRects[j].z > sortedRects[j + 1].z then
					sortedRects[j], sortedRects[j + 1] = sortedRects[j + 1], sortedRects[j]
				end
			end
		end

		rects = sortedRects

		-- Save rects to a file
		local mapName = game.GetMap()
		local fileName = "minimap_rects_" .. mapName .. ".txt"
		if file.Exists(fileName, "DATA") then
			file.Delete(fileName)
		end
		file.Write(fileName, util.TableToJSON(rects))
		print("Saved rects to " .. fileName)

		mapReady = true
    end)

	-- Console command to request minimap rects for the client
	concommand.Add("cl_minimapsystem_request_rects", function(ply, cmd, args)
		if not IsValid(ply) or not ply:IsPlayer() then return end
		rects = {}
		net.Start("RequestNavAreas")
		net.SendToServer()
	end)

	concommand.Add("cl_minimapsystem_reset_settings", function()
		LocalPlayer():ConCommand("cl_minimap_normalmap_x 50")
		LocalPlayer():ConCommand("cl_minimap_normalmap_y 50")
		LocalPlayer():ConCommand("cl_minimap_normalmapsize_x 300")
		LocalPlayer():ConCommand("cl_minimap_normalmapsize_y 300")
		LocalPlayer():ConCommand("cl_minimap_drawplayertrail 1")
		LocalPlayer():ConCommand("cl_minimap_playertraillength 1000")
		LocalPlayer():ConCommand("cl_minimap_drawprops 1")
		LocalPlayer():ConCommand("cl_minimap_rainbowtrail 0")
		LocalPlayer():ConCommand("cl_minimap_transparency 250")
		LocalPlayer():ConCommand("cl_minimap_iconsize 50")
		LocalPlayer():ConCommand("cl_minimap_fadetype 1")
		LocalPlayer():ConCommand("cl_minimap_fadedistance 300")
		LocalPlayer():ConCommand("cl_minimap_drawnames 1")
		LocalPlayer():ConCommand("cl_minimap_ceilingculling 1")
		LocalPlayer():ConCommand("cl_minimap_drawcones 1")
		LocalPlayer():ConCommand("cl_minimap_drawcompass 1")
		LocalPlayer():ConCommand("cl_minimap_entitydistance 1500")
		LocalPlayer():ConCommand("cl_minimap_bgcolour_r 0")
		LocalPlayer():ConCommand("cl_minimap_bgcolour_g 0")
		LocalPlayer():ConCommand("cl_minimap_bgcolour_b 0")
		LocalPlayer():ConCommand("cl_minimap_fgcolour_r 200")
		LocalPlayer():ConCommand("cl_minimap_fgcolour_g 200")
		LocalPlayer():ConCommand("cl_minimap_fgcolour_b 200")
		LocalPlayer():ConCommand("cl_minimap_propcolor_r 255")
		LocalPlayer():ConCommand("cl_minimap_propcolor_g 255")
		LocalPlayer():ConCommand("cl_minimap_propcolor_b 255")
		LocalPlayer():ConCommand("cl_minimap_textcolour_r 255")
		LocalPlayer():ConCommand("cl_minimap_textcolour_g 255")
		LocalPlayer():ConCommand("cl_minimap_textcolour_b 255")
		LocalPlayer():ConCommand("cl_minimap_drawborder 0")
		LocalPlayer():ConCommand("cl_minimap_transparentcullthreshold 5")
		LocalPlayer():ConCommand("cl_minimap_showonhud 1")
		LocalPlayer():ConCommand("cl_minimap_key M")
		LocalPlayer():ConCommand("cl_minimap_drawinfotext 1")
		LocalPlayer():ConCommand("cl_minimap_drawplayers 1")
		LocalPlayer():ConCommand("local_enable_minimap 1")
		notification.AddLegacy("3D Minimap options reset to defaults.", NOTIFY_GENERIC, 3)
	end)

	-- Create a spawn menu option for the minimap
	hook.Add("PopulateToolMenu", "3DMinimapSettings", function()
		spawnmenu.AddToolMenuOption("Utilities", "User", "3D Minimap", "3D Minimap", "", "", function(panel)
			panel:ClearControls()
			panel:CheckBox("Enable minimap", "local_enable_minimap")

			panel:TextEntry("Map Key", "cl_minimap_key")

			panel:CheckBox("Show minimap on HUD", "cl_minimap_showonhud")

			panel:CheckBox("Draw Physics Props", "cl_minimap_drawprops")

			panel:CheckBox("Draw Names", "cl_minimap_drawnames")

			panel:CheckBox("Draw Players", "cl_minimap_drawplayers")

			panel:CheckBox("Draw Cones", "cl_minimap_drawcones")

			panel:CheckBox("Ceiling Culling", "cl_minimap_ceilingculling")

			panel:NumSlider("Transparent Cull Threshold", "cl_minimap_transparentcullthreshold", 0, 255, 0)

			panel:NumSlider("Entity Distance", "cl_minimap_entitydistance", 0, 10000, 0)

			panel:NumSlider("Fade Type", "cl_minimap_fadetype", 0, 1, 0)
			panel:NumSlider("Fade Distance", "cl_minimap_fadedistance", 0, 1000, 0)

			panel:NumSlider("Icon Size", "cl_minimap_iconsize", 0, 100, 0)

			panel:NumSlider("Minimap Transparency", "cl_minimap_transparency", 0, 255, 0)

			panel:CheckBox("Draw Compass", "cl_minimap_drawcompass")

			panel:CheckBox("Draw Information Text", "cl_minimap_drawinfotext")

			panel:NumSlider("Map X Position", "cl_minimap_normalmap_x", 0, ScrW(), 0)
			panel:NumSlider("Map Y Position", "cl_minimap_normalmap_y", 0, ScrH(), 0)

			panel:NumSlider("Map Width", "cl_minimap_normalmapsize_x", 0, ScrW(), 0)
			panel:NumSlider("Map Height", "cl_minimap_normalmapsize_y", 0, ScrH(), 0)

			panel:CheckBox("Draw Player Trail", "cl_minimap_drawplayertrail")
			panel:CheckBox("Rainbow Player Trail", "cl_minimap_rainbowtrail")
			panel:NumSlider("Player Trail Length", "cl_minimap_playertraillength", 0, 1000, 0)

			panel:ColorPicker("Background Color", "cl_minimap_bgcolour_r", "cl_minimap_bgcolour_g", "cl_minimap_bgcolour_b")
			panel:ColorPicker("Foreground Color", "cl_minimap_fgcolour_r", "cl_minimap_fgcolour_g", "cl_minimap_fgcolour_b")
			panel:ColorPicker("Prop Color", "cl_minimap_propcolor_r", "cl_minimap_propcolor_g", "cl_minimap_propcolor_b")
			panel:ColorPicker("Text Color", "cl_minimap_textcolour_r", "cl_minimap_textcolour_g", "cl_minimap_textcolour_b")
			panel:CheckBox("Draw Border", "cl_minimap_drawborder")

			panel:Button("Request minimap Data (Client)", "cl_minimapsystem_request_rects")
			panel:Button("Regenerate minimap Data (Server)", "sv_minimapsystem_regenerate")

			panel:Button("Reset All Options", "cl_minimapsystem_reset_settings")
		end)
	end)

	cvars.AddChangeCallback("cl_minimap_normalmap_x", function(convar_name, value_old, value_new)
		normalMapx = tonumber(value_new)
		if not fullscreenMap then
			mapx = normalMapx
		end
	end)

	cvars.AddChangeCallback("cl_minimap_normalmap_y", function(convar_name, value_old, value_new)
		normalMapy = tonumber(value_new)
		if not fullscreenMap then
			mapy = normalMapy
		end
	end)

	cvars.AddChangeCallback("cl_minimap_normalmapsize_x", function(convar_name, value_old, value_new)
		normalMapSizeX = tonumber(value_new)
		if not fullscreenMap then
			mapSizeX = normalMapSizeX
		end
	end)

	cvars.AddChangeCallback("cl_minimap_normalmapsize_y", function(convar_name, value_old, value_new)
		normalMapSizeY = tonumber(value_new)
		if not fullscreenMap then
			mapSizeY = normalMapSizeY
		end
	end)
end