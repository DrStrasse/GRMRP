--Alexandrovich April 2025
--Feel free to do whatever the hell you want with this code


if SERVER then return end

local rtNameBase = "GTA5FullMapRT"
local fullmapRT, rtMaterial
local fullmapFrame, mapPanel
local isFullmapVisible = false
local fadeAlpha, fadeSpeed = 0, 300
local lastRTW, lastRTH = 1366, 768

local cameraOffset = Vector(0, 0, 0)
local cameraZ = 100000
local defaultFOV = 90
local cameraFOV = defaultFOV
local minFOV, maxFOV, zoomStep = 1, 180, 5
local dragging, dragStart, dragStartOffset = false, nil, nil

local function CreateOrUpdateRT(w, h)
    fullmapRT = GetRenderTarget(rtNameBase .. "_" .. w .. "x" .. h, w, h)
    rtMaterial = CreateMaterial("GTA5FullMapMat_" .. w .. "x" .. h, "UnlitGeneric", {
        ["$basetexture"] = fullmapRT:GetName(),
        ["$vertexalpha"] = "1",
        ["$vertexcolor"] = "1"
    })
end

local function RenderFullMapView(w, h)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local playerPos = ply:GetPos()
    local playerXY = Vector(playerPos.x, playerPos.y, 0)
    local cameraPos = Vector(0, 0, cameraZ) + playerXY + cameraOffset

    local view = {
        origin = cameraPos,
        angles = Angle(90, 90, 0),
        x = 0, y = 0,
        w = w, h = h,
        znear = 10,
        zfar = 1000000,
        fov = cameraFOV,
        drawviewmodel = false,
        drawhud = false
    }

    render.PushRenderTarget(fullmapRT)
        render.Clear(0, 0, 0, 255)
        render.RenderView(view)
    render.PopRenderTarget()
end

local function CreateFullMap()
    if IsValid(fullmapFrame) then return end

    fullmapFrame = vgui.Create("DFrame")
    fullmapFrame:SetSize(lastRTW, lastRTH)
    fullmapFrame:SetTitle("Full Map")
    fullmapFrame:SetDraggable(true)
    fullmapFrame:SetSizable(true)
    fullmapFrame:SetPos(ScrW() / 2 - lastRTW / 2, ScrH() / 2 - lastRTH / 2)
    fullmapFrame:SetVisible(false)
    fullmapFrame:SetDeleteOnClose(false)
    fullmapFrame:SetKeyboardInputEnabled(true)
    fullmapFrame:SetMouseInputEnabled(true)

    fullmapFrame.OnClose = function()
        isFullmapVisible = false
        gui.EnableScreenClicker(false)
    end

    mapPanel = vgui.Create("DPanel", fullmapFrame)
    mapPanel:Dock(FILL)

    CreateOrUpdateRT(lastRTW, lastRTH)

    mapPanel.Paint = function(_, w, h)
        if w ~= lastRTW or h ~= lastRTH then
            lastRTW = w
            lastRTH = h
            CreateOrUpdateRT(w, h)
        end

        RenderFullMapView(w, h)

        surface.SetDrawColor(30, 30, 30, fadeAlpha)
        surface.DrawRect(0, 0, w, h)

        surface.SetMaterial(rtMaterial)
        surface.SetDrawColor(255, 255, 255, fadeAlpha)
        surface.DrawTexturedRect(0, 0, w, h)
    end

    mapPanel.OnMousePressed = function(_, code)
        if code == MOUSE_LEFT then
            dragging = true
            dragStart = Vector(gui.MouseX(), gui.MouseY())
            dragStartOffset = cameraOffset
        end
    end
    mapPanel.OnMouseReleased = function(_, code)
        if code == MOUSE_LEFT then
            dragging = false
        end
    end
    mapPanel.OnMouseWheeled = function(_, delta)
        cameraFOV = math.Clamp(cameraFOV - delta * zoomStep, minFOV, maxFOV)
    end

    hook.Add("Think", "GTA5MapPanThink", function()
        if dragging and dragStart and IsValid(fullmapFrame) then
            local cur = Vector(gui.MouseX(), gui.MouseY())
            local diff = cur - dragStart

            local scale = math.tan(math.rad(cameraFOV / 2)) * cameraZ / (lastRTW / 2)
            local moveX = diff.x * scale
            local moveY = -diff.y * scale

            cameraOffset = dragStartOffset - Vector(moveX, moveY, 0)
        end
    end)

    local resetButton = vgui.Create("DButton", fullmapFrame)
    resetButton:SetText("Reset View")
    resetButton:SetSize(100, 20)
    resetButton:SetPos(10, 30)
    resetButton.DoClick = function()
        cameraOffset = Vector(0, 0, 0)
        cameraFOV = defaultFOV
    end
end

hook.Add("Think", "GTA5MapFade", function()
    if not IsValid(fullmapFrame) then return end
    if isFullmapVisible then
        fadeAlpha = math.Clamp(fadeAlpha + FrameTime() * fadeSpeed, 0, 255)
    else
        fadeAlpha = math.Clamp(fadeAlpha - FrameTime() * fadeSpeed, 0, 255)
    end
    fullmapFrame:SetAlpha(fadeAlpha)
end)

hook.Add("OnPlayerChat", "GTA5MapCommand", function(ply, txt)
    if ply ~= LocalPlayer() then return end
    if string.Trim(string.lower(txt)) == "/fullmap" then
        if not IsValid(fullmapFrame) then CreateFullMap() end
        isFullmapVisible = not isFullmapVisible
        fullmapFrame:SetVisible(true)
        fullmapFrame:SetKeyboardInputEnabled(isFullmapVisible)
        fullmapFrame:SetMouseInputEnabled(isFullmapVisible)
        gui.EnableScreenClicker(isFullmapVisible)
        chat.AddText(Color(0,255,0), "[Full Map] ", color_white, isFullmapVisible and "Enabled" or "Disabled")
        return true
    end
end)