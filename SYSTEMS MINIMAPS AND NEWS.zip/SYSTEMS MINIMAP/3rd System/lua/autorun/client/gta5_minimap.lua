--Alexandrovich April 2025
--Do whatever you want with this code










timer.Simple(3,function()
chat.AddText( Color(40,255,40,255), "=================================")
chat.AddText( Color(40,255,40,255), "GTA 5 Minimap LOADED")
chat.AddText( Color(40,255,40,255), "Type /minimap_help for a list of commands")
chat.AddText( Color(40,255,40,255), "=================================")
end)


if SERVER then return end

local rtName = "GTA5MinimapRT"
local rtW, rtH = 512, 288
local minimapRT = GetRenderTarget(rtName, rtW, rtH)
local rtMaterial = CreateMaterial("GTA5MinimapMat", "UnlitGeneric", {
	["$basetexture"] = rtName,
	["$vertexalpha"] = "1",
	["$vertexcolor"] = "1"
})

local minimapFrame
local isMinimapVisible = true
local fadeAlpha = 0
local fadeSpeed = 300

local barHeight = 14
local barSpacing = 2
local barTotalHeight = barHeight + barSpacing * 2
local minimapAspectRatio = 2
local minimapWidth = 384
local minimapHeight = minimapWidth / minimapAspectRatio
local defaultFrameHeight = minimapHeight + barTotalHeight

local arrowImage = Material("arrow_gta5_minimap.png", "smooth mips")

local zoomFOV = 45
local minFOV, maxFOV = 1, 180
local fixedCameraHeight = 32000
local minimapRotation = 0

local zoomInButton, zoomOutButton
local zoomInButtonHeld, zoomOutButtonHeld = false, false
local isZoomButtonsVisible = false

local defaultX, defaultY, defaultWidth, defaultHeight = 20, ScrH() - defaultFrameHeight - 20, minimapWidth, defaultFrameHeight

local function RenderMinimapView()
	local ply = LocalPlayer()
	if not IsValid(ply) then return end

	local pos = ply:GetPos()
	pos.z = fixedCameraHeight
	local yaw = ply:InVehicle() and (ply:GetVehicle():GetAngles().y + 90) or ply:EyeAngles().y

	local view = {
		origin = pos,
		angles = Angle(90, yaw, 0),
		x = 0, y = 0,
		w = rtW, h = rtH,
		znear = 10, zfar = 9000000,
		fov = zoomFOV,
		drawviewmodel = false,
		drawhud = false
	}

	render.PushRenderTarget(minimapRT)
		render.Clear(0, 0, 0, 255)
		render.RenderView(view)
	render.PopRenderTarget()
end

local function CreateZoomButtons()
	if IsValid(zoomInButton) and IsValid(zoomOutButton) then return end

	local buttonSize = 24
	local buttonSpacing = 4
	local topOffset = (minimapHeight - buttonSize * 2 - buttonSpacing) / 2
	local rightOffset = 4

	zoomInButton = vgui.Create("DButton", minimapFrame)
	zoomInButton:SetText("+")
	zoomInButton:SetSize(buttonSize, buttonSize)
	zoomInButton:SetFont("DermaDefaultBold")
	zoomInButton:SetPos(minimapWidth - buttonSize - rightOffset, topOffset)
	zoomInButton:SetZPos(1)
	zoomInButton:SetAlpha(fadeAlpha)
	zoomInButton.OnMousePressed = function()
		zoomInButtonHeld = true
	end
	zoomInButton.OnMouseReleased = function()
		zoomInButtonHeld = false
	end

	zoomOutButton = vgui.Create("DButton", minimapFrame)
	zoomOutButton:SetText("-")
	zoomOutButton:SetSize(buttonSize, buttonSize)
	zoomOutButton:SetFont("DermaDefaultBold")
	zoomOutButton:SetPos(minimapWidth - buttonSize - rightOffset, topOffset + buttonSize + buttonSpacing)
	zoomOutButton:SetZPos(1)
	zoomOutButton:SetAlpha(fadeAlpha)
	zoomOutButton.OnMousePressed = function()
		zoomOutButtonHeld = true
	end
	zoomOutButton.OnMouseReleased = function()
		zoomOutButtonHeld = false
	end

	zoomInButton:SetVisible(isZoomButtonsVisible)
	zoomOutButton:SetVisible(isZoomButtonsVisible)
end

local function ToggleZoomButtons(visible)
	isZoomButtonsVisible = visible
	if IsValid(zoomInButton) and IsValid(zoomOutButton) then
		zoomInButton:SetVisible(visible)
		zoomOutButton:SetVisible(visible)
	end
end

local function CreateMinimap()
	if IsValid(minimapFrame) then return end

	minimapFrame = vgui.Create("DFrame")
	minimapFrame:SetSize(minimapWidth, defaultFrameHeight)
	minimapFrame:SetTitle("")
	minimapFrame:SetDraggable(true)
	minimapFrame:SetSizable(true)
	minimapFrame:ShowCloseButton(false)
	minimapFrame:SetScreenLock(false)
	minimapFrame:SetMinWidth(128)
	minimapFrame:SetMinHeight(96 + barTotalHeight)
	minimapFrame:SetPos(defaultX, defaultY)
	minimapFrame.Paint = function() end
	minimapFrame:SetAlpha(fadeAlpha)

	local content = vgui.Create("DPanel", minimapFrame)
	content:Dock(FILL)
	content.Paint = function(self, w, h)
		RenderMinimapView()

		local mapH = h - barTotalHeight
		surface.SetDrawColor(255, 255, 255, fadeAlpha)
		surface.SetMaterial(rtMaterial)
		surface.DrawTexturedRect(0, 0, w, mapH)

		if arrowImage then
			local sz = math.min(w, mapH) * 0.08
			surface.SetMaterial(arrowImage)
			surface.SetDrawColor(255, 255, 255, fadeAlpha)
			surface.DrawTexturedRect((w - sz) / 2, (mapH - sz) / 2, sz, sz)
		end

		local ply = LocalPlayer()
		if not IsValid(ply) then return end

		local hp = math.Clamp(ply:Health(), 0, 100)
		local ar = math.Clamp(ply:Armor(), 0, 100)
		local hpRatio = hp / 100
		local arRatio = ar / 100

		local splitLine = 2
		local halfW = (w - splitLine) / 2
		local y = mapH + barSpacing

		local lowHealthThreshold = 20
		local defaultHPColor = Color(114, 204, 114)
		local lowHPColor = Color(255, 0, 0)
		local defaultBarColor = Color(40, 80, 40)
		local lowHealthBarColor = Color(80, 20, 20)

		surface.SetDrawColor(0, 0, 0, fadeAlpha)
		surface.DrawRect(0, mapH, w, barSpacing)

		surface.SetDrawColor(hp < lowHealthThreshold and lowHealthBarColor or defaultBarColor, fadeAlpha)
		surface.DrawRect(0, y, halfW, barHeight)
		surface.SetDrawColor(30, 60, 80, fadeAlpha)
		surface.DrawRect(halfW + splitLine, y, halfW, barHeight)

		surface.SetDrawColor(0, 0, 0, fadeAlpha)
		surface.DrawRect(halfW, y, splitLine, barHeight)

		surface.SetDrawColor(hp < lowHealthThreshold and lowHPColor or defaultHPColor, fadeAlpha)
		surface.DrawRect(0, y, halfW * hpRatio, barHeight)
		surface.SetDrawColor(93, 182, 229, fadeAlpha)
		surface.DrawRect(halfW + splitLine, y, halfW * arRatio, barHeight)

		surface.SetDrawColor(0, 0, 0, fadeAlpha)
		surface.DrawRect(0, y + barHeight, w, barSpacing)
	end

	CreateZoomButtons()
end

local function IsMouseOverMinimap()
	if not IsValid(minimapFrame) then return false end
	local mx, my = gui.MouseX(), gui.MouseY()
	local x, y = minimapFrame:GetPos()
	local w, h = minimapFrame:GetSize()
	return mx >= x and mx <= x + w and my >= y and my <= y + h
end

hook.Add("Think", "MinimapScrollZoomThink", function()
	if not IsValid(minimapFrame) or not minimapFrame:IsVisible() then return end
	if not (input.IsKeyDown(KEY_C) or input.IsKeyDown(KEY_TAB)) then return end
	if not IsMouseOverMinimap() then return end

	local scroll = input.WheelMoved and input.WheelMoved() or 0
	if scroll ~= 0 then
		zoomFOV = math.Clamp(zoomFOV - scroll * 0.5, minFOV, maxFOV)
	end

	if zoomInButtonHeld then
		zoomFOV = math.Clamp(zoomFOV - 0.2, minFOV, maxFOV)
	end
	if zoomOutButtonHeld then
		zoomFOV = math.Clamp(zoomFOV + 0.2, minFOV, maxFOV)
	end
end)

hook.Add("InitPostEntity", "CreateGTA5MinimapAfterSpawn", function()
	timer.Simple(1, CreateMinimap)
end)

hook.Add("OnScreenSizeChanged", "UpdateMinimapPosition", function()
	if IsValid(minimapFrame) then
		minimapFrame:SetPos(20, ScrH() - minimapFrame:GetTall() - 20)
	end
end)

hook.Add("Think", "MinimapFadeAnimation", function()
	if not IsValid(minimapFrame) then return end
	fadeAlpha = math.Clamp(fadeAlpha + FrameTime() * fadeSpeed * (isMinimapVisible and 1 or -1), 0, 255)
	minimapFrame:SetAlpha(fadeAlpha)
	if IsValid(zoomInButton) and IsValid(zoomOutButton) then
		zoomInButton:SetAlpha(fadeAlpha)
		zoomOutButton:SetAlpha(fadeAlpha)
	end
end)

hook.Add("OnPlayerChat", "MinimapChatCommands", function(ply, text)
	if ply ~= LocalPlayer() then return end
	local cmd = string.lower(text)
	if cmd == "/minimap" then
		if not IsValid(minimapFrame) then CreateMinimap() end
		isMinimapVisible = not isMinimapVisible
		minimapFrame:SetVisible(true)
		chat.AddText(Color(0,255,0), "[Minimap] ", color_white, isMinimapVisible and "Enabled" or "Disabled")
		return true
	elseif cmd == "/minimap_reset" then
		if IsValid(minimapFrame) then
			minimapFrame:SetPos(defaultX, defaultY)
			minimapFrame:SetSize(defaultWidth, defaultHeight)
			zoomFOV = 45
			chat.AddText(Color(0,255,0),"[Minimap]",color_white," Reset to default position and size.")
		end
		return true
	elseif cmd == "/minimap_zoom" then
		if not IsValid(minimapFrame) then CreateMinimap() end
		ToggleZoomButtons(not isZoomButtonsVisible)
		chat.AddText(Color(0,255,0), "[Minimap] ", color_white, isZoomButtonsVisible and "Zoom buttons Enabled" or "Zoom buttons Disabled")
		return true
	elseif cmd == "/minimap_help" then
	        chat.AddText( Color(40,255,40,255), "=================================")
	        chat.AddText( Color(40,255,40,255), "GTA V Minimap by Alexandrovich 2025")
	        chat.AddText( Color(40,255,40,255), "/minimap -- Toggles minimap")
	        chat.AddText( Color(40,255,40,255), "/fullmap -- Toggles map browser")
	        chat.AddText( Color(40,255,40,255), "/minimap_reset -- Resets size and position")
	        chat.AddText( Color(40,255,40,255), "/minimap_zoom -- Toggles the zoom buttons")
	        chat.AddText( Color(40,255,40,255), "/minimap_help -- Shows help")
	        chat.AddText( Color(40,255,40,255), "=================================")
	        return true
		end
end)

hook.Add("PlayerEnteredVehicle", "RotateMinimapOnEnterVehicle", function(ply, veh)
	if ply == LocalPlayer() then minimapRotation = 90 end
end)

hook.Add("PlayerLeaveVehicle", "ResetMinimapOnExitVehicle", function(ply, veh)
	if ply == LocalPlayer() then minimapRotation = 0 end
end)
