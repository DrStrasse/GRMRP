Typography = Typography or {}
local T = Typography
local C = T.Config

local NET = {
    Bootstrap = "typo_bootstrap",
    TemplateList = "typo_template_list",
    TemplateSave = "typo_template_save",
    TemplateLoad = "typo_template_load",
    TemplateData = "typo_template_data",
    TemplateDelete = "typo_template_delete",
    DraftSave = "typo_draft_save",
    Print = "typo_print",
    OpenIssue = "typo_open_issue",
    Notify = "typo_notify",
    PhotoUpload = "typo_photo_upload",
    PhotoList = "typo_photo_list",
    PhotoDataRequest = "typo_photo_request",
    PhotoData = "typo_photo_data",
    PhotoDelete = "typo_photo_delete",
    CameraCapture = "typo_camera_capture",
    StorageClear = "typo_storage_clear"
}

T.Net = NET
for _, name in pairs(NET) do util.AddNetworkString(name) end

local sessions, rates = {}, {}

local function notify(ply, keyOrText, kind, ...)
    if not IsValid(ply) then return end
    local text = T.Locale.en[keyOrText] and T.L(ply, keyOrText, ...) or tostring(keyOrText or "")
    net.Start(NET.Notify)
        net.WriteString(text)
        net.WriteUInt(math.Clamp(tonumber(kind) or 0, 0, 3), 2)
    net.Send(ply)
end
T.Notify = notify

local function writePayload(tbl)
    local json = util.TableToJSON(tbl, false) or "{}"
    local compressed = util.Compress(json) or ""
    if #compressed <= 0 or #compressed > C.MaxCompressedBytes then return false end
    net.WriteUInt(#compressed, 16)
    net.WriteData(compressed, #compressed)
    return true
end

local function readPayload()
    local byteCount = net.ReadUInt(16)
    if byteCount <= 0 or byteCount > C.MaxCompressedBytes then return nil end
    local compressed = net.ReadData(byteCount)
    if not compressed or #compressed ~= byteCount then return nil end
    local json = util.Decompress(compressed)
    if not json or #json > C.MaxDesignBytes * 2 then return nil end
    local ok, data = pcall(util.JSONToTable, json)
    if not ok or not istable(data) then return nil end
    return data
end

local function writeBlob(blob)
    blob = tostring(blob or "")
    net.WriteUInt(#blob, 16)
    net.WriteData(blob, #blob)
end

local function readBlob(limit)
    local n = net.ReadUInt(16)
    if n <= 0 or n > (limit or 60000) then return nil end
    local data = net.ReadData(n)
    if not data or #data ~= n then return nil end
    return data
end

local function rateAllowed(ply, key, delay)
    rates[ply] = rates[ply] or {}
    local now = CurTime()
    local nextAt = rates[ply][key] or 0
    if nextAt > now then return false end
    rates[ply][key] = now + (delay or C.NetRateDefault)
    return true
end

local function newSession(ply, printer)
    local token = util.CRC(ply:SteamID64() .. ":" .. tostring(printer:EntIndex()) .. ":" .. tostring(SysTime()) .. ":" .. tostring(math.random()))
    sessions[ply] = {printer = printer, token = token, expires = CurTime() + C.EditorSessionLifetime}
    return token
end

local function validSession(ply, printer, token)
    local ok, reason = T.CanUsePrinter(ply, printer)
    if not ok then return false, reason end

    local s = sessions[ply]
    if not s or s.expires < CurTime() then
        return false, "session_expired"
    end
    if s.printer ~= printer or s.token ~= tostring(token or "") then
        return false, "invalid_session"
    end
    return true
end

local function validDraftSession(ply, printer, token)
    local s = sessions[ply]
    if not s or s.expires < CurTime() then
        return false, "session_expired"
    end
    if s.printer ~= printer or s.token ~= tostring(token or "") then
        return false, "invalid_session"
    end
    return true
end

function T.OpenEditor(ply, printer)
    local ok, reason = T.CanUsePrinter(ply, printer)
    if not ok then notify(ply, reason, 1) return end
    if not rateAllowed(ply, "open", 0.5) then return end

    local token = newSession(ply, printer)
    net.Start(NET.Bootstrap)
        net.WriteEntity(printer)
        net.WriteString(token)
        writePayload({
            templates = T.TemplateSummary(ply),
            draft = T.LoadDraft(ply),
            photos = T.PhotoSummary(ply)
        })
    net.Send(ply)
end

local function sendTemplateList(ply)
    net.Start(NET.TemplateList)
        writePayload(T.TemplateSummary(ply))
    net.Send(ply)
end

local function sendPhotoList(ply)
    net.Start(NET.PhotoList)
        writePayload(T.PhotoSummary(ply))
    net.Send(ply)
end

net.Receive(NET.TemplateSave, function(_, ply)
    if not rateAllowed(ply, "save", C.NetRateSave) then return end
    local printer = net.ReadEntity()
    local token = net.ReadString()
    local id = net.ReadString()
    local name = net.ReadString()
    if #token > 64 or #id > 64 or #name > C.MaxTemplateNameLength * 2 then notify(ply, "bad_request", 1) return end
    local design = readPayload()
    if not design then notify(ply, "bad_design", 1) return end

    local ok, reason = validSession(ply, printer, token)
    if not ok then notify(ply, reason, 1) return end

    local saved, result = T.SaveTemplate(ply, id, name, design)
    if not saved then notify(ply, result, 1) return end

    notify(ply, "template_saved", 0)
    sendTemplateList(ply)

    net.Start(NET.TemplateData)
        writePayload({id = result.id, name = result.name, design = result.design, saved = true})
    net.Send(ply)
end)

net.Receive(NET.TemplateLoad, function(_, ply)
    if not rateAllowed(ply, "load", C.NetRateDefault) then return end
    local printer = net.ReadEntity()
    local token = net.ReadString()
    local id = net.ReadString()
    if #token > 64 or #id > 64 then return end

    local ok, reason = validSession(ply, printer, token)
    if not ok then notify(ply, reason, 1) return end

    local tpl = T.GetTemplate(ply, id)
    if not tpl then notify(ply, "template_not_found", 1) return end

    net.Start(NET.TemplateData)
        writePayload({id = tpl.id, name = tpl.name, design = tpl.design})
    net.Send(ply)
end)

net.Receive(NET.TemplateDelete, function(_, ply)
    if not rateAllowed(ply, "delete", 0.6) then return end
    local printer = net.ReadEntity()
    local token = net.ReadString()
    local id = net.ReadString()
    if #token > 64 or #id > 64 then return end

    local ok, reason = validSession(ply, printer, token)
    if not ok then notify(ply, reason, 1) return end

    local deleted, err = T.DeleteTemplate(ply, id)
    if not deleted then notify(ply, err, 1) return end
    notify(ply, "template_deleted", 0)
    sendTemplateList(ply)
end)

net.Receive(NET.DraftSave, function(_, ply)
    if not rateAllowed(ply, "draft", C.NetRateDraft) then return end
    local printer = net.ReadEntity()
    local token = net.ReadString()
    if #token > 64 then return end
    local design = readPayload()
    if not design then return end

    local ok, reason = validDraftSession(ply, printer, token)
    if not ok then notify(ply, reason, 1) return end

    local saved, err = T.SaveDraft(ply, design)
    if not saved then notify(ply, err, 1) end
end)

local function canPay(ply, amount)
    if amount <= 0 then return true end
    local hookResult, hookReason = hook.Run("TypographyCanPay", ply, amount)
    if hookResult ~= nil then return hookResult ~= false, hookReason end
    if isfunction(ply.canAfford) then return ply:canAfford(amount), "cannot_pay" end
    return false, "cannot_pay"
end

local function takeMoney(ply, amount)
    if amount <= 0 then return true end
    local hookResult = hook.Run("TypographyTakeMoney", ply, amount)
    if hookResult ~= nil then return hookResult ~= false end
    if isfunction(ply.addMoney) then ply:addMoney(-amount) return true end
    return false
end

local function spawnPrintedNewspaper(printer, issue)
    if not IsValid(printer) then return false end
    local paper = ents.Create("typography_newspaper")
    if not IsValid(paper) then return false end
    paper:SetPos(printer:GetPos() + printer:GetForward() * 28 + printer:GetUp() * 24)
    paper:SetAngles(Angle(0, printer:GetAngles().y, 0))
    paper:Spawn()
    paper:Activate()
    paper:SetIssueID(issue.id)
    paper:SetIssueNumber(issue.issueNo)
    paper:SetNewspaperName(issue.newspaperName)
    return true
end

net.Receive(NET.Print, function(_, ply)
    if not rateAllowed(ply, "print", C.NetRatePrint) then return end
    local printer = net.ReadEntity()
    local token = net.ReadString()
    if #token > 64 then return end
    local design = readPayload()
    if not design then notify(ply, "bad_design", 1) return end

    local ok, reason = validSession(ply, printer, token)
    if not ok then notify(ply, reason, 1) return end
    if printer:GetPrinting() then notify(ply, "printing_busy", 1) return end
    if (printer.NextPrintAllowed or 0) > CurTime() then notify(ply, "printer_cooldown", 1) return end
    if table.Count(T.RuntimeIssues or {}) >= C.MaxWorldNewspapers then notify(ply, "world_limit", 1) return end

    local clean, cleanErr = T.SanitizeDesign(design)
    if not clean then notify(ply, cleanErr, 1) return end
    if printer:GetInk() < C.InkPerPrint then notify(ply, "not_enough_ink", 1) return end

    local afford, payReason = canPay(ply, C.PrintCost)
    if not afford then notify(ply, payReason or "cannot_pay", 1) return end

    printer:SetInk(math.max(0, printer:GetInk() - C.InkPerPrint))
    printer:SetPrinting(true)
    if printer.StartPrintLoop then printer:StartPrintLoop() end
    printer.NextPrintAllowed = CurTime() + C.PrintDuration + C.PrintCooldown

    if not takeMoney(ply, C.PrintCost) then
        printer:SetInk(math.min(C.PrinterInkCapacity, printer:GetInk() + C.InkPerPrint))
        printer:SetPrinting(false)
        if printer.StopPrintLoop then printer:StopPrintLoop() end
        notify(ply, "cannot_pay", 1)
        return
    end

    local issue, issueErr = T.CreateIssue(ply, clean)
    if not issue then
        printer:SetInk(math.min(C.PrinterInkCapacity, printer:GetInk() + C.InkPerPrint))
        printer:SetPrinting(false)
        if printer.StopPrintLoop then printer:StopPrintLoop() end
        notify(ply, issueErr or "issue_create_fail", 1)
        return
    end

    printer.PendingTypographyIssueID = issue.id

    local timerName = "TypographyPrint_" .. printer:EntIndex()
    timer.Remove(timerName)
    timer.Create(timerName, C.PrintDuration, 1, function()
        if not IsValid(printer) then return end
        printer:SetPrinting(false)
        if printer.StopPrintLoop then printer:StopPrintLoop() end
        printer.PendingTypographyIssueID = nil
        if spawnPrintedNewspaper(printer, issue) then
            notify(ply, "issue_created", 0, issue.issueNo)
        else
            if T.CleanupRuntimeIssue then T.CleanupRuntimeIssue(issue.id) end
            if IsValid(ply) then notify(ply, "issue_spawn_fail", 1) end
        end
    end)
end)

function T.OpenIssue(ply, newspaper)
    if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return end
    if not IsValid(newspaper) or newspaper:GetClass() ~= "typography_newspaper" then return end
    if ply:GetPos():DistToSqr(newspaper:GetPos()) > (C.InteractDistance * C.InteractDistance) then return end
    if not rateAllowed(ply, "issue", 0.35) then return end

    local issue = T.LoadIssue(newspaper:GetIssueID())
    if not issue then notify(ply, "issue_not_found", 1) return end

    net.Start(NET.OpenIssue)
        writePayload(issue)
    net.Send(ply)
end

net.Receive(NET.PhotoUpload, function(_, ply)
    if not rateAllowed(ply, "photo_upload", 1.0) then return end
    local title = net.ReadString()
    local mime = net.ReadString()
    local width = net.ReadUInt(16)
    local height = net.ReadUInt(16)
    local data = readBlob(C.MaxPhotoBytes)
    if not data or #title > C.MaxPhotoTitleLength * 2 or #mime > 32 then notify(ply, "photo_invalid", 1) return end

    local ok, result = T.SavePhoto(ply, title, mime, width, height, data)
    if not ok then notify(ply, result, 1) return end

    notify(ply, "photo_uploaded", 0)
    sendPhotoList(ply)
end)

net.Receive(NET.PhotoDataRequest, function(_, ply)
    if not rateAllowed(ply, "photo_data", 0.15) then return end
    local id = net.ReadString()
    if #id > 64 then return end
    local photo = T.GetPhoto(ply, id)
    if not photo then notify(ply, "photo_not_found", 1) return end

    net.Start(NET.PhotoData)
        net.WriteString(photo.id)
        net.WriteString(photo.mime)
        net.WriteUInt(math.Clamp(photo.width or 0, 0, 65535), 16)
        net.WriteUInt(math.Clamp(photo.height or 0, 0, 65535), 16)
        writeBlob(photo.data)
    net.Send(ply)
end)

net.Receive(NET.PhotoDelete, function(_, ply)
    if not rateAllowed(ply, "photo_delete", 0.35) then return end
    local id = net.ReadString()
    if #id > 64 then notify(ply, "bad_request", 1) return end

    local ok, err = T.DeletePhoto(ply, id)
    if not ok then
        notify(ply, err or "photo_not_found", 1)
        return
    end

    notify(ply, "photo_deleted", 0)
    sendPhotoList(ply)
end)

net.Receive(NET.StorageClear, function(_, ply)
    if not rateAllowed(ply, "storage_clear", 0.75) then return end
    local action = net.ReadUInt(2)

    if action == 1 then
        T.ClearPlayerPhotos(ply)
        notify(ply, "storage_photos_cleared", 0)
        sendPhotoList(ply)
    elseif action == 2 then
        T.ClearPlayerTemplates(ply)
        notify(ply, "storage_templates_cleared", 0)
        sendTemplateList(ply)
    elseif action == 3 then
        T.ClearPlayerStorage(ply)
        notify(ply, "storage_all_cleared", 0)
        sendPhotoList(ply)
        sendTemplateList(ply)
    else
        notify(ply, "bad_request", 1)
    end
end)

hook.Add("PlayerDisconnected", "TypographyCleanupSessions", function(ply)
    sessions[ply] = nil
    rates[ply] = nil
end)

hook.Add("CanTool", "TypographyBlockDuplicator", function(_, tr, tool)
    if tool ~= "duplicator" or not tr or not IsValid(tr.Entity) then return end
    local class = tr.Entity:GetClass()
    if class == "typography_newspaper" or class == "typography_ink" or class == "typography_printer" or class == "typography_newspaper_stand" then return false end
end)
