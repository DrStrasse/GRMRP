Typography = Typography or {}
local T = Typography
local C = T.Config

local DATA_ROOT = "typography"
local TEMPLATE_DIR = DATA_ROOT .. "/templates"
local DRAFT_DIR = DATA_ROOT .. "/drafts"
local PHOTO_DIR = DATA_ROOT .. "/photos"

local LEGACY_ISSUE_DIR = DATA_ROOT .. "/issues"
local LEGACY_COUNTER_FILE = DATA_ROOT .. "/issue_counter.txt"

file.CreateDir(DATA_ROOT)
file.CreateDir(TEMPLATE_DIR)
file.CreateDir(DRAFT_DIR)
file.CreateDir(PHOTO_DIR)

do
    local oldFiles = file.Find(LEGACY_ISSUE_DIR .. "/*.json", "DATA") or {}
    for _, name in ipairs(oldFiles) do
        file.Delete(LEGACY_ISSUE_DIR .. "/" .. name)
    end
    if file.Exists(LEGACY_COUNTER_FILE, "DATA") then
        file.Delete(LEGACY_COUNTER_FILE)
    end
end

T.RuntimeIssues = T.RuntimeIssues or {}
T.RuntimeIssueCounters = T.RuntimeIssueCounters or {}
T.RuntimeIssueID = tonumber(T.RuntimeIssueID) or 0

local function safeReadJSON(path)
    if not file.Exists(path, "DATA") then return nil end
    local raw = file.Read(path, "DATA")
    if not raw or raw == "" then return nil end
    local ok, data = pcall(util.JSONToTable, raw)
    if not ok or not istable(data) then return nil end
    return data
end

local function safeWriteJSON(path, data)
    local raw = util.TableToJSON(data, false)
    if not raw then return false end
    file.Write(path, raw)
    return true
end

local function templatePath(ply)
    return TEMPLATE_DIR .. "/" .. ply:SteamID64() .. ".json"
end

local function draftPath(ply)
    return DRAFT_DIR .. "/" .. ply:SteamID64() .. ".json"
end

local function photoPathBySID64(sid64)
    return PHOTO_DIR .. "/" .. tostring(sid64 or "0") .. ".json"
end

function T.LoadTemplates(ply)
    if not IsValid(ply) then return {} end
    local data = safeReadJSON(templatePath(ply))
    if not istable(data) then return {} end

    local result = {}
    for _, tpl in ipairs(data) do
        if istable(tpl) and isstring(tpl.id) and isstring(tpl.name) and istable(tpl.design) then
            local clean = T.SanitizeDesign(tpl.design)
            if clean then
                result[#result + 1] = {
                    id = string.sub(tpl.id, 1, 40),
                    name = T.TrimText(tpl.name, C.MaxTemplateNameLength),
                    updated = tonumber(tpl.updated) or 0,
                    design = clean
                }
            end
        end
    end
    return result
end

function T.TemplateSummary(ply)
    local result = {}
    for _, tpl in ipairs(T.LoadTemplates(ply)) do
        result[#result + 1] = {id = tpl.id, name = tpl.name, updated = tpl.updated}
    end
    return result
end

function T.GetTemplate(ply, id)
    id = tostring(id or "")
    for _, tpl in ipairs(T.LoadTemplates(ply)) do
        if tpl.id == id then return tpl end
    end
end

function T.SaveTemplate(ply, id, name, design)
    name = T.TrimText(name, C.MaxTemplateNameLength)
    if name == "" then return false, "template_name_required" end

    local clean, err = T.SanitizeDesign(design)
    if not clean then return false, err end

    local templates = T.LoadTemplates(ply)
    local found
    if id and id ~= "" then
        for _, tpl in ipairs(templates) do
            if tpl.id == id then found = tpl break end
        end
    end

    if not found then
        if #templates >= C.MaxTemplatesPerPlayer then return false, "template_limit" end
        found = {
            id = util.CRC(ply:SteamID64() .. ":" .. tostring(SysTime()) .. ":" .. tostring(math.random())),
            name = name,
            updated = os.time(),
            design = clean
        }
        templates[#templates + 1] = found
    else
        found.name = name
        found.updated = os.time()
        found.design = clean
    end

    if not safeWriteJSON(templatePath(ply), templates) then return false, "template_disk_fail" end
    return true, found
end

function T.DeleteTemplate(ply, id)
    id = tostring(id or "")
    local templates = T.LoadTemplates(ply)
    local changed = false

    for i = #templates, 1, -1 do
        if templates[i].id == id then
            table.remove(templates, i)
            changed = true
            break
        end
    end

    if not changed then return false, "template_not_found" end
    if not safeWriteJSON(templatePath(ply), templates) then return false, "template_update_fail" end
    return true
end

function T.SaveDraft(ply, design)
    local clean, err = T.SanitizeDesign(design)
    if not clean then return false, err end
    if not safeWriteJSON(draftPath(ply), clean) then return false, "template_disk_fail" end
    return true
end

function T.LoadDraft(ply)
    if not IsValid(ply) then return nil end
    local data = safeReadJSON(draftPath(ply))
    if not istable(data) then return nil end
    local clean = T.SanitizeDesign(data)
    return clean
end

local function loadPhotosBySID64(sid64)
    sid64 = tostring(sid64 or "0")
    local data = safeReadJSON(photoPathBySID64(sid64))
    if not istable(data) then return {} end

    local out = {}
    for _, photo in ipairs(data) do
        if istable(photo) and isstring(photo.id) and isstring(photo.data) then
            out[#out + 1] = {
                id = string.sub(photo.id, 1, 40),
                title = T.TrimText(photo.title or "Photo", C.MaxPhotoTitleLength),
                created = tonumber(photo.created) or 0,
                createdText = T.TrimText(photo.createdText or "", 64),
                mime = T.TrimText(photo.mime or "image/jpeg", 32),
                width = math.floor(tonumber(photo.width) or C.CameraPhotoWidth),
                height = math.floor(tonumber(photo.height) or C.CameraPhotoHeight),
                data = string.sub(photo.data or "", 1, C.MaxEmbeddedPhotoBytes)
            }
        end
    end
    return out
end

function T.LoadPhotos(ply)
    if not IsValid(ply) then return {} end
    return loadPhotosBySID64(ply:SteamID64())
end

function T.PhotoSummary(ply)
    local result = {}
    for _, p in ipairs(T.LoadPhotos(ply)) do
        result[#result + 1] = {
            id = p.id,
            title = p.title,
            created = p.created,
            createdText = p.createdText,
            width = p.width,
            height = p.height
        }
    end
    return result
end

function T.GetPhoto(ply, id)
    id = tostring(id or "")
    for _, p in ipairs(T.LoadPhotos(ply)) do
        if p.id == id then return p end
    end
end

function T.GetPhotoByOwner(sid64, id)
    id = tostring(id or "")
    for _, p in ipairs(loadPhotosBySID64(sid64)) do
        if p.id == id then return p end
    end
end

function T.DeletePhoto(ply, id)
    if not IsValid(ply) then return false, "photo_not_found" end
    id = tostring(id or "")
    local photos = T.LoadPhotos(ply)
    local changed = false

    for i = #photos, 1, -1 do
        if photos[i].id == id then
            table.remove(photos, i)
            changed = true
            break
        end
    end

    if not changed then return false, "photo_not_found" end
    if not safeWriteJSON(photoPathBySID64(ply:SteamID64()), photos) then return false, "template_disk_fail" end
    return true
end

function T.SavePhoto(ply, title, mime, width, height, data)
    if not IsValid(ply) then return false, "photo_invalid" end
    title = T.TrimText(title, C.MaxPhotoTitleLength)
    if title == "" then title = T.L(ply, "photo_default_title") end
    mime = T.TrimText(mime or "image/jpeg", 32)
    data = tostring(data or "")
    if data == "" or #data > C.MaxPhotoBytes then return false, "photo_invalid" end

    data = util.Base64Encode(data)
    if not data or data == "" or #data > C.MaxEmbeddedPhotoBytes then return false, "photo_invalid" end

    local photos = T.LoadPhotos(ply)
    if #photos >= C.MaxPhotosPerPlayer then return false, "photo_limit" end

    local photo = {
        id = util.CRC(ply:SteamID64() .. ":photo:" .. tostring(SysTime()) .. ":" .. tostring(math.random())),
        title = title,
        mime = mime,
        width = math.floor(math.Clamp(tonumber(width) or C.CameraPhotoWidth, 1, C.CameraMaxWidth or 1280)),
        height = math.floor(math.Clamp(tonumber(height) or C.CameraPhotoHeight, 1, C.CameraMaxHeight or 720)),
        created = os.time(),
        createdText = os.date("%d.%m.%Y %H:%M"),
        data = data
    }
    photos[#photos + 1] = photo

    if not safeWriteJSON(photoPathBySID64(ply:SteamID64()), photos) then return false, "template_disk_fail" end
    return true, photo
end

function T.ClearPlayerPhotos(ply)
    if not IsValid(ply) then return false end
    local path = photoPathBySID64(ply:SteamID64())
    if file.Exists(path, "DATA") then file.Delete(path) end
    return true
end

function T.ClearPlayerTemplates(ply)
    if not IsValid(ply) then return false end
    local path = templatePath(ply)
    if file.Exists(path, "DATA") then file.Delete(path) end
    return true
end

function T.ClearPlayerStorage(ply)
    if not IsValid(ply) then return false end
    T.ClearPlayerPhotos(ply)
    T.ClearPlayerTemplates(ply)
    local path = draftPath(ply)
    if file.Exists(path, "DATA") then file.Delete(path) end
    return true
end

local function designForIssue(ply, design)
    local clean, err = T.SanitizeDesign(design)
    if not clean then return nil, err end

    local sid64 = IsValid(ply) and ply:SteamID64() or "0"
    for _, el in ipairs(clean.elements) do
        if el.kind == "image" and el.sourceType == "photo" then
            local photo = T.GetPhotoByOwner(sid64, el.photoID)
            if not photo then return nil, "photo_not_found" end
            el.photoData = photo.data
            el.photoMime = photo.mime
        end
    end

    return clean
end

local function nextSeriesIssueNumber(ply, newspaperName)
    local sid64 = IsValid(ply) and ply:SteamID64() or "0"
    local normalizedName = string.lower(T.TrimText(newspaperName or "Newspaper", C.MaxNewspaperNameLength))
    local key = sid64 .. "\0" .. normalizedName
    local nextNo = (tonumber(T.RuntimeIssueCounters[key]) or 0) + 1
    T.RuntimeIssueCounters[key] = nextNo
    return nextNo
end

local function nextRuntimeIssueID()
    T.RuntimeIssueID = math.max(0, math.floor(tonumber(T.RuntimeIssueID) or 0)) + 1
    return T.RuntimeIssueID
end

function T.CreateIssue(ply, design)
    local resolved, err = designForIssue(ply, design)
    if not resolved then return nil, err end

    local issue = {
        id = nextRuntimeIssueID(),
        issueNo = nextSeriesIssueNumber(ply, resolved.newspaperName),
        newspaperName = resolved.newspaperName,
        author = IsValid(ply) and ply:Nick() or "Unknown",
        authorSteamID64 = IsValid(ply) and ply:SteamID64() or "0",
        created = os.time(),
        createdText = os.date("%d.%m.%Y %H:%M"),
        design = resolved
    }

    T.RuntimeIssues[issue.id] = issue
    return table.Copy(issue)
end

function T.LoadIssue(id)
    id = math.floor(tonumber(id) or 0)
    if id <= 0 then return nil end
    local issue = T.RuntimeIssues[id]
    if not istable(issue) then return nil end
    return table.Copy(issue)
end

function T.CleanupRuntimeIssue(id)
    id = math.floor(tonumber(id) or 0)
    if id <= 0 or not T.RuntimeIssues[id] then return end

    for _, paper in ipairs(ents.FindByClass("typography_newspaper")) do
        if IsValid(paper) and paper:GetIssueID() == id then return end
    end

    for _, stand in ipairs(ents.FindByClass("typography_newspaper_stand")) do
        if IsValid(stand) then
            for _, storedID in ipairs(stand.StoredIssues or {}) do
                if storedID == id then return end
            end
        end
    end

    T.RuntimeIssues[id] = nil
end

function T.ScheduleRuntimeIssueCleanup(id)
    id = math.floor(tonumber(id) or 0)
    if id <= 0 then return end
    timer.Simple(0, function()
        if T and T.CleanupRuntimeIssue then T.CleanupRuntimeIssue(id) end
    end)
end
