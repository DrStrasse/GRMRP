Typography = Typography or {}
local T = Typography
local C = T.Config

local editor
local fontCache = {}
T.EditorClipboard = T.EditorClipboard or nil
T.PhotoCache = T.PhotoCache or {}
T.GalleryWindow = T.GalleryWindow or nil

local function L(key, ...)
    return T.L(nil, key, ...)
end

local function notify(text, kind)
    local notifyType = kind == 1 and NOTIFY_ERROR or NOTIFY_GENERIC
    notification.AddLegacy(text, notifyType, 4)
    surface.PlaySound(kind == 1 and "buttons/button10.wav" or "buttons/button15.wav")
end

local function encodePayload(tbl)
    local json = util.TableToJSON(tbl, false) or "{}"
    if #json > C.MaxDesignBytes then return nil end
    local compressed = util.Compress(json) or ""
    if #compressed <= 0 or #compressed > C.MaxCompressedBytes then return nil end
    return compressed
end

local function writePayloadBytes(compressed)
    net.WriteUInt(#compressed, 16)
    net.WriteData(compressed, #compressed)
end

local function readPayload()
    local byteCount = net.ReadUInt(16)
    if byteCount <= 0 or byteCount > C.MaxCompressedBytes then return nil end
    local compressed = net.ReadData(byteCount)
    if not compressed then return nil end
    local json = util.Decompress(compressed)
    if not json or #json > C.MaxDesignBytes * 2 then return nil end
    return util.JSONToTable(json)
end

local function writeColorToMixer(mixer, col)
    col = T.SanitizeColor(col)
    mixer:SetColor(Color(col.r, col.g, col.b, col.a))
end

local fontFaces = {sans = "Roboto", serif = "Georgia", mono = "Courier New"}
function T.GetPaperFont(fontFamily, size, bold)
    size = math.Clamp(math.floor(size), 8, 96)
    local key = tostring(fontFamily) .. "_" .. size .. "_" .. tostring(bold == true)
    if fontCache[key] then return fontCache[key] end
    local name = "Typography_" .. util.CRC(key)
    surface.CreateFont(name, {font = fontFaces[fontFamily] or fontFaces.sans, size = size, weight = bold and 800 or 500, antialias = true, extended = true})
    fontCache[key] = name
    return name
end

local function splitLines(text)
    text = string.Replace(tostring(text or ""), "\r", "")
    return string.Explode("\n", text, false)
end

local function wrapParagraph(text, font, maxWidth)
    surface.SetFont(font)
    local words = string.Explode(" ", text, false)
    local lines, line = {}, ""
    for _, word in ipairs(words) do
        local candidate = line == "" and word or (line .. " " .. word)
        local width = surface.GetTextSize(candidate)
        if width <= maxWidth or line == "" then
            line = candidate
        else
            lines[#lines + 1] = line
            line = word
        end
    end
    lines[#lines + 1] = line
    return lines
end

local function colorObj(data)
    return T.ColorObject(data or {r = 25, g = 25, b = 25, a = 255})
end

local function ellipsePoly(x, y, w, h)
    local poly = {}
    local cx, cy = x + w / 2, y + h / 2
    local rx, ry = math.max(1, w / 2), math.max(1, h / 2)
    for i = 0, 48 do
        local a = math.rad((i / 48) * -360)
        poly[#poly + 1] = {x = cx + math.sin(a) * rx, y = cy + math.cos(a) * ry}
    end
    return poly
end

local function drawEllipse(x, y, w, h, col, filled, thickness)
    draw.NoTexture()
    surface.SetDrawColor(col)
    if filled then
        surface.DrawPoly(ellipsePoly(x, y, w, h))
        return
    end

    thickness = math.max(1, math.floor(thickness or 1))
    for inset = 0, thickness - 1 do
        local poly = ellipsePoly(x + inset, y + inset, math.max(2, w - inset * 2), math.max(2, h - inset * 2))
        for i = 1, #poly - 1 do
            surface.DrawLine(poly[i].x, poly[i].y, poly[i + 1].x, poly[i + 1].y)
        end
    end
end

local function drawTriangleOutline(w, h, col, thickness)
    thickness = math.max(1, math.floor(thickness or 1))
    surface.SetDrawColor(col)
    for inset = 0, thickness - 1 do
        local leftX = inset
        local rightX = math.max(leftX + 1, w - inset)
        local topY = inset
        local bottomY = math.max(topY + 1, h - inset)
        local midX = w / 2
        surface.DrawLine(midX, topY, rightX, bottomY)
        surface.DrawLine(rightX, bottomY, leftX, bottomY)
        surface.DrawLine(leftX, bottomY, midX, topY)
    end
end

function T.DrawTextElement(data, w, h, alpha)
    local size = math.max(8, math.floor(data.fontSize or 18))
    local font = T.GetPaperFont(data.font or "sans", size, data.bold == true)
    local maxWidth = math.max(8, w)
    local x, y = 0, 0
    local align = data.align or "left"
    local textAlign, drawX = TEXT_ALIGN_LEFT, x
    if align == "center" then
        textAlign = TEXT_ALIGN_CENTER
        drawX = x + maxWidth / 2
    elseif align == "right" then
        textAlign = TEXT_ALIGN_RIGHT
        drawX = x + maxWidth
    end

    surface.SetFont(font)
    local _, lineHeight = surface.GetTextSize("Ag")
    lineHeight = math.max(10, lineHeight + 2)
    local currentY = y
    local col = colorObj(data.color)
    col.a = alpha or col.a

    for _, paragraph in ipairs(splitLines(data.text or "")) do
        local lines = wrapParagraph(paragraph, font, maxWidth)
        for _, line in ipairs(lines) do
            draw.SimpleText(line, font, drawX, currentY, col, textAlign, TEXT_ALIGN_TOP)
            if data.underline then
                local lineW = surface.GetTextSize(line)
                local sx = drawX
                if textAlign == TEXT_ALIGN_CENTER then sx = drawX - lineW / 2 end
                if textAlign == TEXT_ALIGN_RIGHT then sx = drawX - lineW end
                surface.SetDrawColor(col)
                surface.DrawRect(sx, currentY + lineHeight - 3, lineW, 1)
            end
            currentY = currentY + lineHeight
            if currentY > h then return end
        end
    end
end

function T.DrawShapeElement(data, w, h)
    local fill = colorObj(data.color)
    local border = colorObj(data.borderColor)
    local bw = math.max(1, data.borderWidth or 2)
    local shape = data.shape or "rect"
    if shape == "rect" then
        surface.SetDrawColor(fill)
        surface.DrawRect(0, 0, w, h)
        if bw > 0 then
            surface.SetDrawColor(border)
            surface.DrawOutlinedRect(0, 0, w, h, bw)
        end
    elseif shape == "outline_rect" then
        surface.SetDrawColor(border)
        surface.DrawOutlinedRect(0, 0, w, h, bw)
    elseif shape == "ellipse" then
        drawEllipse(0, 0, w, h, fill, true)
        drawEllipse(0, 0, w, h, border, false, bw)
    elseif shape == "outline_ellipse" then
        drawEllipse(0, 0, w, h, border, false, bw)
    elseif shape == "triangle" then
        draw.NoTexture()
        surface.SetDrawColor(fill)
        surface.DrawPoly({{x = w / 2, y = 0}, {x = w, y = h}, {x = 0, y = h}})
        drawTriangleOutline(w, h, border, bw)
    elseif shape == "outline_triangle" then
        drawTriangleOutline(w, h, border, bw)
    end
end

local function escapeHTML(str)
    str = tostring(str or "")
    str = string.gsub(str, "&", "&amp;")
    str = string.gsub(str, "<", "&lt;")
    str = string.gsub(str, ">", "&gt;")
    str = string.gsub(str, '"', "&quot;")
    return str
end

local function imageSourceFromData(data)
    if data.sourceType == "photo" then
        if data.photoData and data.photoMime then
            return "data:" .. data.photoMime .. ";base64," .. data.photoData
        end
        local cached = T.PhotoCache[data.photoID or ""]
        if cached then
            return "data:" .. cached.mime .. ";base64," .. cached.data
        end
    end
    return data.url or ""
end

local function ensurePhotoRequested(frame, id)
    if not id or id == "" then return end
    frame.PhotoRequestPending = frame.PhotoRequestPending or {}
    if T.PhotoCache[id] or frame.PhotoRequestPending[id] then return end
    frame.PhotoRequestPending[id] = true
    net.Start(T.Net.PhotoDataRequest)
        net.WriteString(id)
    net.SendToServer()
end

local function applyImageHTML(html, data)
    local src = imageSourceFromData(data)
    local fit = data.fit or "contain"
    local grayscale = data.grayscale and "grayscale(100%)" or "none"
    local body = [[<html><body style="margin:0;overflow:hidden;background:transparent;"><img src="]] .. escapeHTML(src) .. [[" style="width:100%;height:100%;object-fit:]] .. fit .. [[;filter:]] .. grayscale .. [[;image-rendering:auto;"/></body></html>]]
    html:SetHTML(body)
end

local function encodeCurrent(frame)
    local payload = encodePayload(frame.Design)
    if not payload then
        notify(L("design_too_large"), 1)
        return nil
    end
    return payload
end

local function deleteSelected(frame)
    local sel = IsValid(frame.Page.Selected) and frame.Page.Selected or nil
    if not sel then return end
    local data = sel.Data
    for i = #frame.Design.elements, 1, -1 do
        if frame.Design.elements[i] == data then table.remove(frame.Design.elements, i) break end
    end
    frame.Page.Selected = nil
    frame.Page:Rebuild(true)
end

local function copySelected(frame)
    local sel = IsValid(frame.Page.Selected) and frame.Page.Selected or nil
    if not sel then notify(L("copied_none"), 1) return end
    T.EditorClipboard = table.Copy(sel.Data)
end

local function pasteClipboard(frame, x, y)
    if not T.EditorClipboard then notify(L("paste_none"), 1) return end
    if #frame.Design.elements >= C.MaxElements then notify(L("element_limit"), 1) return end
    local data = table.Copy(T.EditorClipboard)
    data.x = math.Clamp(math.floor(tonumber(x) or (data.x + 20)), 0, C.PageWidth - data.w)
    data.y = math.Clamp(math.floor(tonumber(y) or (data.y + 20)), 0, C.PageHeight - data.h)
    frame.Design.elements[#frame.Design.elements + 1] = data
    frame.Page:Rebuild(true)
end

local function cutSelected(frame)
    copySelected(frame)
    deleteSelected(frame)
end

local function makePageRenderer(parent, design, editable, frame)
    local page = vgui.Create("DPanel", parent)
    page.Design = design
    page.Editable = editable == true
    page.Frame = frame
    page.ElementPanels = {}
    page.Selected = nil

    function page:Paint(w, h)
        draw.RoundedBox(2, 0, 0, w, h, Color(244, 239, 221))
        surface.SetDrawColor(195, 185, 160)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end

    function page:GetScale()
        return self:GetWide() / C.PageWidth
    end

    function page:PerformLayout()
        local s = self:GetScale()
        for _, pnl in ipairs(self.ElementPanels or {}) do
            if IsValid(pnl) then
                local d = pnl.Data
                pnl:SetPos(math.floor(d.x * s), math.floor(d.y * s))
                pnl:SetSize(math.max(8, math.floor(d.w * s)), math.max(8, math.floor(d.h * s)))
                if pnl.Content and pnl.Content.SetSize then pnl.Content:SetSize(pnl:GetSize()) end
            end
        end
    end

    function page:OpenContextMenu(x, y)
        local menu = DermaMenu()
        menu:AddOption(L("paste"), function() pasteClipboard(self.Frame, x, y) end)
        menu:Open()
    end

    function page:OnMousePressed(code)
        if code ~= MOUSE_RIGHT then return end
        local mx, my = self:LocalCursorPos()
        local s = self:GetScale()
        self:OpenContextMenu(math.floor(mx / s), math.floor(my / s))
    end

    function page:Rebuild(keepSelection)
        local oldData = keepSelection and IsValid(self.Selected) and self.Selected.Data or nil
        for _, pnl in ipairs(self.ElementPanels or {}) do if IsValid(pnl) then pnl:Remove() end end
        self.ElementPanels = {}
        self.Selected = nil
        for _, data in ipairs(self.Design.elements or {}) do
            local pnl = vgui.Create("DPanel", self)
            pnl.Data = data
            pnl:SetMouseInputEnabled(true)
            pnl.DragMode = nil
            pnl.Content = nil

            if data.kind == "image" then
                local html = vgui.Create("DHTML", pnl)
                html:Dock(FILL)
                html:SetMouseInputEnabled(false)
                html:SetAllowLua(false)
                pnl.Content = html
                applyImageHTML(html, data)
                if data.sourceType == "photo" and not data.photoData then
                    ensurePhotoRequested(self.Frame, data.photoID)
                end
            end

            function pnl:Paint(w, h)
                if data.kind == "text" or data.kind == "title" or data.kind == "subtitle" then
                    T.DrawTextElement(data, w, h)
                elseif data.kind == "shape" then
                    T.DrawShapeElement(data, w, h)
                elseif not self.Content then
                    draw.RoundedBox(0, 0, 0, w, h, Color(230, 230, 230))
                    draw.SimpleText(L("image_placeholder"), "DermaDefaultBold", w / 2, h / 2, Color(60, 60, 60), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                end
            end

            function pnl:PaintOver(w, h)
                if data.kind == "image" and data.border then
                    surface.SetDrawColor(colorObj(data.borderColor))
                    surface.DrawOutlinedRect(0, 0, w, h, math.max(1, data.borderWidth or 2))
                end

                if not page.Editable then return end
                if page.Selected == self then
                    surface.SetDrawColor(70, 120, 190, 255)
                    surface.DrawOutlinedRect(0, 0, w, h, 2)
                    draw.RoundedBox(0, w - 12, h - 12, 12, 12, Color(70, 120, 190))
                else
                    surface.SetDrawColor(130, 130, 130, 110)
                    surface.DrawOutlinedRect(0, 0, w, h, 1)
                end
            end

            function pnl:OpenContextMenu()
                page.Selected = self
                rebuildProperties(page.Frame)
                local menu = DermaMenu()
                menu:AddOption(L("copy"), function() copySelected(page.Frame) end)
                menu:AddOption(L("paste"), function() pasteClipboard(page.Frame) end)
                menu:AddOption(L("cut_action"), function() cutSelected(page.Frame) end)
                menu:AddOption(L("delete"), function() deleteSelected(page.Frame) end)
                menu:Open()
            end

            function pnl:OnMousePressed(code)
                page.Selected = self
                rebuildProperties(page.Frame)
                if code == MOUSE_RIGHT then self:OpenContextMenu() return end
                if code ~= MOUSE_LEFT or not page.Editable then return end
                local mx, my = self:LocalCursorPos()
                if mx >= self:GetWide() - 16 and my >= self:GetTall() - 16 then self.DragMode = "resize" else self.DragMode = "move" end
                self.StartMouseX, self.StartMouseY = gui.MousePos()
                self.StartX, self.StartY = self.Data.x, self.Data.y
                self.StartW, self.StartH = self.Data.w, self.Data.h
                self:MouseCapture(true)
            end

            function pnl:OnMouseReleased(code)
                if code ~= MOUSE_LEFT then return end
                self.DragMode = nil
                self:MouseCapture(false)
            end

            function pnl:Think()
                if not self.DragMode then return end
                local mx, my = gui.MousePos()
                local s = page:GetScale()
                if s <= 0 then return end
                local dx = (mx - self.StartMouseX) / s
                local dy = (my - self.StartMouseY) / s
                if self.DragMode == "move" then
                    self.Data.x = math.floor(math.Clamp(self.StartX + dx, 0, C.PageWidth - self.Data.w))
                    self.Data.y = math.floor(math.Clamp(self.StartY + dy, 0, C.PageHeight - self.Data.h))
                else
                    self.Data.w = math.floor(math.Clamp(self.StartW + dx, C.MinElementWidth, C.PageWidth - self.Data.x))
                    self.Data.h = math.floor(math.Clamp(self.StartH + dy, C.MinElementHeight, C.PageHeight - self.Data.y))
                end
                page:InvalidateLayout(true)
            end

            self.ElementPanels[#self.ElementPanels + 1] = pnl
            if oldData and oldData == data then self.Selected = pnl end
        end
        self:InvalidateLayout(true)
        if not keepSelection then rebuildProperties(self.Frame) end
    end

    return page
end

local function addSlider(parent, text, min, max, decimals, value, onChange)
    local slider = vgui.Create("DNumSlider", parent)
    slider:Dock(TOP)
    slider:SetTall(40)
    slider:SetText(text)
    slider:SetDark(true)
    if IsValid(slider.Label) then
        slider.Label:SetTextColor(Color(0, 0, 0))
        slider.Label:SetDark(true)
    end
    slider:SetMin(min)
    slider:SetMax(max)
    slider:SetDecimals(decimals or 0)
    slider:SetValue(value)
    slider.OnValueChanged = function(_, val) onChange(val) end
    return slider
end

local function addTextLabel(parent, txt)
    local lbl = vgui.Create("DLabel", parent)
    lbl:Dock(TOP)
    lbl:SetTall(20)
    lbl:SetText(txt)
    lbl:SetTextColor(Color(0, 0, 0))
    return lbl
end

local function makeColorMixer(parent, title, value, onChange)
    addTextLabel(parent, title)
    local mixer = vgui.Create("DColorMixer", parent)
    mixer:Dock(TOP)
    mixer:SetTall(130)
    mixer:SetPalette(false)
    mixer:SetAlphaBar(true)
    mixer:SetWangs(true)
    writeColorToMixer(mixer, value)
    mixer.ValueChanged = function(_, col)
        onChange({r = col.r, g = col.g, b = col.b, a = col.a})
    end
    return mixer
end

function rebuildProperties(frame)
    local props = frame.Properties
    if not IsValid(props) then return end
    props:Clear()
    local canvas = props:GetCanvas()

    local title = vgui.Create("DLabel", canvas)
    title:Dock(TOP)
    title:SetTall(30)
    title:SetFont("DermaDefaultBold")
    title:SetText(L("props_title"))
    title:SetTextColor(Color(0, 0, 0))
    title:SetContentAlignment(5)

    local selected = frame.Page.Selected
    if not IsValid(selected) then
        local empty = vgui.Create("DLabel", canvas)
        empty:Dock(TOP)
        empty:SetTall(60)
        empty:SetWrap(true)
        empty:SetTextColor(Color(0, 0, 0))
        empty:SetText(L("no_selection"))
        return
    end

    local data = selected.Data
    addSlider(canvas, L("width"), C.MinElementWidth, C.PageWidth, 0, data.w, function(v)
        data.w = math.Clamp(math.floor(v), C.MinElementWidth, C.PageWidth - data.x)
        frame.Page:InvalidateLayout(true)
    end)
    addSlider(canvas, L("height"), C.MinElementHeight, C.PageHeight, 0, data.h, function(v)
        data.h = math.Clamp(math.floor(v), C.MinElementHeight, C.PageHeight - data.y)
        frame.Page:InvalidateLayout(true)
    end)

    if data.kind == "text" or data.kind == "title" or data.kind == "subtitle" then
        addTextLabel(canvas, L("text_value"))
        local text = vgui.Create("DTextEntry", canvas)
        text:Dock(TOP)
        text:SetTall(110)
        text:SetMultiline(true)
        text:SetText(data.text or "")
        text.OnChange = function(self) data.text = self:GetValue() end

        addSlider(canvas, L("font_size"), C.MinFontSize, C.MaxFontSize, 0, data.fontSize or 18, function(v)
            data.fontSize = math.floor(v)
        end)

        addTextLabel(canvas, L("alignment"))
        local align = vgui.Create("DComboBox", canvas)
        align:Dock(TOP); align:SetTall(26)
        align:AddChoice("Left", "left", data.align == "left")
        align:AddChoice("Center", "center", data.align == "center")
        align:AddChoice("Right", "right", data.align == "right")
        align.OnSelect = function(_, _, _, value) data.align = value end

        addTextLabel(canvas, L("font"))
        local font = vgui.Create("DComboBox", canvas)
        font:Dock(TOP); font:SetTall(26)
        font:AddChoice("Sans", "sans", data.font == "sans")
        font:AddChoice("Serif", "serif", data.font == "serif")
        font:AddChoice("Mono", "mono", data.font == "mono")
        font.OnSelect = function(_, _, _, value) data.font = value end

        local bold = vgui.Create("DCheckBoxLabel", canvas)
        bold:Dock(TOP); bold:SetTall(24); bold:SetText(L("bold")); bold:SetTextColor(Color(0,0,0))
        bold:SetValue(data.bold and 1 or 0)
        bold.OnChange = function(_, val) data.bold = val == true end

        local underline = vgui.Create("DCheckBoxLabel", canvas)
        underline:Dock(TOP); underline:SetTall(24); underline:SetText(L("underline")); underline:SetTextColor(Color(0,0,0))
        underline:SetValue(data.underline and 1 or 0)
        underline.OnChange = function(_, val) data.underline = val == true end

        makeColorMixer(canvas, L("color"), data.color, function(col) data.color = col end)
    elseif data.kind == "image" then
        addTextLabel(canvas, L("source") .. ": " .. (data.sourceType == "photo" and L("source_gallery") or L("source_url")))
        local change = vgui.Create("DButton", canvas)
        change:Dock(TOP); change:SetTall(28); change:SetText(L("change_source"))
        change.DoClick = function() frame:PromptAddImage(data) end

        addTextLabel(canvas, L("fit_mode"))
        local fit = vgui.Create("DComboBox", canvas)
        fit:Dock(TOP); fit:SetTall(26)
        fit:AddChoice(L("fit_contain"), "contain", data.fit == "contain")
        fit:AddChoice(L("fit_cover"), "cover", data.fit == "cover")
        fit:AddChoice(L("fit_fill"), "fill", data.fit == "fill")
        fit.OnSelect = function(_, _, _, value)
            data.fit = value
            if IsValid(selected.Content) then applyImageHTML(selected.Content, data) end
        end

        local gray = vgui.Create("DCheckBoxLabel", canvas)
        gray:Dock(TOP); gray:SetTall(24); gray:SetText(L("grayscale")); gray:SetTextColor(Color(0,0,0))
        gray:SetValue(data.grayscale and 1 or 0)
        gray.OnChange = function(_, val)
            data.grayscale = val == true
            if IsValid(selected.Content) then applyImageHTML(selected.Content, data) end
        end

        local border = vgui.Create("DCheckBoxLabel", canvas)
        border:Dock(TOP); border:SetTall(24); border:SetText(L("use_border")); border:SetTextColor(Color(0,0,0))
        border:SetValue(data.border and 1 or 0)
        border.OnChange = function(_, val) data.border = val == true end

        addSlider(canvas, L("border_width"), 0, 12, 0, data.borderWidth or 2, function(v) data.borderWidth = math.floor(v) end)
        makeColorMixer(canvas, L("border_color"), data.borderColor, function(col) data.borderColor = col end)
    elseif data.kind == "shape" then
        addTextLabel(canvas, L("shape_type"))
        local shape = vgui.Create("DComboBox", canvas)
        shape:Dock(TOP); shape:SetTall(26)
        shape:AddChoice(L("rect"), "rect", data.shape == "rect")
        shape:AddChoice(L("ellipse"), "ellipse", data.shape == "ellipse")
        shape:AddChoice(L("triangle"), "triangle", data.shape == "triangle")
        shape.OnSelect = function(_, _, _, value) data.shape = value end
        makeColorMixer(canvas, L("color"), data.color, function(col) data.color = col end)
        addSlider(canvas, L("border_width"), 0, 12, 0, data.borderWidth or 2, function(v) data.borderWidth = math.floor(v) end)
        makeColorMixer(canvas, L("border_color"), data.borderColor, function(col) data.borderColor = col end)
    end

    local delete = vgui.Create("DButton", canvas)
    delete:Dock(TOP)
    delete:DockMargin(0, 12, 0, 0)
    delete:SetTall(32)
    delete:SetText(L("delete_element"))
    delete.DoClick = function() deleteSelected(frame) end
end

local function addDefaultElement(frame, data)
    if #frame.Design.elements >= C.MaxElements then notify(L("element_limit"), 1) return end
    frame.Design.elements[#frame.Design.elements + 1] = data
    frame.Page:Rebuild(true)
    frame.Page.Selected = frame.Page.ElementPanels[#frame.Page.ElementPanels]
    rebuildProperties(frame)
end

local function addElement(frame, kind, extra)
    if kind == "text" then
        addDefaultElement(frame, {kind = "text", text = "New text", x = 55, y = 180, w = 280, h = 120, fontSize = 18, align = "left", font = "sans", bold = false, underline = false, color = {r = 25, g = 25, b = 25, a = 255}})
    elseif kind == "title" then
        addDefaultElement(frame, {kind = "title", text = "MAIN HEADLINE", x = 60, y = 60, w = 600, h = 80, fontSize = 38, align = "center", font = "serif", bold = true, underline = false, color = {r = 25, g = 25, b = 25, a = 255}})
    elseif kind == "subtitle" then
        addDefaultElement(frame, {kind = "subtitle", text = "Subtitle", x = 60, y = 150, w = 420, h = 60, fontSize = 26, align = "left", font = "serif", bold = true, underline = false, color = {r = 25, g = 25, b = 25, a = 255}})
    elseif kind == "image" then
        local data = {kind = "image", x = 80, y = 240, w = 220, h = 160, fit = "contain", border = false, borderWidth = 2, borderColor = {r = 25, g = 25, b = 25, a = 255}, grayscale = false, color = {r = 255, g = 255, b = 255, a = 255}}
        if extra then for k, v in pairs(extra) do data[k] = v end end
        addDefaultElement(frame, data)
    elseif kind == "shape" then
        local data = {kind = "shape", shape = extra or "rect", x = 100, y = 320, w = 180, h = 120, color = {r = 200, g = 200, b = 200, a = 200}, borderColor = {r = 25, g = 25, b = 25, a = 255}, borderWidth = 2}
        addDefaultElement(frame, data)
    end
end

local function updateTemplateCombo(frame, list)
    frame.TemplateList = list or {}
    if not IsValid(frame.TemplateCombo) then return end
    frame.TemplateCombo:Clear()
    frame.TemplateCombo:SetValue(L("templates"))
    for _, tpl in ipairs(frame.TemplateList) do frame.TemplateCombo:AddChoice(tpl.name, tpl.id) end
end

local function updatePhotoList(frame, list)
    frame.PhotoList = list or {}

    local keep = {}
    for _, photo in ipairs(frame.PhotoList) do
        if photo.id then keep[photo.id] = true end
    end
    for id in pairs(T.PhotoCache or {}) do
        if not keep[id] then T.PhotoCache[id] = nil end
    end

    if IsValid(T.GalleryWindow) and T.GalleryWindow.OwnerFrame == frame and T.GalleryWindow.PopulateList then
        T.GalleryWindow:PopulateList()
    end
end

local function currentDesign(frame)
    local design = table.Copy(frame.Design)
    if IsValid(frame.NameEntry) then design.newspaperName = frame.NameEntry:GetValue() end
    return design
end

local function sendDraftSave(frame)
    if not frame or not IsValid(frame.Printer) then return end
    if not frame.SessionToken or frame.SessionToken == "" then return end

    local payload = encodePayload(currentDesign(frame))
    if not payload then return end

    net.Start(T.Net.DraftSave)
        net.WriteEntity(frame.Printer)
        net.WriteString(frame.SessionToken)
        writePayloadBytes(payload)
    net.SendToServer()
end

local function sendTemplateSaveRequest(frame, id, name)
    if not IsValid(frame) then return end
    local payload = encodeCurrent(frame)
    if not payload then return end

    net.Start(T.Net.TemplateSave)
        net.WriteEntity(frame.Printer)
        net.WriteString(frame.SessionToken)
        net.WriteString(id or "")
        net.WriteString(name or "")
        writePayloadBytes(payload)
    net.SendToServer()
end

local function promptTemplateName(frame, defaultName, onChosen)
    Derma_StringRequest(
        L("save_template_title"),
        L("save_template_prompt"),
        defaultName or frame.Design.newspaperName or "My template",
        function(name)
            if not IsValid(frame) then return end
            name = string.Trim(tostring(name or ""))
            if name == "" then return end
            onChosen(name)
        end
    )
end

local function saveTemplate(frame)
    if frame.CurrentTemplateID and frame.CurrentTemplateID ~= "" then
        sendTemplateSaveRequest(frame, frame.CurrentTemplateID, frame.CurrentTemplateName or frame.Design.newspaperName or "Template")
        return
    end

    promptTemplateName(frame, frame.CurrentTemplateName or frame.Design.newspaperName or "My template", function(name)
        sendTemplateSaveRequest(frame, "", name)
    end)
end

local function saveTemplateAs(frame)
    promptTemplateName(frame, frame.CurrentTemplateName or frame.Design.newspaperName or "My template", function(name)
        sendTemplateSaveRequest(frame, "", name)
    end)
end

local function openReader(issue, preview)
    if not issue or not issue.design then return end
    local frame = vgui.Create("DFrame")
    frame:SetSize(math.min(ScrW() * 0.78, 980), ScrH() * 0.92)
    frame:Center()
    frame:SetTitle(preview and L("preview_title") or L("issue_title", tostring(issue.issueNo or "?")))
    frame:MakePopup()

    local info = vgui.Create("DLabel", frame)
    info:Dock(TOP)
    info:SetTall(42)
    info:SetContentAlignment(5)
    info:SetFont("DermaDefaultBold")
    info:SetTextColor(Color(0,0,0))
    info:SetText(preview and L("preview_info", issue.newspaperName or issue.design.newspaperName or "Newspaper") or L("issue_info", issue.newspaperName or issue.design.newspaperName or "Newspaper", tostring(issue.issueNo or "?"), tostring(issue.createdText or ""), tostring(issue.author or "")))

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    local holder = scroll:Add("DPanel")
    holder:Dock(TOP)
    holder.Paint = nil

    local maxW = math.min(C.PageWidth, frame:GetWide() - 80)
    local scale = maxW / C.PageWidth
    local page = makePageRenderer(holder, issue.design, false, frame)
    page:SetSize(math.floor(C.PageWidth * scale), math.floor(C.PageHeight * scale))
    page:SetPos(20, 10)
    page:Rebuild(true)

    holder:SetTall(page:GetTall() + 30)
    holder.PerformLayout = function(self)
        page:SetPos(math.max(10, (self:GetWide() - page:GetWide()) / 2), 10)
    end
end

local function setGalleryPreviewHTML(preview, html)
    if not IsValid(preview) then return end
    preview:SetHTML(html)
end

local function previewPhotoInPanel(frame, preview, photoID)
    if not photoID or photoID == "" then
        setGalleryPreviewHTML(preview, "<html><body style='margin:0;display:flex;align-items:center;justify-content:center;background:#ddd;color:#444'>" .. escapeHTML(L("photo_gallery_hint")) .. "</body></html>")
        return
    end

    if T.PhotoCache[photoID] then
        local c = T.PhotoCache[photoID]
        setGalleryPreviewHTML(preview, "<html><body style='margin:0;background:#ddd'><img src='data:" .. c.mime .. ";base64," .. c.data .. "' style='width:100%;height:100%;object-fit:contain;'></body></html>")
    else
        setGalleryPreviewHTML(preview, "<html><body style='margin:0;display:flex;align-items:center;justify-content:center;background:#ddd'>" .. escapeHTML(L("image_loading")) .. "</body></html>")
        ensurePhotoRequested(frame, photoID)
    end
end

local function openGalleryManager(frame, callback)
    if IsValid(T.GalleryWindow) then T.GalleryWindow:Remove() end

    local wnd = vgui.Create("DFrame")
    T.GalleryWindow = wnd
    wnd.OwnerFrame = frame
    wnd.InsertCallback = callback
    wnd.SelectedPhotoID = nil
    wnd:SetSize(860, 500)
    wnd:Center()
    wnd:SetTitle(L("gallery_title"))
    wnd:MakePopup()

    local list = vgui.Create("DListView", wnd)
    list:Dock(LEFT)
    list:SetWide(360)
    list:AddColumn(L("photo_gallery_col1"))
    list:AddColumn(L("photo_gallery_col2"))
    list:AddColumn(L("photo_gallery_col3"))
    wnd.List = list

    local right = vgui.Create("DPanel", wnd)
    right:Dock(FILL)
    right:DockPadding(8, 8, 8, 8)

    local hint = vgui.Create("DLabel", right)
    hint:Dock(TOP)
    hint:SetTall(40)
    hint:SetWrap(true)
    hint:SetTextColor(Color(0, 0, 0))
    hint:SetText(L("photo_gallery_hint"))

    local preview = vgui.Create("DHTML", right)
    preview:Dock(FILL)
    preview:SetAllowLua(false)
    wnd.Preview = preview

    local buttons = vgui.Create("DPanel", right)
    buttons:Dock(BOTTOM)
    buttons:SetTall(36)
    buttons.Paint = nil

    local insert = vgui.Create("DButton", buttons)
    insert:Dock(LEFT)
    insert:SetWide(160)
    insert:SetText(L("insert_photo"))
    insert:SetEnabled(callback ~= nil)
    insert.DoClick = function()
        if not callback then return end
        local chosen = wnd.SelectedPhotoID
        if not chosen then notify(L("no_photo_selected"), 1) return end
        callback(chosen)
        wnd:Close()
    end

    local delete = vgui.Create("DButton", buttons)
    delete:Dock(LEFT)
    delete:DockMargin(8, 0, 0, 0)
    delete:SetWide(120)
    delete:SetText(L("delete_photo"))
    delete.DoClick = function()
        local chosen = wnd.SelectedPhotoID
        if not chosen then notify(L("no_photo_selected"), 1) return end
        Derma_Query(L("delete_photo_confirm"), L("gallery_title"), L("delete"), function()
            if not IsValid(wnd) then return end
            net.Start(T.Net.PhotoDelete)
                net.WriteString(chosen)
            net.SendToServer()
        end, L("cancel"))
    end

    local close = vgui.Create("DButton", buttons)
    close:Dock(RIGHT)
    close:SetWide(100)
    close:SetText(L("close"))
    close.DoClick = function() wnd:Close() end

    function wnd:PopulateList()
        if not IsValid(self.List) then return end
        self.List:Clear()
        for _, photo in ipairs(frame.PhotoList or {}) do
            local line = self.List:AddLine(photo.title or photo.id, photo.createdText or "", tostring(photo.width or 0) .. "x" .. tostring(photo.height or 0))
            line.PhotoID = photo.id
        end

        local stillExists = false
        if self.SelectedPhotoID then
            for _, photo in ipairs(frame.PhotoList or {}) do
                if photo.id == self.SelectedPhotoID then stillExists = true break end
            end
        end
        if not stillExists then self.SelectedPhotoID = nil end
        previewPhotoInPanel(frame, self.Preview, self.SelectedPhotoID)
    end

    list.OnRowSelected = function(_, _, row)
        wnd.SelectedPhotoID = row.PhotoID
        previewPhotoInPanel(frame, preview, wnd.SelectedPhotoID)
    end

    wnd.OnRemove = function(self)
        if T.GalleryWindow == self then T.GalleryWindow = nil end
    end

    wnd:PopulateList()
end

function T.TryRefreshEditorPhotos()
    if not IsValid(editor) then return end
    editor.Page:Rebuild(true)
end

local function buildSkinRecursive(panel)
    if not IsValid(panel) then return end
    if panel.SetTextColor then panel:SetTextColor(Color(0, 0, 0)) end
    for _, child in ipairs(panel:GetChildren()) do buildSkinRecursive(child) end
end

local function openEditor(printer, token, bootstrap)
    if IsValid(editor) then editor:Remove() end

    local frame = vgui.Create("DFrame")
    editor = frame
    frame:SetSize(math.min(ScrW() * 0.96, 1500), ScrH() * 0.94)
    frame:Center()
    frame:SetTitle(L("editor_title"))
    frame:MakePopup()
    frame.Printer = printer
    frame.SessionToken = token
    frame.TemplateList = bootstrap.templates or {}
    frame.PhotoList = bootstrap.photos or {}
    frame.PhotoRequestPending = {}
    frame.Design = bootstrap.draft or {newspaperName = "Newspaper", elements = {}}

    local function saveDraftOnExit(self)
        if self.DraftSavedOnExit then return end
        self.DraftSavedOnExit = true
        if C.DraftSaveOnClose then sendDraftSave(self) end
    end

    frame.OnClose = saveDraftOnExit
    frame.OnRemove = saveDraftOnExit

    if IsValid(frame.btnClose) then
        frame.btnClose.DoClick = function()
            if not IsValid(frame) then return end
            saveDraftOnExit(frame)
            frame:Close()
        end
    end

    function frame:PromptAddImage(existingData)
        local function setFromURL(url)
            if existingData then
                existingData.kind = "image"; existingData.sourceType = "url"; existingData.url = url; existingData.photoID = nil; existingData.photoData = nil; existingData.photoMime = nil
                if IsValid(self.Page.Selected and self.Page.Selected.Content) then applyImageHTML(self.Page.Selected.Content, existingData) end
            else
                addElement(self, "image", {sourceType = "url", url = url})
            end
            self.Page:Rebuild(true)
        end

        local function setFromPhoto(photoID)
            if existingData then
                existingData.kind = "image"; existingData.sourceType = "photo"; existingData.photoID = photoID; existingData.url = nil
                existingData.photoData = nil
                existingData.photoMime = nil
            else
                addElement(self, "image", {sourceType = "photo", photoID = photoID})
            end
            self.Page:Rebuild(true)
        end

        local menu = DermaMenu()
        menu:AddOption(L("image_from_url"), function()
            Derma_StringRequest(L("image_url_title"), L("image_url_prompt"), existingData and (existingData.url or "https://") or "https://", function(text)
                setFromURL(text)
            end)
        end)
        menu:AddOption(L("image_from_gallery"), function() openGalleryManager(self, setFromPhoto) end)
        menu:Open()
    end

    local function keyboardFocusIsTextEntry()
        local focus = vgui.GetKeyboardFocus()
        if not IsValid(focus) then return false end

        local className = focus.GetClassName and focus:GetClassName() or ""
        return className == "TextEntry" or className == "DTextEntry"
    end

    frame.ShortcutState = {}
    frame.Think = function(self)
        local ctrl = input.IsKeyDown(KEY_LCONTROL) or input.IsKeyDown(KEY_RCONTROL)
        local del = input.IsKeyDown(KEY_DELETE)
        local c = input.IsKeyDown(KEY_C)
        local v = input.IsKeyDown(KEY_V)
        local typing = keyboardFocusIsTextEntry()

        if not typing then
            if del and not self.ShortcutState.del then deleteSelected(self) end
            if ctrl and c and not self.ShortcutState.c then copySelected(self) end
            if ctrl and v and not self.ShortcutState.v then pasteClipboard(self) end
        end

        self.ShortcutState.del = del
        self.ShortcutState.c = c
        self.ShortcutState.v = v
    end

    local toolbar = vgui.Create("DPanel", frame)
    toolbar:Dock(TOP)
    toolbar:SetTall(48)

    local function toolButton(text, width, fn)
        local btn = vgui.Create("DButton", toolbar)
        btn:Dock(LEFT); btn:DockMargin(4, 6, 0, 6); btn:SetWide(width); btn:SetText(text); btn.DoClick = fn
        return btn
    end

    toolButton(L("add_text"), 80, function() addElement(frame, "text") end)
    toolButton(L("add_title"), 105, function() addElement(frame, "title") end)
    toolButton(L("add_subtitle"), 120, function() addElement(frame, "subtitle") end)
    toolButton(L("add_image"), 105, function() frame:PromptAddImage() end)
    toolButton(L("add_shape"), 90, function()
        local menu = DermaMenu()
        menu:AddOption(L("rect"), function() addElement(frame, "shape", "rect") end)
        menu:AddOption(L("ellipse"), function() addElement(frame, "shape", "ellipse") end)
        menu:AddOption(L("triangle"), function() addElement(frame, "shape", "triangle") end)
        menu:Open()
    end)

    local combo = vgui.Create("DComboBox", toolbar)
    combo:Dock(LEFT); combo:DockMargin(10, 6, 0, 6); combo:SetWide(170); combo:SetValue(L("templates")); frame.TemplateCombo = combo
    combo.OnSelect = function(_, _, _, id)
        if not id then return end
        net.Start(T.Net.TemplateLoad)
            net.WriteEntity(frame.Printer)
            net.WriteString(frame.SessionToken)
            net.WriteString(id)
        net.SendToServer()
    end

    toolButton(L("save"), 90, function() saveTemplate(frame) end)
    toolButton(L("save_as"), 110, function() saveTemplateAs(frame) end)

    toolButton(L("delete_template"), 120, function()
        if not frame.CurrentTemplateID then notify(L("no_template_loaded"), 1) return end
        Derma_Query(L("delete_template_confirm"), L("addon_name"), L("delete"), function()
            if not IsValid(frame) then return end
            net.Start(T.Net.TemplateDelete)
                net.WriteEntity(frame.Printer)
                net.WriteString(frame.SessionToken)
                net.WriteString(frame.CurrentTemplateID or "")
            net.SendToServer()
            frame.CurrentTemplateID = nil; frame.CurrentTemplateName = nil
        end, L("cancel"))
    end)

    toolButton(L("clear_page"), 80, function()
        Derma_Query(L("clear_confirm"), L("addon_name"), L("clear"), function() if IsValid(frame) then frame.Design.elements = {} frame.Page:Rebuild(true) end end, L("cancel"))
    end)

    toolButton(L("preview"), 105, function() openReader({newspaperName = currentDesign(frame).newspaperName, design = currentDesign(frame)}, true) end)

    local print = vgui.Create("DButton", toolbar)
    print:Dock(RIGHT); print:DockMargin(0, 6, 6, 6); print:SetWide(110); print:SetText(L("print"))
    print.DoClick = function()
        if not IsValid(frame.Printer) then notify(L("printer_missing"), 1) return end
        local payload = encodeCurrent(frame)
        if not payload then return end
        net.Start(T.Net.Print)
            net.WriteEntity(frame.Printer)
            net.WriteString(frame.SessionToken)
            writePayloadBytes(payload)
        net.SendToServer()
    end

    local ink = vgui.Create("DLabel", toolbar)
    ink:Dock(RIGHT); ink:SetWide(175); ink:SetContentAlignment(5); ink:SetFont("DermaDefaultBold"); ink:SetTextColor(Color(0, 0, 0))
    ink.Think = function(self)
        if not IsValid(frame.Printer) then self:SetText(L("printer_missing")) return end
        local state = frame.Printer:GetPrinting() and L("state_printing") or L("state_ready")
        self:SetText(L("ink_status", frame.Printer:GetInk(), C.PrinterInkCapacity) .. "\n" .. state)
    end

    local body = vgui.Create("DPanel", frame)
    body:Dock(FILL); body:DockPadding(8, 8, 8, 8)

    local left = vgui.Create("DPanel", body)
    left:Dock(LEFT); left:SetWide(210); left:DockMargin(0, 0, 8, 0)

    local nameLabel = addTextLabel(left, L("newspaper_name"))
    nameLabel:SetTall(25)
    local name = vgui.Create("DTextEntry", left)
    name:Dock(TOP); name:SetTall(30); name:SetText(frame.Design.newspaperName or "Newspaper")
    name:SetUpdateOnType(true)
    name.OnValueChange = function(_, value) frame.Design.newspaperName = string.sub(value or "", 1, C.MaxNewspaperNameLength) end
    frame.NameEntry = name

    local help = vgui.Create("DLabel", left)
    help:Dock(TOP); help:DockMargin(0, 16, 0, 0); help:SetTall(280); help:SetWrap(true); help:SetTextColor(Color(0,0,0)); help:SetText(L("help_text"))

    local props = vgui.Create("DScrollPanel", body)
    props:Dock(RIGHT); props:SetWide(280); props:DockMargin(8, 0, 0, 0); frame.Properties = props

    local center = vgui.Create("DPanel", body)
    center:Dock(FILL)
    center.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, Color(55, 58, 63)) end

    local page = makePageRenderer(center, frame.Design, true, frame)
    frame.Page = page
    center.PerformLayout = function(self)
        local availableW = self:GetWide() - 32
        local availableH = self:GetTall() - 32
        local scale = math.min(availableW / C.PageWidth, availableH / C.PageHeight)
        scale = math.max(0.25, scale)
        page:SetSize(math.floor(C.PageWidth * scale), math.floor(C.PageHeight * scale))
        page:SetPos(math.floor((self:GetWide() - page:GetWide()) / 2), math.floor((self:GetTall() - page:GetTall()) / 2))
        page:InvalidateLayout(true)
    end

    updateTemplateCombo(frame, bootstrap.templates)
    updatePhotoList(frame, bootstrap.photos)
    page:Rebuild(true)
    rebuildProperties(frame)
    buildSkinRecursive(frame)
    if bootstrap.draft then notify(L("draft_restored"), 0) end
end

T.Net = T.Net or {
    Bootstrap = "typo_bootstrap",
    TemplateList = "typo_template_list",
    TemplateSave = "typo_template_save",
    TemplateLoad = "typo_template_load",
    TemplateData = "typo_template_data",
    TemplateDelete = "typo_template_delete",
    DraftSave = "typo_draft_save",
    Print = "typo_print",
    OpenIssue = "typo_open_issue",
    Notify = "typo_notify",
    PhotoUpload = "typo_photo_upload",
    PhotoList = "typo_photo_list",
    PhotoDataRequest = "typo_photo_request",
    PhotoData = "typo_photo_data",
    PhotoDelete = "typo_photo_delete",
    CameraCapture = "typo_camera_capture",
    StorageClear = "typo_storage_clear"
}

net.Receive(T.Net.Bootstrap, function()
    local printer = net.ReadEntity()
    local token = net.ReadString()
    local bootstrap = readPayload() or {}
    openEditor(printer, token, bootstrap)
end)

net.Receive(T.Net.TemplateList, function()
    local list = readPayload() or {}
    if IsValid(editor) then updateTemplateCombo(editor, list) end
end)

net.Receive(T.Net.PhotoList, function()
    local list = readPayload() or {}
    if IsValid(editor) then updatePhotoList(editor, list) end
end)

net.Receive(T.Net.TemplateData, function()
    local payload = readPayload()
    if not payload or not payload.design or not IsValid(editor) then return end
    editor.CurrentTemplateID = payload.id
    editor.CurrentTemplateName = payload.name
    editor.Design = payload.design
    editor.Page.Design = editor.Design
    if IsValid(editor.NameEntry) then editor.NameEntry:SetText(editor.Design.newspaperName or "Newspaper") end
    editor.Page:Rebuild(true)
    if not payload.saved then
        notify(L("template_loaded"), 0)
    end
end)

net.Receive(T.Net.OpenIssue, function()
    local issue = readPayload()
    if issue then openReader(issue, false) end
end)

net.Receive(T.Net.Notify, function()
    notify(net.ReadString(), net.ReadUInt(2))
end)

net.Receive(T.Net.PhotoData, function()
    local id = net.ReadString()
    local mime = net.ReadString()
    local width = net.ReadUInt(16)
    local height = net.ReadUInt(16)
    local n = net.ReadUInt(16)
    if n <= 0 or n > (C.MaxEmbeddedPhotoBytes or 44000) then return end
    local data = net.ReadData(n)
    if not data then return end
    T.PhotoCache[id] = {mime = mime, data = data, width = width, height = height}
    if IsValid(editor) and editor.PhotoRequestPending then editor.PhotoRequestPending[id] = nil end
    if IsValid(T.GalleryWindow) and T.GalleryWindow.SelectedPhotoID == id and IsValid(T.GalleryWindow.OwnerFrame) and IsValid(T.GalleryWindow.Preview) then
        previewPhotoInPanel(T.GalleryWindow.OwnerFrame, T.GalleryWindow.Preview, id)
    end
    T.TryRefreshEditorPhotos()
end)
