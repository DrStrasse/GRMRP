Typography = Typography or {}
local T = Typography
local C = T.Config

local allowedKinds = {
    text = true,
    title = true,
    subtitle = true,
    image = true,
    shape = true
}

local allowedAlign = {
    left = true,
    center = true,
    right = true
}

local allowedFonts = {
    sans = true,
    serif = true,
    mono = true
}

local allowedImageFit = {
    contain = true,
    cover = true,
    fill = true
}

local allowedShapes = {
    rect = true,
    outline_rect = true,
    ellipse = true,
    outline_ellipse = true,
    triangle = true,
    outline_triangle = true
}

T.Locale = T.Locale or {
    ru = {
        addon_name = "G-Typography",
        printer_name = "Печатная машинка",
        printer_ready = "ГОТОВА",
        printer_printing = "ПЕЧАТЬ...",
        printer_no_ink = "НЕТ ЧЕРНИЛ",
        printer_low_ink = "МАЛО ЧЕРНИЛ",
        ink_label = "Чернила",
        state_label = "Состояние",
        unavailable = "Недоступно",
        editor_title = "G-Typography — редактор газеты",
        preview_title = "Предпросмотр газеты",
        issue_title = "Газета — выпуск №%s",
        issue_info = "%s • №%s • %s • Автор: %s",
        preview_info = "%s • предпросмотр",
        templates = "Шаблоны",
        save = "Сохранить",
        save_as = "Сохранить как…",
        delete_template = "Удалить шаблон",
        clear_page = "Очистить",
        preview = "Предпросмотр",
        print = "НАПЕЧАТАТЬ",
        add_text = "+ Текст",
        add_title = "+ Заголовок",
        add_subtitle = "+ Подзаголовок",
        add_image = "+ Изображение",
        add_shape = "+ Фигура",
        gallery = "Галерея",
        draft_restored = "Черновик восстановлен.",
        template_loaded = "Шаблон загружен.",
        template_saved = "Шаблон сохранён.",
        template_deleted = "Шаблон удалён.",
        design_too_large = "Макет слишком большой.",
        bad_request = "Некорректный запрос.",
        draft_saved = "Черновик сохранён.",
        no_template_loaded = "Сначала загрузите шаблон.",
        element_limit = "Достигнут лимит элементов.",
        no_selection = "Выберите элемент на странице, чтобы редактировать его свойства.",
        props_title = "Свойства элемента",
        newspaper_name = "Название газеты",
        help_text = "Как редактировать:\n\n• Перетаскивайте элементы мышью.\n• Тяните синий квадрат в углу для изменения размера.\n• Ctrl+C / Ctrl+V / Delete работают для выбранного элемента.\n• ПКМ открывает меню действий.\n• Изображения можно добавить по ссылке или из вашей фотогалереи.",
        ink_status = "Чернила: %s/%s",
        printer_missing = "Печатная машинка недоступна.",
        state_printing = "ПЕЧАТЬ",
        state_ready = "ГОТОВА",
        save_template_title = "Сохранение шаблона",
        save_template_prompt = "Название шаблона:",
        delete_template_confirm = "Удалить текущий шаблон?",
        clear_confirm = "Очистить страницу?",
        delete = "Удалить",
        cancel = "Отмена",
        width = "Ширина",
        height = "Высота",
        font_size = "Размер шрифта",
        alignment = "Выравнивание",
        font = "Шрифт",
        color = "Цвет",
        border_color = "Цвет рамки",
        border_width = "Толщина рамки",
        text_value = "Текст",
        bold = "Жирное начертание",
        underline = "Подчёркивание",
        grayscale = "Чёрно-белое",
        use_border = "Показывать рамку",
        fit_mode = "Режим вписывания",
        source = "Источник",
        source_url = "Ссылка",
        source_gallery = "Фото из галереи",
        change_source = "Сменить источник",
        shape_type = "Фигура",
        rect = "Прямоугольник",
        outline_rect = "Контурный прямоугольник",
        ellipse = "Эллипс",
        outline_ellipse = "Контурный эллипс",
        line = "Линия",
        triangle = "Треугольник",
        outline_triangle = "Контурный треугольник",
        fit_contain = "По размеру",
        fit_cover = "Заполнить",
        fit_fill = "Растянуть",
        delete_element = "Удалить элемент",
        copied = "Элемент скопирован.",
        pasted = "Элемент вставлен.",
        cut = "Элемент вырезан.",
        copied_none = "Нет выбранного элемента для копирования.",
        paste_none = "Буфер обмена пуст.",
        choose_image_source = "Добавление изображения",
        choose_image_source_text = "Выберите источник изображения.",
        image_url_title = "Ссылка на изображение",
        image_url_prompt = "Введите прямую HTTP/HTTPS ссылку на изображение:",
        image_from_url = "По ссылке",
        image_from_gallery = "Из галереи",
        gallery_title = "Галерея фотографий",
        gallery_empty = "Галерея пуста. Сделайте снимок камерой.",
        use_selected_photo = "Использовать фото",
        no_photo_selected = "Выберите фото из галереи.",
        image_placeholder = "Изображение",
        image_loading = "Загрузка фото...",
        camera_name = "Камера G-Typography",
        camera_saved = "Фото сохранено в галерею.",
        camera_failed = "Не удалось сохранить фото.",
        photo_title = "Название фото",
        photo_title_prompt = "Введите подпись для фото:",
        photo_default_title = "Снимок",
        photo_uploaded = "Фото загружено в галерею.",
        photo_request_failed = "Не удалось загрузить фото.",
        inserted_ink = "Чернила добавлены: %s/%s",
        printer_full_ink = "Запас чернил уже полный.",
        wait_print_end = "Дождитесь окончания печати.",
        picked_up_ink = "Картридж можно перетащить к печатной машинке клавишей E.",
        player_unavailable = "Игрок недоступен.",
        printer_unavailable = "Печатная машинка недоступна.",
        approach_printer = "Подойдите ближе к печатной машинке.",
        team_denied = "Ваша профессия не может пользоваться типографией.",
        access_denied = "Доступ к печатной машинке запрещён.",
        session_expired = "Сессия редактора истекла. Откройте машинку заново.",
        invalid_session = "Неверная сессия редактора.",
        bad_design = "Макет повреждён или слишком велик.",
        printing_busy = "Печатная машинка уже работает.",
        printer_cooldown = "Печатная машинка ещё не готова.",
        world_limit = "На карте достигнут лимит газет.",
        not_enough_ink = "Недостаточно чернил.",
        cannot_pay = "Невозможно оплатить печать.",
        issue_created = "Выпуск №%s напечатан.",
        issue_spawn_fail = "Выпуск создан, но сущность газеты создать не удалось.",
        issue_not_found = "Данные этой газеты не найдены.",
        invalid_format = "Макет имеет неверный формат.",
        missing_elements = "В макете отсутствует список элементов.",
        too_many_elements = "Слишком много элементов на странице.",
        template_name_required = "Введите название шаблона.",
        template_limit = "Достигнут лимит сохранённых шаблонов.",
        template_disk_fail = "Не удалось сохранить шаблон на диск.",
        template_update_fail = "Не удалось обновить хранилище шаблонов.",
        template_not_found = "Шаблон не найден.",
        issue_create_fail = "Не удалось создать выпуск.",
        photo_invalid = "Некорректное фото.",
        photo_limit = "Достигнут лимит фото в галерее.",
        photo_not_found = "Фото не найдено.",
        url_blocked = "Ссылка на изображение запрещена сервером.",
        clear = "Очистить",
        copy = "Скопировать",
        paste = "Вставить",
        cut_action = "Вырезать",
        change_color = "Изменить цвет",
        choose_shape = "Выберите фигуру",
        photo_gallery_col1 = "Название",
        photo_gallery_col2 = "Дата",
        photo_gallery_col3 = "Размер",
        choose = "Выбрать",
        delete_photo = "Удалить фото",
        close = "Закрыть",
        gallery_manage = "Галерея",
        insert_photo = "Вставить в газету",
        photo_deleted = "Фото удалено.",
        delete_photo_confirm = "Удалить выбранное фото из галереи?",
        photo_gallery_hint = "Выберите фото слева, чтобы просмотреть, удалить или вставить его в макет.",
        camera_settings = "Настройки камеры",
        camera_resolution = "Разрешение снимка",
        camera_resolution_help = "Выберите разрешение фотографий SWEP-камеры. Большие снимки автоматически сильнее сжимаются для передачи по сети.",
        memory_settings = "Память",
        memory_help = "Управление вашими сохранёнными данными G-Typography",
        memory_delete_photos = "Удалить все фото",
        memory_delete_templates = "Удалить все шаблоны",
        memory_delete_all = "Удалить всё",
        memory_confirm_photos = "Удалить все фотографии из вашей галереи? Это действие нельзя отменить.",
        memory_confirm_templates = "Удалить все ваши шаблоны? Это действие нельзя отменить.",
        memory_confirm_all = "Удалить все фото, шаблоны и сохранённый черновик G-Typography? Это действие нельзя отменить.",
        memory_confirm_title = "G-Typography — Память",
        storage_photos_cleared = "Все фотографии удалены.",
        storage_templates_cleared = "Все шаблоны удалены.",
        storage_all_cleared = "Все сохранённые данные G-Typography удалены.",
        stand_title = "Газетный стенд",
        stand_count = "Газет: %s/%s",
        stand_empty = "Стенд пуст.",
        stand_full = "Газетный стенд заполнен.",
        stand_inserted = "Газета помещена на стенд.",
        stand_take_failed = "Не удалось выдать газету со стенда."
    },
    en = {
        addon_name = "G-Typography",
        printer_name = "Printing Machine",
        printer_ready = "READY",
        printer_printing = "PRINTING...",
        printer_no_ink = "NO INK",
        printer_low_ink = "LOW INK",
        ink_label = "Ink",
        state_label = "State",
        unavailable = "Unavailable",
        editor_title = "G-Typography — newspaper editor",
        preview_title = "Newspaper preview",
        issue_title = "Newspaper — issue #%s",
        issue_info = "%s • #%s • %s • Author: %s",
        preview_info = "%s • preview",
        templates = "Templates",
        save = "Save",
        save_as = "Save as…",
        delete_template = "Delete template",
        clear_page = "Clear",
        preview = "Preview",
        print = "PRINT",
        add_text = "+ Text",
        add_title = "+ Title",
        add_subtitle = "+ Subtitle",
        add_image = "+ Image",
        add_shape = "+ Shape",
        gallery = "Gallery",
        draft_restored = "Draft restored.",
        template_loaded = "Template loaded.",
        template_saved = "Template saved.",
        template_deleted = "Template deleted.",
        design_too_large = "The layout is too large.",
        bad_request = "Bad request.",
        draft_saved = "Draft saved.",
        no_template_loaded = "Load a template first.",
        element_limit = "The page element limit has been reached.",
        no_selection = "Select an element on the page to edit its properties.",
        props_title = "Element properties",
        newspaper_name = "Newspaper title",
        help_text = "How to edit:\n\n• Drag elements with the mouse.\n• Pull the blue handle in the corner to resize.\n• Ctrl+C / Ctrl+V / Delete work on the selected element.\n• Right-click opens the action menu.\n• Images can be added by URL or from your photo gallery.",
        ink_status = "Ink: %s/%s",
        printer_missing = "The printing machine is unavailable.",
        state_printing = "PRINTING",
        state_ready = "READY",
        save_template_title = "Save template",
        save_template_prompt = "Template name:",
        delete_template_confirm = "Delete the current template?",
        clear_confirm = "Clear the page?",
        delete = "Delete",
        cancel = "Cancel",
        width = "Width",
        height = "Height",
        font_size = "Font size",
        alignment = "Alignment",
        font = "Font",
        color = "Color",
        border_color = "Border color",
        border_width = "Border width",
        text_value = "Text",
        bold = "Bold",
        underline = "Underline",
        grayscale = "Black and white",
        use_border = "Show border",
        fit_mode = "Fit mode",
        source = "Source",
        source_url = "URL",
        source_gallery = "Photo from gallery",
        change_source = "Change source",
        shape_type = "Shape",
        rect = "Rectangle",
        outline_rect = "Outlined rectangle",
        ellipse = "Ellipse",
        outline_ellipse = "Outlined ellipse",
        line = "Line",
        triangle = "Triangle",
        outline_triangle = "Outlined triangle",
        fit_contain = "Contain",
        fit_cover = "Cover",
        fit_fill = "Fill",
        delete_element = "Delete element",
        copied = "Element copied.",
        pasted = "Element pasted.",
        cut = "Element cut.",
        copied_none = "No selected element to copy.",
        paste_none = "Clipboard is empty.",
        choose_image_source = "Add image",
        choose_image_source_text = "Choose an image source.",
        image_url_title = "Image URL",
        image_url_prompt = "Enter a direct HTTP/HTTPS image URL:",
        image_from_url = "By URL",
        image_from_gallery = "From gallery",
        gallery_title = "Photo gallery",
        gallery_empty = "Your gallery is empty. Take a photo with the camera.",
        use_selected_photo = "Use photo",
        no_photo_selected = "Select a photo from the gallery.",
        image_placeholder = "Image",
        image_loading = "Loading photo...",
        camera_name = "G-Typography Camera",
        camera_saved = "Photo saved to the gallery.",
        camera_failed = "Failed to save the photo.",
        photo_title = "Photo title",
        photo_title_prompt = "Enter a title for the photo:",
        photo_default_title = "Snapshot",
        photo_uploaded = "Photo uploaded to the gallery.",
        photo_request_failed = "Failed to load the photo.",
        inserted_ink = "Ink inserted: %s/%s",
        printer_full_ink = "The ink reserve is already full.",
        wait_print_end = "Wait until printing is finished.",
        picked_up_ink = "You can drag the ink cartridge to the press with the E key.",
        player_unavailable = "Player unavailable.",
        printer_unavailable = "The printing machine is unavailable.",
        approach_printer = "Move closer to the printing machine.",
        team_denied = "Your job cannot use the typography system.",
        access_denied = "Access to the printing machine is denied.",
        session_expired = "The editor session has expired. Reopen the machine.",
        invalid_session = "Invalid editor session.",
        bad_design = "The layout is corrupted or too large.",
        printing_busy = "The printing machine is already working.",
        printer_cooldown = "The printing machine is not ready yet.",
        world_limit = "The world newspaper limit has been reached.",
        not_enough_ink = "Not enough ink.",
        cannot_pay = "Unable to pay for printing.",
        issue_created = "Issue #%s has been printed.",
        issue_spawn_fail = "The issue was created, but the newspaper entity could not be created.",
        issue_not_found = "The data for this newspaper could not be found.",
        invalid_format = "The layout format is invalid.",
        missing_elements = "The layout does not contain an element list.",
        too_many_elements = "Too many elements on the page.",
        template_name_required = "Enter a template name.",
        template_limit = "The saved template limit has been reached.",
        template_disk_fail = "Failed to save the template to disk.",
        template_update_fail = "Failed to update template storage.",
        template_not_found = "Template not found.",
        issue_create_fail = "Failed to create the issue.",
        photo_invalid = "Invalid photo.",
        photo_limit = "The photo gallery limit has been reached.",
        photo_not_found = "Photo not found.",
        url_blocked = "This image URL is blocked by the server.",
        clear = "Clear",
        copy = "Copy",
        paste = "Paste",
        cut_action = "Cut",
        change_color = "Change color",
        choose_shape = "Choose a shape",
        photo_gallery_col1 = "Title",
        photo_gallery_col2 = "Date",
        photo_gallery_col3 = "Size",
        choose = "Choose",
        delete_photo = "Delete photo",
        close = "Close",
        gallery_manage = "Gallery",
        insert_photo = "Insert into newspaper",
        photo_deleted = "Photo deleted.",
        delete_photo_confirm = "Delete the selected photo from the gallery?",
        photo_gallery_hint = "Select a photo on the left to preview, delete, or insert it into the layout.",
        camera_settings = "Camera settings",
        camera_resolution = "Photo resolution",
        camera_resolution_help = "Choose the SWEP camera photo resolution. Larger images are automatically compressed more aggressively for networking.",
        memory_settings = "Storage",
        memory_help = "Manage your saved G-Typography data",
        memory_delete_photos = "Delete all photos",
        memory_delete_templates = "Delete all templates",
        memory_delete_all = "Delete everything",
        memory_confirm_photos = "Delete every photo from your gallery? This cannot be undone.",
        memory_confirm_templates = "Delete all of your templates? This cannot be undone.",
        memory_confirm_all = "Delete all G-Typography photos, templates, and the saved draft? This cannot be undone.",
        memory_confirm_title = "G-Typography — Storage",
        storage_photos_cleared = "All photos deleted.",
        storage_templates_cleared = "All templates deleted.",
        storage_all_cleared = "All saved G-Typography data deleted.",
        stand_title = "Newspaper Stand",
        stand_count = "Newspapers: %s/%s",
        stand_empty = "The stand is empty.",
        stand_full = "The newspaper stand is full.",
        stand_inserted = "Newspaper placed on the stand.",
        stand_take_failed = "Failed to dispense a newspaper from the stand."
    }
}

local function finiteNumber(v, fallback)
    v = tonumber(v)
    if not v or v ~= v or math.abs(v) > 1000000 then
        return fallback
    end
    return v
end

function T.GetLang(langOrPly)
    if isstring(langOrPly) then
        if string.sub(string.lower(langOrPly), 1, 2) == "ru" then return "ru" end
        return "en"
    end

    if CLIENT then
        local cv = GetConVar and GetConVar("gmod_language")
        local val = cv and cv:GetString() or "en"
        if string.sub(string.lower(val), 1, 2) == "ru" then return "ru" end
        return "en"
    end

    local val = IsValid(langOrPly) and langOrPly:GetInfo("gmod_language") or "en"
    if string.sub(string.lower(val), 1, 2) == "ru" then return "ru" end
    return "en"
end

function T.L(langOrPly, key, ...)
    local lang = T.GetLang(langOrPly)
    local set = T.Locale[lang] or T.Locale.en
    local str = set[key] or T.Locale.en[key] or key
    if select("#", ...) > 0 then
        local ok, formatted = pcall(string.format, str, ...)
        if ok then return formatted end
    end
    return str
end

function T.TrimText(value, maxLen)
    value = tostring(value or "")
    value = string.Trim(value)
    if #value > maxLen then
        value = string.sub(value, 1, maxLen)
    end
    return value
end

function T.DefaultDesign()
    return {
        newspaperName = "Newspaper",
        elements = {}
    }
end

function T.CanUsePrinter(ply, printer)
    if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then
        return false, "player_unavailable"
    end

    if not IsValid(printer) or printer:GetClass() ~= "typography_printer" then
        return false, "printer_unavailable"
    end

    if ply:GetPos():DistToSqr(printer:GetPos()) > (C.InteractDistance * C.InteractDistance) then
        return false, "approach_printer"
    end

    if next(C.AllowedTeams) ~= nil and not C.AllowedTeams[ply:Team()] then
        return false, "team_denied"
    end

    local hookResult, hookReason = hook.Run("TypographyCanUsePrinter", ply, printer)
    if hookResult == false then
        return false, hookReason or "access_denied"
    end

    return true
end

function T.SanitizeColor(raw, fallback)
    local base = fallback or {r = 25, g = 25, b = 25, a = 255}
    if IsColor and IsColor(raw) then
        return {r = raw.r, g = raw.g, b = raw.b, a = raw.a}
    end
    if not istable(raw) then
        return table.Copy(base)
    end

    return {
        r = math.floor(math.Clamp(finiteNumber(raw.r, base.r), 0, 255)),
        g = math.floor(math.Clamp(finiteNumber(raw.g, base.g), 0, 255)),
        b = math.floor(math.Clamp(finiteNumber(raw.b, base.b), 0, 255)),
        a = math.floor(math.Clamp(finiteNumber(raw.a, base.a), 0, 255))
    }
end

function T.ColorObject(tbl)
    tbl = T.SanitizeColor(tbl)
    return Color(tbl.r, tbl.g, tbl.b, tbl.a)
end

local function normalizeHost(host)
    host = string.Trim(string.lower(tostring(host or "")))
    if host == "" then return "" end
    host = string.gsub(host, ":%d+$", "")
    return host
end

function T.ValidateImageURL(url)
    if not C.AllowRemoteImages then
        return false, "url_blocked"
    end

    url = T.TrimText(url, C.MaxImageURLLength)
    if url == "" then return false, "url_blocked" end
    if not string.match(url, "^https?://") then return false, "url_blocked" end

    local host = normalizeHost(string.match(url, "^https?://([^/%?#]+)"))
    if host == "" or host == "localhost" then return false, "url_blocked" end
    if host == "0.0.0.0" then return false, "url_blocked" end
    if string.match(host, "^127%.") or string.match(host, "^10%.") or string.match(host, "^192%.168%.") then
        return false, "url_blocked"
    end
    if string.match(host, "^172%.(1[6-9]|2%d|3[0-1])%.") then
        return false, "url_blocked"
    end

    if #C.AllowedImageHosts > 0 then
        local allowed = false
        for _, pattern in ipairs(C.AllowedImageHosts) do
            pattern = normalizeHost(pattern)
            if string.StartWith(pattern, "*.") then
                local suffix = string.sub(pattern, 2)
                if string.EndsWith(host, suffix) then
                    allowed = true
                    break
                end
            elseif host == pattern then
                allowed = true
                break
            end
        end
        if not allowed then return false, "url_blocked" end
    end

    return true, url
end

local function sanitizeImage(raw, out)
    out.sourceType = raw.sourceType == "photo" and "photo" or "url"
    out.fit = allowedImageFit[raw.fit] and raw.fit or "contain"
    out.border = raw.border == true
    out.borderWidth = math.floor(math.Clamp(finiteNumber(raw.borderWidth, 2), 0, 12))
    out.borderColor = T.SanitizeColor(raw.borderColor, {r = 25, g = 25, b = 25, a = 255})
    out.grayscale = raw.grayscale == true
    out.color = T.SanitizeColor(raw.color, {r = 255, g = 255, b = 255, a = 255})

    if out.sourceType == "photo" then
        out.photoID = T.TrimText(raw.photoID or "", 64)
    else
        local ok, clean = T.ValidateImageURL(raw.url or "")
        if not ok then return nil, clean end
        out.url = clean
    end

    return out
end

local function sanitizeShape(raw, out)
    out.shape = allowedShapes[raw.shape] and raw.shape or "rect"
    out.color = T.SanitizeColor(raw.color, {r = 220, g = 220, b = 220, a = 255})
    out.borderColor = T.SanitizeColor(raw.borderColor, {r = 20, g = 20, b = 20, a = 255})
    out.borderWidth = math.floor(math.Clamp(finiteNumber(raw.borderWidth, 2), 0, 12))
    return out
end

function T.SanitizeDesign(input)
    if not istable(input) then
        return nil, "invalid_format"
    end

    local out = {
        newspaperName = T.TrimText(input.newspaperName or "Newspaper", C.MaxNewspaperNameLength),
        elements = {}
    }

    if out.newspaperName == "" then
        out.newspaperName = "Newspaper"
    end

    if not istable(input.elements) then
        return nil, "missing_elements"
    end

    if #input.elements > C.MaxElements then
        return nil, "too_many_elements"
    end

    local imageCount = 0

    for i, raw in ipairs(input.elements) do
        if not istable(raw) then
            return nil, "invalid_format"
        end

        local kind = tostring(raw.kind or "text")
        if not allowedKinds[kind] then
            return nil, "invalid_format"
        end

        local x = math.Clamp(finiteNumber(raw.x, 0), 0, C.PageWidth - C.MinElementWidth)
        local y = math.Clamp(finiteNumber(raw.y, 0), 0, C.PageHeight - C.MinElementHeight)
        local w = math.Clamp(finiteNumber(raw.w, 220), C.MinElementWidth, C.PageWidth - x)
        local h = math.Clamp(finiteNumber(raw.h, 80), C.MinElementHeight, C.PageHeight - y)

        local item = {
            kind = kind,
            x = math.floor(x + 0.5),
            y = math.floor(y + 0.5),
            w = math.floor(w + 0.5),
            h = math.floor(h + 0.5)
        }

        if kind == "image" then
            imageCount = imageCount + 1
            if imageCount > C.MaxImages then
                return nil, "too_many_elements"
            end

            local ok, err = sanitizeImage(raw, item)
            if not ok then return nil, err end
        elseif kind == "shape" then
            sanitizeShape(raw, item)
        else
            local maxText = kind == "text" and C.MaxTextLength or C.MaxTitleLength
            item.text = T.TrimText(raw.text or "", maxText)
            item.fontSize = math.floor(math.Clamp(
                finiteNumber(raw.fontSize, kind == "title" and 34 or 18),
                C.MinFontSize,
                C.MaxFontSize
            ))
            item.align = allowedAlign[tostring(raw.align or "left")] and tostring(raw.align or "left") or "left"
            item.font = allowedFonts[tostring(raw.font or "sans")] and tostring(raw.font or "sans") or "sans"
            item.bold = raw.bold == true
            item.underline = raw.underline == true
            item.color = T.SanitizeColor(raw.color, {r = 25, g = 25, b = 25, a = 255})
        end

        out.elements[#out.elements + 1] = item
    end

    local json = util.TableToJSON(out, false)
    if not json or #json > C.MaxDesignBytes then
        return nil, "design_too_large"
    end

    return out
end

function T.CloneElement(data)
    return table.Copy(data)
end
