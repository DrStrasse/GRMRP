Typography = Typography or {}
local T = Typography
local C = T.Config

CreateClientConVar(
    "gtypography_camera_resolution",
    tostring(C.CameraPhotoWidth or 640) .. "x" .. tostring(C.CameraPhotoHeight or 480),
    true,
    false,
    "G-Typography camera photo resolution"
)

local resolutions = {
    {w = 320, h = 240},
    {w = 640, h = 360},
    {w = 640, h = 480},
    {w = 800, h = 600},
    {w = 1024, h = 576},
    {w = 1280, h = 720}
}

table.sort(resolutions, function(a, b)
    local areaA, areaB = a.w * a.h, b.w * b.h
    if areaA == areaB then return a.w < b.w end
    return areaA < areaB
end)

hook.Add("AddToolMenuCategories", "GTypography_AddUtilitiesCategory", function()
    spawnmenu.AddToolCategory("Utilities", "GTypography", "G-Typography")
end)

local function sendStorageClear(action)
    net.Start((T.Net and T.Net.StorageClear) or "typo_storage_clear")
        net.WriteUInt(action, 2)
    net.SendToServer()
end

local function addConfirmButton(panel, text, confirmation, action)
    local button = vgui.Create("DButton")
    button:SetTall(32)
    button:SetText(text)
    button.DoClick = function()
        Derma_Query(
            confirmation,
            T.L(nil, "memory_confirm_title"),
            T.L(nil, "delete"), function() sendStorageClear(action) end,
            T.L(nil, "cancel")
        )
    end
    panel:AddItem(button)
end

hook.Add("PopulateToolMenu", "GTypography_PopulateUtilities", function()
    spawnmenu.AddToolMenuOption(
        "Utilities",
        "GTypography",
        "GTypographyCameraSettings",
        T.L(nil, "camera_settings"),
        "",
        "",
        function(panel)
            panel:ClearControls()
            panel:Help(T.L(nil, "camera_settings"))

            local label = vgui.Create("DLabel")
            label:SetText(T.L(nil, "camera_resolution"))
            label:SetTextColor(Color(0, 0, 0))
            label:SizeToContents()
            panel:AddItem(label)

            local combo = vgui.Create("DComboBox")
            combo:SetTall(28)

            local cv = GetConVar("gtypography_camera_resolution")
            local current = cv and cv:GetString() or "640x480"
            combo:SetValue(current)

            for _, size in ipairs(resolutions) do
                local value = size.w .. "x" .. size.h
                combo:AddChoice(value, value, current == value)
            end

            combo.OnSelect = function(_, _, _, value)
                if value then RunConsoleCommand("gtypography_camera_resolution", value) end
            end
            panel:AddItem(combo)
            panel:Help(T.L(nil, "camera_resolution_help"))
        end
    )

    spawnmenu.AddToolMenuOption(
        "Utilities",
        "GTypography",
        "GTypographyMemory",
        T.L(nil, "memory_settings"),
        "",
        "",
        function(panel)
            panel:ClearControls()
            panel:Help(T.L(nil, "memory_help"))

            addConfirmButton(panel, T.L(nil, "memory_delete_photos"), T.L(nil, "memory_confirm_photos"), 1)
            addConfirmButton(panel, T.L(nil, "memory_delete_templates"), T.L(nil, "memory_confirm_templates"), 2)
            addConfirmButton(panel, T.L(nil, "memory_delete_all"), T.L(nil, "memory_confirm_all"), 3)
        end
    )
end)
