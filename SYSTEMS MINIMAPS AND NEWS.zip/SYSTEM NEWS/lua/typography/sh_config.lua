Typography = Typography or {}
Typography.Config = Typography.Config or {}

local C = Typography.Config

C.InteractDistance = 150
C.InkInsertDistance = 120
C.PrinterInkCapacity = 100
C.DefaultPrinterInk = 0
C.InkPerCartridge = 35
C.InkPerPrint = 8
C.LowInkThreshold = 20
C.PrintDuration = 4
C.PrintCooldown = 1.5

C.MaxWorldNewspapers = 40
C.NewspaperStandCapacity = 20
C.PrintCost = 0
C.SpawnMenuAdminOnly = false

C.PageWidth = 720
C.PageHeight = 1018
C.MaxElements = 64
C.MaxTextLength = 2500
C.MaxTitleLength = 180
C.MaxTemplateNameLength = 48
C.MaxNewspaperNameLength = 64
C.MaxTemplatesPerPlayer = 20
C.MinElementWidth = 24
C.MinElementHeight = 16
C.MinFontSize = 10
C.MaxFontSize = 72

C.AllowRemoteImages = true
C.MaxImages = 12
C.MaxImageURLLength = 512
C.AllowedImageHosts = {}
C.MaxEmbeddedPhotoBytes = 62000
C.MaxPhotosPerPlayer = 32
C.MaxPhotoTitleLength = 48
C.CameraPhotoWidth = 640
C.CameraPhotoHeight = 480
C.CameraMaxWidth = 1280
C.CameraMaxHeight = 720
C.CameraJPEGQuality = 45

C.MaxCompressedBytes = 61000
C.MaxDesignBytes = 59000
C.MaxPhotoBytes = 45000

C.EditorSessionLifetime = 600
C.NetRateDefault = 0.20
C.NetRatePrint = 1.0
C.NetRateSave = 0.7
C.NetRateDraft = 0.4
C.DraftSaveOnClose = true

C.AllowedTeams = {}

C.PrinterModel = "models/props_c17/consolebox01a.mdl"
C.InkModel = "models/props_lab/box01a.mdl"
C.NewspaperModel = "models/props_junk/garbage_newspaper001a.mdl"
C.NewspaperStandModel = "models/props_c17/display_cooler01a.mdl"

C.PrintSound = "ambient/levels/labs/equipment_printer_loop1.wav"
C.PrintSoundVolume = 0.8
C.PrintSoundPitch = 100
C.PrintSoundLevel = 70
