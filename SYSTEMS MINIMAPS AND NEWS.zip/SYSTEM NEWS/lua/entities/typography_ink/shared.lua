ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "#gtypography.ink"
ENT.Category = "G-Typography"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.DoNotDuplicate = true
