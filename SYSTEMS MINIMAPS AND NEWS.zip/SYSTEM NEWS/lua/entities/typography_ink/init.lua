AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel(Typography.Config.InkModel)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    self.NextUse = 0
    self.NextInsert = 0
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() or not activator:Alive() then return end
    if self.NextUse > CurTime() then return end
    self.NextUse = CurTime() + 0.25
    self:SetOwner(activator)
    activator:PickupObject(self)
end

function ENT:TryInsert(printer, ply)
    if not IsValid(printer) or printer:GetClass() ~= "typography_printer" then return end
    if self.NextInsert > CurTime() then return end
    self.NextInsert = CurTime() + 0.2

    local C = Typography.Config
    if printer:GetPrinting() then
        if IsValid(ply) then ply:ChatPrint("[G-Typography] " .. Typography.L(ply, "wait_print_end")) end
        return
    end
    if printer:GetInk() >= C.PrinterInkCapacity then
        if IsValid(ply) then ply:ChatPrint("[G-Typography] " .. Typography.L(ply, "printer_full_ink")) end
        return
    end

    local newAmount = math.min(C.PrinterInkCapacity, printer:GetInk() + C.InkPerCartridge)
    printer:SetInk(newAmount)
    if IsValid(ply) then
        ply:ChatPrint("[G-Typography] " .. Typography.L(ply, "inserted_ink", newAmount, C.PrinterInkCapacity))
    end
    self:Remove()
end

function ENT:PhysicsCollide(data)
    if not data or not IsValid(data.HitEntity) then return end
    if data.HitEntity:GetClass() ~= "typography_printer" then return end
    local owner = self:GetOwner()
    self:TryInsert(data.HitEntity, IsValid(owner) and owner or nil)
end
