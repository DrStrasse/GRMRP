ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "#gtypography.printer"
ENT.Category = "G-Typography"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.DoNotDuplicate = true

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "Ink")
    self:NetworkVar("Bool", 0, "Printing")
end
