AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    local C = Typography.Config
    self:SetModel(C.PrinterModel)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    self:SetInk(math.Clamp(C.DefaultPrinterInk, 0, C.PrinterInkCapacity))
    self:SetPrinting(false)
    self.NextPrintAllowed = 0
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    if not Typography or not Typography.OpenEditor then return end
    Typography.OpenEditor(activator, self)
end

function ENT:StartPrintLoop()
    local C = Typography.Config
    if not self.PrintLoop then
        self.PrintLoop = CreateSound(self, C.PrintSound)
    end
    if self.PrintLoop then
        self.PrintLoop:PlayEx(C.PrintSoundVolume or 0.8, C.PrintSoundPitch or 100)
    end
end

function ENT:StopPrintLoop()
    if self.PrintLoop then self.PrintLoop:Stop() end
end

function ENT:OnRemove()
    timer.Remove("TypographyPrint_" .. self:EntIndex())
    self:StopPrintLoop()

    local pendingID = math.floor(tonumber(self.PendingTypographyIssueID) or 0)
    if pendingID > 0 and Typography and Typography.ScheduleRuntimeIssueCleanup then
        Typography.ScheduleRuntimeIssueCleanup(pendingID)
    end
end
