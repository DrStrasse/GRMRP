include("shared.lua")

surface.CreateFont("TypographyPrinterTitle", {
    font = "Roboto",
    size = 30,
    weight = 900,
    antialias = true,
    extended = true
})

surface.CreateFont("TypographyPrinterStatus", {
    font = "Roboto",
    size = 18,
    weight = 700,
    antialias = true,
    extended = true
})

function ENT:Draw()
    self:DrawModel()
    local lp = LocalPlayer()
    if not IsValid(lp) or self:GetPos():DistToSqr(lp:GetPos()) > 500 * 500 then return end

    local C = Typography.Config
    local T = Typography
    local pos = self:GetPos() + self:GetUp() * (self:OBBMaxs().z + 12)

    local ang = (pos - EyePos()):GetNormalized():Angle()
    ang = Angle(0, ang.y, 0)
    ang:RotateAroundAxis(ang:Up(), -90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    local ink = self:GetInk()
    local statusKey
    if self:GetPrinting() then
        statusKey = "printer_printing"
    elseif ink <= 0 then
        statusKey = "printer_no_ink"
    elseif ink <= C.LowInkThreshold then
        statusKey = "printer_low_ink"
    else
        statusKey = "printer_ready"
    end

    cam.Start3D2D(pos, ang, 0.08)
        draw.RoundedBox(8, -120, -45, 240, 90, Color(245, 241, 226, 235))
        surface.SetDrawColor(30, 30, 30, 255)
        surface.DrawOutlinedRect(-120, -45, 240, 90, 2)
        draw.SimpleText(T.L(nil, "addon_name"), "TypographyPrinterTitle", 0, -28, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(T.L(nil, statusKey) .. "  •  " .. ink .. "/" .. C.PrinterInkCapacity, "TypographyPrinterStatus", 0, 12, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        local fraction = math.Clamp(ink / C.PrinterInkCapacity, 0, 1)
        draw.RoundedBox(2, -90, 28, 180, 8, Color(120, 120, 120, 120))
        draw.RoundedBox(2, -90, 28, 180 * fraction, 8, Color(20, 20, 20, 220))
    cam.End3D2D()
end
