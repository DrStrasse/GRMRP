include("shared.lua")

surface.CreateFont("GTypographyNewspaperFloat", {
    font = "Roboto",
    size = 24,
    weight = 800,
    antialias = true,
    extended = true
})

function ENT:Draw()
    self:DrawModel()

    local lp = LocalPlayer()
    if not IsValid(lp) or self:GetPos():DistToSqr(lp:GetPos()) > 450 * 450 then return end

    local name = self:GetNewspaperName()
    if not name or name == "" then return end

    local pos = self:GetPos() + self:GetUp() * (self:OBBMaxs().z + 10)
    local ang = (pos - EyePos()):GetNormalized():Angle()
    ang = Angle(0, ang.y, 0)
    ang:RotateAroundAxis(ang:Up(), -90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    cam.Start3D2D(pos, ang, 0.075)
        draw.SimpleTextOutlined(
            name,
            "GTypographyNewspaperFloat",
            0,
            0,
            Color(255, 255, 255),
            TEXT_ALIGN_CENTER,
            TEXT_ALIGN_CENTER,
            2,
            Color(0, 0, 0, 220)
        )
    cam.End3D2D()
end
