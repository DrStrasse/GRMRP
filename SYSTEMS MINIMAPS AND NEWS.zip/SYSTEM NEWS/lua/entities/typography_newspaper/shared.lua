ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "#gtypography.newspaper"
ENT.Category = "G-Typography"
ENT.Spawnable = false
ENT.AdminOnly = false
ENT.DoNotDuplicate = true

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "IssueID")
    self:NetworkVar("Int", 1, "IssueNumber")
    self:NetworkVar("String", 0, "NewspaperName")
end
