AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel(Typography.Config.NewspaperModel)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    if not Typography or not Typography.OpenIssue then return end
    Typography.OpenIssue(activator, self)
end

function ENT:OnRemove()
    local issueID = self:GetIssueID()
    if Typography and Typography.ScheduleRuntimeIssueCleanup then
        Typography.ScheduleRuntimeIssueCleanup(issueID)
    end
end
