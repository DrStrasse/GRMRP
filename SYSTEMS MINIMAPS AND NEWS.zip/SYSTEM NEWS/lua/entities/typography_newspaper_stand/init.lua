AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    local C = Typography.Config

    self:SetModel(C.NewspaperStandModel or "models/props_c17/display_cooler01a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    self.StoredIssues = {}
    self:SetStoredCount(0)
    self.NextUse = 0
    self.NextInsert = 0
end

function ENT:SyncCount()
    self:SetStoredCount(#(self.StoredIssues or {}))
end

function ENT:InsertNewspaper(paper)
    if not IsValid(paper) or paper:GetClass() ~= "typography_newspaper" then return false end
    if self.NextInsert > CurTime() then return false end

    local C = Typography.Config
    self.StoredIssues = self.StoredIssues or {}
    if #self.StoredIssues >= (C.NewspaperStandCapacity or 20) then return false end

    local issueID = math.floor(tonumber(paper:GetIssueID()) or 0)
    if issueID <= 0 or not Typography.LoadIssue(issueID) then return false end

    self.NextInsert = CurTime() + 0.15
    self.StoredIssues[#self.StoredIssues + 1] = issueID
    self:SyncCount()
    self:EmitSound("items/itempickup.wav", 60, 105, 0.6)
    paper:Remove()
    return true
end

function ENT:PhysicsCollide(data)
    if not data or not IsValid(data.HitEntity) then return end
    if data.HitEntity:GetClass() ~= "typography_newspaper" then return end
    self:InsertNewspaper(data.HitEntity)
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() or not activator:Alive() then return end
    if self.NextUse > CurTime() then return end
    self.NextUse = CurTime() + 0.35

    local C = Typography.Config
    if activator:GetPos():DistToSqr(self:GetPos()) > (C.InteractDistance * C.InteractDistance) then return end

    self.StoredIssues = self.StoredIssues or {}
    if #self.StoredIssues <= 0 then
        activator:ChatPrint("[G-Typography] " .. Typography.L(activator, "stand_empty"))
        return
    end

    local issueID = table.remove(self.StoredIssues, 1)
    self:SyncCount()

    local issue = Typography.LoadIssue(issueID)
    if not issue then
        activator:ChatPrint("[G-Typography] " .. Typography.L(activator, "stand_take_failed"))
        return
    end

    local paper = ents.Create("typography_newspaper")
    if not IsValid(paper) then
        table.insert(self.StoredIssues, 1, issueID)
        self:SyncCount()
        activator:ChatPrint("[G-Typography] " .. Typography.L(activator, "stand_take_failed"))
        return
    end

    paper:SetPos(self:GetPos() + self:GetForward() * 40 + self:GetUp() * 34)
    paper:SetAngles(Angle(0, activator:EyeAngles().y, 0))
    paper:Spawn()
    paper:Activate()
    paper:SetIssueID(issue.id)
    paper:SetIssueNumber(issue.issueNo)
    paper:SetNewspaperName(issue.newspaperName)
    self:EmitSound("items/ammocrate_open.wav", 60, 105, 0.45)

    timer.Simple(0, function()
        if IsValid(activator) and IsValid(paper) then
            activator:PickupObject(paper)
        end
    end)
end

function ENT:OnRemove()
    if not Typography or not Typography.ScheduleRuntimeIssueCleanup then return end
    for _, issueID in ipairs(self.StoredIssues or {}) do
        Typography.ScheduleRuntimeIssueCleanup(issueID)
    end
end
