include("shared.lua")

surface.CreateFont("GTypographyStandTitle", {
    font = "Roboto",
    size = 28,
    weight = 900,
    antialias = true,
    extended = true
})

surface.CreateFont("GTypographyStandCount", {
    font = "Roboto",
    size = 20,
    weight = 700,
    antialias = true,
    extended = true
})

function ENT:Draw()
    self:DrawModel()

    local lp = LocalPlayer()
    if not IsValid(lp) or self:GetPos():DistToSqr(lp:GetPos()) > 600 * 600 then return end

    local C = Typography.Config
    local pos = self:GetPos() + self:GetUp() * (self:OBBMaxs().z + 12)
    local ang = (pos - EyePos()):GetNormalized():Angle()
    ang = Angle(0, ang.y, 0)
    ang:RotateAroundAxis(ang:Up(), -90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    cam.Start3D2D(pos, ang, 0.08)
        draw.RoundedBox(8, -125, -42, 250, 84, Color(245, 241, 226, 235))
        surface.SetDrawColor(25, 25, 25, 255)
        surface.DrawOutlinedRect(-125, -42, 250, 84, 2)
        draw.SimpleText(Typography.L(nil, "stand_title"), "GTypographyStandTitle", 0, -18, Color(0, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(
            Typography.L(nil, "stand_count", self:GetStoredCount(), C.NewspaperStandCapacity or 20),
            "GTypographyStandCount",
            0,
            16,
            Color(0, 0, 0),
            TEXT_ALIGN_CENTER,
            TEXT_ALIGN_CENTER
        )
    cam.End3D2D()
end
