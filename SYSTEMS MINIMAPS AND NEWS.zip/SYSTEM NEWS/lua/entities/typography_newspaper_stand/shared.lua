ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "#gtypography.stand"
ENT.Category = "G-Typography"
ENT.Spawnable = true
ENT.AdminOnly = false
ENT.DoNotDuplicate = true

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "StoredCount")
end
