Typography = Typography or {}

if SERVER then
    AddCSLuaFile("typography/sh_config.lua")
    AddCSLuaFile("typography/sh_util.lua")
    AddCSLuaFile("typography/cl_ui.lua")
    AddCSLuaFile("typography/cl_spawnmenu.lua")
end

include("typography/sh_config.lua")
include("typography/sh_util.lua")

if SERVER then
    include("typography/sv_storage.lua")
    include("typography/sv_network.lua")
else
    include("typography/cl_ui.lua")
    include("typography/cl_spawnmenu.lua")
end
