if SERVER then
    AddCSLuaFile("cl_init.lua")
    AddCSLuaFile("shared.lua")
end

SWEP.PrintName = "#gtypography.camera"
SWEP.Author = ""
SWEP.Instructions = "#gtypography.camera.instructions"
SWEP.Category = "G-Typography"
SWEP.Spawnable = true
SWEP.AdminOnly = false

SWEP.UseHands = false
SWEP.ViewModel = "models/weapons/c_arms_animations.mdl"
SWEP.WorldModel = Model("models/MaxOfS2D/camera.mdl")
SWEP.ViewModelFOV = 62

SWEP.Primary = {
    ClipSize = -1,
    DefaultClip = -1,
    Automatic = false,
    Ammo = "none"
}

SWEP.Secondary = {
    ClipSize = -1,
    DefaultClip = -1,
    Automatic = true,
    Ammo = "none"
}

SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false
SWEP.ShootSound = Sound("NPC_CScanner.TakePhoto")

function SWEP:SetupDataTables()
    self:NetworkVar("Float", 0, "Zoom")
end

function SWEP:Initialize()
    self:SetHoldType("camera")
    if SERVER and self:GetZoom() <= 0 then
        self:SetZoom(75)
    end
end

function SWEP:Deploy()
    local owner = self:GetOwner()
    if SERVER and IsValid(owner) and owner:IsPlayer() and self:GetZoom() <= 0 then
        self:SetZoom(owner:IsBot() and 75 or owner:GetInfoNum("fov_desired", 75))
    end
    return true
end

function SWEP:Equip(owner)
    if SERVER and IsValid(owner) and owner:IsPlayer() and self:GetZoom() <= 0 then
        self:SetZoom(owner:IsBot() and 75 or owner:GetInfoNum("fov_desired", 75))
    end
end

function SWEP:PrimaryAttack()
    self:SetNextPrimaryFire(CurTime() + 0.8)

    if SERVER then
        local owner = self:GetOwner()
        if IsValid(owner) and owner:IsPlayer() and Typography and Typography.Net and Typography.Net.CameraCapture then
            net.Start(Typography.Net.CameraCapture)
            net.Send(owner)
        end
        self:EmitSound(self.ShootSound, 65, 100, 0.7)
    end
end

function SWEP:SecondaryAttack()
end

function SWEP:Tick()
    local owner = self:GetOwner()
    if not IsValid(owner) or not owner:IsPlayer() then return end
    if CLIENT and owner ~= LocalPlayer() then return end

    local cmd = owner:GetCurrentCommand()
    if not cmd or not cmd:KeyDown(IN_ATTACK2) then return end

    local current = self:GetZoom()
    if current <= 0 then current = owner:IsBot() and 75 or owner:GetInfoNum("fov_desired", 75) end
    self:SetZoom(math.Clamp(current + cmd:GetMouseY() * FrameTime() * 6.6, 0.1, 175))
end

function SWEP:Reload()
    local owner = self:GetOwner()
    if not IsValid(owner) or not owner:IsPlayer() then return end
    self:SetZoom(owner:IsBot() and 75 or owner:GetInfoNum("fov_desired", 75))
end

function SWEP:TranslateFOV(currentFOV)
    local zoom = self:GetZoom()
    if zoom <= 0 then return currentFOV end
    return zoom
end

function SWEP:CalcView(ply, origin, angles, fov)
    return origin, angles, fov
end

function SWEP:AdjustMouseSensitivity()
    local zoom = self:GetZoom()
    if zoom <= 0 then return nil end
    return zoom / 80
end

function SWEP:ShouldDropOnDie()
    return false
end

function SWEP:DrawWorldModel()
    self:DrawModel()
end
