include("shared.lua")

local T = Typography
local C = Typography.Config

local function notify(text, kind)
    notification.AddLegacy(text, kind == 1 and NOTIFY_ERROR or NOTIFY_GENERIC, 4)
    surface.PlaySound(kind == 1 and "buttons/button10.wav" or "buttons/button15.wav")
end

local capturePending = false
local namingDialogOpen = false

local function uploadCapturedPhoto(data, captureW, captureH)
    if not data or data == "" then
        notify(T.L(nil, "camera_failed"), 1)
        return
    end

    if #data > (C.MaxPhotoBytes or 45000) then
        notify(T.L(nil, "camera_failed"), 1)
        return
    end

    if namingDialogOpen then return end
    namingDialogOpen = true

    local titleDefault = T.L(nil, "photo_default_title") .. " " .. os.date("%H:%M:%S")
    local dialog = Derma_StringRequest(
        T.L(nil, "photo_title"),
        T.L(nil, "photo_title_prompt"),
        titleDefault,
        function(title)
            namingDialogOpen = false
            net.Start(T.Net.PhotoUpload)
                net.WriteString(title ~= "" and title or titleDefault)
                net.WriteString("image/jpeg")
                net.WriteUInt(math.Clamp(math.floor(captureW or C.CameraPhotoWidth or 640), 1, 65535), 16)
                net.WriteUInt(math.Clamp(math.floor(captureH or C.CameraPhotoHeight or 480), 1, 65535), 16)
                net.WriteUInt(#data, 16)
                net.WriteData(data, #data)
            net.SendToServer()
        end,
        function()
            namingDialogOpen = false
        end
    )

    if IsValid(dialog) then
        dialog.OnRemove = function()
            namingDialogOpen = false
        end
    else
        namingDialogOpen = false
        notify(T.L(nil, "camera_failed"), 1)
    end
end

function SWEP:RequestTypographyCapture()
    capturePending = true
end

net.Receive("typo_camera_capture", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "weapon_typography_camera" then return end
    capturePending = true
end)

hook.Add("PostRender", "TypographyCameraCapture", function()
    if not capturePending or namingDialogOpen then return end

    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "weapon_typography_camera" then
        capturePending = false
        return
    end

    capturePending = false

    local requestedW = C.CameraPhotoWidth or 640
    local requestedH = C.CameraPhotoHeight or 480
    local resolutionCVar = GetConVar("gtypography_camera_resolution")
    if resolutionCVar then
        local rw, rh = string.match(resolutionCVar:GetString(), "^(%d+)x(%d+)$")
        rw, rh = tonumber(rw), tonumber(rh)
        if rw and rh then
            requestedW = math.Clamp(math.floor(rw), 160, C.CameraMaxWidth or 1280)
            requestedH = math.Clamp(math.floor(rh), 120, C.CameraMaxHeight or 720)
        end
    end

    local captureW = math.min(requestedW, ScrW())
    local captureH = math.min(requestedH, ScrH())
    local captureX = math.max(0, math.floor((ScrW() - captureW) / 2))
    local captureY = math.max(0, math.floor((ScrH() - captureH) / 2))

    local data
    local maxBytes = C.MaxPhotoBytes or 45000
    local qualities = {C.CameraJPEGQuality or 45, 35, 25, 15, 8, 5, 3, 1}

    for _, quality in ipairs(qualities) do
        data = render.Capture({
            format = "jpeg",
            quality = math.Clamp(quality, 1, 100),
            x = captureX,
            y = captureY,
            w = captureW,
            h = captureH
        })

        if data and data ~= "" and #data <= maxBytes then
            break
        end
    end

    timer.Simple(0, function()
        uploadCapturedPhoto(data, captureW, captureH)
    end)
end)

function SWEP:DrawHUD()
    if capturePending then return end

    local zoom = self:GetZoom()
    if zoom <= 0 then zoom = 75 end

    local cx, cy = ScrW() * 0.5, ScrH() * 0.5
    surface.SetDrawColor(255, 255, 255, 180)
    surface.DrawLine(cx - 8, cy, cx + 8, cy)
    surface.DrawLine(cx, cy - 8, cx, cy + 8)

    draw.SimpleText(
        string.format("FOV %.1f", zoom),
        "DermaDefaultBold",
        cx,
        ScrH() - 70,
        Color(255, 255, 255, 220),
        TEXT_ALIGN_CENTER,
        TEXT_ALIGN_CENTER
    )
end

function SWEP:HUDShouldDraw(name)
    if name == "CHudWeaponSelection" or name == "CHudChat" then return true end
    return false
end

function SWEP:FreezeMovement()
    local owner = self:GetOwner()
    if not IsValid(owner) then return false end
    return owner:KeyDown(IN_ATTACK2) or owner:KeyReleased(IN_ATTACK2)
end

function SWEP:PreDrawViewModel()
    return true
end
