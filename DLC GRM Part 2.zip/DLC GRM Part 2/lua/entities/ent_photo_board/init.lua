-- lua/entities/ent_photo_board/init.lua

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_c17/Frame002a.mdl")
    local ang = self:GetAngles()
    ang:RotateAroundAxis(ang:Forward(), 90)
    self:SetAngles(ang)

    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:SetModelScale(2, 0)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(100)
    end

    self.AttachedPhotos = {}
    self.Strings = {}
    self.Texts = {}
    self:SetPhotoCount(0)
    self:SetInteractionMode(false)
    self:SetZoneScale(PhotoCamera.Settings.BoardZoneDefaultScale)
    self:SetDisplayMode(0)

    -- Увеличиваем trigger зону для Use
    self:SetTrigger(true)
    self:UseTriggerBounds(true, 4)
end

function ENT:Use(activator, caller)
    if not IsValid(caller) or not caller:IsPlayer() then return end

    local maxDist = PhotoCamera.Settings.BoardInteractDistance * self:GetZoneScale()
    local dist = caller:GetPos():Distance(self:GetPos())
    if dist > maxDist then return end

    -- Если игрок несёт фото через +use — не открываем UI
    local heldEnt = caller:GetEyeTrace().Entity
    if IsValid(heldEnt) and heldEnt:GetClass() == "ent_photo"
        and heldEnt:GetPos():Distance(caller:GetShootPos()) < 80 then
        return
    end

    -- Отправляем открытие UI
    local data = self:SerializeBoardState()
    net.Start("PhotoCam_BoardOpenUI")
        net.WriteEntity(self)
        net.WriteUInt(#data, 32)
        net.WriteData(data, #data)
    net.Send(caller)
end

function ENT:SetBoardZoneScale(scale)
    scale = math.Clamp(scale, PhotoCamera.Settings.BoardZoneMinScale, PhotoCamera.Settings.BoardZoneMaxScale)
    self:SetZoneScale(scale)
end

function ENT:CycleDisplayMode()
    local current = self:GetDisplayMode() or 0
    local next = (current + 1) % 3
    self:SetDisplayMode(next)
end

function ENT:SetBoardDisplayMode(mode)
    self:SetDisplayMode(math.Clamp(mode, 0, 2))
end

function ENT:AttachPhoto(photoEnt, u, v, scale)
    if not IsValid(photoEnt) then return end
    local photoID = photoEnt:GetPhotoID()
    if not photoID or photoID == "" then return end
    scale = scale or PhotoCamera.Settings.PhotoDefaultScale

    self.AttachedPhotos[photoID] = {
        entity = photoEnt, u = u, v = v, scale = scale,
    }

    photoEnt:SetOnBoard(true)
    photoEnt:SetBoardU(u)
    photoEnt:SetBoardV(v)
    photoEnt:SetParent(self)

    local phys = photoEnt:GetPhysicsObject()
    if IsValid(phys) then phys:EnableMotion(false) end
    photoEnt:SetMoveType(MOVETYPE_NONE)
    photoEnt:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    photoEnt:SetSolid(SOLID_NONE)

    self:RepositionPhoto(photoID)
    self:SetPhotoCount(table.Count(self.AttachedPhotos))
end

function ENT:DetachPhoto(photoID)
    local data = self.AttachedPhotos[photoID]
    if not data then return end

    local photoEnt = data.entity
    if IsValid(photoEnt) then
        photoEnt:SetOnBoard(false)
        photoEnt:SetParent(nil)
        photoEnt:SetMoveType(MOVETYPE_VPHYSICS)
        photoEnt:SetCollisionGroup(COLLISION_GROUP_NONE)
        photoEnt:SetSolid(SOLID_VPHYSICS)

        local boardAng = self:GetAngles()
        local ejectDir = boardAng:Forward() * 60 + Vector(0, 0, 30)
        local ejectPos = self:GetPos() + boardAng:Forward() * 20

        photoEnt:SetPos(ejectPos)

        local phys = photoEnt:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(true)
            phys:Wake()
            phys:SetVelocity(ejectDir)
        end

        photoEnt.JustDetached = CurTime()
    end

    self.AttachedPhotos[photoID] = nil
    for i = #self.Strings, 1, -1 do
        local s = self.Strings[i]
        if s[1] == photoID or s[2] == photoID then table.remove(self.Strings, i) end
    end
    self:SetPhotoCount(table.Count(self.AttachedPhotos))
end
function ENT:DeletePhoto(photoID)
    local data = self.AttachedPhotos[photoID]
    if not data then return end
    if IsValid(data.entity) then data.entity:Remove() end
    self.AttachedPhotos[photoID] = nil
    for i = #self.Strings, 1, -1 do
        local s = self.Strings[i]
        if s[1] == photoID or s[2] == photoID then table.remove(self.Strings, i) end
    end
    self:SetPhotoCount(table.Count(self.AttachedPhotos))
end

function ENT:MovePhotoOnBoard(photoID, u, v)
    local data = self.AttachedPhotos[photoID]
    if not data then return end
    data.u = math.Clamp(u, 0.02, 0.98)
    data.v = math.Clamp(v, 0.02, 0.98)
    if IsValid(data.entity) then
        data.entity:SetBoardU(data.u)
        data.entity:SetBoardV(data.v)
    end
    self:RepositionPhoto(photoID)
end

function ENT:ResizePhoto(photoID, scale)
    local data = self.AttachedPhotos[photoID]
    if not data then return end
    data.scale = math.Clamp(scale, PhotoCamera.Settings.PhotoMinScale, PhotoCamera.Settings.PhotoMaxScale)
    self:RepositionPhoto(photoID)
end

function ENT:RepositionPhoto(photoID)
    local data = self.AttachedPhotos[photoID]
    if not data or not IsValid(data.entity) then return end

    local settings = PhotoCamera.Settings
    local zoneScale = self:GetZoneScale()
    local ang = self:GetAngles()
    local fwd = ang:Forward()
    local right = ang:Right()
    local up = ang:Up()

    local halfW = (settings.BoardWidth * zoneScale) / 2
    local halfH = (settings.BoardHeight * zoneScale) / 2

    local offsetRight = (data.u - 0.5) * halfW * 2
    local offsetUp = (data.v - 0.5) * halfH * 2
    local worldPos = self:GetPos()

    data.entity:SetPos(worldPos)
    data.entity:SetAngles(ang)
end

function ENT:AddString(fromPhotoID, toPhotoID)
    if fromPhotoID == toPhotoID then return end
    if not self.AttachedPhotos[fromPhotoID] then return end
    if not self.AttachedPhotos[toPhotoID] then return end
    for _, s in ipairs(self.Strings) do
        if (s[1] == fromPhotoID and s[2] == toPhotoID) or
           (s[1] == toPhotoID and s[2] == fromPhotoID) then return end
    end
    table.insert(self.Strings, { fromPhotoID, toPhotoID })
end

function ENT:RemoveString(index)
    if self.Strings[index] then table.remove(self.Strings, index) end
end

function ENT:AddText(text, u, v, colorTbl, scale)
    if #self.Texts >= PhotoCamera.Settings.MaxTextsPerBoard then return end
    text = string.sub(text, 1, PhotoCamera.Settings.TextMaxLength)
    colorTbl = colorTbl or PhotoCamera.Settings.TextDefaultColor
    scale = scale or PhotoCamera.Settings.TextDefaultScale
    table.insert(self.Texts, {
        text = text,
        u = math.Clamp(u, 0.05, 0.95),
        v = math.Clamp(v, 0.05, 0.95),
        color = { colorTbl.r, colorTbl.g, colorTbl.b, colorTbl.a or 255 },
        scale = scale,
    })
end

function ENT:RemoveText(index)
    if self.Texts[index] then table.remove(self.Texts, index) end
end

function ENT:MoveText(index, u, v)
    if not self.Texts[index] then return end
    self.Texts[index].u = math.Clamp(u, 0.05, 0.95)
    self.Texts[index].v = math.Clamp(v, 0.05, 0.95)
end

function ENT:EditText(index, newText)
    if not self.Texts[index] then return end
    self.Texts[index].text = string.sub(newText, 1, PhotoCamera.Settings.TextMaxLength)
end

function ENT:ResizeText(index, scale)
    if not self.Texts[index] then return end
    self.Texts[index].scale = math.Clamp(scale, PhotoCamera.Settings.TextMinScale, PhotoCamera.Settings.TextMaxScale)
end

function ENT:GetAttachedPhotos()
    local result = {}
    for id, data in pairs(self.AttachedPhotos) do
        table.insert(result, { id = id, u = data.u, v = data.v, scale = data.scale or 1, entity = data.entity })
    end
    return result
end

function ENT:GetStrings() return self.Strings or {} end

function ENT:SerializeBoardState()
    local state = {
        photos = {},
        strings = self.Strings or {},
        texts = self.Texts or {},
        zoneScale = self:GetZoneScale(),
        displayMode = self:GetDisplayMode(),
    }
    for photoID, data in pairs(self.AttachedPhotos) do
        table.insert(state.photos, {
            id = photoID, u = data.u, v = data.v,
            scale = data.scale or 1,
            entIndex = IsValid(data.entity) and data.entity:EntIndex() or -1,
        })
    end
    return util.Compress(util.TableToJSON(state))
end

function ENT:OnRemove()
    for _, data in pairs(self.AttachedPhotos) do
        if IsValid(data.entity) then
            data.entity:SetOnBoard(false)
            data.entity:SetParent(nil)
            data.entity:SetMoveType(MOVETYPE_VPHYSICS)
            data.entity:SetCollisionGroup(COLLISION_GROUP_NONE)
            data.entity:SetSolid(SOLID_VPHYSICS)
            local phys = data.entity:GetPhysicsObject()
            if IsValid(phys) then phys:EnableMotion(true); phys:Wake() end
        end
    end
end

function ENT:Think()
    for photoID, _ in pairs(self.AttachedPhotos) do
        self:RepositionPhoto(photoID)
    end
    self:NextThink(CurTime() + 0.5)
    return true
end
function ENT:StartTouch(ent)
    if not IsValid(ent) then return end
    if ent:GetClass() ~= "ent_photo" then return end
    if ent:GetOnBoard() then return end

    if table.Count(self.AttachedPhotos) >= PhotoCamera.Settings.MaxBoardPhotos then return end

    -- Защита от обратного прикрепления после извлечения
    if ent.JustDetached and CurTime() - ent.JustDetached < 3 then return end

    -- Если игрок держит — не прикрепляем
    if ent.IsPlayerHolding and ent:IsPlayerHolding() then return end

    if ent.PendingAttach then return end
    ent.PendingAttach = true

    local board = self
    timer.Simple(0.4, function()
        if not IsValid(board) or not IsValid(ent) then return end
        if ent:GetOnBoard() then return end
        ent.PendingAttach = nil

        if ent.JustDetached and CurTime() - ent.JustDetached < 3 then return end

        -- Главная проверка: если игрок держит — не прикрепляем
        if ent.IsPlayerHolding and ent:IsPlayerHolding() then return end

        local phys = ent:GetPhysicsObject()
        if IsValid(phys) and phys:GetVelocity():Length() > 150 then return end

        if table.Count(board.AttachedPhotos) >= PhotoCamera.Settings.MaxBoardPhotos then return end

        board:AttachPhoto(ent, 0.5, 0.5, PhotoCamera.Settings.PhotoDefaultScale)
        PhotoCamera.Server.SyncBoard(board)
    end)
end