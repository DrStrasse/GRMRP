-- lua/entities/ent_photo_board/shared.lua

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Investigation Board"
ENT.Author = "puddingheh"
ENT.Category = "Investigation system"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "PhotoCount")
    self:NetworkVar("Bool", 0, "InteractionMode")
    self:NetworkVar("Float", 0, "ZoneScale")
    self:NetworkVar("Int", 1, "DisplayMode")
end