-- lua/entities/ent_photo_board/cl_init.lua

include("shared.lua")

ENT.BoardState = nil

function ENT:Initialize()
    self.BoardState = {
        photos = {},
        strings = {},
        texts = {},
        zoneScale = 1,
        modelHidden = false,
    }

    timer.Simple(1, function()
        if IsValid(self) then
            net.Start("PhotoCam_BoardSyncRequest")
                net.WriteEntity(self)
            net.SendToServer()
        end
    end)
end

local scaledFonts3D = {}
local function GetScaledFont3D(scale)
    local key = math.Round(scale * 10)
    if not scaledFonts3D[key] then
        local fontSize = math.max(8, math.Round(14 * scale))
        local fontName = "PhotoCam3D_" .. key
        surface.CreateFont(fontName, {
            font = "Arial",
            size = fontSize,
            weight = 700,
            antialias = true,
        })
        scaledFonts3D[key] = fontName
    end
    return scaledFonts3D[key]
end
local function DrawCircle3D(x, y, radius, color, segments)
    segments = segments or 24
    local circle = {}
    for i = 0, segments do
        local a = math.rad((i / segments) * 360)
        table.insert(circle, {
            x = x + math.cos(a) * radius,
            y = y + math.sin(a) * radius,
        })
    end
    draw.NoTexture()
    surface.SetDrawColor(color)
    surface.DrawPoly(circle)
end
local function DrawSmoothLine(points, thickness, color)
    if #points < 2 then return end

    draw.NoTexture()
    surface.SetDrawColor(color)

    local half = thickness / 2
    local side1 = {}
    local side2 = {}

    for i = 1, #points do
        local dx, dy

        if i == 1 then
            dx = points[2].x - points[1].x
            dy = points[2].y - points[1].y
        elseif i == #points then
            dx = points[#points].x - points[#points - 1].x
            dy = points[#points].y - points[#points - 1].y
        else
            dx = points[i + 1].x - points[i - 1].x
            dy = points[i + 1].y - points[i - 1].y
        end

        local len = math.sqrt(dx * dx + dy * dy)
        if len < 0.001 then dx, dy, len = 1, 0, 1 end

        local nx = -dy / len * half
        local ny =  dx / len * half

        side1[i] = { x = points[i].x + nx, y = points[i].y + ny }
        side2[i] = { x = points[i].x - nx, y = points[i].y - ny }
    end

    for i = 1, #points - 1 do
        surface.DrawPoly({
            side1[i],
            side2[i],
            side2[i + 1],
            side1[i + 1],
        })
    end
end
function ENT:Draw()
    local displayMode = self:GetDisplayMode() or 0

    local showModel = (displayMode ~= 2)
    local showZone = (displayMode == 0)

    if showModel then
        self:DrawModel()
    end

    local pos = self:GetPos()
    local ang = self:GetAngles()
    local settings = PhotoCamera.Settings
    local zoneScale = self:GetZoneScale()
    if zoneScale <= 0 then zoneScale = 1 end

    local fwd = ang:Forward()
    local right = ang:Right()
    local up = ang:Up()

    -- Строим углы для 3D2D так, чтобы:
    -- Ось X на плоскости 3D2D = right энтити (горизонталь доски)
    -- Ось Y на плоскости 3D2D = -forward энтити (вертикаль доски, вниз)
    -- Нормаль плоскости = -up энтити (смотрит от доски к игроку)

    local drawAng = (-up):Angle()
    -- Корректируем roll чтобы X 3D2D совпадал с right
    local currentRight = drawAng:Right()
    local dotR = currentRight:Dot(right)
    local crossR = currentRight:Cross(right):Dot(-up)
    local rollCorrection = math.deg(math.atan2(crossR, dotR))
    drawAng:RotateAroundAxis(-up, rollCorrection)

    local drawPos = pos

    local scale3D2D = 0.12 * zoneScale
    local boardPixelW = settings.BoardWidth / 0.12
    local boardPixelH = settings.BoardHeight / 0.12

    local basePhotoSize = 50
    local borderW = 4
    local pinR = 4

    -- Определяем направление осей 3D2D после коррекции
    -- После коррекции: 3D2D X = right, 3D2D Y = вниз по доске
    -- В UI: u=0 слева, u=1 справа → X = (u-0.5)*W → положительный X = правее
    -- Нужно проверить совпадает ли 3D2D X с "правее" на доске
    -- 
    -- drawAng:Right() после коррекции должен = right энтити
    -- Значит положительный X в 3D2D = right, что соответствует u растущему вправо
    --
    -- drawAng:Up() (отрицательный = вниз по 3D2D Y) — нужно чтобы совпадал с fwd
    -- Тогда положительный Y в 3D2D = вниз = -fwd
    -- v=1 вверху доски, (1-v) маленькое = вверху → py = -(v-0.5)*H → v=1 → py отрицательный = вверх
    -- Это соответствует: вверх = -Y = fwd. Верно.

    cam.Start3D2D(drawPos, drawAng, scale3D2D)

        if showZone then
            surface.SetDrawColor(160, 120, 80, 30)
            surface.DrawRect(-boardPixelW / 2, -boardPixelH / 2, boardPixelW, boardPixelH)

            surface.SetDrawColor(100, 70, 40, 80)
            surface.DrawOutlinedRect(-boardPixelW / 2, -boardPixelH / 2, boardPixelW, boardPixelH, 2)

            draw.SimpleText("INVESTIGATION BOARD", "DermaDefaultBold",
                0, -boardPixelH / 2 - 15,
                Color(60, 40, 20, 200),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end

        local function GetPhotoPixelPos(photoData)
            local px = (photoData.u - 0.5) * boardPixelW
            local py = -(photoData.v - 0.5) * boardPixelH
            return px, py
        end

        local function GetPhotoSizeScaled(photoData)
            return (photoData.scale or 1) * basePhotoSize
        end

        local function GetPinPos(photoData)
            local px, py = GetPhotoPixelPos(photoData)
            local s = GetPhotoSizeScaled(photoData)
            return px, py - s / 2 - borderW
        end

        -- Strings
        if self.BoardState and self.BoardState.strings then
            for _, str in ipairs(self.BoardState.strings) do
                local fromData = self:FindPhotoInState(str[1])
                local toData = self:FindPhotoInState(str[2])

                if fromData and toData then
                    local fromX, fromY = GetPinPos(fromData)
                    local toX, toY = GetPinPos(toData)
                    local segments = 30
                    local points = {}
                    for i = 0, segments do
                        local frac = i / segments
                        local cx = Lerp(frac, fromX, toX)
                        local cy = Lerp(frac, fromY, toY)
                        cy = cy + math.sin(frac * math.pi) * 12
                        table.insert(points, { x = cx, y = cy })
                    end

                    DrawSmoothLine(points, 3, settings.StringColor)
                end
            end
        end

        -- Photos
        if self.BoardState and self.BoardState.photos then
            for _, photoData in ipairs(self.BoardState.photos) do
                local px, py = GetPhotoPixelPos(photoData)
                local photoSize = GetPhotoSizeScaled(photoData)

                surface.SetDrawColor(0, 0, 0, 60)
                surface.DrawRect(px - photoSize / 2 + 2, py - photoSize / 2 + 2,
                    photoSize + borderW * 2, photoSize + borderW * 2 + 8)

                surface.SetDrawColor(settings.PhotoBorderColor)
                surface.DrawRect(px - photoSize / 2 - borderW, py - photoSize / 2 - borderW,
                    photoSize + borderW * 2, photoSize + borderW * 2 + 8)

                local mat = PhotoCamera.Capture and PhotoCamera.Capture.GetMaterial(photoData.id)
                if mat and not mat:IsError() then
                    surface.SetDrawColor(255, 255, 255, 255)
                    surface.SetMaterial(mat)
                    surface.DrawTexturedRect(px - photoSize / 2, py - photoSize / 2, photoSize, photoSize)
                else
                    surface.SetDrawColor(120, 120, 120, 255)
                    surface.DrawRect(px - photoSize / 2, py - photoSize / 2, photoSize, photoSize)
                end

                local pinX, pinY = GetPinPos(photoData)
                DrawCircle3D(pinX, pinY, pinR, settings.PinColor)
            end
        end

        -- Texts
        if self.BoardState and self.BoardState.texts then
            for _, textData in ipairs(self.BoardState.texts) do
                local tx = (textData.u - 0.5) * boardPixelW
                local ty = -(textData.v - 0.5) * boardPixelH
                local textScale = textData.scale or 1
                local fontName = GetScaledFont3D(textScale)

                local textColor = Color(
                    textData.color and textData.color[1] or 30,
                    textData.color and textData.color[2] or 30,
                    textData.color and textData.color[3] or 30, 255)

                draw.SimpleText(textData.text or "", fontName,
                    tx + 1, ty + 1, Color(0, 0, 0, 60),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                draw.SimpleText(textData.text or "", fontName,
                    tx, ty, textColor,
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end

    cam.End3D2D()
end

function ENT:FindPhotoInState(photoID)
    if not self.BoardState or not self.BoardState.photos then return nil end
    for _, p in ipairs(self.BoardState.photos) do
        if p.id == photoID then return p end
    end
    return nil
end

function ENT:Think()
end