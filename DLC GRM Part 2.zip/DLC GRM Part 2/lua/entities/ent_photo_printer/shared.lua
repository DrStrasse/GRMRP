-- lua/entities/ent_photo_printer/shared.lua

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Photo Printer"
ENT.Author = "puddingheh"
ENT.Category = "Investigation system"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "ImageURL")
    self:NetworkVar("String", 1, "ImageID")
    self:NetworkVar("Bool", 0, "HasImage")
end