-- lua/entities/ent_photo_printer/cl_init.lua

include("shared.lua")

function ENT:Initialize()
    self.PrinterMaterial = nil
    self.LastImageID = ""
    self.LoadingHTTP = false
    self.HTTPMaterials = PhotoCamera.PrinterMaterials or {}
end

function ENT:Think()
    local imageID = self:GetImageID()
    if imageID ~= self.LastImageID then
        self.LastImageID = imageID
        if imageID ~= "" then
            self.PrinterMaterial = PhotoCamera.Printer.GetMaterial(imageID)

            if not self.PrinterMaterial and PhotoCamera.Capture and PhotoCamera.Capture.GetMaterial then
                self.PrinterMaterial = PhotoCamera.Capture.GetMaterial(imageID)
            end

            if not self.PrinterMaterial then
                timer.Create("PrinterRetry_" .. self:EntIndex(), 1, 10, function()
                    if not IsValid(self) then return end
                    local id = self:GetImageID()
                    self.PrinterMaterial = PhotoCamera.Printer.GetMaterial(id)
                    if not self.PrinterMaterial and PhotoCamera.Capture and PhotoCamera.Capture.GetMaterial then
                        self.PrinterMaterial = PhotoCamera.Capture.GetMaterial(id)
                    end
                    if self.PrinterMaterial then
                        timer.Remove("PrinterRetry_" .. self:EntIndex())
                    end
                end)
            end
        else
            self.PrinterMaterial = nil
        end
    end
end

function ENT:Draw()
    self:DrawModel()
end