-- lua/entities/ent_photo_printer/init.lua

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_lab/monitor02.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(50)
    end

    self:SetHasImage(false)
    self:SetImageURL("")
    self:SetImageID("")
end

function ENT:Use(activator, caller)
    if not IsValid(caller) or not caller:IsPlayer() then return end

    local dist = caller:GetPos():Distance(self:GetPos())
    if dist > 150 then return end

    -- Открыть UI на клиенте
    net.Start("PhotoCam_PrinterSetURL")
        net.WriteEntity(self)
        net.WriteString(self:GetImageURL())
        net.WriteBool(false) -- это запрос на открытие UI, не сабмит
    net.Send(caller)
end

function ENT:SetPrinterImage(url, imageID)
    self:SetImageURL(url)
    self:SetImageID(imageID)
    self:SetHasImage(true)
end

function ENT:ClearImage()
    self:SetImageURL("")
    self:SetImageID("")
    self:SetHasImage(false)
end