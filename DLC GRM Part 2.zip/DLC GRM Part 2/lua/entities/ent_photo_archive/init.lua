-- lua/entities/ent_photo_archive/init.lua

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/props_c17/BriefCase001a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(30)
    end

    -- Хранилище: таблица { [index] = { id = photoID, photographer = steamID, time = CurTime() } }
    self.StoredPhotos = {}
    -- Хранилище сжатых данных фото для раздачи
    self.PhotoDataCache = {}
    self:SetStoredCount(0)
    self:SetTrigger(true)
    self:UseTriggerBounds(true, 2)

    -- Флаг для подавления дропа при подборе как чемодан
    self.SuppressDropOnRemove = false
end

function ENT:Use(activator, caller)
    if not IsValid(caller) or not caller:IsPlayer() then return end

    local dist = caller:GetPos():Distance(self:GetPos())
    if dist > PhotoCamera.Settings.ArchiveInteractDistance then return end

    -- Если игрок несёт фото через +use — не открываем UI
    local heldEnt = caller:GetEyeTrace().Entity
    if IsValid(heldEnt) and heldEnt:GetClass() == "ent_photo"
        and heldEnt:GetPos():Distance(caller:GetShootPos()) < 80 then
        return
    end

    -- Открыть UI со списком фото
    self:OpenArchiveUI(caller)
end

function ENT:StorePhoto(ply, photoEnt)
    if not IsValid(photoEnt) then return end

    local photoID = photoEnt:GetPhotoID()
    if not photoID or photoID == "" then
        ply:ChatPrint("Invalid photo!")
        return
    end

    if #self.StoredPhotos >= PhotoCamera.Settings.ArchiveMaxPhotos then
        ply:ChatPrint("Archive is full! (" .. PhotoCamera.Settings.ArchiveMaxPhotos .. " max)")
        return
    end

    -- Проверяем что фото не на доске
    if photoEnt:GetOnBoard() then
        ply:ChatPrint("Detach photo from board first!")
        return
    end

    -- Сохраняем данные фото
    local photoData = {
        id = photoID,
        photographer = IsValid(photoEnt:GetPhotographer()) and photoEnt:GetPhotographer():Nick() or "Unknown",
        photographerSteamID = IsValid(photoEnt:GetPhotographer()) and photoEnt:GetPhotographer():SteamID() or "",
        time = photoEnt:GetCreationTime(),
        storedTime = CurTime(),
    }

    table.insert(self.StoredPhotos, photoData)

    -- Кэшируем сжатые данные изображения
    if PhotoCamera.Server and PhotoCamera.Server.PhotoData and PhotoCamera.Server.PhotoData[photoID] then
        self.PhotoDataCache[photoID] = PhotoCamera.Server.PhotoData[photoID]
    end

    -- Также проверяем принтер
    if PhotoCamera.Printer and PhotoCamera.Printer.ImageCache and PhotoCamera.Printer.ImageCache[photoID] then
        self.PhotoDataCache[photoID] = PhotoCamera.Printer.ImageCache[photoID]
    end

    self:SetStoredCount(#self.StoredPhotos)

    -- Убираем фото из рук и удаляем entity
    ply.HeldPhoto = nil
    ply.HeldPhotoGrabbed = false
    photoEnt:Remove()

    -- Синхронизируем UI если кто-то смотрит
    self:BroadcastSync()
end

function ENT:RetrievePhoto(ply, index)
    if not IsValid(ply) then return end
    if not self.StoredPhotos[index] then
        ply:ChatPrint("Photo not found!")
        return
    end

    local dist = ply:GetPos():Distance(self:GetPos())
    if dist > PhotoCamera.Settings.ArchiveInteractDistance then
        ply:ChatPrint("Too far!")
        return
    end

    local photoData = self.StoredPhotos[index]
    local photoID = photoData.id

    local dirToPlayer = (ply:GetPos() - self:GetPos())
    dirToPlayer.z = 0
    if dirToPlayer:Length() < 1 then
        dirToPlayer = self:GetAngles():Forward()
    end
    dirToPlayer:Normalize()

    local spawnPos = self:GetPos() + dirToPlayer * 40 + Vector(0, 0, 15)
    local ejectVel = dirToPlayer * 120 + Vector(0, 0, 80)

    local photo = ents.Create("ent_photo")
    if not IsValid(photo) then return end

    photo:SetPos(spawnPos)
    photo:SetAngles(Angle(0, self:GetAngles().y, 0))
    photo:Spawn()
    photo:Activate()
    photo:SetPhotoID(photoID)
    photo:SetPhotographer(ply)
    photo:SetCreationTime(CurTime())

    -- Метка только для извлечения
    photo.JustRetrieved = CurTime()

    local phys = photo:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(5)
        phys:SetVelocity(ejectVel)
    end

    if self.PhotoDataCache[photoID] then
        PhotoCamera.Server.PhotoData[photoID] = self.PhotoDataCache[photoID]
        PhotoCamera.Server.BroadcastPhotoData(photoID, self.PhotoDataCache[photoID], nil)
    end

    ply.PhotoEntities = ply.PhotoEntities or {}
    table.insert(ply.PhotoEntities, photo)

    net.Start("PhotoCam_SpawnPhoto")
        net.WriteEntity(photo)
        net.WriteString(photoID)
    net.Broadcast()

    table.remove(self.StoredPhotos, index)
    self:SetStoredCount(#self.StoredPhotos)

    self:BroadcastSync()
end

function ENT:OpenArchiveUI(ply)
    local syncData = self:SerializeArchive()

    net.Start("PhotoCam_ArchiveOpenUI")
        net.WriteEntity(self)
        net.WriteUInt(#syncData, 32)
        net.WriteData(syncData, #syncData)
    net.Send(ply)
end

function ENT:BroadcastSync()
    local syncData = self:SerializeArchive()

    net.Start("PhotoCam_ArchiveSync")
        net.WriteEntity(self)
        net.WriteUInt(#syncData, 32)
        net.WriteData(syncData, #syncData)
    net.Broadcast()
end

function ENT:SerializeArchive()
    local state = {
        photos = {},
        maxPhotos = PhotoCamera.Settings.ArchiveMaxPhotos,
    }

    for i, pd in ipairs(self.StoredPhotos) do
        table.insert(state.photos, {
            index = i,
            id = pd.id,
            photographer = pd.photographer,
            storedTime = pd.storedTime,
        })
    end

    return util.Compress(util.TableToJSON(state))
end

function ENT:OnRemove()
    -- Если подбираем как чемодан — не дропаем фото
    if self.SuppressDropOnRemove then return end

    for i, pd in ipairs(self.StoredPhotos) do
        local photoID = pd.id
        local randomDir = Vector(math.random(-1, 1), math.random(-1, 1), 0)
        if randomDir:Length() < 0.1 then randomDir = Vector(1, 0, 0) end
        randomDir:Normalize()

        local spawnPos = self:GetPos() + randomDir * (20 + i * 5) + Vector(0, 0, 15 + i * 3)

        local photo = ents.Create("ent_photo")
        if IsValid(photo) then
            photo:SetPos(spawnPos)
            photo:SetAngles(Angle(0, math.random(0, 360), 0))
            photo:Spawn()
            photo:Activate()
            photo:SetPhotoID(photoID)
            photo:SetCreationTime(CurTime())

            -- Метки защиты
            photo.RetrieveTime = CurTime()
            photo.DetachTime = CurTime()

            local phys = photo:GetPhysicsObject()
            if IsValid(phys) then
                phys:Wake()
                phys:SetMass(5)
                phys:SetVelocity(randomDir * 80 + Vector(0, 0, 60))
            end

            if self.PhotoDataCache[photoID] then
                PhotoCamera.Server.PhotoData[photoID] = self.PhotoDataCache[photoID]
                PhotoCamera.Server.BroadcastPhotoData(photoID, self.PhotoDataCache[photoID], nil)
            end

            net.Start("PhotoCam_SpawnPhoto")
                net.WriteEntity(photo)
                net.WriteString(photoID)
            net.Broadcast()
        end
    end
end

function ENT:StartTouch(ent)
    if not IsValid(ent) then return end
    if ent:GetClass() ~= "ent_photo" then return end
    if ent:GetOnBoard() then return end

    if #self.StoredPhotos >= PhotoCamera.Settings.ArchiveMaxPhotos then return end

    -- Защита от обратного прикрепления после извлечения
    if ent.JustRetrieved and CurTime() - ent.JustRetrieved < 3 then return end

    -- Если игрок держит — не забираем
    if ent.IsPlayerHolding and ent:IsPlayerHolding() then return end

    if ent.PendingArchive then return end
    ent.PendingArchive = true

    local archive = self
    timer.Simple(0.4, function()
        if not IsValid(archive) or not IsValid(ent) then return end
        if ent:GetOnBoard() then return end
        ent.PendingArchive = nil

        if ent.JustRetrieved and CurTime() - ent.JustRetrieved < 3 then return end

        -- Главная проверка: если игрок держит — не забираем
        if ent.IsPlayerHolding and ent:IsPlayerHolding() then return end

        local phys = ent:GetPhysicsObject()
        if IsValid(phys) and phys:GetVelocity():Length() > 150 then return end

        if #archive.StoredPhotos >= PhotoCamera.Settings.ArchiveMaxPhotos then return end

        local closestPly = nil
        local closestDist = math.huge
        for _, ply in ipairs(player.GetAll()) do
            if IsValid(ply) then
                local d = ply:GetPos():Distance(archive:GetPos())
                if d < closestDist then
                    closestDist = d
                    closestPly = ply
                end
            end
        end

        archive:StorePhoto(closestPly or game.GetWorld(), ent)
    end)
end