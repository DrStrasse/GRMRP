-- lua/entities/ent_photo_archive/cl_init.lua

include("shared.lua")

function ENT:Initialize()
end

function ENT:Draw()
    self:DrawModel()
end

function ENT:DrawTranslucent()
    self:Draw()
end