ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Photo Archive"
ENT.Author = "puddingheh"
ENT.Category = "Investigation system"
ENT.Spawnable = true
ENT.AdminSpawnable = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:SetupDataTables()
    self:NetworkVar("Int", 0, "StoredCount")
end