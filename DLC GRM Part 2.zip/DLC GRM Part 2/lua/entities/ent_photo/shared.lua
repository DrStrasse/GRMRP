ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Photo"
ENT.Author = "PhotoCamera Addon"
ENT.Category = "Photo Camera"
ENT.Spawnable = false
ENT.AdminSpawnable = false
ENT.RenderGroup = RENDERGROUP_BOTH

function ENT:SetupDataTables()
    self:NetworkVar("String", 0, "PhotoID")
    self:NetworkVar("Entity", 0, "Photographer")
    self:NetworkVar("Float", 0, "CreationTime")
    self:NetworkVar("Bool", 0, "OnBoard")
    self:NetworkVar("Float", 1, "BoardU")
    self:NetworkVar("Float", 2, "BoardV")
end