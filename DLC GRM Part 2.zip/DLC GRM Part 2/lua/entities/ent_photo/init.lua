-- lua/entities/ent_photo/init.lua

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel("models/hunter/plates/plate05x05.mdl")
    self:DrawShadow(false)
    self:SetMaterial("models/debug/debugwhite") -- белая карточка

    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)
    self:SetCollisionGroup(COLLISION_GROUP_NONE)

    self:SetOnBoard(false)
    self:SetBoardU(0.5)
    self:SetBoardV(0.5)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(5)
    end
end

function ENT:Use(activator, caller)
    if not IsValid(caller) or not caller:IsPlayer() then return end
    caller:PickupObject(self)
end

function ENT:OnRemove()
    local photoID = self:GetPhotoID()
    if photoID and PhotoCamera.Server then
        PhotoCamera.Server.PhotoData[photoID] = nil
    end
end

-- Разрешаем подбор гравипушкой и руками
function ENT:PhysgunPickup(ply)
    return true
end

function ENT:GravGunPickupAllowed(ply)
    if self:GetOnBoard() then return false end
    return true
end

function ENT:GravGunPunt(ply)
    if self:GetOnBoard() then return false end
    return true
end

function ENT:CanTool(ply, tr, tool)
    return true
end