

include("shared.lua")

function ENT:Initialize()
    self.PhotoMaterial = nil
    self.LastPhotoID = ""
end

function ENT:Think()
    local photoID = self:GetPhotoID()
    if photoID ~= self.LastPhotoID and photoID ~= "" then
        self.LastPhotoID = photoID
        self.PhotoMaterial = PhotoCamera.Capture.GetMaterial(photoID)

        -- Если не нашли в Capture, проверяем в Printer
        if not self.PhotoMaterial and PhotoCamera.Printer and PhotoCamera.Printer.GetMaterial then
            self.PhotoMaterial = PhotoCamera.Printer.GetMaterial(photoID)
        end

        if not self.PhotoMaterial then
            self.RetryCount = 0
            timer.Create("PhotoRetry_" .. photoID, 1, 10, function()
                if not IsValid(self) then return end
                self.PhotoMaterial = PhotoCamera.Capture.GetMaterial(photoID)
                if not self.PhotoMaterial and PhotoCamera.Printer and PhotoCamera.Printer.GetMaterial then
                    self.PhotoMaterial = PhotoCamera.Printer.GetMaterial(photoID)
                end
                if self.PhotoMaterial then
                    timer.Remove("PhotoRetry_" .. photoID)
                end
            end)
        end
    end
end

function ENT:Draw()
    -- Если фото на доске — ничего не рисуем, доска сама рисует
    if self:GetOnBoard() then return end

    -- Модель не рисуем — она только для физики

    local pos = self:GetPos()
    local ang = self:GetAngles()
    local settings = PhotoCamera.Settings
    local size = settings.PhotoEntitySize
    local borderW = 4
    local offset = ang:Up() * 1.5

    render.SuppressEngineLighting(true)

    -- Задняя сторона (белая обратка)
    render.CullMode(MATERIAL_CULLMODE_CW)
    cam.Start3D2D(pos + offset, ang, 0.15)
        surface.SetDrawColor(settings.PhotoShadowColor)
        surface.DrawRect(-size - 1 + 2, -size - 1 + 2, size * 2 + 2, size * 2 + 12)

        surface.SetDrawColor(settings.PhotoBorderColor)
        surface.DrawRect(-size - borderW, -size - borderW, size * 2 + borderW * 2, size * 2 + borderW * 2 + 8)

        surface.SetDrawColor(245, 245, 240, 255)
        surface.DrawRect(-size, -size, size * 2, size * 2)
    cam.End3D2D()

    -- Передняя сторона (фото)
    render.CullMode(MATERIAL_CULLMODE_CCW)
    cam.Start3D2D(pos + offset, ang, 0.15)
        surface.SetDrawColor(settings.PhotoShadowColor)
        surface.DrawRect(-size - 1 + 2, -size - 1 + 2, size * 2 + 2, size * 2 + 12)

        surface.SetDrawColor(settings.PhotoBorderColor)
        surface.DrawRect(-size - borderW, -size - borderW, size * 2 + borderW * 2, size * 2 + borderW * 2 + 8)

        if self.PhotoMaterial and not self.PhotoMaterial:IsError() then
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(self.PhotoMaterial)
            surface.DrawTexturedRect(-size, -size, size * 2, size * 2)
        else
            surface.SetDrawColor(100, 100, 100, 255)
            surface.DrawRect(-size, -size, size * 2, size * 2)
            draw.SimpleText("LOADING...", "DermaDefault",
                0, 0,
                Color(200, 200, 200),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
            )
        end
    cam.End3D2D()

    render.SuppressEngineLighting(false)
end

function ENT:DrawTranslucent()
    self:Draw()
end