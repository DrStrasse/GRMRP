




























PB = PB or {}
PB.Graphs = PB.Graphs or {}





function PB.NewGraph()
    return {
        nodes = {},
        nextID = 1,




        autoManage = true,
        pconstraints = {},
        nextPCID = 1,
        gconstraints = {},
        nextGCID = 1,
        variables = {},
        variableMeta = {},
        history = {},
        historyPos = 0,
        _entityIndex = {},
    }
end

function PB.GraphAutoManageEnabled(graph)
    if not graph then return true end
    return graph.autoManage ~= false
end

function PB.SetGraphAutoManage(graph, enabled)
    if not graph then return false end
    graph.autoManage = enabled ~= false
    return true
end

function PB.NewNode(graph, ent, parentID, localPos, localAngle)
    local id = graph.nextID
    graph.nextID = id + 1

    local node = {
        id = id, entity = ent, model = IsValid(ent) and ent:GetModel() or "",
        entityClass = IsValid(ent) and ent:GetClass() or "prop_physics",
        parentID = parentID, localPos = localPos or Vector(), localAngle = localAngle or Angle(),
        worldPos = IsValid(ent) and ent:GetPos() or Vector(),
        worldAngle = IsValid(ent) and ent:GetAngles() or Angle(),
        constraintType = "none", constraintParams = {}, constraintEnt = nil,
        children = {}, locked = false, visible = true, label = "Node " .. id,
        exprPos = nil, exprAngle = nil,
        dofOverrides = { pos = {}, ang = {} },
        snapParentFace = nil, snapChildFace = nil, snapGap = 0,
        isPattern = false, patternType = nil, patternParams = nil,
        patternEntities = {}, patternConstraints = {},
        patternConstraintType = "none", patternConstraintParams = {}, copyConstraints = false,
        isMirrorGenerated = false, mirrorSourceNodeID = nil, mirrorPCID = nil,
    }
    graph.nodes[id] = node
    if parentID and graph.nodes[parentID] then graph.nodes[parentID].children[id] = true end

    if IsValid(ent) then
        graph._entityIndex[ent] = id





        if SERVER and PB.PhysFeatures and PB.PhysFeatures.BuildForEntity then
            PB.PhysFeatures.BuildForEntity(ent)
        end
    end

    return node
end

function PB.NewPatternNode(graph, parentID, patType, params, copyConst, constType, constParams)
    local id = graph.nextID
    graph.nextID = id + 1

    local node = {
        id = id, entity = nil, model = "",
        parentID = parentID, localPos = Vector(), localAngle = Angle(),
        worldPos = Vector(), worldAngle = Angle(),
        constraintType = "none", constraintParams = {}, constraintEnt = nil,
        children = {}, locked = false, visible = true,
        label = string.upper(patType or "?") .. " Pattern",
        exprPos = nil, exprAngle = nil,
        dofOverrides = { pos = {}, ang = {} },
        snapParentFace = nil, snapChildFace = nil, snapGap = 0,
        isPattern = true, patternType = patType, patternParams = params or {},
        patternEntities = {}, patternConstraints = {},
        patternConstraintType = constType or "none",
        patternConstraintParams = constParams or {},
        copyConstraints = copyConst or false,
        isMirrorGenerated = false, mirrorSourceNodeID = nil, mirrorPCID = nil,
    }
    graph.nodes[id] = node
    if parentID and graph.nodes[parentID] then graph.nodes[parentID].children[id] = true end
    return node
end



function PB.RemoveNode(graph, nodeID, removeChildren)
    local node = graph.nodes[nodeID]
    if not node then return {} end

    local removedIDs = { nodeID }
    local removedPCIDs = {}
    local removedGCIDs = {}

    if node.parentID and graph.nodes[node.parentID] then
        graph.nodes[node.parentID].children[nodeID] = nil
    end
    if node.isPattern and SERVER then
        for _, ent in ipairs(node.patternEntities) do if IsValid(ent) then ent:Remove() end end
        for _, cEnt in ipairs(node.patternConstraints) do if IsValid(cEnt) then cEnt:Remove() end end
    end


    for pcid, pc in pairs(graph.pconstraints) do
        if pc.parentNodeID == nodeID or pc.childNodeID == nodeID then
            table.insert(removedPCIDs, pcid)
        end
    end
    PB.RemovePConstraintsForNode(graph, nodeID)
    if PB.RemoveGConstraintsForNode then
        removedGCIDs = PB.RemoveGConstraintsForNode(graph, nodeID)
    end

    if node.entity then
        graph._entityIndex[node.entity] = nil
    end

    if removeChildren then

        local childIDs = {}
        for cid in pairs(node.children) do table.insert(childIDs, cid) end
        for _, childID in ipairs(childIDs) do
            local childRemoved, childPCRemoved, childGCRemoved = PB.RemoveNode(graph, childID, true)
            for _, rid in ipairs(childRemoved) do table.insert(removedIDs, rid) end
            for _, pid in ipairs(childPCRemoved) do table.insert(removedPCIDs, pid) end
            for _, gid in ipairs(childGCRemoved or {}) do table.insert(removedGCIDs, gid) end
        end
    else
        for childID in pairs(node.children) do
            local child = graph.nodes[childID]
            if child then
                if node.parentID and graph.nodes[node.parentID] then
                    local gp = graph.nodes[node.parentID]
                    child.localPos, child.localAngle = WorldToLocal(child.worldPos, child.worldAngle, gp.worldPos, gp.worldAngle)
                    child.parentID = node.parentID
                    gp.children[childID] = true
                else
                    child.localPos = child.worldPos
                    child.localAngle = child.worldAngle
                    child.parentID = nil
                end
            end
        end
    end
    if SERVER and IsValid(node.constraintEnt) then node.constraintEnt:Remove() end
    graph.nodes[nodeID] = nil

    if not next(graph.nodes) then
        graph.nextID = 1
        graph.nextPCID = 1
        graph.nextGCID = 1
    end

    return removedIDs, removedPCIDs, removedGCIDs
end

function PB.ReparentNode(graph, nodeID, newParentID)
    local node = graph.nodes[nodeID]
    if not node then return false end
    if PB.WouldCreateCycle(graph, nodeID, newParentID) then return false end
    if node.parentID and graph.nodes[node.parentID] then
        graph.nodes[node.parentID].children[nodeID] = nil
    end
    if newParentID and graph.nodes[newParentID] then
        local parent = graph.nodes[newParentID]
        node.localPos, node.localAngle = WorldToLocal(node.worldPos, node.worldAngle, parent.worldPos, parent.worldAngle)
        node.parentID = newParentID
        parent.children[nodeID] = true
    else
        node.localPos = node.worldPos
        node.localAngle = node.worldAngle
        node.parentID = nil
    end
    return true
end

function PB.WouldCreateCycle(graph, nodeID, proposedParentID)
    if not proposedParentID then return false end
    if proposedParentID == nodeID then return true end
    local visited, current = {}, proposedParentID
    while current do
        if current == nodeID then return true end
        if visited[current] then return false end
        visited[current] = true
        local n = graph.nodes[current]
        current = n and n.parentID
    end
    return false
end





function PB.TreeOrder(graph)
    local order, visited = {}, {}
    local function dfs(nodeID)
        if visited[nodeID] then return end
        visited[nodeID] = true
        table.insert(order, nodeID)
        local node = graph.nodes[nodeID]
        if not node then return end
        local childIDs = {}
        for cid in pairs(node.children) do table.insert(childIDs, cid) end
        table.sort(childIDs)
        for _, cid in ipairs(childIDs) do dfs(cid) end
    end
    local roots = {}
    for id, node in pairs(graph.nodes) do
        if not node.parentID or not graph.nodes[node.parentID] then table.insert(roots, id) end
    end
    table.sort(roots)
    for _, rid in ipairs(roots) do dfs(rid) end
    return order
end

function PB.SubtreeOrder(graph, rootID)
    local order, visited = {}, {}
    local queue = { rootID }
    while #queue > 0 do
        local id = table.remove(queue, 1)
        if not visited[id] then
            visited[id] = true
            table.insert(order, id)
            local node = graph.nodes[id]
            if node then for cid in pairs(node.children) do table.insert(queue, cid) end end
        end
    end
    return order
end





function PB.GrabFromEntity(graph, nodeID)
    local node = graph.nodes[nodeID]
    if not node or node.isPattern then return end
    if not IsValid(node.entity) then return end

    node.worldPos = node.entity:GetPos()
    node.worldAngle = node.entity:GetAngles()

    if node.parentID and graph.nodes[node.parentID] then
        local parent = graph.nodes[node.parentID]
        node.localPos, node.localAngle = WorldToLocal(
            node.worldPos, node.worldAngle,
            parent.worldPos, parent.worldAngle)
    else
        node.localPos = Vector(node.worldPos)
        node.localAngle = Angle(node.worldAngle)
    end
end

function PB.GrabAllFromEntities(graph)
    local order = PB.TreeOrder(graph)
    for _, nid in ipairs(order) do
        PB.GrabFromEntity(graph, nid)
    end
end





function PB.SetVariable(graph, name, value) graph.variables[name] = tonumber(value) or 0 end
function PB.GetVariable(graph, name) return graph.variables[name] or 0 end






function PB.RecordAction(graph, actionType, data) end
function PB.GetHistory(graph) return {}, 0 end





function PB.GetGraph(ply)
    if CLIENT then
        if not PB.Graphs["local"] then PB.Graphs["local"] = PB.NewGraph() end
        return PB.Graphs["local"]
    end

    local sid = IsValid(ply) and ply:SteamID() or "server"



    if not (PB.Store and PB.Store.projects) then
        if not PB.Graphs[sid] then PB.Graphs[sid] = PB.NewGraph() end
        return PB.Graphs[sid]
    end

    local pid
    if PB.Store.ResolveActiveProject then
        pid = PB.Store.ResolveActiveProject(sid)
    else
        pid = PB.Store.activeProject[sid]
        if pid and not PB.Store.projects[pid] then
            pid = nil
            PB.Store.activeProject[sid] = nil
        end
    end

    local proj = pid and PB.Store.projects[pid] or nil
    if not proj then
        if not PB.Graphs[sid] then PB.Graphs[sid] = PB.NewGraph() end
        return PB.Graphs[sid]
    end



    PB.Graphs[sid] = proj.graph
    return proj.graph
end

function PB.FindNodeByEntity(graph, ent)
    if not IsValid(ent) then return nil end
    local nodeID = graph._entityIndex[ent]
    if nodeID and graph.nodes[nodeID] then
        return graph.nodes[nodeID]
    end
    for _, node in pairs(graph.nodes) do
        if node.isPattern then
            for _, patEnt in ipairs(node.patternEntities) do
                if patEnt == ent then return node end
            end
        end
    end
    return nil
end

function PB.GetNodeDepth(graph, nodeID)
    local depth, current, visited = 0, nodeID, {}
    while current and graph.nodes[current] and graph.nodes[current].parentID do
        if visited[current] then break end
        visited[current] = true
        current = graph.nodes[current].parentID
        depth = depth + 1
    end
    return depth
end

function PB.GetNodeList(graph)
    local list = {}
    for id, node in pairs(graph.nodes) do
        if not node.isPattern then table.insert(list, { id = id, label = node.label }) end
    end
    table.sort(list, function(a, b) return a.id < b.id end)
    return list
end

function PB.IsToolActive()
    if SERVER then return true end
    local ply = LocalPlayer()
    if not IsValid(ply) then return false end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "gmod_tool" then return false end
    return ply:GetInfo("gmod_toolmode") == "parametric_builder"
end





local BLOCKED_ENTITY_KV = {
    classname = true, model = true, origin = true, angles = true,
    targetname = true, hammerid = true, spawnflags = true,
}

local function copyScalarKeyValues(ent)
    if not IsValid(ent) or not ent.GetKeyValues then return nil end
    local kv = ent:GetKeyValues()
    if not istable(kv) then return nil end

    local out = {}
    for k, v in pairs(kv) do
        k = tostring(k or "")
        if k ~= "" and not BLOCKED_ENTITY_KV[string.lower(k)] then
            local tv = type(v)
            if tv == "string" or tv == "number" or tv == "boolean" then
                out[k] = v
            end
        end
    end

    return next(out) and out or nil
end

local function copyBodygroups(ent)
    if not IsValid(ent) or not ent.GetNumBodyGroups or not ent.GetBodygroup then return nil end
    local out = {}
    local count = math.max(0, tonumber(ent:GetNumBodyGroups()) or 0)

    for i = 0, count - 1 do
        out[i] = ent:GetBodygroup(i) or 0
    end

    return next(out) and out or nil
end

function PB.GetEntitySpawnInfo(ent)
    if not IsValid(ent) then return nil end

    local col = ent.GetColor and ent:GetColor() or nil
    return {
        class = ent:GetClass() or "prop_physics",
        model = ent:GetModel() or "",
        skin = ent.GetSkin and ent:GetSkin() or nil,
        material = ent.GetMaterial and ent:GetMaterial() or nil,
        color = col and { r = col.r, g = col.g, b = col.b, a = col.a } or nil,
        bodygroups = copyBodygroups(ent),
        keyValues = copyScalarKeyValues(ent),
    }
end

local function applyEntityAppearance(ent, info)
    if not IsValid(ent) or not istable(info) then return end

    if info.skin and ent.SetSkin then ent:SetSkin(tonumber(info.skin) or 0) end
    if info.material and info.material ~= "" and ent.SetMaterial then ent:SetMaterial(info.material) end

    if istable(info.color) and ent.SetColor then
        local c = info.color
        ent:SetColor(Color(tonumber(c.r) or 255, tonumber(c.g) or 255, tonumber(c.b) or 255, tonumber(c.a) or 255))
        if ent.SetRenderMode and (tonumber(c.a) or 255) < 255 then ent:SetRenderMode(RENDERMODE_TRANSCOLOR) end
    end

    if istable(info.bodygroups) and ent.SetBodygroup then
        for id, value in pairs(info.bodygroups) do
            ent:SetBodygroup(tonumber(id) or 0, tonumber(value) or 0)
        end
    end
end

function PB.SpawnEntityFromInfo(info, pos, ang)
    if not SERVER or not istable(info) then return nil end

    local class = tostring(info.class or info.entityClass or "prop_physics")
    if class == "" then class = "prop_physics" end

    local model = tostring(info.model or "")
    local ent = ents.Create(class)

    if not IsValid(ent) and class ~= "prop_physics" then
        ent = ents.Create("prop_physics")
    end

    if not IsValid(ent) then return nil end

    if istable(info.keyValues) then
        for k, v in pairs(info.keyValues) do
            local tv = type(v)
            if k and (tv == "string" or tv == "number" or tv == "boolean") then
                ent:SetKeyValue(tostring(k), tostring(v))
            end
        end
    end

    if model ~= "" and ent.SetModel then ent:SetModel(model) end
    if pos then ent:SetPos(pos) end
    if ang then ent:SetAngles(ang) end

    ent:Spawn()

    if pos then ent:SetPos(pos) end
    if ang then ent:SetAngles(ang) end
    ent:Activate()
    applyEntityAppearance(ent, info)

    return ent
end

function PB.SpawnEntityLikeSource(sourceEnt, pos, ang)
    local info = PB.GetEntitySpawnInfo(sourceEnt)
    if not info then return nil end
    return PB.SpawnEntityFromInfo(info, pos, ang), info
end

function PB.GetNodeEntitySpawnInfo(node)
    if not node then return nil end
    if IsValid(node.entity) then return PB.GetEntitySpawnInfo(node.entity) end

    return {
        class = node.entityClass or "prop_physics",
        model = node.model or "",
        skin = node.entitySkin,
        material = node.entityMaterial,
        color = node.entityColor,
        bodygroups = node.entityBodygroups,
        keyValues = node.entityKeyValues,
    }
end





local function serializeSolverDiagnostic(diag)
    if not istable(diag) then return nil end

    return {
        impl = diag.impl or "legacy",
        status = diag.status,
        modelStatus = diag.modelStatus,
        attemptStatus = diag.attemptStatus,
        converged = diag.converged,
        accepted = diag.accepted,
        iterations = tonumber(diag.iterations) or 0,
        residualNorm = tonumber(diag.residualNorm) or 0,
        numEquations = tonumber(diag.numEquations) or 0,
        numUnknowns = tonumber(diag.numUnknowns) or 0,
        rank = tonumber(diag.rank) or 0,
        nullity = tonumber(diag.nullity) or 0,
        redundant = tonumber(diag.redundant) or 0,
        underConstrained = diag.underConstrained or false,
        overConstrained = table.Copy(diag.overConstrained or {}),
        nodeAxes = table.Copy(diag.nodeAxes or {}),
        nodeAxisScores = table.Copy(diag.nodeAxisScores or {}),
        axisSelection = table.Copy(diag.axisSelection or {}),
        branchAttempts = tonumber(diag.branchAttempts) or 0,
        conditionEstimate = tonumber(diag.conditionEstimate) or 0,
        trustRatio = tonumber(diag.trustRatio) or 0,
        groundingModes = table.Copy(diag.groundingModes or {}),
        anchorNodeIDs = table.Copy(diag.anchorNodeIDs or {}),
        gaugeNodeIDs = table.Copy(diag.gaugeNodeIDs or {}),
    }
end
PB.SerializeSolverDiagnostic = serializeSolverDiagnostic

function PB.Serialize(graph)
    local data = { autoManage = graph.autoManage ~= false, variables = table.Copy(graph.variables), variableMeta = table.Copy(graph.variableMeta or {}), nodes = {}, pconstraints = {}, gconstraints = {}, solverDiagnostic = serializeSolverDiagnostic(graph.solverDiagnostic) }
    for id, n in pairs(graph.nodes) do
        local spawnInfo = PB.GetNodeEntitySpawnInfo and PB.GetNodeEntitySpawnInfo(n) or nil
        data.nodes[id] = {
            id = n.id, model = n.model, entityClass = n.entityClass or (spawnInfo and spawnInfo.class) or "prop_physics", parentID = n.parentID,
            entitySkin = spawnInfo and spawnInfo.skin or nil,
            entityMaterial = spawnInfo and spawnInfo.material or nil,
            entityColor = spawnInfo and spawnInfo.color or nil,
            entityBodygroups = spawnInfo and spawnInfo.bodygroups or nil,
            entityKeyValues = spawnInfo and spawnInfo.keyValues or nil,
            localPos = { x = n.localPos.x, y = n.localPos.y, z = n.localPos.z },
            localAngle = { p = n.localAngle.p, y = n.localAngle.y, r = n.localAngle.r },
            worldPos = { x = n.worldPos.x, y = n.worldPos.y, z = n.worldPos.z },
            worldAngle = { p = n.worldAngle.p, y = n.worldAngle.y, r = n.worldAngle.r },
            constraintType = n.constraintType, constraintParams = n.constraintParams,
            label = n.label, notes = n.notes, exprPos = n.exprPos, exprAngle = n.exprAngle,
            exprPosParts = n.exprPosParts, exprAngleParts = n.exprAngleParts,
            dofOverrides = n.dofOverrides,
            isPattern = n.isPattern, patternType = n.patternType, patternParams = n.patternParams,
            copyConstraints = n.copyConstraints, patternConstraintType = n.patternConstraintType,
            patternConstraintParams = n.patternConstraintParams,
            isMirrorGenerated = n.isMirrorGenerated or false,
            mirrorSourceNodeID = n.mirrorSourceNodeID,
            mirrorPCID = n.mirrorPCID,
        }
    end
    for id, pc in pairs(graph.pconstraints) do
        data.pconstraints[id] = {
            id = pc.id, parentNodeID = pc.parentNodeID, childNodeID = pc.childNodeID,
            parentFeature = pc.parentFeature, childFeature = pc.childFeature, mode = pc.mode,
            offset = pc.offset, slideX = pc.slideX, slideY = pc.slideY, angle = pc.angle,
            parentFraction = pc.parentFraction, childFraction = pc.childFraction, distance = pc.distance,
            mirrorNodeID = pc.mirrorNodeID, mirrorFace = pc.mirrorFace, mirrorAxis = pc.mirrorAxis, mirrorGConstraints = pc.mirrorGConstraints or false, active = pc.active, flipped = pc.flipped,
            branchParentSide = pc.branchParentSide or 1, branchChildSide = pc.branchChildSide or 1,
            crossLink = pc.crossLink or false,
        }
    end
    for id, gc in pairs(graph.gconstraints or {}) do
        data.gconstraints[id] = {
            id = gc.id,
            name = gc.name or "",
            type = gc.type,
            enabled = gc.enabled ~= false,
            nodeA = gc.nodeA,
            nodeB = gc.nodeB,
            attachA = PB.GCSerializeAttachment and PB.GCSerializeAttachment(gc.attachA) or gc.attachA,
            attachB = PB.GCSerializeAttachment and PB.GCSerializeAttachment(gc.attachB) or gc.attachB,
            params = gc.params or {},
            updateMode = gc.updateMode or "live",
            debugVisible = gc.debugVisible ~= false,
            isMirrorGenerated = gc.isMirrorGenerated or false,
            mirrorPCID = gc.mirrorPCID,
            mirrorSourceGCID = gc.mirrorSourceGCID,
        }
    end
    return util.TableToJSON(data, true)
end

function PB.Deserialize(graph, json)
    local data = nil
    if istable(json) then
        data = json
    elseif isstring(json) then
        data = util.JSONToTable(json)
    end
    if not data or not istable(data.nodes) then return false end
    graph.autoManage = data.autoManage ~= false
    graph.variables = data.variables or {}
    graph.variableMeta = data.variableMeta or {}
    graph.solverDiagnostic = istable(data.solverDiagnostic) and table.Copy(data.solverDiagnostic) or nil
    local idMap = {}
    for oldID, nd in pairs(data.nodes) do
        oldID = tonumber(oldID)
        if SERVER then
            local newNode
            if nd.isPattern then
                newNode = PB.NewPatternNode(graph, nil, nd.patternType, nd.patternParams, nd.copyConstraints, nd.patternConstraintType, nd.patternConstraintParams)
            else
                local pos = Vector(nd.worldPos.x, nd.worldPos.y, nd.worldPos.z)
                local ang = Angle(nd.worldAngle.p, nd.worldAngle.y, nd.worldAngle.r)
                local ent = PB.SpawnEntityFromInfo({
                    class = nd.entityClass or "prop_physics",
                    model = nd.model,
                    skin = nd.entitySkin,
                    material = nd.entityMaterial,
                    color = nd.entityColor,
                    bodygroups = nd.entityBodygroups,
                    keyValues = nd.entityKeyValues,
                }, pos, ang)
                if not IsValid(ent) then continue end
                if PB.GraphAutoManageEnabled(graph) then
                    local phys = ent:GetPhysicsObject()
                    if IsValid(phys) then phys:EnableMotion(false) end
                end
                newNode = PB.NewNode(graph, ent, nil,
                    Vector(nd.localPos.x, nd.localPos.y, nd.localPos.z),
                    Angle(nd.localAngle.p, nd.localAngle.y, nd.localAngle.r))
                newNode.constraintType = nd.constraintType
                newNode.constraintParams = nd.constraintParams
                newNode.entityClass = nd.entityClass or (IsValid(ent) and ent:GetClass()) or "prop_physics"
                newNode.entitySkin = nd.entitySkin
                newNode.entityMaterial = nd.entityMaterial
                newNode.entityColor = nd.entityColor
                newNode.entityBodygroups = nd.entityBodygroups
                newNode.entityKeyValues = nd.entityKeyValues
            end
            newNode.label = nd.label
            newNode.notes = nd.notes
            newNode.exprPos = nd.exprPos
            newNode.exprAngle = nd.exprAngle
            newNode.exprPosParts = istable(nd.exprPosParts) and table.Copy(nd.exprPosParts) or nil
            newNode.exprAngleParts = istable(nd.exprAngleParts) and table.Copy(nd.exprAngleParts) or nil
            newNode.dofOverrides = istable(nd.dofOverrides) and table.Copy(nd.dofOverrides) or { pos = {}, ang = {} }
            newNode.isMirrorGenerated = nd.isMirrorGenerated or false
            newNode.mirrorSourceNodeID = nd.mirrorSourceNodeID and idMap[tonumber(nd.mirrorSourceNodeID)] or nil
            newNode.mirrorPCID = tonumber(nd.mirrorPCID) or nil
            idMap[oldID] = newNode.id
        end
    end
    for oldID, nd in pairs(data.nodes) do
        local nid = idMap[tonumber(oldID)]
        if nid and nd.parentID then
            local np = idMap[tonumber(nd.parentID)]
            if np then PB.ReparentNode(graph, nid, np) end
        end
    end
    for oldID, nd in pairs(data.nodes) do
        local nid = idMap[tonumber(oldID)]
        local node = nid and graph.nodes[nid]
        if node and nd.mirrorSourceNodeID then
            node.mirrorSourceNodeID = idMap[tonumber(nd.mirrorSourceNodeID)]
        end
    end

    local oldToNewPCID = {}
    for oldPCID, pcd in pairs(data.pconstraints or {}) do
        local pnid = idMap[tonumber(pcd.parentNodeID)]
        local cnid = idMap[tonumber(pcd.childNodeID)]
        if pnid and cnid then
            local pc = PB.NewPConstraint(graph, pnid, cnid, pcd.parentFeature, pcd.childFeature, pcd.mode)
            if pc then
                oldToNewPCID[tonumber(oldPCID)] = pc.id
                pc.offset = pcd.offset or 0
                pc.slideX = pcd.slideX or 0
                pc.slideY = pcd.slideY or 0
                pc.angle = pcd.angle or 0
                pc.parentFraction = pcd.parentFraction or 0.5
                pc.childFraction = pcd.childFraction or 0.5
                pc.distance = pcd.distance or 100
                pc.mirrorNodeID = pcd.mirrorNodeID and idMap[tonumber(pcd.mirrorNodeID)]
                pc.mirrorFace = pcd.mirrorFace
                pc.mirrorAxis = pcd.mirrorAxis or pcd.mirrorFace or "x"
                pc.mirrorGConstraints = pcd.mirrorGConstraints and true or false
                pc.active = pcd.active ~= false
                pc.flipped = pcd.flipped or false
                pc.branchParentSide = math.Clamp(math.floor(tonumber(pcd.branchParentSide) or 1), 1, 2)
                pc.branchChildSide = math.Clamp(math.floor(tonumber(pcd.branchChildSide) or 1), 1, 2)
            end
        end
    end

    for oldID, nd in pairs(data.nodes) do
        local nid = idMap[tonumber(oldID)]
        local node = nid and graph.nodes[nid]
        if node and nd.mirrorPCID then
            node.mirrorPCID = oldToNewPCID[tonumber(nd.mirrorPCID)]
        end
    end

    graph.gconstraints = {}
    graph.nextGCID = graph.nextGCID or 1
    local oldToNewGCID = {}
    local pendingGCMirrorMeta = {}
    local gcOrder = {}
    for oldID in pairs(data.gconstraints or {}) do
        gcOrder[#gcOrder + 1] = tonumber(oldID) or oldID
    end
    table.sort(gcOrder, function(a, b) return tonumber(a) < tonumber(b) end)
    for _, oldID in ipairs(gcOrder) do
        local gcd = data.gconstraints[oldID] or data.gconstraints[tostring(oldID)]
        if gcd then
            local a = idMap[tonumber(gcd.nodeA)]
            local b = idMap[tonumber(gcd.nodeB)]
            if a and b and PB.NewGConstraint then
                local gc = PB.NewGConstraint(graph, a, b, gcd.type, gcd.attachA, gcd.attachB, gcd.params or {}, gcd.name or "")
                if gc then
                    gc.enabled = gcd.enabled ~= false
                    gc.updateMode = gcd.updateMode or "live"
                    gc.debugVisible = gcd.debugVisible ~= false
                    oldToNewGCID[tonumber(oldID)] = gc.id
                    pendingGCMirrorMeta[gc.id] = {
                        isMirrorGenerated = gcd.isMirrorGenerated or false,
                        mirrorPCID = tonumber(gcd.mirrorPCID),
                        mirrorSourceGCID = tonumber(gcd.mirrorSourceGCID),
                    }
                end
            end
        end
    end
    for gcid, meta in pairs(pendingGCMirrorMeta) do
        local gc = graph.gconstraints[gcid]
        if gc then
            gc.isMirrorGenerated = meta.isMirrorGenerated or false
            gc.mirrorPCID = meta.mirrorPCID and oldToNewPCID[meta.mirrorPCID] or nil
            gc.mirrorSourceGCID = meta.mirrorSourceGCID and oldToNewGCID[meta.mirrorSourceGCID] or nil
        end
    end

    if PB.SyncAllMirrorGConstraintsForGraph then
        PB.SyncAllMirrorGConstraintsForGraph(graph)
    end

    PB.Propagate(graph)
    if PB.RefreshGConstraints then PB.RefreshGConstraints(graph, false) end
    return true
end





function PB.ComputeSnapOffset(parentEnt, childEnt, parentFace, childFace, childLocalAngle, gap)
    if not IsValid(parentEnt) or not IsValid(childEnt) then return Vector() end
    local pfc = PB.GetFaceCenter(parentEnt, parentFace)
    local cfc = Vector(PB.GetFaceCenter(childEnt, childFace))
    cfc:Rotate(childLocalAngle or Angle())
    return pfc - cfc + (PB.FACE_NORMALS[parentFace] or Vector()) * (gap or 0)
end
















PB.FACES = { "+x", "-x", "+y", "-y", "+z", "-z" }

PB.FACE_NAMES = {
    ["+x"] = "Front (+X)",  ["-x"] = "Back (-X)",
    ["+y"] = "Right (+Y)",  ["-y"] = "Left (-Y)",
    ["+z"] = "Top (+Z)",    ["-z"] = "Bottom (-Z)",
}

PB.FACE_NORMALS = {
    ["+x"] = Vector(1, 0, 0),  ["-x"] = Vector(-1, 0, 0),
    ["+y"] = Vector(0, 1, 0),  ["-y"] = Vector(0, -1, 0),
    ["+z"] = Vector(0, 0, 1),  ["-z"] = Vector(0, 0, -1),
}

PB.EDGE_INDICES = {
    {1,2}, {2,3}, {3,4}, {4,1},
    {5,6}, {6,7}, {7,8}, {8,5},
    {1,5}, {2,6}, {3,7}, {4,8},
}

PB.EDGE_NAMES = {
    "-Y Bottom", "Front Bottom", "+Y Bottom", "Back Bottom",
    "-Y Top",    "Front Top",    "+Y Top",    "Back Top",
    "Back-Left", "Front-Left",   "Front-Right","Back-Right",
}

PB.EDGE_ADJACENT_FACES = {
    [1]  = {"-y", "-z"}, [2]  = {"+x", "-z"}, [3]  = {"+y", "-z"}, [4]  = {"-x", "-z"},
    [5]  = {"-y", "+z"}, [6]  = {"+x", "+z"}, [7]  = {"+y", "+z"}, [8]  = {"-x", "+z"},
    [9]  = {"-x", "-y"}, [10] = {"+x", "-y"}, [11] = {"+x", "+y"}, [12] = {"-x", "+y"},
}

PB.CORNER_NAMES = {
    "-X -Y -Z", "+X -Y -Z", "+X +Y -Z", "-X +Y -Z",
    "-X -Y +Z", "+X -Y +Z", "+X +Y +Z", "-X +Y +Z",
}





function PB.GetModelVisualBounds(model, lod, bodygroupMask, skin)
    local meshes = util.GetModelMeshes(model, lod or 0, bodygroupMask or 0, skin or 0)
    if not meshes then return nil, nil end
    local mins = Vector(math.huge, math.huge, math.huge)
    local maxs = Vector(-math.huge, -math.huge, -math.huge)
    for _, mesh in ipairs(meshes) do
        local tris = mesh.triangles
        if tris then
            for i = 1, #tris do
                local v = tris[i].pos
                if v.x < mins.x then mins.x = v.x end
                if v.y < mins.y then mins.y = v.y end
                if v.z < mins.z then mins.z = v.z end
                if v.x > maxs.x then maxs.x = v.x end
                if v.y > maxs.y then maxs.y = v.y end
                if v.z > maxs.z then maxs.z = v.z end
            end
        end
    end
    return mins, maxs
end



local _boundsCache = {}


local function GetBounds(ent)
    local model = ent:GetModel()
    local cached = _boundsCache[model]
    if cached == nil then
        local mn, mx = PB.GetModelVisualBounds(model)
        if mn then
            _boundsCache[model] = { mn = mn, mx = mx }
            return mn, mx
        else
            _boundsCache[model] = false
        end
    elseif cached then
        return cached.mn, cached.mx
    end
    return ent:OBBMins(), ent:OBBMaxs()
end
PB.GetBounds = GetBounds































PB.PhysFeatures = PB.PhysFeatures or {}
local PF = PB.PhysFeatures

local PF_PLANE_NORMAL_TOL = 1e-3
local PF_PLANE_OFFSET_TOL = 0.05
local PF_VERTEX_MERGE_TOL = 0.05
local PF_EDGE_DIHEDRAL_TOL = 1e-3



local function pf_round(x, places)


    local m = 10 ^ (places or 4)
    if x >= 0 then
        return math.floor(x * m + 0.5) / m
    else
        return -math.floor(-x * m + 0.5) / m
    end
end





local function pf_build(ent)
    if not SERVER then return nil end
    if not IsValid(ent) then return nil end
    local phys = ent:GetPhysicsObject()
    if not IsValid(phys) then return nil end
    if not phys.GetMeshConvexes then return nil end

    local convexes = phys:GetMeshConvexes()
    if not convexes or #convexes == 0 then return nil end




    local vertexPool = {}
    local function poolVertex(v)
        for i = 1, #vertexPool do
            local p = vertexPool[i]
            local dx, dy, dz = p.x - v.x, p.y - v.y, p.z - v.z
            if dx*dx + dy*dy + dz*dz < PF_VERTEX_MERGE_TOL * PF_VERTEX_MERGE_TOL then
                return i
            end
        end
        vertexPool[#vertexPool + 1] = Vector(v.x, v.y, v.z)
        return #vertexPool
    end




    local rawFaces = {}
    for _, convex in ipairs(convexes) do
        local n = #convex
        if n >= 3 and (n % 3) == 0 then
            local convexFaces = {}
            for tri = 1, n, 3 do
                local v1 = convex[tri].pos
                local v2 = convex[tri + 1].pos
                local v3 = convex[tri + 2].pos
                local e1x, e1y, e1z = v2.x - v1.x, v2.y - v1.y, v2.z - v1.z
                local e2x, e2y, e2z = v3.x - v1.x, v3.y - v1.y, v3.z - v1.z
                local nx = e1y * e2z - e1z * e2y
                local ny = e1z * e2x - e1x * e2z
                local nz = e1x * e2y - e1y * e2x
                local nlen = math.sqrt(nx*nx + ny*ny + nz*nz)
                if nlen > 1e-6 then
                    nx, ny, nz = nx / nlen, ny / nlen, nz / nlen
                    local offset = nx * v1.x + ny * v1.y + nz * v1.z

                    local face = nil
                    for _, f in ipairs(convexFaces) do
                        local d = f.nx * nx + f.ny * ny + f.nz * nz
                        if d > 1 - PF_PLANE_NORMAL_TOL
                            and math.abs(f.offset - offset) < PF_PLANE_OFFSET_TOL then
                            face = f; break
                        end
                    end
                    if not face then
                        face = { nx = nx, ny = ny, nz = nz, offset = offset, vertSet = {}, verts = {} }
                        convexFaces[#convexFaces + 1] = face
                    end

                    for _, v in ipairs({ v1, v2, v3 }) do
                        local idx = poolVertex(v)
                        if not face.vertSet[idx] then
                            face.vertSet[idx] = true
                            face.verts[#face.verts + 1] = idx
                        end
                    end
                end
            end
            for _, f in ipairs(convexFaces) do
                rawFaces[#rawFaces + 1] = f
            end
        end
    end

    if #rawFaces == 0 then return nil end




    for _, f in ipairs(rawFaces) do
        local cx, cy, cz = 0, 0, 0
        for _, idx in ipairs(f.verts) do
            local p = vertexPool[idx]
            cx, cy, cz = cx + p.x, cy + p.y, cz + p.z
        end
        local n = #f.verts
        f.ox, f.oy, f.oz = cx / n, cy / n, cz / n


        local nx, ny, nz = f.nx, f.ny, f.nz
        local ux, uy, uz
        if math.abs(nz) < 0.9 then

            ux, uy, uz = ny, -nx, 0
        else

            ux, uy, uz = 0, nz, -ny
        end
        local ulen = math.sqrt(ux*ux + uy*uy + uz*uz)
        if ulen < 1e-6 then
            ux, uy, uz = 1, 0, 0
        else
            ux, uy, uz = ux / ulen, uy / ulen, uz / ulen
        end

        local vx = ny * uz - nz * uy
        local vy = nz * ux - nx * uz
        local vz = nx * uy - ny * ux
        f.ux, f.uy, f.uz = ux, uy, uz
        f.vx, f.vy, f.vz = vx, vy, vz


        local angles = {}
        for i, idx in ipairs(f.verts) do
            local p = vertexPool[idx]
            local du = (p.x - f.ox) * ux + (p.y - f.oy) * uy + (p.z - f.oz) * uz
            local dv = (p.x - f.ox) * vx + (p.y - f.oy) * vy + (p.z - f.oz) * vz
            angles[i] = { idx = idx, ang = math.atan2(dv, du) }
        end
        table.sort(angles, function(a, b)
            if a.ang ~= b.ang then return a.ang < b.ang end
            return a.idx < b.idx
        end)
        local ordered = {}
        for i, e in ipairs(angles) do ordered[i] = e.idx end
        f.verts = ordered
        f.vertSet = nil



        local minU, maxU, minV, maxV = math.huge, -math.huge, math.huge, -math.huge
        for _, idx in ipairs(f.verts) do
            local p = vertexPool[idx]
            local du = (p.x - f.ox) * ux + (p.y - f.oy) * uy + (p.z - f.oz) * uz
            local dv = (p.x - f.ox) * vx + (p.y - f.oy) * vy + (p.z - f.oz) * vz
            if du < minU then minU = du end
            if du > maxU then maxU = du end
            if dv < minV then minV = dv end
            if dv > maxV then maxV = dv end
        end
        f.sizeMin = math.min(maxU - minU, maxV - minV)
    end




    table.sort(rawFaces, function(a, b)
        local axn, ayn, azn = pf_round(a.nx), pf_round(a.ny), pf_round(a.nz)
        local bxn, byn, bzn = pf_round(b.nx), pf_round(b.ny), pf_round(b.nz)
        if axn ~= bxn then return axn < bxn end
        if ayn ~= byn then return ayn < byn end
        if azn ~= bzn then return azn < bzn end
        local ao, bo = pf_round(a.offset, 2), pf_round(b.offset, 2)
        if ao ~= bo then return ao < bo end
        return (a.verts[1] or 0) < (b.verts[1] or 0)
    end)



    local vertOrder = {}
    for i = 1, #vertexPool do vertOrder[i] = i end
    table.sort(vertOrder, function(ia, ib)
        local a, b = vertexPool[ia], vertexPool[ib]
        local ax, ay, az = pf_round(a.x, 2), pf_round(a.y, 2), pf_round(a.z, 2)
        local bx, by, bz = pf_round(b.x, 2), pf_round(b.y, 2), pf_round(b.z, 2)
        if ax ~= bx then return ax < bx end
        if ay ~= by then return ay < by end
        return az < bz
    end)
    local oldToNew = {}
    local newPool = {}
    for newIdx, oldIdx in ipairs(vertOrder) do
        oldToNew[oldIdx] = newIdx
        newPool[newIdx] = vertexPool[oldIdx]
    end
    vertexPool = newPool
    for _, f in ipairs(rawFaces) do
        for i, idx in ipairs(f.verts) do f.verts[i] = oldToNew[idx] end
    end






    local edgeMap = {}
    for fIdx, f in ipairs(rawFaces) do
        local n = #f.verts
        for i = 1, n do
            local a = f.verts[i]
            local b = f.verts[(i % n) + 1]
            local lo, hi = a, b
            if lo > hi then lo, hi = hi, lo end
            local key = lo * 100000 + hi
            local e = edgeMap[key]
            if not e then
                e = { vA = lo, vB = hi, faces = {} }
                edgeMap[key] = e
            end
            local seen = false
            for _, fi in ipairs(e.faces) do if fi == fIdx then seen = true; break end end
            if not seen then e.faces[#e.faces + 1] = fIdx end
        end
    end

    local edges = {}
    for _, e in pairs(edgeMap) do
        if #e.faces >= 2 then
            local fA = rawFaces[e.faces[1]]
            local fB = rawFaces[e.faces[2]]
            local d = fA.nx * fB.nx + fA.ny * fB.ny + fA.nz * fB.nz

            if math.abs(d) < 1 - PF_EDGE_DIHEDRAL_TOL then
                edges[#edges + 1] = {
                    vA = e.vA, vB = e.vB,
                    nAx = fA.nx, nAy = fA.ny, nAz = fA.nz,
                    nBx = fB.nx, nBy = fB.ny, nBz = fB.nz,
                }
            end
        elseif #e.faces == 1 then


            local fA = rawFaces[e.faces[1]]
            edges[#edges + 1] = {
                vA = e.vA, vB = e.vB,
                nAx = fA.nx, nAy = fA.ny, nAz = fA.nz,
                nBx = fA.nx, nBy = fA.ny, nBz = fA.nz,
            }
        end
    end

    table.sort(edges, function(a, b)
        if a.vA ~= b.vA then return a.vA < b.vA end
        return a.vB < b.vB
    end)


    local cornerSet = {}
    for _, e in ipairs(edges) do
        cornerSet[e.vA] = true
        cornerSet[e.vB] = true
    end
    local corners = {}
    for idx in pairs(cornerSet) do corners[#corners + 1] = idx end
    table.sort(corners)
    local cornerList = {}
    for i, idx in ipairs(corners) do
        cornerList[i] = { v = idx }
    end

    return {
        faces = rawFaces,
        edges = edges,
        corners = cornerList,
        vertices = vertexPool,
    }
end

local _physCache = {}




local function buildForEntity(ent)
    if not SERVER or not IsValid(ent) then return nil end
    local model = ent:GetModel() or ""
    local cached = _physCache[model]
    if cached ~= nil then
        if cached == false then return nil end
        return cached
    end
    local features = pf_build(ent)
    _physCache[model] = features or false
    return features
end
PF.BuildForEntity = buildForEntity




local function getForModel(model)
    if not model or model == "" then return nil end
    local cached = _physCache[model]
    if cached == false then return nil end
    return cached or nil
end
PF.GetForModel = getForModel





function PF.SetForModel(model, features)
    if not model or model == "" then return end
    _physCache[model] = features or false
end


function PF.AllModels()
    return pairs(_physCache)
end






local function getPhysFeatures(ent)
    if not IsValid(ent) then return nil end
    local model = ent:GetModel() or ""
    local cached = _physCache[model]
    if cached ~= nil then
        if cached == false then return nil end
        return cached
    end
    if SERVER then
        return buildForEntity(ent)
    end
    return nil
end
PF.Get = getPhysFeatures


local function isPhysID(id)
    return type(id) == "string" and id:sub(1, 1) == "p" and #id >= 2
        and (id:sub(2, 2) == "f" or id:sub(2, 2) == "e" or id:sub(2, 2) == "c")
end
PF.IsPhysID = isPhysID

local function physIndex(id)

    return tonumber(id:sub(3))
end

local function getPhysFace(ent, id)
    local set = getPhysFeatures(ent); if not set then return nil end
    return set.faces[physIndex(id)]
end
local function getPhysEdge(ent, id)
    local set = getPhysFeatures(ent); if not set then return nil end
    return set.edges[physIndex(id)]
end
local function getPhysCorner(ent, id)
    local set = getPhysFeatures(ent); if not set then return nil end
    local c = set.corners[physIndex(id)]
    return c and set.vertices[c.v] or nil
end
PF.GetFace = getPhysFace
PF.GetEdge = getPhysEdge
PF.GetCorner = getPhysCorner





function PB.GetOBBCorners(ent)
    local mn, mx = GetBounds(ent)
    return {
        Vector(mn.x, mn.y, mn.z), Vector(mx.x, mn.y, mn.z),
        Vector(mx.x, mx.y, mn.z), Vector(mn.x, mx.y, mn.z),
        Vector(mn.x, mn.y, mx.z), Vector(mx.x, mn.y, mx.z),
        Vector(mx.x, mx.y, mx.z), Vector(mn.x, mx.y, mx.z),
    }
end

function PB.GetEdgeEndpoints(ent, idx)

    if isPhysID(idx) then
        local set = getPhysFeatures(ent)
        local e = set and set.edges[physIndex(idx)]
        if e then
            return ent:LocalToWorld(set.vertices[e.vA]), ent:LocalToWorld(set.vertices[e.vB])
        end
        return Vector(), Vector()
    end
    local corners = PB.GetOBBCorners(ent)
    local pair = PB.EDGE_INDICES[idx]
    if not pair then return Vector(), Vector() end
    return ent:LocalToWorld(corners[pair[1]]), ent:LocalToWorld(corners[pair[2]])
end

function PB.GetEdgeLocalEndpoints(ent, idx)
    if isPhysID(idx) then
        local set = getPhysFeatures(ent)
        local e = set and set.edges[physIndex(idx)]
        if e then
            return Vector(set.vertices[e.vA]), Vector(set.vertices[e.vB])
        end
        return Vector(), Vector()
    end
    local corners = PB.GetOBBCorners(ent)
    local pair = PB.EDGE_INDICES[idx]
    if not pair then return Vector(), Vector() end
    return corners[pair[1]], corners[pair[2]]
end

function PB.GetEdgeLocalPoint(ent, idx, frac)
    local a, b = PB.GetEdgeLocalEndpoints(ent, idx)
    return a + (b - a) * (frac or 0.5)
end

function PB.GetEdgeLocalDir(ent, idx)
    local a, b = PB.GetEdgeLocalEndpoints(ent, idx)
    local dir = b - a
    dir:Normalize()
    return dir
end

function PB.GetEdgeAdjacentFaces(idx)


    if isPhysID(idx) then return nil end
    local pair = PB.EDGE_ADJACENT_FACES[idx]
    if not pair then return nil end
    return { pair[1], pair[2] }
end

function PB.GetEdgeLocalSideNormal(ent, idx, sideIndex)
    if isPhysID(idx) then
        local set = getPhysFeatures(ent)
        local e = set and set.edges[physIndex(idx)]
        if not e then return Vector(0, 0, 1), nil end
        sideIndex = math.Clamp(math.floor(tonumber(sideIndex) or 1), 1, 2)
        if sideIndex == 1 then
            return Vector(e.nAx, e.nAy, e.nAz), nil
        else
            return Vector(e.nBx, e.nBy, e.nBz), nil
        end
    end
    local faces = PB.GetEdgeAdjacentFaces(idx)
    if not faces then return Vector(0, 0, 1), nil end
    sideIndex = math.Clamp(math.floor(tonumber(sideIndex) or 1), 1, #faces)
    local faceID = faces[sideIndex]
    return Vector(PB.FACE_NORMALS[faceID] or Vector(0, 0, 1)), faceID
end



function PB.GetFaceLocalNormal(ent, faceID)
    if isPhysID(faceID) then
        local f = getPhysFace(ent, faceID)
        if f then return Vector(f.nx, f.ny, f.nz) end
        return Vector(0, 0, 1)
    end
    return Vector(PB.FACE_NORMALS[faceID] or Vector(0, 0, 1))
end

function PB.GetFaceCenter(ent, faceID)
    if not IsValid(ent) then return Vector() end
    if isPhysID(faceID) then
        local f = getPhysFace(ent, faceID)
        if f then return Vector(f.ox, f.oy, f.oz) end
        return Vector()
    end
    local mn, mx = GetBounds(ent)
    local c = (mn + mx) * 0.5
    if     faceID == "+x" then return Vector(mx.x, c.y, c.z)
    elseif faceID == "-x" then return Vector(mn.x, c.y, c.z)
    elseif faceID == "+y" then return Vector(c.x, mx.y, c.z)
    elseif faceID == "-y" then return Vector(c.x, mn.y, c.z)
    elseif faceID == "+z" then return Vector(c.x, c.y, mx.z)
    elseif faceID == "-z" then return Vector(c.x, c.y, mn.z) end
    return c
end

function PB.GetCornerLocalPos(ent, idx)
    if isPhysID(idx) then
        local v = getPhysCorner(ent, idx)
        if v then return Vector(v) end
        return Vector()
    end
    return PB.GetOBBCorners(ent)[idx] or Vector()
end

function PB.GetCornerWorldPos(ent, idx)
    return ent:LocalToWorld(PB.GetCornerLocalPos(ent, idx))
end

function PB.GetFeatureLocalPos(ent, feature, frac)
    if feature.type == "face" then return PB.GetFaceCenter(ent, feature.id)
    elseif feature.type == "edge" then return PB.GetEdgeLocalPoint(ent, feature.id, frac or 0.5)
    elseif feature.type == "corner" then return PB.GetCornerLocalPos(ent, feature.id) end
    return Vector()
end

function PB.GetFeatureWorldPos(node, feature, frac)
    if not node or not IsValid(node.entity) then return Vector() end
    return node.entity:LocalToWorld(PB.GetFeatureLocalPos(node.entity, feature, frac))
end









function PB.NodeLocalToWorld(node, localPos)
    local wp = Vector(localPos)
    wp:Rotate(node.worldAngle)
    return node.worldPos + wp
end


function PB.GetEdgeWorldEndpoints(node, idx)
    if not IsValid(node.entity) then return Vector(), Vector() end
    local a, b = PB.GetEdgeLocalEndpoints(node.entity, idx)
    return PB.NodeLocalToWorld(node, a), PB.NodeLocalToWorld(node, b)
end


function PB.GetEdgeWorldDir(node, idx)
    if not IsValid(node.entity) then return Vector(1, 0, 0) end
    local dir = PB.GetEdgeLocalDir(node.entity, idx)
    local wDir = Vector(dir)
    wDir:Rotate(node.worldAngle)
    return wDir
end


function PB.GetFeatureWorldPosFromNode(node, feature, frac)
    if not node or not IsValid(node.entity) then return Vector() end
    return PB.NodeLocalToWorld(node, PB.GetFeatureLocalPos(node.entity, feature, frac))
end


function PB.GetCornerWorldPosFromNode(node, idx)
    if not IsValid(node.entity) then return Vector() end
    return PB.NodeLocalToWorld(node, PB.GetCornerLocalPos(node.entity, idx))
end





function PB.PointToSegmentDist(point, segA, segB)
    local seg = segB - segA
    local lenSq = seg:Dot(seg)
    if lenSq < 0.0001 then return point:Distance(segA) end
    local t = math.Clamp((point - segA):Dot(seg) / lenSq, 0, 1)
    return point:Distance(segA + seg * t)
end

function PB.SegmentToSegmentDist(a1, a2, b1, b2)
    local u, v, w = a2 - a1, b2 - b1, a1 - b1
    local uu, uv, vv, uw, vw = u:Dot(u), u:Dot(v), v:Dot(v), u:Dot(w), v:Dot(w)
    local denom = uu * vv - uv * uv
    local sc, tc
    if denom < 0.0001 then
        sc = 0
        tc = (uv > vv) and (uw / uv) or (vw / vv)
    else
        sc = (uv * vw - vv * uw) / denom
        tc = (uu * vw - uv * uw) / denom
    end
    return (a1 + u * math.Clamp(sc, 0, 1)):Distance(b1 + v * math.Clamp(tc, 0, 1))
end



local function dist2DToSegment(pu, pv, au, av, bu, bv)
    local dx, dy = bu - au, bv - av
    local lenSq = dx * dx + dy * dy
    if lenSq < 1e-6 then
        local ex, ey = pu - au, pv - av
        return math.sqrt(ex * ex + ey * ey)
    end
    local t = ((pu - au) * dx + (pv - av) * dy) / lenSq
    if t < 0 then t = 0 elseif t > 1 then t = 1 end
    local cx, cy = au + dx * t, av + dy * t
    local ex, ey = pu - cx, pv - cy
    return math.sqrt(ex * ex + ey * ey)
end












local cvCornerPct = CreateConVar and CreateConVar(
    "parametric_builder_pick_corner_pct", "0.15", FCVAR_ARCHIVE,
    "PConstraint picker: corner zone radius as fraction of face's smallest dimension.") or nil
local cvEdgePct = CreateConVar and CreateConVar(
    "parametric_builder_pick_edge_pct", "0.20", FCVAR_ARCHIVE,
    "PConstraint picker: edge zone width as fraction of face's smallest dimension.") or nil
local cvMinUnit = CreateConVar and CreateConVar(
    "parametric_builder_pick_min_unit", "0", FCVAR_ARCHIVE,
    "PConstraint picker: absolute minimum threshold in source units (0 = pure percentage).") or nil

local function clampPickerPct(v, fallback)
    v = tonumber(v)
    if v == nil then v = fallback end
    return math.Clamp(v, 0, 0.45)
end

local function clampPickerMinUnit(v, fallback)
    v = tonumber(v)
    if v == nil then v = fallback end
    return math.Clamp(v, 0, 16)
end

function PB.PickerPrefsFromConVars()
    return {
        cornerPct = clampPickerPct((cvCornerPct and cvCornerPct:GetFloat()) or 0.15, 0.15),
        edgePct = clampPickerPct((cvEdgePct and cvEdgePct:GetFloat()) or 0.20, 0.20),
        minUnit = clampPickerMinUnit((cvMinUnit and cvMinUnit:GetFloat()) or 0, 0),
    }
end

function PB.NormalizePickerPrefs(prefs)
    prefs = prefs or {}
    return {
        cornerPct = clampPickerPct(prefs.cornerPct, 0.15),
        edgePct = clampPickerPct(prefs.edgePct, 0.20),
        minUnit = clampPickerMinUnit(prefs.minUnit, 0),
    }
end

local function pickerThresholds(sizeMin, prefs)
    prefs = prefs and PB.NormalizePickerPrefs(prefs) or PB.PickerPrefsFromConVars()
    return math.max(sizeMin * prefs.cornerPct, prefs.minUnit), math.max(sizeMin * prefs.edgePct, prefs.minUnit)
end









local PF_HIT_NORMAL_DOT_MIN = 0.35
local PF_INSIDE_EPS = 0.05

local function faceNormalDotWorld(ent, face, hitNormal)
    if not hitNormal then return 1 end
    local n = Vector(face.nx, face.ny, face.nz)
    n:Rotate(ent:GetAngles())
    return math.abs(hitNormal:Dot(n))
end

local function projectOntoFace(face, p)
    local dx, dy, dz = p.x - face.ox, p.y - face.oy, p.z - face.oz
    local u = dx * face.ux + dy * face.uy + dz * face.uz
    local v = dx * face.vx + dy * face.vy + dz * face.vz
    local plane = dx * face.nx + dy * face.ny + dz * face.nz
    return u, v, math.abs(plane)
end

local function buildFaceUV(set, face)
    local n = #face.verts
    local vu, vv = {}, {}
    for k = 1, n do
        local p = set.vertices[face.verts[k]]
        vu[k], vv[k] = projectOntoFace(face, p)
    end
    return vu, vv
end

local function pointInPolygon2D(u, v, vu, vv)
    local inside = false
    local n = #vu
    local j = n
    for i = 1, n do
        local yi, yj = vv[i], vv[j]
        local xi, xj = vu[i], vu[j]
        if ((yi > v) ~= (yj > v)) then
            local xCross = (xj - xi) * (v - yi) / ((yj - yi) ~= 0 and (yj - yi) or 1e-9) + xi
            if u < xCross then inside = not inside end
        end
        j = i
    end
    return inside
end

local function nearestFaceEdgeDistance2D(u, v, vu, vv)
    local best = math.huge
    local n = #vu
    for k = 1, n do
        local kn = (k % n) + 1
        local d = dist2DToSegment(u, v, vu[k], vv[k], vu[kn], vv[kn])
        if d < best then best = d end
    end
    return best
end

local function detectPhysFaceAtHit(ent, set, localHit, hitNormal)
    local bestIdx, bestScore = nil, math.huge

    for i, face in ipairs(set.faces) do
        local normalDot = faceNormalDotWorld(ent, face, hitNormal)
        if normalDot >= PF_HIT_NORMAL_DOT_MIN then
            local u, v, planeDist = projectOntoFace(face, localHit)
            local vu, vv = buildFaceUV(set, face)
            local edgeDist = nearestFaceEdgeDistance2D(u, v, vu, vv)
            local inside = pointInPolygon2D(u, v, vu, vv) or edgeDist <= PF_INSIDE_EPS





            local score = (inside and 0 or 100000)
                + planeDist * 100
                + edgeDist
                + (1 - normalDot) * 10

            if score < bestScore then
                bestScore = score
                bestIdx = i
            end
        end
    end

    return bestIdx
end





local function ensurePhysSetLookups(set)
    if set._cornerByVert and set._edgeByVertPair then return end
    if not set._cornerByVert then
        local cv = {}
        for i, c in ipairs(set.corners) do cv[c.v] = i end
        set._cornerByVert = cv
    end
    if not set._edgeByVertPair then
        local ev = {}
        for i, e in ipairs(set.edges) do
            local lo, hi = e.vA, e.vB
            if lo > hi then lo, hi = hi, lo end
            ev[lo * 100000 + hi] = i
        end
        set._edgeByVertPair = ev
    end
end

local function classifyPhysFeatureOnFace(set, faceIdx, localHit, pickerPrefs)
    local face = set.faces[faceIdx]
    if not face then return nil end

    ensurePhysSetLookups(set)

    local u, v = projectOntoFace(face, localHit)
    local vu, vv = buildFaceUV(set, face)
    local nVerts = #face.verts

    local bestCornerID, bestCornerDist = nil, math.huge
    local bestEdgeID, bestEdgeDist = nil, math.huge

    for k = 1, nVerts do
        local dx, dy = u - vu[k], v - vv[k]
        local d = math.sqrt(dx * dx + dy * dy)
        if d < bestCornerDist then
            local cid = set._cornerByVert[face.verts[k]]
            if cid then
                bestCornerDist = d
                bestCornerID = cid
            end
        end
    end

    for k = 1, nVerts do
        local kn = (k % nVerts) + 1
        local d = dist2DToSegment(u, v, vu[k], vv[k], vu[kn], vv[kn])
        if d < bestEdgeDist then
            local a, b = face.verts[k], face.verts[kn]
            local lo, hi = a, b
            if lo > hi then lo, hi = hi, lo end
            local eid = set._edgeByVertPair[lo * 100000 + hi]
            if eid then
                bestEdgeDist = d
                bestEdgeID = eid
            end
        end
    end

    local cornerThresh, edgeThresh = pickerThresholds(face.sizeMin or 8, pickerPrefs)
    if bestCornerID and bestCornerDist < cornerThresh then
        return { type = "corner", id = "pc" .. bestCornerID }
    end
    if bestEdgeID and bestEdgeDist < edgeThresh then
        return { type = "edge", id = "pe" .. bestEdgeID }
    end
    return { type = "face", id = "pf" .. faceIdx }
end

local function detectFeaturePhys(ent, hitPos, hitNormal, pickerPrefs)
    local set = getPhysFeatures(ent)
    if not set or not hitPos then return nil end

    local localHit = ent:WorldToLocal(hitPos)
    local faceIdx = detectPhysFaceAtHit(ent, set, localHit, hitNormal)
    if not faceIdx then return nil end

    return classifyPhysFeatureOnFace(set, faceIdx, localHit, pickerPrefs)
end
PF.Detect = detectFeaturePhys

function PB.DetectFeature(ent, eyePos, eyeDir, hitPos, hitNormal, pickerPrefs)
    if not IsValid(ent) then return nil end
    return detectFeaturePhys(ent, hitPos, hitNormal, pickerPrefs)
end















local function MakeExprEnv(variables)
    local env = {
        Vector = Vector, Angle = Angle,
        math = {
            abs = math.abs, ceil = math.ceil, floor = math.floor,
            sin = math.sin, cos = math.cos, tan = math.tan,
            asin = math.asin, acos = math.acos, atan = math.atan, atan2 = math.atan2,
            sqrt = math.sqrt, exp = math.exp, log = math.log,
            min = math.min, max = math.max,
            pi = math.pi, huge = math.huge,
            rad = math.rad, deg = math.deg,
            fmod = math.fmod, Clamp = math.Clamp,
        },
        sin = math.sin, cos = math.cos, tan = math.tan,
        abs = math.abs, sqrt = math.sqrt,
        pi = math.pi, rad = math.rad, deg = math.deg,
        min = math.min, max = math.max,
        isvector = isvector, isangle = isangle, isnumber = isnumber,
        tonumber = tonumber, tostring = tostring,
    }
    if variables then
        for name, value in pairs(variables) do env[name] = value end
    end
    return env
end

local function IsExprSafe(str)
    if string.find(str, "%[") then return false end
    if string.find(str, '["\']%s*:') then return false end
    if string.find(str, "__") then return false end
    if string.find(str, "rawget") then return false end
    if string.find(str, "rawset") then return false end
    if string.find(str, "string%.rep") then return false end
    if #str > 500 then return false end
    return true
end




local EXPR_INSTRUCTION_LIMIT = 10000

function PB.EvalExpression(graph, expr)
    if not expr or expr == "" then return nil end
    local substituted = string.gsub(tostring(expr), "%$([%w_]+)", function(name)
        return tostring(graph.variables[name] or 0)
    end)
    if not IsExprSafe(substituted) then return nil end
    local fn = CompileString("return " .. substituted, "PB_Expr", false)
    if isstring(fn) then return nil end
    if isfunction(fn) then
        setfenv(fn, MakeExprEnv(graph.variables))

        local aborted = false
        debug.sethook(function() aborted = true; error("PB_Expr: instruction limit exceeded") end, "", EXPR_INSTRUCTION_LIMIT)
        local ok, result = pcall(fn)
        debug.sethook()
        if ok and not aborted then return result end
    end
    return nil
end

function PB.EvalPCParam(graph, value)
    if type(value) == "number" then return value end
    if type(value) == "string" and value ~= "" then
        return tonumber(PB.EvalExpression(graph, value)) or 0
    end
    return tonumber(value) or 0
end

function PB.ResolveLocalPos(graph, node)
    if node.exprPos then
        local v = PB.EvalExpression(graph, node.exprPos)
        if isvector(v) then return v end
    end
    return node.localPos
end

function PB.ResolveLocalAngle(graph, node)
    if node.exprAngle then
        local v = PB.EvalExpression(graph, node.exprAngle)
        if isangle(v) then return v end
    end
    return node.localAngle
end





function PB.AngleFromVectors(fwd, up)
    local ang = fwd:Angle()
    local desUp = up - fwd * fwd:Dot(up)
    if desUp:LengthSqr() < 0.0001 then return ang end
    desUp:Normalize()
    local curUp = ang:Up() - fwd * fwd:Dot(ang:Up())
    curUp:Normalize()
    local dot = math.Clamp(curUp:Dot(desUp), -1, 1)
    local cross = curUp:Cross(desUp):Dot(fwd)
    ang.r = ang.r + math.deg(math.atan2(cross, dot))
    return ang
end

function PB.Rodrigues(vec, axis, theta)
    local c, s = math.cos(theta), math.sin(theta)
    return vec * c + axis:Cross(vec) * s + axis * (axis:Dot(vec) * (1 - c))
end

function PB.RotateAngle(angle, axis, radians)
    return PB.AngleFromVectors(
        PB.Rodrigues(angle:Forward(), axis, radians),
        PB.Rodrigues(angle:Up(), axis, radians)
    )
end






PB.MIRROR_AXES = PB.MIRROR_AXES or { x = true, y = true, z = true }

local function mirrorAxisName(axis)
    axis = string.lower(tostring(axis or "x"))
    if axis ~= "x" and axis ~= "y" and axis ~= "z" then axis = "x" end
    return axis
end
PB.NormalizeMirrorAxis = mirrorAxisName

function PB.GetMirrorPlaneNormal(node, axis)
    if not node then return Vector(1, 0, 0) end
    local ang = node.worldAngle or (IsValid(node.entity) and node.entity:GetAngles()) or Angle()
    axis = mirrorAxisName(axis)
    if axis == "y" then return ang:Right():GetNormalized() end
    if axis == "z" then return ang:Up():GetNormalized() end
    return ang:Forward():GetNormalized()
end

local DEFAULT_MIRROR_ORIGIN_REFERENCE_CLASSES = {
    prop_vehicle_airboat = true,
    prop_vehicle_apc = true,
    prop_vehicle_crane = true,
    prop_vehicle_jeep = true,
    prop_vehicle_prisoner_pod = true,
}

local DEFAULT_MIRROR_ORIGIN_REFERENCE_MODELS = {
    ["models/nova/airboat_seat.mdl"] = true,
    ["models/nova/jeep_seat.mdl"] = true,
}

local function mirrorOriginReferenceLookupTable(listName, key)
    key = string.lower(tostring(key or ""))
    if key == "" or not list or not list.Get then return false end

    local values = list.Get(listName) or {}
    if values[key] then return true end

    for k, v in pairs(values) do
        if v then
            k = string.lower(tostring(k or ""))
            if k ~= "" and key == k then return true end
        end
    end

    return false
end

local function mirrorOriginReferenceLookupPrefix(listName, key)
    key = string.lower(tostring(key or ""))
    if key == "" or not list or not list.Get then return false end

    local values = list.Get(listName) or {}
    for prefix, enabled in pairs(values) do
        if enabled then
            prefix = string.lower(tostring(prefix or ""))
            if prefix ~= "" and string.sub(key, 1, #prefix) == prefix then return true end
        end
    end

    return false
end

function PB.NodeUsesMirrorOriginReference(node)
    if not node then return false end

    local ent = node.entity
    if IsValid(ent) then
        if ent.IsVehicle and ent:IsVehicle() then return true end

        local class = string.lower(tostring(ent:GetClass() or ""))
        if DEFAULT_MIRROR_ORIGIN_REFERENCE_CLASSES[class] then return true end
        if mirrorOriginReferenceLookupTable("PA_mirror_origin_reference_classes", class) then return true end
        if mirrorOriginReferenceLookupPrefix("PA_mirror_origin_reference_class_prefixes", class) then return true end
        if string.sub(class, 1, 13) == "prop_vehicle_" then return true end

        local model = string.lower(tostring(ent:GetModel() or ""))
        if DEFAULT_MIRROR_ORIGIN_REFERENCE_MODELS[model] then return true end
        if mirrorOriginReferenceLookupTable("PA_mirror_origin_reference_models", model) then return true end
        if mirrorOriginReferenceLookupPrefix("PA_mirror_origin_reference_model_prefixes", model) then return true end
    end

    local class = string.lower(tostring(node.entityClass or ""))
    if DEFAULT_MIRROR_ORIGIN_REFERENCE_CLASSES[class] then return true end
    if mirrorOriginReferenceLookupTable("PA_mirror_origin_reference_classes", class) then return true end
    if mirrorOriginReferenceLookupPrefix("PA_mirror_origin_reference_class_prefixes", class) then return true end
    if string.sub(class, 1, 13) == "prop_vehicle_" then return true end

    local model = string.lower(tostring(node.model or ""))
    if DEFAULT_MIRROR_ORIGIN_REFERENCE_MODELS[model] then return true end
    if mirrorOriginReferenceLookupTable("PA_mirror_origin_reference_models", model) then return true end
    if mirrorOriginReferenceLookupPrefix("PA_mirror_origin_reference_model_prefixes", model) then return true end

    return false
end

function PB.GetMirrorPlaneCenter(node)
    if not node then return Vector() end

    if PB.NodeUsesMirrorOriginReference and PB.NodeUsesMirrorOriginReference(node) then
        return node.worldPos or (IsValid(node.entity) and node.entity:GetPos()) or Vector()
    end

    if IsValid(node.entity) then
        return node.entity:LocalToWorld(node.entity:OBBCenter())
    end
    return node.worldPos or Vector()
end

local DEFAULT_MIRROR_EXCEPTIONS_SPECIFIC = {
    ["models/nova/airboat_seat.mdl"] = Angle(0, 0, 180),
    ["models/nova/chair_office01.mdl"] = Angle(0, 0, 180),
    ["models/nova/chair_office02.mdl"] = Angle(0, 0, 180),
    ["models/nova/jeep_seat.mdl"] = Angle(0, 0, 180),
}

local DEFAULT_MIRROR_EXCEPTIONS_PREFIX = {
    { "models/xeon133/racewheel/", Angle(0, 0, 180) },
    { "models/xeon133/racewheelskinny/", Angle(0, 0, 180) },
}

local function copyAngle(a)
    if not a then return nil end
    return Angle(a.p or a[1] or 0, a.y or a[2] or 0, a.r or a[3] or 0)
end

local function lookupMirrorException(model)
    model = string.lower(tostring(model or ""))

    if list and list.Get then
        local specific = list.Get("PA_mirror_exceptions_specific") or {}
        local found = specific[model]
        if found then return copyAngle(found) end

        local prefixes = list.Get("PA_mirror_exceptions") or {}
        for prefix, ang in pairs(prefixes) do
            prefix = string.lower(tostring(prefix or ""))
            if prefix ~= "" and string.sub(model, 1, #prefix) == prefix then
                return copyAngle(ang)
            end
        end
    end

    local found = DEFAULT_MIRROR_EXCEPTIONS_SPECIFIC[model]
    if found then return copyAngle(found) end

    for _, row in ipairs(DEFAULT_MIRROR_EXCEPTIONS_PREFIX) do
        local prefix, ang = row[1], row[2]
        if string.sub(model, 1, #prefix) == prefix then return copyAngle(ang) end
    end

    return Angle(180, 0, 0)
end

local function worldFromLocal(localPos, worldPos, worldAng)
    return worldPos
        + worldAng:Forward() * localPos.x
        + worldAng:Right() * localPos.y
        + worldAng:Up() * localPos.z
end

local function localFromWorld(worldPos, origin, ang)
    local d = worldPos - origin
    return Vector(d:Dot(ang:Forward()), d:Dot(ang:Right()), d:Dot(ang:Up()))
end

local function localToWorldAngle(localAng, worldAng, ent)
    if IsValid(ent) and ent.LocalToWorldAngles then
        return ent:LocalToWorldAngles(localAng)
    end

    if LocalToWorld then
        local _, outAng = LocalToWorld(Vector(), localAng, Vector(), worldAng)
        if outAng then return outAng end
    end

    local out = Angle(worldAng.p, worldAng.y, worldAng.r)
    out:RotateAroundAxis(out:Forward(), localAng.r or 0)
    out:RotateAroundAxis(out:Right(), localAng.p or 0)
    out:RotateAroundAxis(out:Up(), localAng.y or 0)
    return out
end

local function mirrorPointAcrossPlane(pos, planeOrigin, planeNormal)
    return pos + planeNormal * (planeNormal:Dot(planeOrigin - pos) * 2)
end

local function getMirrorReferencePoint(sourceNode, srcPos, srcAng)
    if PB.NodeUsesMirrorOriginReference and PB.NodeUsesMirrorOriginReference(sourceNode) then
        return srcPos, Vector()
    end

    local ent = sourceNode and sourceNode.entity
    if IsValid(ent) then
        local phys = ent:GetPhysicsObject()
        if IsValid(phys) and phys.GetMassCenter then
            local localMass = phys:GetMassCenter()
            return ent:LocalToWorld(localMass), localMass
        end

        local localCenter = ent:OBBCenter()
        return ent:LocalToWorld(localCenter), localCenter
    end

    local ref = sourceNode and (sourceNode.worldPos or srcPos) or srcPos
    return ref, localFromWorld(ref, srcPos, srcAng)
end

function PB.ComputeMirrorTransform(sourceNode, mirrorNode, axis)
    if not sourceNode or not mirrorNode then return nil, nil end

    axis = mirrorAxisName(axis)
    local normal = PB.GetMirrorPlaneNormal(mirrorNode, axis)
    local origin = PB.GetMirrorPlaneCenter and PB.GetMirrorPlaneCenter(mirrorNode) or (mirrorNode.worldPos or Vector())

    local ent = sourceNode.entity
    local srcPos = sourceNode.worldPos or (IsValid(ent) and ent:GetPos()) or Vector()
    local srcAng = sourceNode.worldAngle or (IsValid(ent) and ent:GetAngles()) or Angle()

    local refWorld, refLocal = getMirrorReferencePoint(sourceNode, srcPos, srcAng)
    local localCorrection = lookupMirrorException(IsValid(ent) and ent:GetModel() or sourceNode.model or "")

    local mirroredAng = localToWorldAngle(localCorrection, srcAng, ent)
    mirroredAng:RotateAroundAxis(normal, 180)

    local refAfterRotation = worldFromLocal(refLocal, srcPos, mirroredAng)
    local rotatedPos = srcPos + (refWorld - refAfterRotation)
    local mirroredRef = mirrorPointAcrossPlane(refWorld, origin, normal)
    local mirroredPos = rotatedPos + (mirroredRef - refWorld)

    return mirroredPos, mirroredAng
end

function PB.ApplyMirrorPConstraint(graph, pc)
    if not graph or not pc or pc.mode ~= "mirror" or pc.active == false then return false end
    local sourceNode = graph.nodes[pc.parentNodeID]
    local drivenNode = graph.nodes[pc.childNodeID]
    local mirrorNode = graph.nodes[pc.mirrorNodeID]
    if not sourceNode or not drivenNode or not mirrorNode then return false end
    if sourceNode.isPattern or drivenNode.isPattern or mirrorNode.isPattern then return false end

    local pos, ang = PB.ComputeMirrorTransform(sourceNode, mirrorNode, pc.mirrorAxis or pc.mirrorFace or "x")
    if not pos or not ang then return false end

    drivenNode.worldPos = Vector(pos.x, pos.y, pos.z)
    drivenNode.worldAngle = Angle(ang.p, ang.y, ang.r)

    if drivenNode.parentID and graph.nodes[drivenNode.parentID] then
        local parent = graph.nodes[drivenNode.parentID]
        local lp, la = WorldToLocal(drivenNode.worldPos, drivenNode.worldAngle, parent.worldPos, parent.worldAngle)
        drivenNode.localPos = Vector(lp.x, lp.y, lp.z)
        drivenNode.localAngle = Angle(la.p, la.y, la.r)
    else
        drivenNode.localPos = Vector(drivenNode.worldPos.x, drivenNode.worldPos.y, drivenNode.worldPos.z)
        drivenNode.localAngle = Angle(drivenNode.worldAngle.p, drivenNode.worldAngle.y, drivenNode.worldAngle.r)
    end

    drivenNode.isMirrorGenerated = true
    drivenNode.mirrorSourceNodeID = pc.parentNodeID
    drivenNode.mirrorPCID = pc.id







    if SERVER and IsValid(drivenNode.entity) then
        drivenNode.entity:SetPos(drivenNode.worldPos)
        drivenNode.entity:SetAngles(drivenNode.worldAngle)
        local phys = drivenNode.entity:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(false)
            phys:Sleep()
        end
    end

    return true
end

function PB.ApplyMirrorPConstraints(graph)
    if not graph or not graph.pconstraints then return end
    local list = {}
    for _, pc in pairs(graph.pconstraints) do
        if pc.mode == "mirror" and pc.active ~= false then list[#list + 1] = pc end
    end
    table.sort(list, function(a, b) return (a.id or 0) < (b.id or 0) end)
    for _ = 1, math.max(1, #list) do
        local changed = false
        for _, pc in ipairs(list) do
            changed = PB.ApplyMirrorPConstraint(graph, pc) or changed
        end
        if not changed then break end
    end
end





function PB.MeasurePConstraint(graph, pc)
    local pn = graph.nodes[pc.parentNodeID]
    local cn = graph.nodes[pc.childNodeID]
    if pc and pc.mode == "mirror" then
        if not pn or not cn then return nil end
        local pPos = pn.worldPos or (IsValid(pn.entity) and pn.entity:GetPos()) or Vector()
        local cPos = cn.worldPos or (IsValid(cn.entity) and cn.entity:GetPos()) or Vector()
        return {
            dist = pPos:Distance(cPos),
            midpoint = (pPos + cPos) * 0.5,
            label = "Mirror " .. string.upper(tostring(pc.mirrorAxis or pc.mirrorFace or "x")),
            parentPos = pPos,
            childPos = cPos,
        }
    end
    if not pn or not cn or not IsValid(pn.entity) or not IsValid(cn.entity) then return nil end
    local pFrac = PB.EvalPCParam(graph, pc.parentFraction)
    local cFrac = PB.EvalPCParam(graph, pc.childFraction)
    local pPos = PB.GetFeatureWorldPosFromNode(pn, pc.parentFeature, pFrac)
    local cPos = PB.GetFeatureWorldPosFromNode(cn, pc.childFeature, cFrac)
    local dist = pPos:Distance(cPos)
    return {
        dist = dist,
        midpoint = (pPos + cPos) * 0.5,
        label = string.format("%.1f", dist),
        parentPos = pPos,
        childPos = cPos,
    }
end




















function PB.NewPConstraint(graph, referenceNodeID, drivenNodeID, parentFeature, childFeature, mode)
    if referenceNodeID == drivenNodeID then return nil end
    if not graph.nodes[referenceNodeID] or not graph.nodes[drivenNodeID] then return nil end



    local driven = graph.nodes[drivenNodeID]
    local reference = graph.nodes[referenceNodeID]
    local drivenIsRoot  = not driven.parentID or not graph.nodes[driven.parentID]
    local refIsRoot     = not reference.parentID or not graph.nodes[reference.parentID]
    if drivenIsRoot and not refIsRoot then
        referenceNodeID, drivenNodeID = drivenNodeID, referenceNodeID
        parentFeature, childFeature = childFeature, parentFeature
    end

    local id = graph.nextPCID
    local pc = {
        id = id,
        parentNodeID = referenceNodeID,
        childNodeID = drivenNodeID,
        parentFeature = parentFeature,
        childFeature = childFeature,
        mode = mode or "geometric",
        offset = 0,
        parentFraction = 0.5,
        childFraction = 0.5,
        distance = 100,
        mirrorNodeID = nil,
        mirrorFace = nil,
        mirrorAxis = nil,
        active = true,
        flipped = false,
        crossLink = false,
        slideX = 0, slideY = 0, angle = 0,
        branchParentSide = 1,
        branchChildSide = 1,
        solverResidual = 0,
        solverSatisfied = true,
    }
    graph.pconstraints[id] = pc
    graph.nextPCID = id + 1
    return pc
end

function PB.RemovePConstraint(graph, pcid)
    graph.pconstraints[pcid] = nil

end

function PB.RemovePConstraintsForNode(graph, nodeID)
    local toRemove = {}
    for pcid, pc in pairs(graph.pconstraints) do
        if pc.parentNodeID == nodeID or pc.childNodeID == nodeID then
            table.insert(toRemove, pcid)
        end
    end
    for _, pcid in ipairs(toRemove) do graph.pconstraints[pcid] = nil end

end


function PB.GetPConstraintsForChild(graph, childNodeID)
    local result = {}
    for _, pc in pairs(graph.pconstraints) do
        if pc.childNodeID == childNodeID and pc.active then
            table.insert(result, pc)
        end
    end
    table.sort(result, function(a, b) return a.id < b.id end)
    return result
end


function PB.GetCrossLinksForNode(graph, nodeID)
    return {}
end


function PB.GetAllActivePConstraints(graph)
    local result = {}
    for _, pc in pairs(graph.pconstraints) do
        if pc.active then table.insert(result, pc) end
    end
    table.sort(result, function(a, b) return a.id < b.id end)
    return result
end


function PB.GetAllPConstraintsForChild(graph, childNodeID)
    return PB.GetPConstraintsForChild(graph, childNodeID)
end

function PB.GetPConstraintList(graph)
    local result = {}
    for _, pc in pairs(graph.pconstraints) do table.insert(result, pc) end
    table.sort(result, function(a, b) return a.id < b.id end)
    return result
end





function PB.GetPCGeometricMode(pc)
    return pc.parentFeature.type .. "_" .. pc.childFeature.type
end

local CFG = PB.Config or {}
local STR = CFG.Strings or {}
local PC_STR = STR.PConstraints or {}
local SOLVER_SUMMARY_STR = STR.SolverSummary or {}
local COL = CFG.Colors or {}
PB.PC_COLORS = COL.constraintModes or {}

function PB.GetPCColor(pc)
    if pc.mode == "distance" then return PB.PC_COLORS.distance end
    if pc.mode == "planar" then return PB.PC_COLORS.planar end
    if pc.mode == "mirror" then return PB.PC_COLORS.mirror end
    if pc.mode == "symmetry" then return PB.PC_COLORS.symmetry end
    if pc.mode == "parallel" then return PB.PC_COLORS.parallel end
    if pc.mode == "perpendicular" then return PB.PC_COLORS.perpendicular end
    return PB.PC_COLORS[PB.GetPCGeometricMode(pc)] or PB.PC_COLORS.fallback
end




function PB.GetPCDOF(pc)
    if pc and pc.mode == "mirror" then
        return { desc = PC_STR.mirrorOutputNote }
    end

    if pc and pc.mode == "planar" and pc.parentFeature and pc.childFeature then
        local a, b = pc.parentFeature.type, pc.childFeature.type
        if a == "face" and b == "face" then
            return { desc = "2 rot DOFs locked. 1 pos DOF locked. The faces share the same infinite plane; sliding and spin within that plane remain free." }
        elseif (a == "edge" and b == "face") or (a == "face" and b == "edge") then
            return { desc = "1 rot DOF locked. 1 pos DOF locked. The edge stays in the selected face plane." }
        end
        return { desc = "1 pos DOF locked. The selected point stays on the selected face plane; rotations remain free." }
    end

    if not PB._ConstraintRegistry or not PB._RegKey then
        return { desc = "Solver not loaded." }
    end

    if pc and pc.mode == "geometric" and pc.parentFeature and pc.childFeature
        and pc.parentFeature.type == "edge" and pc.childFeature.type == "edge" then
        return { desc = "2 rot DOFs locked. 2 pos DOFs locked. In-plane spin and slide along the parent edge remain free." }
    end

    local key
    if pc.mode == "distance" then key = "distance"
    elseif pc.mode == "symmetry" then key = "symmetry"
    else key = PB._RegKey(pc.mode, pc.parentFeature.type, pc.childFeature.type) end

    local def = PB._ConstraintRegistry[key]
    if not def then return { desc = "Unknown constraint type." } end

    local parts = {}
    if def.dofRot > 0 then table.insert(parts, def.dofRot .. " rot DOF" .. (def.dofRot > 1 and "s" or "") .. " locked") end
    if def.dofPos > 0 then table.insert(parts, def.dofPos .. " pos DOF" .. (def.dofPos > 1 and "s" or "") .. " locked") end
    if def.dofRot == 0 then table.insert(parts, "All rotations free") end
    if def.dofPos == 0 then table.insert(parts, "All positions free") end
    return { desc = table.concat(parts, ". ") .. "." }
end




function PB.GetPCLockedAxes(pc, graph)
    local result = { pos = {}, ang = {} }

    if pc and pc.mode == "mirror" then
        return { pos = {"x", "y", "z"}, ang = {"p", "y", "r"} }
    end

    local FACE_AXIS     = { ["+x"] = "x", ["-x"] = "x", ["+y"] = "y", ["-y"] = "y", ["+z"] = "z", ["-z"] = "z" }
    local FACE_FREE_ANG = { ["+x"] = "r", ["-x"] = "r", ["+y"] = "p", ["-y"] = "p", ["+z"] = "y", ["-z"] = "y" }
    local ALL_POS = {"x","y","z"}
    local ALL_ANG = {"p","y","r"}





    local function physFaceAxisHint(nodeID, featureID)
        if not isPhysID(featureID) then return nil end
        local n = graph.nodes[nodeID]
        if not n or not IsValid(n.entity) then return nil end
        local normal = PB.GetFaceLocalNormal(n.entity, featureID)
        local ax, ay, az = math.abs(normal.x), math.abs(normal.y), math.abs(normal.z)
        if ax >= ay and ax >= az then return "x"
        elseif ay >= az then return "y" end
        return "z"
    end

    local function physFaceFreeAng(nodeID, featureID)
        local axis = physFaceAxisHint(nodeID, featureID)
        if axis == "x" then return "r"
        elseif axis == "y" then return "p"
        elseif axis == "z" then return "y" end
        return "y"
    end

    local function EdgeDominantAxis(nodeID, featureID)
        local n = graph.nodes[nodeID]
        if not n or not IsValid(n.entity) then return "z" end
        local dir = PB.GetEdgeLocalDir(n.entity, featureID)
        if math.abs(dir.x) > math.abs(dir.y) and math.abs(dir.x) > math.abs(dir.z) then return "x"
        elseif math.abs(dir.y) > math.abs(dir.z) then return "y" end
        return "z"
    end


    if pc and pc.mode == "planar" and pc.parentFeature and pc.childFeature then
        local faceSide = pc.parentFeature.type == "face" and "parent" or (pc.childFeature.type == "face" and "child" or nil)
        if faceSide then
            local nodeID = faceSide == "parent" and pc.parentNodeID or pc.childNodeID
            local feature = faceSide == "parent" and pc.parentFeature or pc.childFeature
            local axis = isPhysID(feature.id) and physFaceAxisHint(nodeID, feature.id) or FACE_AXIS[feature.id]
            if axis then table.insert(result.pos, axis) end

            if pc.parentFeature.type == "face" and pc.childFeature.type == "face" then
                local freeAng = isPhysID(feature.id) and physFaceFreeAng(nodeID, feature.id) or (FACE_FREE_ANG[feature.id] or "y")
                for _, ax in ipairs(ALL_ANG) do
                    if ax ~= freeAng then table.insert(result.ang, ax) end
                end
            elseif pc.parentFeature.type == "edge" or pc.childFeature.type == "edge" then
                local edgeNodeID = pc.parentFeature.type == "edge" and pc.parentNodeID or pc.childNodeID
                local edgeID = pc.parentFeature.type == "edge" and pc.parentFeature.id or pc.childFeature.id
                local dominant = EdgeDominantAxis(edgeNodeID, edgeID)
                local rotAxis = ({ x = "r", y = "p", z = "y" })[dominant] or "y"
                table.insert(result.ang, rotAxis)
            end
        end
        return result
    end


    if pc and pc.mode == "geometric" and pc.parentFeature and pc.childFeature
        and pc.parentFeature.type == "edge" and pc.childFeature.type == "edge" then
        local dominant = EdgeDominantAxis(pc.parentNodeID, pc.parentFeature.id)
        local freePos = dominant
        for _, ax in ipairs(ALL_POS) do
            if ax ~= freePos then table.insert(result.pos, ax) end
        end
        local freeAng = ({ x = "r", y = "p", z = "y" })[dominant] or "y"
        for _, ax in ipairs(ALL_ANG) do
            if ax ~= freeAng then table.insert(result.ang, ax) end
        end
        return result
    end


    if not PB._ConstraintRegistry or not PB._RegKey then return result end

    local key
    if pc.mode == "distance" then key = "distance"
    elseif pc.mode == "symmetry" then key = "symmetry"
    else key = PB._RegKey(pc.mode, pc.parentFeature.type, pc.childFeature.type) end

    local def = PB._ConstraintRegistry[key]
    if not def then return result end


    if pc.mode == "symmetry" or pc.mode == "mirror" then return { pos = {"x","y","z"}, ang = {"p","y","r"} } end



    local pType = pc.parentFeature.type


    if def.dofPos > 0 then
        if def.dofPos >= 3 then
            result.pos = {"x","y","z"}
        elseif pType == "face" then
            local axis = isPhysID(pc.parentFeature.id)
                and physFaceAxisHint(pc.parentNodeID, pc.parentFeature.id)
                or FACE_AXIS[pc.parentFeature.id]
            if axis then table.insert(result.pos, axis) end
        elseif pType == "edge" then
            local freeAxis = EdgeDominantAxis(pc.parentNodeID, pc.parentFeature.id)
            for _, ax in ipairs(ALL_POS) do
                if ax ~= freeAxis then table.insert(result.pos, ax) end
            end
        elseif pType == "corner" then
            result.pos = {"x","y","z"}
        end
    end


    if def.dofRot > 0 then
        if def.dofRot >= 3 then
            result.ang = {"p","y","r"}
        elseif def.dofRot == 2 then

            local freeAng
            if pType == "face" then
                if isPhysID(pc.parentFeature.id) then
                    freeAng = physFaceFreeAng(pc.parentNodeID, pc.parentFeature.id)
                else
                    freeAng = FACE_FREE_ANG[pc.parentFeature.id] or "y"
                end
            else
                local dominant = EdgeDominantAxis(pc.parentNodeID, pc.parentFeature.id)
                freeAng = ({ x = "r", y = "p", z = "y" })[dominant] or "y"
            end
            for _, ax in ipairs(ALL_ANG) do
                if ax ~= freeAng then table.insert(result.ang, ax) end
            end
        elseif def.dofRot == 1 then

            local lockedAng
            if pType == "face" then
                if isPhysID(pc.parentFeature.id) then
                    lockedAng = physFaceFreeAng(pc.parentNodeID, pc.parentFeature.id)
                else
                    lockedAng = FACE_FREE_ANG[pc.parentFeature.id]
                end
            else
                local dominant = EdgeDominantAxis(pc.parentNodeID, pc.parentFeature.id)
                lockedAng = ({ x = "r", y = "p", z = "y" })[dominant] or "y"
            end
            if lockedAng then table.insert(result.ang, lockedAng) end
        end
    end

    return result
end

function PB.GetPCEditParams(pc)
    if pc.mode == "distance" then return {{ key = "distance", label = PC_STR.targetDistance }} end
    if pc.mode == "mirror" then return {} end
    if pc.mode == "symmetry" then return {} end
    if pc.mode == "parallel" then return {} end
    if pc.mode == "perpendicular" then return {} end
    local pType, cType = pc.parentFeature.type, pc.childFeature.type
    if pType == "corner" and cType == "corner" then return {} end

    local params = {{ key = "offset", label = PC_STR.offsetLift }}
    if pType == "edge" then table.insert(params, { key = "parentFraction", label = PC_STR.parentEdgePos }) end
    if cType == "edge" then table.insert(params, { key = "childFraction", label = PC_STR.childEdgePos }) end
    return params
end

function PB.GetPCEdgeBranchFace(pc, which)
    if not pc or pc.mode ~= "geometric" then return nil end
    if not pc.parentFeature or not pc.childFeature then return nil end
    if pc.parentFeature.type ~= "edge" or pc.childFeature.type ~= "edge" then return nil end

    local edgeID, sideIndex
    if which == "parent" then
        edgeID = pc.parentFeature.id
        sideIndex = pc.branchParentSide
    else
        edgeID = pc.childFeature.id
        sideIndex = pc.branchChildSide
    end

    local faces = PB.GetEdgeAdjacentFaces(edgeID)
    if not faces then return nil end
    sideIndex = math.Clamp(math.floor(tonumber(sideIndex) or 1), 1, #faces)
    return faces[sideIndex]
end

function PB.GetPCEdgeBranchFaceLabel(pc, which)

    local feature = which == "parent" and pc.parentFeature or pc.childFeature
    if feature and isPhysID(feature.id) then
        local side = which == "parent" and pc.branchParentSide or pc.branchChildSide
        return PC_STR.sidePrefix .. tostring(math.Clamp(math.floor(tonumber(side) or 1), 1, 2))
    end
    local faceID = PB.GetPCEdgeBranchFace(pc, which)
    if not faceID then return PC_STR.unknown end
    return PB.FACE_NAMES[faceID] or faceID
end

function PB.DescribePConstraint(pc, graph)
    local pn = graph.nodes[pc.parentNodeID]
    local cn = graph.nodes[pc.childNodeID]
    local pLabel = pn and pn.label or PC_STR.unknown
    local cLabel = cn and cn.label or PC_STR.unknown
    local function featureName(f)
        if f.type == "face" then


            if isPhysID(f.id) then return PC_STR.facePrefix .. tostring(f.id:sub(3)) end
            return PB.FACE_NAMES[f.id] or f.id
        elseif f.type == "edge" then
            if isPhysID(f.id) then return PC_STR.edgePrefix .. tostring(f.id:sub(3)) end
            return PB.EDGE_NAMES[f.id] or (PC_STR.edgePrefix .. tostring(f.id))
        elseif f.type == "corner" then
            if isPhysID(f.id) then return PC_STR.cornerPrefix .. tostring(f.id:sub(3)) end
            return PB.CORNER_NAMES[f.id] or (PC_STR.pointPrefix .. tostring(f.id))
        end
        return PC_STR.unknown
    end
    local prefix = ""
    if pc.mode == "mirror" then
        local mn = pc.mirrorNodeID and graph.nodes[pc.mirrorNodeID] or nil
        local mLabel = mn and mn.label or PC_STR.unknown
        local axis = string.upper(tostring(pc.mirrorAxis or pc.mirrorFace or "x"))
        return pLabel .. " -> " .. cLabel .. " [MIRROR " .. axis .. " @ " .. mLabel .. "]"
    end
    if pc.mode == "symmetry" then return pLabel .. " <> " .. cLabel .. " [SYM]" end
    if pc.mode == "distance" then return pLabel .. " <> " .. cLabel .. " [DIST]" end
    if pc.mode == "planar" then return prefix .. pLabel .. " [" .. featureName(pc.parentFeature) .. "] > " .. cLabel .. " [" .. featureName(pc.childFeature) .. "] [PLANAR]" end
    local modeTag = ""
    if pc.mode == "parallel" then modeTag = " ∥"
    elseif pc.mode == "perpendicular" then modeTag = " ⊥" end
    return prefix .. pLabel .. " [" .. featureName(pc.parentFeature) .. "] > " .. cLabel .. " [" .. featureName(pc.childFeature) .. "]" .. modeTag
end







function PB.GetValidModes(parentType, childType)
    local modes = { "geometric" }
    local hasParentDir = (parentType == "face" or parentType == "edge")
    local hasChildDir  = (childType == "face" or childType == "edge")
    if hasParentDir and hasChildDir then
        table.insert(modes, "parallel")
        table.insert(modes, "perpendicular")
    end
    if parentType == "face" or childType == "face" then
        table.insert(modes, "planar")
    end
    return modes
end


function PB.IsModeValidForFeatures(mode, parentType, childType)
    if mode == "geometric" or mode == "distance" or mode == "symmetry" or mode == "mirror" then return true end
    for _, m in ipairs(PB.GetValidModes(parentType, childType)) do
        if m == mode then return true end
    end
    return false
end


PB.MODE_NAMES = STR.ModeNames




PB.SOLVER_STATUS_COLORS = COL.solverStatus or {}

PB.SOLVER_STATUS_LABELS = STR.SolverStatus

function PB.GetSolverStatusColor(graph)
    local diag = graph.solverDiagnostic
    if not diag then return PB.SOLVER_STATUS_COLORS.unknown end
    return PB.SOLVER_STATUS_COLORS[diag.status] or PB.SOLVER_STATUS_COLORS.unknown
end

function PB.GetSolverStatusLabel(graph)
    local diag = graph.solverDiagnostic
    if not diag then return (STR.SolverStatus and STR.SolverStatus.unknown) end
    return PB.SOLVER_STATUS_LABELS[diag.status] or diag.status
end

function PB.GetSolverSummary(graph)
    local diag = graph.solverDiagnostic
    if not diag then return "" end
    local parts = {
        PB.SOLVER_STATUS_LABELS[diag.status] or diag.status,
        string.format(SOLVER_SUMMARY_STR.equationsUnknowns, diag.numEquations, diag.numUnknowns),
    }
    if diag.iterations > 0 then
        local branchText = (diag.branchAttempts and diag.branchAttempts > 0) and (SOLVER_SUMMARY_STR.branchTriesPrefix .. tostring(diag.branchAttempts)) or ""
        table.insert(parts, string.format(SOLVER_SUMMARY_STR.iterationsResidual, diag.iterations, diag.residualNorm, branchText))
    end
    if diag.attemptStatus or diag.modelStatus then
        table.insert(parts, string.format(SOLVER_SUMMARY_STR.modelAttempt, tostring(diag.modelStatus or PC_STR.unknown), tostring(diag.attemptStatus or PC_STR.unknown)))
    end
    if #diag.overConstrained > 0 then
        local ids = {}
        for _, oc in ipairs(diag.overConstrained) do
            table.insert(ids, "PC#" .. oc.pcid)
        end
        table.insert(parts, (SOLVER_SUMMARY_STR.conflictsPrefix or PC_STR.conflictsPrefix) .. table.concat(ids, ", "))
    end
    return table.concat(parts, "\n")
end

function PB.GetPCSolverColor(pc)
    if not pc.solverSatisfied then return (COL.solverStatus and COL.solverStatus.over_constrained) end
    local wr = tonumber(pc.solverWeightedResidual) or tonumber(pc.solverResidual) or 0
    if wr > 0.01 then return COL.warning end
    return nil
end





if SERVER then

function PB.ApplyConstraint(childEnt, parentEnt, cType, params)
    if not IsValid(childEnt) or not IsValid(parentEnt) then return nil end
    cType = cType or "none"
    if cType == "none" then return nil end
    params = params or {}
    local cA, pA = Vector(), parentEnt:WorldToLocal(childEnt:GetPos())
    local created = nil
    if cType == "weld" then
        created = constraint.Weld(childEnt, parentEnt, 0, 0, params.forcelimit or 0, (tonumber(params.nocollide) or 0) ~= 0)
    elseif cType == "axis" then
        created = constraint.Axis(childEnt, parentEnt, 0, 0, cA, pA, params.forcelimit or 0, params.torquelimit or 0, params.friction or 0, tonumber(params.nocollide) or 0)
    elseif cType == "ballsocket" then
        created = constraint.Ballsocket(childEnt, parentEnt, 0, 0, pA, params.forcelimit or 0, params.torquelimit or 0, tonumber(params.nocollide) or 0)
    elseif cType == "advballsocket" then
        created = constraint.AdvBallsocket(childEnt, parentEnt, 0, 0, cA, pA,
            params.forcelimit or 0, params.torquelimit or 0,
            params.xmin or -180, params.ymin or -180, params.zmin or -180,
            params.xmax or 180, params.ymax or 180, params.zmax or 180,
            params.xfric or 0, params.yfric or 0, params.zfric or 0,
            tonumber(params.onlyrotation) or 0, tonumber(params.nocollide) or 0)
    elseif cType == "slider" then
        created = constraint.Slider(childEnt, parentEnt, 0, 0, cA, pA, params.width or 1)
    elseif cType == "rope" then
        local len = params.length
        if not len or len <= 0 then len = childEnt:GetPos():Distance(parentEnt:GetPos()) end
        created = constraint.Rope(childEnt, parentEnt, 0, 0, cA, pA, len, params.addlength or 0, params.forcelimit or 0, params.width or 1, params.material or "cable/rope", (tonumber(params.rigid) or 0) ~= 0)
    elseif cType == "elastic" then
        created = constraint.Elastic(childEnt, parentEnt, 0, 0, cA, pA, params.constant or 100, params.damping or 0, params.rdamping or 0, params.material or "cable/rope", params.width or 1, (tonumber(params.stretchonly) or 0) ~= 0)
    elseif cType == "nocollide" then
        created = constraint.NoCollide(childEnt, parentEnt, 0, 0)
    elseif cType == "parent" then
        childEnt:SetParent(parentEnt)
        return nil
    end
    if PB.MarkRuntimeConstraintEnt then PB.MarkRuntimeConstraintEnt(created, "NodeConstraint", nil) end
    return created
end

function PB.ClearConstraint(node)
    if not node then return end
    if IsValid(node.constraintEnt) then node.constraintEnt:Remove() end
    node.constraintEnt = nil
    if node.constraintType == "parent" and IsValid(node.entity) then
        node.entity:SetParent(nil)
        node.entity:SetMoveType(MOVETYPE_VPHYSICS)
    end
end

function PB.RebuildConstraints(graph, nodeOrder)
    if PB.GraphAutoManageEnabled and not PB.GraphAutoManageEnabled(graph) then return end
    for _, nid in ipairs(nodeOrder or PB.TreeOrder(graph)) do
        local node = graph.nodes[nid]
        if node and node.parentID and not node.isPattern then
            local parent = graph.nodes[node.parentID]
            if parent and not parent.isPattern and IsValid(node.entity) and IsValid(parent.entity) then
                PB.ClearConstraint(node)
                node.constraintEnt = PB.ApplyConstraint(node.entity, parent.entity, node.constraintType, node.constraintParams)
            end
        end
    end
end

end










if CLIENT then return end





function PB.RegeneratePattern(graph, patternID)
    local pat = graph.nodes[patternID]
    if not pat or not pat.isPattern then return end
    local sourceNode = graph.nodes[pat.parentID]
    if not sourceNode then return end
    for _, ent in ipairs(pat.patternEntities) do if IsValid(ent) then ent:Remove() end end
    for _, cEnt in ipairs(pat.patternConstraints) do if IsValid(cEnt) then cEnt:Remove() end end
    pat.patternEntities = {}
    pat.patternConstraints = {}
    local sourceEnt = sourceNode.entity
    if not IsValid(sourceEnt) then return end
    local model = sourceEnt:GetModel()
    local srcPos, srcAng = sourceNode.worldPos, sourceNode.worldAngle
    local params = pat.patternParams or {}
    local pivot = Vector()
    local pivotNodeID = params.pivotNodeID
    if pivotNodeID and graph.nodes[pivotNodeID] and pivotNodeID ~= pat.parentID then
        pivot = WorldToLocal(graph.nodes[pivotNodeID].worldPos, Angle(), srcPos, srcAng)
    end
    local po = params.pivotOffset
    if po then pivot = pivot + Vector(po.x or 0, po.y or 0, po.z or 0) end
    for _, entry in ipairs(PB.ComputePatternOffsets(pat.patternType, params)) do
        local wp, wa = LocalToWorld(pivot + entry.offset, entry.angle, srcPos, srcAng)
        local ent = ents.Create("prop_physics")
        ent:SetModel(model); ent:SetPos(wp); ent:SetAngles(wa); ent:Spawn()
        if PB.GraphAutoManageEnabled(graph) then
            local phys = ent:GetPhysicsObject()
            if IsValid(phys) then phys:EnableMotion(false) end
        end
        table.insert(pat.patternEntities, ent)
        if pat.copyConstraints and pat.patternConstraintType ~= "none" then
            local cEnt = PB.ApplyConstraint(ent, sourceEnt, pat.patternConstraintType, pat.patternConstraintParams)
            if IsValid(cEnt) then table.insert(pat.patternConstraints, cEnt) end
        end
    end
end





function PB.ComputePatternOffsets(patternType, params)
    local offsets = {}
    if patternType == "linear" then
        local dir = params.direction or Vector(1, 0, 0)
        local count = params.count or 3
        local spacing = params.spacing or 50
        for i = 1, count do
            table.insert(offsets, { offset = dir * spacing * i, angle = Angle() })
        end
    elseif patternType == "circular" then
        local count = params.count or 6
        local radius = params.radius or 100
        local axis = params.axis or "z"
        local step = 360 / count
        local fwd, rt
        if axis == "z" then fwd, rt = Vector(1,0,0), Vector(0,1,0)
        elseif axis == "y" then fwd, rt = Vector(1,0,0), Vector(0,0,1)
        else fwd, rt = Vector(0,1,0), Vector(0,0,1) end
        for i = 1, count - 1 do
            local deg = step * i
            local rad = math.rad(deg)
            local off = fwd * math.cos(rad) * radius + rt * math.sin(rad) * radius - fwd * radius
            local ang = Angle()
            if axis == "z" then ang = Angle(0, deg, 0)
            elseif axis == "y" then ang = Angle(0, 0, deg)
            else ang = Angle(deg, 0, 0) end
            table.insert(offsets, { offset = off, angle = ang })
        end
    elseif patternType == "grid" then
        local cols = params.cols or 3
        local rows = params.rows or 3
        local sx = params.spacingX or 50
        local sy = params.spacingY or 50
        for col = 0, cols - 1 do
            for row = 0, rows - 1 do
                if col ~= 0 or row ~= 0 then
                    table.insert(offsets, { offset = Vector(col * sx, row * sy, 0), angle = Angle() })
                end
            end
        end
    elseif patternType == "helix" then
        local count = params.count or 12
        local radius = params.radius or 80
        local rise = params.rise or 15
        local turns = params.turns or 1
        for i = 1, count do
            local t = i / count
            local rad = math.rad(turns * 360 * t)
            table.insert(offsets, {
                offset = Vector(math.cos(rad) * radius - radius, math.sin(rad) * radius, rise * i),
                angle = Angle(0, math.deg(rad), 0),
            })
        end
    elseif patternType == "arc" then
        local count = params.count or 8
        local radius = params.radius or 100
        local arcDeg = params.arcDeg or 180
        local axis = params.axis or "z"
        for i = 1, count - 1 do
            local t = i / (count - 1)
            local rad = math.rad(arcDeg * t)
            local off, ang
            if axis == "z" then
                off = Vector(math.cos(rad) * radius - radius, math.sin(rad) * radius, 0)
                ang = Angle(0, math.deg(rad), 0)
            elseif axis == "y" then
                off = Vector(math.cos(rad) * radius - radius, 0, math.sin(rad) * radius)
                ang = Angle(0, 0, math.deg(rad))
            else
                off = Vector(0, math.cos(rad) * radius - radius, math.sin(rad) * radius)
                ang = Angle(math.deg(rad), 0, 0)
            end
            table.insert(offsets, { offset = off, angle = ang })
        end
    end
    return offsets
end


