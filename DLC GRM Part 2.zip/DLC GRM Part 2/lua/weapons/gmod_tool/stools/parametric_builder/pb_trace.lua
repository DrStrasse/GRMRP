









PB = PB or {}
PB.Trace = PB.Trace or {}
local Trace = PB.Trace

local CFG = PB.Config or {}
local LOGCFG = CFG.Logging or {}
local PREFIX = CFG.CommandPrefix or "parametric_builder_"
local REALM = SERVER and "server" or "client"

local function convarDef(key, fallbackName, fallbackDefault, fallbackHelp)
    local def = ((CFG.ConVars or {})[key]) or {}
    return def.name or fallbackName, def.default or fallbackDefault, def.help or fallbackHelp
end

local cvName, cvDefault, cvHelp = convarDef("fileLogEnabled", PREFIX .. "file_log_enabled", LOGCFG.enabledDefault == false and "0" or "1", (CFG.ConVars.fileLogEnabled or {}).help)
local cvEnabled = CreateConVar and CreateConVar(cvName, cvDefault, FCVAR_ARCHIVE, cvHelp) or nil
cvName, cvDefault, cvHelp = convarDef("fileLogConsole", PREFIX .. "file_log_console", LOGCFG.consoleMirrorDefault and "1" or "0", (CFG.ConVars.fileLogConsole or {}).help)
local cvConsole = CreateConVar and CreateConVar(cvName, cvDefault, FCVAR_ARCHIVE, cvHelp) or nil
cvName, cvDefault, cvHelp = convarDef("fileLogPayloadMaxDepth", PREFIX .. "file_log_max_depth", tostring(LOGCFG.maxDepth or 7), (CFG.ConVars.fileLogPayloadMaxDepth or {}).help)
local cvMaxDepth = CreateConVar and CreateConVar(cvName, cvDefault, FCVAR_ARCHIVE, cvHelp) or nil
cvName, cvDefault, cvHelp = convarDef("fileLogPayloadMaxItems", PREFIX .. "file_log_max_items", tostring(LOGCFG.maxItems or 160), (CFG.ConVars.fileLogPayloadMaxItems or {}).help)
local cvMaxItems = CreateConVar and CreateConVar(cvName, cvDefault, FCVAR_ARCHIVE, cvHelp) or nil

local logPath = nil
local seq = 0

local function nowWall()
    return os.date("!%Y-%m-%dT%H:%M:%SZ")
end

local function nowLocalForFile()
    return os.date("%Y%m%d_%H%M%S")
end

local function runtimeClock()
    if SysTime then return SysTime() end
    if CurTime then return CurTime() end
    return os.clock()
end

local function isEnabled()
    if cvEnabled then return cvEnabled:GetBool() end
    return LOGCFG.enabledDefault ~= false
end

local function mirrorConsole()
    if cvConsole then return cvConsole:GetBool() end
    return LOGCFG.consoleMirrorDefault == true
end

local function maxDepth()
    if cvMaxDepth then return math.max(1, cvMaxDepth:GetInt()) end
    return LOGCFG.maxDepth or 7
end

local function maxItems()
    if cvMaxItems then return math.max(16, cvMaxItems:GetInt()) end
    return LOGCFG.maxItems or 160
end

local function ensureLogPath()
    if logPath then return logPath end
    local base = LOGCFG.directory or "parametric_builder/logs"
    local prefix = LOGCFG.filePrefix or "pb_trace"
    if file and file.CreateDir then
        file.CreateDir("parametric_builder")
        file.CreateDir("parametric_builder/logs")
    end
    local suffix = nowLocalForFile() .. "_" .. REALM
    logPath = string.format("%s/%s_%s.txt", base, prefix, suffix)
    if file and file.Write then
        file.Write(logPath, string.format("# %s detailed log\n# realm=%s utc=%s\n", CFG.AddonName or CFG.AddonName, REALM, nowWall()))
    end
    return logPath
end

function Trace.GetPath()

    return logPath
end

function Trace.IsEnabled()
    return isEnabled()
end

function Trace.NextSeq()
    seq = seq + 1
    return seq
end

local function round(n)
    n = tonumber(n)
    if not n then return nil end
    if math.abs(n) < 1e-12 then n = 0 end
    return tonumber(string.format("%.9g", n))
end

function Trace.Vector(v)
    if not v then return nil end
    return { x = round(v.x), y = round(v.y), z = round(v.z) }
end

function Trace.Angle(a)
    if not a then return nil end
    return { p = round(a.p), y = round(a.y), r = round(a.r) }
end

function Trace.Player(ply)
    if not ply then return nil end
    local okValid = (IsValid and IsValid(ply)) or false
    local out = { valid = okValid }
    if ply.Nick then out.name = ply:Nick() end
    if ply.SteamID then out.steamID = ply:SteamID() end
    if ply.UserID then out.userID = ply:UserID() end
    return out
end

function Trace.Entity(ent)
    if not ent then return nil end
    local okValid = (IsValid and IsValid(ent)) or false
    local out = { valid = okValid }
    if ent.EntIndex then out.index = ent:EntIndex() end
    if ent.GetClass then out.class = ent:GetClass() end
    if ent.GetModel then out.model = ent:GetModel() end
    if ent.GetPos then out.pos = Trace.Vector(ent:GetPos()) end
    if ent.GetAngles then out.ang = Trace.Angle(ent:GetAngles()) end
    return out
end

function Trace.Feature(feature)
    if not feature then return nil end
    local out = {}
    for k, v in pairs(feature) do
        if k == "pos" or k == "origin" or k == "normal" or k == "dir" then
            out[k] = Trace.Vector(v)
        else
            out[k] = v
        end
    end
    return out
end

function Trace.Node(node)
    if not node then return nil end
    return {
        id = node.id,
        label = node.label,
        parentID = node.parentID,
        model = node.model,
        locked = node.locked == true,
        visible = node.visible ~= false,
        isPattern = node.isPattern == true,
        localPos = Trace.Vector(node.localPos),
        localAngle = Trace.Angle(node.localAngle),
        worldPos = Trace.Vector(node.worldPos),
        worldAngle = Trace.Angle(node.worldAngle),
        exprPos = node.exprPos,
        exprAngle = node.exprAngle,
        snapParentFace = node.snapParentFace,
        snapChildFace = node.snapChildFace,
        snapGap = node.snapGap,
        entity = Trace.Entity(node.entity),
    }
end

function Trace.PConstraint(pc, graph)
    if not pc then return nil end
    return {
        id = pc.id,
        active = pc.active ~= false,
        mode = pc.mode,
        parentNodeID = pc.parentNodeID,
        childNodeID = pc.childNodeID,
        parentLabel = graph and graph.nodes and graph.nodes[pc.parentNodeID] and graph.nodes[pc.parentNodeID].label or nil,
        childLabel = graph and graph.nodes and graph.nodes[pc.childNodeID] and graph.nodes[pc.childNodeID].label or nil,
        parentFeature = Trace.Feature(pc.parentFeature),
        childFeature = Trace.Feature(pc.childFeature),
        parentFraction = pc.parentFraction,
        childFraction = pc.childFraction,
        offset = pc.offset,
        angle = pc.angle,
        slideX = pc.slideX,
        slideY = pc.slideY,
        distance = pc.distance,
        flipped = pc.flipped == true,
        residualNorm = pc.residualNorm,
        weightedResidualNorm = pc.weightedResidualNorm,
        satisfied = pc.satisfied,
    }
end

function Trace.GConstraint(gc, graph)
    if not gc then return nil end
    return {
        id = gc.id,
        name = gc.name,
        type = gc.type,
        enabled = gc.enabled ~= false,
        updateMode = gc.updateMode,
        nodeA = gc.nodeA,
        nodeB = gc.nodeB,
        nodeALabel = graph and graph.nodes and graph.nodes[gc.nodeA] and graph.nodes[gc.nodeA].label or nil,
        nodeBLabel = graph and graph.nodes and graph.nodes[gc.nodeB] and graph.nodes[gc.nodeB].label or nil,
        params = gc.params,
        dirty = gc.dirty == true,
        attachA = gc.attachA,
        attachB = gc.attachB,
    }
end

local function sortedIDs(t)
    local ids = {}
    if t then
        for id in pairs(t) do ids[#ids + 1] = tonumber(id) or id end
        table.sort(ids, function(a, b) return tostring(a) < tostring(b) end)
    end
    return ids
end

function Trace.GraphSummary(graph)
    if not graph then return nil end
    local nodeCount, pcCount, gcCount = 0, 0, 0
    for _ in pairs(graph.nodes or {}) do nodeCount = nodeCount + 1 end
    for _ in pairs(graph.pconstraints or {}) do pcCount = pcCount + 1 end
    for _ in pairs(graph.gconstraints or {}) do gcCount = gcCount + 1 end
    return {
        nodes = nodeCount,
        pconstraints = pcCount,
        gconstraints = gcCount,
        nextNodeID = graph.nextNodeID,
        nextPCID = graph.nextPCID,
        selectedPCID = graph.selectedPCID,
        variables = graph.variables,
        solver = Trace.Diagnostic(graph.solverDiagnostic),
    }
end

function Trace.Diagnostic(diag)
    if not diag then return nil end
    local over = {}
    for i, pc in ipairs(diag.overConstrained or {}) do
        over[i] = {
            id = pc.id,
            pcid = pc.id or pc.pcid,
            residualNorm = pc.residualNorm,
            weightedResidualNorm = pc.weightedResidualNorm,
            mode = pc.mode,
            parentNodeID = pc.parentNodeID,
            childNodeID = pc.childNodeID,
        }
    end
    return {
        impl = diag.impl,
        status = diag.status,
        modelStatus = diag.modelStatus,
        attemptStatus = diag.attemptStatus,
        converged = diag.converged,
        accepted = diag.accepted,
        iterations = diag.iterations,
        residualNorm = diag.residualNorm,
        numEquations = diag.numEquations,
        numUnknowns = diag.numUnknowns,
        rank = diag.rank,
        nullity = diag.nullity,
        redundant = diag.redundant,
        underConstrained = diag.underConstrained,
        overConstrained = over,
        conditionEstimate = diag.conditionEstimate,
        activeNodeIDs = diag.activeNodeIDs,
        anchorNodeIDs = diag.anchorNodeIDs,
        nodeAxes = diag.nodeAxes,
        nodeAxisScores = diag.nodeAxisScores,
        axisSelection = diag.axisSelection,
    }
end

local function sanitize(value, depth, seen)
    depth = depth or 0
    seen = seen or {}
    local tv = type(value)
    if value == nil or tv == "number" or tv == "string" or tv == "boolean" then return value end
    if tv == "Vector" then return Trace.Vector(value) end
    if tv == "Angle" then return Trace.Angle(value) end
    if tv == "Player" then return Trace.Player(value) end
    if tv == "Entity" or tv == "Weapon" or tv == "NPC" or tv == "Vehicle" then return Trace.Entity(value) end
    if tv ~= "table" then return tostring(value) end
    if seen[value] then return "<cycle>" end
    if depth >= maxDepth() then return "<max-depth>" end
    seen[value] = true
    local out = {}
    local count = 0
    for k, v in pairs(value) do
        count = count + 1
        if count > maxItems() then
            out["<truncated>"] = true
            break
        end
        local sk = sanitize(k, depth + 1, seen)
        if type(sk) ~= "string" and type(sk) ~= "number" then sk = tostring(sk) end
        out[sk] = sanitize(v, depth + 1, seen)
    end
    seen[value] = nil
    return out
end

function Trace.Event(category, action, payload)
    if not isEnabled() then return end
    local path = ensureLogPath()
    local event = {
        seq = Trace.NextSeq(),
        utc = nowWall(),
        realm = REALM,
        category = tostring(category or "general"),
        action = tostring(action or "event"),
        payload = sanitize(payload or {}, 0, {}),
    }
    local line
    if util and util.TableToJSON then
        line = util.TableToJSON(event, false) or tostring(event)
    else
        line = string.format("[%s] %s.%s %s", event.utc, event.category, event.action, tostring(event.payload))
    end
    if file and file.Append then file.Append(path, line .. "\n") end
    if mirrorConsole() then
        if MsgN then MsgN(line) else print(line) end
    end
end

function Trace.Marker(text, payload)
    Trace.Event("marker", tostring(text or "marker"), payload or {})
end

function Trace.BeginPropagate(ply, graph, startID, reason, context)
    local token = { id = Trace.NextSeq(), t = runtimeClock(), reason = reason or "unspecified" }
    Trace.Event("propagate", "begin", {
        token = token.id,
        player = Trace.Player(ply),
        reason = reason,
        startID = startID,
        context = context,
        graph = Trace.GraphSummary(graph),
    })
    return token
end

function Trace.EndPropagate(token, ply, graph, ok)
    Trace.Event("propagate", "end", {
        token = token and token.id or nil,
        reason = token and token.reason or nil,
        duration = token and round(runtimeClock() - (token.t or runtimeClock())) or nil,
        player = Trace.Player(ply),
        ok = ok,
        graph = Trace.GraphSummary(graph),
        diag = Trace.Diagnostic(graph and graph.solverDiagnostic or nil),
    })
end

function Trace.Command(ply, commandName, args, extra)
    Trace.Event("command", commandName, {
        player = Trace.Player(ply),
        args = args,
        extra = extra,
    })
end

local function printPath(ply)
    local msg
    if not isEnabled() then
        msg = string.format("PB detailed file logging is disabled (%s = 0); no log file has been created.", cvEnabled and cvEnabled:GetName() or (PREFIX .. "file_log_enabled"))
    else
        msg = string.format("PB detailed log path: garrysmod/data/%s", ensureLogPath())
    end
    if SERVER and IsValid and IsValid(ply) and ply.PrintMessage then
        ply:PrintMessage(3, msg)
    end
    if MsgN then MsgN(msg) else print(msg) end
end

if concommand and concommand.Add then
    concommand.Add(PREFIX .. "log_path", function(ply) printPath(ply) end)
    concommand.Add(PREFIX .. "log_marker", function(ply, _, args)
        local text = table.concat(args or {}, " ")
        Trace.Marker(text ~= "" and text or "manual", { player = Trace.Player(ply) })
        printPath(ply)
    end)
    concommand.Add(PREFIX .. "log_newfile", function(ply)
        logPath = nil
        Trace.Marker("new_file", { player = Trace.Player(ply) })
        printPath(ply)
    end)
end

Trace.Event("trace", "module_loaded", {
    addon = CFG.AddonName or CFG.AddonName,
    realm = REALM,
})
