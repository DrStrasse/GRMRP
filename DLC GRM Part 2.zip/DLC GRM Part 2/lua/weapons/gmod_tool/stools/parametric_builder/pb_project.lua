






















PB = PB or {}
PB.Store = PB.Store or {
    projects      = {},
    folders       = {},
    activeProject = {},
}




local function newID(seed)
    local s = tostring(seed or "server") .. tostring(SysTime()) .. tostring(math.random(1, 2^31 - 1))
    return string.sub(util.SHA1(s), 1, 16)
end

local function now()
    return os.time()
end

local function markFolderChain(folderID, out)
    while folderID do
        if out[folderID] then return end
        out[folderID] = true
        local folder = PB.Store.folders[folderID]
        if not folder then return end
        folderID = folder.parentID
    end
end

local function normalizeProjectBaseName(name)
    name = tostring(name or "Untitled")
    local base = string.match(name, "^(.-)%s%((%d+)%)$")
    if base and base ~= "" then
        return base
    end
    return name
end

function PB.Store.MakeUniqueProjectName(ownerSID, baseName)
    baseName = normalizeProjectBaseName(baseName)
    local used = {}
    for _, proj in pairs(PB.Store.projects) do
        if proj.ownerSteamID == ownerSID then
            used[string.lower(proj.name or "")] = true
        end
    end

    if not used[string.lower(baseName)] then
        return baseName
    end

    local n = 1
    while true do
        local candidate = string.format("%s (%d)", baseName, n)
        if not used[string.lower(candidate)] then
            return candidate
        end
        n = n + 1
    end
end





function PB.Store.PlayerOwnsProject(steamID, projectID)
    local proj = PB.Store.projects[projectID]
    return proj ~= nil and proj.ownerSteamID == steamID
end

function PB.Store.PlayerCanAccessProject(steamID, projectID)
    local proj = PB.Store.projects[projectID]
    if not proj then return false end
    if proj.ownerSteamID == steamID then return true end
    return proj.collaborators and proj.collaborators[steamID] == true or false
end

function PB.Store.FindOwnedProject(steamID)
    local bestID, bestProj = nil, nil
    for pid, proj in pairs(PB.Store.projects) do
        if proj.ownerSteamID == steamID then
            if not bestProj
                or (proj.createdAt or 0) < (bestProj.createdAt or 0)
                or ((proj.createdAt or 0) == (bestProj.createdAt or 0) and pid < bestID) then
                bestID = pid
                bestProj = proj
            end
        end
    end
    return bestID
end

function PB.Store.ResolveActiveProject(steamID)
    local pid = PB.Store.activeProject[steamID]
    if pid and PB.Store.PlayerCanAccessProject(steamID, pid) then
        return pid
    end

    local fallback = PB.Store.FindOwnedProject(steamID)
    if fallback then
        PB.Store.activeProject[steamID] = fallback
        return fallback
    end

    PB.Store.activeProject[steamID] = nil
    return nil
end

function PB.Store.TouchProject(projectID)
    local proj = PB.Store.projects[projectID]
    if not proj then return false end
    proj.modifiedAt = now()
    return true
end

function PB.Store.TouchActiveForPlayer(steamID)
    local pid = PB.Store.activeProject[steamID]
    if not pid then return false end
    return PB.Store.TouchProject(pid)
end





function PB.Store.CreateProject(ownerSID, name, folderID)
    local id = newID(ownerSID)
    PB.Store.projects[id] = {
        id            = id,
        name          = name or "Untitled",
        folderID      = folderID,
        ownerSteamID  = ownerSID or "server",
        collaborators = {},
        graph         = PB.NewGraph(),
        createdAt     = now(),
        modifiedAt    = now(),
    }
    return id
end

function PB.Store.DeleteProject(projectID)
    local proj = PB.Store.projects[projectID]
    if not proj then return false end

    if PB.ClearGConstraintRuntime and proj.graph then
        PB.ClearGConstraintRuntime(proj.graph)
    end

    PB.Store.projects[projectID] = nil
    if PB.Store.presence then
        PB.Store.presence[projectID] = nil
    end

    for sid, pid in pairs(PB.Store.activeProject) do
        if pid == projectID then
            PB.Store.activeProject[sid] = nil
        end
    end
    return true
end

function PB.Store.ProjectHasLiveEntities(project)
    if not project or not project.graph then return false end

    for _, node in pairs(project.graph.nodes or {}) do
        if not node.isPattern and IsValid(node.entity) then
            return true
        end
    end

    return false
end

function PB.Store.FindProjectNodeByEntity(ent)
    if not IsValid(ent) or not PB.Store.projects then return nil end

    for projectID, project in pairs(PB.Store.projects) do
        local graph = project.graph
        if graph then
            local nodeID = graph._entityIndex and graph._entityIndex[ent] or nil

            if not nodeID then
                for id, node in pairs(graph.nodes or {}) do
                    if node.entity == ent then
                        nodeID = id
                        break
                    end
                end
            end

            if nodeID and graph.nodes[nodeID] then
                return projectID, project, graph, nodeID
            end
        end
    end

    return nil
end

function PB.Store.QueueAutoDeleteIfEmpty(projectID)
    if not projectID then return end

    local timerName = "PB_AutoDeleteEmptyProject_" .. tostring(projectID)
    timer.Remove(timerName)
    timer.Create(timerName, 0.1, 1, function()
        if not (PB.Store and PB.Store.projects) then return end

        local project = PB.Store.projects[projectID]
        if not project then return end
        if project.autoDeleteWhenEmpty ~= true then return end
        if PB.Store.ProjectHasLiveEntities(project) then return end

        local ownerSID = project.ownerSteamID
        PB.Store.DeleteProject(projectID)

        if PB.Store.BroadcastAllProjectLists then
            PB.Store.BroadcastAllProjectLists()
        end

        for _, ply in ipairs(player.GetAll()) do
            local shouldResync = not ownerSID or ply:SteamID() == ownerSID
            if not shouldResync and project.collaborators then
                shouldResync = project.collaborators[ply:SteamID()] == true
            end

            if shouldResync and PB.Store.ResyncPlayerProjectState then
                PB.Store.ResyncPlayerProjectState(ply)
            end
        end
    end)
end

function PB.Store.RenameProject(projectID, name)
    local proj = PB.Store.projects[projectID]
    if not proj then return false end
    proj.name = name
    proj.modifiedAt = now()
    return true
end

function PB.Store.MoveProject(projectID, folderID)
    local proj = PB.Store.projects[projectID]
    if not proj then return false end
    if folderID ~= nil and not PB.Store.folders[folderID] then return false end
    proj.folderID = folderID
    proj.modifiedAt = now()
    return true
end





function PB.Store.CreateFolder(ownerSID, name, parentID)
    if parentID ~= nil and not PB.Store.folders[parentID] then return nil end
    local id = newID(ownerSID)
    PB.Store.folders[id] = {
        id           = id,
        name         = name or "New Folder",
        parentID     = parentID,
        ownerSteamID = ownerSID or "server",
    }
    return id
end

local function wouldCreateCycle(folderID, newParentID)
    local cur = newParentID
    while cur do
        if cur == folderID then return true end
        local f = PB.Store.folders[cur]
        if not f then return false end
        cur = f.parentID
    end
    return false
end

function PB.Store.MoveFolder(folderID, parentID)
    local f = PB.Store.folders[folderID]
    if not f then return false end
    if parentID ~= nil and not PB.Store.folders[parentID] then return false end
    if parentID == folderID then return false end
    if wouldCreateCycle(folderID, parentID) then return false end
    f.parentID = parentID
    return true
end

function PB.Store.RenameFolder(folderID, name)
    local f = PB.Store.folders[folderID]
    if not f then return false end
    f.name = name
    return true
end

function PB.Store.DeleteFolder(folderID, recursive)
    local f = PB.Store.folders[folderID]
    if not f then return false end

    local childFolders, childProjects = {}, {}
    for fid, fol in pairs(PB.Store.folders) do
        if fol.parentID == folderID then childFolders[#childFolders + 1] = fid end
    end
    for pid, proj in pairs(PB.Store.projects) do
        if proj.folderID == folderID then childProjects[#childProjects + 1] = pid end
    end

    if recursive then
        for _, fid in ipairs(childFolders) do
            PB.Store.DeleteFolder(fid, true)
        end
        for _, pid in ipairs(childProjects) do
            PB.Store.DeleteProject(pid)
        end
    else
        for _, fid in ipairs(childFolders) do
            PB.Store.folders[fid].parentID = f.parentID
        end
        for _, pid in ipairs(childProjects) do
            PB.Store.projects[pid].folderID = f.parentID
        end
    end

    PB.Store.folders[folderID] = nil
    return true
end





function PB.Store.SetActive(steamID, projectID)
    if not PB.Store.PlayerCanAccessProject(steamID, projectID) then return false end
    PB.Store.activeProject[steamID] = projectID
    return true
end

function PB.Store.GetActive(steamID)
    return PB.Store.activeProject[steamID]
end





function PB.Store.ListForPlayer(steamID)
    local out = { projects = {}, folders = {} }
    local visibleFolderIDs = {}

    for fid, fol in pairs(PB.Store.folders) do
        if fol.ownerSteamID == steamID then
            visibleFolderIDs[fid] = true
            markFolderChain(fol.parentID, visibleFolderIDs)
        end
    end

    for pid, proj in pairs(PB.Store.projects) do
        if PB.Store.PlayerCanAccessProject(steamID, pid) then
            out.projects[pid] = proj
            markFolderChain(proj.folderID, visibleFolderIDs)
        end
    end

    for fid in pairs(visibleFolderIDs) do
        if PB.Store.folders[fid] then
            out.folders[fid] = PB.Store.folders[fid]
        end
    end

    return out
end













if SERVER then
    function PB.Store.SaveAll()
        return false
    end

    function PB.Store.SaveProject(projectID)
        return false
    end

    function PB.Store.LoadAll()
        PB.Store.projects = {}
        PB.Store.folders = {}
        PB.Store.activeProject = {}
        if PB.Store.presence then PB.Store.presence = {} end
        return true
    end
end














if SERVER then
if not PB or not PB.Store then return end

local STRINGS = {
    "pb_proj_list",
    "pb_proj_set_active",
    "pb_proj_active_changed",
    "pb_proj_create",
    "pb_proj_delete",
    "pb_proj_rename",
    "pb_proj_move",
    "pb_proj_set_auto_manage",
    "pb_folder_create",
    "pb_folder_delete",
    "pb_folder_rename",
    "pb_folder_move",
}
for _, s in ipairs(STRINGS) do util.AddNetworkString(s) end

local function buildPayload(sid)
    local visible = PB.Store.ListForPlayer and PB.Store.ListForPlayer(sid) or { projects = {}, folders = {} }
    local projects, folders = {}, {}

    for id, p in pairs(visible.projects or {}) do
        local collaborators = {}
        for collabSID, _ in pairs(p.collaborators or {}) do
            collaborators[#collaborators + 1] = collabSID
        end
        table.sort(collaborators)

        projects[#projects + 1] = {
            id            = id,
            name          = p.name or "Untitled",
            folderID      = p.folderID,
            ownerSteamID  = p.ownerSteamID,
            collaborators = collaborators,
            createdAt     = p.createdAt or 0,
            modifiedAt    = p.modifiedAt or 0,
            autoManage    = (not p.graph) or p.graph.autoManage ~= false,
            isOwner       = p.ownerSteamID == sid,
        }
    end

    for id, f in pairs(visible.folders or {}) do
        folders[#folders + 1] = {
            id           = id,
            name         = f.name or "Folder",
            parentID     = f.parentID,
            ownerSteamID = f.ownerSteamID,
            isOwner      = f.ownerSteamID == sid,
        }
    end

    table.sort(projects, function(a, b) return a.id < b.id end)
    table.sort(folders, function(a, b) return a.id < b.id end)

    return {
        active   = PB.Store.activeProject and PB.Store.activeProject[sid] or nil,
        projects = projects,
        folders  = folders,
    }
end

function PB.Store.BroadcastProjectList(ply)
    if not IsValid(ply) then return end
    local payload = util.TableToJSON(buildPayload(ply:SteamID()))
    local data = util.Compress(payload) or payload
    net.Start("pb_proj_list")
        net.WriteUInt(#data, 24)
        net.WriteData(data, #data)
    net.Send(ply)
end

function PB.Store.BroadcastAllProjectLists()
    for _, target in ipairs(player.GetAll()) do
        PB.Store.BroadcastProjectList(target)
    end
end

function PB.Store.SendActiveProjectChanged(ply, pid)
    if not IsValid(ply) then return end
    net.Start("pb_proj_active_changed")
        net.WriteString(pid or "")
    net.Send(ply)
end

function PB.Store.ResyncPlayerProjectState(ply)
    if not IsValid(ply) then return end
    local sid = ply:SteamID()
    local pid = PB.Store.ResolveActiveProject and PB.Store.ResolveActiveProject(sid) or PB.Store.activeProject[sid]
    PB.Store.SendActiveProjectChanged(ply, pid)
    if PB.SyncFullToClient then
        PB.SyncFullToClient(ply, PB.GetGraph(ply))
    end
end

local function touchSave()
    if PB.Store.SaveAll then PB.Store.SaveAll() end
end

local function rebroadcastAll()
    if PB.Store.BroadcastAllProjectLists then
        PB.Store.BroadcastAllProjectLists()
    end
end

local function ownerOnlyProject(project, sid)
    return project and project.ownerSteamID == sid
end

local function ownerOnlyFolder(folder, sid)
    return folder and folder.ownerSteamID == sid
end

local function resyncIfActiveInvalid(ply)
    if not IsValid(ply) then return end
    local sid = ply:SteamID()
    local pid = PB.Store.activeProject and PB.Store.activeProject[sid] or nil
    if pid and PB.Store.PlayerCanAccessProject and PB.Store.PlayerCanAccessProject(sid, pid) then
        return
    end
    PB.Store.ResyncPlayerProjectState(ply)
end

net.Receive("pb_proj_create", function(_, ply)
    local sid = ply:SteamID()
    local name = net.ReadString()
    local folderID = net.ReadString()
    if folderID == "" then folderID = nil end
    if folderID and not ownerOnlyFolder(PB.Store.folders[folderID], sid) then
        folderID = nil
    end

    local pid = PB.Store.CreateProject(sid, name ~= "" and name or "Untitled", folderID)
    PB.Store.SetActive(sid, pid)
    touchSave()
    rebroadcastAll()
    PB.Store.ResyncPlayerProjectState(ply)
end)

net.Receive("pb_proj_delete", function(_, ply)
    local sid = ply:SteamID()
    local pid = net.ReadString()
    local project = PB.Store.projects[pid]
    if not ownerOnlyProject(project, sid) then return end

    PB.Store.DeleteProject(pid)
    touchSave()
    rebroadcastAll()

    for _, target in ipairs(player.GetAll()) do
        resyncIfActiveInvalid(target)
    end
end)

net.Receive("pb_proj_rename", function(_, ply)
    local sid = ply:SteamID()
    local pid = net.ReadString()
    local name = net.ReadString()
    local project = PB.Store.projects[pid]
    if not ownerOnlyProject(project, sid) then return end
    if name == "" then return end

    PB.Store.RenameProject(pid, name)
    if PB.Store.RefreshDuplicationData then
        PB.Store.RefreshDuplicationData(pid)
    end
    touchSave()
    rebroadcastAll()
end)

net.Receive("pb_proj_move", function(_, ply)
    local sid = ply:SteamID()
    local pid = net.ReadString()
    local folderID = net.ReadString()
    if folderID == "" then folderID = nil end

    local project = PB.Store.projects[pid]
    if not ownerOnlyProject(project, sid) then return end
    if folderID and not ownerOnlyFolder(PB.Store.folders[folderID], sid) then return end
    if not PB.Store.MoveProject(pid, folderID) then return end

    touchSave()
    rebroadcastAll()
end)


net.Receive("pb_proj_set_auto_manage", function(_, ply)
    local sid = ply:SteamID()
    local pid = net.ReadString()
    local enabled = net.ReadBool()
    local project = PB.Store.projects[pid]
    if not ownerOnlyProject(project, sid) then return end

    local graph = project.graph
    if not graph then return end

    if PB.SetGraphAutoManage then
        PB.SetGraphAutoManage(graph, enabled)
    else
        graph.autoManage = enabled ~= false
    end

    PB.Store.TouchProject(pid)






    if graph.autoManage ~= false then
        if PB.GrabAllFromEntities then PB.GrabAllFromEntities(graph) end
        if PB.Propagate then PB.Propagate(graph, nil, { preserveGConstraints = true }) end
    end

    if PB.Store.RefreshDuplicationData then
        PB.Store.RefreshDuplicationData(pid)
    end

    touchSave()
    rebroadcastAll()

    for _, target in ipairs(player.GetAll()) do
        if PB.Store.activeProject and PB.Store.activeProject[target:SteamID()] == pid then
            PB.Store.ResyncPlayerProjectState(target)
        end
    end
end)

net.Receive("pb_proj_set_active", function(_, ply)
    local sid = ply:SteamID()
    local pid = net.ReadString()
    if not PB.Store.PlayerCanAccessProject or not PB.Store.PlayerCanAccessProject(sid, pid) then return end
    if not PB.Store.SetActive(sid, pid) then return end

    PB.Store.ResyncPlayerProjectState(ply)
    PB.Store.BroadcastProjectList(ply)
end)

net.Receive("pb_folder_create", function(_, ply)
    local sid = ply:SteamID()
    local name = net.ReadString()
    local parentID = net.ReadString()
    if parentID == "" then parentID = nil end
    if parentID and not ownerOnlyFolder(PB.Store.folders[parentID], sid) then
        parentID = nil
    end

    PB.Store.CreateFolder(sid, name ~= "" and name or "Folder", parentID)
    touchSave()
    rebroadcastAll()
end)

net.Receive("pb_folder_delete", function(_, ply)
    local sid = ply:SteamID()
    local fid = net.ReadString()
    local recursive = net.ReadBool()
    local folder = PB.Store.folders[fid]
    if not ownerOnlyFolder(folder, sid) then return end

    PB.Store.DeleteFolder(fid, recursive)
    touchSave()
    rebroadcastAll()
end)

net.Receive("pb_folder_rename", function(_, ply)
    local sid = ply:SteamID()
    local fid = net.ReadString()
    local name = net.ReadString()
    local folder = PB.Store.folders[fid]
    if not ownerOnlyFolder(folder, sid) then return end
    if name == "" then return end

    PB.Store.RenameFolder(fid, name)
    touchSave()
    rebroadcastAll()
end)

net.Receive("pb_folder_move", function(_, ply)
    local sid = ply:SteamID()
    local fid = net.ReadString()
    local parentID = net.ReadString()
    if parentID == "" then parentID = nil end

    local folder = PB.Store.folders[fid]
    if not ownerOnlyFolder(folder, sid) then return end
    if parentID and not ownerOnlyFolder(PB.Store.folders[parentID], sid) then return end
    if not PB.Store.MoveFolder(fid, parentID) then return end

    touchSave()
    rebroadcastAll()
end)

hook.Add("PlayerInitialSpawn", "PB_BroadcastProjectListOnSpawn", function(ply)
    timer.Simple(2, function()
        if IsValid(ply) then
            PB.Store.BroadcastProjectList(ply)
        end
    end)
end)


end





if SERVER then

PB = PB or {}
PB.Store = PB.Store or {}

local STRINGS = {
    "pb_proj_share",
    "pb_proj_unshare",
    "pb_proj_presence",
}
for _, s in ipairs(STRINGS) do util.AddNetworkString(s) end

PB.Store.presence = PB.Store.presence or {}

local function findPlayerBySteamID(steamID)
    for _, ply in ipairs(player.GetAll()) do
        if ply:SteamID() == steamID then
            return ply
        end
    end
end

local function touchPresence(sid, pid)
    if not sid or not pid then return end
    PB.Store.presence[pid] = PB.Store.presence[pid] or {}
    PB.Store.presence[pid][sid] = CurTime()
end

local function leavePresence(sid, pid)
    if not sid or not pid then return end
    local set = PB.Store.presence[pid]
    if set then
        set[sid] = nil
    end
end

function PB.Store.ActiveCollaborators(projectID, except)
    local rf = RecipientFilter()
    local set = PB.Store.presence[projectID]
    if not set then return rf end

    local cutoff = CurTime() - 30
    for sid, touchedAt in pairs(set) do
        if touchedAt < cutoff then
            set[sid] = nil
        else
            local ply = findPlayerBySteamID(sid)
            if IsValid(ply) and ply ~= except then
                rf:AddPlayer(ply)
            end
        end
    end
    return rf
end

local function broadcastPresence(projectID)
    local set = PB.Store.presence[projectID] or {}
    local list = {}
    for sid in pairs(set) do
        list[#list + 1] = sid
    end
    table.sort(list)

    net.Start("pb_proj_presence")
        net.WriteString(projectID)
        net.WriteUInt(#list, 8)
        for _, sid in ipairs(list) do
            net.WriteString(sid)
        end
    net.Broadcast()
end

local function projectOwnedBy(ply, projectID)
    local project = PB.Store.projects and PB.Store.projects[projectID]
    return project ~= nil and project.ownerSteamID == ply:SteamID(), project
end

net.Receive("pb_proj_share", function(_, ply)
    local pid = net.ReadString()
    local targetSID = net.ReadString()
    local ok, project = projectOwnedBy(ply, pid)
    if not ok or not targetSID or targetSID == "" then return end
    if targetSID == ply:SteamID() then return end

    project.collaborators = project.collaborators or {}
    project.collaborators[targetSID] = true
    project.modifiedAt = os.time()

    if PB.Store.SaveAll then PB.Store.SaveAll() end
    if PB.Store.BroadcastAllProjectLists then PB.Store.BroadcastAllProjectLists() end








    local targetPly = findPlayerBySteamID(targetSID)
    if IsValid(targetPly) and PB.Store.ResyncPlayerProjectState then
        if PB.Store.activeProject then
            local active = PB.Store.activeProject[targetSID]
            if not active or not (PB.Store.PlayerCanAccessProject and PB.Store.PlayerCanAccessProject(targetSID, active)) then
                PB.Store.SetActive(targetSID, pid)
            end
        end
        PB.Store.ResyncPlayerProjectState(targetPly)
    end
end)

net.Receive("pb_proj_unshare", function(_, ply)
    local pid = net.ReadString()
    local targetSID = net.ReadString()
    local ok, project = projectOwnedBy(ply, pid)
    if not ok or not targetSID or targetSID == "" then return end

    if project.collaborators then
        project.collaborators[targetSID] = nil
    end
    project.modifiedAt = os.time()

    if PB.Store.activeProject and PB.Store.activeProject[targetSID] == pid then
        PB.Store.activeProject[targetSID] = nil
    end

    leavePresence(targetSID, pid)
    broadcastPresence(pid)

    if PB.Store.SaveAll then PB.Store.SaveAll() end
    if PB.Store.BroadcastAllProjectLists then PB.Store.BroadcastAllProjectLists() end

    local targetPly = findPlayerBySteamID(targetSID)
    if IsValid(targetPly) and PB.Store.ResyncPlayerProjectState then
        PB.Store.ResyncPlayerProjectState(targetPly)
    end
end)

do
    local origSetActive = PB.Store.SetActive
    function PB.Store.SetActive(sid, pid)
        local prev = PB.Store.activeProject and PB.Store.activeProject[sid]
        local ok = origSetActive and origSetActive(sid, pid)
        if not ok then return false end

        if prev and prev ~= pid then
            leavePresence(sid, prev)
            broadcastPresence(prev)
        end
        if pid then
            touchPresence(sid, pid)
            broadcastPresence(pid)
        end
        return true
    end
end

timer.Create("pb_presence_sweep", 10, 0, function()
    local cutoff = CurTime() - 30
    for pid, set in pairs(PB.Store.presence) do
        local dirty = false
        for sid, touchedAt in pairs(set) do
            if touchedAt < cutoff then
                set[sid] = nil
                dirty = true
            end
        end
        if dirty then
            broadcastPresence(pid)
        end
    end
end)

hook.Add("PlayerDisconnected", "pb_presence_disconnect", function(ply)
    local sid = ply:SteamID()
    for pid, set in pairs(PB.Store.presence) do
        if set[sid] then
            set[sid] = nil
            broadcastPresence(pid)
        end
    end
end)

do
    local origGetGraph = PB.GetGraph
    function PB.GetGraph(ply)
        if SERVER and IsValid(ply) then
            local sid = ply:SteamID()
            local pid = PB.Store.activeProject and PB.Store.activeProject[sid]
            if pid then
                touchPresence(sid, pid)
            end
        end
        return origGetGraph(ply)
    end
end

function PB.Store.PushCollabSync(projectID, except)
    local project = PB.Store.projects and PB.Store.projects[projectID]
    if not project or not project.graph or not PB.SyncFullToClient then return end

    local rf = PB.Store.ActiveCollaborators(projectID, except)
    for _, target in ipairs(rf:GetPlayers()) do
        if IsValid(target)
            and PB.Store.activeProject
            and PB.Store.activeProject[target:SteamID()] == projectID
            and PB.Store.PlayerCanAccessProject
            and PB.Store.PlayerCanAccessProject(target:SteamID(), projectID) then
            PB.SyncFullToClient(target, project.graph)
            if PB.Store.SendActiveProjectChanged then
                PB.Store.SendActiveProjectChanged(target, projectID)
            end
        end
    end
end

hook.Add("PB_PostGraphMutation", "pb_collab_rebroadcast", function(ply, projectID)
    projectID = projectID or (IsValid(ply) and PB.Store.activeProject[ply:SteamID()])
    if projectID then
        PB.Store.PushCollabSync(projectID, ply)
    end
end)


























if timer.Exists and timer.Exists("pb_collab_debounce") then
    timer.Remove("pb_collab_debounce")
end

print(((PB.Config and PB.Config.ChatPrefix) or "[PB]") .. " Project sharing / presence loaded")


end

if SERVER then
    local DUPE_MOD = "pb_project_node"
    local pendingDupes = {}
    local completedDupeImports = {}

    local function advDupePasteInProgress()
        return AdvDupe2
            and AdvDupe2.JobManager
            and AdvDupe2.JobManager.PastingHook == true
    end

    local function dupeBucketPlayer(bucket)
        return bucket and bucket.player or nil
    end

    local function countGraphEntities(graph)
        local n = 0
        for _, node in pairs(graph.nodes or {}) do
            if not node.isPattern and IsValid(node.entity) then
                n = n + 1
            end
        end
        return n
    end

    local function currentGraphJSONForDupe(ply, data)
        if not istable(data) then return nil end
        if not PB or not PB.Store or not PB.Store.projects or not PB.Serialize then return nil end
        local projectID = data.projectID and tostring(data.projectID) or nil
        local project = projectID and PB.Store.projects[projectID] or nil
        if not project or not project.graph then return nil end
        local sid = IsValid(ply) and ply:SteamID() or "server"
        if project.ownerSteamID ~= sid then
            if not PB.Store.PlayerCanAccessProject or not PB.Store.PlayerCanAccessProject(sid, projectID) then return nil end
        end
        return PB.Serialize(project.graph)
    end

    local function stampRuntimeGConstraintsForDupe(projectID, graph)
        if not graph or not graph.gconstraints then return end
        for _, def in pairs(graph.gconstraints) do
            if def then
                def.projectID = projectID
                for _, ent in ipairs(def.runtimeEnts or {}) do
                    if IsValid(ent) then
                        ent.BuildDupeInfo = ent.BuildDupeInfo or {}
                        ent.BuildDupeInfo.PB_GParametricRuntime = true
                        ent.BuildDupeInfo.PB_ProjectID = projectID
                        ent.BuildDupeInfo.PB_GConstraintID = def.id
                    end
                end
                if IsValid(def.runtimeEnt) then
                    def.runtimeEnt.BuildDupeInfo = def.runtimeEnt.BuildDupeInfo or {}
                    def.runtimeEnt.BuildDupeInfo.PB_GParametricRuntime = true
                    def.runtimeEnt.BuildDupeInfo.PB_ProjectID = projectID
                    def.runtimeEnt.BuildDupeInfo.PB_GConstraintID = def.id
                end
            end
        end
    end

    function PB.Store.RefreshDuplicationData(projectID)
        if not duplicator or not duplicator.StoreEntityModifier then return end
        local project = PB.Store.projects[projectID]
        if not project or not project.graph then return end

        local graph = project.graph
        local expectedCount = countGraphEntities(graph)
        if expectedCount <= 0 then return end

        stampRuntimeGConstraintsForDupe(projectID, graph)

        local graphJSON = PB.Serialize and PB.Serialize(graph)
        if not graphJSON or graphJSON == "" then return end

        for _, node in pairs(graph.nodes or {}) do
            if not node.isPattern and IsValid(node.entity) then
                duplicator.StoreEntityModifier(node.entity, DUPE_MOD, {
                    projectID = project.id,
                    projectName = project.name or "Untitled",
                    sourceNodeID = node.id,
                    expectedCount = expectedCount,
                    graphJSON = graphJSON,
                })
            end
        end
    end

    function PB.Store.RefreshDuplicationDataForGraph(graph)
        if not graph or not PB.Store.projects then return end
        for projectID, project in pairs(PB.Store.projects) do
            if project.graph == graph then
                PB.Store.RefreshDuplicationData(projectID)
                return
            end
        end
    end

    local function vecFrom(tbl)
        if not istable(tbl) then return Vector() end
        return Vector(tonumber(tbl.x) or 0, tonumber(tbl.y) or 0, tonumber(tbl.z) or 0)
    end

    local function angFrom(tbl)
        if not istable(tbl) then return Angle() end
        return Angle(tonumber(tbl.p) or 0, tonumber(tbl.y) or 0, tonumber(tbl.r) or 0)
    end

    local function rebuildChildren(graph)
        for _, node in pairs(graph.nodes or {}) do
            node.children = {}
        end
        for _, node in pairs(graph.nodes or {}) do
            if node.parentID and graph.nodes[node.parentID] then
                graph.nodes[node.parentID].children[node.id] = true
            end
        end
    end

    local function decodeGraphJSON(json)
        if not isstring(json) or json == "" then return nil end
        return util.JSONToTable(json)
    end

    local function sourceNodeData(data, oldID)
        return data.nodes[oldID] or data.nodes[tostring(oldID)]
    end

    local function constraintBuildInfo(ent)
        if not IsValid(ent) then return nil end
        local bi = ent.BuildDupeInfo
        if istable(bi) then return bi end
        local tbl = ent.GetTable and ent:GetTable() or nil
        bi = istable(tbl) and tbl.BuildDupeInfo or nil
        return istable(bi) and bi or nil
    end

    local function adoptPastedGConstraintRefs(graph, oldToNewGCID, createdConstraints, sourceProjectID)
        if not graph or not graph.gconstraints then return end
        local adopted = {}

        for _, ent in ipairs(createdConstraints or {}) do
            if IsValid(ent) then
                local bi = constraintBuildInfo(ent)
                local oldGCID = bi and tonumber(bi.PB_GConstraintID) or nil
                local biProjectID = bi and bi.PB_ProjectID or nil

                if oldGCID and (biProjectID == nil or tostring(biProjectID) == tostring(sourceProjectID or biProjectID)) then
                    local newGCID = oldToNewGCID[oldGCID]
                    local def = newGCID and graph.gconstraints[newGCID] or nil
                    if def then
                        def.runtimeEnts = def.runtimeEnts or {}
                        def.runtimeEnts[#def.runtimeEnts + 1] = ent
                        def.runtimeEnt = def.runtimeEnt or ent
                        def.status = "ok"
                        def.projectID = nil
                        if PB.MarkRuntimeConstraintEnt then
                            PB.MarkRuntimeConstraintEnt(ent, "GConstraint", def.id, nil)
                        end
                        adopted[newGCID] = true
                    end
                end
            end
        end



        if PB.GConstraints and PB.GConstraints.AdoptWorldRefs then
            for gcid, def in pairs(graph.gconstraints) do
                if def and not adopted[gcid] and PB.GConstraints.AdoptWorldRefs(graph, def, { allowLoose = true }) then
                    adopted[gcid] = true
                end
            end
        end





        if #(createdConstraints or {}) > 0 and PB.GConstraints and PB.GConstraints.EnsureLive then
            for gcid, def in pairs(graph.gconstraints) do
                if def and def.enabled ~= false and not adopted[gcid] and not IsValid(def.runtimeEnt) then
                    PB.GConstraints.EnsureLive(graph, def, { adopt = true, forceRebuild = true })
                end
            end
        elseif PB.GConstraints and PB.GConstraints.ReconcileGraph then
            PB.GConstraints.ReconcileGraph(graph, { adopt = true, noBuild = true })
        end
    end

    local function collectBatchConstraints(pasteBatches, ply)
        local out = {}
        if not istable(pasteBatches) then return out end
        for _, batch in ipairs(pasteBatches) do
            if istable(batch) and (not IsValid(ply) or batch.Player == ply) then
                for _, ent in ipairs(batch.CreatedConstraints or {}) do
                    if IsValid(ent) then out[#out + 1] = ent end
                end
            end
        end
        return out
    end

    local function partialImportTimerName(key)
        return "PB_DupeImportPartial_" .. tostring(key)
    end

    local function fallbackImportTimerName(key)
        return "PB_DupeImportFallback_" .. tostring(key)
    end

    local function clearDupeImportTimers(key)
        timer.Remove(partialImportTimerName(key))
        timer.Remove(fallbackImportTimerName(key))
    end

    local function importDuplicatedGraph(ply, bucket)
        local sid = IsValid(ply) and ply:SteamID() or "server"
        local data = decodeGraphJSON(bucket.graphJSON)
        if not data or not istable(data.nodes) then return nil end






        local projectName = PB.Store.MakeUniqueProjectName(sid, bucket.projectName or "Untitled")
        local projectID = PB.Store.CreateProject(sid, projectName, nil)
        local project = PB.Store.projects[projectID]
        if not project then return nil end

        project.autoDeleteWhenEmpty = true
        project.createdFromDupe = true
        project.dupeSourceProjectID = bucket.projectID

        local graph = project.graph



        graph.autoManage = false
        graph.variables = table.Copy(data.variables or {})
        graph.variableMeta = table.Copy(data.variableMeta or {})
        graph.solverDiagnostic = istable(data.solverDiagnostic) and table.Copy(data.solverDiagnostic) or nil

        local nodeOrder = {}
        for oldID in pairs(data.nodes) do
            nodeOrder[#nodeOrder + 1] = tonumber(oldID) or oldID
        end
        table.sort(nodeOrder, function(a, b) return tonumber(a) < tonumber(b) end)

        local idMap = {}

        for _, oldID in ipairs(nodeOrder) do
            local nd = sourceNodeData(data, oldID)
            if nd then
                local newNode = nil
                if nd.isPattern and PB.NewPatternNode then
                    newNode = PB.NewPatternNode(
                        graph,
                        nil,
                        nd.patternType,
                        table.Copy(nd.patternParams or {}),
                        nd.copyConstraints,
                        nd.patternConstraintType,
                        table.Copy(nd.patternConstraintParams or {})
                    )
                    if newNode then
                        newNode.label = nd.label or newNode.label
                        newNode.notes = nd.notes
                        newNode.exprPos = nd.exprPos
                        newNode.exprAngle = nd.exprAngle
                        newNode.exprPosParts = istable(nd.exprPosParts) and table.Copy(nd.exprPosParts) or nil
                        newNode.exprAngleParts = istable(nd.exprAngleParts) and table.Copy(nd.exprAngleParts) or nil
                        newNode.dofOverrides = istable(nd.dofOverrides) and table.Copy(nd.dofOverrides) or { pos = {}, ang = {} }
                        newNode.isMirrorGenerated = nd.isMirrorGenerated or false
                        newNode.mirrorPCID = tonumber(nd.mirrorPCID) or nil
                        newNode.localPos = vecFrom(nd.localPos)
                        newNode.localAngle = angFrom(nd.localAngle)
                        newNode.worldPos = vecFrom(nd.worldPos)
                        newNode.worldAngle = angFrom(nd.worldAngle)
                        newNode.constraintType = nd.constraintType or "none"
                        newNode.constraintParams = table.Copy(nd.constraintParams or {})
                    end
                else
                    local ent = bucket.entities[tonumber(oldID)]
                    if IsValid(ent) then
                        newNode = PB.NewNode(graph, ent, nil, vecFrom(nd.localPos), angFrom(nd.localAngle))
                        newNode.model = nd.model or ent:GetModel()
                        newNode.entityClass = nd.entityClass or ent:GetClass() or "prop_physics"
                        newNode.entitySkin = nd.entitySkin
                        newNode.entityMaterial = nd.entityMaterial
                        newNode.entityColor = nd.entityColor
                        newNode.entityBodygroups = nd.entityBodygroups
                        newNode.entityKeyValues = nd.entityKeyValues
                        newNode.worldPos = ent:GetPos()
                        newNode.worldAngle = ent:GetAngles()
                        newNode.constraintType = nd.constraintType or "none"
                        newNode.constraintParams = table.Copy(nd.constraintParams or {})
                        newNode.label = nd.label or newNode.label
                        newNode.notes = nd.notes
                        newNode.exprPos = nd.exprPos
                        newNode.exprAngle = nd.exprAngle
                        newNode.exprPosParts = istable(nd.exprPosParts) and table.Copy(nd.exprPosParts) or nil
                        newNode.exprAngleParts = istable(nd.exprAngleParts) and table.Copy(nd.exprAngleParts) or nil
                        newNode.dofOverrides = istable(nd.dofOverrides) and table.Copy(nd.dofOverrides) or { pos = {}, ang = {} }
                        newNode.isMirrorGenerated = nd.isMirrorGenerated or false
                        newNode.mirrorPCID = tonumber(nd.mirrorPCID) or nil
                        newNode.locked = nd.locked or false
                        newNode.visible = nd.visible ~= false
                        newNode.snapParentFace = nd.snapParentFace
                        newNode.snapChildFace = nd.snapChildFace
                        newNode.snapGap = tonumber(nd.snapGap) or 0
                        newNode.copyConstraints = nd.copyConstraints or false
                        newNode.patternConstraintType = nd.patternConstraintType or "none"
                        newNode.patternConstraintParams = table.Copy(nd.patternConstraintParams or {})
                    end
                end

                if newNode then
                    idMap[tonumber(oldID)] = newNode.id
                end
            end
        end

        for oldID, newID in pairs(idMap) do
            local nd = sourceNodeData(data, oldID)
            local node = graph.nodes[newID]
            if nd and node then
                local newParent = nd.parentID and idMap[tonumber(nd.parentID)] or nil
                node.parentID = newParent
                node.mirrorSourceNodeID = nd.mirrorSourceNodeID and idMap[tonumber(nd.mirrorSourceNodeID)] or nil
            end
        end
        rebuildChildren(graph)





        if PB.GrabAllFromEntities then
            PB.GrabAllFromEntities(graph)
        else
            for _, node in pairs(graph.nodes or {}) do
                if not node.isPattern and IsValid(node.entity) then
                    node.worldPos = node.entity:GetPos()
                    node.worldAngle = node.entity:GetAngles()
                    if node.parentID and graph.nodes[node.parentID] then
                        local parent = graph.nodes[node.parentID]
                        node.localPos, node.localAngle = WorldToLocal(
                            node.worldPos, node.worldAngle,
                            parent.worldPos, parent.worldAngle
                        )
                    else
                        node.localPos = Vector(node.worldPos)
                        node.localAngle = Angle(node.worldAngle)
                    end
                end
            end
        end

        local pcOrder = {}
        for oldID in pairs(data.pconstraints or {}) do
            pcOrder[#pcOrder + 1] = tonumber(oldID) or oldID
        end
        table.sort(pcOrder, function(a, b) return tonumber(a) < tonumber(b) end)

        local oldToNewPCID = {}

        for _, oldID in ipairs(pcOrder) do
            local pcd = data.pconstraints[oldID] or data.pconstraints[tostring(oldID)]
            if pcd then
                local parentNodeID = idMap[tonumber(pcd.parentNodeID)]
                local childNodeID = idMap[tonumber(pcd.childNodeID)]
                if parentNodeID and childNodeID then
                    local pc = PB.NewPConstraint(
                        graph,
                        parentNodeID,
                        childNodeID,
                        table.Copy(pcd.parentFeature or {}),
                        table.Copy(pcd.childFeature or {}),
                        pcd.mode
                    )
                    if pc then
                        oldToNewPCID[tonumber(oldID)] = pc.id
                        pc.offset = tonumber(pcd.offset) or 0
                        pc.slideX = tonumber(pcd.slideX) or 0
                        pc.slideY = tonumber(pcd.slideY) or 0
                        pc.angle = tonumber(pcd.angle) or 0
                        pc.parentFraction = tonumber(pcd.parentFraction) or 0.5
                        pc.childFraction = tonumber(pcd.childFraction) or 0.5
                        pc.distance = tonumber(pcd.distance) or 100
                        pc.mirrorNodeID = pcd.mirrorNodeID and idMap[tonumber(pcd.mirrorNodeID)] or nil
                        pc.mirrorFace = pcd.mirrorFace
                        pc.mirrorAxis = pcd.mirrorAxis or pcd.mirrorFace or "x"
                        pc.mirrorGConstraints = pcd.mirrorGConstraints and true or false
                        pc.active = pcd.active ~= false
                        pc.flipped = pcd.flipped or false
                        pc.branchParentSide = math.Clamp(math.floor(tonumber(pcd.branchParentSide) or 1), 1, 2)
                        pc.branchChildSide = math.Clamp(math.floor(tonumber(pcd.branchChildSide) or 1), 1, 2)
                        pc.crossLink = pcd.crossLink or false
                    end
                end
            end
        end





        for oldID, newID in pairs(idMap) do
            local nd = sourceNodeData(data, oldID)
            local node = graph.nodes[newID]
            if nd and node and nd.mirrorPCID then
                node.mirrorPCID = oldToNewPCID[tonumber(nd.mirrorPCID)]
            end
        end

        graph.gconstraints = {}
        graph.nextGCID = graph.nextGCID or 1
        local oldToNewGCID = {}
        local pendingGCMirrorMeta = {}
        local gcOrder = {}
        for oldID in pairs(data.gconstraints or {}) do
            gcOrder[#gcOrder + 1] = tonumber(oldID) or oldID
        end
        table.sort(gcOrder, function(a, b) return tonumber(a) < tonumber(b) end)
        for _, oldID in ipairs(gcOrder) do
            local gcd = data.gconstraints[oldID] or data.gconstraints[tostring(oldID)]
            if gcd then
                local nodeA = idMap[tonumber(gcd.nodeA)]
                local nodeB = idMap[tonumber(gcd.nodeB)]
                if nodeA and nodeB and PB.NewGConstraint then
                    local gc = PB.NewGConstraint(graph, nodeA, nodeB, gcd.type, gcd.attachA, gcd.attachB, table.Copy(gcd.params or {}), gcd.name or "")
                    if gc then
                        gc.enabled = gcd.enabled ~= false
                        gc.updateMode = gcd.updateMode or "live"
                        gc.debugVisible = gcd.debugVisible ~= false
                        oldToNewGCID[tonumber(oldID)] = gc.id
                        pendingGCMirrorMeta[gc.id] = {
                            isMirrorGenerated = gcd.isMirrorGenerated or false,
                            mirrorPCID = tonumber(gcd.mirrorPCID),
                            mirrorSourceGCID = tonumber(gcd.mirrorSourceGCID),
                        }
                    end
                end
            end
        end




        for gcid, meta in pairs(pendingGCMirrorMeta) do
            local gc = graph.gconstraints[gcid]
            if gc then
                gc.isMirrorGenerated = meta.isMirrorGenerated or false
                gc.mirrorPCID = meta.mirrorPCID and oldToNewPCID[meta.mirrorPCID] or nil
                gc.mirrorSourceGCID = meta.mirrorSourceGCID and oldToNewGCID[meta.mirrorSourceGCID] or nil
            end
        end

        if PB.SyncAllMirrorGConstraintsForGraph then
            PB.SyncAllMirrorGConstraintsForGraph(graph)
        end

        adoptPastedGConstraintRefs(graph, oldToNewGCID, bucket.createdConstraints, bucket.projectID)

        graph.solverDiagnostic = istable(data.solverDiagnostic) and table.Copy(data.solverDiagnostic) or graph.solverDiagnostic
        graph._pbEditDrive = nil

        PB.Store.SetActive(sid, projectID)
        PB.Store.RefreshDuplicationData(projectID)

        if IsValid(ply) then
            if PB.Store.BroadcastAllProjectLists then PB.Store.BroadcastAllProjectLists() end
            if PB.Store.ResyncPlayerProjectState then PB.Store.ResyncPlayerProjectState(ply) end
        end

        return projectID
    end

    local function importDupeBucketNow(key, bucket, createdConstraints)
        if not bucket then return nil end
        pendingDupes[key] = nil
        completedDupeImports[key] = nil
        clearDupeImportTimers(key)
        if createdConstraints then
            bucket.createdConstraints = createdConstraints
        end
        return importDuplicatedGraph(dupeBucketPlayer(bucket), bucket)
    end

    local function schedulePartialDupeImport(key, bucket)
        if not bucket then return end
        timer.Create(partialImportTimerName(key), 0.15, 1, function()
            local queued = pendingDupes[key]
            if not queued then return end
            if advDupePasteInProgress() then return end
            importDupeBucketNow(key, queued)
        end)
    end

    if duplicator and duplicator.RegisterEntityModifier then
        duplicator.RegisterEntityModifier(DUPE_MOD, function(ply, ent, data)
            if not IsValid(ent) or not istable(data) then return end

            local sourceNodeID = tonumber(data.sourceNodeID)
            local expectedCount = math.max(tonumber(data.expectedCount) or 0, 1)
            if not sourceNodeID then return end

            local sid = IsValid(ply) and ply:SteamID() or "server"
            local key = sid .. "::" .. tostring(data.projectID or data.projectName or "project")

            local bucket = pendingDupes[key]
            if not bucket then
                bucket = {
                    graphJSON = currentGraphJSONForDupe(ply, data) or data.graphJSON,
                    projectID = data.projectID,
                    projectName = data.projectName or "Untitled",
                    expectedCount = expectedCount,
                    entities = {},
                    player = ply,
                    steamID = sid,
                }
                pendingDupes[key] = bucket
            else
                bucket.graphJSON = currentGraphJSONForDupe(ply, data) or bucket.graphJSON
            end

            if not IsValid(bucket.entities[sourceNodeID]) then
                bucket.entities[sourceNodeID] = ent
            end

            local count = 0
            for _ in pairs(bucket.entities) do count = count + 1 end
            if count >= bucket.expectedCount then
                pendingDupes[key] = nil
                completedDupeImports[key] = bucket
                timer.Remove(partialImportTimerName(key))

                if not advDupePasteInProgress() then
                    timer.Simple(0, function()
                        local queued = completedDupeImports[key]
                        if not queued then return end
                        if advDupePasteInProgress() then return end
                        importDupeBucketNow(key, queued)
                    end)
                else
                    timer.Create(fallbackImportTimerName(key), 30, 1, function()
                        local queued = completedDupeImports[key]
                        if not queued then return end
                        importDupeBucketNow(key, queued)
                    end)
                end
            else
                schedulePartialDupeImport(key, bucket)
            end
        end)
    end

    hook.Add("AdvDupe_FinishPasting", "PB_DupeImportAfterAdvDupeFinish", function(pasteBatches)
        local ply = nil
        if istable(pasteBatches) then
            local batch = pasteBatches[1]
            if istable(batch) and IsValid(batch.Player) then
                ply = batch.Player
            elseif IsValid(pasteBatches.Player) then
                ply = pasteBatches.Player
            end
        end
        if not IsValid(ply) then return end

        local sid = ply:SteamID()
        local createdConstraints = collectBatchConstraints(pasteBatches, ply)
        local toImport = {}
        for key, bucket in pairs(completedDupeImports) do
            if bucket and bucket.steamID == sid then
                toImport[#toImport + 1] = { key = key, bucket = bucket }
            end
        end
        for key, bucket in pairs(pendingDupes) do
            if bucket and bucket.steamID == sid then
                toImport[#toImport + 1] = { key = key, bucket = bucket }
            end
        end

        for _, item in ipairs(toImport) do
            importDupeBucketNow(item.key, item.bucket, createdConstraints)
        end
    end)
end







if SERVER then return end

PB = PB or {}
PB.Net = PB.Net or {}

PB.ProjectCache = PB.ProjectCache or {
    active   = nil,
    projects = {},
    folders  = {},
    presence = {},
}

local function applyPayload(tbl)
    if type(tbl) ~= "table" then return end

    PB.ProjectCache.active = (tbl.active ~= "" and tbl.active) or nil
    PB.ProjectCache.projects = {}
    PB.ProjectCache.folders = {}

    for _, project in ipairs(tbl.projects or {}) do
        PB.ProjectCache.projects[project.id] = project
    end
    for _, folder in ipairs(tbl.folders or {}) do
        PB.ProjectCache.folders[folder.id] = folder
    end

    if PB_RequestTreeRefresh then
        PB_RequestTreeRefresh()
    end
end

net.Receive("pb_proj_list", function()
    local n = net.ReadUInt(24)
    local data = net.ReadData(n)
    local json = util.Decompress(data) or data
    local ok, tbl = pcall(util.JSONToTable, json)
    if ok and tbl then
        applyPayload(tbl)
    end
end)

net.Receive("pb_proj_active_changed", function()
    local pid = net.ReadString()
    PB.ProjectCache.active = (pid ~= "" and pid) or nil
    if PB_RequestTreeRefresh then
        PB_RequestTreeRefresh()
    end
end)

net.Receive("pb_proj_presence", function()
    local pid = net.ReadString()
    local n = net.ReadUInt(8)
    local list = {}
    for i = 1, n do
        list[i] = net.ReadString()
    end
    PB.ProjectCache.presence[pid] = list
    if PB_RequestTreeRefresh then
        PB_RequestTreeRefresh()
    end
end)

local function send(name, fn)
    net.Start(name)
    fn()
    net.SendToServer()
end

function PB.Net.ProjectCreate(name, folderID)
    send("pb_proj_create", function()
        net.WriteString(name or "")
        net.WriteString(folderID or "")
    end)
end

function PB.Net.ProjectDelete(pid)
    send("pb_proj_delete", function()
        net.WriteString(pid or "")
    end)
end

function PB.Net.ProjectRename(pid, name)
    send("pb_proj_rename", function()
        net.WriteString(pid or "")
        net.WriteString(name or "")
    end)
end

function PB.Net.ProjectMove(pid, folderID)
    send("pb_proj_move", function()
        net.WriteString(pid or "")
        net.WriteString(folderID or "")
    end)
end

function PB.Net.ProjectSetActive(pid)
    send("pb_proj_set_active", function()
        net.WriteString(pid or "")
    end)
end

function PB.Net.ProjectSetAutoManage(pid, enabled)
    send("pb_proj_set_auto_manage", function()
        net.WriteString(pid or "")
        net.WriteBool(enabled and true or false)
    end)
end

function PB.Net.ProjectShare(projectID, targetSteamID)
    send("pb_proj_share", function()
        net.WriteString(projectID or "")
        net.WriteString(targetSteamID or "")
    end)
end

function PB.Net.ProjectUnshare(projectID, targetSteamID)
    send("pb_proj_unshare", function()
        net.WriteString(projectID or "")
        net.WriteString(targetSteamID or "")
    end)
end

function PB.Net.FolderCreate(name, parentID)
    send("pb_folder_create", function()
        net.WriteString(name or "")
        net.WriteString(parentID or "")
    end)
end

function PB.Net.FolderDelete(fid, recursive)
    send("pb_folder_delete", function()
        net.WriteString(fid or "")
        net.WriteBool(recursive and true or false)
    end)
end

function PB.Net.FolderRename(fid, name)
    send("pb_folder_rename", function()
        net.WriteString(fid or "")
        net.WriteString(name or "")
    end)
end

function PB.Net.FolderMove(fid, parentID)
    send("pb_folder_move", function()
        net.WriteString(fid or "")
        net.WriteString(parentID or "")
    end)
end



