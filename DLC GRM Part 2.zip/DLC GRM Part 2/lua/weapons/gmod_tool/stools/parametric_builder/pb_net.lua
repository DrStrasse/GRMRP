
























if CLIENT then return end

local CFG = PB.Config or {}
local STR = CFG.Strings or {}
local MSG_STR = STR.Messages or {}
local COL = CFG.Colors or {}
local PREFIX = CFG.CommandPrefix or "parametric_builder_"
local KC = nil

local function TraceEvent(category, action, payload)
    if PB.Trace and PB.Trace.Event then PB.Trace.Event(category, action, payload or {}) end
end
local function TraceCommand(ply, name, args, extra)
    if PB.Trace and PB.Trace.Command then PB.Trace.Command(ply, name, args, extra) end
end
local function TNode(node) return PB.Trace and PB.Trace.Node and PB.Trace.Node(node) or nil end
local function TPC(pc, graph) return PB.Trace and PB.Trace.PConstraint and PB.Trace.PConstraint(pc, graph) or nil end
local function TGC(gc, graph) return PB.Trace and PB.Trace.GConstraint and PB.Trace.GConstraint(gc, graph) or nil end
local function TDiag(graph) return PB.Trace and PB.Trace.Diagnostic and PB.Trace.Diagnostic(graph and graph.solverDiagnostic or nil) or nil end

KC = PB and PB.KernelConstraints or nil





util.AddNetworkString(PREFIX .. "sync_graph")
util.AddNetworkString(PREFIX .. "sync_node")
util.AddNetworkString(PREFIX .. "sync_clear")
util.AddNetworkString(PREFIX .. "select_feedback")
util.AddNetworkString(PREFIX .. "sync_pc")
util.AddNetworkString(PREFIX .. "pc_select_mode")
util.AddNetworkString(PREFIX .. "sync_solver_status")
util.AddNetworkString(PREFIX .. "sync_pc_state")
util.AddNetworkString(PREFIX .. "pc_mode_exit")
util.AddNetworkString(PREFIX .. "mirror_select_mode")
util.AddNetworkString(PREFIX .. "mirror_node_picked")
util.AddNetworkString(PREFIX .. "mirror_mode_exit")
util.AddNetworkString(PREFIX .. "sync_delete_node")
util.AddNetworkString(PREFIX .. "sync_gc")
util.AddNetworkString(PREFIX .. "sync_delete_gc")
util.AddNetworkString(PREFIX .. "gc_create")
util.AddNetworkString(PREFIX .. "gc_edit")
util.AddNetworkString(PREFIX .. "gc_delete")
util.AddNetworkString(PREFIX .. "phys_features")







local RATE_LIMIT_INTERVAL = ((PB.Config or {}).Server or {}).rateLimitInterval or 0.05
local lastPropagateTime = {}

local function CheckRateLimit(ply)
    local sid = ply:SteamID()
    local now = CurTime()
    if lastPropagateTime[sid] and (now - lastPropagateTime[sid]) < RATE_LIMIT_INTERVAL then
        TraceEvent("rate_limit", "blocked", {
            player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil,
            steamID = sid,
            elapsed = now - lastPropagateTime[sid],
            interval = RATE_LIMIT_INTERVAL,
        })
        return false
    end
    lastPropagateTime[sid] = now
    return true
end


local function cleanScalarArg(value)
    if value == nil then return "" end
    return string.Trim(tostring(value))
end

local function evalScalarArg(graph, value, fallback)
    local text = cleanScalarArg(value)
    if text == "" then return fallback end

    local direct = tonumber(text)
    if direct ~= nil then return direct end

    if PB.EvalExpression then
        local result = PB.EvalExpression(graph, text)
        if isnumber(result) then return result end
        local numeric = tonumber(result)
        if numeric ~= nil then return numeric end
    end

    return fallback
end

local function scalarArgIsExpression(value)
    local text = cleanScalarArg(value)
    return text ~= "" and tonumber(text) == nil
end

local function partsHaveScalarExpression(parts, axes)
    if not istable(parts) then return false end
    for _, ax in ipairs(axes) do
        if cleanScalarArg(parts[ax]) ~= "" then return true end
    end
    return false
end

local function cleanupPosExprParts(node)
    if not partsHaveScalarExpression(node.exprPosParts, {"x", "y", "z"}) then
        node.exprPosParts = nil
    end



    node.exprPos = nil
end

local function cleanupAngleExprParts(node)
    if not partsHaveScalarExpression(node.exprAngleParts, {"p", "y", "r"}) then
        node.exprAngleParts = nil
    end

    node.exprAngle = nil
end

local function buildExpressionDriveForNode(graph, node, requestedAxes)
    if not graph or not node then return nil end
    local drive = { axes = {} }
    local wanted = {}
    if istable(requestedAxes) then
        for _, item in ipairs(requestedAxes) do
            if item and item.family and item.axis then
                wanted[item.family .. ":" .. item.axis] = true
            end
        end
    end

    local function want(family, axis)
        if not istable(requestedAxes) then return true end
        return wanted[family .. ":" .. axis] == true
    end

    if istable(node.exprPosParts) then
        for _, ax in ipairs({"x", "y", "z"}) do
            local expr = cleanScalarArg(node.exprPosParts[ax])
            if expr ~= "" and want("pos", ax) then
                local value = evalScalarArg(graph, expr, node.localPos and node.localPos[ax] or 0)
                drive.axes[#drive.axes + 1] = {
                    nodeID = node.id,
                    family = "pos",
                    axis = ax,
                    target = value
                }
            end
        end
    end

    if istable(node.exprAngleParts) then
        for _, ax in ipairs({"p", "y", "r"}) do
            local expr = cleanScalarArg(node.exprAngleParts[ax])
            if expr ~= "" and want("ang", ax) then
                local value = evalScalarArg(graph, expr, node.localAngle and node.localAngle[ax] or 0)
                drive.axes[#drive.axes + 1] = {
                    nodeID = node.id,
                    family = "ang",
                    axis = ax,
                    target = value
                }
            end
        end
    end

    if #drive.axes == 0 then return nil end
    return drive
end

local function buildExpressionDriveForGraph(graph)
    if not graph or not graph.nodes then return nil end
    local drive = { axes = {} }

    for _, node in pairs(graph.nodes) do
        local nd = buildExpressionDriveForNode(graph, node)
        if nd and nd.axes then
            for _, axisDrive in ipairs(nd.axes) do
                drive.axes[#drive.axes + 1] = axisDrive
            end
        end
    end

    if #drive.axes == 0 then return nil end
    return drive
end

local function applyVectorArgsToNode(graph, node, xArg, yArg, zArg)
    node.exprPosParts = istable(node.exprPosParts) and table.Copy(node.exprPosParts) or {}

    local values = { x = xArg, y = yArg, z = zArg }
    local resolved = {}

    for _, ax in ipairs({"x", "y", "z"}) do
        local value = values[ax]
        local text = cleanScalarArg(value)
        local cur = node.localPos and node.localPos[ax] or 0
        local out = evalScalarArg(graph, text, cur)
        resolved[ax] = out

        if scalarArgIsExpression(text) then
            local result = PB.EvalExpression and PB.EvalExpression(graph, text) or nil
            if isnumber(result) or tonumber(result) ~= nil then
                node.exprPosParts[ax] = text



            else
                node.exprPosParts[ax] = nil
            end
        else
            node.exprPosParts[ax] = nil
            node.localPos[ax] = math.Round(out, 2)
        end
    end

    cleanupPosExprParts(node)
    return resolved
end

local function applyAngleArgsToNode(graph, node, pArg, yArg, rArg)
    node.exprAngleParts = istable(node.exprAngleParts) and table.Copy(node.exprAngleParts) or {}

    local values = { p = pArg, y = yArg, r = rArg }
    local resolved = {}

    for _, ax in ipairs({"p", "y", "r"}) do
        local value = values[ax]
        local text = cleanScalarArg(value)
        local cur = node.localAngle and node.localAngle[ax] or 0
        local out = evalScalarArg(graph, text, cur)
        resolved[ax] = out

        if scalarArgIsExpression(text) then
            local result = PB.EvalExpression and PB.EvalExpression(graph, text) or nil
            if isnumber(result) or tonumber(result) ~= nil then
                node.exprAngleParts[ax] = text



            else
                node.exprAngleParts[ax] = nil
            end
        else
            node.exprAngleParts[ax] = nil
            node.localAngle[ax] = math.Round(out, 2)
        end
    end

    cleanupAngleExprParts(node)
    return resolved
end

local function copyNodePose(node)
    if not node then return nil end
    return {
        worldPos = Vector(node.worldPos.x, node.worldPos.y, node.worldPos.z),
        worldAngle = Angle(node.worldAngle.p, node.worldAngle.y, node.worldAngle.r),
    }
end

local function captureFeatureFrame(node, feature, fraction)
    if not KC or not node or not feature or not IsValid(node.entity) then return nil end
    local body = {
        node = node,
        featureGeometry = KC.CaptureNodeGeometry(node),
    }
    return KC.GetFeatureFrame(body, feature, copyNodePose(node), tonumber(fraction) or 0.5)
end

local function chooseFlipAxisAndOrigin(graph, pc)
    local parent = graph and graph.nodes[pc and pc.parentNodeID or 0]
    local child = graph and graph.nodes[pc and pc.childNodeID or 0]
    if not parent or not child or not pc or not pc.parentFeature or not pc.childFeature then return nil, nil end

    local parentFrame = captureFeatureFrame(parent, pc.parentFeature, pc.parentFraction)
    local childFrame = captureFeatureFrame(child, pc.childFeature, pc.childFraction)
    if not parentFrame or not childFrame then return nil, nil end

    local axis = nil
    local origin = nil

    if pc.mode == "geometric" and pc.parentFeature.type == "edge" and pc.childFeature.type == "edge" then
        axis = Vector(parentFrame.dir.x, parentFrame.dir.y, parentFrame.dir.z)
        origin = Vector(parentFrame.origin.x, parentFrame.origin.y, parentFrame.origin.z)
    elseif pc.mode == "parallel" or pc.mode == "perpendicular" then
        if parentFrame.dir and parentFrame.dir:LengthSqr() > 1e-10 then
            axis = Vector(parentFrame.dir.x, parentFrame.dir.y, parentFrame.dir.z)
        elseif childFrame.dir and childFrame.dir:LengthSqr() > 1e-10 then
            axis = Vector(childFrame.dir.x, childFrame.dir.y, childFrame.dir.z)
        end
        origin = Vector(child.worldPos.x, child.worldPos.y, child.worldPos.z)
    elseif pc.mode == "geometric" then
        if parentFrame.dir and parentFrame.dir:LengthSqr() > 1e-10 then
            axis = Vector(parentFrame.dir.x, parentFrame.dir.y, parentFrame.dir.z)
            origin = Vector(parentFrame.origin.x, parentFrame.origin.y, parentFrame.origin.z)
        elseif childFrame.dir and childFrame.dir:LengthSqr() > 1e-10 then
            axis = Vector(childFrame.dir.x, childFrame.dir.y, childFrame.dir.z)
            origin = Vector(childFrame.origin.x, childFrame.origin.y, childFrame.origin.z)
        end
    end

    if not axis or axis:LengthSqr() <= 1e-10 then return nil, nil end
    axis:Normalize()
    origin = origin or Vector(child.worldPos.x, child.worldPos.y, child.worldPos.z)
    return origin, axis
end

local function rotateSubtreeAboutAxis(graph, rootID, origin, axis, radians)
    if not graph or not graph.nodes[rootID] or not origin or not axis then return false end
    if axis:LengthSqr() <= 1e-10 then return false end
    axis = Vector(axis.x, axis.y, axis.z)
    axis:Normalize()

    local subtree = PB.SubtreeOrder(graph, rootID)
    if #subtree == 0 then return false end

    for _, nodeID in ipairs(subtree) do
        local node = graph.nodes[nodeID]
        if node and not node.isPattern and IsValid(node.entity) then
            local delta = node.worldPos - origin
            local rel = Vector(delta.x, delta.y, delta.z)
            node.worldPos = origin + PB.Rodrigues(rel, axis, radians)
            node.worldAngle = PB.RotateAngle(node.worldAngle, axis, radians)
        end
    end

    for _, nodeID in ipairs(subtree) do
        local node = graph.nodes[nodeID]
        if node and not node.isPattern then
            if node.parentID and graph.nodes[node.parentID] then
                local parent = graph.nodes[node.parentID]
                node.localPos, node.localAngle = WorldToLocal(node.worldPos, node.worldAngle, parent.worldPos, parent.worldAngle)
            else
                node.localPos = Vector(node.worldPos.x, node.worldPos.y, node.worldPos.z)
                node.localAngle = Angle(node.worldAngle.p, node.worldAngle.y, node.worldAngle.r)
            end
        end
    end

    return true
end

local function nudgeFlipSolution(graph, pc)
    if not graph or not pc or not pc.childNodeID then return false end
    local origin, axis = chooseFlipAxisAndOrigin(graph, pc)
    if not origin or not axis then return false end
    return rotateSubtreeAboutAxis(graph, pc.childNodeID, origin, axis, math.pi)
end






local function GetPlayerGraph(ply)
    if not IsValid(ply) then return nil end
    return PB.GetGraph(ply)
end

local function TouchActiveProject(ply)
    if not IsValid(ply) or not (PB and PB.Store) then return nil end
    local sid = ply:SteamID()
    if PB.Store.TouchActiveForPlayer then
        PB.Store.TouchActiveForPlayer(sid)
    end
    return PB.Store.activeProject and PB.Store.activeProject[sid] or nil
end

local function NotifyProjectMutation(ply)
    local projectID = TouchActiveProject(ply)
    hook.Run("PB_PostGraphMutation", ply, projectID)
end

local function ReplacePlayerProjectGraph(ply, newGraph)
    local sid = IsValid(ply) and ply:SteamID() or "server"
    if PB and PB.Store and PB.Store.ResolveActiveProject then
        local pid = PB.Store.ResolveActiveProject(sid)
        local project = pid and PB.Store.projects[pid] or nil
        if project then
            project.graph = newGraph
            project.modifiedAt = os.time()
        end
    end
    PB.Graphs[sid] = newGraph
    return newGraph
end


local function AuthNode(ply, graph, nodeID)
    if not graph then return nil end
    local node = graph.nodes[nodeID]
    if not node then return nil end
    return node
end


local function AuthPC(ply, graph, pcid)
    if not graph then return nil end
    local pc = graph.pconstraints[pcid]
    if not pc then return nil end
    return pc
end


local function AuthGC(ply, graph, gcid)
    if not graph then return nil end
    local gc = graph.gconstraints and graph.gconstraints[gcid]
    if not gc then return nil end
    return gc
end































local _physSent = {}

local function buildPhysFeaturesPayload(model, features)


    local verts = {}
    for i, v in ipairs(features.vertices) do
        verts[i] = { v.x, v.y, v.z }
    end
    local faces = {}
    for i, f in ipairs(features.faces) do
        faces[i] = {
            n = { f.nx, f.ny, f.nz },
            o = { f.ox, f.oy, f.oz },
            u = { f.ux, f.uy, f.uz },
            v = { f.vx, f.vy, f.vz },
            verts = f.verts,
            sizeMin = f.sizeMin,
        }
    end
    local edges = {}
    for i, e in ipairs(features.edges) do
        edges[i] = {
            vA = e.vA, vB = e.vB,
            nA = { e.nAx, e.nAy, e.nAz },
            nB = { e.nBx, e.nBy, e.nBz },
        }
    end
    local corners = {}
    for i, c in ipairs(features.corners) do
        corners[i] = c.v
    end
    return util.TableToJSON({
        model = model,
        vertices = verts,
        faces = faces,
        edges = edges,
        corners = corners,
    })
end



local function sendPhysFeaturesForModel(ply, model)
    if not IsValid(ply) or not model or model == "" then return end
    local sid = ply:SteamID()
    local set = _physSent[sid]
    if not set then
        set = {}
        _physSent[sid] = set
    end
    if set[model] then return end

    local features = PB.PhysFeatures and PB.PhysFeatures.GetForModel
        and PB.PhysFeatures.GetForModel(model) or nil
    if not features then return end

    local json = buildPhysFeaturesPayload(model, features)
    local compressed = util.Compress(json)
    if not compressed then return end

    set[model] = true
    net.Start(PREFIX .. "phys_features")
    net.WriteUInt(#compressed, 24)
    net.WriteData(compressed, #compressed)
    net.Send(ply)
end
PB.SendPhysFeaturesForModel = sendPhysFeaturesForModel



local function ensurePhysFeaturesForNode(ply, node)
    if not node or not IsValid(ply) then return end
    if IsValid(node.entity) and PB.PhysFeatures and PB.PhysFeatures.BuildForEntity then



        PB.PhysFeatures.BuildForEntity(node.entity)
    end
    sendPhysFeaturesForModel(ply, node.model or (IsValid(node.entity) and node.entity:GetModel()) or "")
end


hook.Add("PlayerDisconnected", "PB_PhysFeatures_Reset", function(ply)
    if IsValid(ply) then _physSent[ply:SteamID()] = nil end
end)

local function SyncNode(ply, graph, nodeID)
    local node = graph.nodes[nodeID]
    if not node then return end




    ensurePhysFeaturesForNode(ply, node)

    local data = {
        id = nodeID,
        localPos = { x = node.localPos.x, y = node.localPos.y, z = node.localPos.z },
        localAngle = { p = node.localAngle.p, y = node.localAngle.y, r = node.localAngle.r },
        worldPos = { x = node.worldPos.x, y = node.worldPos.y, z = node.worldPos.z },
        worldAngle = { p = node.worldAngle.p, y = node.worldAngle.y, r = node.worldAngle.r },
        constraintType = node.constraintType or "none",
        label = node.label or "",
        notes = node.notes or "",
        parentID = node.parentID or 0,
        model = node.model or "",
        entityClass = node.entityClass or (IsValid(node.entity) and node.entity:GetClass()) or "prop_physics",
        locked = node.locked or false,
        visible = node.visible ~= false,
        exprPos = node.exprPos or "",
        exprAngle = node.exprAngle or "",
        exprPosParts = node.exprPosParts or {},
        exprAngleParts = node.exprAngleParts or {},
        dofOverrides = node.dofOverrides or { pos = {}, ang = {} },
        isPattern = node.isPattern or false,
        patternType = node.patternType or "",
        patternParams = node.patternParams or {},
        copyConstraints = node.copyConstraints or false,
        patternConstraintType = node.patternConstraintType or "none",
        patternConstraintParams = node.patternConstraintParams or {},
        isMirrorGenerated = node.isMirrorGenerated or false,
        mirrorSourceNodeID = node.mirrorSourceNodeID or 0,
        mirrorPCID = node.mirrorPCID or 0,
    }

    net.Start(PREFIX .. "sync_node")
    net.WriteString(util.TableToJSON(data))
    net.WriteEntity(IsValid(node.entity) and node.entity or Entity(0))
    local patEnts = node.patternEntities or {}
    net.WriteUInt(#patEnts, 8)
    for _, ent in ipairs(patEnts) do
        net.WriteEntity(IsValid(ent) and ent or Entity(0))
    end
    net.Send(ply)
end

local function SyncPC(ply, graph, pcid)
    local pc = graph.pconstraints[pcid]
    if not pc then return end

    net.Start(PREFIX .. "sync_pc")
    net.WriteUInt(pcid, 24)
    net.WriteBool(false)
    net.WriteString(util.TableToJSON({
        parentNodeID = pc.parentNodeID,
        childNodeID = pc.childNodeID,
        parentFeature = pc.parentFeature,
        childFeature = pc.childFeature,
        mode = pc.mode or "geometric",
        offset = pc.offset,
        slideX = pc.slideX,
        slideY = pc.slideY,
        angle = pc.angle,
        parentFraction = pc.parentFraction,
        childFraction = pc.childFraction,
        distance = pc.distance,
        mirrorNodeID = pc.mirrorNodeID or 0,
        mirrorFace = pc.mirrorFace or "",
        mirrorAxis = pc.mirrorAxis or pc.mirrorFace or "",
        mirrorGConstraints = pc.mirrorGConstraints or false,
        active = pc.active,
        flipped = pc.flipped or false,
        branchParentSide = pc.branchParentSide or 1,
        branchChildSide = pc.branchChildSide or 1,
        crossLink = pc.crossLink or false,
        solverResidual = pc.solverResidual or 0,
        solverWeightedResidual = pc.solverWeightedResidual or 0,
        solverSatisfied = pc.solverSatisfied ~= false,
        solverStatus = pc.solverStatus or "unknown",
    }))
    net.Send(ply)
end

local function SyncPCDelete(ply, pcid)
    net.Start(PREFIX .. "sync_pc")
    net.WriteUInt(pcid, 24)
    net.WriteBool(true)
    net.Send(ply)
end

local function SyncNodeDelete(ply, nodeID)
    net.Start(PREFIX .. "sync_delete_node")
    net.WriteUInt(nodeID, 24)
    net.Send(ply)
end


local function SyncGC(ply, graph, gcid)
    local gc = graph.gconstraints and graph.gconstraints[gcid]
    if not gc then return end

    net.Start(PREFIX .. "sync_gc")
    net.WriteUInt(gcid, 24)
    net.WriteBool(false)
    net.WriteString(util.TableToJSON({
        id = gc.id,
        name = gc.name or "",
        type = gc.type,
        enabled = gc.enabled ~= false,
        nodeA = gc.nodeA,
        nodeB = gc.nodeB,
        attachA = PB.GCSerializeAttachment and PB.GCSerializeAttachment(gc.attachA) or nil,
        attachB = PB.GCSerializeAttachment and PB.GCSerializeAttachment(gc.attachB) or nil,
        params = gc.params or {},
        updateMode = gc.updateMode or "live",
        status = gc.status or "ok",
        debugVisible = gc.debugVisible ~= false,
        isMirrorGenerated = gc.isMirrorGenerated or false,
        mirrorPCID = gc.mirrorPCID,
        mirrorSourceGCID = gc.mirrorSourceGCID,
    }))
    net.Send(ply)
end

local function SyncGCDelete(ply, gcid)
    net.Start(PREFIX .. "sync_gc")
    net.WriteUInt(gcid, 24)
    net.WriteBool(true)
    net.Send(ply)
end

local function SyncSolverStatus(ply, graph)
    local diag = graph.solverDiagnostic
    if not diag then return end

    local diagData = {
        impl = diag.impl or "legacy",
        status = diag.status,
        modelStatus = diag.modelStatus,
        attemptStatus = diag.attemptStatus,
        converged = diag.converged,
        accepted = diag.accepted,
        iterations = diag.iterations,
        residualNorm = diag.residualNorm,
        numEquations = diag.numEquations,
        numUnknowns = diag.numUnknowns,
        rank = diag.rank or 0,
        nullity = diag.nullity or 0,
        redundant = diag.redundant or 0,
        underConstrained = diag.underConstrained,
        overConstrained = {},
        nodeAxes = diag.nodeAxes or {},
        nodeAxisScores = diag.nodeAxisScores or {},
        axisSelection = diag.axisSelection or {},
        branchAttempts = diag.branchAttempts or 0,
        conditionEstimate = diag.conditionEstimate or 0,
        trustRatio = diag.trustRatio or 0,
        groundingModes = diag.groundingModes or {},
        anchorNodeIDs = diag.anchorNodeIDs or {},
        gaugeNodeIDs = diag.gaugeNodeIDs or {},
    }
    for _, oc in ipairs(diag.overConstrained or {}) do
        table.insert(diagData.overConstrained, { pcid = oc.pcid, residual = oc.residual, status = oc.status or "unknown" })
    end
    local pcStatus = {}
    for pcid, pc in pairs(graph.pconstraints) do
        if (pc.solverResidual and pc.solverResidual > 0) or pc.solverSatisfied == false or pc.solverStatus then
            pcStatus[tostring(pcid)] = {
                residual = pc.solverResidual or 0,
                weightedResidual = pc.solverWeightedResidual or 0,
                satisfied = pc.solverSatisfied,
                status = pc.solverStatus or "unknown"
            }
        end
    end
    diagData.pcStatus = pcStatus
    net.Start(PREFIX .. "sync_solver_status")
    net.WriteString(util.TableToJSON(diagData))
    net.Send(ply)
end


local function SyncFull(ply, graph)
    if SERVER and PB and PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    net.Start(PREFIX .. "sync_clear")
    net.Send(ply)

    net.Start(PREFIX .. "sync_graph")
    net.WriteString(util.TableToJSON({
        variables = graph.variables,
        variableMeta = graph.variableMeta or {},
    }))
    net.WriteUInt(table.Count(graph.nodes), 24)
    net.Send(ply)

    for nodeID in pairs(graph.nodes) do
        SyncNode(ply, graph, nodeID)
    end
    for pcid in pairs(graph.pconstraints) do
        SyncPC(ply, graph, pcid)
    end
    for gcid in pairs(graph.gconstraints or {}) do
        SyncGC(ply, graph, gcid)
    end
    SyncSolverStatus(ply, graph)
end
PB.SyncFullToClient = SyncFull


local function SyncUpdate(ply, graph)
    if SERVER and PB and PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    net.Start(PREFIX .. "sync_graph")
    net.WriteString(util.TableToJSON({
        variables = graph.variables,
        variableMeta = graph.variableMeta or {},
    }))
    net.WriteUInt(table.Count(graph.nodes), 24)
    net.Send(ply)

    for nodeID in pairs(graph.nodes) do
        SyncNode(ply, graph, nodeID)
    end
    for pcid in pairs(graph.pconstraints) do
        SyncPC(ply, graph, pcid)
    end
    for gcid in pairs(graph.gconstraints or {}) do
        SyncGC(ply, graph, gcid)
    end
    SyncSolverStatus(ply, graph)

    NotifyProjectMutation(ply)
end


local function SyncPartial(ply, graph, nodeIDs)
    for _, nid in ipairs(nodeIDs) do
        SyncNode(ply, graph, nid)
    end
    for pcid in pairs(graph.pconstraints) do
        SyncPC(ply, graph, pcid)
    end
    for gcid in pairs(graph.gconstraints or {}) do
        SyncGC(ply, graph, gcid)
    end
    SyncSolverStatus(ply, graph)
end

local function GCBuildLive(graph, def, force)
    if PB.GConstraints and PB.GConstraints.EnsureLive then
        return PB.GConstraints.EnsureLive(graph, def, {
            adopt = true,
            forceRebuild = force == true,
            noBuild = false,
        })
    end
    if PB.GConstraints and PB.GConstraints.BuildLive then
        return PB.GConstraints.BuildLive(graph, def, force)
    end
    if def then def.status = "no_gconstraint_builder" end
    return false
end

local function RefreshGConstraintsAfterMutation(graph, primaryGCID, mirrorResult)
    if not graph or not graph.gconstraints then return end

    local wanted = {}
    if primaryGCID then wanted[tonumber(primaryGCID)] = true end

    for _, gcid in ipairs((mirrorResult and mirrorResult.created) or {}) do
        wanted[tonumber(gcid)] = true
    end
    for _, gcid in ipairs((mirrorResult and mirrorResult.updated) or {}) do
        wanted[tonumber(gcid)] = true
    end

    for gcid in pairs(wanted) do
        local def = graph.gconstraints[gcid]
        if def then GCBuildLive(graph, def, true) end
    end
end




































util.AddNetworkString(PREFIX .. "solver_active")

local _solverState = {}
setmetatable(_solverState, { __mode = "k" })

local syncAllMirrorGConstraints
local syncMirrorGCResult
local applyMirrorPosesBeforeGConstraintSync

local function getSolverEntry(graph)
    local s = _solverState[graph]
    if not s then
        s = { active = false, dirty = false }
        _solverState[graph] = s
    end
    return s
end

local function notifySolverActive(ply, active)
    if not IsValid(ply) then return end
    net.Start(PREFIX .. "solver_active")
    net.WriteBool(active and true or false)
    net.Send(ply)
end

local function finishSolve(s, ok)



    local ply = s.ply
    local graph = s.graph






    applyMirrorPosesBeforeGConstraintSync(graph)
    if syncAllMirrorGConstraints then syncAllMirrorGConstraints(graph) end

    if PB.RefreshGConstraints then PB.RefreshGConstraints(graph, false) end

    if IsValid(ply) and graph then
        if s.useFullSync then
            local SyncFull = PB.SyncFullToClient
            if SyncFull then SyncFull(ply, graph) end
        else
            SyncUpdate(ply, graph)
        end
    end

    if PB.KernelDebug and PB.KernelDebug.ShouldAutoDump and PB.KernelDebug.ShouldAutoDump() then
        PB.KernelDebug.EmitGraphDiagnostic(ply, graph, "auto_propagate")
    end

    if PB.Trace and PB.Trace.EndPropagate and s.token then
        PB.Trace.EndPropagate(s.token, ply, graph, ok)
    end

    notifySolverActive(ply, false)

    s.active = false
    s.coroutine = nil
    s.token = nil



    if s.dirty then
        s.dirty = false
        local pending = s.pendingArgs
        s.pendingArgs = nil
        if pending and PB.PropagateAndSync then
            PB.PropagateAndSync(pending.ply, pending.graph, pending.startID,
                pending.reason, pending.context, pending.useFullSync)
        end
    end
end

local function pumpSolvers()


    for graph, s in pairs(_solverState) do
        if s.active and s.coroutine then
            local ok, err = coroutine.resume(s.coroutine)
            if not ok then




                if PB.Log and PB.Log.Error then
                    PB.Log.Error(MSG_STR.solverCoroutineError .. tostring(err))
                else
                    print((CFG.ChatPrefix .. " " .. MSG_STR.solverCoroutineError) .. tostring(err))
                end
                finishSolve(s, false)
            elseif coroutine.status(s.coroutine) == "dead" then


                finishSolve(s, err ~= false)
            end
        end
    end
end
hook.Add("Tick", "PB_SolverPump", pumpSolvers)








local function PropagateAndSync(ply, graph, startID, reason, context, useFullSync)
    if not graph then return end

    local s = getSolverEntry(graph)

    if s.active then



        s.dirty = true
        s.pendingArgs = {
            ply = ply, graph = graph, startID = startID,
            reason = reason, context = context, useFullSync = useFullSync,
        }
        return
    end

    s.active = true
    s.ply = ply
    s.graph = graph
    s.useFullSync = useFullSync and true or false
    s.token = PB.Trace and PB.Trace.BeginPropagate
        and PB.Trace.BeginPropagate(ply, graph, startID, reason or "unspecified", context or {})
        or nil

    notifySolverActive(ply, true)





    s.coroutine = coroutine.create(function()
        return PB.Propagate(graph, startID)
    end)




end
PB.PropagateAndSync = PropagateAndSync

function PB.NotifySelection(ply, nodeID)
    ply.PB_SelectedNode = nodeID
    net.Start(PREFIX .. "select_feedback")
    net.WriteUInt(nodeID or 0, 24)
    net.Send(ply)
end
local NotifySelection = PB.NotifySelection

function PB.NotifyPCModeExit(ply)
    net.Start(PREFIX .. "pc_mode_exit")
    net.Send(ply)
end

function PB.NotifyMirrorNodePicked(ply, sourceNodeID, mirrorNodeID)
    if not IsValid(ply) then return end
    ply.PB_MirrorSelectMode = false
    ply.PB_MirrorState = {}
    net.Start(PREFIX .. "mirror_node_picked")
    net.WriteUInt(math.max(0, tonumber(sourceNodeID) or 0), 24)
    net.WriteUInt(math.max(0, tonumber(mirrorNodeID) or 0), 24)
    net.Send(ply)
end

function PB.NotifyMirrorModeExit(ply)
    if not IsValid(ply) then return end
    ply.PB_MirrorSelectMode = false
    ply.PB_MirrorState = {}
    net.Start(PREFIX .. "mirror_mode_exit")
    net.Send(ply)
end

local function Feedback(ply, message)
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, CFG.ChatPrefix .. " " .. message)
    end
end





net.Receive(PREFIX .. "pc_select_mode", function(_, ply)
    local entering = net.ReadBool()
    ply.PB_PCSelectMode = entering
    if entering then
        ply.PB_PCState = {}
        ply.PB_PCPendingMode = net.ReadString()
    end
    TraceEvent("constraint_ui", "pc_select_mode", {
        player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil,
        entering = entering,
        pendingMode = ply.PB_PCPendingMode,
    })
end)

net.Receive(PREFIX .. "mirror_select_mode", function(_, ply)
    local entering = net.ReadBool()
    ply.PB_MirrorSelectMode = entering
    if entering then
        local sourceID = net.ReadUInt(24)
        ply.PB_MirrorState = { sourceNodeID = sourceID, axis = "x" }
    else
        ply.PB_MirrorState = {}
    end
    TraceEvent("mirror_ui", "mirror_select_mode", {
        player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil,
        entering = entering,
        sourceNodeID = ply.PB_MirrorState and ply.PB_MirrorState.sourceNodeID or nil,
    })
end)


applyMirrorPosesBeforeGConstraintSync = function(graph)
    if graph and PB.ApplyMirrorPConstraints then
        PB.ApplyMirrorPConstraints(graph)
    end
end

local function readGCPayload()
    return util.JSONToTable(net.ReadString() or "{}") or {}
end

local function syncAllGCsToPlayer(ply, graph)
    if not graph or not graph.gconstraints then return end
    for gcid in pairs(graph.gconstraints) do
        SyncGC(ply, graph, gcid)
    end
end

net.Receive(PREFIX .. "gc_create", function(_, ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    if not CheckRateLimit(ply) then return end

    local data = readGCPayload()
    local gcType = tostring(data.type or data.gcType or "")
    if not PB.GCIsSupportedType or not PB.GCIsSupportedType(gcType) then
        Feedback(ply, MSG_STR.unsupportedGConstraint)
        return
    end

    local nodeA = tonumber(data.nodeA)
    local nodeB = tonumber(data.nodeB)
    if not AuthNode(ply, graph, nodeA) or not AuthNode(ply, graph, nodeB) or nodeA == nodeB then
        Feedback(ply, MSG_STR.pickTwoPBProps)
        return
    end

    local def = PB.NewGConstraint(graph, nodeA, nodeB, gcType,
        PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(data.attachA) or data.attachA,
        PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(data.attachB) or data.attachB,
        data.params or {},
        data.name or "")
    if not def then
        Feedback(ply, MSG_STR.createGConstraintFailed)
        return
    end

    def.enabled = data.enabled ~= false
    def.debugVisible = data.debugVisible ~= false
    def.updateMode = data.updateMode or "live"
    GCBuildLive(graph, def, true)
    local mirrorGCResult = syncAllMirrorGConstraints(graph)
    RefreshGConstraintsAfterMutation(graph, def.id, mirrorGCResult)
    PB.RecordAction(graph, "create_gc", { gcID = def.id })
    SyncGC(ply, graph, def.id)
    syncMirrorGCResult(ply, graph, mirrorGCResult)
    if PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    NotifyProjectMutation(ply)







    graph._pbForceGConstraintRebuildOnce = true
    PropagateAndSync(ply, graph, nil, "create_gc", { gc = TGC(def, graph), mirrorGConstraints = mirrorGCResult }, false)

    Feedback(ply, "GC#" .. def.id .. ": " .. (PB.GConstraintSummary and PB.GConstraintSummary(def, graph) or PB.GCTypeLabel(gcType)))
end)

net.Receive(PREFIX .. "gc_edit", function(_, ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    if not CheckRateLimit(ply) then return end

    local data = readGCPayload()
    local gcid = tonumber(data.id or data.gcid)
    local def = AuthGC(ply, graph, gcid)
    if not def then return end

    if data.name ~= nil then def.name = tostring(data.name or "") end
    if data.enabled ~= nil then def.enabled = data.enabled ~= false end
    if data.updateMode ~= nil then def.updateMode = tostring(data.updateMode or "live") end
    if data.debugVisible ~= nil then def.debugVisible = data.debugVisible == true end

    if data.type and PB.GCIsSupportedType and PB.GCIsSupportedType(data.type) then
        def.type = tostring(data.type)
    end

    if data.attachA ~= nil and PB.GCDeserializeAttachment then
        def.attachA = PB.GCDeserializeAttachment(data.attachA)
    end
    if data.attachB ~= nil and PB.GCDeserializeAttachment then
        def.attachB = PB.GCDeserializeAttachment(data.attachB)
    end
    if data.params ~= nil and PB.GCMergeParams then
        def.params = PB.GCMergeParams(def.type, data.params or {})
    end

    GCBuildLive(graph, def, true)
    local mirrorGCResult = syncAllMirrorGConstraints(graph)
    RefreshGConstraintsAfterMutation(graph, def.id, mirrorGCResult)
    PB.RecordAction(graph, "edit_gc", { gcID = def.id })
    SyncGC(ply, graph, def.id)
    syncMirrorGCResult(ply, graph, mirrorGCResult)
    if PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    NotifyProjectMutation(ply)
    Feedback(ply, MSG_STR.updatedGCPrefix .. def.id)
end)

net.Receive(PREFIX .. "gc_delete", function(_, ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end

    local data = readGCPayload()
    local gcid = tonumber(data.id or data.gcid or data[1])
    local def = AuthGC(ply, graph, gcid)
    if not def then return end

    local removed = PB.Trace and PB.Trace.GConstraint and PB.Trace.GConstraint(def, graph) or nil
    PB.RemoveGConstraint(graph, gcid)
    local mirrorGCResult = syncAllMirrorGConstraints(graph)
    RefreshGConstraintsAfterMutation(graph, nil, mirrorGCResult)
    SyncGCDelete(ply, gcid)
    syncMirrorGCResult(ply, graph, mirrorGCResult)
    PB.RecordAction(graph, "delete_gc", { gcID = gcid, removed = removed })
    if PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    NotifyProjectMutation(ply)
    Feedback(ply, MSG_STR.removedGCPrefix .. tostring(gcid))
end)





hook.Add("PhysgunPickup", "PB_PhysgunPickupGConstraints", function(ply, ent)
    if not IsValid(ent) or ent:IsPlayer() then return end

    local graph = PB.GetGraph(ply)
    if not graph then return end
    if PB.GraphAutoManageEnabled and not PB.GraphAutoManageEnabled(graph) then return end

    local node = PB.FindNodeByEntity(graph, ent)
    if not node or node.isPattern then return end

    if PB.ClearGConstraintRuntime then
        PB.ClearGConstraintRuntime(graph, node.id)
    end
end)

hook.Add("PhysgunDrop", "PB_PhysgunDrop", function(ply, ent)
    if not IsValid(ent) or ent:IsPlayer() then return end

    local graph = PB.GetGraph(ply)
    if not graph then return end
    if PB.GraphAutoManageEnabled and not PB.GraphAutoManageEnabled(graph) then return end

    local node = PB.FindNodeByEntity(graph, ent)
    if not node then return end
    if node.isPattern then return end

    PB.GrabFromEntity(graph, node.id)
    PropagateAndSync(ply, graph)
end)






local function AssignSpawnedEntityToPlayer(ply, ent)
    if not IsValid(ply) or not IsValid(ent) then return end

    if ent.CPPISetOwner then
        ent:CPPISetOwner(ply)
    end

    if ent.SetCreator then
        ent:SetCreator(ply)
    end

    ent.PB_SpawnedOwner = ply

    if cleanup and cleanup.Add then
        cleanup.Add(ply, "props", ent)
    end
end

local function RegisterUndo(ply, label, graph, nodeID, removeEntity, undoEnt)
    undo.Create(CFG.AddonName)
    undo.SetPlayer(ply)
    if IsValid(undoEnt) then
        undo.AddEntity(undoEnt)
    end
    undo.AddFunction(function()
        local g = PB.GetGraph(ply)
        local node = g.nodes[nodeID]
        if not node then return end

        if node.isPattern then
            for _, ent in ipairs(node.patternEntities or {}) do
                if IsValid(ent) then ent:Remove() end
            end
            for _, cEnt in ipairs(node.patternConstraints or {}) do
                if IsValid(cEnt) then cEnt:Remove() end
            end
        end

        if removeEntity and IsValid(node.entity) then node.entity:Remove() end
        if IsValid(node.constraintEnt) then node.constraintEnt:Remove() end

        local removedNodes, removedPCs, removedGCs = PB.RemoveNode(g, nodeID, false)
        for _, rid in ipairs(removedNodes) do SyncNodeDelete(ply, rid) end
        for _, pid in ipairs(removedPCs) do SyncPCDelete(ply, pid) end
        for _, gid in ipairs(removedGCs or {}) do SyncGCDelete(ply, gid) end
        SyncUpdate(ply, g)
    end)
    undo.SetCustomUndoText(MSG_STR.undoPrefix .. label)
    undo.Finish()
end
PB.RegisterUndo = RegisterUndo

local function removeMirrorGeneratedSubtree(ply, graph, rootNodeID)
    local entsToRemove = {}
    for _, id in ipairs(PB.SubtreeOrder(graph, rootNodeID) or {}) do
        local n = graph.nodes[id]
        if n and not n.isPattern and IsValid(n.entity) then entsToRemove[#entsToRemove + 1] = n.entity end
        if n and n.isPattern then
            for _, ent in ipairs(n.patternEntities or {}) do if IsValid(ent) then entsToRemove[#entsToRemove + 1] = ent end end
            for _, ent in ipairs(n.patternConstraints or {}) do if IsValid(ent) then entsToRemove[#entsToRemove + 1] = ent end end
        end
    end

    local removedNodes, removedPCs, removedGCs = PB.RemoveNode(graph, rootNodeID, true)
    for _, ent in ipairs(entsToRemove) do if IsValid(ent) then ent:Remove() end end

    for _, rid in ipairs(removedNodes or {}) do SyncNodeDelete(ply, rid) end
    for _, pid in ipairs(removedPCs or {}) do SyncPCDelete(ply, pid) end
    for _, gid in ipairs(removedGCs or {}) do SyncGCDelete(ply, gid) end
    return removedNodes or {}, removedPCs or {}, removedGCs or {}
end


local function copyTable(value)
    if table.Copy then return table.Copy(value or {}) end
    if not istable(value) then return value end
    local out = {}
    for k, v in pairs(value) do
        out[k] = istable(v) and copyTable(v) or v
    end
    return out
end

local function mirrorAxisEquals(a, b)
    local norm = PB.NormalizeMirrorAxis
    a = norm and norm(a) or string.lower(tostring(a or "x"))
    b = norm and norm(b) or string.lower(tostring(b or "x"))
    return a == b
end

local function findMirroredCounterpart(graph, sourceID, mirrorNodeID, axis)
    if not graph or not graph.nodes then return nil end
    sourceID = tonumber(sourceID)
    mirrorNodeID = tonumber(mirrorNodeID)
    for id, node in pairs(graph.nodes) do
        if node and node.isMirrorGenerated and tonumber(node.mirrorSourceNodeID) == sourceID then
            local pc = node.mirrorPCID and graph.pconstraints and graph.pconstraints[node.mirrorPCID] or nil
            if pc and tonumber(pc.mirrorNodeID) == mirrorNodeID and mirrorAxisEquals(pc.mirrorAxis or pc.mirrorFace, axis) then
                return tonumber(id) or node.id
            end
        end
    end
    return nil
end

local function copyVector(value, fallback)
    if isvector and isvector(value) then return Vector(value.x, value.y, value.z) end
    if istable(value) then return Vector(tonumber(value.x) or 0, tonumber(value.y) or 0, tonumber(value.z) or 0) end
    return fallback and Vector(fallback.x, fallback.y, fallback.z) or Vector()
end

local function normalizedVector(value, fallback)
    local out = copyVector(value, fallback)
    if out:LengthSqr() < 0.000001 then
        out = fallback and copyVector(fallback) or Vector(1, 0, 0)
    end
    out:Normalize()
    return out
end

local function reflectVectorAcrossPlane(vec, normal)
    normal = normalizedVector(normal, Vector(1, 0, 0))
    return copyVector(vec) - normal * (2 * copyVector(vec):Dot(normal))
end

local function mirrorPointAcrossPlaneForGC(pos, origin, normal)
    normal = normalizedVector(normal, Vector(1, 0, 0))
    return copyVector(pos) + normal * (normal:Dot(copyVector(origin) - copyVector(pos)) * 2)
end

local function graphAttachmentFromWorld(node, worldPos, worldAng)
    if not node or not worldPos or not worldAng then return nil end
    local nodePos = node.worldPos or (IsValid(node.entity) and node.entity:GetPos()) or Vector()
    local nodeAng = node.worldAngle or (IsValid(node.entity) and node.entity:GetAngles()) or Angle()
    local lp, la = WorldToLocal(copyVector(worldPos), Angle(worldAng.p, worldAng.y, worldAng.r), nodePos, nodeAng)

    local att = {
        localPos = Vector(lp.x, lp.y, lp.z),
        localAngle = Angle(la.p, la.y, la.r),
        source = "mirror",
    }

    if PB.GCRoundGeneratedAttachment then
        return PB.GCRoundGeneratedAttachment(att)
    end

    return att
end

local function mirroredAttachment(graph, fromNodeID, toNodeID, att, mirrorNode, axis)
    if not graph or not mirrorNode or not PB.GCResolveAttachmentWorld then return nil end
    local worldPos, worldAng = PB.GCResolveAttachmentWorld(graph, fromNodeID, att)
    if not worldPos or not worldAng then return nil end

    local normal = PB.GetMirrorPlaneNormal and PB.GetMirrorPlaneNormal(mirrorNode, axis) or Vector(1, 0, 0)
    local origin = PB.GetMirrorPlaneCenter and PB.GetMirrorPlaneCenter(mirrorNode) or (mirrorNode.worldPos or Vector())
    normal = normalizedVector(normal, Vector(1, 0, 0))





    local mirroredPos = mirrorPointAcrossPlaneForGC(worldPos, origin, normal)
    local mirroredForward = reflectVectorAcrossPlane(worldAng:Forward(), normal)
    local mirroredUp = reflectVectorAcrossPlane(worldAng:Up(), normal)

    local mirroredAng
    if PB.GCAngleFromForwardUp then
        mirroredAng = PB.GCAngleFromForwardUp(mirroredForward, mirroredUp)
    else
        mirroredAng = normalizedVector(mirroredForward, Vector(1, 0, 0)):Angle()
    end

    local toNode = graph.nodes and graph.nodes[toNodeID]
    return graphAttachmentFromWorld(toNode, mirroredPos, mirroredAng)
end

local function buildMirroredGConstraint(graph, pc, sourceDef)
    if not graph or not pc or not sourceDef then return nil end

    local sourceID = tonumber(pc.parentNodeID)
    local mirrorChildID = tonumber(pc.childNodeID)
    local mirrorNodeID = tonumber(pc.mirrorNodeID)
    local axis = pc.mirrorAxis or pc.mirrorFace or "x"
    local mirrorNode = graph.nodes and graph.nodes[mirrorNodeID]
    if not sourceID or not mirrorChildID or not mirrorNodeID or not mirrorNode then return nil end

    local sourceOnA = tonumber(sourceDef.nodeA) == sourceID
    if not sourceOnA and tonumber(sourceDef.nodeB) ~= sourceID then return nil end

    local otherID = tonumber(sourceOnA and sourceDef.nodeB or sourceDef.nodeA)
    if not otherID then return nil end

    local targetOtherID = nil
    local mirrorOtherAttachment = false

    if otherID == mirrorNodeID then
        targetOtherID = mirrorNodeID
        mirrorOtherAttachment = true
    else
        targetOtherID = findMirroredCounterpart(graph, otherID, mirrorNodeID, axis)
        mirrorOtherAttachment = targetOtherID ~= nil
    end

    if not targetOtherID then
        targetOtherID = otherID
        mirrorOtherAttachment = false
    end

    local newNodeA, newNodeB, newAttachA, newAttachB
    if sourceOnA then
        newNodeA = mirrorChildID
        newNodeB = targetOtherID
        newAttachA = mirroredAttachment(graph, sourceID, mirrorChildID, sourceDef.attachA, mirrorNode, axis)
        newAttachB = mirrorOtherAttachment and mirroredAttachment(graph, otherID, targetOtherID, sourceDef.attachB, mirrorNode, axis)
            or (PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(sourceDef.attachB) or sourceDef.attachB)
    elseif sourceDef.type == "axis" then





        newNodeA = mirrorChildID
        newNodeB = targetOtherID
        newAttachA = mirroredAttachment(graph, sourceID, mirrorChildID, sourceDef.attachB, mirrorNode, axis)
        newAttachB = mirrorOtherAttachment and mirroredAttachment(graph, otherID, targetOtherID, sourceDef.attachA, mirrorNode, axis)
            or (PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(sourceDef.attachA) or sourceDef.attachA)
    else
        newNodeA = targetOtherID
        newNodeB = mirrorChildID
        newAttachA = mirrorOtherAttachment and mirroredAttachment(graph, otherID, targetOtherID, sourceDef.attachA, mirrorNode, axis)
            or (PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(sourceDef.attachA) or sourceDef.attachA)
        newAttachB = mirroredAttachment(graph, sourceID, mirrorChildID, sourceDef.attachB, mirrorNode, axis)
    end

    if not newNodeA or not newNodeB or newNodeA == newNodeB or not newAttachA or not newAttachB then return nil end

    local name = tostring(sourceDef.name or "")
    if name ~= "" then name = name .. " Mirror" end

    return {
        nodeA = newNodeA,
        nodeB = newNodeB,
        attachA = newAttachA,
        attachB = newAttachB,
        type = sourceDef.type,
        params = copyTable(sourceDef.params or {}),
        name = name,
        enabled = sourceDef.enabled ~= false,
        updateMode = sourceDef.updateMode or "live",
        debugVisible = sourceDef.debugVisible ~= false,
    }
end

local function removeMirroredGConstraintsForPC(graph, pcid, keep)
    local removed = {}
    if not graph or not graph.gconstraints then return removed end
    pcid = tonumber(pcid)
    keep = keep or {}

    for gcid, def in pairs(graph.gconstraints) do
        if def and tonumber(def.mirrorPCID) == pcid and not keep[gcid] then
            removed[#removed + 1] = gcid
        end
    end

    for _, gcid in ipairs(removed) do
        if PB.RemoveGConstraint then PB.RemoveGConstraint(graph, gcid) end
    end

    return removed
end

function PB.SyncMirrorGConstraintsForPC(graph, pc)
    local result = { created = {}, updated = {}, removed = {} }
    if not graph or not pc or pc.mode ~= "mirror" then return result end





    applyMirrorPosesBeforeGConstraintSync(graph)

    if pc.mirrorGConstraints ~= true then
        result.removed = removeMirroredGConstraintsForPC(graph, pc.id)
        return result
    end

    local sourceID = tonumber(pc.parentNodeID)
    if not sourceID or not graph.gconstraints then return result end

    local bySource = {}
    for gcid, def in pairs(graph.gconstraints) do
        if def and tonumber(def.mirrorPCID) == tonumber(pc.id) and def.mirrorSourceGCID then
            bySource[tonumber(def.mirrorSourceGCID)] = gcid
        end
    end

    local keep = {}
    local sourceDefs = {}
    local pcID = tonumber(pc.id)
    local sourceNode = graph.nodes and graph.nodes[sourceID] or nil
    local allowGeneratedSources = sourceNode and sourceNode.isMirrorGenerated == true

    for gcid, def in pairs(graph.gconstraints) do
        local touchesSource = def and (tonumber(def.nodeA) == sourceID or tonumber(def.nodeB) == sourceID)
        local generatedByMirror = def and (def.isMirrorGenerated or def.mirrorSourceGCID or def.mirrorPCID)






        if touchesSource and (not generatedByMirror or (allowGeneratedSources and tonumber(def.mirrorPCID) ~= pcID)) then
            sourceDefs[#sourceDefs + 1] = { id = gcid, def = def }
        end
    end
    table.sort(sourceDefs, function(a, b) return tonumber(a.id) < tonumber(b.id) end)

    for _, row in ipairs(sourceDefs) do
        local spec = buildMirroredGConstraint(graph, pc, row.def)
        if spec then
            local existingID = bySource[tonumber(row.id)]
            local mirrorDef = existingID and graph.gconstraints[existingID] or nil

            if mirrorDef then
                if PB.GConstraints and PB.GConstraints.RemoveRuntimeRefs then
                    PB.GConstraints.RemoveRuntimeRefs(mirrorDef)
                end
                mirrorDef.type = spec.type
                mirrorDef.name = spec.name
                mirrorDef.enabled = spec.enabled
                mirrorDef.nodeA = spec.nodeA
                mirrorDef.nodeB = spec.nodeB
                mirrorDef.attachA = spec.attachA
                mirrorDef.attachB = spec.attachB
                mirrorDef.params = spec.params
                mirrorDef.updateMode = spec.updateMode
                mirrorDef.debugVisible = spec.debugVisible
                mirrorDef.status = "pending"
                mirrorDef.mirrorPCID = pc.id
                mirrorDef.mirrorSourceGCID = row.id
                mirrorDef.isMirrorGenerated = true
                keep[existingID] = true
                result.updated[#result.updated + 1] = existingID
            elseif PB.NewGConstraint then
                mirrorDef = PB.NewGConstraint(graph, spec.nodeA, spec.nodeB, spec.type, spec.attachA, spec.attachB, spec.params, spec.name)
                if mirrorDef then
                    mirrorDef.enabled = spec.enabled
                    mirrorDef.updateMode = spec.updateMode
                    mirrorDef.debugVisible = spec.debugVisible
                    mirrorDef.mirrorPCID = pc.id
                    mirrorDef.mirrorSourceGCID = row.id
                    mirrorDef.isMirrorGenerated = true
                    keep[mirrorDef.id] = true
                    result.created[#result.created + 1] = mirrorDef.id
                end
            end
        end
    end

    local removed = removeMirroredGConstraintsForPC(graph, pc.id, keep)
    for _, id in ipairs(removed) do result.removed[#result.removed + 1] = id end

    return result
end

syncAllMirrorGConstraints = function(graph)
    local result = { created = {}, updated = {}, removed = {} }
    if not graph or not graph.pconstraints then return result end

    applyMirrorPosesBeforeGConstraintSync(graph)

    for _, pc in pairs(graph.pconstraints) do
        if pc and pc.mode == "mirror" then
            local r = PB.SyncMirrorGConstraintsForPC(graph, pc)
            for _, id in ipairs(r.created or {}) do result.created[#result.created + 1] = id end
            for _, id in ipairs(r.updated or {}) do result.updated[#result.updated + 1] = id end
            for _, id in ipairs(r.removed or {}) do result.removed[#result.removed + 1] = id end
        end
    end

    return result
end
PB.SyncAllMirrorGConstraintsForGraph = syncAllMirrorGConstraints

syncMirrorGCResult = function(ply, graph, result)
    if not result then return end
    local sent = {}
    for _, gcid in ipairs(result.removed or {}) do
        if not sent["d" .. tostring(gcid)] then
            SyncGCDelete(ply, gcid)
            sent["d" .. tostring(gcid)] = true
        end
    end
    for _, gcid in ipairs(result.created or {}) do
        if not sent["u" .. tostring(gcid)] then
            SyncGC(ply, graph, gcid)
            sent["u" .. tostring(gcid)] = true
        end
    end
    for _, gcid in ipairs(result.updated or {}) do
        if not sent["u" .. tostring(gcid)] then
            SyncGC(ply, graph, gcid)
            sent["u" .. tostring(gcid)] = true
        end
    end
end

function PB.CreateMirrorNodeAndPC(ply, graph, sourceID, mirrorNodeID, axis, mirrorGConstraints)
    if not graph then return nil, MSG_STR.noGraph end
    sourceID = tonumber(sourceID)
    mirrorNodeID = tonumber(mirrorNodeID)
    axis = PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(axis) or string.lower(tostring(axis or "x"))
    if axis ~= "x" and axis ~= "y" and axis ~= "z" then axis = "x" end
    mirrorGConstraints = mirrorGConstraints == true or mirrorGConstraints == "1" or mirrorGConstraints == 1

    local sourceNode = AuthNode(ply, graph, sourceID)
    local mirrorNode = AuthNode(ply, graph, mirrorNodeID)
    if not sourceNode or sourceNode.isPattern then return nil, MSG_STR.selectValidSourceNode end
    if not mirrorNode or mirrorNode.isPattern then return nil, MSG_STR.pickValidMirrorNode end
    if not IsValid(sourceNode.entity) then return nil, MSG_STR.sourceNodeHasNoProp end
    if not IsValid(mirrorNode.entity) then return nil, MSG_STR.mirrorNodeHasNoProp end
    if not CheckRateLimit(ply) then return nil, MSG_STR.rateLimited end

    local pos, ang = PB.ComputeMirrorTransform(sourceNode, mirrorNode, axis)
    if not pos or not ang then return nil, MSG_STR.computeMirrorFailed end

    local ent, spawnInfo = PB.SpawnEntityLikeSource(sourceNode.entity, pos, ang)
    if not IsValid(ent) then return nil, MSG_STR.createPropFailed end
    AssignSpawnedEntityToPlayer(ply, ent)

    if PB.GraphAutoManageEnabled and PB.GraphAutoManageEnabled(graph) then
        local phys = ent:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableMotion(false)
            phys:Sleep()
        end
    end

    local lp, la = WorldToLocal(pos, ang, sourceNode.worldPos, sourceNode.worldAngle)
    local mirrorChild = PB.NewNode(graph, ent, sourceID, Vector(lp.x, lp.y, lp.z), Angle(la.p, la.y, la.r))
    mirrorChild.model = ent:GetModel()
    if spawnInfo then
        mirrorChild.entityClass = spawnInfo.class or ent:GetClass()
        mirrorChild.entitySkin = spawnInfo.skin
        mirrorChild.entityMaterial = spawnInfo.material
        mirrorChild.entityColor = spawnInfo.color
        mirrorChild.entityBodygroups = spawnInfo.bodygroups
        mirrorChild.entityKeyValues = spawnInfo.keyValues
    end
    mirrorChild.worldPos = Vector(pos.x, pos.y, pos.z)
    mirrorChild.worldAngle = Angle(ang.p, ang.y, ang.r)
    mirrorChild.label = (sourceNode.label or (MSG_STR.nodePrefix .. tostring(sourceID))) .. MSG_STR.mirrorSuffix
    mirrorChild.isMirrorGenerated = true
    mirrorChild.mirrorSourceNodeID = sourceID

    local pc = PB.NewPConstraint(graph, sourceID, mirrorChild.id,
        { type = "face", id = "+x" }, { type = "face", id = "+x" }, "mirror")
    if not pc then
        graph._entityIndex[ent] = nil
        graph.nodes[mirrorChild.id] = nil
        if graph.nodes[sourceID] then graph.nodes[sourceID].children[mirrorChild.id] = nil end
        if IsValid(ent) then ent:Remove() end
        return nil, "Could not create mirror PConstraint"
    end

    pc.mirrorNodeID = mirrorNodeID
    pc.mirrorAxis = axis
    pc.mirrorFace = axis
    pc.mirrorGConstraints = mirrorGConstraints and true or false
    pc.active = true
    mirrorChild.mirrorPCID = pc.id
    PB.ApplyMirrorPConstraint(graph, pc)

    local mirrorGCResult = PB.SyncMirrorGConstraintsForPC and PB.SyncMirrorGConstraintsForPC(graph, pc) or nil
    local mirroredGCCount = #(mirrorGCResult and mirrorGCResult.created or {}) + #(mirrorGCResult and mirrorGCResult.updated or {})

    RegisterUndo(ply, MSG_STR.mirrorUndoPrefix .. mirrorChild.label, graph, mirrorChild.id, false, ent)





    if PB.SyncFullToClient then
        PB.SyncFullToClient(ply, graph)
    else
        SyncUpdate(ply, graph)
    end

    PropagateAndSync(ply, graph, nil, "create_mirror_pc", { pc = TPC(pc, graph), sourceID = sourceID, mirrorNodeID = mirrorNodeID, axis = axis, mirrorGConstraints = pc.mirrorGConstraints, mirroredGConstraints = mirroredGCCount }, true)
    return pc, nil
end





concommand.Add(PREFIX .. "add_root", function(ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end

    local trace = ply:GetEyeTrace()
    if not IsValid(trace.Entity) or trace.Entity:IsPlayer() or trace.Entity:IsWorld() then
        Feedback(ply, MSG_STR.aimAtProp)
        return
    end
    if PB.FindNodeByEntity(graph, trace.Entity) then
        Feedback(ply, MSG_STR.alreadyInGraph)
        return
    end

    local ent = trace.Entity
    local node = PB.NewNode(graph, ent, nil, ent:GetPos(), ent:GetAngles())
    node.model = ent:GetModel()
    node.worldPos = ent:GetPos()
    node.worldAngle = ent:GetAngles()

    NotifySelection(ply, node.id)
    RegisterUndo(ply, MSG_STR.rootUndoPrefix .. node.label, graph, node.id, false)
    Feedback(ply, MSG_STR.rootPrefix .. node.label)
    SyncUpdate(ply, graph)
end)

concommand.Add(PREFIX .. "select_node", function(ply, _, args)
    NotifySelection(ply, tonumber(args[1]))
end)

concommand.Add(PREFIX .. "set_pos_all", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local nodeID = tonumber(args[1])
    local node = AuthNode(ply, graph, nodeID)
    TraceCommand(ply, PREFIX .. "set_pos_all", args, { nodeID = nodeID, nodeBefore = TNode(node), diagBefore = TDiag(graph) })
    if not node then return end
    if not CheckRateLimit(ply) then return end

    local before = TNode(node)
    local requested = applyVectorArgsToNode(graph, node, args[2], args[3], args[4])
    local editAxis = tostring(args[5] or "")
    if editAxis == "x" or editAxis == "y" or editAxis == "z" then
        local axisIsExpression = istable(node.exprPosParts) and cleanScalarArg(node.exprPosParts[editAxis]) ~= ""
        if axisIsExpression then
            graph._pbEditDrive = buildExpressionDriveForNode(graph, node, {{ family = "pos", axis = editAxis }})
        else
            graph._pbEditDrive = { nodeID = node.id, family = "pos", axis = editAxis }
        end
    else
        graph._pbEditDrive = nil
    end
    node.snapParentFace = nil
    node.snapChildFace = nil
    local afterAssign = TNode(node)
    TraceEvent("dof", "set_pos_all_apply", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, nodeID = node.id, before = before, requested = requested, afterAssign = afterAssign, diagBefore = TDiag(graph) })
    PropagateAndSync(ply, graph, node.id, "set_pos_all", { nodeID = node.id, before = before, requested = requested, afterAssign = afterAssign })
end)

concommand.Add(PREFIX .. "set_ang_all", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local nodeID = tonumber(args[1])
    local node = AuthNode(ply, graph, nodeID)
    TraceCommand(ply, PREFIX .. "set_ang_all", args, { nodeID = nodeID, nodeBefore = TNode(node), diagBefore = TDiag(graph) })
    if not node then return end
    if not CheckRateLimit(ply) then return end

    local before = TNode(node)
    local requested = applyAngleArgsToNode(graph, node, args[2], args[3], args[4])
    local editAxis = tostring(args[5] or "")
    if editAxis == "p" or editAxis == "y" or editAxis == "r" then
        local axisIsExpression = istable(node.exprAngleParts) and cleanScalarArg(node.exprAngleParts[editAxis]) ~= ""
        if axisIsExpression then
            graph._pbEditDrive = buildExpressionDriveForNode(graph, node, {{ family = "ang", axis = editAxis }})
        else
            graph._pbEditDrive = { nodeID = node.id, family = "ang", axis = editAxis }
        end
    else
        graph._pbEditDrive = nil
    end
    local afterAssign = TNode(node)
    TraceEvent("dof", "set_ang_all_apply", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, nodeID = node.id, before = before, requested = requested, afterAssign = afterAssign, diagBefore = TDiag(graph) })
    PropagateAndSync(ply, graph, node.id, "set_ang_all", { nodeID = node.id, before = before, requested = requested, afterAssign = afterAssign })
end)

concommand.Add(PREFIX .. "set_expr_pos", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    if not CheckRateLimit(ply) then return end

    local before = TNode(node)
    node.exprPos = (args[2] == "nil" or args[2] == "") and nil or args[2]
    node.exprPosParts = nil
    TraceEvent("dof", "set_expr_pos", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, nodeID = node.id, before = before, afterAssign = TNode(node), expr = node.exprPos })
    PropagateAndSync(ply, graph, node.parentID or node.id, "set_expr_pos", { nodeID = node.id, expr = node.exprPos })
end)

concommand.Add(PREFIX .. "set_expr_ang", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    if not CheckRateLimit(ply) then return end

    local before = TNode(node)
    node.exprAngle = (args[2] == "nil" or args[2] == "") and nil or args[2]
    node.exprAngleParts = nil
    TraceEvent("dof", "set_expr_ang", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, nodeID = node.id, before = before, afterAssign = TNode(node), expr = node.exprAngle })
    PropagateAndSync(ply, graph, node.parentID or node.id, "set_expr_ang", { nodeID = node.id, expr = node.exprAngle })
end)


concommand.Add(PREFIX .. "set_dof_override", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    if not CheckRateLimit(ply) then return end

    local family = tostring(args[2] or "")
    local axis = tostring(args[3] or "")
    local mode = tostring(args[4] or "auto")

    local validPos = family == "pos" and (axis == "x" or axis == "y" or axis == "z")
    local validAng = family == "ang" and (axis == "p" or axis == "y" or axis == "r")
    if not validPos and not validAng then return end
    if mode ~= "lock" and mode ~= "unlock" then mode = nil end

    node.dofOverrides = istable(node.dofOverrides) and node.dofOverrides or { pos = {}, ang = {} }
    node.dofOverrides.pos = istable(node.dofOverrides.pos) and node.dofOverrides.pos or {}
    node.dofOverrides.ang = istable(node.dofOverrides.ang) and node.dofOverrides.ang or {}
    node.dofOverrides[family][axis] = mode

    PropagateAndSync(ply, graph, node.id, "set_dof_override", { nodeID = node.id, family = family, axis = axis, mode = mode or "auto" })
end)

concommand.Add(PREFIX .. "snap_to_face", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node or not node.parentID then return end
    local parent = graph.nodes[node.parentID]
    if not parent or not IsValid(parent.entity) or not IsValid(node.entity) then return end
    if not CheckRateLimit(ply) then return end

    local gap = tonumber(args[4]) or 0
    node.localPos = PB.ComputeSnapOffset(parent.entity, node.entity, args[2], args[3], node.localAngle, gap)
    node.snapParentFace = args[2]
    node.snapChildFace = args[3]
    node.snapGap = gap
    PropagateAndSync(ply, graph, node.parentID)
    Feedback(ply, "Snapped")
end)

concommand.Add(PREFIX .. "set_constraint", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    if not CheckRateLimit(ply) then return end

    PB.ClearConstraint(node)
    node.constraintType = "none"
    node.constraintParams = {}
    TouchActiveProject(ply)
    SyncNode(ply, graph, node.id)
    NotifyProjectMutation(ply)
    Feedback(ply, MSG_STR.legacyManualRemoved)
end)

concommand.Add(PREFIX .. "set_cparam", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    if not CheckRateLimit(ply) then return end

    PB.ClearConstraint(node)
    node.constraintType = "none"
    node.constraintParams = {}
    TouchActiveProject(ply)
    SyncNode(ply, graph, node.id)
    NotifyProjectMutation(ply)
    Feedback(ply, MSG_STR.legacyManualRemoved)
end)

concommand.Add(PREFIX .. "set_variable", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    if not args[1] or args[1] == "" then return end
    if not CheckRateLimit(ply) then return end

    PB.SetVariable(graph, args[1], tonumber(args[2]) or 0)
    PB.RecordAction(graph, "set_variable", { name = args[1] })
    graph._pbEditDrive = buildExpressionDriveForGraph(graph)
    TouchActiveProject(ply)
    if PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    PropagateAndSync(ply, graph)
    Feedback(ply, "$" .. args[1] .. " = " .. (args[2] or "0"))
end)

concommand.Add(PREFIX .. "del_variable", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    if not args[1] then return end
    graph.variables[args[1]] = nil
    if graph.variableMeta then graph.variableMeta[args[1]] = nil end
    graph._pbEditDrive = buildExpressionDriveForGraph(graph)
    TouchActiveProject(ply)
    if PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    PropagateAndSync(ply, graph)
end)

concommand.Add(PREFIX .. "set_variable_meta", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    if not args[1] or args[1] == "" then return end
    graph.variableMeta = graph.variableMeta or {}
    graph.variableMeta[args[1]] = graph.variableMeta[args[1]] or {}
    local meta = graph.variableMeta[args[1]]
    if args[2] == "min" then meta.min = tonumber(args[3])
    elseif args[2] == "max" then meta.max = tonumber(args[3])
    elseif args[2] == "step" then meta.step = tonumber(args[3]) end
    TouchActiveProject(ply)
    if PB.Store and PB.Store.RefreshDuplicationDataForGraph then
        PB.Store.RefreshDuplicationDataForGraph(graph)
    end
    SyncUpdate(ply, graph)
end)

concommand.Add(PREFIX .. "rename_node", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    node.label = args[2] or node.label
    TouchActiveProject(ply)
    SyncNode(ply, graph, node.id)
    NotifyProjectMutation(ply)
end)

concommand.Add(PREFIX .. "set_notes", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    node.notes = (args[2] and args[2] ~= "") and args[2] or nil
    TouchActiveProject(ply)
    SyncNode(ply, graph, node.id)
    NotifyProjectMutation(ply)
end)

concommand.Add(PREFIX .. "toggle_lock", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    node.locked = not node.locked
    TouchActiveProject(ply)
    SyncNode(ply, graph, node.id)
    NotifyProjectMutation(ply)
end)

concommand.Add(PREFIX .. "toggle_visibility", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local node = AuthNode(ply, graph, tonumber(args[1]))
    if not node then return end
    node.visible = not node.visible

    if IsValid(node.entity) then
        if node.visible then
            node.entity:SetNoDraw(false)
            node.entity:SetColor(COL.restoreEntityColor)
        else
            node.entity:SetNoDraw(true)
        end
    end
    TouchActiveProject(ply)
    SyncNode(ply, graph, node.id)
    NotifyProjectMutation(ply)
    Feedback(ply, node.label .. (node.visible and MSG_STR.shown or MSG_STR.hidden))
end)

concommand.Add(PREFIX .. "remove_node", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local nodeID = tonumber(args[1])
    local removeChildren = args[2] == "1"
    local node = AuthNode(ply, graph, nodeID)
    if not node then return end

    local entsToRemove = {}
    local function collectEntities(n)
        if IsValid(n.entity) then table.insert(entsToRemove, n.entity) end
        if n.isPattern then
            for _, ent in ipairs(n.patternEntities or {}) do
                if IsValid(ent) then table.insert(entsToRemove, ent) end
            end
            for _, cEnt in ipairs(n.patternConstraints or {}) do
                if IsValid(cEnt) then table.insert(entsToRemove, cEnt) end
            end
        end
        if IsValid(n.constraintEnt) then table.insert(entsToRemove, n.constraintEnt) end
    end

    if removeChildren then
        for _, id in ipairs(PB.SubtreeOrder(graph, nodeID)) do
            local n = graph.nodes[id]
            if n then collectEntities(n) end
        end
    else
        collectEntities(node)
    end

    local removedNodes, removedPCs, removedGCs = PB.RemoveNode(graph, nodeID, removeChildren)

    for _, ent in ipairs(entsToRemove) do
        if IsValid(ent) then ent:Remove() end
    end


    for _, rid in ipairs(removedNodes) do SyncNodeDelete(ply, rid) end
    for _, pid in ipairs(removedPCs) do SyncPCDelete(ply, pid) end
    for _, gid in ipairs(removedGCs or {}) do SyncGCDelete(ply, gid) end

    if ply.PB_SelectedNode == nodeID then NotifySelection(ply, nil) end


    SyncUpdate(ply, graph)
end)

concommand.Add(PREFIX .. "propagate_all", function(ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    if not CheckRateLimit(ply) then return end
    graph._pbForceGConstraintRebuildOnce = true
    PropagateAndSync(ply, graph)
    Feedback(ply, "Propagated")
end)

concommand.Add(PREFIX .. "diag_dump", function(ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    if PB.KernelDebug and PB.KernelDebug.EmitGraphDiagnostic then
        PB.KernelDebug.EmitGraphDiagnostic(ply, graph, "manual_dump")
    else
        Feedback(ply, MSG_STR.kernelDebugMissing)
    end
end)

concommand.Add(PREFIX .. "diag_propagate_dump", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local startID = tonumber(args[1] or 0)
    if not CheckRateLimit(ply) then return end
    graph._pbForceGConstraintRebuildOnce = true
    PB.Propagate(graph, startID and startID > 0 and startID or nil)
    if PB.RefreshGConstraints then PB.RefreshGConstraints(graph, false) end
    SyncUpdate(ply, graph)
    if PB.KernelDebug and PB.KernelDebug.EmitGraphDiagnostic then
        PB.KernelDebug.EmitGraphDiagnostic(ply, graph, "manual_propagate_dump")
    end
end)

concommand.Add(PREFIX .. "diag_autodump", function(ply, _, args)
    local cv = GetConVar("parametric_builder_diag_autodump")
    local lv = GetConVar("parametric_builder_diag_level")
    if args[1] ~= nil and cv then
        cv:SetBool((tonumber(args[1]) or 0) ~= 0)
    end
    if args[2] ~= nil and lv then
        lv:SetInt(math.Clamp(math.floor(tonumber(args[2]) or 1), 0, 2))
    end
    Feedback(ply, string.format("diag autodump=%s level=%s", cv and tostring(cv:GetBool()) or "nil", lv and tostring(lv:GetInt()) or "nil"))
end)

concommand.Add(PREFIX .. "refresh_from_world", function(ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    PB.GrabAllFromEntities(graph)
    PropagateAndSync(ply, graph)
    Feedback(ply, MSG_STR.refreshedFromWorld)
end)

concommand.Add(PREFIX .. "clear_all", function(ply)
    local graph = GetPlayerGraph(ply)
    if not graph then return end

    graph._entityIndex = {}

    for _, node in pairs(graph.nodes) do
        if IsValid(node.entity) then node.entity:Remove() end
        if IsValid(node.constraintEnt) then node.constraintEnt:Remove() end
        if node.isPattern then
            for _, ent in ipairs(node.patternEntities or {}) do if IsValid(ent) then ent:Remove() end end
            for _, cEnt in ipairs(node.patternConstraints or {}) do if IsValid(cEnt) then cEnt:Remove() end end
        end
    end
    for _, gc in pairs(graph.gconstraints or {}) do
        if PB.GConstraints and PB.GConstraints.RemoveRuntimeRefs then
            PB.GConstraints.RemoveRuntimeRefs(gc)
        else
            for _, ent in ipairs(gc.runtimeEnts or gc.liveRefs or {}) do if IsValid(ent) then ent:Remove() end end
        end
    end

    graph = ReplacePlayerProjectGraph(ply, PB.NewGraph())
    NotifySelection(ply, nil)
    SyncFull(ply, graph)
    NotifyProjectMutation(ply)
    Feedback(ply, "Cleared")
end)

concommand.Add(PREFIX .. "reparent", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local nodeID = tonumber(args[1])
    if not nodeID or not AuthNode(ply, graph, nodeID) then return end
    if not CheckRateLimit(ply) then return end

    local newParent = tonumber(args[2])
    if newParent == 0 then newParent = nil end

    if PB.ReparentNode(graph, nodeID, newParent) then
        PropagateAndSync(ply, graph)
        Feedback(ply, "Reparented")
    else
        Feedback(ply, MSG_STR.reparentCycle)
    end
end)





concommand.Add(PREFIX .. "create_pc", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local parentNodeID = tonumber(args[1])
    local childNodeID = tonumber(args[2])
    if not parentNodeID or not childNodeID then return end
    if not AuthNode(ply, graph, parentNodeID) or not AuthNode(ply, graph, childNodeID) then return end

    local function parseFeatureID(featureType, rawID)


        if type(rawID) == "string" and rawID:sub(1, 1) == "p" then return rawID end
        if featureType == "edge" or featureType == "corner" then return tonumber(rawID) end
        return rawID
    end

    local parentFeature = { type = args[3], id = parseFeatureID(args[3], args[4]) }
    local childFeature = { type = args[5], id = parseFeatureID(args[5], args[6]) }
    local mode = args[7] or "geometric"

    if PB.IsModeValidForFeatures and not PB.IsModeValidForFeatures(mode, parentFeature.type, childFeature.type) then
        Feedback(ply, (PB.MODE_NAMES and PB.MODE_NAMES[mode] or mode)
            .. " not valid for " .. tostring(parentFeature.type) .. "/" .. tostring(childFeature.type))
        return
    end

    TraceEvent("pconstraint", "create_pc_attempt", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, args = args, parentNode = TNode(graph.nodes[parentNodeID]), childNode = TNode(graph.nodes[childNodeID]), parentFeature = parentFeature, childFeature = childFeature, mode = mode, diagBefore = TDiag(graph), graph = PB.Trace and PB.Trace.GraphSummary and PB.Trace.GraphSummary(graph) or nil })
    local pc = PB.NewPConstraint(graph, parentNodeID, childNodeID, parentFeature, childFeature, mode)
    if not pc then
        TraceEvent("pconstraint", "create_pc_failed", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, args = args, parentNodeID = parentNodeID, childNodeID = childNodeID, mode = mode, reason = "cycle_or_invalid" })
        Feedback(ply, MSG_STR.createCycle)
        return
    end

    PB.RecordAction(graph, "create_pc", { pcID = pc.id })
    TraceEvent("pconstraint", "create_pc_success_before_solve", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pc = TPC(pc, graph), summary = PB.DescribePConstraint(pc, graph) })
    PropagateAndSync(ply, graph, nil, "create_pc", { pc = TPC(pc, graph), summary = PB.DescribePConstraint(pc, graph) })
    TraceEvent("pconstraint", "create_pc_success_after_solve", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pc = TPC(pc, graph), summary = PB.DescribePConstraint(pc, graph), diagAfter = TDiag(graph) })
    Feedback(ply, "PC#" .. pc.id .. ": " .. PB.DescribePConstraint(pc, graph))
end)

concommand.Add(PREFIX .. "create_distance_pc", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local parentNodeID = tonumber(args[1])
    local childNodeID = tonumber(args[2])
    if not parentNodeID or not childNodeID then return end
    if not AuthNode(ply, graph, parentNodeID) or not AuthNode(ply, graph, childNodeID) then return end

    TraceEvent("pconstraint", "create_distance_pc_attempt", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, args = args, parentNode = TNode(graph.nodes[parentNodeID]), childNode = TNode(graph.nodes[childNodeID]), distance = tonumber(args[3]) or 100, diagBefore = TDiag(graph) })
    local pc = PB.NewPConstraint(graph, parentNodeID, childNodeID,
        { type = "face", id = "+z" }, { type = "face", id = "+z" }, "distance")
    if not pc then
        TraceEvent("pconstraint", "create_distance_pc_failed", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, args = args, parentNodeID = parentNodeID, childNodeID = childNodeID })
        Feedback(ply, MSG_STR.createDistanceFailed)
        return
    end

    pc.distance = tonumber(args[3]) or 100
    TraceEvent("pconstraint", "create_distance_pc_success_before_solve", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pc = TPC(pc, graph) })
    PropagateAndSync(ply, graph, nil, "create_distance_pc", { pc = TPC(pc, graph) })
    TraceEvent("pconstraint", "create_distance_pc_success_after_solve", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pc = TPC(pc, graph), diagAfter = TDiag(graph) })
    Feedback(ply, MSG_STR.distancePCPrefix .. pc.id)
end)

concommand.Add(PREFIX .. "create_symmetry_pc", function(ply, _, args)
    Feedback(ply, MSG_STR.symmetryDisabled)
end)

concommand.Add(PREFIX .. "create_mirror_pc", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local pc, err = PB.CreateMirrorNodeAndPC(ply, graph, tonumber(args[1]), tonumber(args[2]), args[3] or "x", args[4] == "1")
    if pc then
        Feedback(ply, MSG_STR.mirrorPCPrefix .. pc.id .. ": " .. PB.DescribePConstraint(pc, graph))
    elseif err and err ~= MSG_STR.rateLimited then
        Feedback(ply, err)
    end
end)

concommand.Add(PREFIX .. "edit_pc", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local pcid = tonumber(args[1])
    local key = args[2]
    local value = args[3]
    local pc = AuthPC(ply, graph, pcid)
    TraceEvent("pconstraint", "edit_pc_recv", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pcid = pcid, key = key, value = value, pcBefore = TPC(pc, graph), diagBefore = TDiag(graph) })
    if not pc then return end
    if not CheckRateLimit(ply) then return end
    local pcBefore = TPC(pc, graph)

    local PC_EDITABLE_NUMERIC = {
        offset = true, slideX = true, slideY = true, angle = true,
        parentFraction = true, childFraction = true, distance = true,
        branchParentSide = true, branchChildSide = true,
    }

    if key == "active" then
        pc.active = value == "1"
    elseif key == "mirrorFace" then
        pc.mirrorFace = value
        if pc.mode == "mirror" then pc.mirrorAxis = PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(value) or value end
    elseif key == "mirrorAxis" then
        pc.mirrorAxis = PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(value) or tostring(value or "x")
        pc.mirrorFace = pc.mirrorAxis
    elseif key == "mirrorNodeID" then
        pc.mirrorNodeID = tonumber(value) or 0
    elseif key == "mirrorGConstraints" then
        pc.mirrorGConstraints = value == "1"
    elseif key == "flipped" then
        pc.flipped = value == "1"
    elseif PC_EDITABLE_NUMERIC[key] then
        local num = tonumber(value)
        if num then
            if key == "branchParentSide" or key == "branchChildSide" then
                num = math.Clamp(math.floor(num), 1, 2)
            end
            pc[key] = num
        end
    else
        Feedback(ply, MSG_STR.unknownPCField .. tostring(key))
        return
    end

    local mirrorGCResult = nil
    if pc.mode == "mirror" and (key == "mirrorGConstraints" or key == "mirrorAxis" or key == "mirrorFace" or key == "mirrorNodeID") then
        mirrorGCResult = PB.SyncMirrorGConstraintsForPC and PB.SyncMirrorGConstraintsForPC(graph, pc) or nil
        syncMirrorGCResult(ply, graph, mirrorGCResult)
    end

    TraceEvent("pconstraint", "edit_pc_apply", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pcid = pcid, key = key, value = value, pcBefore = pcBefore, pcAfter = TPC(pc, graph), mirrorGCResult = mirrorGCResult })
    PropagateAndSync(ply, graph, nil, "edit_pc", { pcid = pcid, key = key, value = value, pcBefore = pcBefore, pcAfter = TPC(pc, graph) })
end)

concommand.Add(PREFIX .. "remove_pc", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local pcid = tonumber(args[1])
    local pc = AuthPC(ply, graph, pcid)
    TraceEvent("pconstraint", "remove_pc_recv", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pcid = pcid, pcBefore = TPC(pc, graph), diagBefore = TDiag(graph) })
    if not pcid or not pc then return end

    if pc.mode == "mirror" and pc.childNodeID and graph.nodes[pc.childNodeID] then
        local removedSnapshot = TPC(pc, graph)
        local removedNodes, removedPCs, removedGCs = removeMirrorGeneratedSubtree(ply, graph, pc.childNodeID)
        TraceEvent("pconstraint", "remove_mirror_pc_apply", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pcid = pcid, removed = removedSnapshot, removedNodes = removedNodes, removedPCs = removedPCs, removedGCs = removedGCs })
        PropagateAndSync(ply, graph, nil, "remove_mirror_pc", { pcid = pcid, removed = removedSnapshot }, true)
        Feedback(ply, MSG_STR.removedMirrorPCPrefix .. pcid .. MSG_STR.removedMirrorPCSuffix)
        return
    end

    PB.RemovePConstraint(graph, pcid)
    SyncPCDelete(ply, pcid)
    TraceEvent("pconstraint", "remove_pc_apply", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pcid = pcid, removed = TPC(pc, graph) })
    PropagateAndSync(ply, graph, nil, "remove_pc", { pcid = pcid, removed = TPC(pc, graph) })
    Feedback(ply, MSG_STR.removedPCPrefix .. pcid)
end)

concommand.Add(PREFIX .. "flip_pc", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local pcid = tonumber(args[1])
    local pc = AuthPC(ply, graph, pcid)
    if not pc then return end
    if not CheckRateLimit(ply) then return end

    local before = TPC(pc, graph)
    pc.flipped = not pc.flipped
    local nudged = nudgeFlipSolution(graph, pc)
    TraceEvent("pconstraint", "flip_pc_apply", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pcid = pcid, before = before, afterFlip = TPC(pc, graph), nudged = nudged })
    PropagateAndSync(ply, graph, nil, "flip_pc", { pcid = pcid, before = before, afterFlip = TPC(pc, graph), nudged = nudged })
    local suffix = pc.flipped and (nudged and MSG_STR.flippedSolution or MSG_STR.flipped) or (nudged and MSG_STR.unflippedSolution or MSG_STR.unflipped)
    TraceEvent("pconstraint", "flip_pc_after_solve", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pc = TPC(pc, graph), diagAfter = TDiag(graph), message = "PC#" .. pcid .. suffix })
    Feedback(ply, "PC#" .. pcid .. suffix)
end)





concommand.Add(PREFIX .. "create_pattern", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local sourceID = tonumber(args[1])
    local patternType = args[2]
    local axis = args[3] or "z"
    local p1 = tonumber(args[4]) or 0
    local p2 = tonumber(args[5]) or 0
    local p3 = tonumber(args[6]) or 0
    local p4 = tonumber(args[7]) or 0
    local copyConstraints = args[8] == "1"
    local constraintType = args[9] or "weld"

    if not sourceID or not AuthNode(ply, graph, sourceID) then return end
    if graph.nodes[sourceID].isPattern then
        Feedback(ply, MSG_STR.selectNonPattern)
        return
    end

    local AXIS_VECTORS = { x = Vector(1,0,0), y = Vector(0,1,0), z = Vector(0,0,1) }
    local params = {}

    if patternType == "linear" then
        params = { direction = AXIS_VECTORS[axis] or Vector(1,0,0), count = math.Clamp(math.floor(p1), 1, 50), spacing = p2 }
    elseif patternType == "circular" then
        params = { axis = axis, count = math.Clamp(math.floor(p1), 2, 50), radius = p2 }
    elseif patternType == "grid" then
        params = { cols = math.Clamp(math.floor(p1), 1, 20), rows = math.Clamp(math.floor(p2), 1, 20), spacingX = p3, spacingY = p4 }
    elseif patternType == "helix" then
        params = { count = math.Clamp(math.floor(p1), 1, 100), radius = p2, rise = p3, turns = p4 }
    elseif patternType == "arc" then
        params = { axis = axis, count = math.Clamp(math.floor(p1), 2, 100), radius = p2, arcDeg = p3 }
    else
        Feedback(ply, MSG_STR.unknownPattern)
        return
    end

    local pattern = PB.NewPatternNode(graph, sourceID, patternType, params, copyConstraints, constraintType, {})
    pattern.worldPos = graph.nodes[sourceID].worldPos
    pattern.worldAngle = graph.nodes[sourceID].worldAngle
    PB.RegeneratePattern(graph, pattern.id)
    PB.RecordAction(graph, "create_pattern", { patternID = pattern.id })
    RegisterUndo(ply, "PB " .. string.upper(patternType) .. ((STR.Patterns or {}).patternSuffix), graph, pattern.id, false)
    SyncUpdate(ply, graph)
    Feedback(ply, string.upper(patternType) .. MSG_STR.patternUndoMiddle .. #pattern.patternEntities .. MSG_STR.patternUndoSuffix)
end)

concommand.Add(PREFIX .. "edit_pattern", function(ply, _, args)
    local graph = GetPlayerGraph(ply)
    if not graph then return end
    local nodeID = tonumber(args[1])
    local key = args[2]
    local value = args[3]
    local pattern = AuthNode(ply, graph, nodeID)
    if not pattern or not pattern.isPattern then return end
    if not CheckRateLimit(ply) then return end

    local AXIS_VECTORS = { x = Vector(1,0,0), y = Vector(0,1,0), z = Vector(0,0,1) }

    if key == "copyConstraints" then
        pattern.copyConstraints = (value == "1")
    elseif key == "patternConstraintType" then
        pattern.patternConstraintType = value or "none"
    elseif key == "direction" then
        pattern.patternParams.direction = AXIS_VECTORS[value] or Vector(1,0,0)
    elseif key == "axis" then
        pattern.patternParams.axis = value
    elseif key == "pivotNodeID" then
        local id = tonumber(value) or 0
        pattern.patternParams.pivotNodeID = id > 0 and id or nil
    elseif key:find("pivotOffset") then
        if not pattern.patternParams.pivotOffset then
            pattern.patternParams.pivotOffset = { x = 0, y = 0, z = 0 }
        end
        if key == "pivotOffsetX" then pattern.patternParams.pivotOffset.x = tonumber(value) or 0
        elseif key == "pivotOffsetY" then pattern.patternParams.pivotOffset.y = tonumber(value) or 0
        else pattern.patternParams.pivotOffset.z = tonumber(value) or 0 end
    else
        local num = tonumber(value)
        if num then
            if key == "count" or key == "cols" or key == "rows" then
                num = math.max(1, math.floor(num))
            end
            pattern.patternParams[key] = num
        end
    end

    PB.RegeneratePattern(graph, nodeID)
    SyncUpdate(ply, graph)
    Feedback(ply, MSG_STR.patternUpdated)
end)

concommand.Add(PREFIX .. "mirror", function(ply, _, args)
    Feedback(ply, MSG_STR.mirrorPickerHelp .. PREFIX .. MSG_STR.mirrorPickerCommandHelp)
end)





concommand.Add(PREFIX .. "save", function(ply)
    Feedback(ply, MSG_STR.savesRemoved)
end)

concommand.Add(PREFIX .. "load", function(ply)
    Feedback(ply, MSG_STR.loadsRemoved)
end)





hook.Add("PlayerDisconnected", "PB_Cleanup", function(ply)
    PB.Graphs[ply:SteamID()] = nil
    lastPropagateTime[ply:SteamID()] = nil
end)

hook.Add("EntityRemoved", "PB_EntityCleanup", function(ent, fullUpdate)
    if fullUpdate then return end
    if not IsValid(ent) or ent:IsPlayer() or ent:IsWorld() then return end

    local projectID, project, graph, nodeID

    if PB.Store and PB.Store.FindProjectNodeByEntity then
        projectID, project, graph, nodeID = PB.Store.FindProjectNodeByEntity(ent)
    end

    if not graph and PB.Graphs then
        for steamID, candidate in pairs(PB.Graphs) do
            local candidateNodeID = candidate._entityIndex and candidate._entityIndex[ent] or nil
            if candidateNodeID and candidate.nodes and candidate.nodes[candidateNodeID] then
                graph = candidate
                nodeID = candidateNodeID
                project = nil
                projectID = nil
                break
            end
        end
    end

    if not graph or not nodeID then return end

    local foundNode = graph.nodes[nodeID]
    if not foundNode or foundNode.isPattern then return end

    foundNode.entity = nil
    if graph._entityIndex then
        graph._entityIndex[ent] = nil
    end

    local removedNodes, removedPCs, removedGCs = PB.RemoveNode(graph, nodeID, false)

    if PB.Store and PB.Store.QueueAutoDeleteIfEmpty and projectID then
        PB.Store.QueueAutoDeleteIfEmpty(projectID)
    end

    local touched = {}
    if project then
        if project.ownerSteamID then touched[project.ownerSteamID] = true end
        for sid in pairs(project.collaborators or {}) do touched[sid] = true end
    else
        for steamID, candidate in pairs(PB.Graphs or {}) do
            if candidate == graph then touched[steamID] = true end
        end
    end

    for _, ply in ipairs(player.GetAll()) do
        local steamID = ply:SteamID()
        if touched[steamID] then
            if ply.PB_SelectedNode == nodeID then
                PB.NotifySelection(ply, nil)
            end

            for _, rid in ipairs(removedNodes) do SyncNodeDelete(ply, rid) end
            for _, pid in ipairs(removedPCs) do SyncPCDelete(ply, pid) end
            for _, gid in ipairs(removedGCs or {}) do SyncGCDelete(ply, gid) end

            local timerName = "PB_EntityCleanupSync_" .. steamID
            timer.Remove(timerName)
            timer.Create(timerName, 0, 1, function()
                for _, p in ipairs(player.GetAll()) do
                    if p:SteamID() == steamID then
                        if projectID and PB.Store and not PB.Store.projects[projectID] and PB.Store.ResyncPlayerProjectState then
                            PB.Store.ResyncPlayerProjectState(p)
                        else
                            SyncUpdate(p, PB.GetGraph(p))
                        end
                        break
                    end
                end
            end)
        end
    end
end)


