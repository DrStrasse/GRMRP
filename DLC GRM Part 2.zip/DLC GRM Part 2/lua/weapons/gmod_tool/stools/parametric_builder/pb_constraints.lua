









PB = PB or {}
PB.GConstraints = PB.GConstraints or {}
PB.GCPicker = PB.GCPicker or {}
PB.GCPickerClient = PB.GCPickerClient or {}
PB.GCSnap = PB.GCSnap or {}

local CFG = PB.Config or {}
local STR = CFG.Strings or {}
local GC_STR = STR.GConstraints or {}
local CHAT_STR = STR.Chat or {}
local DEFAULT_MATERIALS = CFG.DefaultMaterials or {}
local PREFIX = CFG.CommandPrefix or "parametric_builder_"

PB.GCONSTRAINT_TYPES = { "weld", "axis", "advballsocket", "rope", "slider", "elastic" }
PB.GCONSTRAINT_TYPE_LABELS = GC_STR.types or {}

local DIRECTIONAL_TYPES = {
    axis = true,
    advballsocket = true,
}

local function tcopy(tbl)
    return table.Copy and table.Copy(tbl or {}) or (tbl or {})
end

local function vecCopy(v)
    if isvector and isvector(v) then return Vector(v.x, v.y, v.z) end
    if istable and istable(v) then return Vector(tonumber(v.x) or 0, tonumber(v.y) or 0, tonumber(v.z) or 0) end
    return Vector()
end

local function angCopy(a)
    if isangle and isangle(a) then return Angle(a.p, a.y, a.r) end
    if istable and istable(a) then return Angle(tonumber(a.p) or 0, tonumber(a.y) or 0, tonumber(a.r) or 0) end
    return Angle()
end

local function clampBool(v)
    if v == true or v == 1 or v == "1" or v == "true" then return true end
    return false
end

local function finiteNumber(v, fallback)
    v = tonumber(v)
    if v == nil then return fallback or 0 end
    if v ~= v or v == math.huge or v == -math.huge then return fallback or 0 end
    return v
end

local function normalizeLocalDir(dir)
    dir = vecCopy(dir)
    if dir:LengthSqr() < 0.000001 then return Vector(1, 0, 0) end
    dir:Normalize()
    return dir
end

local function isDirectional(gcType)
    return DIRECTIONAL_TYPES[tostring(gcType or "")] == true
end

function PB.GCIsSupportedType(gcType)
    gcType = tostring(gcType or "")
    for _, typ in ipairs(PB.GCONSTRAINT_TYPES) do
        if typ == gcType then return true end
    end
    return false
end

function PB.GCTypeLabel(gcType)
    return PB.GCONSTRAINT_TYPE_LABELS[tostring(gcType or "")] or tostring(gcType or GC_STR.generic)
end

function PB.GCIsDirectionalType(gcType)
    return isDirectional(gcType)
end

local DEFAULT_PARAMS = {
    weld = {
        forcelimit = 0,
        nocollide = 0,
    },
    axis = {
        forcelimit = 0,
        torquelimit = 0,
        friction = 0,
        nocollide = 0,
    },
    advballsocket = {
        forcelimit = 0,
        torquelimit = 0,
        xmin = -180,
        ymin = -180,
        zmin = -180,
        xmax = 180,
        ymax = 180,
        zmax = 180,
        xfric = 0,
        yfric = 0,
        zfric = 0,
        onlyrotation = 0,
        nocollide = 0,
    },
    rope = {
        length = 0,
        addlength = 0,
        forcelimit = 0,
        width = 2,
        material = DEFAULT_MATERIALS.rope,
        rigid = 0,
        color_r = 255,
        color_g = 255,
        color_b = 255,
    },
    slider = {
        width = 1,
    },
    elastic = {
        constant = 100,
        damping = 0,
        rdamping = 0,
        width = 1,
        material = DEFAULT_MATERIALS.elastic,
        stretchonly = 0,
    },
}

local OPTION_SCHEMA = {
    weld = {
        { key = "forcelimit", label = GC_STR.options.forcelimit, kind = "number" },
        { key = "nocollide", label = GC_STR.options.nocollide, kind = "bool" },
    },
    axis = {
        { key = "forcelimit", label = GC_STR.options.forcelimit, kind = "number" },
        { key = "torquelimit", label = GC_STR.options.torquelimit, kind = "number" },
        { key = "friction", label = GC_STR.options.friction, kind = "number" },
        { key = "nocollide", label = GC_STR.options.nocollide, kind = "bool" },
    },
    advballsocket = {
        { key = "forcelimit", label = GC_STR.options.forcelimit, kind = "number" },
        { key = "torquelimit", label = GC_STR.options.torquelimit, kind = "number" },
        { key = "xmin", label = GC_STR.options.xmin, kind = "number" },
        { key = "xmax", label = GC_STR.options.xmax, kind = "number" },
        { key = "ymin", label = GC_STR.options.ymin, kind = "number" },
        { key = "ymax", label = GC_STR.options.ymax, kind = "number" },
        { key = "zmin", label = GC_STR.options.zmin, kind = "number" },
        { key = "zmax", label = GC_STR.options.zmax, kind = "number" },
        { key = "xfric", label = GC_STR.options.xfric, kind = "number" },
        { key = "yfric", label = GC_STR.options.yfric, kind = "number" },
        { key = "zfric", label = GC_STR.options.zfric, kind = "number" },
        { key = "onlyrotation", label = GC_STR.options.onlyrotation, kind = "bool" },
        { key = "nocollide", label = GC_STR.options.nocollide, kind = "bool" },
    },
    rope = {
        { key = "length", label = GC_STR.options.length, kind = "number", hint = GC_STR.options.lengthHint },
        { key = "addlength", label = GC_STR.options.addlength, kind = "number" },
        { key = "forcelimit", label = GC_STR.options.forcelimit, kind = "number" },
        { key = "width", label = GC_STR.options.width, kind = "number" },
        { key = "material", label = GC_STR.options.material, kind = "string" },
        { key = "rigid", label = GC_STR.options.rigid, kind = "bool" },
        { key = "color_r", label = GC_STR.options.colorR, kind = "number" },
        { key = "color_g", label = GC_STR.options.colorG, kind = "number" },
        { key = "color_b", label = GC_STR.options.colorB, kind = "number" },
    },
    slider = {
        { key = "width", label = GC_STR.options.width, kind = "number" },
    },
    elastic = {
        { key = "constant", label = GC_STR.options.constant, kind = "number" },
        { key = "damping", label = GC_STR.options.damping, kind = "number" },
        { key = "rdamping", label = GC_STR.options.relativeDamping, kind = "number" },
        { key = "width", label = GC_STR.options.width, kind = "number" },
        { key = "material", label = GC_STR.options.material, kind = "string" },
        { key = "stretchonly", label = GC_STR.options.stretchOnly, kind = "bool" },
    },
}

function PB.GCDefaultParams(gcType)
    return tcopy(DEFAULT_PARAMS[tostring(gcType or "")] or {})
end

function PB.GConstraints.OptionSchema(gcType)
    return tcopy(OPTION_SCHEMA[tostring(gcType or "")] or {})
end

function PB.GCMergeParams(gcType, params)
    local merged = PB.GCDefaultParams(gcType)
    params = params or {}
    for key, value in pairs(params) do
        merged[key] = value
    end

    local schema = OPTION_SCHEMA[tostring(gcType or "")] or {}
    for _, opt in ipairs(schema) do
        if opt.kind == "number" then
            merged[opt.key] = finiteNumber(merged[opt.key], DEFAULT_PARAMS[tostring(gcType or "")] and DEFAULT_PARAMS[tostring(gcType or "")][opt.key] or 0)
        elseif opt.kind == "bool" then
            merged[opt.key] = clampBool(merged[opt.key]) and 1 or 0
        elseif opt.kind == "string" then
            merged[opt.key] = tostring(merged[opt.key] or "")
        end
    end
    return merged
end

local function defaultLocalCenter(ent)
    if not IsValid(ent) then return Vector() end
    local mn, mx = ent:OBBMins(), ent:OBBMaxs()
    return (mn + mx) * 0.5
end

local function normalizedAngle(a)
    a = angCopy(a)
    a:Normalize()
    return a
end

local function roundGeneratedNumber(v)
    v = finiteNumber(v, 0)
    if math.abs(v) < 0.005 then return 0 end
    return math.Round(v, 2)
end

local function roundGeneratedVector(v)
    v = vecCopy(v)
    return Vector(roundGeneratedNumber(v.x), roundGeneratedNumber(v.y), roundGeneratedNumber(v.z))
end

local function roundGeneratedAngle(a)
    a = normalizedAngle(a)
    return normalizedAngle(Angle(roundGeneratedNumber(a.p), roundGeneratedNumber(a.y), roundGeneratedNumber(a.r)))
end

function PB.GCRoundGeneratedAttachment(att)
    att = PB.GCDeserializeAttachment(att)
    if not att then return nil end

    return {
        localPos = roundGeneratedVector(att.localPos),
        localAngle = roundGeneratedAngle(att.localAngle),
        source = att.source,
        feature = att.feature and tcopy(att.feature) or nil,
    }
end

function PB.GCSerializeAttachment(att)
    if not att then return nil end
    local lp = vecCopy(att.localPos)
    local la = normalizedAngle(att.localAngle)
    return {
        localPos = { x = lp.x, y = lp.y, z = lp.z },
        localAngle = { p = la.p, y = la.y, r = la.r },
        source = att.source or nil,
        feature = att.feature and tcopy(att.feature) or nil,
    }
end

function PB.GCDeserializeAttachment(att)
    if not att then return nil end
    local lp = att.localPos or att.pos or att
    local la = att.localAngle or att.ang or {}
    return {
        localPos = vecCopy(lp),
        localAngle = normalizedAngle(la),
        source = att.source,
        feature = att.feature and tcopy(att.feature) or nil,
    }
end

function PB.GCAttachmentLabel(att)
    if not att then return "unset" end
    local lp = vecCopy(att.localPos)
    local source = att.source and (" [" .. tostring(att.source) .. "]") or ""
    return string.format("%.1f, %.1f, %.1f%s", lp.x, lp.y, lp.z, source)
end

function PB.GCAngleFromForwardUp(forward, up)
    forward = normalizeLocalDir(forward)
    local ang = forward:Angle()

    if up then
        local desiredUp = normalizeLocalDir(up)
        local baseUp = ang:Up()
        local dot = math.Clamp(baseUp:Dot(desiredUp), -1, 1)
        local deg = math.deg(math.acos(dot))
        if deg > 0.001 then
            local sign = baseUp:Cross(desiredUp):Dot(forward) >= 0 and 1 or -1
            ang:RotateAroundAxis(forward, deg * sign)
        end
    end

    ang:Normalize()
    return ang
end

function PB.GCAnchorFromEntityLocal(ent, localPos, localAngle)
    if not IsValid(ent) then return nil end
    return PB.GCRoundGeneratedAttachment({
        localPos = vecCopy(localPos or defaultLocalCenter(ent)),
        localAngle = normalizedAngle(localAngle or Angle()),
        source = "manual",
    })
end

function PB.GCAttachmentFromWorld(node, worldPos, worldAng)
    if not node or not IsValid(node.entity) then return nil end
    local lp, la = WorldToLocal(vecCopy(worldPos), angCopy(worldAng), node.entity:GetPos(), node.entity:GetAngles())
    return PB.GCAnchorFromEntityLocal(node.entity, lp, la)
end

local function faceTangent(ent, faceID, normal)
    if PB.PhysFeatures and PB.PhysFeatures.IsPhysID and PB.PhysFeatures.IsPhysID(faceID) then
        local f = PB.PhysFeatures.GetFace and PB.PhysFeatures.GetFace(ent, faceID) or nil
        if f then return normalizeLocalDir(Vector(f.ux, f.uy, f.uz)) end
    end
    local up = Vector(0, 0, 1)
    if math.abs(normal:Dot(up)) > 0.9 then up = Vector(0, 1, 0) end
    local right = up:Cross(normal)
    if right:LengthSqr() < 0.000001 then return Vector(0, 1, 0) end
    right:Normalize()
    return right
end

function PB.GCAttachmentFromSnap(node, feature, keepAngle)
    if not node or not IsValid(node.entity) or not feature then return nil end
    local ent = node.entity
    local localPos = PB.GetFeatureLocalPos and PB.GetFeatureLocalPos(ent, feature, 0.5) or defaultLocalCenter(ent)
    local localAngle = keepAngle and angCopy(keepAngle) or Angle()
    local source = tostring(feature.type or "feature")

    if feature.type == "face" then
        local normal = PB.GetFaceLocalNormal and PB.GetFaceLocalNormal(ent, feature.id) or Vector(1, 0, 0)
        normal = normalizeLocalDir(normal)
        local tangent = faceTangent(ent, feature.id, normal)
        localAngle = PB.GCAngleFromForwardUp(normal, tangent)
    elseif feature.type == "edge" then
        local dir = PB.GetEdgeLocalDir and PB.GetEdgeLocalDir(ent, feature.id) or Vector(1, 0, 0)
        dir = normalizeLocalDir(dir)
        local side = PB.GetEdgeLocalSideNormal and PB.GetEdgeLocalSideNormal(ent, feature.id, 1) or Vector(0, 0, 1)
        localAngle = PB.GCAngleFromForwardUp(dir, side)
    elseif feature.type == "corner" then
        source = "corner"
    end

    return PB.GCRoundGeneratedAttachment({
        localPos = vecCopy(localPos),
        localAngle = normalizedAngle(localAngle),
        source = source,
        feature = tcopy(feature),
    })
end

function PB.GCAttachmentFromHit(node, hitPos, hitNormal, pickerPrefs, previous, forceFeatureAngle)
    if not node or not IsValid(node.entity) then return nil end
    local feature = PB.DetectFeature and PB.DetectFeature(node.entity, nil, nil, hitPos, hitNormal, pickerPrefs) or nil
    if not feature then return nil end
    local keepAngle = previous and previous.localAngle or nil
    if forceFeatureAngle then keepAngle = nil end
    return PB.GCAttachmentFromSnap(node, feature, keepAngle)
end

function PB.GCResolveAttachmentWorld(graph, nodeID, att)
    local node = graph and graph.nodes and graph.nodes[nodeID]
    if not node then return nil, nil end
    att = PB.GCDeserializeAttachment(att)
    if not att then return nil, nil end
    return LocalToWorld(vecCopy(att.localPos), angCopy(att.localAngle), node.worldPos or Vector(), node.worldAngle or Angle())
end

function PB.GCResnapAttachment(graph, nodeID, att)
    local node = graph and graph.nodes and graph.nodes[nodeID]
    if not node or not IsValid(node.entity) then return nil end
    att = PB.GCDeserializeAttachment(att)
    if not att or not att.feature then return att end
    return PB.GCAttachmentFromSnap(node, att.feature, att.localAngle)
end

function PB.GCCaptureCurrentPoseAnchors(graph, nodeAID, nodeBID, gcType)
    local a = graph and graph.nodes and graph.nodes[nodeAID]
    local b = graph and graph.nodes and graph.nodes[nodeBID]
    if not a or not b or not IsValid(a.entity) or not IsValid(b.entity) then return nil, nil end

    local attA = PB.GCAnchorFromEntityLocal(a.entity, defaultLocalCenter(a.entity), Angle())
    local attB = PB.GCAnchorFromEntityLocal(b.entity, defaultLocalCenter(b.entity), Angle())

    if isDirectional(gcType) then
        attA.localAngle = Angle()
        attB.localAngle = Angle()
    end

    attA.source = "center"
    attB.source = "center"
    return attA, attB
end

function PB.GCCaptureCurrentPoseAttachments(graph, nodeAID, nodeBID, gcType)
    return PB.GCCaptureCurrentPoseAnchors(graph, nodeAID, nodeBID, gcType)
end

function PB.GCCapturePConstraintAttachments(graph, pc, gcType)
    if not graph or not pc then return nil, nil end
    local a = graph.nodes and graph.nodes[pc.parentNodeID]
    local b = graph.nodes and graph.nodes[pc.childNodeID]
    if not a or not b then return nil, nil end
    local attA = PB.GCAttachmentFromSnap(a, pc.parentFeature)
    local attB = PB.GCAttachmentFromSnap(b, pc.childFeature)
    if attA then attA.source = "pconstraint" end
    if attB then attB.source = "pconstraint" end
    return attA, attB
end

local markRuntimeEnts
local normalizeDef

local function runtimeOwnerID(ent)
    if not IsValid(ent) then return nil end

    local directID = ent.PB_RuntimeConstraintID
    if ent.PB_RuntimeConstraint == true and ent.PB_RuntimeConstraintOwner == "GConstraint" and directID ~= nil then
        return tonumber(directID)
    end

    local bi = ent.BuildDupeInfo
    if not istable(bi) and ent.GetTable then
        local tbl = ent:GetTable()
        bi = istable(tbl) and tbl.BuildDupeInfo or nil
    end

    if istable(bi) then
        local stamped = bi.PB_GParametricRuntime == true or bi.PB_GParametricRuntime == 1
            or bi.PB_GParametricRuntime == "1" or bi.PB_GParametricRuntime == "true"
        if stamped and bi.PB_GConstraintID ~= nil then
            return tonumber(bi.PB_GConstraintID)
        end
    end

    return nil
end

local function runtimeRefOwnedByDef(ent, def)
    if not IsValid(ent) then return false end

    local ownerID = runtimeOwnerID(ent)
    if ownerID == nil then return true end

    return ownerID == tonumber(def and def.id)
end

local function shouldCollectRuntimeRef(ent, def, opts)
    if not IsValid(ent) then return false end

    opts = opts or {}
    local ownerID = runtimeOwnerID(ent)
    if ownerID ~= nil then
        return ownerID == tonumber(def and def.id) or opts.includeForeign == true
    end

    return opts.allowLoose == true
end

local function pruneRuntimeRefs(def)
    local refs = {}
    local seen = {}

    local function add(ent)
        if IsValid(ent) and not seen[ent] then
            seen[ent] = true
            refs[#refs + 1] = ent
        end
    end

    if istable(def and def.runtimeEnts) then
        for _, ent in ipairs(def.runtimeEnts) do
            add(ent)
        end
    end
    add(def and def.runtimeEnt)

    if def then
        def.runtimeEnts = refs
        def.runtimeEnt = refs[1]
    end

    return refs
end

local function hasRuntimeRefs(def)
    for _, ent in ipairs(pruneRuntimeRefs(def)) do
        if runtimeRefOwnedByDef(ent, def) then return true end
    end
    return false
end
PB.GConstraints.HasRuntimeRefs = hasRuntimeRefs

local function constraintRecordReferencesEnt(rec, runtimeEnt)
    if rec == runtimeEnt then return true end
    if not istable(rec) then return false end

    if rec.Entity == runtimeEnt then return true end
    if rec.Constraint == runtimeEnt then return true end
    if rec.ConstraintEntity == runtimeEnt then return true end
    if rec.ConstraintEnt == runtimeEnt then return true end
    if rec.Ent == runtimeEnt then return true end

    if istable(rec.Constraints) then
        for _, ent in pairs(rec.Constraints) do
            if ent == runtimeEnt then return true end
        end
    end

    return false
end

local function detachConstraintRecordFromEntity(ent, runtimeEnt)
    if not IsValid(ent) or not IsValid(runtimeEnt) then return 0 end
    if not istable(ent.Constraints) then return 0 end

    local old = ent.Constraints
    local keptNumeric = {}
    local maxNumericKey = 0
    local removed = 0

    for key, rec in pairs(old) do
        local shouldRemove = constraintRecordReferencesEnt(rec, runtimeEnt)
        if type(key) == "number" then
            if key > maxNumericKey then maxNumericKey = key end
            if shouldRemove then
                removed = removed + 1
            else
                keptNumeric[#keptNumeric + 1] = rec
            end
        elseif shouldRemove then
            old[key] = nil
            removed = removed + 1
        end
    end

    if maxNumericKey > 0 then
        for i = 1, maxNumericKey do
            old[i] = nil
        end
        for i, rec in ipairs(keptNumeric) do
            old[i] = rec
        end
    end

    if next(old) == nil then
        ent.Constraints = nil
    end

    if removed > 0 and ent.IsConstrained then
        ent:IsConstrained()
    end

    return removed
end

local function addConstraintEndpoint(out, seen, ent)
    if IsValid(ent) and not seen[ent] then
        seen[ent] = true
        out[#out + 1] = ent
    end
end

local function collectRuntimeConstraintEndpoints(def, graph, runtimeEnt)
    local out = {}
    local seen = {}

    if graph and def and graph.nodes then
        local nodeA = graph.nodes[def.nodeA]
        local nodeB = graph.nodes[def.nodeB]
        addConstraintEndpoint(out, seen, nodeA and nodeA.entity)
        addConstraintEndpoint(out, seen, nodeB and nodeB.entity)
    end

    if IsValid(runtimeEnt) and runtimeEnt.GetTable then
        local tbl = runtimeEnt:GetTable()
        if istable(tbl) then
            addConstraintEndpoint(out, seen, tbl.Ent1)
            addConstraintEndpoint(out, seen, tbl.Ent2)
            addConstraintEndpoint(out, seen, tbl.ent1)
            addConstraintEndpoint(out, seen, tbl.ent2)
        end
    end

    return out
end

local function detachRuntimeConstraintFromEntityLists(def, graph, runtimeEnt)
    local removed = 0

    for _, ent in ipairs(collectRuntimeConstraintEndpoints(def, graph, runtimeEnt)) do
        removed = removed + detachConstraintRecordFromEntity(ent, runtimeEnt)
    end

    return removed
end

local function removeRuntimeRefs(def, graph)
    if not def then return 0 end

    local removed = 0
    local seen = {}
    for _, ent in ipairs(pruneRuntimeRefs(def)) do
        if IsValid(ent) and not seen[ent] then
            seen[ent] = true
            if runtimeRefOwnedByDef(ent, def) then
                detachRuntimeConstraintFromEntityLists(def, graph, ent)
                ent:Remove()
                removed = removed + 1
            end
        end
    end

    def.runtimeEnts = nil
    def.runtimeEnt = nil
    return removed
end

PB.GConstraints.RemoveRuntimeRefs = removeRuntimeRefs
PB.GConstraints.PruneRuntimeRefs = pruneRuntimeRefs

local function gcTouchesNode(def, nodeID)
    nodeID = tonumber(nodeID)
    if not def or not nodeID then return false end
    return tonumber(def.nodeA) == nodeID or tonumber(def.nodeB) == nodeID
end

PB.GConstraints.TouchesNode = gcTouchesNode

local function normalizeConstraintTypeName(value)
    value = string.lower(tostring(value or ""))
    value = string.gsub(value, "%s+", "")
    value = string.gsub(value, "_", "")
    value = string.gsub(value, "%-", "")
    return value
end

local TYPE_ALIASES = {
    weld = { weld = true },
    axis = { axis = true },
    advballsocket = {
        advballsocket = true,
        advancedballsocket = true,
        advballsockets = true,
        ballsocketadv = true,
        ballsocketadvanced = true,
    },
    rope = { rope = true },
    slider = { slider = true },
    elastic = { elastic = true },
}

local function recordTypeMatches(def, rec)
    if not def or not rec then return false end
    local aliases = TYPE_ALIASES[tostring(def.type or "")] or {}
    local recType = normalizeConstraintTypeName(rec.Type or rec.type or rec.ConstraintType or rec.constraintType)
    if aliases[recType] then return true end

    local ent = rec.Constraint or rec.constraint
    if IsValid(ent) then
        local class = normalizeConstraintTypeName(ent:GetClass() or "")
        if def.type == "rope" and string.find(class, "rope", 1, true) then return true end
        if def.type == "weld" and string.find(class, "weld", 1, true) then return true end
        if def.type == "axis" and string.find(class, "axis", 1, true) then return true end
        if def.type == "slider" and string.find(class, "slider", 1, true) then return true end
        if def.type == "elastic" and string.find(class, "elastic", 1, true) then return true end
        if def.type == "advballsocket" and string.find(class, "ballsocket", 1, true) then return true end
    end

    return false
end

local ENDPOINT_KEYS = {
    "Ent1", "Ent2", "EntA", "EntB", "Entity1", "Entity2",
    "ent1", "ent2", "entity1", "entity2",
}

local function addRecordEndpoint(out, value)
    if IsValid(value) then
        out[#out + 1] = value
    elseif istable(value) then
        if IsValid(value.Entity) then out[#out + 1] = value.Entity end
        if IsValid(value.Ent) then out[#out + 1] = value.Ent end
        if IsValid(value.entity) then out[#out + 1] = value.entity end
        if IsValid(value.ent) then out[#out + 1] = value.ent end
    end
end

local function recordTouchesEntityPair(rec, entA, entB)
    if not IsValid(entA) or not IsValid(entB) or not istable(rec) then return false end

    local endpoints = {}
    for _, key in ipairs(ENDPOINT_KEYS) do
        addRecordEndpoint(endpoints, rec[key])
    end

    if #endpoints == 0 and istable(rec.Entities) then
        for _, value in pairs(rec.Entities) do
            addRecordEndpoint(endpoints, value)
        end
    end

    local hasA = false
    local hasB = false
    for _, ent in ipairs(endpoints) do
        if ent == entA then hasA = true end
        if ent == entB then hasB = true end
    end

    return hasA and hasB
end

local function looksLikeConstraintEntity(ent)
    if not IsValid(ent) then return false end
    local class = string.lower(tostring(ent:GetClass() or ""))
    if string.sub(class, 1, 5) == "phys_" then return true end
    if class == "keyframe_rope" or class == "move_rope" then return true end
    if string.find(class, "constraint", 1, true) then return true end
    if string.find(class, "rope", 1, true) then return true end
    return ent.PB_RuntimeConstraint == true
end

local RUNTIME_REF_KEYS = {
    "Constraint", "constraint", "ConstraintEnt", "constraintEnt",
    "Entity", "entity", "Ent", "ent",
}

local function collectRecordRuntimeRefs(rec, out, def, opts)
    if not istable(rec) then return end

    local function add(ent)
        if IsValid(ent) and looksLikeConstraintEntity(ent) and shouldCollectRuntimeRef(ent, def, opts) then
            out[#out + 1] = ent
        end
    end

    for _, key in ipairs(RUNTIME_REF_KEYS) do
        add(rec[key])
    end

    if istable(rec.Constraints) then
        for _, ent in pairs(rec.Constraints) do
            add(ent)
        end
    end
end

local function findWorldConstraintRefsForDef(graph, def, opts)
    local out = {}
    if not graph or not def or not constraint or not constraint.GetTable then return out end

    local nodeA = graph.nodes and graph.nodes[def.nodeA]
    local nodeB = graph.nodes and graph.nodes[def.nodeB]
    local entA = nodeA and nodeA.entity or nil
    local entB = nodeB and nodeB.entity or nil
    if not IsValid(entA) or not IsValid(entB) then return out end

    local records = constraint.GetTable(entA) or {}
    local seenRecs = {}
    for _, rec in pairs(records) do
        if istable(rec) and not seenRecs[rec] then
            seenRecs[rec] = true
            if recordTypeMatches(def, rec) and recordTouchesEntityPair(rec, entA, entB) then
                collectRecordRuntimeRefs(rec, out, def, opts)
            end
        end
    end

    local recordsB = constraint.GetTable(entB) or {}
    for _, rec in pairs(recordsB) do
        if istable(rec) and not seenRecs[rec] then
            seenRecs[rec] = true
            if recordTypeMatches(def, rec) and recordTouchesEntityPair(rec, entA, entB) then
                collectRecordRuntimeRefs(rec, out, def, opts)
            end
        end
    end

    local deduped = {}
    local seen = {}
    for _, ent in ipairs(out) do
        if IsValid(ent) and not seen[ent] then
            seen[ent] = true
            deduped[#deduped + 1] = ent
        end
    end

    return deduped
end

function PB.GConstraints.AdoptWorldRefs(graph, def, opts)
    if not graph or not def then return false end
    normalizeDef(def)
    opts = opts or {}

    if hasRuntimeRefs(def) then
        def.status = def.enabled == false and "disabled" or "ok"
        return true
    end

    local refs = findWorldConstraintRefsForDef(graph, def, opts)
    if #refs == 0 then return false end

    def.runtimeEnts = markRuntimeEnts(def, refs)
    def.runtimeEnt = def.runtimeEnts[1]
    if #def.runtimeEnts == 0 then return false end
    def.status = "ok"
    return true
end

function PB.GConstraints.EnsureLive(graph, def, opts)
    if not graph or not def then return false end
    opts = opts or {}
    normalizeDef(def)

    if def.enabled == false then
        if opts.removeDisabled ~= false then removeRuntimeRefs(def, graph) end
        def.status = "disabled"
        return false
    end

    if opts.adopt ~= false and PB.GConstraints.AdoptWorldRefs(graph, def, {
        allowLoose = opts.allowLooseAdopt == true,
    }) then
        if not opts.forceRebuild then return true end
    end

    if hasRuntimeRefs(def) and not opts.forceRebuild then
        def.status = "ok"
        return true
    end

    if opts.noBuild then
        def.status = hasRuntimeRefs(def) and "ok" or "not_built_passive"
        return hasRuntimeRefs(def)
    end

    if not PB.GConstraints.BuildLive then
        def.status = "no_gconstraint_builder"
        return false
    end

    return PB.GConstraints.BuildLive(graph, def, true)
end

function PB.GConstraints.ReconcileGraph(graph, opts)
    if not graph or not graph.gconstraints then return 0 end
    opts = opts or {}

    local autoManaged = true
    if PB.GraphAutoManageEnabled then
        autoManaged = PB.GraphAutoManageEnabled(graph) ~= false
    end

    local forceRebuild = opts.forceRebuild == true
    local noBuild = opts.noBuild == true or (autoManaged == false and not forceRebuild)

    local touched = 0
    for _, def in pairs(graph.gconstraints) do
        if def then
            local ok = PB.GConstraints.EnsureLive(graph, def, {
                adopt = opts.adopt ~= false,
                forceRebuild = forceRebuild,
                noBuild = noBuild,
                removeDisabled = opts.removeDisabled,
                allowLooseAdopt = opts.allowLooseAdopt == true,
            })
            if ok then touched = touched + 1 end
        end
    end
    return touched
end

function PB.ClearGConstraintRuntime(graph, nodeID)
    if not graph or not graph.gconstraints then return 0 end

    nodeID = nodeID and tonumber(nodeID) or nil
    local cleared = 0

    for _, def in pairs(graph.gconstraints) do
        if def and (not nodeID or gcTouchesNode(def, nodeID)) then
            if hasRuntimeRefs(def) then cleared = cleared + 1 end
            removeRuntimeRefs(def, graph)
            def.status = "pending_rebuild"
        end
    end

    return cleared
end

function PB.RefreshGConstraintsForNode(graph, nodeID)
    if not graph or not graph.gconstraints then return end
    nodeID = tonumber(nodeID)
    if not nodeID then return end

    for _, def in pairs(graph.gconstraints) do
        if gcTouchesNode(def, nodeID) then
            PB.GConstraints.EnsureLive(graph, def, { adopt = true, forceRebuild = true })
        end
    end
end

function PB.RefreshGConstraintsForNodes(graph, nodeIDs)
    if not graph or not graph.gconstraints then return end
    local wanted = {}

    for _, nodeID in ipairs(nodeIDs or {}) do
        nodeID = tonumber(nodeID)
        if nodeID then wanted[nodeID] = true end
    end

    for _, def in pairs(graph.gconstraints) do
        if def and (wanted[tonumber(def.nodeA)] or wanted[tonumber(def.nodeB)]) then
            PB.GConstraints.EnsureLive(graph, def, { adopt = true, forceRebuild = true })
        end
    end
end

function PB.MarkRuntimeConstraintEnt(ent, ownerKind, ownerID, projectID)
    if not IsValid(ent) then return end
    ent.PB_RuntimeConstraint = true
    ent.PB_RuntimeConstraintOwner = ownerKind or "PB"
    ent.PB_RuntimeConstraintID = ownerID




    ent.BuildDupeInfo = ent.BuildDupeInfo or {}
    ent.BuildDupeInfo.PB_GParametricRuntime = true
    ent.BuildDupeInfo.PB_GConstraintID = ownerID
    if projectID ~= nil then
        ent.BuildDupeInfo.PB_ProjectID = projectID
    end
end

markRuntimeEnts = function(def, refs)
    local out = {}
    for _, ent in ipairs(refs or {}) do
        if IsValid(ent) and looksLikeConstraintEntity(ent) then
            PB.MarkRuntimeConstraintEnt(ent, "GConstraint", def and def.id or nil, def and def.projectID or nil)
            out[#out + 1] = ent
        end
    end
    return out
end

local function collectReturnEntities(...)
    local out = {}
    for i = 1, select("#", ...) do
        local value = select(i, ...)
        if isentity(value) and IsValid(value) then
            out[#out + 1] = value
        elseif istable(value) then
            for _, maybeEnt in pairs(value) do
                if isentity(maybeEnt) and IsValid(maybeEnt) then out[#out + 1] = maybeEnt end
            end
        end
    end
    return out
end

function PB.RemoveGConstraint(graph, gcid)
    if not graph or not graph.gconstraints then return end
    local def = graph.gconstraints[gcid]
    removeRuntimeRefs(def, graph)
    graph.gconstraints[gcid] = nil
end

function PB.RemoveGConstraintsForNode(graph, nodeID)
    local removed = {}
    if not graph or not graph.gconstraints then return removed end

    for gcid, def in pairs(graph.gconstraints) do
        if def and (def.nodeA == nodeID or def.nodeB == nodeID) then
            removed[#removed + 1] = gcid
        end
    end

    for _, gcid in ipairs(removed) do
        PB.RemoveGConstraint(graph, gcid)
    end

    return removed
end

normalizeDef = function(def)
    if not def then return nil end
    def.type = tostring(def.type or "")
    if not PB.GCIsSupportedType(def.type) then return nil end
    def.nodeA = tonumber(def.nodeA)
    def.nodeB = tonumber(def.nodeB)
    def.enabled = def.enabled ~= false
    def.attachA = PB.GCDeserializeAttachment(def.attachA)
    def.attachB = PB.GCDeserializeAttachment(def.attachB)
    def.params = PB.GCMergeParams(def.type, def.params or {})
    def.updateMode = def.updateMode or "live"
    return def
end

function PB.NewGConstraint(graph, nodeA, nodeB, gcType, attachA, attachB, params, name)
    if not graph or not graph.nodes then return nil end
    if not PB.GCIsSupportedType(gcType) then return nil end
    nodeA = tonumber(nodeA)
    nodeB = tonumber(nodeB)
    if not nodeA or not nodeB or nodeA == nodeB then return nil end
    if not graph.nodes[nodeA] or not graph.nodes[nodeB] then return nil end

    graph.gconstraints = graph.gconstraints or {}
    graph.nextGCID = graph.nextGCID or 1

    local id = graph.nextGCID
    graph.nextGCID = id + 1

    local def = {
        id = id,
        name = name and tostring(name) or "",
        type = tostring(gcType),
        enabled = true,
        nodeA = nodeA,
        nodeB = nodeB,
        attachA = PB.GCDeserializeAttachment(attachA),
        attachB = PB.GCDeserializeAttachment(attachB),
        params = PB.GCMergeParams(gcType, params or {}),
        updateMode = "live",
        status = "pending",
        debugVisible = true,
    }

    if not def.attachA or not def.attachB then
        def.attachA, def.attachB = PB.GCCaptureCurrentPoseAnchors(graph, nodeA, nodeB, gcType)
    end

    graph.gconstraints[id] = def
    return def
end

function PB.GetGConstraintList(graph)
    local list = {}
    if not graph or not graph.gconstraints then return list end
    for id, def in pairs(graph.gconstraints) do
        list[#list + 1] = { id = tonumber(id) or id, def = def }
    end
    table.sort(list, function(a, b) return tonumber(a.id) < tonumber(b.id) end)
    return list
end

function PB.GConstraintSummary(def, graph)
    if not def then return GC_STR.generic end
    local a = graph and graph.nodes and graph.nodes[def.nodeA]
    local b = graph and graph.nodes and graph.nodes[def.nodeB]
    local lhs = a and a.label or ((GC_STR.nodePrefix or "") .. tostring(def.nodeA or GC_STR.unknownNode))
    local rhs = b and b.label or ((GC_STR.nodePrefix or "") .. tostring(def.nodeB or GC_STR.unknownNode))
    local prefix = def.enabled == false and GC_STR.summaryOffPrefix or ""
    return prefix .. GC_STR.summaryPrefix .. tostring(def.id or GC_STR.unknownNode) .. " " .. PB.GCTypeLabel(def.type) .. GC_STR.summarySeparator .. lhs .. GC_STR.summaryJoiner .. rhs
end

local function attachLocalPos(att)
    att = PB.GCDeserializeAttachment(att)
    return att and vecCopy(att.localPos) or Vector()
end

local function attachLocalAxis(att)
    att = PB.GCDeserializeAttachment(att)
    if not att then return Vector(1, 0, 0) end
    return normalizeLocalDir(angCopy(att.localAngle):Forward())
end

local function angleHasUsefulDirection(att)
    att = PB.GCDeserializeAttachment(att)
    if not att then return false end
    local source = tostring(att.source or "")
    if source == "face" or source == "edge" or source == "pconstraint" then return true end
    local ang = angCopy(att.localAngle)
    return math.abs(ang.p) > 0.001 or math.abs(ang.y) > 0.001 or math.abs(ang.r) > 0.001
end

local function physObject(ent, bone)
    if not IsValid(ent) then return nil end
    bone = tonumber(bone) or 0
    local phys = ent:GetPhysicsObjectNum(bone)
    if IsValid(phys) then return phys end
    phys = ent:GetPhysicsObject()
    if IsValid(phys) then return phys end
    return nil
end

local function entityLocalToPhysLocal(ent, bone, localPos)
    local phys = physObject(ent, bone)
    if not phys then return vecCopy(localPos) end
    return phys:WorldToLocal(ent:LocalToWorld(vecCopy(localPos)))
end

local function entityLocalDirToWorld(ent, localDir)
    local origin = ent:LocalToWorld(Vector())
    local tip = ent:LocalToWorld(normalizeLocalDir(localDir))
    local out = tip - origin
    if out:LengthSqr() < 0.000001 then return ent:GetForward() end
    out:Normalize()
    return out
end

local function worldDirToEntityLocal(ent, worldDir)
    worldDir = vecCopy(worldDir)
    if worldDir:LengthSqr() < 0.000001 then return Vector(1, 0, 0) end
    worldDir:Normalize()
    local origin = ent:GetPos()
    local localOrigin = ent:WorldToLocal(origin)
    local localTip = ent:WorldToLocal(origin + worldDir)
    return normalizeLocalDir(localTip - localOrigin)
end

local function axisLocalPointForConstraint(entA, entB, attachA, attachB, aPos)
    attachA = PB.GCDeserializeAttachment(attachA)
    attachB = PB.GCDeserializeAttachment(attachB)

    local axisDir
    if angleHasUsefulDirection(attachA) then
        axisDir = attachLocalAxis(attachA)
    elseif angleHasUsefulDirection(attachB) and IsValid(entB) then
        local worldDir = entityLocalDirToWorld(entB, attachLocalAxis(attachB))
        axisDir = worldDirToEntityLocal(entA, worldDir)
    end

    if not axisDir then return nil end

    local localAxisPoint = vecCopy(aPos) + normalizeLocalDir(axisDir) * 100
    return entityLocalToPhysLocal(entA, 0, localAxisPoint)
end

local function ropeColorFromParams(params)
    if not Color then return nil end
    local r = math.Clamp(math.floor(tonumber(params.color_r) or 255), 0, 255)
    local g = math.Clamp(math.floor(tonumber(params.color_g) or 255), 0, 255)
    local b = math.Clamp(math.floor(tonumber(params.color_b) or 255), 0, 255)
    return CFG.MakeColor(r, g, b)
end

local function runtimeEnabled(graph)
    return true
end

if SERVER then
    if util and util.AddNetworkString then
        util.AddNetworkString(PREFIX .. "gc_pick_mode")
        util.AddNetworkString(PREFIX .. "gc_pick_state")
        util.AddNetworkString(PREFIX .. "gc_nodes_picked")
        util.AddNetworkString(PREFIX .. "gc_attach_picked")
        util.AddNetworkString(PREFIX .. "gc_pick_exit")
    end

    function PB.GConstraints.BuildLive(graph, def, force)
        if not graph or not def then return false end
        normalizeDef(def)
        removeRuntimeRefs(def, graph)

        if def.enabled == false then
            def.status = "disabled"
            return false
        end
        if not runtimeEnabled(graph) then
            def.status = "auto_manage_off"
            return false
        end
        if not constraint then
            def.status = "constraint_library_missing"
            return false
        end

        local nodeA = graph.nodes and graph.nodes[def.nodeA]
        local nodeB = graph.nodes and graph.nodes[def.nodeB]
        if not nodeA or not nodeB then
            def.status = "missing_node"
            return false
        end
        local entA = nodeA.entity
        local entB = nodeB.entity
        if not IsValid(entA) or not IsValid(entB) then
            def.status = "missing_entity"
            return false
        end

        local params = PB.GCMergeParams(def.type, def.params or {})
        def.params = params
        local aEntPos = attachLocalPos(def.attachA)
        local bEntPos = attachLocalPos(def.attachB)
        local aPos = entityLocalToPhysLocal(entA, 0, aEntPos)
        local bPos = entityLocalToPhysLocal(entB, 0, bEntPos)
        local refs = {}
        local beforeRefs = findWorldConstraintRefsForDef(graph, def, { allowLoose = true, includeForeign = true })
        local beforeSet = {}
        for _, ent in ipairs(beforeRefs or {}) do
            if IsValid(ent) then beforeSet[ent] = true end
        end

        if def.type == "weld" then
            refs = collectReturnEntities(constraint.Weld(entA, entB, 0, 0, params.forcelimit or 0, (tonumber(params.nocollide) or 0) ~= 0))
        elseif def.type == "axis" then
            local localAxis = axisLocalPointForConstraint(entA, entB, def.attachA, def.attachB, aEntPos)
            refs = collectReturnEntities(constraint.Axis(entA, entB, 0, 0, aPos, bPos,
                params.forcelimit or 0, params.torquelimit or 0, params.friction or 0,
                tonumber(params.nocollide) or 0, localAxis))
        elseif def.type == "advballsocket" then
            refs = collectReturnEntities(constraint.AdvBallsocket(entA, entB, 0, 0, aPos, bPos,
                params.forcelimit or 0, params.torquelimit or 0,
                params.xmin or -180, params.ymin or -180, params.zmin or -180,
                params.xmax or 180, params.ymax or 180, params.zmax or 180,
                params.xfric or 0, params.yfric or 0, params.zfric or 0,
                tonumber(params.onlyrotation) or 0, tonumber(params.nocollide) or 0))
        elseif def.type == "rope" then
            local physA = physObject(entA, 0)
            local physB = physObject(entB, 0)
            local worldA = physA and physA:LocalToWorld(aPos) or entA:LocalToWorld(aEntPos)
            local worldB = physB and physB:LocalToWorld(bPos) or entB:LocalToWorld(bEntPos)
            local length = tonumber(params.length) or 0
            if length <= 0 then length = worldA:Distance(worldB) end
            refs = collectReturnEntities(constraint.Rope(entA, entB, 0, 0, aPos, bPos,
                length, params.addlength or 0, params.forcelimit or 0,
                params.width or 2, params.material or DEFAULT_MATERIALS.rope, (tonumber(params.rigid) or 0) ~= 0,
                ropeColorFromParams(params)))
        elseif def.type == "slider" then
            refs = collectReturnEntities(constraint.Slider(entA, entB, 0, 0, aPos, bPos, params.width or 1))
        elseif def.type == "elastic" then
            refs = collectReturnEntities(constraint.Elastic(entA, entB, 0, 0, aPos, bPos,
                params.constant or 100, params.damping or 0, params.rdamping or 0,
                params.material or DEFAULT_MATERIALS.rope, params.width or 1,
                (tonumber(params.stretchonly) or 0) ~= 0))
        end

        local seenRefs = {}
        local mergedRefs = {}
        local function addRef(ent)
            if IsValid(ent) and looksLikeConstraintEntity(ent) and not seenRefs[ent] then
                seenRefs[ent] = true
                mergedRefs[#mergedRefs + 1] = ent
            end
        end

        for _, ent in ipairs(refs or {}) do
            addRef(ent)
        end

        local afterRefs = findWorldConstraintRefsForDef(graph, def, { allowLoose = true, includeForeign = true })
        for _, ent in ipairs(afterRefs or {}) do
            if IsValid(ent) and not beforeSet[ent] then
                addRef(ent)
            end
        end

        def.runtimeEnts = markRuntimeEnts(def, mergedRefs)
        def.runtimeEnt = def.runtimeEnts[1]
        def.status = (#def.runtimeEnts > 0 or def.type == "weld") and "ok" or "created_no_entity"
        return true
    end

    function PB.RefreshGConstraints(graph, _, targetID)
        if not graph or not graph.gconstraints then return end
        if targetID then
            local def = graph.gconstraints[targetID]
            if def then
                PB.GConstraints.EnsureLive(graph, def, { adopt = true, forceRebuild = true })
            end
            return
        end

        local forceRebuild = graph._pbForceGConstraintRebuildOnce == true
        graph._pbForceGConstraintRebuildOnce = nil
        PB.GConstraints.ReconcileGraph(graph, { adopt = true, forceRebuild = forceRebuild })
    end


    local function pickerFeedback(ply, text)
        if IsValid(ply) then
            ply:PrintMessage(HUD_PRINTTALK, (CFG.ChatPrefix) .. " " .. tostring(text or ""))
        end
    end

    local function sendPickerState(ply)
        local state = ply.PB_GCState or {}
        net.Start(PREFIX .. "gc_pick_state")
        net.WriteString(util.TableToJSON({
            active = ply.PB_GCSelectMode == true,
            phase = state.phase or "",
            gcType = state.gcType or "",
            firstNodeID = state.firstNodeID or 0,
            nodeID = state.nodeID or 0,
            side = state.side or "",
        }) or "{}")
        net.Send(ply)
    end

    local function exitPicker(ply, message)
        ply.PB_GCSelectMode = false
        ply.PB_GCState = {}
        net.Start(PREFIX .. "gc_pick_exit")
        net.WriteString(message or "")
        net.Send(ply)
        sendPickerState(ply)
    end

    function PB.GCPicker.Start(ply, data)
        if not IsValid(ply) or not istable(data) then return false end
        data.mode = tostring(data.mode or "nodes")

        local activeProjectID = nil
        if PB.Store and PB.Store.ResolveActiveProject then
            activeProjectID = PB.Store.ResolveActiveProject(ply:SteamID())
        elseif PB.Store and PB.Store.activeProject then
            activeProjectID = PB.Store.activeProject[ply:SteamID()]
        end

        if not activeProjectID then
            local msg = GC_STR.noActiveProject or CHAT_STR.createOrSelectProject
            pickerFeedback(ply, msg)
            exitPicker(ply, msg)
            return false
        end

        ply.PB_PCSelectMode = false
        ply.PB_MirrorSelectMode = false
        ply.PB_GCSelectMode = true
        ply.PB_GCState = {
            phase = data.mode,
            gcType = tostring(data.gcType or data.type or "weld"),
            side = tostring(data.side or "A"),
            nodeID = tonumber(data.nodeID) or 0,
            gcid = tonumber(data.gcid) or 0,
            previousAttach = PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(data.previousAttach) or nil,
            firstNodeID = nil,
        }
        sendPickerState(ply)
        return true
    end

    function PB.GCPicker.Cancel(ply)
        if not IsValid(ply) then return end
        exitPicker(ply, GC_STR.pickerCancelled)
    end

    function PB.GCPicker.ToolRightClick(ply)
        PB.GCPicker.Cancel(ply)
        return true
    end

    function PB.GCPicker.ToolLeftClick(ply, trace)
        if not IsValid(ply) or not trace then return false end
        local state = ply.PB_GCState or {}
        local graph = PB.GetGraph and PB.GetGraph(ply) or nil
        if not graph then return false end
        local ent = trace.Entity
        if not IsValid(ent) or ent:IsWorld() or ent:IsPlayer() then return false end
        local node = PB.FindNodeByEntity and PB.FindNodeByEntity(graph, ent) or nil
        if not node then
            pickerFeedback(ply, GC_STR.notInActiveGraph)
            return true
        end

        if state.phase == "attach" then
            local targetID = tonumber(state.nodeID) or 0
            if targetID > 0 and node.id ~= targetID then
                pickerFeedback(ply, GC_STR.pickHighlightedProp)
                return true
            end
            local previous = nil
            local gc = state.gcid and graph.gconstraints and graph.gconstraints[state.gcid] or nil
            if gc then previous = state.side == "B" and gc.attachB or gc.attachA end
            previous = previous or state.previousAttach
            local forceFeatureAngle = isDirectional(state.gcType)
            local att = PB.GCAttachmentFromHit(node, trace.HitPos, trace.HitNormal, ply.PB_PickerPrefs, previous, forceFeatureAngle)
            if not att then
                pickerFeedback(ply, GC_STR.noFeature)
                return true
            end
            net.Start(PREFIX .. "gc_attach_picked")
            net.WriteString(util.TableToJSON({
                side = state.side == "B" and "B" or "A",
                nodeID = node.id,
                gcid = tonumber(state.gcid) or 0,
                attach = PB.GCSerializeAttachment(att),
            }) or "{}")
            net.Send(ply)
            exitPicker(ply)
            return true
        end

        if state.phase ~= "nodes" then
            exitPicker(ply)
            return true
        end

        if not state.firstNodeID then
            state.firstNodeID = node.id
            ply.PB_GCState = state
            pickerFeedback(ply, GC_STR.firstPropPrefix .. tostring(node.label or node.id))
            sendPickerState(ply)
            return true
        end

        if node.id == state.firstNodeID then
            state.firstNodeID = nil
            ply.PB_GCState = state
            pickerFeedback(ply, GC_STR.firstPropCleared)
            sendPickerState(ply)
            return true
        end

        local attA, attB = PB.GCCaptureCurrentPoseAttachments(graph, state.firstNodeID, node.id, state.gcType)
        if not attA or not attB then
            pickerFeedback(ply, GC_STR.defaultAnchorsFailed)
            exitPicker(ply)
            return true
        end

        net.Start(PREFIX .. "gc_nodes_picked")
        net.WriteString(util.TableToJSON({
            gcType = state.gcType or "weld",
            nodeA = state.firstNodeID,
            nodeB = node.id,
            attachA = PB.GCSerializeAttachment(attA),
            attachB = PB.GCSerializeAttachment(attB),
            params = PB.GCDefaultParams(state.gcType or "weld"),
        }) or "{}")
        net.Send(ply)
        exitPicker(ply)
        return true
    end

    if net and net.Receive then
        net.Receive(PREFIX .. "gc_pick_mode", function(_, ply)
            local raw = net.ReadString() or "{}"
            local data = util.JSONToTable(raw) or {}
            if data.mode == "cancel" or data.enter == false then
                PB.GCPicker.Cancel(ply)
            else
                PB.GCPicker.Start(ply, data)
            end
        end)
    end
end

if CLIENT then
    PB_GCMode = PB_GCMode or {
        active = false,
        phase = "",
        gcType = "weld",
        firstNodeID = nil,
        nodeID = nil,
        side = "A",
        hoveredEnt = nil,
        hoveredNodeID = nil,
        hoveredFeature = nil,
        panelWasOpen = false,
        selectedGCID = nil,
    }

    PB_GCDraft = PB_GCDraft or nil

    PB.ReleaseGameInput = PB.ReleaseGameInput or function()
        if vgui and vgui.GetKeyboardFocus then
            local focused = vgui.GetKeyboardFocus()
            if IsValid(focused) and focused.KillFocus then focused:KillFocus() end
        end
        if gui and gui.EnableScreenClicker then gui.EnableScreenClicker(false) end
    end

    local function showPanelAgain()
        if PB_GCMode.panelWasOpen and IsValid(PB_MainPanel) then
            PB_MainPanel:SetVisible(true)
            PB_MainPanel:SetMouseInputEnabled(true)
            PB_MainPanel:SetKeyboardInputEnabled(true)
            PB_MainPanel:MakePopup()
        else
            PB.ReleaseGameInput()
        end
    end

    local function applyState(data)
        data = data or {}
        PB_GCMode.active = data.active == true
        PB_GCMode.phase = data.phase or ""
        PB_GCMode.gcType = data.gcType or PB_GCMode.gcType or "weld"
        PB_GCMode.firstNodeID = tonumber(data.firstNodeID) or nil
        if PB_GCMode.firstNodeID == 0 then PB_GCMode.firstNodeID = nil end
        PB_GCMode.nodeID = tonumber(data.nodeID) or nil
        if PB_GCMode.nodeID == 0 then PB_GCMode.nodeID = nil end
        PB_GCMode.side = data.side or "A"
        if PB_Overlay then PB_Overlay._needsRefresh = true end
    end

    function PB.GCPickerClient.Start(data)
        data = data or {}
        if PB_PCMode then PB_PCMode.active = false end
        if PB_MirrorMode then PB_MirrorMode.active = false end
        PB_GCMode.active = true
        PB_GCMode.phase = data.mode or "nodes"
        PB_GCMode.gcType = data.gcType or data.type or PB_GCMode.gcType or "weld"
        PB_GCMode.side = data.side or "A"
        PB_GCMode.nodeID = tonumber(data.nodeID) or nil
        PB_GCMode.hoveredEnt = nil
        PB_GCMode.hoveredNodeID = nil
        PB_GCMode.hoveredFeature = nil

        if IsValid(PB_MainPanel) then
            PB_GCMode.panelWasOpen = true
            PB_MainPanel:SetVisible(false)
            PB_MainPanel:SetMouseInputEnabled(false)
            PB_MainPanel:SetKeyboardInputEnabled(false)
        else
            PB_GCMode.panelWasOpen = false
        end
        gui.EnableScreenClicker(false)

        net.Start(PREFIX .. "gc_pick_mode")
        net.WriteString(util.TableToJSON(data) or "{}")
        net.SendToServer()
        return true
    end

    function PB.GCPickerClient.Cancel()
        PB_GCMode.active = false
        net.Start(PREFIX .. "gc_pick_mode")
        net.WriteString(util.TableToJSON({ mode = "cancel" }) or "{}")
        net.SendToServer()
        showPanelAgain()
    end

    function PB.GCPickerClient.ToolLeftClick()
        return PB_GCMode.active == true
    end

    function PB.GCPickerClient.ToolRightClick()
        if PB_GCMode.active then
            PB.GCPickerClient.Cancel()
            return true
        end
        return false
    end

    if net and net.Receive then
        net.Receive(PREFIX .. "gc_pick_state", function()
            local data = util.JSONToTable(net.ReadString() or "{}") or {}
            applyState(data)
        end)

        net.Receive(PREFIX .. "gc_pick_exit", function()
            net.ReadString()
            PB_GCMode.active = false
            PB_GCMode.hoveredEnt = nil
            PB_GCMode.hoveredNodeID = nil
            PB_GCMode.hoveredFeature = nil
            showPanelAgain()
            if PB_Overlay then PB_Overlay._needsRefresh = true end
        end)

        net.Receive(PREFIX .. "gc_nodes_picked", function()
            local data = util.JSONToTable(net.ReadString() or "{}") or {}
            data.attachA = PB.GCRoundGeneratedAttachment(data.attachA) or PB.GCDeserializeAttachment(data.attachA)
            data.attachB = PB.GCRoundGeneratedAttachment(data.attachB) or PB.GCDeserializeAttachment(data.attachB)
            data.params = PB.GCMergeParams(data.gcType or data.type or "weld", data.params or {})
            PB_GCDraft = data
            PB_GCMode.selectedGCID = nil
            if PB_RebuildGConstraintPanel then PB_RebuildGConstraintPanel() end
            if PB_Overlay then PB_Overlay._needsRefresh = true end
        end)

        net.Receive(PREFIX .. "gc_attach_picked", function()
            local data = util.JSONToTable(net.ReadString() or "{}") or {}
            data.attach = PB.GCRoundGeneratedAttachment(data.attach) or PB.GCDeserializeAttachment(data.attach)
            if PB_HandleGCAttachmentPicked then PB_HandleGCAttachmentPicked(data) end
            if PB_Overlay then PB_Overlay._needsRefresh = true end
        end)
    end
end
