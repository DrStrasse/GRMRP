
























if SERVER then return end
local PREFIX = (PB.Config and PB.Config.CommandPrefix) or "parametric_builder_"

local CFG = PB.Config or {}
local COL = CFG.Colors or {}
local STR = CFG.Strings or {}
local UI_STR = STR.UI or {}
local TAB_STR = STR.Tabs or {}
local SETTINGS_STR = STR.Settings or {}
local PROP_STR = STR.Properties or {}
local PC_STR = STR.PConstraints or {}
local HUD_STR = STR.HUD or {}
local GC_STR = STR.GConstraints or {}
local TREE_STR = STR.Tree or {}
local PATTERN_STR = STR.Patterns or {}
local PROJECT_MENU_STR = STR.ProjectMenus or {}

local function TraceEvent(category, action, payload)
    if PB.Trace and PB.Trace.Event then PB.Trace.Event(category, action, payload or {}) end
end
local function TNode(node) return PB.Trace and PB.Trace.Node and PB.Trace.Node(node) or nil end
local function TDiag() return PB.Trace and PB.Trace.Diagnostic and PB.Trace.Diagnostic(PB_ClientGraph and PB_ClientGraph.solverDiagnostic or nil) or nil end
local function WithAlpha(color, alpha) return CFG.ColorWithAlpha and CFG.ColorWithAlpha(color, alpha) or color end





local COL_ROOT        = COL.rootNode
local COL_CHILD       = COL.childNode
local COL_SELECTED    = COL.selected
local COL_HOVERED     = COL.hoveredNode
local COL_LOCKED      = COL.locked
local COL_PATTERN     = COL.patternNode
local COL_LINE        = COL.constraintLine
local COL_LINE_ACTIVE = COL.constraintLineActive
local COL_LABEL_BG    = COL.labelBackground
local COL_FACE_HOV    = COL.faceHover
local COL_FACE_SEL    = COL.faceSelected
local COL_DIM         = COL.dimension

local CONSTRAINT_DISPLAY = STR.ConstraintDisplay or {}
local CONSTRAINT_COLORS = COL.physicalConstraint or {}





PB_Overlay = PB_Overlay or {
    enabled = true,
    selectedNodeID = nil,
    hoveredNodeID = nil,
    maxDrawDist = 4000,
}





PB_SolverActive = PB_SolverActive or false

local CV = CFG.ConVars or {}
local function cvarName(key, fallback)
    local def = CV[key] or {}
    return def.name or fallback
end
local function createClientCVar(key, fallbackName, fallbackDefault, fallbackHelp)
    local def = CV[key] or {}
    CreateClientConVar(def.name or fallbackName, def.default or fallbackDefault, true, false, def.help or fallbackHelp)
end
createClientCVar("overlayEnabled",     PREFIX .. "overlay_enabled",     "1",    ((CV.overlayEnabled or {}).help))
createClientCVar("overlayLabels",      PREFIX .. "overlay_labels",      "1",    ((CV.overlayLabels or {}).help))
createClientCVar("overlayOffsets",     PREFIX .. "overlay_offsets",     "1",    ((CV.overlayOffsets or {}).help))
createClientCVar("overlayConstraints", PREFIX .. "overlay_constraints", "1",    ((CV.overlayConstraints or {}).help))
createClientCVar("overlayAxes",        PREFIX .. "overlay_axes",        "0",    ((CV.overlayAxes or {}).help))
createClientCVar("overlayDimensions",  PREFIX .. "overlay_dimensions",  "1",    ((CV.overlayDimensions or {}).help))
createClientCVar("overlayMaxDistance", PREFIX .. "overlay_maxdist",     "4000", ((CV.overlayMaxDistance or {}).help))
createClientCVar("snapGrid",           PREFIX .. "snap_grid",           "1",    ((CV.snapGrid or {}).help))

local function PB_SendPickerPrefsToServer()
    if not (net and util and util.TableToJSON and PB and PB.PickerPrefsFromConVars) then return end
    local payload = util.TableToJSON(PB.PickerPrefsFromConVars())
    if not payload then return end
    net.Start(PREFIX .. "picker_prefs")
    net.WriteString(payload)
    net.SendToServer()
end
PB.SendPickerPrefsToServer = PB_SendPickerPrefsToServer

timer.Simple(1, function()
    if PB_SendPickerPrefsToServer then PB_SendPickerPrefsToServer() end
end)





local function DrawText3D(worldPos, text, textColor, bgColor)
    local screen = worldPos:ToScreen()
    if not screen.visible then return end

    local alpha = math.Clamp(1 - LocalPlayer():GetShootPos():Distance(worldPos) / PB_Overlay.maxDrawDist, 0, 1)
    if alpha <= 0 then return end

    cam.Start2D()
    surface.SetFont("DermaDefaultBold")
    local textW, textH = surface.GetTextSize(text)

    if bgColor then
        draw.RoundedBox(4, screen.x - textW / 2 - 4, screen.y - textH / 2 - 2, textW + 8, textH + 4,
            WithAlpha(bgColor, (bgColor.a or 255) * alpha))
    end
    draw.SimpleText(text, "DermaDefaultBold", screen.x, screen.y,
        WithAlpha(textColor, (textColor.a or 255) * alpha),
        TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    cam.End2D()
end

local function GetNodeColor(node, isSelected, isHovered)
    if isSelected then return COL_SELECTED end
    if isHovered then return COL_HOVERED end
    if node.locked then return COL_LOCKED end
    if node.isPattern then return COL_PATTERN end
    if not node.parentID then return COL_ROOT end
    return COL_CHILD
end

local function DrawFaceQuad(ent, faceID, color)
    if not IsValid(ent) then return end




    if PB.PhysFeatures and PB.PhysFeatures.IsPhysID and PB.PhysFeatures.IsPhysID(faceID) then
        local face = PB.PhysFeatures.GetFace and PB.PhysFeatures.GetFace(ent, faceID) or nil
        local set  = PB.PhysFeatures.Get and PB.PhysFeatures.Get(ent) or nil
        if not face or not set then return end
        local verts = face.verts
        if not verts or #verts < 3 then return end

        render.SetMaterial(Material("sprites/light_ignorez"))
        cam.Start3D()
        if #verts == 4 then
            local w1 = ent:LocalToWorld(set.vertices[verts[1]])
            local w2 = ent:LocalToWorld(set.vertices[verts[2]])
            local w3 = ent:LocalToWorld(set.vertices[verts[3]])
            local w4 = ent:LocalToWorld(set.vertices[verts[4]])
            render.DrawQuad(w1, w2, w3, w4, color)
        else

            local w1 = ent:LocalToWorld(set.vertices[verts[1]])
            for i = 2, #verts - 1 do
                local w2 = ent:LocalToWorld(set.vertices[verts[i]])
                local w3 = ent:LocalToWorld(set.vertices[verts[i + 1]])

                render.DrawQuad(w1, w2, w3, w3, color)
            end
        end
        cam.End3D()
        return
    end

    local mn, mx = PB.GetModelVisualBounds(ent:GetModel())
    if not mn then mn, mx = ent:OBBMins(), ent:OBBMaxs() end

    local corners
    if     faceID == "+z" then corners = {Vector(mn.x,mn.y,mx.z), Vector(mx.x,mn.y,mx.z), Vector(mx.x,mx.y,mx.z), Vector(mn.x,mx.y,mx.z)}
    elseif faceID == "-z" then corners = {Vector(mn.x,mn.y,mn.z), Vector(mn.x,mx.y,mn.z), Vector(mx.x,mx.y,mn.z), Vector(mx.x,mn.y,mn.z)}
    elseif faceID == "+x" then corners = {Vector(mx.x,mn.y,mn.z), Vector(mx.x,mx.y,mn.z), Vector(mx.x,mx.y,mx.z), Vector(mx.x,mn.y,mx.z)}
    elseif faceID == "-x" then corners = {Vector(mn.x,mn.y,mn.z), Vector(mn.x,mn.y,mx.z), Vector(mn.x,mx.y,mx.z), Vector(mn.x,mx.y,mn.z)}
    elseif faceID == "+y" then corners = {Vector(mn.x,mx.y,mn.z), Vector(mn.x,mx.y,mx.z), Vector(mx.x,mx.y,mx.z), Vector(mx.x,mx.y,mn.z)}
    elseif faceID == "-y" then corners = {Vector(mn.x,mn.y,mn.z), Vector(mx.x,mn.y,mn.z), Vector(mx.x,mn.y,mx.z), Vector(mn.x,mn.y,mx.z)}
    end
    if not corners then return end

    local worldCorners = {}
    for i, corner in ipairs(corners) do worldCorners[i] = ent:LocalToWorld(corner) end

    render.SetMaterial(Material("sprites/light_ignorez"))
    cam.Start3D()
    render.DrawQuad(worldCorners[1], worldCorners[2], worldCorners[3], worldCorners[4], color)
    cam.End3D()
end

local function DrawEdgeLine(ent, edgeIndex, color)
    if not IsValid(ent) then return end
    local p1, p2 = PB.GetEdgeEndpoints(ent, edgeIndex)
    render.DrawLine(p1, p2, color, true)

    local dir = (p2 - p1); dir:Normalize()
    local right = dir:Cross(Vector(0, 0, 1))
    if right:Length() < 0.1 then right = dir:Cross(Vector(1, 0, 0)) end
    right:Normalize()
    render.DrawLine(p1 + right * 0.4, p2 + right * 0.4, color, true)
    render.DrawLine(p1 - right * 0.4, p2 - right * 0.4, color, true)
end

local function DrawCornerDot(ent, cornerIndex, color)
    if not IsValid(ent) then return end
    local worldPos = PB.GetCornerWorldPos(ent, cornerIndex)
    render.SetMaterial(Material("sprites/light_ignorez"))
    render.DrawSprite(worldPos, 8, 8, color)
end

local function DrawFeature(ent, feature, color)
    if feature.type == "face" then
        DrawFaceQuad(ent, feature.id, WithAlpha(color, 60))
    elseif feature.type == "edge" then
        DrawEdgeLine(ent, feature.id, color)
    elseif feature.type == "corner" then
        DrawCornerDot(ent, feature.id, color)
    end
end

local function DrawGCPointMarker(pos, color, spriteMat, size)
    if not pos then return end
    size = size or 7
    render.SetMaterial(spriteMat or Material("sprites/light_ignorez"))
    render.DrawSprite(pos, size * 1.6, size * 1.6, color)
    render.DrawLine(pos + Vector(size, 0, 0), pos - Vector(size, 0, 0), color, true)
    render.DrawLine(pos + Vector(0, size, 0), pos - Vector(0, size, 0), color, true)
    render.DrawLine(pos + Vector(0, 0, size), pos - Vector(0, 0, size), color, true)
end

local function IsGCDirectionalVisualType(gcType)
    local typ = string.lower(tostring(gcType or ""))
    return typ == "axis" or typ == "advballsocket"
end

local function vecUnit(v, fallback)
    if not v or v:LengthSqr() < 0.000001 then v = fallback end
    if not v or v:LengthSqr() < 0.000001 then v = Vector(1, 0, 0) end
    v = Vector(v.x, v.y, v.z)
    v:Normalize()
    return v
end

local function featureLocalDirection(ent, feature, fallbackAngle)
    feature = feature or {}

    if feature.type == "face" then
        return vecUnit(PB.GetFaceLocalNormal and PB.GetFaceLocalNormal(ent, feature.id) or nil)
    end

    if feature.type == "edge" then
        return vecUnit(PB.GetEdgeLocalDir and PB.GetEdgeLocalDir(ent, feature.id) or nil)
    end

    if isangle and isangle(fallbackAngle) then
        return vecUnit(fallbackAngle:Forward())
    end

    return Vector(1, 0, 0)
end

local function entityLocalDirToWorld(ent, localDir)
    localDir = vecUnit(localDir)

    if IsValid(ent) then
        local origin = ent:LocalToWorld(Vector())
        return vecUnit(ent:LocalToWorld(localDir) - origin)
    end

    return localDir
end

local function gcAttachmentWorldDirection(graph, nodeID, att, fallbackWorldDir)
    local node = graph and graph.nodes and graph.nodes[nodeID]
    att = PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(att) or att

    if not node or not att then return vecUnit(fallbackWorldDir) end

    local ent = node.entity
    local localDir = featureLocalDirection(ent, att.feature, att.localAngle)

    if IsValid(ent) then
        return entityLocalDirToWorld(ent, localDir)
    end

    local baseAng = node.worldAngle or Angle()
    return vecUnit(baseAng:Forward() * localDir.x + baseAng:Right() * localDir.y + baseAng:Up() * localDir.z, fallbackWorldDir)
end

local function gcVisualScale(graph, nodeID)
    local node = graph and graph.nodes and graph.nodes[nodeID]
    if not node or not IsValid(node.entity) then return 18 end

    local mn, mx = node.entity:OBBMins(), node.entity:OBBMaxs()
    local size = mx - mn
    local maxDim = math.max(math.abs(size.x), math.abs(size.y), math.abs(size.z))

    return math.Clamp(maxDim * 0.28, 12, 28)
end

local function DrawGCAxisMarker(pos, worldDir, color, spriteMat, label, length)
    if not pos then return end

    local dir = vecUnit(worldDir)
    length = tonumber(length) or 18

    local c = Color(color.r or 255, color.g or 150, color.b or 0, 255)
    local a = pos - dir * length
    local b = pos + dir * length



    render.DrawLine(a, b, c, true)
    render.DrawLine(a + Vector(0, 0, 0.6), b + Vector(0, 0, 0.6), c, true)
    render.DrawLine(a - Vector(0, 0, 0.6), b - Vector(0, 0, 0.6), c, true)

    render.SetMaterial(spriteMat or Material("sprites/light_ignorez"))
    render.DrawSprite(pos, 7, 7, c)
    render.DrawSprite(a, 5, 5, c)
    render.DrawSprite(b, 5, 5, c)

    if label then
        DrawText3D(b + dir * 3 + Vector(0, 0, 4), label, c, COL_LABEL_BG)
    end
end

local function DrawGCVisual(graph, gc, opts)
    if not graph or not gc then return end
    opts = opts or {}
    if gc.debugVisible == false and not opts.force then return end

    local aPos, aAng = PB.GCResolveAttachmentWorld and PB.GCResolveAttachmentWorld(graph, gc.nodeA, gc.attachA)
    local bPos, bAng = PB.GCResolveAttachmentWorld and PB.GCResolveAttachmentWorld(graph, gc.nodeB, gc.attachB)
    if not aPos or not bPos then return end

    local eyePos = LocalPlayer():GetShootPos()
    if eyePos:Distance(aPos) > PB_Overlay.maxDrawDist and eyePos:Distance(bPos) > PB_Overlay.maxDrawDist then return end

    local color = opts.color or COL.gcAnchor or COL.actionLinear or COL.selected
    local lineColor = opts.lineColor or COL.gcLine or COL.constraintLineActive or color
    if gc.enabled == false then lineColor = COL.textMuted or lineColor end

    render.DrawLine(aPos, bPos, lineColor, true)

    local gcType = gc.type or gc.gcType or ""
    if IsGCDirectionalVisualType(gcType) then
        local ab = bPos - aPos
        local ba = aPos - bPos
        local aDir = gcAttachmentWorldDirection(graph, gc.nodeA, gc.attachA, ab)
        local bDir = gcAttachmentWorldDirection(graph, gc.nodeB, gc.attachB, ba)
        DrawGCAxisMarker(aPos, aDir, color, opts.spriteMat, opts.label and "A AXIS" or nil, gcVisualScale(graph, gc.nodeA))
        DrawGCAxisMarker(bPos, bDir, color, opts.spriteMat, opts.label and "B AXIS" or nil, gcVisualScale(graph, gc.nodeB))
    else
        DrawGCPointMarker(aPos, color, opts.spriteMat, 7)
        DrawGCPointMarker(bPos, color, opts.spriteMat, 7)
    end

    if opts.label then
        local mid = (aPos + bPos) * 0.5
        DrawText3D(mid + Vector(0, 0, 8), opts.label, color, COL_LABEL_BG)
        DrawText3D(aPos + Vector(0, 0, 8), "A", color, COL_LABEL_BG)
        DrawText3D(bPos + Vector(0, 0, 8), "B", color, COL_LABEL_BG)
    end
end

local function GetCurrentGCPickerAttach(graph)
    if not PB_GCMode or PB_GCMode.phase ~= "attach" then return nil end
    local side = PB_GCMode.side == "B" and "B" or "A"

    if PB_GCEditDraft and tonumber(PB_GCEditDraft.id or 0) == tonumber(PB_GCMode.selectedGCID or PB_GCEditDraft.id or 0) then
        return side == "B" and PB_GCEditDraft.attachB or PB_GCEditDraft.attachA
    end

    if PB_GCDraft then
        return side == "B" and PB_GCDraft.attachB or PB_GCDraft.attachA
    end

    return nil
end

local function DrawGCHoverPreview(graph, spriteMat)
    if not PB_GCMode or not PB_GCMode.active or PB_GCMode.phase ~= "attach" then return end
    if not PB_GCMode.hoveredFeature or not PB_GCMode.hoveredNodeID then return end
    local node = graph and graph.nodes and graph.nodes[PB_GCMode.hoveredNodeID]
    if not node or not IsValid(node.entity) then return end
    if PB_GCMode.nodeID and tonumber(PB_GCMode.nodeID) ~= tonumber(node.id) then return end

    local previous = GetCurrentGCPickerAttach(graph)
    local keepAngle = previous and previous.localAngle or nil
    if IsGCDirectionalVisualType(PB_GCMode.gcType or "") then keepAngle = nil end
    local att = PB.GCAttachmentFromSnap and PB.GCAttachmentFromSnap(node, PB_GCMode.hoveredFeature, keepAngle)
    if not att then return end

    local pos, ang = PB.GCResolveAttachmentWorld and PB.GCResolveAttachmentWorld({ nodes = { [node.id] = node } }, node.id, att)
    if not pos then return end

    local color = COL.faceSelected or COL.selected
    if IsGCDirectionalVisualType(PB_GCMode.gcType or "") then
        local dir = gcAttachmentWorldDirection({ nodes = { [node.id] = node } }, node.id, att)
        DrawGCAxisMarker(pos, dir, color, spriteMat, "AXIS", gcVisualScale(graph, node.id))
    else
        DrawGCPointMarker(pos, color, spriteMat, 8)
    end
end






















local function NodeDisplayCenter(node)
    if node and IsValid(node.entity) then
        return node.entity:LocalToWorld(node.entity:OBBCenter())
    end
    return node and node.worldPos or Vector()
end
PB.NodeDisplayCenter = NodeDisplayCenter

local MIRROR_PLANE_COLORS = COL.mirrorPlaneFill or {}
local MIRROR_PLANE_LINE_COLORS = COL.mirrorPlaneLine or {}

local function DrawMirrorPlaneForNode(node, axis, active)
    if not node or not IsValid(node.entity) then return end
    axis = (PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(axis)) or tostring(axis or "x")
    local center = NodeDisplayCenter(node)
    local ang = node.worldAngle or node.entity:GetAngles()
    local u, v
    if axis == "x" then
        u, v = ang:Right(), ang:Up()
    elseif axis == "y" then
        u, v = ang:Forward(), ang:Up()
    else
        u, v = ang:Forward(), ang:Right()
    end

    local mins, maxs = node.entity:OBBMins(), node.entity:OBBMaxs()
    local size = math.max((maxs - mins):Length() * 0.42, active and 48 or 34)
    local a = center + u * size + v * size
    local b = center - u * size + v * size
    local c = center - u * size - v * size
    local d = center + u * size - v * size
    local fill = MIRROR_PLANE_COLORS[axis] or MIRROR_PLANE_COLORS.fallback
    local line = MIRROR_PLANE_LINE_COLORS[axis] or MIRROR_PLANE_LINE_COLORS.fallback
    if active then
        fill = WithAlpha(fill, 28)
        line = WithAlpha(line, 145)
    end
    render.SetColorMaterial()
    render.DrawQuad(a, b, c, d, fill)
    render.DrawQuad(d, c, b, a, WithAlpha(fill, math.floor((fill.a or 255) * 0.65)))
    render.DrawLine(a, b, line, true)
    render.DrawLine(b, c, line, true)
    render.DrawLine(c, d, line, true)
    render.DrawLine(d, a, line, true)
    DrawText3D(center + v * (size + 8), string.upper(axis), line, COL_LABEL_BG)
end

local function DrawMirrorPlanes(graph, mirrorNodeID, activeAxis)
    local node = mirrorNodeID and graph.nodes[mirrorNodeID] or nil
    if not node or not IsValid(node.entity) then return end
    for _, axis in ipairs({"x", "y", "z"}) do
        DrawMirrorPlaneForNode(node, axis, axis == activeAxis)
    end
end

hook.Add("PostDrawOpaqueRenderables", "PB_Overlay", function(_, isSkybox, is3DSkybox)
    if isSkybox or is3DSkybox then return end
    if not PB.IsToolActive() then return end
    if not PB_Overlay.enabled or not GetConVar(cvarName("overlayEnabled", PREFIX .. "overlay_enabled")):GetBool() then return end

    local graph = PB.GetGraph(LocalPlayer())
    if not graph or table.Count(graph.nodes) == 0 then return end

    local eyePos = LocalPlayer():GetShootPos()
    PB_Overlay.maxDrawDist = GetConVar(cvarName("overlayMaxDistance", PREFIX .. "overlay_maxdist")):GetFloat()
    local showLabels = GetConVar(cvarName("overlayLabels", PREFIX .. "overlay_labels")):GetBool()
    local showOffsets = GetConVar(cvarName("overlayOffsets", PREFIX .. "overlay_offsets")):GetBool()
    local showConstraints = GetConVar(cvarName("overlayConstraints", PREFIX .. "overlay_constraints")):GetBool()
    local showAxes = GetConVar(cvarName("overlayAxes", PREFIX .. "overlay_axes")):GetBool()
    local showDimensions = GetConVar(cvarName("overlayDimensions", PREFIX .. "overlay_dimensions")):GetBool()
    local spriteMat = Material("sprites/light_ignorez")


    for nodeID, node in pairs(graph.nodes) do
        local isSelected = (nodeID == PB_Overlay.selectedNodeID)
        local isHovered = (nodeID == PB_Overlay.hoveredNodeID)


        if node.visible == false and not isSelected then continue end

        local color = GetNodeColor(node, isSelected, isHovered)

        if node.isPattern then
            local parentNode = graph.nodes[node.parentID]
            if parentNode and IsValid(parentNode.entity) then
                local parentPos = NodeDisplayCenter(parentNode)

                for _, patEnt in ipairs(node.patternEntities or {}) do
                    if IsValid(patEnt) then
                        local patPos = patEnt:GetPos()
                        if eyePos:Distance(patPos) <= PB_Overlay.maxDrawDist then
                            render.SetMaterial(spriteMat)
                            render.DrawSprite(patPos, 6, 6, COL_PATTERN)


                            local toParent = parentPos - patPos
                            local totalLen = toParent:Length()
                            if totalLen > 0.1 then
                                toParent:Normalize()
                                local pos = 0
                                while pos < totalLen do
                                    local segEnd = math.min(pos + 8, totalLen)
                                    render.DrawLine(patPos + toParent * pos, patPos + toParent * segEnd, COL_PATTERN, true)
                                    pos = segEnd + 4
                                end
                            end
                        end
                    end
                end

                if showLabels and eyePos:Distance(parentPos) < PB_Overlay.maxDrawDist then
                    DrawText3D(parentPos + Vector(0, 0, 24),
                        node.label .. " (" .. #(node.patternEntities or {}) .. ")",
                        color, COL_LABEL_BG)
                end
            end
        elseif IsValid(node.entity) then




            local pos = NodeDisplayCenter(node)
            local ang = node.worldAngle
            if eyePos:Distance(pos) <= PB_Overlay.maxDrawDist then


                render.SetMaterial(spriteMat)
                local spriteSize = isSelected and 6 or 4
                render.DrawSprite(pos, spriteSize * 2, spriteSize * 2, color)
                if isSelected then
                    local pulse = math.sin(CurTime() * 4) * 0.3 + 0.7
                    render.DrawSprite(pos, spriteSize * 4, spriteSize * 4,
                        WithAlpha(color, (color.a or 255) * pulse * 0.3))
                end


                if showAxes then
                    render.DrawLine(pos, pos + ang:Forward() * 20, COL.axisX, true)
                    render.DrawLine(pos, pos + ang:Right() * 20, COL.axisY, true)
                    render.DrawLine(pos, pos + ang:Up() * 20, COL.axisZ, true)
                end


                if node.parentID and graph.nodes[node.parentID] then
                    local parentNode = graph.nodes[node.parentID]
                    if IsValid(parentNode.entity) then
                        local parentPos = NodeDisplayCenter(parentNode)
                        render.DrawLine(pos, parentPos, isSelected and COL_LINE_ACTIVE or COL_LINE, true)

                        if showOffsets then
                            local midpoint = (pos + parentPos) * 0.5
                            local lp = node.localPos
                            DrawText3D(midpoint + Vector(0, 0, 4),
                                node.exprPos or string.format("(%.1f, %.1f, %.1f)", lp.x, lp.y, lp.z),
                                COL.whiteSoft, COL_LABEL_BG)
                            local la = node.localAngle
                            if la.p ~= 0 or la.y ~= 0 or la.r ~= 0 then
                                DrawText3D(midpoint + Vector(0, 0, -6),
                                    node.exprAngle or string.format("A(%.1f, %.1f, %.1f)", la.p, la.y, la.r),
                                    COL.overlayAngleText, COL_LABEL_BG)
                            end
                        end

                        if showConstraints and node.constraintType ~= "none" and CONSTRAINT_DISPLAY[node.constraintType] then
                            DrawText3D(pos + Vector(0, 0, 12),
                                CONSTRAINT_DISPLAY[node.constraintType],
                                CONSTRAINT_COLORS[node.constraintType], COL_LABEL_BG)
                        end
                    end
                end

                if showLabels then
                    DrawText3D(pos + Vector(0, 0, 18), node.label, color, COL_LABEL_BG)

                    if node.notes and (isSelected or isHovered) then
                        DrawText3D(pos + Vector(0, 0, 26), node.notes, COL.overlayNotes, COL_LABEL_BG)
                    end
                end
            end
        end
    end


    do
        local drawn = {}
        local function drawForPC(pc)
            if not pc or pc.mode ~= "mirror" or not pc.mirrorNodeID or drawn[pc.id] then return end
            drawn[pc.id] = true
            DrawMirrorPlanes(graph, pc.mirrorNodeID, PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(pc.mirrorAxis or pc.mirrorFace or "x") or (pc.mirrorAxis or pc.mirrorFace or "x"))
        end

        if PB_MirrorMode and PB_MirrorMode.active and PB_MirrorMode.hoveredNodeID then
            DrawMirrorPlanes(graph, PB_MirrorMode.hoveredNodeID, "x")
        end

        if PB_MirrorDraft and PB_MirrorDraft.mirrorNodeID then
            DrawMirrorPlanes(graph, PB_MirrorDraft.mirrorNodeID, PB_MirrorDraft.axis or "x")
        end

        if PB_PCMode and PB_PCMode.selectedPCID then
            drawForPC(graph.pconstraints[PB_PCMode.selectedPCID])
        end

        local sel = PB_Overlay.selectedNodeID
        if sel then
            local n = graph.nodes[sel]





            if n and n.isMirrorGenerated and n.mirrorPCID then
                drawForPC(graph.pconstraints[n.mirrorPCID])
            end
        end
    end


    local selectedNodeID = PB_Overlay.selectedNodeID
    for _, pc in pairs(graph.pconstraints) do
        if not pc.active then continue end
        local parentNode = graph.nodes[pc.parentNodeID]
        local childNode = graph.nodes[pc.childNodeID]
        if not parentNode or not childNode then continue end
        if not IsValid(parentNode.entity) or not IsValid(childNode.entity) then continue end

        local pcColor = PB.GetPCSolverColor(pc) or PB.GetPCColor(pc)
        local measurement = PB.MeasurePConstraint(graph, pc)
        if measurement then
            render.DrawLine(measurement.parentPos, measurement.childPos, pcColor, true)

            if showDimensions and (selectedNodeID == pc.parentNodeID or selectedNodeID == pc.childNodeID
                or PB_PCMode.selectedPCID == pc.id) then
                DrawText3D(measurement.midpoint + Vector(0, 0, 6), measurement.label, COL_DIM, COL_LABEL_BG)
                local statusSuffix = ""
                if pc.solverResidual and pc.solverResidual > 0.01 then
                    statusSuffix = "  r=" .. string.format("%.2f", pc.solverResidual)
                end
                DrawText3D(measurement.midpoint + Vector(0, 0, -4), PC_STR.pcPrefix .. pc.id .. statusSuffix, pcColor, COL_LABEL_BG)
            end
        end


        if PB_PCMode.selectedPCID == pc.id and pc.mode ~= "mirror" then
            DrawFeature(parentNode.entity, pc.parentFeature, COL_FACE_SEL)
            DrawFeature(childNode.entity, pc.childFeature, COL_FACE_SEL)
        end
    end


    if PB_PCMode.active then
        if PB_PCMode.firstNode and PB_PCMode.firstFeature then
            local firstNode = graph.nodes[PB_PCMode.firstNode]
            if firstNode and IsValid(firstNode.entity) then
                DrawFeature(firstNode.entity, PB_PCMode.firstFeature, COL_FACE_SEL)
                local featurePos = PB.GetFeatureWorldPos(firstNode, PB_PCMode.firstFeature)
                DrawText3D(featurePos + Vector(0, 0, 10), "1st: " .. firstNode.label, COL_FACE_SEL, COL_LABEL_BG)
            end
        end
        if PB_PCMode.hoveredEnt and IsValid(PB_PCMode.hoveredEnt) and PB_PCMode.hoveredFeature then
            DrawFeature(PB_PCMode.hoveredEnt, PB_PCMode.hoveredFeature, COL_FACE_HOV)
        end
    end





    if showConstraints then
        if graph.gconstraints then
            for _, gc in pairs(graph.gconstraints) do
                local selected = showDimensions and PB_GCMode and PB_GCMode.selectedGCID == gc.id
                DrawGCVisual(graph, gc, {
                    spriteMat = spriteMat,
                    label = selected and (PB.GConstraintSummary and PB.GConstraintSummary(gc, graph) or ("GC#" .. tostring(gc.id))) or nil,
                })
            end
        end

        if PB_GCDraft then
            DrawGCVisual(graph, PB_GCDraft, {
                spriteMat = spriteMat,
                force = true,
                color = COL.faceSelected or COL.selected,
                label = GC_STR.newLabelPrefix .. tostring(PB.GCTypeLabel(PB_GCDraft.type or PB_GCDraft.gcType or "")),
            })
        end

        if PB_GCEditDraft and PB_GCMode and PB_GCMode.selectedGCID then
            DrawGCVisual(graph, PB_GCEditDraft, {
                spriteMat = spriteMat,
                force = true,
                color = COL.faceSelected or COL.selected,
                label = GC_STR.editingPrefix .. tostring(PB_GCMode.selectedGCID),
            })
        end

        if PB_GCFieldPreviewDraft then
            DrawGCVisual(graph, PB_GCFieldPreviewDraft, {
                spriteMat = spriteMat,
                force = true,
                color = COL.faceSelected or COL.selected,
                label = GC_STR.editingPrefix .. tostring(PB_GCFieldPreviewDraft.id or GC_STR.newLabelPrefix),
            })
        end
    end



    if PB_GCMode and PB_GCMode.active then
        if PB_GCMode.phase == "nodes" and PB_GCMode.firstNodeID then
            local firstNode = graph.nodes[PB_GCMode.firstNodeID]
            if firstNode and IsValid(firstNode.entity) then
                DrawText3D(NodeDisplayCenter(firstNode) + Vector(0, 0, 28), "1st GC prop: " .. tostring(firstNode.label or firstNode.id), COL_FACE_SEL, COL_LABEL_BG)
            end
        elseif PB_GCMode.phase == "attach" and PB_GCMode.nodeID then
            local targetNode = graph.nodes[PB_GCMode.nodeID]
            if targetNode and IsValid(targetNode.entity) then
                DrawText3D(NodeDisplayCenter(targetNode) + Vector(0, 0, 28), GC_STR.pickAnchorOverlayPrefix .. tostring(PB_GCMode.side or "A"), COL_FACE_SEL, COL_LABEL_BG)
            end
        end
        if PB_GCMode.hoveredEnt and IsValid(PB_GCMode.hoveredEnt) and PB_GCMode.hoveredFeature then
            DrawFeature(PB_GCMode.hoveredEnt, PB_GCMode.hoveredFeature, COL_FACE_HOV)
            DrawGCHoverPreview(graph, spriteMat)
        end
    end
end)





hook.Add("HUDPaint", "PB_PCCreationHUD", function()
    if not PB_PCMode.active then return end
    if not PB.IsToolActive() then return end

    local panelW, panelH = 320, 140
    local panelX = ScrW() / 2 - panelW / 2
    local panelY = 60

    draw.RoundedBox(8, panelX, panelY, panelW, panelH, COL.panelBody)
    draw.RoundedBox(4, panelX + 4, panelY + 4, panelW - 8, 22, COL.panelHighlight)


    local modeName = PB.MODE_NAMES[PB_PCMode.pendingMode or "geometric"]
    local modeColor = COL.constraintModeGeometric
    if PB_PCMode.pendingMode == "parallel" then modeColor = COL.constraintModeParallel
    elseif PB_PCMode.pendingMode == "perpendicular" then modeColor = COL.constraintModePerpendicular
    elseif PB_PCMode.pendingMode == "planar" then modeColor = COL.constraintModePlanar or (COL.constraintModes and COL.constraintModes.planar) or modeColor end

    draw.SimpleText((HUD_STR.constraintPrefix or "") .. string.upper(modeName), "DermaDefaultBold",
        panelX + panelW / 2, panelY + 15, modeColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    if PB_PCMode.firstNode then
        local graph = PB.GetGraph(LocalPlayer())
        local firstNode = graph.nodes[PB_PCMode.firstNode]
        local nodeName = firstNode and firstNode.label or GC_STR.unknownNode
        local feature = PB_PCMode.firstFeature
        local featureName = GC_STR.unknownNode
        if feature then

            if feature.type == "face" then
                if PB.PhysFeatures and PB.PhysFeatures.IsPhysID and PB.PhysFeatures.IsPhysID(feature.id) then
                    featureName = "Face " .. tostring(feature.id):sub(3)
                else
                    featureName = PB.FACE_NAMES[feature.id] or feature.id
                end
            elseif feature.type == "edge" then
                if PB.PhysFeatures and PB.PhysFeatures.IsPhysID and PB.PhysFeatures.IsPhysID(feature.id) then
                    featureName = "Edge " .. tostring(feature.id):sub(3)
                else
                    featureName = PB.EDGE_NAMES[feature.id] or ("Edge " .. feature.id)
                end
            elseif feature.type == "corner" then
                if PB.PhysFeatures and PB.PhysFeatures.IsPhysID and PB.PhysFeatures.IsPhysID(feature.id) then
                    featureName = "Corner " .. tostring(feature.id):sub(3)
                else
                    featureName = PB.CORNER_NAMES[feature.id] or ("Pt " .. feature.id)
                end
            end
        end
        draw.SimpleText((HUD_STR.firstPrefix or "") .. nodeName .. " [" .. featureName .. "]", "DermaDefault",
            panelX + 10, panelY + 35, COL.selected)
        draw.SimpleText(HUD_STR.clickSecondFeature, "DermaDefault",
            panelX + 10, panelY + 55, COL.textSecondary)
    else
        draw.SimpleText(HUD_STR.clickFeature, "DermaDefault",
            panelX + 10, panelY + 35, COL.textSecondary)
        draw.SimpleText(HUD_STR.onFirstProp, "DermaDefault",
            panelX + 10, panelY + 55, COL.gcDisabled)
    end

    draw.SimpleText(HUD_STR.rightClickCancel, "DermaDefault",
        panelX + 10, panelY + 80, COL.error)


    if PB_PCMode.hoveredFeature then
        local feature = PB_PCMode.hoveredFeature
        local featureName = GC_STR.unknownNode
        local isPhys = PB.PhysFeatures and PB.PhysFeatures.IsPhysID and PB.PhysFeatures.IsPhysID(feature.id)
        if feature.type == "face" then
            featureName = isPhys and ("Face " .. tostring(feature.id):sub(3))
                or (PB.FACE_NAMES[feature.id] or feature.id)
        elseif feature.type == "edge" then
            featureName = isPhys and ("Edge " .. tostring(feature.id):sub(3))
                or (PB.EDGE_NAMES[feature.id] or ("Edge " .. feature.id))
        elseif feature.type == "corner" then
            featureName = isPhys and ("Corner " .. tostring(feature.id):sub(3))
                or (PB.CORNER_NAMES[feature.id] or ("Pt " .. feature.id))
        end


        local hovColor = COL.actionLinear
        local pendingMode = PB_PCMode.pendingMode or "geometric"
        if pendingMode ~= "geometric" then
            local firstType = PB_PCMode.firstFeature and PB_PCMode.firstFeature.type
            local checkType = firstType or feature.type
            if not PB.IsModeValidForFeatures(pendingMode, checkType, feature.type) then
                hovColor = COL.error
                featureName = featureName .. (HUD_STR.invalidDirection or "")
            end
        end

        draw.SimpleText((HUD_STR.hoveringPrefix or "") .. feature.type .. " - " .. featureName, "DermaDefault",
            panelX + 10, panelY + 100, hovColor)
    end
end)


hook.Add("HUDPaint", "PB_GConstraintPickerHUD", function()
    if not PB_GCMode or not PB_GCMode.active then return end
    if not PB.IsToolActive() then return end

    local graph = PB.GetGraph(LocalPlayer())
    local panelW, panelH = 340, 118
    local panelX = ScrW() / 2 - panelW / 2
    local panelY = 60
    local gcType = PB_GCMode.gcType or "weld"
    local title = "GMod " .. (PB.GCTypeLabel and PB.GCTypeLabel(gcType) or gcType)

    draw.RoundedBox(8, panelX, panelY, panelW, panelH, COL.panelBody)
    draw.RoundedBox(4, panelX + 4, panelY + 4, panelW - 8, 22, COL.panelHighlight)
    draw.SimpleText(title, "DermaDefaultBold", panelX + panelW / 2, panelY + 15, COL.selected, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    if PB_GCMode.phase == "attach" then
        local node = graph and graph.nodes[tonumber(PB_GCMode.nodeID or 0) or 0]
        draw.SimpleText(GC_STR.anchorTitlePrefix .. tostring(PB_GCMode.side or "A") .. GC_STR.anchorTitleMiddle .. tostring(node and node.label or GC_STR.generic), "DermaDefault", panelX + 10, panelY + 38, COL.selected)
        draw.SimpleText(GC_STR.pickFaceEdgeCorner, "DermaDefault", panelX + 10, panelY + 58, COL.textSecondary)
    elseif PB_GCMode.firstNodeID then
        local node = graph and graph.nodes[tonumber(PB_GCMode.firstNodeID or 0) or 0]
        draw.SimpleText(GC_STR.firstPropPrefix .. tostring(node and node.label or GC_STR.unknownNode), "DermaDefault", panelX + 10, panelY + 38, COL.selected)
        draw.SimpleText(GC_STR.clickSecondProp, "DermaDefault", panelX + 10, panelY + 58, COL.textSecondary)
    else
        draw.SimpleText(GC_STR.clickFirstProp, "DermaDefault", panelX + 10, panelY + 38, COL.textSecondary)
        draw.SimpleText(GC_STR.anchorsStartAtCenters, "DermaDefault", panelX + 10, panelY + 58, COL.textMuted)
    end

    if PB_GCMode.hoveredFeature then
        draw.SimpleText(GC_STR.hoveringPrefix .. tostring(PB_GCMode.hoveredFeature.type or GC_STR.defaultFeature), "DermaDefault", panelX + 10, panelY + 78, COL.actionLinear or COL.selected)
    end

    draw.SimpleText(HUD_STR.rightClickCancel, "DermaDefault", panelX + 10, panelY + 98, COL.error)
end)

hook.Add("HUDPaint", "PB_MirrorCreationHUD", function()
    if not PB_MirrorMode or not PB_MirrorMode.active then return end
    if not PB.IsToolActive() then return end

    local graph = PB.GetGraph(LocalPlayer())
    local source = graph and graph.nodes[PB_MirrorMode.sourceNodeID] or nil
    local panelW, panelH = 340, 120
    local panelX = ScrW() / 2 - panelW / 2
    local panelY = 215

    draw.RoundedBox(8, panelX, panelY, panelW, panelH, COL.panelBody)
    draw.RoundedBox(4, panelX + 4, panelY + 4, panelW - 8, 22, COL.mirrorHudHeader)
    draw.SimpleText(HUD_STR.mirrorPickTitle, "DermaDefaultBold", panelX + panelW / 2, panelY + 15,
        COL.actionMirror, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

    draw.SimpleText((HUD_STR.sourcePrefix or "") .. (source and source.label or GC_STR.unknownNode), "DermaDefault",
        panelX + 10, panelY + 38, COL.selected)

    if PB_MirrorMode.hoveredNodeID then
        local picked = graph.nodes[PB_MirrorMode.hoveredNodeID]
        draw.SimpleText((HUD_STR.mirrorPropPrefix or "") .. (picked and picked.label or GC_STR.unknownNode), "DermaDefault",
            panelX + 10, panelY + 58, COL.mirrorHudPicked)
        draw.SimpleText(HUD_STR.leftClickMirrorPick, "DermaDefault",
            panelX + 10, panelY + 78, COL.textSecondary)
    else
        draw.SimpleText(HUD_STR.aimMirrorPick, "DermaDefault",
            panelX + 10, panelY + 58, COL.textSecondary)
        draw.SimpleText(HUD_STR.mirrorPlanePreview, "DermaDefault",
            panelX + 10, panelY + 78, COL.mirrorHudHint)
    end

    draw.SimpleText(HUD_STR.rightClickCancel, "DermaDefault",
        panelX + 10, panelY + 98, COL.error)
end)





hook.Add("HUDPaint", "PB_Overlay_HUD", function()
    if PB_PCMode.active then return end
    if PB_GCMode and PB_GCMode.active then return end
    if not PB.IsToolActive() then return end
    if not PB_Overlay.enabled or not GetConVar(cvarName("overlayEnabled", PREFIX .. "overlay_enabled")):GetBool() then return end

    local graph = PB.GetGraph(LocalPlayer())
    if not graph or table.Count(graph.nodes) == 0 then return end

    local lineHeight = 18
    local maxWidth = 280
    local startX = 10
    local varCount = table.Count(graph.variables)


    local nodeCount = 0
    for _, nodeID in ipairs(PB.TreeOrder(graph)) do
        local node = graph.nodes[nodeID]
        if node and (node.isPattern or IsValid(node.entity)) then nodeCount = nodeCount + 1 end
    end

    local totalHeight = 22 + (varCount > 0 and ((varCount + 1) * lineHeight + 4) or 0) + (nodeCount + 1) * lineHeight + 10

    local diag = graph.solverDiagnostic
    local hasSolverInfo = diag and diag.numEquations > 0
    if hasSolverInfo then totalHeight = totalHeight + lineHeight + 4 end

    local currentY = math.floor(ScrH() / 2 - totalHeight / 2)

    draw.RoundedBox(6, startX - 4, currentY - 4, maxWidth + 8, totalHeight + 8, COL.pcResidualBackground)
    draw.SimpleText(HUD_STR.parametricTree, "DermaDefaultBold",
        startX + maxWidth / 2, currentY, COL.whiteSoft, TEXT_ALIGN_CENTER)
    currentY = currentY + 22


    if hasSolverInfo then
        local statusCol = PB.GetSolverStatusColor(graph)
        local statusStr = string.upper(diag.status)
            .. "  e=" .. diag.numEquations .. " u=" .. diag.numUnknowns
            .. "  i=" .. diag.iterations .. "  r=" .. string.format("%.3f", diag.residualNorm)
        draw.SimpleText(statusStr, "DermaDefault", startX + 4, currentY, statusCol)
        currentY = currentY + lineHeight + 4
    end


    if varCount > 0 then
        draw.SimpleText(UI_STR.variables, "DermaDefault", startX + 4, currentY, COL.accent)
        currentY = currentY + lineHeight
        for name, value in pairs(graph.variables) do
            draw.SimpleText("  $" .. name .. " = " .. tostring(value), "DermaDefault",
                startX + 4, currentY, COL.variableOverlayText)
            currentY = currentY + lineHeight
        end
        currentY = currentY + 4
    end


    draw.SimpleText(UI_STR.nodes, "DermaDefault", startX + 4, currentY, COL.textSecondary)
    currentY = currentY + lineHeight

    for _, nodeID in ipairs(PB.TreeOrder(graph)) do
        if currentY > ScrH() - 40 then break end
        local node = graph.nodes[nodeID]
        if not node then continue end
        if not node.isPattern and not IsValid(node.entity) then continue end

        local depth = PB.GetNodeDepth(graph, nodeID)
        local isSelected = (nodeID == PB_Overlay.selectedNodeID)

        if isSelected then
            draw.RoundedBox(2, startX, currentY - 1, maxWidth, lineHeight, COL.selectedRowOverlay)
        end
        draw.RoundedBox(4, startX + depth * 12 + 2, currentY + 4, 8, 8, GetNodeColor(node, isSelected, false))

        local label = node.label
        if node.isPattern then
            label = label .. " (" .. #(node.patternEntities or {}) .. ")"
        elseif node.constraintType and node.constraintType ~= "none" then
            label = label .. " [" .. node.constraintType .. "]"
        end
        local pcCount = #PB.GetAllPConstraintsForChild(graph, nodeID)
        if pcCount > 0 then
            label = label .. " {PC" .. (pcCount > 1 and "x" .. pcCount or "") .. "}"
        end
        if node.visible == false then label = label .. " [H]" end

        local textColor = node.visible == false and COL.textDisabled or COL.textPrimary
        draw.SimpleText(label, "DermaDefault",
            startX + depth * 12 + 14, currentY + lineHeight / 2,
            textColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        currentY = currentY + lineHeight
    end
end)





hook.Add("Think", "PB_Overlay_Hover", function()
    if not PB.IsToolActive() or not PB_Overlay.enabled then
        PB_Overlay.hoveredNodeID = nil
        PB_PCMode.hoveredEnt = nil
        PB_PCMode.hoveredFeature = nil
        if PB_MirrorMode then
            PB_MirrorMode.hoveredEnt = nil
            PB_MirrorMode.hoveredNodeID = nil
        end
        return
    end

    local graph = PB.GetGraph(LocalPlayer())
    if not graph then return end

    local ply = LocalPlayer()
    local trace = ply:GetEyeTrace()

    if IsValid(trace.Entity) then
        local node = PB.FindNodeByEntity(graph, trace.Entity)
        PB_Overlay.hoveredNodeID = node and node.id or nil
    else
        PB_Overlay.hoveredNodeID = nil
    end

    if PB_PCMode.active and IsValid(trace.Entity) and not trace.Entity:IsWorld() then
        PB_PCMode.hoveredEnt = trace.Entity
        PB_PCMode.hoveredFeature = PB.DetectFeature(
            trace.Entity, ply:EyePos(), ply:GetAimVector(), trace.HitPos, trace.HitNormal,
            PB.PickerPrefsFromConVars and PB.PickerPrefsFromConVars() or nil)
    else
        PB_PCMode.hoveredEnt = nil
        PB_PCMode.hoveredFeature = nil
    end

    if PB_MirrorMode and PB_MirrorMode.active and IsValid(trace.Entity) and not trace.Entity:IsWorld() then
        local node = PB.FindNodeByEntity(graph, trace.Entity)
        PB_MirrorMode.hoveredEnt = trace.Entity
        PB_MirrorMode.hoveredNodeID = node and node.id or nil
    elseif PB_MirrorMode then
        PB_MirrorMode.hoveredEnt = nil
        PB_MirrorMode.hoveredNodeID = nil
    end

    if PB_GCMode and PB_GCMode.active and IsValid(trace.Entity) and not trace.Entity:IsWorld() then
        local node = PB.FindNodeByEntity(graph, trace.Entity)
        PB_GCMode.hoveredEnt = trace.Entity
        PB_GCMode.hoveredNodeID = node and node.id or nil
        if PB_GCMode.phase == "attach" then
            PB_GCMode.hoveredFeature = PB.DetectFeature(
                trace.Entity, ply:EyePos(), ply:GetAimVector(), trace.HitPos, trace.HitNormal,
                PB.PickerPrefsFromConVars and PB.PickerPrefsFromConVars() or nil)
        else
            PB_GCMode.hoveredFeature = nil
        end
    elseif PB_GCMode then
        PB_GCMode.hoveredEnt = nil
        PB_GCMode.hoveredNodeID = nil
        PB_GCMode.hoveredFeature = nil
    end
end)










if SERVER then return end

PB.CONSTRAINT_TYPES = {"none", "weld", "axis", "ballsocket", "advballsocket", "slider", "rope", "elastic", "nocollide", "parent"}


PB_UI = PB_UI or {
    lastSelectedID = nil,
    treePanel = nil,
    propsPanel = nil,
    gcPanel = nil,
}

PB_MirrorDraft = PB_MirrorDraft or {
    sourceNodeID = nil,
    mirrorNodeID = nil,
    axis = "x",
}

function PB_ClearMirrorDraft(sourceNodeID)
    if sourceNodeID and PB_MirrorDraft and tonumber(PB_MirrorDraft.sourceNodeID) ~= tonumber(sourceNodeID) then return end
    PB_MirrorDraft = { sourceNodeID = nil, mirrorNodeID = nil, axis = "x" }
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end

function PB_SetMirrorDraft(sourceNodeID, mirrorNodeID, axis)
    sourceNodeID = tonumber(sourceNodeID)
    mirrorNodeID = tonumber(mirrorNodeID)
    if not sourceNodeID or sourceNodeID <= 0 or not mirrorNodeID or mirrorNodeID <= 0 then
        PB_ClearMirrorDraft()
        return
    end

    axis = (PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(axis or "x")) or tostring(axis or "x")
    if axis ~= "x" and axis ~= "y" and axis ~= "z" then axis = "x" end

    PB_MirrorDraft = {
        sourceNodeID = sourceNodeID,
        mirrorNodeID = mirrorNodeID,
        axis = axis,
    }

    if PB_Overlay then
        PB_Overlay.selectedNodeID = sourceNodeID
        PB_Overlay._needsRefresh = true
    end
end























PB_MirrorGhost = PB_MirrorGhost or { ent = nil, model = nil, visible = false }

local function PB_DestroyMirrorGhost()
    if IsValid(PB_MirrorGhost.ent) then PB_MirrorGhost.ent:Remove() end
    PB_MirrorGhost.ent = nil
    PB_MirrorGhost.model = nil
    PB_MirrorGhost.visible = false
end


local function PB_GetMirrorPreviewState(graph)
    if not graph then return nil end


    local draft = PB_MirrorDraft
    if draft and draft.sourceNodeID and draft.mirrorNodeID then
        local src = graph.nodes[tonumber(draft.sourceNodeID) or 0]
        local mir = graph.nodes[tonumber(draft.mirrorNodeID) or 0]
        if src and mir and not src.isPattern and not mir.isPattern and src.id ~= mir.id then
            return src, mir, draft.axis or "x"
        end
    end


    if PB_MirrorMode and PB_MirrorMode.active and PB_MirrorMode.sourceNodeID and PB_MirrorMode.hoveredNodeID then
        local src = graph.nodes[tonumber(PB_MirrorMode.sourceNodeID) or 0]
        local mir = graph.nodes[tonumber(PB_MirrorMode.hoveredNodeID) or 0]
        if src and mir and not src.isPattern and not mir.isPattern and src.id ~= mir.id then
            return src, mir, "x"
        end
    end

    return nil
end

local function PB_UpdateMirrorGhost()
    if not PB.IsToolActive or not PB.IsToolActive() then
        PB_DestroyMirrorGhost()
        return
    end

    local graph = PB.GetGraph(LocalPlayer())
    local src, mir, axis = PB_GetMirrorPreviewState(graph)
    if not src or not mir then
        PB_MirrorGhost.visible = false



        if IsValid(PB_MirrorGhost.ent) and PB_MirrorGhost._idleFrames and PB_MirrorGhost._idleFrames > 5 then
            PB_DestroyMirrorGhost()
        else
            PB_MirrorGhost._idleFrames = (PB_MirrorGhost._idleFrames or 0) + 1
        end
        return
    end
    PB_MirrorGhost._idleFrames = 0

    local model = src.model or (IsValid(src.entity) and src.entity:GetModel()) or nil
    if not model or model == "" then
        PB_DestroyMirrorGhost()
        return
    end

    if not IsValid(PB_MirrorGhost.ent) or PB_MirrorGhost.model ~= model then
        if IsValid(PB_MirrorGhost.ent) then PB_MirrorGhost.ent:Remove() end
        local ent = ClientsideModel(model, RENDERGROUP_BOTH)
        if not IsValid(ent) then
            PB_MirrorGhost.ent = nil
            PB_MirrorGhost.model = nil
            return
        end
        ent:SetNoDraw(true)
        ent:SetSolid(SOLID_NONE)
        ent:SetMoveType(MOVETYPE_NONE)
        ent:SetCollisionGroup(COLLISION_GROUP_WORLD)
        ent:DrawShadow(false)
        PB_MirrorGhost.ent = ent
        PB_MirrorGhost.model = model
    end

    local pos, ang = PB.ComputeMirrorTransform and PB.ComputeMirrorTransform(src, mir, axis)
    if not pos or not ang then
        PB_MirrorGhost.visible = false
        return
    end

    PB_MirrorGhost.ent:SetPos(pos)
    PB_MirrorGhost.ent:SetAngles(ang)
    PB_MirrorGhost.ent:SetupBones()
    PB_MirrorGhost.visible = true
end

hook.Add("Think", "PB_MirrorGhostThink", PB_UpdateMirrorGhost)

hook.Add("PostDrawTranslucentRenderables", "PB_MirrorGhostDraw", function(_, isSkybox, is3DSkybox)
    if isSkybox or is3DSkybox then return end
    if not PB_MirrorGhost.visible then return end
    if not IsValid(PB_MirrorGhost.ent) then return end


    render.SetColorModulation(0.55, 0.80, 1.00)
    render.SetBlend(0.45)
    PB_MirrorGhost.ent:DrawModel()
    render.SetColorModulation(1, 1, 1)
    render.SetBlend(1)
end)

hook.Add("ShutDown", "PB_MirrorGhostCleanup", PB_DestroyMirrorGhost)






function PB.SectionHeader(parent, text)
    local panel = vgui.Create("DPanel", parent)
    panel:Dock(TOP); panel:SetTall(22); panel:DockMargin(0, 6, 0, 2)
    panel.Paint = function(_, w, h)
        draw.RoundedBox(0, 0, 0, w, h, COL.panelHeader or COL.panelHeader)
        draw.SimpleText(text, "DermaDefaultBold", 6, h / 2, COL.projectHeaderText, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
end

function PB.HeaderLabel(parent, text, color)
    local label = vgui.Create("DLabel", parent)
    label:Dock(TOP); label:DockMargin(4, 4, 4, 4)
    label:SetText(text); label:SetFont("DermaDefaultBold")
    label:SetTextColor(color or COL.white)
end

function PB.NumberRow(parent, labelText, defaultValue, onSubmit)
    local row = vgui.Create("DPanel", parent)
    row:Dock(TOP); row:SetTall(24); row:DockMargin(4, 1, 4, 0)
    row.Paint = function() end

    local lbl = vgui.Create("DLabel", row)
    lbl:Dock(LEFT); lbl:SetWide(130); lbl:SetText(labelText)
    lbl:SetTextColor(COL.textSecondary); lbl:SetContentAlignment(5)

    local entry = vgui.Create("DTextEntry", row)
    entry:Dock(FILL); entry:SetValue(tostring(defaultValue or 0))
    if onSubmit then entry.OnEnter = function(self) onSubmit(self:GetValue()) end end
    return entry
end

function PB.DisabledRow(parent, labelText, value)
    local row = vgui.Create("DPanel", parent)
    row:Dock(TOP); row:SetTall(24); row:DockMargin(4, 1, 4, 0)
    row.Paint = function() end

    local lbl = vgui.Create("DLabel", row)
    lbl:Dock(LEFT); lbl:SetWide(130); lbl:SetText(labelText)
    lbl:SetTextColor(COL.disabledFieldLabel); lbl:SetContentAlignment(5)

    local entry = vgui.Create("DTextEntry", row)
    entry:Dock(FILL); entry:SetValue(tostring(value or 0))
    entry:SetEnabled(false); entry:SetTextColor(COL.disabledFieldText)
end

function PB.ActionButton(parent, text, color, onClick)
    local btn = vgui.Create("DButton", parent)
    btn:Dock(TOP); btn:DockMargin(4, 4, 4, 4)
    btn:SetText(text); btn:SetTextColor(color)
    btn.DoClick = onClick
end

function PB.InfoLabel(parent, text)
    local lbl = vgui.Create("DLabel", parent)
    lbl:Dock(TOP); lbl:DockMargin(8, 2, 8, 4)
    lbl:SetText(text); lbl:SetTextColor(COL.textMuted)
    lbl:SetAutoStretchVertical(true); lbl:SetWrap(true)
end








local PB_PANEL_STATE_DIR = "parametric_builder"
local PB_PANEL_STATE_PATH = PB_PANEL_STATE_DIR .. "/panel_state.txt"
local PB_PANEL_DEFAULT_W, PB_PANEL_DEFAULT_H = 380, 660

local function PB_ReadPanelState()
    if not (file and file.Read and util and util.JSONToTable) then return {} end
    local raw = file.Read(PB_PANEL_STATE_PATH, "DATA")
    if not raw or raw == "" then return {} end
    local data = util.JSONToTable(raw)
    if type(data) ~= "table" then return {} end
    return data
end

local function PB_WritePanelState(state)
    if not (file and file.Write and util and util.TableToJSON) then return end
    if file.CreateDir then file.CreateDir(PB_PANEL_STATE_DIR) end
    local payload = util.TableToJSON(state or {})
    if payload then file.Write(PB_PANEL_STATE_PATH, payload) end
end

function PB_LoadPanelBounds()
    local data = PB_ReadPanelState()
    return {
        x = tonumber(data.x),
        y = tonumber(data.y),
        w = tonumber(data.w),
        h = tonumber(data.h),
        tab = isstring(data.tab) and data.tab or nil,
    }
end

function PB_SavePanelBounds(bounds)
    if not bounds then return end
    local state = PB_ReadPanelState()
    if bounds.x ~= nil then state.x = tonumber(bounds.x) end
    if bounds.y ~= nil then state.y = tonumber(bounds.y) end
    if bounds.w ~= nil then state.w = tonumber(bounds.w) end
    if bounds.h ~= nil then state.h = tonumber(bounds.h) end
    if bounds.tab ~= nil then state.tab = tostring(bounds.tab) end
    PB_WritePanelState(state)
end

function PB_SavePanelTab(tabKey)
    if not tabKey or tabKey == "" then return end
    PB_SavePanelBounds({ tab = tabKey })
end

function PB_ResetPanelLayout()
    if file and file.Delete then file.Delete(PB_PANEL_STATE_PATH) end
    if IsValid(PB_MainPanel) then
        local panel = PB_MainPanel
        panel:SetSize(PB_PANEL_DEFAULT_W, math.min(PB_PANEL_DEFAULT_H, ScrH()))
        panel:SetPos(math.max(0, ScrW() - PB_PANEL_DEFAULT_W - 10), 80)
        panel.PBActiveTabKey = "projects"
        if IsValid(panel.PBTabs) and panel.PBTabByKey and panel.PBTabByKey.projects and IsValid(panel.PBTabByKey.projects.Tab) then
            panel.PBTabs:SetActiveTab(panel.PBTabByKey.projects.Tab)
        end
        local rx, ry = panel:GetPos()
        local rw, rh = panel:GetSize()
        PB_SavePanelBounds({ x = rx, y = ry, w = rw, h = rh, tab = "projects" })
    end
end

concommand.Add(PREFIX .. "reset_panel_layout", function()
    PB_ResetPanelLayout()
end)

local PB_TOGGLE_DEBOUNCE = 0.18
local _pbLastToggle = 0

local _pbSuppressOpenUntil = 0

local function PB_StoreOpenPanelState()
    if not IsValid(PB_MainPanel) then return end
    local px, py = PB_MainPanel:GetPos()
    local pw, ph = PB_MainPanel:GetSize()
    local tab = PB_MainPanel.PBActiveTabKey
    PB_SavePanelBounds({ x = px, y = py, w = pw, h = ph, tab = tab })
end

local function PB_MarkPanelLayoutDirty(panel)
    if not IsValid(panel) then return end
    panel.PBLayoutDirty = true
    panel.PBNextLayoutSave = SysTime() + 0.2
end

local function PB_SavePanelLayoutIfChanged(panel, force)
    if not IsValid(panel) then return end

    local px, py = panel:GetPos()
    local pw, ph = panel:GetSize()
    local tab = panel.PBActiveTabKey
    local sig = tostring(px) .. ":" .. tostring(py) .. ":" .. tostring(pw) .. ":" .. tostring(ph) .. ":" .. tostring(tab or "")

    if not force and panel.PBLastLayoutSig == sig then return end
    if not force and panel.PBNextLayoutSave and SysTime() < panel.PBNextLayoutSave then return end

    panel.PBLastLayoutSig = sig
    panel.PBLayoutDirty = false
    panel.PBNextLayoutSave = SysTime() + 0.2
    PB_SavePanelBounds({ x = px, y = py, w = pw, h = ph, tab = tab })
end

PB.ReleaseGameInput = PB.ReleaseGameInput or function()
    if vgui and vgui.GetKeyboardFocus then
        local focused = vgui.GetKeyboardFocus()
        if IsValid(focused) and focused.KillFocus then focused:KillFocus() end
    end
    if gui and gui.EnableScreenClicker then gui.EnableScreenClicker(false) end
end

function PB_ClosePanel(suppressReopen)
    if not IsValid(PB_MainPanel) then return false end
    PB_StoreOpenPanelState()
    local panel = PB_MainPanel
    PB_MainPanel = nil
    if suppressReopen then _pbSuppressOpenUntil = SysTime() + 0.1 end
    if IsValid(panel) then panel:Close() end
    if IsValid(panel) then panel:Remove() end
    if PB.ReleaseGameInput then PB.ReleaseGameInput() end
    return true
end

function PB_TogglePanel()
    local now = SysTime()
    if now - _pbLastToggle < PB_TOGGLE_DEBOUNCE then return end
    _pbLastToggle = now
    if PB_ClosePanel and PB_ClosePanel(true) then return end
    if now < _pbSuppressOpenUntil then return end
    PB_OpenPanel()
end

function PB_OpenPanel()
    if IsValid(PB_MainPanel) then return end

    PB_MainPanel = vgui.Create("DFrame")
    PB_MainPanel:SetTitle(UI_STR.mainPanelTitle)




    local DEFAULT_X, DEFAULT_Y = ScrW() - PB_PANEL_DEFAULT_W - 10, 80
    local saved = PB_LoadPanelBounds and PB_LoadPanelBounds() or nil
    local w = (saved and saved.w) or PB_PANEL_DEFAULT_W
    local h = (saved and saved.h) or PB_PANEL_DEFAULT_H


    w = math.Clamp(w, 320, ScrW())
    h = math.Clamp(h, 400, ScrH())
    local x = (saved and saved.x) or DEFAULT_X
    local y = (saved and saved.y) or DEFAULT_Y
    x = math.Clamp(x, 0, math.max(0, ScrW() - w))
    y = math.Clamp(y, 0, math.max(0, ScrH() - h))

    PB_MainPanel:SetSize(w, h)
    PB_MainPanel:SetPos(x, y)
    PB_MainPanel:SetDraggable(true)
    PB_MainPanel:SetSizable(true)
    PB_MainPanel:SetMinWidth(320)
    PB_MainPanel:SetMinHeight(400)
    PB_MainPanel:SetKeyboardInputEnabled(true)
    PB_MainPanel:MakePopup()
    PB_MainPanel:RequestFocus()
    PB_MainPanel:SetDeleteOnClose(true)

    PB_MainPanel.PBLastX = x
    PB_MainPanel.PBLastY = y
    PB_MainPanel.PBLastW = w
    PB_MainPanel.PBLastH = h
    PB_MainPanel.PBLastLayoutSig = tostring(x) .. ":" .. tostring(y) .. ":" .. tostring(w) .. ":" .. tostring(h) .. ":" .. tostring(PB_MainPanel.PBActiveTabKey or "")

    PB_MainPanel.OnKeyCodePressed = function(self, code)
        if code == KEY_R then
            PB_ClosePanel(true)
            return
        end
    end

    local oldThink = PB_MainPanel.Think
    PB_MainPanel.Think = function(self)
        if oldThink then oldThink(self) end
        if not IsValid(self) then return end

        local px, py = self:GetPos()
        local pw, ph = self:GetSize()
        if px ~= self.PBLastX or py ~= self.PBLastY or pw ~= self.PBLastW or ph ~= self.PBLastH then
            self.PBLastX = px
            self.PBLastY = py
            self.PBLastW = pw
            self.PBLastH = ph
            PB_MarkPanelLayoutDirty(self)
        end

        if self.PBLayoutDirty then
            PB_SavePanelLayoutIfChanged(self, false)
        end
    end

    PB_MainPanel.OnClose = function(self)
        if IsValid(self) then
            PB_SavePanelLayoutIfChanged(self, true)
        end
        if PB_PCMode.active then PB_PCMode_Exit() end
        if PB_GCMode and PB_GCMode.active and PB.GCPickerClient and PB.GCPickerClient.Cancel then PB.GCPickerClient.Cancel() end
        if PB_MainPanel == self then PB_MainPanel = nil end
        if PB.ReleaseGameInput then PB.ReleaseGameInput() end
    end

    PB_MainPanel.OnRemove = function(self)
        if IsValid(self) then
            PB_SavePanelLayoutIfChanged(self, true)
        end
        if PB_MainPanel == self then PB_MainPanel = nil end
        if PB.ReleaseGameInput then PB.ReleaseGameInput() end
    end

    local tabs = vgui.Create("DPropertySheet", PB_MainPanel)
    tabs:Dock(FILL)

    local savedTab = saved and saved.tab or nil
    local tabByKey = {}
    PB_MainPanel.PBTabs = tabs
    PB_MainPanel.PBTabByKey = tabByKey
    local function AddPBTab(key, label, panel, icon)
        local sheet = tabs:AddSheet(label, panel, icon)
        if sheet then
            tabByKey[key] = sheet
            if IsValid(sheet.Tab) then
                local oldDoClick = sheet.Tab.DoClick
                sheet.Tab.DoClick = function(tabButton, ...)
                    PB_MainPanel.PBActiveTabKey = key
                    PB_SavePanelTab(key)
                    PB_MarkPanelLayoutDirty(PB_MainPanel)
                    if oldDoClick then return oldDoClick(tabButton, ...) end
                    return tabs:SetActiveTab(tabButton)
                end
            end
        end
        return sheet
    end


    local projectsContainer = vgui.Create("DPanel", tabs)
    projectsContainer:Dock(FILL)
    projectsContainer.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelBackground) end
    AddPBTab("projects", TAB_STR.projects, projectsContainer, "icon16/folder_page.png")

    local projectsToolbar = vgui.Create("DPanel", projectsContainer)
    projectsToolbar:Dock(TOP); projectsToolbar:SetTall(28)
    projectsToolbar.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelToolbar) end

    local function ProjectToolbarButton(text, width, dock, onClick)
        local btn = vgui.Create("DButton", projectsToolbar)
        btn:SetText(text); btn:Dock(dock); btn:SetWide(width)
        btn.DoClick = onClick
        return btn
    end
    ProjectToolbarButton(TREE_STR.refresh, 55, LEFT, function() PB_RefreshProjects(projectsContainer) end)
    ProjectToolbarButton(PROJECT_MENU_STR.newProjectTitle, 90, LEFT, function()
        Derma_StringRequest(PROJECT_MENU_STR.newProjectTitle, PROJECT_MENU_STR.namePrompt, UI_STR.untitled, function(text)
            if text and text ~= "" then PB.Net.ProjectCreate(text, "") end
        end)
    end)

    local projectsScroll = vgui.Create("DScrollPanel", projectsContainer)
    projectsScroll:Dock(FILL); projectsScroll:DockMargin(2, 2, 2, 2)
    projectsContainer.projectScroll = projectsScroll
    PB_UI.projectPanel = projectsContainer
    PB_RefreshProjects(projectsContainer)


    local treeContainer = vgui.Create("DPanel", tabs)
    treeContainer:Dock(FILL)
    treeContainer.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelBackground) end
    AddPBTab("tree", TAB_STR.tree, treeContainer, "icon16/chart_organisation.png")

    local toolbar = vgui.Create("DPanel", treeContainer)
    toolbar:Dock(TOP); toolbar:SetTall(28)
    toolbar.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelToolbar) end

    local function ToolbarButton(text, width, dock, onClick)
        local btn = vgui.Create("DButton", toolbar)
        btn:SetText(text); btn:Dock(dock); btn:SetWide(width)
        btn.DoClick = onClick
        return btn
    end
    ToolbarButton(TREE_STR.refresh, 55, LEFT, function() PB_RefreshTree(treeContainer) end)
    ToolbarButton(TREE_STR.propagate, 65, LEFT, function() RunConsoleCommand(PREFIX .. "propagate_all") end)
    ToolbarButton(TREE_STR.addRoot, 55, LEFT, function() RunConsoleCommand(PREFIX .. "add_root") end)
    ToolbarButton(TREE_STR.clear, 45, RIGHT, function()
        Derma_Query(TREE_STR.removeAllConfirm, GC_STR.confirm,
            TREE_STR.yes, function() RunConsoleCommand(PREFIX .. "clear_all") end,
            TREE_STR.no, function() end)
    end):SetTextColor(COL.error)

    local treeScroll = vgui.Create("DScrollPanel", treeContainer)
    treeScroll:Dock(FILL); treeScroll:DockMargin(2, 2, 2, 2)
    treeContainer.treeScroll = treeScroll
    PB_UI.treePanel = treeContainer
    PB_RefreshTree(treeContainer)


    local propScroll = vgui.Create("DScrollPanel", tabs)
    propScroll:Dock(FILL)
    propScroll.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelBackground) end
    AddPBTab("properties", TAB_STR.properties, propScroll, "icon16/wrench.png")
    PB_UI.lastSelectedID = nil
    PB_UI.propsPanel = propScroll
    PB_BuildProps(propScroll)
    propScroll.Think = function(self)
        local sel = PB_Overlay and PB_Overlay.selectedNodeID
        if sel ~= PB_UI.lastSelectedID then
            PB_UI.lastSelectedID = sel
            PB_BuildProps(self)
        end
    end


    local pcContainer = vgui.Create("DPanel", tabs)
    pcContainer:Dock(FILL)
    pcContainer.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelBackground) end
    AddPBTab("pconstraints", TAB_STR.pconstraints, pcContainer, "icon16/link.png")
    PB_BuildPCTab(pcContainer)


    local gcContainer = vgui.Create("DPanel", tabs)
    gcContainer:Dock(FILL)
    gcContainer.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelBackground) end
    AddPBTab("gconstraints", TAB_STR.gconstraints, gcContainer, "icon16/link_go.png")
    PB_BuildGConstraintTab(gcContainer)
    PB_UI.gcPanel = gcContainer


    local varScroll = vgui.Create("DScrollPanel", tabs)
    varScroll:Dock(FILL)
    varScroll.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelBackground) end
    AddPBTab("variables", TAB_STR.variables, varScroll, "icon16/calculator.png")
    PB_UI.varsPanel = varScroll
    PB_BuildVars(varScroll)



    local settingsScroll = vgui.Create("DScrollPanel", tabs)
    settingsScroll:Dock(FILL)
    settingsScroll.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelBackground) end
    AddPBTab("settings", TAB_STR.settings, settingsScroll, "icon16/cog.png")
    PB_BuildSettings(settingsScroll)

    local restore = savedTab and tabByKey[savedTab]
    if restore and IsValid(restore.Tab) then
        PB_MainPanel.PBActiveTabKey = savedTab
        tabs:SetActiveTab(restore.Tab)
    else
        PB_MainPanel.PBActiveTabKey = "projects"
    end
end
concommand.Add(PREFIX .. "open_panel", PB_TogglePanel)




hook.Add("Think", PREFIX .. "panel_reload_key_close", function()
    if not IsValid(PB_MainPanel) then return end
    if not input or not input.WasKeyPressed then return end
    if input.WasKeyPressed(KEY_R) then
        PB_ClosePanel(true)
    end
end)


hook.Add("Think", "PB_AutoRefresh", function()
    if not IsValid(PB_MainPanel) or not PB_UI.treePanel then return end
    if PB_Overlay and PB_Overlay._needsRefresh then
        PB_Overlay._needsRefresh = false
        PB_RefreshTree(PB_UI.treePanel)
        if IsValid(PB_UI.propsPanel) then PB_BuildProps(PB_UI.propsPanel) end
        if IsValid(PB_UI.varsPanel) and PB_MainPanel.PBActiveTabKey == "variables" then
            PB_BuildVars(PB_UI.varsPanel)
        end
    end
end)










if SERVER then return end


function PB_RefreshTree(container)
    local scroll = container.treeScroll
    if not IsValid(scroll) then return end
    scroll:Clear()




    PB_TreeContainer = container

    local graph = PB.GetGraph(LocalPlayer())
    if not graph then return end

    for _, nodeID in ipairs(PB.TreeOrder(graph)) do
        local node = graph.nodes[nodeID]
        if not node then continue end
        if not node.isPattern and not IsValid(node.entity) then continue end

        local depth = PB.GetNodeDepth(graph, nodeID)
        local isSelected = (nodeID == (PB_Overlay and PB_Overlay.selectedNodeID))

        local label
        if node.isPattern then
            label = "~ " .. node.label .. " (" .. #(node.patternEntities or {}) .. ")"
        else
            label = node.parentID and "+ " or "> "
            local pcCount = #PB.GetPConstraintsForChild(graph, nodeID)
            local xlCount = #PB.GetCrossLinksForNode(graph, nodeID)
            if pcCount > 0 then label = label .. "{PC" .. (pcCount > 1 and "x" .. pcCount or "") .. "} " end
            if xlCount > 0 then label = label .. "{XL" .. (xlCount > 1 and "x" .. xlCount or "") .. "} " end
            if node.constraintType and node.constraintType ~= "none" then
                label = label .. "[" .. string.sub(node.constraintType, 1, 1):upper() .. "] "
            end
            label = label .. node.label
        end

        local textColor
        if isSelected then textColor = COL.selected
        elseif node.locked then textColor = COL.error
        elseif node.isPattern then textColor = COL.patternHeader
        elseif not node.parentID then textColor = COL.rootNode
        else textColor = COL.childNode end

        local row = vgui.Create("DButton", scroll)
        row:Dock(TOP); row:SetTall(26); row:DockMargin(depth * 16, 1, 2, 0)
        row:SetText(label); row:SetTextColor(textColor); row:SetContentAlignment(4)
        row.Paint = function(self, w, h)
            local bg = isSelected and COL.rowSelected
                or (self:IsHovered() and COL.panelHeader or COL.panelHeader or COL.rowDefault)
            draw.RoundedBox(2, 0, 0, w, h, bg)
        end

        row.DoClick = function()
            if PB_Overlay then PB_Overlay.selectedNodeID = nodeID end
            RunConsoleCommand(PREFIX .. "select_node", tostring(nodeID))
            timer.Simple(0.05, function()
                if IsValid(container) then PB_RefreshTree(container) end
            end)
        end

        row.DoRightClick = function()
            local menu = DermaMenu()
            menu:AddOption("Select", function()
                if PB_Overlay then PB_Overlay.selectedNodeID = nodeID end
                RunConsoleCommand(PREFIX .. "select_node", tostring(nodeID))
            end):SetIcon("icon16/cursor.png")

            if not node.isPattern then
                menu:AddOption(PROJECT_MENU_STR.rename, function()
                    Derma_StringRequest(PROJECT_MENU_STR.rename, PROP_STR.label, node.label, function(text)
                        RunConsoleCommand(PREFIX .. "rename_node", tostring(nodeID), text)
                    end)
                end):SetIcon("icon16/textfield_rename.png")
            end

            local parentMenu = menu:AddSubMenu(TREE_STR.setParent)
            parentMenu:AddOption(TREE_STR.root, function()
                RunConsoleCommand(PREFIX .. "reparent", tostring(nodeID), "0")
            end)
            for _, info in ipairs(PB.GetNodeList(graph)) do
                if info.id ~= nodeID then
                    parentMenu:AddOption(info.label .. " #" .. info.id, function()
                        RunConsoleCommand(PREFIX .. "reparent", tostring(nodeID), tostring(info.id))
                    end)
                end
            end

            menu:AddOption("Lock/Unlock", function()
                RunConsoleCommand(PREFIX .. "toggle_lock", tostring(nodeID))
            end):SetIcon("icon16/lock.png")

            local visLabel = node.visible ~= false and TREE_STR.hide or TREE_STR.show
            menu:AddOption(visLabel, function()
                RunConsoleCommand(PREFIX .. "toggle_visibility", tostring(nodeID))
            end):SetIcon(node.visible ~= false and "icon16/eye.png" or "icon16/link_break.png")

            menu:AddSpacer()
            menu:AddOption(PC_STR.delete, function()
                RunConsoleCommand(PREFIX .. "remove_node", tostring(nodeID), "0")
            end):SetIcon("icon16/cross.png")
            menu:AddOption(TREE_STR.deleteChildren, function()
                RunConsoleCommand(PREFIX .. "remove_node", tostring(nodeID), "1")
            end):SetIcon("icon16/delete.png")

            menu:Open()
        end
    end

    if table.Count(graph.nodes) == 0 then
        PB.InfoLabel(scroll, TREE_STR.empty)
    end
end










if SERVER then return end


function PB_BuildProps(panel)
    panel:Clear()
    local graph = PB.GetGraph(LocalPlayer())
    local nodeID = PB_Overlay and PB_Overlay.selectedNodeID
    if not graph or not nodeID or not graph.nodes[nodeID] then
        PB.InfoLabel(panel, PROP_STR.selectNode)
        return
    end

    local node = graph.nodes[nodeID]
    local nodeIDStr = tostring(nodeID)

    if node.isPattern then
        PB_BuildPatternProps(panel, node, nodeIDStr)
        return
    end

    PB.HeaderLabel(panel, (PROP_STR.nodePrefix or "") .. node.label .. " (" .. PROP_STR.idPrefix .. nodeID .. ")", COL.selected)


    PB.NumberRow(panel, PROP_STR.label, node.label, function(val)
        RunConsoleCommand(PREFIX .. "rename_node", nodeIDStr, val)
    end)


    local notesEntry = PB.NumberRow(panel, PROP_STR.notes, node.notes or "", function(val)
        RunConsoleCommand(PREFIX .. "set_notes", nodeIDStr, val)
    end)















    local pcs = PB.GetPConstraintsForChild(graph, nodeID)
    local lockedPos, lockedAng = {}, {}
    local diag = graph.solverDiagnostic
    local diagAxes = nil
    if diag and diag.nodeAxes then



        diagAxes = diag.nodeAxes[nodeIDStr] or diag.nodeAxes[nodeID]
    end
    if diagAxes then
        for ax, isFree in pairs(diagAxes.pos or {}) do
            if ax == "x" or ax == "y" or ax == "z" then
                lockedPos[ax] = not isFree
            end
        end
        for ax, isFree in pairs(diagAxes.ang or {}) do
            if ax == "p" or ax == "y" or ax == "r" then
                lockedAng[ax] = not isFree
            end
        end
    end

    if node.isMirrorGenerated then
        lockedPos.x, lockedPos.y, lockedPos.z = true, true, true
        lockedAng.p, lockedAng.y, lockedAng.r = true, true, true
    end

    local axisSel = diag and diag.axisSelection or nil
    if axisSel and ((tonumber(axisSel.hiddenNullity) or 0) > 0 or (tonumber(axisSel.coupledPins) or 0) > 0) then
        local bits = {}
        if (tonumber(axisSel.coupledPins) or 0) > 0 then
            bits[#bits + 1] = tostring(axisSel.coupledPins) .. PROP_STR.coupledUIDOF .. ((tonumber(axisSel.coupledPins) or 0) == 1 and "" or "s")
        end
        if (tonumber(axisSel.hiddenNullity) or 0) > 0 then
            bits[#bits + 1] = tostring(axisSel.hiddenNullity) .. PROP_STR.hiddenMechanismDOF .. ((tonumber(axisSel.hiddenNullity) or 0) == 1 and "" or "s")
        end
        PB.InfoLabel(panel, PROP_STR.solverNote .. table.concat(bits, ", ") .. ".")
    end


    local allPCs = PB.GetPConstraintsForChild(graph, nodeID)
    for _, pc in ipairs(allPCs) do
        local dof = PB.GetPCDOF(pc)
        local pcIDStr = tostring(pc.id)
        local label = PC_STR.pcPrefix .. pc.id .. " (" .. pc.mode .. ")" .. (pc.flipped and PC_STR.flippedTag or "")
        PB.SectionHeader(panel, label)
        PB.InfoLabel(panel, dof.desc)

            for _, param in ipairs(PB.GetPCEditParams(pc)) do
                PB.NumberRow(panel, param.label .. ":", pc[param.key] or 0, function(val)
                    RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, param.key, val)
                end)
            end

            if pc.mode == "mirror" then
                local mirrorNode = pc.mirrorNodeID and graph.nodes[pc.mirrorNodeID] or nil
                PB.InfoLabel(panel, PROP_STR.mirroredAround .. (mirrorNode and (mirrorNode.label .. " (" .. PROP_STR.idPrefix .. mirrorNode.id .. ")") or GC_STR.unknownNode)
                    .. "\nPlane: " .. string.upper(tostring(pc.mirrorAxis or pc.mirrorFace or "x"))
                    .. "\nEdit or delete this mirror from the PConstraints list.")

                local mirrorGCCheck = vgui.Create("DCheckBoxLabel", panel)
                mirrorGCCheck:Dock(TOP)
                mirrorGCCheck:DockMargin(8, 3, 8, 0)
                mirrorGCCheck:SetText(PROP_STR.mirrorGConstraints or "Mirror GMod constraints")
                mirrorGCCheck:SetTextColor(COL.text or color_white)
                mirrorGCCheck:SetValue(pc.mirrorGConstraints and 1 or 0)
                mirrorGCCheck.OnChange = function(_, val)
                    RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "mirrorGConstraints", val and "1" or "0")
                    if PB_Overlay then PB_Overlay._needsRefresh = true end
                end

                PB.InfoLabel(panel, PROP_STR.mirrorGConstraintsHelp or "Also copies compatible GMod constraint definitions to the mirrored node.")
            elseif pc.mode == "symmetry" then
                PB.NumberRow(panel, PROP_STR.mirrorNodeID, pc.mirrorNodeID or 0, function(val)
                    RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "mirrorNodeID", val)
                end)
                local mirrorCombo = vgui.Create("DComboBox", panel)
                mirrorCombo:Dock(TOP); mirrorCombo:DockMargin(4, 2, 4, 2)
                mirrorCombo:SetValue(pc.mirrorFace or "+x")
                for _, face in ipairs(PB.FACES) do mirrorCombo:AddChoice(PB.FACE_NAMES[face], face) end
                mirrorCombo.OnSelect = function(_, _, _, data)
                    RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "mirrorFace", data)
                end
            end

            if pc.mode ~= "mirror" then
                local buttonRow = vgui.Create("DPanel", panel)
                buttonRow:Dock(TOP); buttonRow:SetTall(24); buttonRow:DockMargin(4, 2, 4, 0)
                buttonRow.Paint = function() end

                local flipBtn = vgui.Create("DButton", buttonRow)
                flipBtn:Dock(LEFT); flipBtn:SetWide(70)
                flipBtn:SetText(pc.flipped and (UI_STR.unflipSolutionShort ) or (UI_STR.flipSolutionShort ))
                flipBtn:SetTextColor(COL.warning)
                flipBtn.DoClick = function() RunConsoleCommand(PREFIX .. "flip_pc", pcIDStr) end

                local deleteBtn = vgui.Create("DButton", buttonRow)
                deleteBtn:Dock(RIGHT); deleteBtn:SetWide(70)
                deleteBtn:SetText(PC_STR.delete); deleteBtn:SetTextColor(COL.error)
                deleteBtn.DoClick = function()
                    RunConsoleCommand(PREFIX .. "remove_pc", pcIDStr)
                    PB_PCMode.selectedPCID = nil
                end
            end
    end

    local function shortExprLabel(expr)
        expr = tostring(expr or "")
        if expr == "" then return nil end
        if #expr > 18 then expr = string.sub(expr, 1, 15) .. "..." end
        return expr
    end

    local function axisFieldLabel(base, expr, suffix)
        local short = shortExprLabel(expr)
        if short then
            return base .. " [" .. short .. "]" .. (suffix or ":")
        end
        return base .. (suffix or ":")
    end

    local function axisFieldValue(nodeTable, family, ax, fallback)
        local parts = family == "pos" and nodeTable.exprPosParts or nodeTable.exprAngleParts
        if istable(parts) and parts[ax] and tostring(parts[ax]) ~= "" then
            return tostring(parts[ax])
        end
        return tostring(math.Round(fallback, 2))
    end


    local function cleanDOFOverride(family, ax)
        local ov = istable(node.dofOverrides) and node.dofOverrides or nil
        ov = ov and istable(ov[family]) and ov[family][ax] or nil
        if ov == "lock" or ov == "unlock" then return ov end
        return nil
    end

    local function dofState(family, ax, solverLocked)
        local ov = cleanDOFOverride(family, ax)
        if node.isMirrorGenerated then
            return true, "generated", nil
        end
        if ov == "lock" then return true, "user_lock", ov end
        if ov == "unlock" then return false, "user_unlock", ov end
        if solverLocked then return true, "solver_lock", nil end
        return false, "free", nil
    end

    local function dofSuffix(source)
        if source == "user_lock" then return PROP_STR.userLockedSuffix or " (user locked):" end
        if source == "user_unlock" then return PROP_STR.userUnlockedSuffix or " (user unlocked):" end
        if source == "solver_lock" then return PROP_STR.solverLockedSuffix or PROP_STR.lockedSuffix or " (locked):" end
        if source == "generated" then return PROP_STR.lockedSuffix or " (locked):" end
        return ":"
    end

    local function dofIconColor(source)
        if source == "user_lock" then return COL.dofUserLock or COL.warning end
        if source == "user_unlock" then return COL.dofUserUnlock or COL.info end
        if source == "solver_lock" or source == "generated" then return COL.dofSolverLock or COL.textMuted end
        return COL.dofFree or COL.success
    end

    local function dofIconText(locked, source)
        if source == "user_unlock" then return "U" end
        if locked then return "L" end
        return "O"
    end

    local function setLocalDOFOverride(family, ax, mode)
        node.dofOverrides = istable(node.dofOverrides) and node.dofOverrides or { pos = {}, ang = {} }
        node.dofOverrides.pos = istable(node.dofOverrides.pos) and node.dofOverrides.pos or {}
        node.dofOverrides.ang = istable(node.dofOverrides.ang) and node.dofOverrides.ang or {}
        node.dofOverrides[family][ax] = mode ~= "auto" and mode or nil
    end

    local function DOFRow(parent, family, ax, labelText, value, locked, source)
        local row = vgui.Create("DPanel", parent)
        row:Dock(TOP)
        row:SetTall(24)
        row:DockMargin(4, 1, 4, 0)
        row.Paint = function() end

        local lbl = vgui.Create("DLabel", row)
        lbl:Dock(LEFT)
        lbl:SetWide(106)
        lbl:SetText(labelText)
        lbl:SetTextColor(locked and COL.disabledFieldLabel or COL.textSecondary)
        lbl:SetContentAlignment(5)

        local icon = vgui.Create("DButton", row)
        icon:Dock(LEFT)
        icon:SetWide(22)
        icon:DockMargin(0, 1, 4, 1)
        icon:SetText(dofIconText(locked, source))
        icon:SetTextColor(dofIconColor(source))
        icon:SetTooltip(source == "user_lock" and "User locked. Click to return to solver/auto."
            or source == "user_unlock" and "User unlocked. Click to return to solver/auto."
            or source == "solver_lock" and "Solver locked. Click to force unlock."
            or source == "generated" and "Mirror-generated DOF."
            or "Free. Click to user lock.")
        icon.DoClick = function()
            if source == "generated" then return end
            local mode
            if source == "user_lock" or source == "user_unlock" then
                mode = "auto"
            elseif locked then
                mode = "unlock"
            else
                mode = "lock"
            end
            setLocalDOFOverride(family, ax, mode)
            RunConsoleCommand(PREFIX .. "set_dof_override", nodeIDStr, family, ax, mode)
            if PB_Overlay then PB_Overlay._needsRefresh = true end
        end
        icon.DoRightClick = function()
            if source == "generated" then return end
            local mode = source == "user_lock" and "unlock" or "lock"
            setLocalDOFOverride(family, ax, mode)
            RunConsoleCommand(PREFIX .. "set_dof_override", nodeIDStr, family, ax, mode)
            if PB_Overlay then PB_Overlay._needsRefresh = true end
        end

        local entry = vgui.Create("DTextEntry", row)
        entry:Dock(FILL)
        entry:SetValue(tostring(value or 0))
        if locked then
            entry:SetEnabled(false)
            entry:SetTextColor(COL.disabledFieldText)
        end
        return locked and nil or entry
    end

    PB.SectionHeader(panel, PROP_STR.localPosition)
    local posEntries = {}
    for _, ax in ipairs({"x", "y", "z"}) do
        local locked, source = dofState("pos", ax, lockedPos[ax])
        local expr = istable(node.exprPosParts) and node.exprPosParts[ax] or nil
        local label = axisFieldLabel(string.upper(ax), expr, dofSuffix(source))
        local value = axisFieldValue(node, "pos", ax, node.localPos[ax])
        posEntries[ax] = DOFRow(panel, "pos", ax, label, value, locked, source)
    end
    local function getPosValues()
        return posEntries.x and posEntries.x:GetValue() or axisFieldValue(node, "pos", "x", node.localPos.x),
               posEntries.y and posEntries.y:GetValue() or axisFieldValue(node, "pos", "y", node.localPos.y),
               posEntries.z and posEntries.z:GetValue() or axisFieldValue(node, "pos", "z", node.localPos.z)
    end
    for _, ax in ipairs({"x", "y", "z"}) do
        if posEntries[ax] then
            posEntries[ax].OnEnter = function()
                local x, y, z = getPosValues()
                TraceEvent("ui_dof", "pos_submit", { nodeID = nodeID, axis = ax, values = { x = x, y = y, z = z }, nodeBefore = TNode(node), diag = TDiag() })
                RunConsoleCommand(PREFIX .. "set_pos_all", nodeIDStr, x, y, z, ax)
            end
            posEntries[ax].OnLoseFocus = function(entry)
                TraceEvent("ui_dof", "pos_lose_focus", { nodeID = nodeID, axis = ax, text = entry and entry.GetValue and entry:GetValue() or nil, node = TNode(node), diag = TDiag() })
            end
        end
    end
    if #pcs == 0 then
        local posExprEntry = PB.NumberRow(panel, PROP_STR.posExpr, node.exprPos or "", function(val)
            TraceEvent("ui_dof", "pos_expr_submit", { nodeID = nodeID, value = val, nodeBefore = TNode(node), diag = TDiag() })
            RunConsoleCommand(PREFIX .. "set_expr_pos", nodeIDStr, val == "" and nil or val)
        end)

        if node.exprPos and node.exprPos ~= "" then
            local result = PB.EvalExpression(graph, node.exprPos)
            local preview = result and ("→ " .. tostring(result)) or PROP_STR.previewError
            local previewColor = result and COL.previewSuccess or COL.previewError
            PB.InfoLabel(panel, preview)
        end
    end


    PB.SectionHeader(panel, PROP_STR.localAngle)
    local angEntries = {}
    for _, pair in ipairs({{"p", GC_STR.pitch}, {"y", GC_STR.yaw}, {"r", GC_STR.roll}}) do
        local ax, labelBase = pair[1], pair[2]
        local locked, source = dofState("ang", ax, lockedAng[ax])
        local expr = istable(node.exprAngleParts) and node.exprAngleParts[ax] or nil
        local label = axisFieldLabel(labelBase, expr, dofSuffix(source))
        local value = axisFieldValue(node, "ang", ax, node.localAngle[ax])
        angEntries[ax] = DOFRow(panel, "ang", ax, label, value, locked, source)
    end
    local function getAngValues()
        return angEntries.p and angEntries.p:GetValue() or axisFieldValue(node, "ang", "p", node.localAngle.p),
               angEntries.y and angEntries.y:GetValue() or axisFieldValue(node, "ang", "y", node.localAngle.y),
               angEntries.r and angEntries.r:GetValue() or axisFieldValue(node, "ang", "r", node.localAngle.r)
    end
    for _, ax in ipairs({"p", "y", "r"}) do
        if angEntries[ax] then
            angEntries[ax].OnEnter = function()
                local p, y, r = getAngValues()
                TraceEvent("ui_dof", "ang_submit", { nodeID = nodeID, axis = ax, values = { p = p, y = y, r = r }, nodeBefore = TNode(node), diag = TDiag() })
                RunConsoleCommand(PREFIX .. "set_ang_all", nodeIDStr, p, y, r, ax)
            end
            angEntries[ax].OnLoseFocus = function(entry)
                TraceEvent("ui_dof", "ang_lose_focus", { nodeID = nodeID, axis = ax, text = entry and entry.GetValue and entry:GetValue() or nil, node = TNode(node), diag = TDiag() })
            end
        end
    end
    if #pcs == 0 then
        local angExprEntry = PB.NumberRow(panel, PROP_STR.angExpr, node.exprAngle or "", function(val)
            TraceEvent("ui_dof", "ang_expr_submit", { nodeID = nodeID, value = val, nodeBefore = TNode(node), diag = TDiag() })
            RunConsoleCommand(PREFIX .. "set_expr_ang", nodeIDStr, val == "" and nil or val)
        end)
        if node.exprAngle and node.exprAngle ~= "" then
            local result = PB.EvalExpression(graph, node.exprAngle)
            local preview = result and ("→ " .. tostring(result)) or PROP_STR.previewError
            PB.InfoLabel(panel, preview)
        end
    end


    PB.SectionHeader(panel, PROP_STR.mirror)
    PB.InfoLabel(panel, PROP_STR.mirrorHelp)

    if node.isMirrorGenerated and node.mirrorPCID then
        local pc = graph.pconstraints and graph.pconstraints[node.mirrorPCID] or nil
        local src = node.mirrorSourceNodeID and graph.nodes[node.mirrorSourceNodeID] or nil
        PB.InfoLabel(panel, PROP_STR.generatedByMirror .. tostring(node.mirrorPCID) .. (src and (PROP_STR.from .. src.label) or ""))

        if pc and pc.mode == "mirror" then
            local mirrorNode = pc.mirrorNodeID and graph.nodes[pc.mirrorNodeID] or nil
            PB.InfoLabel(panel, PROP_STR.mirrorProp .. (mirrorNode and (mirrorNode.label .. " (" .. PROP_STR.idPrefix .. mirrorNode.id .. ")") or GC_STR.unknownNode))

            local axisCombo = vgui.Create("DComboBox", panel)
            axisCombo:Dock(TOP); axisCombo:DockMargin(4, 2, 4, 2)
            axisCombo:SetValue(PROP_STR.mirrorPlane .. string.upper(tostring(pc.mirrorAxis or pc.mirrorFace or "x")))
            axisCombo:AddChoice(PROP_STR.xPlane, "x")
            axisCombo:AddChoice(PROP_STR.yPlane, "y")
            axisCombo:AddChoice(PROP_STR.zPlane, "z")
            axisCombo.OnSelect = function(_, _, _, data)
                RunConsoleCommand(PREFIX .. "edit_pc", tostring(pc.id), "mirrorAxis", data)
                if PB_Overlay then PB_Overlay._needsRefresh = true end
            end

            local editRow = vgui.Create("DPanel", panel)
            editRow:Dock(TOP); editRow:SetTall(24); editRow:DockMargin(4, 2, 4, 2)
            editRow.Paint = function() end




            local deleteBtn = vgui.Create("DButton", editRow)
            deleteBtn:Dock(FILL)
            deleteBtn:SetText(PROP_STR.deleteMirror)
            deleteBtn:SetTextColor(COL.error)
            deleteBtn.DoClick = function()
                RunConsoleCommand(PREFIX .. "remove_pc", tostring(pc.id))
                PB_PCMode.selectedPCID = nil
                if PB_Overlay then PB_Overlay._needsRefresh = true end
            end
        end
    end

    local draft = PB_MirrorDraft
    local hasDraft = draft and tonumber(draft.sourceNodeID) == nodeID and draft.mirrorNodeID and graph.nodes[draft.mirrorNodeID]
    if hasDraft then
        local mirrorNode = graph.nodes[draft.mirrorNodeID]
        PB.InfoLabel(panel, PROP_STR.pickedMirrorProp .. (mirrorNode.label or ("Node " .. tostring(mirrorNode.id))) .. " (" .. PROP_STR.idPrefix .. tostring(mirrorNode.id) .. ")")

        local axisCombo = vgui.Create("DComboBox", panel)
        axisCombo:Dock(TOP); axisCombo:DockMargin(4, 2, 4, 2)
        axisCombo:SetValue(PROP_STR.mirrorPlane .. string.upper(tostring(draft.axis or "x")))
        axisCombo:AddChoice(PROP_STR.xPlane, "x")
        axisCombo:AddChoice(PROP_STR.yPlane, "y")
        axisCombo:AddChoice(PROP_STR.zPlane, "z")
        axisCombo.OnSelect = function(_, _, _, data)
            if PB_MirrorDraft and tonumber(PB_MirrorDraft.sourceNodeID) == nodeID then
                PB_MirrorDraft.axis = (PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(data)) or data or "x"
            end
            if PB_Overlay then PB_Overlay._needsRefresh = true end
        end

        local gcCheck = vgui.Create("DCheckBoxLabel", panel)
        gcCheck:Dock(TOP)
        gcCheck:DockMargin(8, 3, 8, 0)
        gcCheck:SetText(PROP_STR.mirrorGConstraints or "Mirror GMod constraints")
        gcCheck:SetTextColor(COL.text or color_white)
        gcCheck:SetValue(PB_MirrorDraft and PB_MirrorDraft.mirrorGConstraints and 1 or 0)
        gcCheck.OnChange = function(_, val)
            if PB_MirrorDraft and tonumber(PB_MirrorDraft.sourceNodeID) == nodeID then
                PB_MirrorDraft.mirrorGConstraints = val and true or false
            end
        end

        PB.InfoLabel(panel, PROP_STR.mirrorGConstraintsHelp or "Also copies compatible GMod constraint definitions to the mirrored node.")

        local createRow = vgui.Create("DPanel", panel)
        createRow:Dock(TOP); createRow:SetTall(24); createRow:DockMargin(4, 2, 4, 2)
        createRow.Paint = function() end

        local createBtn = vgui.Create("DButton", createRow)
        createBtn:Dock(LEFT); createBtn:SetWide(120)
        createBtn:SetText(PROP_STR.create)
        createBtn:SetTextColor(COL.actionCreate)
        createBtn.DoClick = function()
            local mirrorID = tonumber(PB_MirrorDraft and PB_MirrorDraft.mirrorNodeID)
            local axis = (PB_MirrorDraft and PB_MirrorDraft.axis) or "x"
            local mirrorGConstraints = PB_MirrorDraft and PB_MirrorDraft.mirrorGConstraints == true
            axis = (PB.NormalizeMirrorAxis and PB.NormalizeMirrorAxis(axis)) or axis
            PB_ClearMirrorDraft(nodeID)
            RunConsoleCommand(PREFIX .. "create_mirror_pc", nodeIDStr, tostring(mirrorID or 0), axis, mirrorGConstraints and "1" or "0")
        end

        local cancelBtn = vgui.Create("DButton", createRow)
        cancelBtn:Dock(RIGHT); cancelBtn:SetWide(150)
        cancelBtn:SetText(PROP_STR.deleteMirror)
        cancelBtn:SetTextColor(COL.error)
        cancelBtn.DoClick = function()
            PB_ClearMirrorDraft(nodeID)
        end
    else
        local mirrorPCs = {}
        for _, pc in pairs(graph.pconstraints or {}) do
            if pc.mode == "mirror" and pc.parentNodeID == nodeID then
                mirrorPCs[#mirrorPCs + 1] = pc
            end
        end
        table.sort(mirrorPCs, function(a, b) return (a.id or 0) < (b.id or 0) end)

        if #mirrorPCs == 0 then
            PB.InfoLabel(panel, PROP_STR.noMirrors)
        else
            local lines = {}
            for _, pc in ipairs(mirrorPCs) do
                local mirrorNode = pc.mirrorNodeID and graph.nodes[pc.mirrorNodeID] or nil
                local childNode = pc.childNodeID and graph.nodes[pc.childNodeID] or nil
                lines[#lines + 1] = "PC#" .. tostring(pc.id)
                    .. PROP_STR.plane .. string.upper(tostring(pc.mirrorAxis or pc.mirrorFace or "x"))
                    .. PROP_STR.around .. (mirrorNode and (mirrorNode.label .. " (" .. PROP_STR.idPrefix .. mirrorNode.id .. ")") or GC_STR.unknownNode)
                    .. PROP_STR.output .. (childNode and (childNode.label .. " (" .. PROP_STR.idPrefix .. childNode.id .. ")") or GC_STR.unknownNode)
            end
            PB.InfoLabel(panel, table.concat(lines, "\n"))
            PB.InfoLabel(panel, PC_STR.editCreatedMirror)
        end

        PB.ActionButton(panel, PROP_STR.createMirror, COL.actionMirror, function()
            PB_ClearMirrorDraft()
            PB_MirrorMode_Enter(nodeID)
        end)
    end


    if node.parentID then
        PB.SectionHeader(panel, PROP_STR.snapToBounds)
        local parentFaceCombo = vgui.Create("DComboBox", panel)
        parentFaceCombo:Dock(TOP); parentFaceCombo:DockMargin(4, 2, 4, 0)
        parentFaceCombo:SetValue(node.snapParentFace and PB.FACE_NAMES[node.snapParentFace] or PROP_STR.parentFacePlaceholder)
        for _, face in ipairs(PB.FACES) do parentFaceCombo:AddChoice(PB.FACE_NAMES[face], face) end

        local childFaceCombo = vgui.Create("DComboBox", panel)
        childFaceCombo:Dock(TOP); childFaceCombo:DockMargin(4, 2, 4, 0)
        childFaceCombo:SetValue(node.snapChildFace and PB.FACE_NAMES[node.snapChildFace] or PROP_STR.childFacePlaceholder)
        for _, face in ipairs(PB.FACES) do childFaceCombo:AddChoice(PB.FACE_NAMES[face], face) end

        local gapEntry = PB.NumberRow(panel, PROP_STR.gap, node.snapGap or 0)
        PB.ActionButton(panel, PROP_STR.snap, COL.actionCreate, function()
            local _, parentFace = parentFaceCombo:GetSelected()
            local _, childFace = childFaceCombo:GetSelected()
            if parentFace and childFace then
                RunConsoleCommand(PREFIX .. "snap_to_face", nodeIDStr, parentFace, childFace, gapEntry:GetValue())
            end
        end)

        local SNAP_PRESETS = {
            {PROP_STR.stackTop, "+z", "-z"}, {PROP_STR.below, "-z", "+z"},
            {PROP_STR.front, "+x", "-x"}, {PROP_STR.back, "-x", "+x"},
            {PROP_STR.right, "+y", "-y"}, {PROP_STR.left, "-y", "+y"},
        }
        for _, preset in ipairs(SNAP_PRESETS) do
            local btn = vgui.Create("DButton", panel)
            btn:Dock(TOP); btn:DockMargin(8, 1, 8, 0); btn:SetTall(20)
            btn:SetText(preset[1]); btn:SetTextColor(COL.actionPreset)
            btn.DoClick = function()
                RunConsoleCommand(PREFIX .. "snap_to_face", nodeIDStr, preset[2], preset[3], gapEntry:GetValue())
            end
        end
    end

end










if SERVER then return end


function PB_BuildPCTab(panel)
    local scroll = vgui.Create("DScrollPanel", panel)
    scroll:Dock(FILL); scroll:DockMargin(2, 2, 2, 2)

    local function Rebuild()
        scroll:Clear()
        local graph = PB.GetGraph(LocalPlayer())

        PB.SectionHeader(scroll, "Parametric Constraints (Single Solver)")


        local diag = graph.solverDiagnostic
        if diag and diag.numEquations > 0 then
            local statusColor = PB.GetSolverStatusColor(graph)
            local statusRow = vgui.Create("DPanel", scroll)
            statusRow:Dock(TOP); statusRow:SetTall(64); statusRow:DockMargin(4, 2, 4, 2)
            statusRow.Paint = function(self, w, h)
                draw.RoundedBox(4, 0, 0, w, h, COL.statusPanelBackground)
                draw.RoundedBox(2, 0, 0, 4, h, statusColor)
                local label = PB.GetSolverStatusLabel(graph)
                draw.SimpleText(label, "DermaDefaultBold", 10, 6, statusColor, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                local info = string.format((STR.SolverSummary or {}).statusCompact,
                    diag.numEquations, diag.numUnknowns, diag.iterations, diag.residualNorm, tonumber(diag.trustRatio) or 0)
                draw.SimpleText(info, "DermaDefault", 10, 24, COL.statusInfoText, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                local detail = string.format((STR.SolverSummary or {}).detailCompact, tostring(diag.modelStatus or GC_STR.unknownNode), tostring(diag.attemptStatus or GC_STR.unknownNode))
                draw.SimpleText(detail, "DermaDefault", 10, 38, COL.statusDetailText, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                if #diag.overConstrained > 0 then
                    local ids = {}
                    for _, oc in ipairs(diag.overConstrained) do
                        table.insert(ids, PC_STR.pcPrefix .. oc.pcid)
                    end
                    draw.SimpleText(PC_STR.conflictsPrefix .. table.concat(ids, ", "), "DermaDefault", 10, 52, COL.error, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
                    statusRow:SetTall(70)
                end
            end
        end

        PB.InfoLabel(scroll, "Select a constraint mode, then click 'Add Constraint' to enter selection mode.")


        PB.SectionHeader(scroll, GC_STR.createConstraint)
        local modeCombo = vgui.Create("DComboBox", scroll)
        modeCombo:Dock(TOP); modeCombo:DockMargin(4, 2, 4, 2)
        modeCombo:SetValue(PB.MODE_NAMES[PB_PCMode.pendingMode or "geometric"])
        for _, mode in ipairs({"geometric", "planar", "parallel", "perpendicular"}) do
            modeCombo:AddChoice(PB.MODE_NAMES[mode], mode)
        end
        modeCombo.OnSelect = function(_, _, _, data)
            PB_PCMode.pendingMode = data
        end

        PB.ActionButton(scroll, PC_STR.addConstraint, COL.pconstraintAddButton or COL.constraintModeGeometric, function()
            PB_PCMode_Enter()
        end)


        PB.SectionHeader(scroll, "Special Constraints")
        PB.ActionButton(scroll, PC_STR.addDistanceConstraint, COL.constraintModes.distance, function()
            local sel = PB_Overlay and PB_Overlay.selectedNodeID
            if not sel then return end
            Derma_StringRequest("Distance Constraint", "Target node ID:", "", function(targetStr)
                local targetID = tonumber(targetStr)
                if targetID then
                    Derma_StringRequest("Distance", "Distance value:", "100", function(distStr)
                        RunConsoleCommand(PREFIX .. "create_distance_pc", tostring(sel), tostring(targetID), distStr)
                    end)
                end
            end)
        end)




        PB.SectionHeader(scroll, "Active Constraints")
        local pcList = PB.GetPConstraintList(graph)
        if #pcList == 0 then PB.InfoLabel(scroll, "No PConstraints yet.") end

        for _, pc in ipairs(pcList) do
            local isSelected = (PB_PCMode.selectedPCID == pc.id)
            local pcColor = PB.GetPCColor(pc)
            local desc = PB.DescribePConstraint(pc, graph)

            local row = vgui.Create("DButton", scroll)
            row:Dock(TOP); row:SetTall(28); row:DockMargin(4, 2, 4, 0)
            row:SetText("")
            row.Paint = function(self, w, h)
                local bg = isSelected and COL.gcRowSelected
                    or (self:IsHovered() and COL.rowHover or COL.rowInactiveDefault)
                draw.RoundedBox(3, 0, 0, w, h, bg)
                if isSelected then draw.RoundedBox(2, 0, 0, 3, h, pcColor) end
                local textCol = pc.active and pcColor or COL.disabledFieldLabel
                draw.SimpleText("#" .. pc.id .. "  " .. desc, "DermaDefault", 8, h / 2, textCol, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)

                local solverCol = PB.GetPCSolverColor(pc)
                if solverCol and pc.active then
                    draw.RoundedBox(3, w - 60, 4, 56, h - 8, COL.pcResidualBackground)
                    local rStr = string.format("r=%.2f", pc.solverResidual or 0)
                    draw.SimpleText(rStr, "DermaDefault", w - 32, h / 2, solverCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                elseif pc.active then
                    draw.RoundedBox(4, w - 14, h / 2 - 4, 8, 8, COL.pcSatisfiedDot)
                end
            end
            row.DoClick = function()
                PB_PCMode.selectedPCID = isSelected and nil or pc.id
                Rebuild()
            end
            row.DoRightClick = function()
                local menu = DermaMenu()
                menu:AddOption(pc.active and PC_STR.deactivate or PC_STR.activate, function()
                    RunConsoleCommand(PREFIX .. "edit_pc", tostring(pc.id), "active", pc.active and "0" or "1")
                    timer.Simple(0.1, Rebuild)
                end)
                menu:AddOption(PC_STR.delete, function()
                    RunConsoleCommand(PREFIX .. "remove_pc", tostring(pc.id))
                    PB_PCMode.selectedPCID = nil
                    timer.Simple(0.1, Rebuild)
                end):SetIcon("icon16/cross.png")
                menu:Open()
            end
        end


        if PB_PCMode.selectedPCID then
            local pc = graph.pconstraints[PB_PCMode.selectedPCID]
            if pc then
                local dof = PB.GetPCDOF(pc)
                local pcIDStr = tostring(pc.id)

                PB.SectionHeader(scroll, "Edit PC#" .. pc.id .. (pc.flipped and PC_STR.flippedTag or ""))
                PB.InfoLabel(scroll, dof.desc)

                for _, param in ipairs(PB.GetPCEditParams(pc)) do
                    PB.NumberRow(scroll, param.label .. ":", pc[param.key] or 0, function(val)
                        RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, param.key, val)
                        timer.Simple(0.1, Rebuild)
                    end)
                end

                if pc.mode ~= "mirror" then
                    PB.ActionButton(scroll, pc.flipped and (UI_STR.unflipSolution) or (UI_STR.flipSolution), COL.warning, function()
                        RunConsoleCommand(PREFIX .. "flip_pc", pcIDStr)
                        timer.Simple(0.1, Rebuild)
                    end)
                end

                if pc.mode == "geometric" and pc.parentFeature and pc.childFeature and pc.parentFeature.type == "edge" and pc.childFeature.type == "edge" then
                    PB.SectionHeader(scroll, "Edge Branch State")
                    PB.InfoLabel(scroll, "Parent ref face: " .. PB.GetPCEdgeBranchFaceLabel(pc, "parent"))
                    PB.ActionButton(scroll, UI_STR.cycleParentRefFace, COL.info, function()
                        local nextSide = (math.floor(tonumber(pc.branchParentSide) or 1) % 2) + 1
                        RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "branchParentSide", tostring(nextSide))
                        timer.Simple(0.1, Rebuild)
                    end)
                    PB.InfoLabel(scroll, "Child ref face: " .. PB.GetPCEdgeBranchFaceLabel(pc, "child"))
                    PB.ActionButton(scroll, UI_STR.cycleChildRefFace, COL.info, function()
                        local nextSide = (math.floor(tonumber(pc.branchChildSide) or 1) % 2) + 1
                        RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "branchChildSide", tostring(nextSide))
                        timer.Simple(0.1, Rebuild)
                    end)
                end

                if pc.mode == "mirror" then
                    PB.SectionHeader(scroll, PROP_STR.mirror)
                    local sourceNode = graph.nodes[pc.parentNodeID]
                    local mirrorNode = pc.mirrorNodeID and graph.nodes[pc.mirrorNodeID] or nil
                    local childNode = graph.nodes[pc.childNodeID]
                    PB.InfoLabel(scroll, PROP_STR.source .. (sourceNode and (sourceNode.label .. " (" .. PROP_STR.idPrefix .. sourceNode.id .. ")") or GC_STR.unknownNode)
                        .. PROP_STR.mirrorProp .. (mirrorNode and (mirrorNode.label .. " (" .. PROP_STR.idPrefix .. mirrorNode.id .. ")") or GC_STR.unknownNode)
                        .. PROP_STR.mirroredNode .. (childNode and (childNode.label .. " (" .. PROP_STR.idPrefix .. childNode.id .. ")") or GC_STR.unknownNode))

                    local mirrorGCCheck = vgui.Create("DCheckBoxLabel", scroll)
                    mirrorGCCheck:Dock(TOP)
                    mirrorGCCheck:DockMargin(8, 3, 8, 0)
                    mirrorGCCheck:SetText(PROP_STR.mirrorGConstraints or "Mirror GMod constraints")
                    mirrorGCCheck:SetTextColor(COL.text or color_white)
                    mirrorGCCheck:SetValue(pc.mirrorGConstraints and 1 or 0)
                    mirrorGCCheck.OnChange = function(_, val)
                        RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "mirrorGConstraints", val and "1" or "0")
                        timer.Simple(0.1, Rebuild)
                    end

                    PB.InfoLabel(scroll, PROP_STR.mirrorGConstraintsHelp or "Also copies compatible GMod constraint definitions to the mirrored node.")

                    local axisCombo = vgui.Create("DComboBox", scroll)
                    axisCombo:Dock(TOP); axisCombo:DockMargin(4, 2, 4, 2)
                    axisCombo:SetValue(PROP_STR.mirrorPlane .. string.upper(tostring(pc.mirrorAxis or pc.mirrorFace or "x")))
                    axisCombo:AddChoice(PROP_STR.xPlane, "x")
                    axisCombo:AddChoice(PROP_STR.yPlane, "y")
                    axisCombo:AddChoice(PROP_STR.zPlane, "z")
                    axisCombo.OnSelect = function(_, _, _, data)
                        RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "mirrorAxis", data)
                        timer.Simple(0.1, Rebuild)
                    end
                elseif pc.mode == "symmetry" then
                    PB.SectionHeader(scroll, "Mirror Plane")
                    PB.NumberRow(scroll, PROP_STR.mirrorNodeID, pc.mirrorNodeID or 0, function(val)
                        RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "mirrorNodeID", val)
                        timer.Simple(0.1, Rebuild)
                    end)
                    local mirrorCombo = vgui.Create("DComboBox", scroll)
                    mirrorCombo:Dock(TOP); mirrorCombo:DockMargin(4, 2, 4, 2)
                    mirrorCombo:SetValue(pc.mirrorFace or "+x")
                    for _, face in ipairs(PB.FACES) do mirrorCombo:AddChoice(PB.FACE_NAMES[face], face) end
                    mirrorCombo.OnSelect = function(_, _, _, data)
                        RunConsoleCommand(PREFIX .. "edit_pc", pcIDStr, "mirrorFace", data)
                        timer.Simple(0.1, Rebuild)
                    end
                end

                PB.ActionButton(scroll, PC_STR.deletePrefix .. pc.id, COL.error, function()
                    RunConsoleCommand(PREFIX .. "remove_pc", pcIDStr)
                    PB_PCMode.selectedPCID = nil
                    timer.Simple(0.1, Rebuild)
                end)
            end
        end
    end

    Rebuild()
    panel.Think = function()
        if PB_Overlay and PB_Overlay._needsRefresh then Rebuild() end
    end
end





PB_GCNewType = PB_GCNewType or "weld"
PB_GCEditDraft = PB_GCEditDraft or nil
PB_GCFieldPreviewDraft = PB_GCFieldPreviewDraft or nil

local function PB_GCNodeLabel(graph, nodeID)
    local node = graph and graph.nodes and graph.nodes[tonumber(nodeID) or 0]
    if not node then return GC_STR.nodePrefix .. tostring(nodeID or GC_STR.unknownNode) end
    return tostring(node.label or ("Node " .. tostring(node.id)))
end

local function PB_GCSend(messageName, payload)
    net.Start(PREFIX .. messageName)
    net.WriteString(util.TableToJSON(payload or {}) or "{}")
    net.SendToServer()
end

local function PB_GCCloneClientData(gc)
    if not gc then return nil end
    return {
        id = gc.id,
        name = gc.name or "",
        type = gc.type or gc.gcType or "weld",
        enabled = gc.enabled ~= false,
        debugVisible = gc.debugVisible ~= false,
        updateMode = gc.updateMode or "live",
        nodeA = gc.nodeA,
        nodeB = gc.nodeB,
        attachA = PB.GCDeserializeAttachment(gc.attachA),
        attachB = PB.GCDeserializeAttachment(gc.attachB),
        params = PB.GCMergeParams(gc.type or gc.gcType or "weld", table.Copy(gc.params or {})),
    }
end

function PB_HandleGCAttachmentPicked(data)
    if not data or not data.attach then return end
    data.attach = PB.GCRoundGeneratedAttachment and PB.GCRoundGeneratedAttachment(data.attach) or data.attach
    local side = data.side == "B" and "B" or "A"
    local gcid = tonumber(data.gcid) or 0

    if gcid > 0 then
        local graph = PB.GetGraph(LocalPlayer())
        if not PB_GCEditDraft or tonumber(PB_GCEditDraft.id) ~= gcid then
            PB_GCEditDraft = PB_GCCloneClientData(graph and graph.gconstraints and graph.gconstraints[gcid])
        end
        if PB_GCEditDraft then
            PB_GCMode.selectedGCID = gcid
            if side == "B" then PB_GCEditDraft.attachB = data.attach else PB_GCEditDraft.attachA = data.attach end
        end
    elseif PB_GCDraft then
        if side == "B" then PB_GCDraft.attachB = data.attach else PB_GCDraft.attachA = data.attach end
    end

    PB_RebuildGConstraintPanel()
end

function PB_RebuildGConstraintPanel()
    if PB_UI and IsValid(PB_UI.gcPanel) then PB_BuildGConstraintTab(PB_UI.gcPanel) end
end

local function makeGCTextRow(parent, labelText, defaultValue)
    local row = vgui.Create("DPanel", parent)
    row:Dock(TOP)
    row:SetTall(24)
    row:DockMargin(4, 1, 4, 0)
    row.Paint = function() end

    local label = vgui.Create("DLabel", row)
    label:Dock(LEFT)
    label:SetWide(105)
    label:SetText(labelText)
    label:SetTextColor(COL.textSecondary)
    label:SetContentAlignment(5)

    local entry = vgui.Create("DTextEntry", row)
    entry:Dock(FILL)
    entry:SetValue(tostring(defaultValue or ""))
    return entry
end

local function makeGCBoolRow(parent, labelText, defaultValue)
    local row = vgui.Create("DPanel", parent)
    row:Dock(TOP)
    row:SetTall(24)
    row:DockMargin(4, 1, 4, 0)
    row.Paint = function() end

    local check = vgui.Create("DCheckBoxLabel", row)
    check:Dock(FILL)
    check:SetText(labelText)
    check:SetTextColor(COL.textSecondary)
    check:SetValue(defaultValue and 1 or 0)
    check:SizeToContents()
    return check
end

local function makeGCNumberEntry(parent, labelText, defaultValue)
    local entry = makeGCTextRow(parent, labelText, defaultValue)
    return entry
end

local function formatGCPickerNumber(value)
    value = tonumber(value) or 0
    if math.abs(value) < 0.005 then return "0" end
    return tostring(math.Round(value, 2))
end

local function readNumEntry(entry, fallback)
    if not IsValid(entry) then return fallback or 0 end
    local v = tonumber(entry:GetValue())
    if v == nil then return fallback or 0 end
    return v
end

local function readStringEntry(entry, fallback)
    if not IsValid(entry) then return fallback or "" end
    return entry:GetValue() or fallback or ""
end

local function buildAttachmentEditor(parent, title, graph, nodeID, att, gcType, side, gcid, onLiveChange)
    att = PB.GCDeserializeAttachment(att) or { localPos = Vector(), localAngle = Angle() }
    local nodeLabel = PB_GCNodeLabel(graph, nodeID)
    PB.SectionHeader(parent, title .. " — " .. nodeLabel)

    local source = vgui.Create("DLabel", parent)
    source:Dock(TOP)
    source:DockMargin(8, 1, 8, 3)
    source:SetTextColor(COL.textMuted)
    source:SetText(GC_STR.currentPrefix .. (PB.GCAttachmentLabel and PB.GCAttachmentLabel(att) or GC_STR.manual))

    local readCurrent = nil
    local pick = vgui.Create("DButton", parent)
    pick:Dock(TOP)
    pick:DockMargin(4, 2, 4, 4)
    pick:SetText(GC_STR.pickAnchorPrefix .. side)
    pick.DoClick = function()
        if PB.GCPickerClient and PB.GCPickerClient.Start then
            PB.GCPickerClient.Start({
                mode = "attach",
                gcType = gcType,
                side = side,
                nodeID = tonumber(nodeID) or 0,
                gcid = tonumber(gcid) or 0,
                previousAttach = (readCurrent and PB.GCSerializeAttachment(readCurrent())) or PB.GCSerializeAttachment(att),
            })
        end
    end

    local pos = att.localPos or Vector()
    local ang = att.localAngle or Angle()
    local entries = {
        x = makeGCNumberEntry(parent, GC_STR.localX, formatGCPickerNumber(pos.x)),
        y = makeGCNumberEntry(parent, GC_STR.localY, formatGCPickerNumber(pos.y)),
        z = makeGCNumberEntry(parent, GC_STR.localZ, formatGCPickerNumber(pos.z)),
        p = makeGCNumberEntry(parent, GC_STR.pitch, formatGCPickerNumber(ang.p)),
        yaw = makeGCNumberEntry(parent, GC_STR.yaw, formatGCPickerNumber(ang.y)),
        r = makeGCNumberEntry(parent, GC_STR.roll, formatGCPickerNumber(ang.r)),
    }

    readCurrent = function()
        return {
            localPos = Vector(
                readNumEntry(entries.x, pos.x),
                readNumEntry(entries.y, pos.y),
                readNumEntry(entries.z, pos.z)
            ),
            localAngle = Angle(
                readNumEntry(entries.p, ang.p),
                readNumEntry(entries.yaw, ang.y),
                readNumEntry(entries.r, ang.r)
            ),
            source = att.source or GC_STR.manual,
            feature = att.feature and table.Copy(att.feature) or nil,
        }
    end

    local function pushLiveChange()
        if not onLiveChange then return end
        local current = readCurrent()
        if PB.GCRoundGeneratedAttachment then
            current = PB.GCRoundGeneratedAttachment(current) or current
        end
        if IsValid(source) then
            source:SetText(GC_STR.currentPrefix .. (PB.GCAttachmentLabel and PB.GCAttachmentLabel(current) or GC_STR.manual))
        end
        onLiveChange(current)
    end

    for _, entry in pairs(entries) do
        entry.OnValueChange = function()
            pushLiveChange()
        end
        entry.OnEnter = function()
            pushLiveChange()
        end
    end

    return readCurrent
end

local function buildParamsEditor(parent, gcType, params)
    PB.SectionHeader(parent, GC_STR.constraintOptions)
    params = PB.GCMergeParams(gcType, params or {})
    local readers = {}

    for _, opt in ipairs(PB.GConstraints.OptionSchema(gcType)) do
        if opt.kind == "bool" then
            local check = makeGCBoolRow(parent, opt.label, tonumber(params[opt.key]) == 1 or params[opt.key] == true)
            readers[opt.key] = function()
                return check:GetChecked() and 1 or 0
            end
        elseif opt.kind == "string" then
            local entry = makeGCTextRow(parent, opt.label, params[opt.key] or "")
            readers[opt.key] = function()
                return readStringEntry(entry, params[opt.key] or "")
            end
        else
            local label = opt.label
            if opt.hint then label = label .. " (" .. opt.hint .. ")" end
            local entry = makeGCNumberEntry(parent, label, params[opt.key] or 0)
            readers[opt.key] = function()
                return readNumEntry(entry, params[opt.key] or 0)
            end
        end
    end

    return function()
        local out = {}
        for key, reader in pairs(readers) do
            out[key] = reader()
        end
        return PB.GCMergeParams(gcType, out)
    end
end

local function buildGCEditor(parent, graph, data, isEdit)
    if not data then return end
    local gcType = data.type or data.gcType or "weld"
    local gcid = isEdit and tonumber(data.id) or 0

    PB.SectionHeader(parent, isEdit and GC_STR.editTitle or GC_STR.createTitle)
    PB.InfoLabel(parent, (PB.GCTypeLabel and PB.GCTypeLabel(gcType) or gcType) .. GC_STR.between .. PB_GCNodeLabel(graph, data.nodeA) .. GC_STR.andText .. PB_GCNodeLabel(graph, data.nodeB))

    local nameEntry = makeGCTextRow(parent, GC_STR.name, data.name or "")
    local enabledCheck = makeGCBoolRow(parent, GC_STR.enabled, data.enabled ~= false)
    local debugCheck = makeGCBoolRow(parent, GC_STR.showAnchors, data.debugVisible ~= false)

    local function pushFieldPreview(side, attachment)
        local preview = PB_GCCloneClientData(data)
        if not preview then return end
        preview.name = readStringEntry(nameEntry, data.name or "")
        preview.enabled = enabledCheck:GetChecked()
        preview.debugVisible = debugCheck:GetChecked()
        preview.type = gcType
        preview.nodeA = tonumber(data.nodeA) or 0
        preview.nodeB = tonumber(data.nodeB) or 0
        if side == "B" then
            preview.attachB = attachment
        else
            preview.attachA = attachment
        end
        PB_GCFieldPreviewDraft = preview
    end

    local readA = buildAttachmentEditor(parent, GC_STR.anchorA, graph, data.nodeA, data.attachA, gcType, "A", gcid, function(attachment)
        pushFieldPreview("A", attachment)
    end)
    local readB = buildAttachmentEditor(parent, GC_STR.anchorB, graph, data.nodeB, data.attachB, gcType, "B", gcid, function(attachment)
        pushFieldPreview("B", attachment)
    end)
    local readParams = buildParamsEditor(parent, gcType, data.params or {})

    local function payload()
        return {
            id = gcid,
            type = gcType,
            name = readStringEntry(nameEntry, data.name or ""),
            enabled = enabledCheck:GetChecked(),
            debugVisible = debugCheck:GetChecked(),
            nodeA = tonumber(data.nodeA) or 0,
            nodeB = tonumber(data.nodeB) or 0,
            attachA = PB.GCSerializeAttachment(readA()),
            attachB = PB.GCSerializeAttachment(readB()),
            params = readParams(),
            updateMode = "live",
        }
    end

    if isEdit then
        PB.ActionButton(parent, GC_STR.applyChanges, COL.actionLinear or COL.selected, function()
            local pl = payload()
            PB_GCEditDraft = PB_GCCloneClientData(pl)
            PB_GCFieldPreviewDraft = nil
            PB_GCSend("gc_edit", pl)
        end)
        PB.ActionButton(parent, GC_STR.deleteConstraint, COL.error, function()
            Derma_Query(GC_STR.deleteConfirmTitlePrefix .. tostring(gcid) .. GC_STR.deleteConfirmTitleSuffix, GC_STR.confirm, GC_STR.delete, function()
                PB_GCSend("gc_delete", { id = gcid })
                PB_GCEditDraft = nil
                PB_GCFieldPreviewDraft = nil
                if PB_GCMode then PB_GCMode.selectedGCID = nil end
            end, GC_STR.cancel, function() end)
        end)
    else
        PB.ActionButton(parent, GC_STR.createConstraint, COL.actionLinear or COL.selected, function()
            local pl = payload()
            PB_GCSend("gc_create", pl)
            PB_GCDraft = nil
            PB_GCFieldPreviewDraft = nil
            if PB_GCMode then PB_GCMode.selectedGCID = nil end
            timer.Simple(0.08, PB_RebuildGConstraintPanel)
        end)
        PB.ActionButton(parent, GC_STR.cancelDraft, COL.error, function()
            PB_GCDraft = nil
            PB_GCFieldPreviewDraft = nil
            PB_RebuildGConstraintPanel()
        end)
    end
end

function PB_BuildGConstraintTab(panel)
    if not IsValid(panel) then return end
    panel:Clear()

    local graph = PB.GetGraph(LocalPlayer())
    if not graph then return end

    local toolbar = vgui.Create("DPanel", panel)
    toolbar:Dock(TOP)
    toolbar:SetTall(30)
    toolbar.Paint = function(_, w, h) draw.RoundedBox(0, 0, 0, w, h, COL.panelToolbar) end

    local combo = vgui.Create("DComboBox", toolbar)
    combo:Dock(LEFT)
    combo:DockMargin(4, 4, 2, 4)
    combo:SetWide(150)
    combo:SetValue(PB.GCTypeLabel(PB_GCNewType))
    for _, typ in ipairs(PB.GCONSTRAINT_TYPES or {}) do
        combo:AddChoice(PB.GCTypeLabel(typ), typ, typ == PB_GCNewType)
    end
    combo.OnSelect = function(_, _, _, data)
        PB_GCNewType = data or "weld"
    end

    local addButton = vgui.Create("DButton", toolbar)
    addButton:Dock(FILL)
    addButton:DockMargin(2, 4, 4, 4)
    addButton:SetText(GC_STR.addNewConstraint)
    addButton.DoClick = function()
        local activeProjectID = PB.ProjectCache and PB.ProjectCache.active or nil
        if not activeProjectID or not (PB.ProjectCache and PB.ProjectCache.projects and PB.ProjectCache.projects[activeProjectID]) then
            if chat and chat.AddText then
                chat.AddText(COL.error or color_white, CFG.ChatPrefix .. " " .. (GC_STR.noActiveProject or ((STR.Chat or {}).createOrSelectProject)))
            end
            return
        end

        if PB.GCPickerClient and PB.GCPickerClient.Start then
            PB_GCDraft = nil
            PB_GCEditDraft = nil
            PB_GCFieldPreviewDraft = nil
            if PB_GCMode then PB_GCMode.selectedGCID = nil end
            PB.GCPickerClient.Start({ mode = "nodes", gcType = PB_GCNewType or "weld" })
        end
    end

    local scroll = vgui.Create("DScrollPanel", panel)
    scroll:Dock(FILL)
    scroll:DockMargin(2, 2, 2, 2)
    panel.gcScroll = scroll

    if PB_GCDraft then
        buildGCEditor(scroll, graph, PB_GCDraft, false)
    end

    PB.SectionHeader(scroll, GC_STR.existingTitle)
    local list = PB.GetGConstraintList and PB.GetGConstraintList(graph) or {}
    if #list == 0 then
        PB.InfoLabel(scroll, GC_STR.emptyHelp)
    end

    for _, item in ipairs(list) do
        local gc = item.def
        local row = vgui.Create("DButton", scroll)
        row:Dock(TOP)
        row:DockMargin(4, 2, 4, 0)
        row:SetTall(28)
        row:SetText(PB.GConstraintSummary and PB.GConstraintSummary(gc, graph) or ("GC#" .. tostring(gc.id)))
        row:SetTextColor((PB_GCMode and PB_GCMode.selectedGCID == gc.id) and (COL.gconstraintListSelectedText or COL.selected or color_white) or (COL.gconstraintListText or COL.textSecondary or color_white))
        row.DoClick = function()
            PB_GCMode.selectedGCID = gc.id
            PB_GCEditDraft = PB_GCCloneClientData(gc)
            PB_GCFieldPreviewDraft = nil
            PB_RebuildGConstraintPanel()
        end
    end

    if PB_GCMode and PB_GCMode.selectedGCID then
        local selected = graph.gconstraints and graph.gconstraints[PB_GCMode.selectedGCID]
        if selected then
            if not PB_GCEditDraft or tonumber(PB_GCEditDraft.id) ~= tonumber(selected.id) then
                PB_GCEditDraft = PB_GCCloneClientData(selected)
            end
            buildGCEditor(scroll, graph, PB_GCEditDraft, true)
        end
    end

    panel.Think = function()
        if PB_GCNeedsRebuild then
            PB_GCNeedsRebuild = false
            PB_BuildGConstraintTab(panel)
        end
    end
end










if SERVER then return end






function PB_BuildPatternProps(panel, node, nodeIDStr)
    PB.HeaderLabel(panel, node.label .. PATTERN_STR.patternSuffix, COL.patternHeader)
    local params = node.patternParams or {}
    local patType = node.patternType or GC_STR.unknownNode

    PB.SectionHeader(panel, PATTERN_STR.patternPrefix .. string.upper(patType))

    if patType == "linear" then
        PB.NumberRow(panel, "Count:", params.count or 3, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "count", v) end)
        PB.NumberRow(panel, "Spacing:", params.spacing or 50, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "spacing", v) end)
    elseif patType == "circular" then
        PB.NumberRow(panel, "Count:", params.count or 6, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "count", v) end)
        PB.NumberRow(panel, "Radius:", params.radius or 100, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "radius", v) end)
    elseif patType == "grid" then
        PB.NumberRow(panel, "Cols:", params.cols or 3, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "cols", v) end)
        PB.NumberRow(panel, "Rows:", params.rows or 3, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "rows", v) end)
        PB.NumberRow(panel, PATTERN_STR.spacingX, params.spacingX or 50, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "spacingX", v) end)
        PB.NumberRow(panel, PATTERN_STR.spacingY, params.spacingY or 50, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "spacingY", v) end)
    elseif patType == "helix" then
        PB.NumberRow(panel, "Count:", params.count or 12, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "count", v) end)
        PB.NumberRow(panel, "Radius:", params.radius or 80, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "radius", v) end)
        PB.NumberRow(panel, "Rise:", params.rise or 15, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "rise", v) end)
        PB.NumberRow(panel, "Turns:", params.turns or 1, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "turns", v) end)
    elseif patType == "arc" then
        PB.NumberRow(panel, "Count:", params.count or 8, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "count", v) end)
        PB.NumberRow(panel, "Radius:", params.radius or 100, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "radius", v) end)
        PB.NumberRow(panel, "Arc:", params.arcDeg or 180, function(v) RunConsoleCommand(PREFIX .. "edit_pattern", nodeIDStr, "arcDeg", v) end)
    end

    PB.SectionHeader(panel, "Pattern")
    PB.InfoLabel(panel, PATTERN_STR.legacyRemoved)
    PB.InfoLabel(panel, PATTERN_STR.itemsPrefix .. #(node.patternEntities or {}))
end





function PB_BuildVars(panel)
    panel:Clear()
    local graph = PB.GetGraph(LocalPlayer())
    local meta = graph.variableMeta or {}

    PB.SectionHeader(panel, "Variables")


    local varNames = {}
    for name in pairs(graph.variables) do table.insert(varNames, name) end
    table.sort(varNames)

    for _, name in ipairs(varNames) do
        local value = graph.variables[name]
        local m = meta[name] or {}
        local hasRange = m.min and m.max


        local headerRow = vgui.Create("DPanel", panel)
        headerRow:Dock(TOP); headerRow:SetTall(24); headerRow:DockMargin(4, 4, 4, 0)
        headerRow.Paint = function(_, w, h) draw.RoundedBox(2, 0, 0, w, h, COL.variableHeaderBackground) end

        local nameLabel = vgui.Create("DLabel", headerRow)
        nameLabel:Dock(LEFT); nameLabel:SetWide(80)
        nameLabel:SetText("$" .. name); nameLabel:SetTextColor(COL.accent)
        nameLabel:SetContentAlignment(5)

        local deleteBtn = vgui.Create("DButton", headerRow)
        deleteBtn:Dock(RIGHT); deleteBtn:SetWide(22); deleteBtn:SetText("X")
        deleteBtn:SetTextColor(COL.error)
        deleteBtn.DoClick = function()
            RunConsoleCommand(PREFIX .. "del_variable", name)
            timer.Simple(0.1, function() if IsValid(panel) then PB_BuildVars(panel) end end)
        end

        local valueEntry = vgui.Create("DTextEntry", headerRow)
        valueEntry:Dock(FILL); valueEntry:SetValue(tostring(value))
        valueEntry.OnEnter = function(self)
            RunConsoleCommand(PREFIX .. "set_variable", name, self:GetValue())
            timer.Simple(0.1, function() if IsValid(panel) then PB_BuildVars(panel) end end)
        end


        if hasRange then
            local slider = vgui.Create("DNumSlider", panel)
            slider:Dock(TOP); slider:SetTall(28); slider:DockMargin(8, 0, 4, 0)
            slider:SetText("")
            slider:SetMin(m.min); slider:SetMax(m.max)
            slider:SetDecimals(m.step and (m.step >= 1 and 0 or 2) or 2)
            slider:SetValue(value)
            slider.OnValueChanged = function(_, val)
                if m.step and m.step > 0 then
                    val = math.Round(val / m.step) * m.step
                end
                RunConsoleCommand(PREFIX .. "set_variable", name, tostring(math.Round(val, 4)))
            end
        end


        local cfgRow = vgui.Create("DPanel", panel)
        cfgRow:Dock(TOP); cfgRow:SetTall(22); cfgRow:DockMargin(8, 0, 4, 0)
        cfgRow.Paint = function() end

        local rangeLabel = vgui.Create("DLabel", cfgRow)
        rangeLabel:Dock(LEFT); rangeLabel:SetWide(35); rangeLabel:SetText(UI_STR.range)
        rangeLabel:SetTextColor(COL.textDim); rangeLabel:SetContentAlignment(5)

        local minEntry = vgui.Create("DTextEntry", cfgRow)
        minEntry:Dock(LEFT); minEntry:SetWide(50); minEntry:SetPlaceholderText("min")
        minEntry:SetValue(m.min and tostring(m.min) or "")
        minEntry.OnEnter = function(self)
            RunConsoleCommand(PREFIX .. "set_variable_meta", name, "min", self:GetValue())
            timer.Simple(0.1, function() if IsValid(panel) then PB_BuildVars(panel) end end)
        end

        local toLabel = vgui.Create("DLabel", cfgRow)
        toLabel:Dock(LEFT); toLabel:SetWide(15); toLabel:SetText(UI_STR.rangeTo)
        toLabel:SetTextColor(COL.textDim); toLabel:SetContentAlignment(5)

        local maxEntry = vgui.Create("DTextEntry", cfgRow)
        maxEntry:Dock(LEFT); maxEntry:SetWide(50); maxEntry:SetPlaceholderText("max")
        maxEntry:SetValue(m.max and tostring(m.max) or "")
        maxEntry.OnEnter = function(self)
            RunConsoleCommand(PREFIX .. "set_variable_meta", name, "max", self:GetValue())
            timer.Simple(0.1, function() if IsValid(panel) then PB_BuildVars(panel) end end)
        end

        local stepLabel = vgui.Create("DLabel", cfgRow)
        stepLabel:Dock(LEFT); stepLabel:SetWide(28); stepLabel:SetText(UI_STR.step)
        stepLabel:SetTextColor(COL.textDim); stepLabel:SetContentAlignment(5)

        local stepEntry = vgui.Create("DTextEntry", cfgRow)
        stepEntry:Dock(LEFT); stepEntry:SetWide(40); stepEntry:SetPlaceholderText("1")
        stepEntry:SetValue(m.step and tostring(m.step) or "")
        stepEntry.OnEnter = function(self)
            RunConsoleCommand(PREFIX .. "set_variable_meta", name, "step", self:GetValue())
            timer.Simple(0.1, function() if IsValid(panel) then PB_BuildVars(panel) end end)
        end
    end


    PB.SectionHeader(panel, "Add Variable")
    local addRow = vgui.Create("DPanel", panel)
    addRow:Dock(TOP); addRow:SetTall(26); addRow:DockMargin(4, 2, 4, 0)
    addRow.Paint = function() end

    local nameEntry = vgui.Create("DTextEntry", addRow)
    nameEntry:Dock(LEFT); nameEntry:SetWide(100); nameEntry:SetPlaceholderText("name")

    local valueEntry = vgui.Create("DTextEntry", addRow)
    valueEntry:Dock(FILL); valueEntry:SetPlaceholderText("value")

    local addBtn = vgui.Create("DButton", addRow)
    addBtn:Dock(RIGHT); addBtn:SetWide(40); addBtn:SetText(UI_STR.add)
    addBtn.DoClick = function()
        if nameEntry:GetValue() ~= "" and valueEntry:GetValue() ~= "" then
            RunConsoleCommand(PREFIX .. "set_variable", nameEntry:GetValue(), valueEntry:GetValue())
            timer.Simple(0.1, function() if IsValid(panel) then PB_BuildVars(panel) end end)
        end
    end
end





function PB_BuildPatterns(panel)
    panel:Clear()
    local function getSelectedID()
        return tostring((PB_Overlay and PB_Overlay.selectedNodeID) or 0)
    end

    PB.SectionHeader(panel, "Options")
    local copyCheck = vgui.Create("DCheckBoxLabel", panel)
    copyCheck:Dock(TOP); copyCheck:DockMargin(8, 8, 4, 4)
    copyCheck:SetText(UI_STR.applyConstraint); copyCheck:SetTextColor(COL.textSecondary)
    copyCheck:SetChecked(true)
    local function getCopyFlag() return copyCheck:GetChecked() and "1" or "0" end

    local constCombo = vgui.Create("DComboBox", panel)
    constCombo:Dock(TOP); constCombo:DockMargin(4, 2, 4, 4); constCombo:SetValue("weld")
    for _, cType in ipairs(PB.CONSTRAINT_TYPES) do constCombo:AddChoice(cType) end
    local function getConstType() local _, data = constCombo:GetSelected(); return data or "weld" end

    PB.SectionHeader(panel, "Linear")
    local linCount = PB.NumberRow(panel, "Count:", 3)
    local linSpacing = PB.NumberRow(panel, "Spacing:", 50)
    local linDir = vgui.Create("DComboBox", panel)
    linDir:Dock(TOP); linDir:DockMargin(4, 2, 4, 2); linDir:SetValue("Forward (X)")
    linDir:AddChoice("Forward (X)", "x"); linDir:AddChoice("Right (Y)", "y"); linDir:AddChoice("Up (Z)", "z")
    PB.ActionButton(panel, UI_STR.createLinear, COL.actionLinear, function()
        local _, dir = linDir:GetSelected()
        RunConsoleCommand(PREFIX .. "create_pattern", getSelectedID(), "linear", dir or "x",
            linCount:GetValue(), linSpacing:GetValue(), "0", "0", getCopyFlag(), getConstType())
    end)

    PB.SectionHeader(panel, "Circular")
    local cirCount = PB.NumberRow(panel, "Count:", 6)
    local cirRadius = PB.NumberRow(panel, "Radius:", 100)
    local cirAxis = vgui.Create("DComboBox", panel)
    cirAxis:Dock(TOP); cirAxis:DockMargin(4, 2, 4, 2); cirAxis:SetValue("Z")
    cirAxis:AddChoice("Z", "z"); cirAxis:AddChoice("Y", "y"); cirAxis:AddChoice("X", "x")
    PB.ActionButton(panel, UI_STR.createCircular, COL.actionCircular, function()
        local _, ax = cirAxis:GetSelected()
        RunConsoleCommand(PREFIX .. "create_pattern", getSelectedID(), "circular", ax or "z",
            cirCount:GetValue(), cirRadius:GetValue(), "0", "0", getCopyFlag(), getConstType())
    end)

    PB.SectionHeader(panel, "Grid")
    local gridCols = PB.NumberRow(panel, "Cols:", 3)
    local gridRows = PB.NumberRow(panel, "Rows:", 3)
    local gridSpX = PB.NumberRow(panel, PATTERN_STR.spacingX, 50)
    local gridSpY = PB.NumberRow(panel, PATTERN_STR.spacingY, 50)
    PB.ActionButton(panel, UI_STR.createGrid, COL.actionGrid, function()
        RunConsoleCommand(PREFIX .. "create_pattern", getSelectedID(), "grid", "z",
            gridCols:GetValue(), gridRows:GetValue(), gridSpX:GetValue(), gridSpY:GetValue(), getCopyFlag(), getConstType())
    end)

    PB.SectionHeader(panel, "Helix")
    local helCount = PB.NumberRow(panel, "Count:", 12)
    local helRadius = PB.NumberRow(panel, "Radius:", 80)
    local helRise = PB.NumberRow(panel, "Rise:", 15)
    local helTurns = PB.NumberRow(panel, "Turns:", 1)
    PB.ActionButton(panel, UI_STR.createHelix, COL.actionHelix, function()
        RunConsoleCommand(PREFIX .. "create_pattern", getSelectedID(), "helix", "z",
            helCount:GetValue(), helRadius:GetValue(), helRise:GetValue(), helTurns:GetValue(), getCopyFlag(), getConstType())
    end)

    PB.SectionHeader(panel, "Arc")
    local arcCount = PB.NumberRow(panel, "Count:", 8)
    local arcRadius = PB.NumberRow(panel, "Radius:", 100)
    local arcDeg = PB.NumberRow(panel, "Arc:", 180)
    local arcAxis = vgui.Create("DComboBox", panel)
    arcAxis:Dock(TOP); arcAxis:DockMargin(4, 2, 4, 2); arcAxis:SetValue("Z")
    arcAxis:AddChoice("Z", "z"); arcAxis:AddChoice("Y", "y"); arcAxis:AddChoice("X", "x")
    PB.ActionButton(panel, UI_STR.createArc, COL.accent, function()
        local _, ax = arcAxis:GetSelected()
        RunConsoleCommand(PREFIX .. "create_pattern", getSelectedID(), "arc", ax or "z",
            arcCount:GetValue(), arcRadius:GetValue(), arcDeg:GetValue(), "0", getCopyFlag(), getConstType())
    end)
end





local PB_SETTINGS_DEFAULTS = {
    [PREFIX .. "overlay_enabled"] = "1",
    [PREFIX .. "overlay_labels"] = "1",
    [PREFIX .. "overlay_offsets"] = "1",
    [PREFIX .. "overlay_constraints"] = "1",
    [PREFIX .. "overlay_axes"] = "0",
    [PREFIX .. "overlay_dimensions"] = "1",
    [PREFIX .. "overlay_maxdist"] = "4000",
    [PREFIX .. "snap_grid"] = "1",
    ["parametric_builder_pick_corner_pct"] = "0.15",
    ["parametric_builder_pick_edge_pct"] = "0.20",
    ["parametric_builder_pick_min_unit"] = "0",
}

local function settingCVar(name)
    return GetConVar(name)
end

local function settingValue(name, fallback)
    local cv = settingCVar(name)
    if cv then return cv:GetString() end
    return tostring(fallback or "")
end

local function setSettingValue(name, value, syncPicker)
    RunConsoleCommand(name, tostring(value))
    if syncPicker and PB.SendPickerPrefsToServer then
        timer.Simple(0, function()
            if PB.SendPickerPrefsToServer then PB.SendPickerPrefsToServer() end
        end)
    end
end

local function settingsBool(parent, labelText, convarName, desc)
    local check = vgui.Create("DCheckBoxLabel", parent)
    check:Dock(TOP); check:DockMargin(8, 3, 8, 1)
    check:SetText(labelText)
    check:SetTextColor(COL.checkboxText)
    local cv = settingCVar(convarName)
    check:SetValue(cv and cv:GetBool() and 1 or 0)
    check:SizeToContents()
    check.OnChange = function(_, val) setSettingValue(convarName, val and "1" or "0") end
    if desc and desc ~= "" then PB.InfoLabel(parent, desc) end
    return check
end

local function settingsNumber(parent, labelText, convarName, fallback, desc, syncPicker)
    local row = vgui.Create("DPanel", parent)
    row:Dock(TOP); row:SetTall(24); row:DockMargin(4, 2, 4, 0)
    row.Paint = function() end

    local lbl = vgui.Create("DLabel", row)
    lbl:Dock(LEFT); lbl:SetWide(135); lbl:SetText(labelText)
    lbl:SetTextColor(COL.textSecondary); lbl:SetContentAlignment(5)

    local entry = vgui.Create("DTextEntry", row)
    entry:Dock(FILL); entry:SetValue(settingValue(convarName, fallback))
    entry.OnEnter = function(self) setSettingValue(convarName, self:GetValue(), syncPicker) end
    entry.OnLoseFocus = function(self) setSettingValue(convarName, self:GetValue(), syncPicker) end
    if desc and desc ~= "" then PB.InfoLabel(parent, desc) end
    return entry
end

local function settingsSlider(parent, labelText, convarName, minVal, maxVal, decimals, desc, syncPicker)
    local slider = vgui.Create("DNumSlider", parent)
    slider:Dock(TOP); slider:SetTall(32); slider:DockMargin(6, 2, 6, 0)
    slider:SetText(labelText)
    slider:SetMin(minVal); slider:SetMax(maxVal)
    slider:SetDecimals(decimals or 0)
    local cv = settingCVar(convarName)
    slider:SetValue(cv and cv:GetFloat() or tonumber(PB_SETTINGS_DEFAULTS[convarName] or minVal) or minVal)
    slider.OnValueChanged = function(_, val)
        local rounded = decimals and math.Round(val, decimals) or math.Round(val)
        setSettingValue(convarName, rounded, syncPicker)
    end
    if desc and desc ~= "" then PB.InfoLabel(parent, desc) end
    return slider
end

local function settingsPreset(parent)
    PB.HeaderLabel(parent, SETTINGS_STR.overlayPreset, COL.sectionHeaderText)
    local combo = vgui.Create("DComboBox", parent)
    combo:Dock(TOP); combo:DockMargin(6, 2, 6, 4)
    combo:SetValue(SETTINGS_STR.choosePreset)
    combo:AddChoice(SETTINGS_STR.presetFull, "full")
    combo:AddChoice(SETTINGS_STR.presetNormal, "normal")
    combo:AddChoice(SETTINGS_STR.presetCleanDetailed, "clean")
    combo:AddChoice(SETTINGS_STR.presetOffDetailed, "off")
    combo.OnSelect = function(_, _, _, data)
        if data == "full" then
            setSettingValue(PREFIX .. "overlay_enabled", "1")
            setSettingValue(PREFIX .. "overlay_labels", "1")
            setSettingValue(PREFIX .. "overlay_offsets", "1")
            setSettingValue(PREFIX .. "overlay_constraints", "1")
            setSettingValue(PREFIX .. "overlay_axes", "0")
            setSettingValue(PREFIX .. "overlay_dimensions", "1")
        elseif data == "normal" then
            setSettingValue(PREFIX .. "overlay_enabled", "1")
            setSettingValue(PREFIX .. "overlay_labels", "1")
            setSettingValue(PREFIX .. "overlay_offsets", "0")
            setSettingValue(PREFIX .. "overlay_constraints", "1")
            setSettingValue(PREFIX .. "overlay_axes", "0")
            setSettingValue(PREFIX .. "overlay_dimensions", "1")
        elseif data == "clean" then
            setSettingValue(PREFIX .. "overlay_enabled", "1")
            setSettingValue(PREFIX .. "overlay_labels", "0")
            setSettingValue(PREFIX .. "overlay_offsets", "0")
            setSettingValue(PREFIX .. "overlay_constraints", "1")
            setSettingValue(PREFIX .. "overlay_axes", "0")
            setSettingValue(PREFIX .. "overlay_dimensions", "0")
        elseif data == "off" then
            setSettingValue(PREFIX .. "overlay_enabled", "0")
        end
        timer.Simple(0.05, function() if IsValid(parent) then PB_BuildSettings(parent) end end)
    end
    PB.InfoLabel(parent, SETTINGS_STR.overlayPresetHelp)
end

function PB_BuildSettings(panel)
    panel:Clear()

    PB.SectionHeader(panel, SETTINGS_STR.settingsTitle)
    PB.InfoLabel(panel, SETTINGS_STR.settingsHelp)

    settingsPreset(panel)

    PB.SectionHeader(panel, SETTINGS_STR.overlay)
    settingsBool(panel, SETTINGS_STR.enable3DOverlay, PREFIX .. "overlay_enabled")
    settingsBool(panel, SETTINGS_STR.showNodeLabels, PREFIX .. "overlay_labels")
    settingsBool(panel, SETTINGS_STR.showConstraintLinks, PREFIX .. "overlay_constraints")
    settingsBool(panel, SETTINGS_STR.showDimensions, PREFIX .. "overlay_dimensions")
    settingsBool(panel, SETTINGS_STR.showLocalOffsets, PREFIX .. "overlay_offsets")
    settingsBool(panel, SETTINGS_STR.showLocalAxes, PREFIX .. "overlay_axes")
    settingsSlider(panel, SETTINGS_STR.overlayDistance, PREFIX .. "overlay_maxdist", 500, 12000, 0, SETTINGS_STR.overlayDistanceHelp)

    PB.SectionHeader(panel, SETTINGS_STR.editing)
    settingsNumber(panel, SETTINGS_STR.nudgeStep, PREFIX .. "snap_grid", "1", SETTINGS_STR.nudgeHelp)

    PB.SectionHeader(panel, SETTINGS_STR.picking)
    settingsSlider(panel, SETTINGS_STR.cornerZone, "parametric_builder_pick_corner_pct", 0, 0.45, 2, SETTINGS_STR.cornerZoneHelp, true)
    settingsSlider(panel, SETTINGS_STR.edgeZone, "parametric_builder_pick_edge_pct", 0, 0.45, 2, SETTINGS_STR.edgeZoneHelp, true)
    settingsNumber(panel, SETTINGS_STR.minimumZone, "parametric_builder_pick_min_unit", "0", SETTINGS_STR.minimumZoneHelp, true)

    PB.SectionHeader(panel, SETTINGS_STR.maintenance)

    local resetLayoutBtn = vgui.Create("DButton", panel)
    resetLayoutBtn:Dock(TOP); resetLayoutBtn:DockMargin(8, 4, 8, 4)
    resetLayoutBtn:SetText(((STR.Tool or {}).resetPanelLayout))
    resetLayoutBtn.DoClick = function()
        RunConsoleCommand(PREFIX .. "reset_panel_layout")
        notification.AddLegacy(STR.ResetLayoutNotification, NOTIFY_GENERIC, 3)
    end

    local resetBtn = vgui.Create("DButton", panel)
    resetBtn:Dock(TOP); resetBtn:DockMargin(8, 4, 8, 4)
    resetBtn:SetText(SETTINGS_STR.resetDefaults)
    resetBtn:SetTextColor(COL.error or COL.gcError)
    resetBtn.DoClick = function()
        Derma_Query(SETTINGS_STR.resetConfirmTitle, SETTINGS_STR.maintenance,
            SETTINGS_STR.resetConfirmYes, function()
                for name, value in pairs(PB_SETTINGS_DEFAULTS) do
                    RunConsoleCommand(name, value)
                end
                if PB.SendPickerPrefsToServer then
                    timer.Simple(0, function() if PB.SendPickerPrefsToServer then PB.SendPickerPrefsToServer() end end)
                end
                timer.Simple(0.05, function() if IsValid(panel) then PB_BuildSettings(panel) end end)
            end,
            SETTINGS_STR.resetConfirmNo, function() end)
    end
end













if SERVER then return end

PB = PB or {}
PB.UI = PB.UI or {}

PB_TreeContainer = PB_TreeContainer or nil

function PB_RequestTreeRefresh()
    if IsValid(PB_UI and PB_UI.projectPanel) and PB_RefreshProjects then
        PB_RefreshProjects(PB_UI.projectPanel)
    end
    if IsValid(PB_TreeContainer) and PB_RefreshTree then
        PB_RefreshTree(PB_TreeContainer)
    end
end

local function playerCanManageProject(project)
    return project and project.isOwner == true
end

local function projectAutoManageEnabled(project)
    return not project or project.autoManage ~= false
end

local function projectDisplayName(project, isActive)
    local sharedTag = playerCanManageProject(project) and "" or TREE_STR.sharedSuffix
    local manageTag = projectAutoManageEnabled(project) and "" or TREE_STR.manualSuffix
    local prefix = isActive and "* " or "  "
    return prefix .. (project.name or (UI_STR.untitled or UI_STR.untitled)) .. sharedTag .. manageTag
end

local function collabSet(project)
    local out = {}
    for _, sid in ipairs((project and project.collaborators) or {}) do
        out[sid] = true
    end
    return out
end

local function sidColor(sid)
    local h = 0
    for i = 1, #sid do
        h = (h * 31 + sid:byte(i)) % 360
    end
    return HSVToColor(h, COL.shareIdentitySaturation, COL.shareIdentityValue)
end

local function rowPaint(self, w, h, bgBase)
    local bg = self:IsHovered() and COL.shareRowHover or bgBase
    draw.RoundedBox(2, 0, 0, w, h, bg)
end

local function openShareDialog(projectID)
    local project = PB.ProjectCache.projects[projectID]
    if not project or not playerCanManageProject(project) then return end

    local frame = vgui.Create("DFrame")
    frame:SetTitle(UI_STR.shareProject)
    frame:SetSize(360, 280)
    frame:Center()
    frame:MakePopup()

    local list = vgui.Create("DListView", frame)
    list:Dock(FILL)
    list:DockMargin(6, 6, 6, 6)
    list:AddColumn("Player")
    list:AddColumn("SteamID")

    local shared = collabSet(project)
    for _, ply in ipairs(player.GetAll()) do
        if ply ~= LocalPlayer() then
            local tag = shared[ply:SteamID()] and " (shared)" or ""
            list:AddLine(ply:Nick() .. tag, ply:SteamID())
        end
    end

    local buttons = vgui.Create("DPanel", frame)
    buttons:Dock(BOTTOM)
    buttons:SetTall(32)
    buttons:DockMargin(6, 0, 6, 6)
    buttons.Paint = function() end

    local shareBtn = vgui.Create("DButton", buttons)
    shareBtn:Dock(LEFT)
    shareBtn:SetWide(150)
    shareBtn:SetText(UI_STR.share)
    shareBtn.DoClick = function()
        local sel = list:GetSelectedLine()
        if not sel then return end
        local line = list:GetLine(sel)
        PB.Net.ProjectShare(projectID, line:GetColumnText(2))
        frame:Close()
    end

    local unshareBtn = vgui.Create("DButton", buttons)
    unshareBtn:Dock(RIGHT)
    unshareBtn:SetWide(150)
    unshareBtn:SetText(UI_STR.unshare)
    unshareBtn.DoClick = function()
        local sel = list:GetSelectedLine()
        if not sel then return end
        local line = list:GetLine(sel)
        PB.Net.ProjectUnshare(projectID, line:GetColumnText(2))
        frame:Close()
    end
end

PB.UI.OpenShareDialog = openShareDialog

concommand.Add("pb_share_active", function()
    local pid = PB.ProjectCache and PB.ProjectCache.active
    if not pid then
        chat.AddText(COL.error or COL.gcError, CFG.ChatPrefix .. " " .. ((STR.Chat or {}).noActiveProjectToShare))
        return
    end
    openShareDialog(pid)
end)

local function buildFolderChildren(folders, projects)
    local kids = { [false] = { folders = {}, projects = {} } }
    for id in pairs(folders) do
        kids[id] = { folders = {}, projects = {} }
    end
    for _, f in pairs(folders) do
        local parent = f.parentID or false
        if not kids[parent] then parent = false end
        table.insert(kids[parent].folders, f)
    end
    for _, p in pairs(projects) do
        local parent = p.folderID or false
        if not kids[parent] then parent = false end
        table.insert(kids[parent].projects, p)
    end
    for _, bucket in pairs(kids) do
        table.sort(bucket.folders, function(a, b) return (a.name or "") < (b.name or "") end)
        table.sort(bucket.projects, function(a, b) return (a.name or "") < (b.name or "") end)
    end
    return kids
end

local function decorateProjectRow(row, projectID)
    local origPaint = row.Paint
    row.Paint = function(self, w, h)
        if origPaint then origPaint(self, w, h) end

        local list = PB.ProjectCache.presence[projectID]
        if not list or #list == 0 then return end

        local me = IsValid(LocalPlayer()) and LocalPlayer():SteamID() or nil
        local x = w - 12
        local drawn = 0
        for _, sid in ipairs(list) do
            if sid ~= me and drawn < 3 then
                surface.SetDrawColor(sidColor(sid))
                surface.DrawRect(x - drawn * 10, h / 2 - 3, 6, 6)
                drawn = drawn + 1
            end
        end
    end
end

local function projectContextMenu(project)
    local menu = DermaMenu()
    menu:AddOption("Set Active", function()
        PB.Net.ProjectSetActive(project.id)
    end):SetIcon("icon16/accept.png")

    if playerCanManageProject(project) then
        local autoManage = projectAutoManageEnabled(project)
        menu:AddOption(autoManage and TREE_STR.disableAutoManage or TREE_STR.enableAutoManage, function()
            PB.Net.ProjectSetAutoManage(project.id, not autoManage)
        end):SetIcon(autoManage and "icon16/control_pause.png" or "icon16/control_play.png")
        menu:AddSpacer()

        menu:AddOption(PROJECT_MENU_STR.rename, function()
            Derma_StringRequest("Rename Project", PROJECT_MENU_STR.namePrompt, project.name, function(text)
                if text and text ~= "" then
                    PB.Net.ProjectRename(project.id, text)
                end
            end)
        end):SetIcon("icon16/textfield_rename.png")

        menu:AddSpacer()
        menu:AddOption(PROJECT_MENU_STR.share, function()
            openShareDialog(project.id)
        end):SetIcon("icon16/user_add.png")

        menu:AddSpacer()
        menu:AddOption(PC_STR.delete, function()
            Derma_Query(
                PROJECT_MENU_STR.deleteProjectPrefix .. project.name .. PROJECT_MENU_STR.deleteProjectSuffix,
                PROJECT_MENU_STR.confirmDelete,
                PC_STR.delete, function() PB.Net.ProjectDelete(project.id) end,
                GC_STR.cancel, function() end
            )
        end):SetIcon("icon16/cross.png")
    end

    menu:Open()
end

local function folderContextMenu(folder)
    local menu = DermaMenu()

    if folder.isOwner then
        menu:AddOption(PROJECT_MENU_STR.newProjectHere, function()
            Derma_StringRequest(PROJECT_MENU_STR.newProjectTitle, PROJECT_MENU_STR.namePrompt, UI_STR.untitled, function(text)
                if text and text ~= "" then
                    PB.Net.ProjectCreate(text, folder.id)
                end
            end)
        end):SetIcon("icon16/page_add.png")

        menu:AddOption(PROJECT_MENU_STR.newSubfolder, function()
            Derma_StringRequest(PROJECT_MENU_STR.newFolderTitle, PROJECT_MENU_STR.namePrompt, PROJECT_MENU_STR.folderDefault, function(text)
                if text and text ~= "" then
                    PB.Net.FolderCreate(text, folder.id)
                end
            end)
        end):SetIcon("icon16/folder_add.png")

        menu:AddOption(PROJECT_MENU_STR.rename, function()
            Derma_StringRequest(PROJECT_MENU_STR.renameFolderTitle, PROJECT_MENU_STR.namePrompt, folder.name, function(text)
                if text and text ~= "" then
                    PB.Net.FolderRename(folder.id, text)
                end
            end)
        end):SetIcon("icon16/textfield_rename.png")

        menu:AddSpacer()
        menu:AddOption(PROJECT_MENU_STR.deleteMoveContents, function()
            PB.Net.FolderDelete(folder.id, false)
        end):SetIcon("icon16/folder_delete.png")

        menu:AddOption(PROJECT_MENU_STR.deleteContents, function()
            Derma_Query(
                PROJECT_MENU_STR.deleteFolderPrefix .. folder.name .. PROJECT_MENU_STR.deleteFolderSuffix,
                PROJECT_MENU_STR.confirmRecursiveDelete,
                PROJECT_MENU_STR.deleteAll, function() PB.Net.FolderDelete(folder.id, true) end,
                GC_STR.cancel, function() end
            )
        end):SetIcon("icon16/delete.png")
    end

    menu:Open()
end

local function makeProjectRow(scroll, project, depth, isActive)
    local row = vgui.Create("DButton", scroll)
    row:Dock(TOP)
    row:SetTall(24)
    row:DockMargin(depth * 14, 1, 2, 0)

    row:SetText(projectDisplayName(project, isActive))
    row:SetTextColor(isActive and COL.projectRowActiveText or COL.actionPreset)
    row:SetContentAlignment(4)

    local bg = isActive and COL.rowSelected or COL.projectRowSelectedAlt or COL.rowDefault
    row.Paint = function(self, w, h) rowPaint(self, w, h, bg) end
    decorateProjectRow(row, project.id)

    row.DoClick = function()
        if not isActive then
            PB.Net.ProjectSetActive(project.id)
        end
    end
    row.DoRightClick = function()
        projectContextMenu(project)
    end

    if playerCanManageProject(project) then
        row:Droppable("pb_project")
        row.pb_project_id = project.id
    end

    return row
end

local function makeFolderRow(scroll, folder, depth)
    local row = vgui.Create("DButton", scroll)
    row:Dock(TOP)
    row:SetTall(24)
    row:DockMargin(depth * 14, 1, 2, 0)
    row:SetText("[F] " .. (folder.name or (UI_STR.folder)))
    row:SetTextColor(COL.projectFolderText)
    row:SetContentAlignment(4)
    row.Paint = function(self, w, h)
        rowPaint(self, w, h, COL.rowFolder)
    end
    row.DoRightClick = function()
        folderContextMenu(folder)
    end

    if folder.isOwner then
        row:Receiver("pb_project", function(_, panels, isDrop)
            if not isDrop then return end
            for _, panel in ipairs(panels) do
                if panel.pb_project_id then
                    PB.Net.ProjectMove(panel.pb_project_id, folder.id)
                end
            end
        end)
    end

    return row
end

local function renderBranch(scroll, kids, parentID, depth, activeID)
    local bucket = kids[parentID or false]
    if not bucket then return end

    for _, folder in ipairs(bucket.folders) do
        makeFolderRow(scroll, folder, depth)
        renderBranch(scroll, kids, folder.id, depth + 1, activeID)
    end

    for _, project in ipairs(bucket.projects) do
        makeProjectRow(scroll, project, depth, project.id == activeID)
    end
end

function PB_RenderProjectTree(scroll)
    if not IsValid(scroll) then return end
    local cache = PB.ProjectCache
    if not cache then return end

    local header = vgui.Create("DButton", scroll)
    header:Dock(TOP)
    header:SetTall(22)
    header:DockMargin(0, 0, 2, 2)
    header:SetText(UI_STR.newProjectFolder)
    header:SetTextColor(COL.projectHeaderText)
    header.Paint = function(self, w, h)
        rowPaint(self, w, h, COL.rowHeader)
    end
    header.DoClick = function()
        local menu = DermaMenu()
        menu:AddOption(PROJECT_MENU_STR.newProjectTitle, function()
            Derma_StringRequest(PROJECT_MENU_STR.newProjectTitle, PROJECT_MENU_STR.namePrompt, UI_STR.untitled, function(text)
                if text and text ~= "" then
                    PB.Net.ProjectCreate(text, "")
                end
            end)
        end):SetIcon("icon16/page_add.png")

        menu:AddOption(PROJECT_MENU_STR.newFolderTitle, function()
            Derma_StringRequest(PROJECT_MENU_STR.newFolderTitle, PROJECT_MENU_STR.namePrompt, PROJECT_MENU_STR.folderDefault, function(text)
                if text and text ~= "" then
                    PB.Net.FolderCreate(text, "")
                end
            end)
        end):SetIcon("icon16/folder_add.png")
        menu:Open()
    end

    local kids = buildFolderChildren(cache.folders or {}, cache.projects or {})
    renderBranch(scroll, kids, nil, 0, cache.active)

    local sep = vgui.Create("DPanel", scroll)
    sep:Dock(TOP)
    sep:SetTall(2)
    sep:DockMargin(2, 4, 2, 4)
    sep.Paint = function(_, w, h)
        surface.SetDrawColor(COL.projectSplitter)
        surface.DrawRect(0, 0, w, h)
    end
end















if SERVER then return end






PB_PCMode = PB_PCMode or {
    active = false,
    firstNode = nil,
    firstFeature = nil,
    hoveredEnt = nil,
    hoveredFeature = nil,
    selectedPCID = nil,
    panelWasOpen = false,
    pendingMode = "geometric",
}

PB_MirrorMode = PB_MirrorMode or {
    active = false,
    sourceNodeID = nil,
    hoveredEnt = nil,
    hoveredNodeID = nil,
    panelWasOpen = false,
}

function PB_MirrorMode_Enter(sourceNodeID)
    sourceNodeID = tonumber(sourceNodeID)
    if not sourceNodeID then return end
    if PB_ClearMirrorDraft then PB_ClearMirrorDraft() end
    PB_MirrorMode.active = true
    PB_MirrorMode.sourceNodeID = sourceNodeID
    PB_MirrorMode.hoveredEnt = nil
    PB_MirrorMode.hoveredNodeID = nil

    net.Start(PREFIX .. "mirror_select_mode")
    net.WriteBool(true)
    net.WriteUInt(sourceNodeID, 24)
    net.SendToServer()

    if IsValid(PB_MainPanel) then
        PB_MirrorMode.panelWasOpen = true
        PB_MainPanel:SetVisible(false)
        PB_MainPanel:SetMouseInputEnabled(false)
        PB_MainPanel:SetKeyboardInputEnabled(false)
    else
        PB_MirrorMode.panelWasOpen = false
    end
    gui.EnableScreenClicker(false)
end

function PB_MirrorMode_Exit()
    PB_MirrorMode.active = false
    PB_MirrorMode.sourceNodeID = nil
    PB_MirrorMode.hoveredEnt = nil
    PB_MirrorMode.hoveredNodeID = nil

    net.Start(PREFIX .. "mirror_select_mode")
    net.WriteBool(false)
    net.SendToServer()

    if PB_MirrorMode.panelWasOpen and IsValid(PB_MainPanel) then
        PB_MainPanel:SetVisible(true)
        PB_MainPanel:SetMouseInputEnabled(true)
        PB_MainPanel:SetKeyboardInputEnabled(true)
        PB_MainPanel:MakePopup()
    end
end

function PB_PCMode_Reset()
    PB_PCMode.firstNode = nil
    PB_PCMode.firstFeature = nil
end

function PB_PCMode_Enter()
    PB_PCMode.active = true
    PB_PCMode_Reset()
    net.Start(PREFIX .. "pc_select_mode")
    net.WriteBool(true)
    net.WriteString(PB_PCMode.pendingMode or "geometric")
    net.SendToServer()

    if IsValid(PB_MainPanel) then
        PB_PCMode.panelWasOpen = true
        PB_MainPanel:SetVisible(false)
        PB_MainPanel:SetMouseInputEnabled(false)
        PB_MainPanel:SetKeyboardInputEnabled(false)
    else
        PB_PCMode.panelWasOpen = false
    end
    gui.EnableScreenClicker(false)
end

function PB_PCMode_Exit()
    PB_PCMode.active = false
    PB_PCMode_Reset()
    net.Start(PREFIX .. "pc_select_mode")
    net.WriteBool(false)
    net.SendToServer()

    if PB_PCMode.panelWasOpen and IsValid(PB_MainPanel) then
        PB_MainPanel:SetVisible(true)
        PB_MainPanel:SetMouseInputEnabled(true)
        PB_MainPanel:SetKeyboardInputEnabled(true)
        PB_MainPanel:MakePopup()
    end
end







local function projectContextMenuFlat(project)
    local menu = DermaMenu()
    menu:AddOption("Set Active", function()
        PB.Net.ProjectSetActive(project.id)
    end):SetIcon("icon16/accept.png")

    if playerCanManageProject(project) then
        local autoManage = projectAutoManageEnabled(project)
        menu:AddOption(autoManage and TREE_STR.disableAutoManage or TREE_STR.enableAutoManage, function()
            PB.Net.ProjectSetAutoManage(project.id, not autoManage)
        end):SetIcon(autoManage and "icon16/control_pause.png" or "icon16/control_play.png")
        menu:AddSpacer()

        menu:AddOption(PROJECT_MENU_STR.rename, function()
            Derma_StringRequest("Rename Project", PROJECT_MENU_STR.namePrompt, project.name, function(text)
                if text and text ~= "" then
                    PB.Net.ProjectRename(project.id, text)
                end
            end)
        end):SetIcon("icon16/textfield_rename.png")

        menu:AddOption(PROJECT_MENU_STR.share, function()
            openShareDialog(project.id)
        end):SetIcon("icon16/user_add.png")

        menu:AddSpacer()
        menu:AddOption(PC_STR.delete, function()
            Derma_Query(
                PROJECT_MENU_STR.deleteProjectPrefix .. project.name .. PROJECT_MENU_STR.deleteProjectSuffix,
                PROJECT_MENU_STR.confirmDelete,
                PC_STR.delete, function() PB.Net.ProjectDelete(project.id) end,
                GC_STR.cancel, function() end
            )
        end):SetIcon("icon16/cross.png")
    end

    menu:Open()
end

function PB_RefreshProjects(container)
    local scroll = container and container.projectScroll
    if not IsValid(scroll) then return end
    scroll:Clear()

    local cache = PB.ProjectCache or { projects = {}, active = nil }

    local info = vgui.Create("DLabel", scroll)
    info:Dock(TOP)
    info:DockMargin(6, 4, 6, 6)
    info:SetWrap(true)
    info:SetAutoStretchVertical(true)
    info:SetTextColor(COL.projectInfoText)
    info:SetText(UI_STR.projectsSessionOnly)

    local projects = {}
    for _, project in pairs(cache.projects or {}) do
        projects[#projects + 1] = project
    end
    table.sort(projects, function(a, b)
        local an = string.lower(a.name or "")
        local bn = string.lower(b.name or "")
        if an ~= bn then return an < bn end
        return (a.id or "") < (b.id or "")
    end)

    if #projects == 0 then
        local empty = vgui.Create("DLabel", scroll)
        empty:Dock(TOP)
        empty:DockMargin(6, 12, 6, 0)
        empty:SetTextColor(COL.checkboxText)
        empty:SetText(UI_STR.noProjects)
        empty:SetWrap(true)
        empty:SetAutoStretchVertical(true)
        return
    end

    for _, project in ipairs(projects) do
        local isActive = project.id == cache.active
        local row = vgui.Create("DButton", scroll)
        row:Dock(TOP)
        row:SetTall(26)
        row:DockMargin(4, 1, 4, 0)
        row:SetText(projectDisplayName(project, isActive))
        row:SetTextColor(isActive and COL.projectRowActiveText or COL.actionPreset)
        row:SetContentAlignment(4)
        local bg = isActive and COL.rowSelected or COL.projectRowSelectedAlt or COL.rowDefault
        row.Paint = function(self, w, h) rowPaint(self, w, h, bg) end
        decorateProjectRow(row, project.id)
        row.DoClick = function()
            if not isActive then PB.Net.ProjectSetActive(project.id) end
        end
        row.DoRightClick = function()
            projectContextMenuFlat(project)
        end
    end
end
net.Receive(PREFIX .. "sync_graph", function()
    local graph = PB.GetGraph(LocalPlayer())
    local data = util.JSONToTable(net.ReadString())
    if data then


        if data.variables then
            graph.variables = data.variables
            graph.variableMeta = data.variableMeta or {}
        else
            graph.variables = data
        end
    end
    graph.solverDiagnostic = nil
    net.ReadUInt(24)
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)

net.Receive(PREFIX .. "sync_node", function()
    local graph = PB.GetGraph(LocalPlayer())
    local data = util.JSONToTable(net.ReadString())
    if not data then return end

    local entity = net.ReadEntity()
    if not IsValid(entity) or entity:EntIndex() == 0 then entity = nil end
    local patternEntCount = net.ReadUInt(8)
    local patternEnts = {}
    for i = 1, patternEntCount do
        local ent = net.ReadEntity()
        if IsValid(ent) and ent:EntIndex() ~= 0 then
            table.insert(patternEnts, ent)
        end
    end

    local nodeID = data.id
    local parentID = data.parentID
    if parentID == 0 then parentID = nil end

    local node = graph.nodes[nodeID]
    if not node then
        node = {
            id = nodeID,
            children = {},
            constraintParams = {},
            patternEntities = {},
            patternConstraints = {},
            patternConstraintParams = {},
        }
        graph.nodes[nodeID] = node
        graph.nextID = math.max(graph.nextID, nodeID + 1)
    end


    if node.entity and node.entity ~= entity then
        graph._entityIndex[node.entity] = nil
    end


    if node.parentID and graph.nodes[node.parentID] then
        graph.nodes[node.parentID].children[nodeID] = nil
    end

    node.localPos = Vector(data.localPos.x, data.localPos.y, data.localPos.z)
    node.localAngle = Angle(data.localAngle.p, data.localAngle.y, data.localAngle.r)
    node.worldPos = Vector(data.worldPos.x, data.worldPos.y, data.worldPos.z)
    node.worldAngle = Angle(data.worldAngle.p, data.worldAngle.y, data.worldAngle.r)
    node.constraintType = data.constraintType
    node.label = data.label
    local notesVal = data.notes
    node.notes = (notesVal and notesVal ~= "") and notesVal or nil
    node.parentID = parentID
    node.model = data.model
    node.entityClass = data.entityClass or "prop_physics"
    node.entity = entity
    node.locked = data.locked
    node.visible = data.visible ~= false

    if entity then
        graph._entityIndex[entity] = nodeID
    end

    local exprPos = data.exprPos
    local exprAngle = data.exprAngle
    node.exprPos = (exprPos ~= "" and exprPos) or nil
    node.exprAngle = (exprAngle ~= "" and exprAngle) or nil
    node.exprPosParts = istable(data.exprPosParts) and data.exprPosParts or nil
    node.exprAngleParts = istable(data.exprAngleParts) and data.exprAngleParts or nil
    node.dofOverrides = istable(data.dofOverrides) and data.dofOverrides or { pos = {}, ang = {} }

    node.isPattern = data.isPattern
    local patType = data.patternType
    node.patternType = (patType ~= "" and patType) or nil
    node.patternParams = data.patternParams or {}
    node.copyConstraints = data.copyConstraints
    local patCT = data.patternConstraintType
    node.patternConstraintType = (patCT ~= "" and patCT) or "none"
    node.patternConstraintParams = data.patternConstraintParams or {}
    node.patternEntities = patternEnts
    node.isMirrorGenerated = data.isMirrorGenerated or false
    node.mirrorSourceNodeID = (data.mirrorSourceNodeID and data.mirrorSourceNodeID > 0) and data.mirrorSourceNodeID or nil
    node.mirrorPCID = (data.mirrorPCID and data.mirrorPCID > 0) and data.mirrorPCID or nil

    if parentID and graph.nodes[parentID] then
        graph.nodes[parentID].children[nodeID] = true
    end

    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)


net.Receive(PREFIX .. "sync_delete_node", function()
    local graph = PB.GetGraph(LocalPlayer())
    local nodeID = net.ReadUInt(24)
    local node = graph.nodes[nodeID]
    if node then
        if node.parentID and graph.nodes[node.parentID] then
            graph.nodes[node.parentID].children[nodeID] = nil
        end
        if node.entity then
            graph._entityIndex[node.entity] = nil
        end

        for childID in pairs(node.children or {}) do
            local child = graph.nodes[childID]
            if child then
                child.parentID = node.parentID
                if node.parentID and graph.nodes[node.parentID] then
                    graph.nodes[node.parentID].children[childID] = true
                end
            end
        end
        graph.nodes[nodeID] = nil
    end
    if PB_Overlay then
        if PB_Overlay.selectedNodeID == nodeID then
            PB_Overlay.selectedNodeID = nil
        end
        PB_Overlay._needsRefresh = true
    end
end)

net.Receive(PREFIX .. "sync_pc", function()
    local graph = PB.GetGraph(LocalPlayer())
    local pcid = net.ReadUInt(24)
    local isDelete = net.ReadBool()

    if isDelete then
        graph.pconstraints[pcid] = nil
        if PB_Overlay then PB_Overlay._needsRefresh = true end
        return
    end

    local data = util.JSONToTable(net.ReadString())
    if not data then return end

    local function parseFeatureID(featureType, rawID)




        if type(rawID) == "string" and rawID:sub(1, 1) == "p" then return rawID end
        if featureType == "edge" or featureType == "corner" then return tonumber(rawID) end
        return rawID
    end

    local parentFeature = data.parentFeature
    parentFeature.id = parseFeatureID(parentFeature.type, parentFeature.id)
    local childFeature = data.childFeature
    childFeature.id = parseFeatureID(childFeature.type, childFeature.id)

    local function toNumberOrString(val)
        local num = tonumber(val)
        if num then return num end
        return val
    end

    graph.pconstraints[pcid] = {
        id = pcid,
        parentNodeID = data.parentNodeID,
        childNodeID = data.childNodeID,
        parentFeature = parentFeature,
        childFeature = childFeature,
        mode = (data.mode ~= "" and data.mode) or "geometric",
        offset = toNumberOrString(data.offset),
        slideX = toNumberOrString(data.slideX),
        slideY = toNumberOrString(data.slideY),
        angle = toNumberOrString(data.angle),
        parentFraction = toNumberOrString(data.parentFraction),
        childFraction = toNumberOrString(data.childFraction),
        distance = toNumberOrString(data.distance),
        mirrorNodeID = (data.mirrorNodeID and data.mirrorNodeID > 0) and data.mirrorNodeID or nil,
        mirrorFace = (data.mirrorFace ~= "" and data.mirrorFace) or nil,
        mirrorAxis = (data.mirrorAxis ~= "" and data.mirrorAxis) or ((data.mirrorFace ~= "" and data.mirrorFace) or nil),
        mirrorGConstraints = data.mirrorGConstraints or false,
        active = data.active,
        flipped = data.flipped or false,
        branchParentSide = math.Clamp(math.floor(tonumber(data.branchParentSide) or 1), 1, 2),
        branchChildSide = math.Clamp(math.floor(tonumber(data.branchChildSide) or 1), 1, 2),
        crossLink = data.crossLink or false,
        solverResidual = tonumber(data.solverResidual) or 0,
        solverWeightedResidual = tonumber(data.solverWeightedResidual) or 0,
        solverSatisfied = data.solverSatisfied ~= false,
        solverStatus = data.solverStatus or "unknown",
    }

    graph.nextPCID = math.max(graph.nextPCID, pcid + 1)
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)


net.Receive(PREFIX .. "sync_gc", function()
    local graph = PB.GetGraph(LocalPlayer())
    local gcid = net.ReadUInt(24)
    local isDelete = net.ReadBool()

    if not graph then return end
    graph.gconstraints = graph.gconstraints or {}

    if isDelete then
        graph.gconstraints[gcid] = nil
        if PB_GCMode and PB_GCMode.selectedGCID == gcid then
            PB_GCMode.selectedGCID = nil
            PB_GCEditDraft = nil
        end
    else
        local data = util.JSONToTable(net.ReadString() or "{}") or {}
        local attachA = PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(data.attachA) or data.attachA
        local attachB = PB.GCDeserializeAttachment and PB.GCDeserializeAttachment(data.attachB) or data.attachB
        graph.gconstraints[gcid] = {
            id = data.id or gcid,
            name = data.name or "",
            type = data.type or "weld",
            enabled = data.enabled ~= false,
            nodeA = tonumber(data.nodeA) or 0,
            nodeB = tonumber(data.nodeB) or 0,
            attachA = attachA,
            attachB = attachB,
            params = PB.GCMergeParams and PB.GCMergeParams(data.type or "weld", data.params or {}) or (data.params or {}),
            updateMode = data.updateMode or "live",
            status = data.status or "ok",
            debugVisible = data.debugVisible ~= false,
            isMirrorGenerated = data.isMirrorGenerated or false,
            mirrorPCID = tonumber(data.mirrorPCID) or nil,
            mirrorSourceGCID = tonumber(data.mirrorSourceGCID) or nil,
        }
        graph.nextGCID = math.max(graph.nextGCID or 1, gcid + 1)
        if PB_GCMode and PB_GCMode.selectedGCID == gcid then
            PB_GCEditDraft = PB_GCCloneClientData(graph.gconstraints[gcid])
        end
    end

    PB_GCNeedsRebuild = true
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)

net.Receive(PREFIX .. "select_feedback", function()
    local nodeID = net.ReadUInt(24)
    if nodeID == 0 then nodeID = nil end
    if PB_Overlay then PB_Overlay.selectedNodeID = nodeID end
end)

net.Receive(PREFIX .. "sync_clear", function()
    PB.Graphs["local"] = PB.NewGraph()
    PB_PCMode_Reset()
    PB_GCDraft = nil
    PB_GCEditDraft = nil
    PB_GCFieldPreviewDraft = nil
    if PB_GCMode then
        PB_GCMode.active = false
        PB_GCMode.selectedGCID = nil
        PB_GCMode.hoveredEnt = nil
        PB_GCMode.hoveredNodeID = nil
        PB_GCMode.hoveredFeature = nil
    end
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)

net.Receive(PREFIX .. "sync_solver_status", function()
    local graph = PB.GetGraph(LocalPlayer())
    local data = util.JSONToTable(net.ReadString())
    if not data then return end

    graph.solverDiagnostic = {
        impl = data.impl or "legacy",
        status = data.status or "ok",
        modelStatus = data.modelStatus or "well_constrained",
        attemptStatus = data.attemptStatus or "accepted",
        converged = data.converged,
        accepted = data.accepted,
        iterations = data.iterations or 0,
        residualNorm = data.residualNorm or 0,
        numEquations = data.numEquations or 0,
        numUnknowns = data.numUnknowns or 0,
        rank = data.rank or 0,
        nullity = data.nullity or 0,
        redundant = data.redundant or 0,
        underConstrained = data.underConstrained or false,
        overConstrained = data.overConstrained or {},
        nodeAxes = data.nodeAxes or {},
        nodeAxisScores = data.nodeAxisScores or {},
        axisSelection = data.axisSelection or {},
        branchAttempts = tonumber(data.branchAttempts) or 0,
        conditionEstimate = tonumber(data.conditionEstimate) or 0,
        trustRatio = tonumber(data.trustRatio) or 0,
        groundingModes = data.groundingModes or {},
        anchorNodeIDs = data.anchorNodeIDs or {},
        gaugeNodeIDs = data.gaugeNodeIDs or {},
    }

    if data.pcStatus then
        for pcidStr, st in pairs(data.pcStatus) do
            local pcid = tonumber(pcidStr)
            if pcid and graph.pconstraints[pcid] then
                graph.pconstraints[pcid].solverResidual = st.residual or 0
                graph.pconstraints[pcid].solverWeightedResidual = st.weightedResidual or 0
                graph.pconstraints[pcid].solverSatisfied = st.satisfied
                graph.pconstraints[pcid].solverStatus = st.status or "unknown"
            end
        end
    end

    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)





net.Receive(PREFIX .. "sync_pc_state", function()
    local hasFirst = net.ReadBool()
    if hasFirst then
        PB_PCMode.firstNode = net.ReadUInt(24)
        local featureType = net.ReadString()
        local featureID = net.ReadString()


        if (featureType == "edge" or featureType == "corner")
            and featureID:sub(1, 1) ~= "p" then
            featureID = tonumber(featureID)
        end
        PB_PCMode.firstFeature = { type = featureType, id = featureID }
        surface.PlaySound("buttons/button15.wav")
    else
        PB_PCMode.firstNode = nil
        PB_PCMode.firstFeature = nil
    end
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)

net.Receive(PREFIX .. "pc_mode_exit", function()
    PB_PCMode.active = false
    PB_PCMode.firstNode = nil
    PB_PCMode.firstFeature = nil
    surface.PlaySound("buttons/button14.wav")

    if PB_PCMode.panelWasOpen and IsValid(PB_MainPanel) then
        PB_MainPanel:SetVisible(true)
        PB_MainPanel:SetMouseInputEnabled(true)
        PB_MainPanel:SetKeyboardInputEnabled(true)
        PB_MainPanel:MakePopup()
    end
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)

net.Receive(PREFIX .. "mirror_node_picked", function()
    local sourceNodeID = net.ReadUInt(24)
    local mirrorNodeID = net.ReadUInt(24)

    PB_MirrorMode.active = false
    PB_MirrorMode.sourceNodeID = nil
    PB_MirrorMode.hoveredEnt = nil
    PB_MirrorMode.hoveredNodeID = nil

    PB_SetMirrorDraft(sourceNodeID, mirrorNodeID, "x")
    surface.PlaySound("buttons/button14.wav")

    if PB_MirrorMode.panelWasOpen and IsValid(PB_MainPanel) then
        PB_MainPanel:SetVisible(true)
        PB_MainPanel:SetMouseInputEnabled(true)
        PB_MainPanel:SetKeyboardInputEnabled(true)
        PB_MainPanel:MakePopup()
    end
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)

net.Receive(PREFIX .. "mirror_mode_exit", function()
    PB_MirrorMode.active = false
    PB_MirrorMode.sourceNodeID = nil
    PB_MirrorMode.hoveredEnt = nil
    PB_MirrorMode.hoveredNodeID = nil
    surface.PlaySound("buttons/button14.wav")

    if PB_MirrorMode.panelWasOpen and IsValid(PB_MainPanel) then
        PB_MainPanel:SetVisible(true)
        PB_MainPanel:SetMouseInputEnabled(true)
        PB_MainPanel:SetKeyboardInputEnabled(true)
        PB_MainPanel:MakePopup()
    end
    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)




net.Receive(PREFIX .. "solver_active", function()
    PB_SolverActive = net.ReadBool()
end)







net.Receive(PREFIX .. "phys_features", function()
    local len = net.ReadUInt(24)
    local compressed = net.ReadData(len)
    local raw = util.Decompress(compressed)
    if not raw then return end
    local data = util.JSONToTable(raw)
    if not data or not data.model then return end

    local function vec(t) return Vector(t[1], t[2], t[3]) end

    local vertices = {}
    for i, v in ipairs(data.vertices or {}) do vertices[i] = vec(v) end

    local faces = {}
    for i, f in ipairs(data.faces or {}) do
        faces[i] = {
            nx = f.n[1], ny = f.n[2], nz = f.n[3],
            ox = f.o[1], oy = f.o[2], oz = f.o[3],
            ux = f.u[1], uy = f.u[2], uz = f.u[3],
            vx = f.v[1], vy = f.v[2], vz = f.v[3],
            verts = f.verts,
            sizeMin = f.sizeMin,
        }
    end

    local edges = {}
    for i, e in ipairs(data.edges or {}) do
        edges[i] = {
            vA = e.vA, vB = e.vB,
            nAx = e.nA[1], nAy = e.nA[2], nAz = e.nA[3],
            nBx = e.nB[1], nBy = e.nB[2], nBz = e.nB[3],
        }
    end

    local corners = {}
    for i, vIdx in ipairs(data.corners or {}) do
        corners[i] = { v = vIdx }
    end

    if PB.PhysFeatures and PB.PhysFeatures.SetForModel then
        PB.PhysFeatures.SetForModel(data.model, {
            faces = faces, edges = edges, corners = corners, vertices = vertices,
        })
    end



    if PB_Overlay then PB_Overlay._needsRefresh = true end
end)


