












PB = PB or {}
PB.Config = PB.Config or {}
local CFG = PB.Config




CFG.AddonName = "GParametric"
CFG.ToolVersionLabel = "GParametric"
CFG.CommandPrefix = "gparametric_"
CFG.ChatPrefix = "[G_Para]"





CFG.Server = CFG.Server or {

    rateLimitInterval = 0.05,
}

CFG.Solver = CFG.Solver or {

    maxIterations = 1200,
    maxLambda = 1e16,





    maxLambdaRestarts = 2,
    lambda0 = 1e-3,
    lambdaGrow = 8,
    lambdaShrink = 0.35,


    stepConvergenceMaxLambdaFactor = 1000,


    convergenceResidual = 1e-5,
    convergenceStep = 1e-5,


    angularScale = 48.0,
    axisFreeTol = 1e-3,



    axisDirectFreeTol = 1e-5,



    axisDirectFreeRatioMin = 0.999,
    axisIndependentRatioMin = 1e-4,
    pivotTol = 1e-8,
    satTol = 0.05,
    conflictTol = 0.5,


    axisIndependenceTol = 1e-4,


    localComponentsDefault = true,
}






CFG.Logging = CFG.Logging or {
    enabledDefault = false,
    consoleMirrorDefault = false,
    directory = "parametric_builder/logs",
    filePrefix = "pb_trace",
    maxDepth = 7,
    maxItems = 160,
}

CFG.ConVars = CFG.ConVars or {
    solverMaxIterations = {
        name = CFG.CommandPrefix .. "solver_max_iterations",
        default = tostring(CFG.Solver.maxIterations),
        help = "Maximum LM iterations per propagate",
    },
    solverMaxLambda = {
        name = CFG.CommandPrefix .. "solver_max_lambda",
        default = tostring(CFG.Solver.maxLambda),
        help = "Maximum LM damping before the solver gives up",
    },
    solverLocalComponents = {
        name = CFG.CommandPrefix .. "solver_local_components",
        default = CFG.Solver.localComponentsDefault and "1" or "0",
        help = "Solve only the constraint-connected component for Propagate(startID)",
    },


    overlayEnabled =       { name = CFG.CommandPrefix .. "overlay_enabled",     default = "1",    help = "Draw GPara 3D overlay" },
    overlayLabels =        { name = CFG.CommandPrefix .. "overlay_labels",      default = "1",    help = "Draw GPara node labels" },
    overlayOffsets =       { name = CFG.CommandPrefix .. "overlay_offsets",     default = "1",    help = "Draw GPara local offset labels" },
    overlayConstraints =   { name = CFG.CommandPrefix .. "overlay_constraints", default = "1",    help = "Draw GPara constraint links" },
    overlayAxes =          { name = CFG.CommandPrefix .. "overlay_axes",        default = "0",    help = "Draw GPara local axes" },
    overlayDimensions =    { name = CFG.CommandPrefix .. "overlay_dimensions",  default = "1",    help = "Draw GPara dimensions" },
    overlayMaxDistance =   { name = CFG.CommandPrefix .. "overlay_maxdist",     default = "4000", help = "Maximum GPara overlay draw distance" },
    snapGrid =             { name = CFG.CommandPrefix .. "snap_grid",           default = "1",    help = "Grid snap amount for GPara placement" },


    fileLogEnabled =      { name = CFG.CommandPrefix .. "file_log_enabled",   default = CFG.Logging.enabledDefault == false and "0" or "1", help = "Write detailed GPara logs to garrysmod/data" },
    fileLogConsole =      { name = CFG.CommandPrefix .. "file_log_console",   default = CFG.Logging.consoleMirrorDefault and "1" or "0", help = "Mirror GPara detailed file-log lines to console" },
    fileLogPayloadMaxDepth = { name = CFG.CommandPrefix .. "file_log_max_depth", default = tostring(CFG.Logging.maxDepth), help = "Maximum recursive depth for GPara file-log payloads" },
    fileLogPayloadMaxItems = { name = CFG.CommandPrefix .. "file_log_max_items", default = tostring(CFG.Logging.maxItems), help = "Maximum table items per GPara file-log payload" },
}





local function C(r, g, b, a)
    return Color(r, g, b, a == nil and 255 or a)
end

CFG.Colors = CFG.Colors or {}
local COL = CFG.Colors


COL.white = C(255, 255, 255)
COL.whiteSoft = C(255, 255, 255, 220)
COL.textPrimary = C(220, 220, 220, 220)
COL.textSecondary = C(200, 200, 200)
COL.textMuted = C(140, 140, 160)
COL.textDisabled = C(80, 80, 80, 150)
COL.textDim = C(120, 120, 140)
COL.error = C(255, 80, 80)
COL.warning = C(255, 200, 80)
COL.success = C(80, 220, 120)
COL.info = C(120, 200, 255)
COL.accent = C(100, 255, 200)
COL.selected = C(255, 220, 50)
COL.locked = C(255, 50, 50)
COL.dofSolverLock = C(125, 125, 135)
COL.dofUserLock = C(255, 175, 70)
COL.dofUserUnlock = C(80, 190, 255)
COL.dofFree = C(90, 220, 120)
COL.labelBackground = C(0, 0, 0, 160)


COL.rootNode = C(80, 200, 80)
COL.childNode = C(80, 140, 255)
COL.hoveredNode = C(255, 180, 0, 180)
COL.patternNode = C(180, 100, 255, 200)
COL.constraintLine = C(200, 200, 200, 180)
COL.constraintLineActive = C(255, 255, 100, 220)
COL.faceHover = C(100, 255, 100, 60)
COL.faceSelected = C(255, 220, 50, 80)
COL.dimension = C(220, 220, 255, 200)
COL.axisX = C(255, 0, 0, 200)
COL.axisY = C(0, 255, 0, 200)
COL.axisZ = C(0, 0, 255, 200)


COL.panelBackground = C(30, 30, 40, 255)
COL.panelToolbar = C(40, 40, 55, 255)
COL.panelHeader = C(50, 50, 70, 200)
COL.panelBody = C(20, 20, 35, 230)
COL.panelHighlight = C(50, 255, 150, 40)
COL.rowDefault = C(30, 35, 55, 220)
COL.rowHover = C(45, 50, 65, 220)
COL.rowSelected = C(60, 55, 25, 220)
COL.rowFolder = C(45, 35, 25, 220)
COL.rowHeader = C(25, 25, 40, 220)
COL.rowVariable = C(35, 45, 40, 200)
COL.shareHover = C(60, 60, 90, 220)


COL.constraintModes = {
    face_face = C(50, 255, 100),
    planar = C(90, 190, 255),
    edge_edge = C(80, 140, 255),
    face_edge = C(255, 180, 50),
    edge_face = C(255, 180, 50),
    face_corner = C(255, 255, 80),
    edge_corner = C(255, 255, 80),
    corner_face = C(255, 255, 80),
    corner_edge = C(255, 255, 80),
    corner_corner = C(255, 255, 80),
    distance = C(200, 100, 255),
    symmetry = C(255, 120, 200),
    mirror = C(120, 180, 255),
    crosslink = C(255, 160, 60),
    parallel = C(80, 220, 220),
    perpendicular = C(220, 140, 80),
    fallback = C(200, 200, 200),
}


COL.solverStatus = {
    ok = C(50, 255, 100),
    solved_redundant = C(80, 220, 140),
    under_constrained = C(255, 255, 80),
    under_constrained_with_conflicts = C(255, 120, 60),
    singular = C(255, 170, 80),
    ill_conditioned = C(255, 130, 220),
    over_constrained = C(255, 60, 60),
    diverged = C(255, 180, 50),
    unknown = C(150, 150, 150),
}


COL.physicalConstraint = {
    weld = C(255, 80, 80, 220),
    axis = C(80, 255, 80, 220),
    ballsocket = C(80, 80, 255, 220),
    advballsocket = C(120, 80, 255, 220),
    slider = C(255, 255, 80, 220),
    rope = C(180, 120, 60, 220),
    elastic = C(255, 120, 200, 220),
    nocollide = C(150, 150, 150, 150),
    parent = C(200, 200, 255, 220),
}



COL.blackOverlay = C(0, 0, 0, 200)
COL.toolScreenBackground = C(0, 0, 0, 200)
COL.toolScreenTitle = C(255, 220, 100)
COL.toolScreenText = C(255, 255, 255)
COL.restoreEntityColor = C(255, 255, 255, 255)
COL.chatTitle = C(255, 220, 100)
COL.overlayAngleText = C(200, 200, 255, 220)
COL.overlayNotes = C(180, 180, 200, 200)
COL.previewSuccess = C(100, 255, 180, 200)
COL.previewError = C(255, 100, 100, 200)
COL.sectionHeaderText = C(180, 210, 255)
COL.actionCreate = C(100, 255, 180)
COL.actionSnap = C(100, 255, 180)
COL.actionMirror = C(120, 180, 255)
COL.actionPreset = C(180, 220, 255)
COL.actionRebuild = C(255, 220, 120)
COL.actionCapture = C(180, 220, 255)
COL.actionLinear = C(100, 255, 100)
COL.actionCircular = C(100, 200, 255)
COL.actionGrid = C(255, 200, 100)
COL.actionHelix = C(255, 140, 255)
COL.statusPanelBackground = C(25, 28, 38, 230)
COL.statusInfoText = C(180, 180, 190)
COL.statusDetailText = C(150, 170, 190)
COL.pcResidualBackground = C(20, 20, 30, 200)
COL.pcSatisfiedDot = C(50, 255, 100)
COL.checkboxText = C(210, 210, 220)
COL.gcDisabled = C(160, 160, 180)
COL.gcError = C(255, 120, 120)
COL.gcRowSelected = C(50, 60, 30, 220)
COL.patternHeader = C(180, 100, 255)
COL.variableHeaderBackground = C(35, 45, 40, 200)
COL.projectRowActiveText = C(255, 220, 80)
COL.projectRowText = C(180, 220, 255)
COL.projectFolderText = C(255, 200, 120)
COL.projectHeaderText = C(200, 200, 220)
COL.projectInfoText = C(170, 170, 190)
COL.projectSplitter = C(80, 80, 100, 200)
COL.emptyText = C(210, 210, 220)
COL.settingHeader = C(180, 210, 255)
COL.shareRowHover = C(60, 60, 90, 220)
COL.mirrorHudHeader = C(120, 180, 255, 45)
COL.mirrorHudText = C(220, 235, 255)
COL.mirrorPlaneFill = {
    x = C(255, 80, 80, 14),
    y = C(80, 255, 120, 14),
    z = C(90, 150, 255, 14),
    fallback = C(120, 180, 255, 24),
}

COL.constraintModeGeometric = C(50, 255, 150)
COL.constraintModeParallel = C(80, 220, 220)
COL.constraintModePerpendicular = C(220, 140, 80)
COL.constraintModePlanar = C(90, 190, 255)
COL.mirrorHudPicked = C(100, 255, 160)
COL.mirrorHudHint = C(160, 180, 220)
COL.variableOverlayText = C(180, 255, 220, 200)
COL.selectedRowOverlay = C(255, 220, 50, 40)
COL.disabledFieldLabel = C(100, 100, 100)
COL.disabledFieldText = C(80, 80, 80)
COL.inactiveText = C(100, 100, 100)
COL.rowInactiveDefault = C(35, 38, 50, 200)
COL.projectRowSelectedAlt = C(60, 55, 25, 220)
COL.toolScreenPulse = C(220, 220, 100, 255)
COL.toolgunScreenBackground = C(20, 20, 20, 255)
COL.mirrorPlaneLine = {
    x = C(255, 80, 80, 80),
    y = C(80, 255, 120, 80),
    z = C(90, 150, 255, 80),
    fallback = C(120, 180, 255, 115),
}


COL.gconstraintPoint = C(255, 230, 90, 230)
COL.gconstraintDirection = C(120, 220, 255, 230)
COL.gconstraintDraft = C(255, 220, 50, 80)
COL.pconstraintAddButton = C(50, 255, 150)
COL.gconstraintListText = C(38, 38, 38)
COL.gconstraintListSelectedText = C(135, 72, 0)
COL.shareIdentitySaturation = 0.55
COL.shareIdentityValue = 0.95

CFG.DefaultMaterials = CFG.DefaultMaterials or {
    rope = "cable/rope",
    elastic = "cable/rope",
}





CFG.Strings = CFG.Strings or {}
local S = CFG.Strings

S.Chat = {
    createOrSelectProject = "Create or select a project first",
    notInGraph = "Not in graph",
    featureUnavailable = "No selectable phys feature found for this prop yet",
    selectionCleared = "Selection cleared",
    pcModeCancelled = "PC mode cancelled",
    noActiveProjectToShare = "No active project to share",
}

S.Tool = {
    category = "Construction",
    nameToken = "#Tool.parametric_builder.name",
    controlHeader = CFG.ToolVersionLabel,
    help = "LMB: Add | RMB: Select | R: Panel | Shift+LMB: Copy",
    description = "Parametric Building Tool",
    cpanelDescription = "A Parametric building addon for better building practices. Made with love by WFL.",
    freeze = "Freeze",
    autoSelectChain = "Auto-select (chain)",
    shiftLmbOffset = "\nShift+LMB Offset:",
    nudgeHeader = "\nNudge (Alt+Arrow/PgUp/PgDn):",
    gridSize = "Grid Size",
    openPanel = "Open Panel",
}

S.UI = {
    mainPanelTitle = CFG.ToolVersionLabel,
    solverTitle = "GParametric",
    variables = "Variables:",
    nodes = "Nodes:",
    projectsSessionOnly = "Projects are session-only. GPara does not save or auto-restore them.",
    noProjects = "No projects yet. Create one, or let another addon populate GPara data into the current session.",
    shareProject = "Share project",
    share = "Share",
    unshare = "Unshare",
    newProjectFolder = "[+] New Project   |   [+] New Folder",
    untitled = "Untitled",
    folder = "Folder",
    applyConstraint = "Apply constraint",
    createLinear = "Create Linear",
    createCircular = "Create Circular",
    createGrid = "Create Grid",
    createHelix = "Create Helix",
    createArc = "Create Arc",
    createGConstraint = "Create GConstraint",
    applyParameterChanges = "Apply Parameter Changes",
    rebuild = "Rebuild",
    captureCurrentPose = "Capture Current Pose",
    captureFromSelectedPConstraint = "Capture From Selected PConstraint",
    flipSolution = "Flip Solution",
    unflipSolution = "Unflip Solution",
    flipSolutionShort = "Flip Sol.",
    unflipSolutionShort = "Unflip Sol.",
    deleteGConstraint = "Delete GConstraint",
    cycleParentRefFace = "Cycle Parent Ref Face",
    cycleChildRefFace = "Cycle Child Ref Face",
    nodeA = "Node A",
    nodeB = "Node B",
    range = "Range:",
    rangeTo = "to",
    step = "step:",
    add = "Add",
}


S.Tabs = {
    projects = "Projects",
    tree = "Tree",
    properties = "Properties",
    pconstraints = "PConstraints",
    gconstraints = "GMod Constraints",
    variables = "Variables",
    settings = "Settings",
}

S.Settings = {
    overlayPreset = "Overlay Preset",
    overlayPresetHelp = "Quick visibility presets for the 3D overlay.",
    presetBalanced = "Balanced",
    presetClean = "Clean",
    presetDebug = "Debug",
    presetOff = "Off",
    enable3DOverlay = "Enable 3D Overlay",
    showNodeLabels = "Show Node Labels",
    showConstraintLinks = "Show Constraint Links",
    showDimensions = "Show Dimensions",
    showLocalOffsets = "Show Local Offsets",
    showLocalAxes = "Show Local Axes",
    overlayDistance = "Overlay Distance",
    nudgeStep = "Nudge Step",
    picking = "PConstraint Picking",
    cornerZone = "Corner Zone",
    edgeZone = "Edge Zone",
    minimumZone = "Minimum Zone",
    resetDefaults = "Reset Settings to Defaults",
    resetConfirmTitle = "Reset Parametric Builder client settings to defaults?",
    resetConfirmBody = "This restores overlay, nudge, and picking preferences.",
    resetConfirmYes = "Reset",
    resetConfirmNo = "Cancel",
    choosePreset = "Choose a preset...",
    presetFull = "Full - labels, links, offsets, dimensions",
    presetNormal = "Normal - labels, links, dimensions",
    presetCleanDetailed = "Clean - links only",
    presetOffDetailed = "Off - hide overlay",
    settingsTitle = "Settings",
    settingsHelp = "Client preferences are archived by convar, so they persist between sessions. Picker settings are also sent to the server for your toolgun picks.",
    overlay = "Overlay",
    overlayDistanceHelp = "Maximum distance before GPara overlay helpers fade out.",
    editing = "Editing",
    nudgeHelp = "Alt + Arrow / PgUp / PgDn moves the selected node by this many units.",
    cornerZoneHelp = "Corner pick radius as a fraction of the face's smallest dimension.",
    edgeZoneHelp = "Edge pick band width as a fraction of the face's smallest dimension.",
    minimumZoneHelp = "Absolute minimum pick zone in Source units. Leave at 0 for pure percentage picking.",
    maintenance = "Maintenance",
}

S.PConstraints = {
    addConstraint = "Add Constraint",
    addDistanceConstraint = "Add Distance Constraint",
    deletePrefix = "Delete PC#",
    delete = "Delete",
    activate = "Activate",
    deactivate = "Deactivate",
    editCreatedMirror = "Edit created mirrors from the mirrored node's Properties or from the PConstraints list.",
    conflictsPrefix = "Conflicts: ",
}

S.Properties = {
    selectNode = "Select a node to edit",
    nodePrefix = "Node: ",
    idPrefix = "ID ",
    label = "Label:",
    notes = "Notes:",
    solverNote = "Solver note: ",
    coupledUIDOF = " coupled UI DOF",
    hiddenMechanismDOF = " hidden mechanism DOF",
    localPosition = "Local Position",
    localAngle = "Local Angle",
    lockedSuffix = " (locked):",
    solverLockedSuffix = " (solver):",
    userLockedSuffix = " (user locked):",
    userUnlockedSuffix = " (user unlocked):",
    posExpr = "Pos Expr:",
    angExpr = "Ang Expr:",
    previewError = "→ (error)",
    mirror = "Mirror",
    mirrorHelp = "Create a parametric mirrored copy of this node around another GPara node. Click Create Mirror, pick the mirror prop with the toolgun, choose X/Y/Z, then confirm.",
    generatedByMirror = "This node is generated by Mirror PC#",
    from = " from ",
    mirrorProp = "Mirror prop: ",
    source = "Source: ",
    mirroredNode = "Mirrored node: ",
    mirrorPlane = "Mirror Plane: ",
    xPlane = "X plane",
    yPlane = "Y plane",
    zPlane = "Z plane",
    deleteMirror = "Delete Mirror",
    pickedMirrorProp = "Picked mirror prop: ",
    create = "Create",
    noMirrors = "No mirrors created from this node yet.",
    pcPrefix = "PC#",
    plane = "  Plane ",
    around = "  Around: ",
    output = "  Output: ",
    createMirror = "Create Mirror",
    mirrorGConstraints = "Mirror GMod constraints",
    mirrorGConstraintsHelp = "Also copy matching GMod constraint definitions onto the mirrored node. Constraints to the mirror prop or already-mirrored counterpart nodes are mirrored; unsupported links are skipped.",
    mirroredAround = "Mirrored around: ",
    planeLabel = "\nPlane: ",
    editOrDeleteMirror = "\nEdit or delete this mirror from the PConstraints list.",
    mirrorNodeID = "Mirror Node ID:",
    snapToBounds = "Snap to Bounds",
    parentFacePlaceholder = "Parent Face...",
    childFacePlaceholder = "Child Face...",
    gap = "Gap:",
    snap = "Snap!",
    stackTop = "Stack Top",
    below = "Below",
    front = "Front",
    back = "Back",
    right = "Right",
    left = "Left",
}

S.HUD = {
    mirrorPickTitle = "MIRROR: PICK MIRROR PROP",
    rightClickCancel = "Right-click to cancel",
    clickFeature = "Click a face, edge, or corner",
    constraintPrefix = "CONSTRAINT: ",
    firstPrefix = "First: ",
    clickSecondFeature = "Click second feature...",
    onFirstProp = "on the first prop (parent)...",
    hoveringPrefix = "Hovering: ",
    invalidDirection = " (no direction — invalid)",
    sourcePrefix = "Source: ",
    mirrorPropPrefix = "Mirror prop: ",
    leftClickMirrorPick = "Left-click to pick this prop. Choose the plane in Properties.",
    aimMirrorPick = "Aim at an existing GPara node/prop, then left-click.",
    mirrorPlanePreview = "The X/Y/Z mirror planes preview on the hovered node.",
    parametricTree = "PARAMETRIC TREE",
    solving = "Solving...",
}

S.ConstraintDisplay = {
    weld = "WELD", axis = "AXIS", ballsocket = "BALL", advballsocket = "ADV.B",
    slider = "SLDR", rope = "ROPE", elastic = "ELST", nocollide = "NCOL", parent = "PAR",
}

S.ModeNames = {
    geometric = "Coincident (touching)",
    parallel = "Parallel (orientation only)",
    perpendicular = "Perpendicular (orientation only)",
    planar = "Planar (same plane)",
    distance = "Distance",
    symmetry = "Symmetry (mirror)",
    mirror = "Mirror",
}




S.GConstraints = {
    generic = "GMod Constraint",
    types = {
        weld = "Weld",
        axis = "Axis",
        advballsocket = "Adv Ballsocket",
        rope = "Rope",
        slider = "Slider",
        elastic = "Elastic",
    },
    options = {
        forcelimit = "Force limit",
        nocollide = "No collide",
        torquelimit = "Torque limit",
        friction = "Friction",
        xmin = "X min",
        xmax = "X max",
        ymin = "Y min",
        ymax = "Y max",
        zmin = "Z min",
        zmax = "Z max",
        xfric = "X friction",
        yfric = "Y friction",
        zfric = "Z friction",
        onlyrotation = "Only rotation",
        length = "Length",
        addlength = "Add length",
        width = "Width",
        material = "Material",
        rigid = "Rigid",
        colorR = "Color R",
        colorG = "Color G",
        colorB = "Color B",
        constant = "Constant",
        damping = "Damping",
        relativeDamping = "Relative damping",
        stretchOnly = "Stretch only",
        lengthHint = "0 = current anchor distance",
    },
    summaryOffPrefix = "[off] ",
    summaryPrefix = "GC#",
    summarySeparator = ": ",
    summaryJoiner = " ↔ ",
    newLabelPrefix = "New ",
    editingPrefix = "Editing GC#",
    anchorTitlePrefix = "Anchor ",
    anchorTitleMiddle = " on ",
    pickFaceEdgeCorner = "Pick a face, edge, or corner",
    firstPropPrefix = "First prop: ",
    clickSecondProp = "Click the second prop",
    clickFirstProp = "Click the first prop",
    anchorsStartAtCenters = "Anchors start at prop centers",
    hoveringPrefix = "Hovering ",
    defaultFeature = "feature",
    currentPrefix = "Current: ",
    manual = "manual",
    pickAnchorPrefix = "Pick face / edge / corner for anchor ",
    localX = "Local X",
    localY = "Local Y",
    localZ = "Local Z",
    pitch = "Pitch",
    yaw = "Yaw",
    roll = "Roll",
    constraintOptions = "Constraint Options",
    editTitle = "Edit GMod Constraint",
    createTitle = "Create GMod Constraint",
    between = " between ",
    andText = " and ",
    name = "Name",
    enabled = "Enabled",
    showAnchors = "Show anchors",
    anchorA = "Anchor A",
    anchorB = "Anchor B",
    applyChanges = "Apply Changes",
    deleteConstraint = "Delete Constraint",
    deleteConfirmTitlePrefix = "Delete GC#",
    deleteConfirmTitleSuffix = "?",
    confirm = "Confirm",
    delete = "Delete",
    cancel = "Cancel",
    createConstraint = "Create Constraint",
    cancelDraft = "Cancel Draft",
    addNewConstraint = "Add New Constraint",
    noActiveProject = "Create or select a project first",
    existingTitle = "Existing GMod Constraints",
    emptyHelp = "No GMod constraints yet. Pick a type above, then click Add New Constraint.",
    nodePrefix = "Node ",
    unknownNode = "?",
    pickerCancelled = "Cancelled",
    notInActiveGraph = "That prop is not in the active GPara graph",
    pickHighlightedProp = "Pick on the highlighted constraint prop",
    noFeature = "No selectable face, edge, or corner found",
    firstPropCleared = "First prop cleared",
    defaultAnchorsFailed = "Could not create default anchors",
    pickAnchorOverlayPrefix = "Pick anchor ",
}

S.Tool.overlayHeader = "\nOverlay:"
S.Tool.resetPanelLayout = "Reset Menu Size / Position / Tab"

S.Tree = {
    addRoot = "Add Root",
    removeAllConfirm = "Remove all?",
    setParent = "Set Parent",
    root = "(Root)",
    deleteChildren = "Delete + Children",
    empty = "No nodes. LMB a prop to add!",
    selectedPrefix = "Selected: ",
    notInGraphHint = "Not in graph — LMB to add",
    hide = "Hide",
    show = "Show",
    sharedSuffix = " [shared]",
    manualSuffix = " [free]",
    disableAutoManage = "Enable Free Mode",
    enableAutoManage = "Disable Free Mode",
    refresh = "Refresh",
    propagate = "Propagate",
    clear = "Clear",
    yes = "Yes",
    no = "No",
}

S.Patterns = {
    patternSuffix = " (Pattern)",
    patternPrefix = "Pattern: ",
    spacingX = "Spacing X:",
    spacingY = "Spacing Y:",
    legacyRemoved = "Legacy pattern-constraint output has been removed from the UI in favor of the GMod Constraints tab.",
    itemsPrefix = "Items: ",
}

S.Log = {
    consoleFormat = "[GPara %s] %s",
    trace = "TRACE",
    info = "INFO",
    warn = "WARN",
    error = "ERROR",
}

S.ResetLayoutNotification = "GParametric menu layout reset"

S.ProjectMenus = {
    share = "Share...",
    newProjectHere = "New Project Here",
    newProjectTitle = "New Project",
    namePrompt = "Name:",
    newSubfolder = "New Subfolder",
    newFolderTitle = "New Folder",
    folderDefault = "Folder",
    rename = "Rename",
    renameFolderTitle = "Rename Folder",
    deleteMoveContents = "Delete (move contents to parent)",
    deleteContents = "Delete + Contents",
    deleteAll = "Delete All",
    confirmDelete = "Confirm Delete",
    confirmRecursiveDelete = "Confirm Recursive Delete",
    deleteProjectPrefix = "Delete project '",
    deleteProjectSuffix = "'? This cannot be undone.",
    deleteFolderPrefix = "Delete folder '",
    deleteFolderSuffix = "' and ALL projects inside? This cannot be undone.",
}




S.PConstraints.targetDistance = "Target Distance"
S.PConstraints.offsetLift = "Offset (Lift Off)"
S.PConstraints.parentEdgePos = "Parent Edge Pos (0-1)"
S.PConstraints.childEdgePos = "Child Edge Pos (0-1)"
S.PConstraints.sidePrefix = "Side "
S.PConstraints.facePrefix = "Face "
S.PConstraints.edgePrefix = "Edge "
S.PConstraints.cornerPrefix = "Corner "
S.PConstraints.pointPrefix = "Pt "
S.PConstraints.unknown = "?"
S.PConstraints.mirrorPrefix = "Mirror "
S.PConstraints.mirrorOutputNote = "Parametric mirror output. The mirrored node is generated from the source node across the selected mirror plane."
S.PConstraints.prefix = "PC#"
S.PConstraints.pcPrefix = "PC#"
S.PConstraints.flippedTag = " [FLIPPED]"
S.PConstraints.pluralSuffix = "s"
S.SolverSummary = {
    equationsUnknowns = "Equations: %d  |  Unknowns: %d",
    branchTriesPrefix = "  |  Branch tries: ",
    iterationsResidual = "Iterations: %d  |  Residual: %.4f%s",
    modelAttempt = "Model: %s  |  Attempt: %s",
    statusCompact = "Eqs: %d | Unknowns: %d | Iter: %d | Residual: %.4f | ρ: %.2f",
    detailCompact = "Model: %s | Attempt: %s",
    conflictsPrefix = "Conflicts: ",
}

S.Messages = {
    solverCoroutineError = "solver coroutine error: ",
    unsupportedGConstraint = "Unsupported GMod constraint type",
    pickTwoPBProps = "Pick two valid GPara props first",
    createGConstraintFailed = "Could not create GMod constraint",
    updatedGCPrefix = "Updated GC#",
    removedGCPrefix = "Removed GC#",
    undoPrefix = "Undone ",
    noGraph = "No graph",
    selectValidSourceNode = "Select a valid source node",
    pickValidMirrorNode = "Pick a valid mirror node",
    sourceNodeHasNoProp = "Source node has no prop",
    mirrorNodeHasNoProp = "Mirror node has no prop",
    rateLimited = "Rate limited",
    computeMirrorFailed = "Could not compute mirror transform",
    createPropFailed = "Could not create prop",
    nodePrefix = "Node ",
    mirrorSuffix = " Mirror",
    mirrorUndoPrefix = "GPara Mirror: ",
    aimAtProp = "Aim at a prop",
    alreadyInGraph = "Already in graph",
    rootUndoPrefix = "GPara Root: ",
    rootPrefix = "Root: ",
    legacyManualRemoved = "Legacy manual/source constraints have been removed. Use the GMod Constraints tab instead.",
    shown = " shown",
    hidden = " hidden",
    kernelDebugMissing = "Kernel debug module not loaded",
    refreshedFromWorld = "Refreshed from world",
    reparentCycle = "Can't reparent (cycle)",
    createCycle = "Can't create (cycle?)",
    createDistanceFailed = "Can't create distance PC",
    distancePCPrefix = "Distance PC#",
    symmetryDisabled = "Symmetry is disabled in the single-solver build",
    mirrorPCPrefix = "Mirror PC#",
    unknownPCField = "Unknown PC field: ",
    removedMirrorPCPrefix = "Removed Mirror PC#",
    removedMirrorPCSuffix = " and mirrored prop",
    removedPCPrefix = "Removed PC#",
    flippedSolution = " flipped solution",
    flipped = " flipped",
    unflippedSolution = " unflipped solution",
    unflipped = " unflipped",
    selectNonPattern = "Select non-pattern",
    unknownPattern = "Unknown pattern",
    patternUndoMiddle = " pattern: ",
    patternUndoSuffix = " items",
    patternUpdated = "Pattern updated",
    mirrorPickerHelp = "Use the node Properties > Mirror picker, or run ",
    mirrorPickerCommandHelp = "create_mirror_pc <sourceNodeID> <mirrorNodeID> <x|y|z>",
    savesRemoved = "GPara no longer saves projects. Use another addon to persist props/parametrics.",
    loadsRemoved = "GPara no longer loads saved projects. Projects are session-only.",
}

S.SolverStatus = {
    ok = "Solved",
    solved_redundant = "Solved (redundant constraints present)",
    under_constrained = "Under-Constrained (free DOFs remain)",
    under_constrained_with_conflicts = "Under-Constrained + Conflicting Constraints",
    singular = "Singular / Ambiguous Configuration",
    ill_conditioned = "Ill-Conditioned / Numerically Fragile",
    over_constrained = "Conflicting Constraints (check flagged PCs)",
    diverged = "Did Not Converge (state preserved)",
    unknown = "No solver data",
}


function CFG.CVar(key)
    local entry = CFG.ConVars and CFG.ConVars[key]
    return entry and entry.name or nil
end

function CFG.MakeColor(r, g, b, a)
    return Color(r or 255, g or 255, b or 255, a == nil and 255 or a)
end

function CFG.ColorWithAlpha(color, alpha)
    color = color or COL.white
    return Color(color.r or 255, color.g or 255, color.b or 255, alpha == nil and (color.a or 255) or alpha)
end
