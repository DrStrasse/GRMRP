



















PB = PB or {}

local SE3 = PB.SE3

PB.Solver = PB.Solver or {}
local Solver = PB.Solver

local CFG = PB.Config or {}
Solver.CONFIG = {
    maxIterations       = 3000,
    maxLambda           = 1e20,
    maxLambdaRestarts   = 8,
    lambda0             = 1e-3,
    lambdaGrow          = 8,
    lambdaShrink        = 0.35,
    convergenceResidual = 1e-5,
    convergenceStep     = 1e-5,
    angularScale        = 48.0,






    softAnchorWeight    = 0.01,
    driveWeight         = 1.0,
    satTol              = 0.05,
    conflictTol         = 0.5,





    nullRecomputeEvery     = 25,
    nullRecomputeStepNorm  = 1.0,

    yieldMS                = 6,

    maxConsecutiveSingular = 6,
}
if CFG.Solver then for k,v in pairs(CFG.Solver) do Solver.CONFIG[k] = v end end

local CV = CFG.ConVars or {}
local function makeCVar(key, fallback, default, help)
    local d = CV[key] or {}
    if not CreateConVar then return nil end
    return CreateConVar(d.name or fallback, d.default or default, FCVAR_ARCHIVE, d.help or help)
end
local cvMaxIter   = makeCVar("solverMaxIterations", (CFG.CommandPrefix or "parametric_builder_") .. "solver_max_iterations", tostring(Solver.CONFIG.maxIterations), (CV.solverMaxIterations or {}).help)
local cvMaxLam    = makeCVar("solverMaxLambda", (CFG.CommandPrefix or "parametric_builder_") .. "solver_max_lambda", tostring(Solver.CONFIG.maxLambda), (CV.solverMaxLambda or {}).help)
local function getMaxIter() return cvMaxIter and math.max(1, cvMaxIter:GetInt()) or Solver.CONFIG.maxIterations end
local function getMaxLambda() return cvMaxLam and math.max(1, tonumber(cvMaxLam:GetString()) or 1e16) or Solver.CONFIG.maxLambda end





local function isFinite(x)
    return type(x) == "number" and x == x and x ~= math.huge and x ~= -math.huge
end





local function wrapRad(x)
    if not isFinite(x) then return 0 end
    local TWO_PI = 2 * math.pi
    x = x - TWO_PI * math.floor((x + math.pi) / TWO_PI)
    return x
end

local function zeros(m, n)
    local M = {}
    for i = 1, m do local r = {} for j = 1, n do r[j] = 0 end M[i] = r end
    return M
end

local function dot(a, b)
    local s = 0 for i = 1, #a do s = s + (a[i] or 0) * (b[i] or 0) end return s
end

local function vnorm(v) return math.sqrt(dot(v, v)) end

local function copyMat(A)
    local o = {}
    for i = 1, #A do local r = {} for j = 1, #(A[i] or {}) do r[j] = A[i][j] end o[i] = r end
    return o
end

local function gaussSolve(A, b, pivotTol)
    local n = #A
    if n == 0 then return {}, true end
    local M, rhs = copyMat(A), {}
    for i = 1, n do rhs[i] = b[i] or 0 end
    for k = 1, n do
        local best, bi = math.abs(M[k][k] or 0), k
        for i = k+1, n do local a = math.abs(M[i][k] or 0) if a > best then best, bi = a, i end end
        if best <= (pivotTol or 1e-10) then return nil, false end
        if bi ~= k then M[k], M[bi] = M[bi], M[k] rhs[k], rhs[bi] = rhs[bi], rhs[k] end
        local piv = M[k][k]
        for i = k+1, n do
            local f = (M[i][k] or 0) / piv
            if f ~= 0 then
                M[i][k] = 0
                for j = k+1, n do M[i][j] = (M[i][j] or 0) - f * (M[k][j] or 0) end
                rhs[i] = rhs[i] - f * rhs[k]
            end
        end
    end
    local x = {}
    for i = n, 1, -1 do
        local s = rhs[i]
        for j = i+1, n do s = s - (M[i][j] or 0) * (x[j] or 0) end


        x[i] = s / M[i][i]
    end
    return x, true
end


local function buildRowBasis(A, tol)
    local basis, eps = {}, tol or 1e-10
    for i = 1, #A do
        local v = {} for j = 1, #(A[i] or {}) do v[j] = A[i][j] or 0 end
        for pass = 1, 2 do
            for _, b in ipairs(basis) do
                local c = dot(v, b)
                if c ~= 0 then for j = 1, #v do v[j] = v[j] - c * b[j] end end
            end
        end
        local n = vnorm(v)
        if n > eps then for j = 1, #v do v[j] = v[j] / n end basis[#basis+1] = v end
    end
    return basis
end


local function rankTol(A)
    local maxAbs, rows, cols = 0, #A, 0
    for i = 1, #A do
        cols = math.max(cols, #(A[i] or {}))
        for j = 1, #(A[i] or {}) do
            local a = math.abs(A[i][j] or 0)
            if a > maxAbs then maxAbs = a end
        end
    end



    return math.max(1e-9, maxAbs * math.max(rows, cols, 1) * 1e-8)
end

local function stableRowBasis(A)
    return buildRowBasis(A, rankTol(A))
end


local function nullProject(q, rowBasis)
    local p = {} for i = 1, #q do p[i] = q[i] or 0 end
    for pass = 1, 2 do
        for _, b in ipairs(rowBasis) do
            local c = dot(p, b)
            if c ~= 0 then for i = 1, #p do p[i] = p[i] - c * b[i] end end
        end
    end
    return p
end



local function computeNullBasis(rowBasis, n)
    local nullity = n - #rowBasis
    if nullity <= 0 or n == 0 then return {} end
    local basis = {}
    for i = 1, n do
        local e = {} for j = 1, n do e[j] = (i == j) and 1 or 0 end
        local p = nullProject(e, rowBasis)
        for pass = 1, 2 do
            for _, b in ipairs(basis) do
                local c = dot(p, b)
                if c ~= 0 then for j = 1, #p do p[j] = p[j] - c * b[j] end end
            end
        end
        local pn = vnorm(p)
        if pn > 1e-10 then
            for j = 1, #p do p[j] = p[j] / pn end
            basis[#basis+1] = p
        end
        if #basis >= nullity then break end
    end
    return basis
end





local function vcopy(v) return Vector(v.x or 0, v.y or 0, v.z or 0) end

local function safeNorm(v, fb)
    local o = vcopy(v or fb or Vector(1,0,0))
    if o:LengthSqr() <= 1e-12 then o = vcopy(fb or Vector(1,0,0)) end
    if o:LengthSqr() <= 1e-12 then o = Vector(1,0,0) end
    o:Normalize() return o
end

local function orthoBasisFromZ(z, xHint)
    local zN = safeNorm(z, Vector(0,0,1))
    local ref = xHint and safeNorm(xHint) or nil
    if not ref or math.abs(ref:Dot(zN)) > 0.98 then
        ref = math.abs(zN.x) < 0.8 and Vector(1,0,0) or Vector(0,1,0)
    end
    local x = ref - zN * ref:Dot(zN)
    if x:LengthSqr() <= 1e-12 then
        ref = math.abs(zN.z) < 0.8 and Vector(0,0,1) or Vector(0,1,0)
        x = ref - zN * ref:Dot(zN)
    end
    x:Normalize()
    local y = zN:Cross(x) y:Normalize()
    return x, y, zN
end

local function featureFrameLocal(node, feature, fraction, branchSide)
    if not node or not IsValid(node.entity) or not feature then return nil end
    local kind = tostring(feature.type or "")
    if kind == "face" then
        local n = vcopy(PB.GetFaceLocalNormal(node.entity, feature.id))
        local x, y, z = orthoBasisFromZ(n)
        return { kind="plane", origin=vcopy(PB.GetFaceCenter(node.entity, feature.id)),
                 x=x, y=y, z=z, sideNormals={{dir=vcopy(z), faceID=feature.id}} }
    elseif kind == "edge" then
        local origin = vcopy(PB.GetEdgeLocalPoint(node.entity, feature.id, fraction or 0.5))
        local dir = vcopy(PB.GetEdgeLocalDir(node.entity, feature.id))
        local sn1, f1 = PB.GetEdgeLocalSideNormal(node.entity, feature.id, branchSide or 1)
        local x, y, z = orthoBasisFromZ(dir, sn1)
        local sn2, f2 = PB.GetEdgeLocalSideNormal(node.entity, feature.id, (branchSide or 1)==1 and 2 or 1)
        return { kind="line", origin=origin, x=x, y=y, z=z,
                 sideNormals={{dir=safeNorm(sn1,x), faceID=f1}, {dir=safeNorm(sn2,y), faceID=f2}} }
    elseif kind == "corner" then
        return { kind="point", origin=vcopy(PB.GetCornerLocalPos(node.entity, feature.id)),
                 x=Vector(1,0,0), y=Vector(0,1,0), z=Vector(0,0,1), sideNormals={} }
    end
    return nil
end

local function applyAttachParams(frame, pc)
    if not frame then return nil end
    local sx = tonumber(pc and pc.slideX) or 0
    local sy = tonumber(pc and pc.slideY) or 0
    local off = tonumber(pc and pc.offset) or 0
    local ang = tonumber(pc and pc.angle) or 0
    if sx==0 and sy==0 and off==0 and ang==0 then return frame end
    local T = { pos=vcopy(frame.origin), R={
        {frame.x.x, frame.y.x, frame.z.x}, {frame.x.y, frame.y.y, frame.z.y}, {frame.x.z, frame.y.z, frame.z.z}} }
    local a = math.rad(ang) local c, s = math.cos(a), math.sin(a)
    local adj = { pos=Vector(sx, sy, off), R={{c,-s,0},{s,c,0},{0,0,1}} }
    local out = SE3.compose(T, adj)
    return { kind=frame.kind, origin=vcopy(out.pos),
             x=SE3.mvec(out.R, Vector(1,0,0)), y=SE3.mvec(out.R, Vector(0,1,0)),
             z=SE3.mvec(out.R, Vector(0,0,1)), sideNormals=frame.sideNormals }
end

local function captureFrame(graph, pc, which)
    local node, feature, frac, bs
    if which == "A" then
        node = graph.nodes[pc.parentNodeID] feature = pc.parentFeature
        frac = tonumber(pc.parentFraction) or 0.5 bs = tonumber(pc.branchParentSide) or 1
    else
        node = graph.nodes[pc.childNodeID] feature = pc.childFeature
        frac = tonumber(pc.childFraction) or 0.5 bs = tonumber(pc.branchChildSide) or 1
    end
    local frame = featureFrameLocal(node, feature, frac, bs)
    if which == "B" then frame = applyAttachParams(frame, pc) end
    return frame
end


PB.KernelConstraints = PB.KernelConstraints or {}
function PB.KernelConstraints.CaptureNodeGeometry(node)
    return { model = node and node.model or "" }
end
function PB.KernelConstraints.GetFeatureFrame(body, feature, pose, fraction)
    local node = body and body.node or nil
    if not node then return nil end
    local lf = featureFrameLocal(node, feature, fraction or 0.5, 1)
    if not lf then return nil end
    local wT = SE3.fromPosAng((pose and pose.worldPos) or node.worldPos, (pose and pose.worldAngle) or node.worldAngle)
    return { kind=lf.kind, origin=SE3.apply(wT, lf.origin), dir=SE3.applyRot(wT, lf.z),
             x=SE3.applyRot(wT, lf.x), y=SE3.applyRot(wT, lf.y), z=SE3.applyRot(wT, lf.z),
             sideNormals=lf.sideNormals }
end





local function J3x6(Jv, Jw)
    local M = {{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}}
    for i = 1,3 do M[i][1]=Jv[i][1] M[i][2]=Jv[i][2] M[i][3]=Jv[i][3]
                   M[i][4]=Jw[i][1] M[i][5]=Jw[i][2] M[i][6]=Jw[i][3] end
    return M
end

local function addRows(out, info, r, JA, JB, angular)
    for i = 1, #r do
        out[#out+1] = { r=r[i], JA=JA and JA[i], JB=JB and JB[i], angular=angular or false,
                        pcid=info and info.pcid, mode=info and info.mode }
    end
end

local function rowsPointCoincident(wA, aA, wB, aB, info)
    local oA, oB = SE3.apply(wA, aA.origin), SE3.apply(wB, aB.origin)
    local d = SE3.vsub(oA, oB)
    local JA = J3x6(SE3.pointJacobian(wA, aA.origin))
    local JB = J3x6(SE3.pointJacobian(wB, aB.origin))
    for i=1,3 do for j=1,6 do JB[i][j] = -JB[i][j] end end
    local rows = {} addRows(rows, info, {d.x, d.y, d.z}, JA, JB, false) return rows
end

local function rowsPointOnPlane(wPl, aPl, wPt, aPt, info, swap)
    local oP = SE3.apply(wPl, aPl.origin)
    local nP = SE3.applyRot(wPl, aPl.z)
    local oPt = SE3.apply(wPt, aPt.origin)
    local q = SE3.vsub(oPt, oP)
    local r = SE3.vdot(q, nP)
    local JoP = J3x6(SE3.pointJacobian(wPl, aPl.origin))
    local JnP = J3x6(SE3.directionJacobian(wPl, aPl.z))
    local JoPt = J3x6(SE3.pointJacobian(wPt, aPt.origin))
    local rPl, rPt = {0,0,0,0,0,0}, {0,0,0,0,0,0}
    for j=1,6 do
        rPl[j] = -(JoP[1][j]*nP.x + JoP[2][j]*nP.y + JoP[3][j]*nP.z)
                +  (q.x*JnP[1][j] + q.y*JnP[2][j] + q.z*JnP[3][j])
        rPt[j] =   JoPt[1][j]*nP.x + JoPt[2][j]*nP.y + JoPt[3][j]*nP.z
    end
    local rows = {}
    if not swap then addRows(rows, info, {r}, {rPl}, {rPt}, false)
    else addRows(rows, info, {r}, {rPt}, {rPl}, false) end
    return rows
end

local function rowsAxesParallel(wA, aA, wB, aB, info)
    local xA = SE3.applyRot(wA, aA.x) local yA = SE3.applyRot(wA, aA.y)
    local zB = SE3.applyRot(wB, aB.z)
    local JxA = J3x6(SE3.directionJacobian(wA, aA.x))
    local JyA = J3x6(SE3.directionJacobian(wA, aA.y))
    local JzB = J3x6(SE3.directionJacobian(wB, aB.z))
    local rAx,rAy,rBx,rBy = {0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}
    for j=1,6 do
        rAx[j] = zB.x*JxA[1][j] + zB.y*JxA[2][j] + zB.z*JxA[3][j]
        rAy[j] = zB.x*JyA[1][j] + zB.y*JyA[2][j] + zB.z*JyA[3][j]
        rBx[j] = xA.x*JzB[1][j] + xA.y*JzB[2][j] + xA.z*JzB[3][j]
        rBy[j] = yA.x*JzB[1][j] + yA.y*JzB[2][j] + yA.z*JzB[3][j]
    end
    local rows = {} addRows(rows, info, {SE3.vdot(xA,zB), SE3.vdot(yA,zB)}, {rAx,rAy}, {rBx,rBy}, true)
    return rows
end

local function rowsAxesPerp(wA, aA, wB, aB, info)
    local zA, zB = SE3.applyRot(wA, aA.z), SE3.applyRot(wB, aB.z)
    local JzA = J3x6(SE3.directionJacobian(wA, aA.z))
    local JzB = J3x6(SE3.directionJacobian(wB, aB.z))
    local rA, rB = {0,0,0,0,0,0}, {0,0,0,0,0,0}
    for j=1,6 do
        rA[j] = zB.x*JzA[1][j] + zB.y*JzA[2][j] + zB.z*JzA[3][j]
        rB[j] = zA.x*JzB[1][j] + zA.y*JzB[2][j] + zA.z*JzB[3][j]
    end
    local rows = {} addRows(rows, info, {SE3.vdot(zA,zB)}, {rA}, {rB}, true) return rows
end

local function rowsPointOnLine(wL, aL, wP, aP, info, swap)
    local oL = SE3.apply(wL, aL.origin)
    local xL, yL = SE3.applyRot(wL, aL.x), SE3.applyRot(wL, aL.y)
    local oP = SE3.apply(wP, aP.origin)
    local q = SE3.vsub(oP, oL)
    local JoL = J3x6(SE3.pointJacobian(wL, aL.origin))
    local JxL = J3x6(SE3.directionJacobian(wL, aL.x))
    local JyL = J3x6(SE3.directionJacobian(wL, aL.y))
    local JoP = J3x6(SE3.pointJacobian(wP, aP.origin))
    local rLx,rLy,rPx,rPy = {0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0},{0,0,0,0,0,0}
    for j=1,6 do
        rLx[j] = -(JoL[1][j]*xL.x + JoL[2][j]*xL.y + JoL[3][j]*xL.z)
                +  (q.x*JxL[1][j] + q.y*JxL[2][j] + q.z*JxL[3][j])
        rLy[j] = -(JoL[1][j]*yL.x + JoL[2][j]*yL.y + JoL[3][j]*yL.z)
                +  (q.x*JyL[1][j] + q.y*JyL[2][j] + q.z*JyL[3][j])
        rPx[j] = JoP[1][j]*xL.x + JoP[2][j]*xL.y + JoP[3][j]*xL.z
        rPy[j] = JoP[1][j]*yL.x + JoP[2][j]*yL.y + JoP[3][j]*yL.z
    end
    local rows = {}
    if not swap then addRows(rows, info, {SE3.vdot(q,xL), SE3.vdot(q,yL)}, {rLx,rLy}, {rPx,rPy}, false)
    else addRows(rows, info, {SE3.vdot(q,xL), SE3.vdot(q,yL)}, {rPx,rPy}, {rLx,rLy}, false) end
    return rows
end

local function rowsDistance(wA, aA, wB, aB, target, info)
    local oA, oB = SE3.apply(wA, aA.origin), SE3.apply(wB, aB.origin)
    local d = SE3.vsub(oA, oB) local len = SE3.vnorm(d)
    local dir = len < 1e-9 and {1,0,0} or {d.x/len, d.y/len, d.z/len}
    local JoA = J3x6(SE3.pointJacobian(wA, aA.origin))
    local JoB = J3x6(SE3.pointJacobian(wB, aB.origin))
    local rA, rB = {0,0,0,0,0,0}, {0,0,0,0,0,0}
    for j=1,6 do
        rA[j] =  dir[1]*JoA[1][j] + dir[2]*JoA[2][j] + dir[3]*JoA[3][j]
        rB[j] = -dir[1]*JoB[1][j] - dir[2]*JoB[2][j] - dir[3]*JoB[3][j]
    end
    local rows = {} addRows(rows, info, {len - (tonumber(target) or 100)}, {rA}, {rB}, false)
    return rows
end

local function rowsFaceFace(wA, aA, wB, aB, info)
    local rows = rowsAxesParallel(wA, aA, wB, aB, info)
    for _, r in ipairs(rowsPointOnPlane(wA, aA, wB, aB, info, false)) do rows[#rows+1] = r end
    return rows
end

local function rowsLineInPlane(wL, aL, wPl, aPl, info, swap)
    local rows = rowsPointOnPlane(wPl, aPl, wL, aL, info, true)
    for _, r in ipairs(rowsAxesPerp(wL, aL, wPl, aPl, info)) do rows[#rows+1] = r end
    if swap then for _, r in ipairs(rows) do r.JA, r.JB = r.JB, r.JA end end
    return rows
end

local function rowsPlanar(pair, wA, aA, wB, aB, info)
    if pair == "face:face" then
        return rowsFaceFace(wA, aA, wB, aB, info)
    elseif pair == "face:corner" then
        return rowsPointOnPlane(wA, aA, wB, aB, info, false)
    elseif pair == "corner:face" then
        return rowsPointOnPlane(wB, aB, wA, aA, info, true)
    elseif pair == "face:edge" then
        return rowsLineInPlane(wB, aB, wA, aA, info, true)
    elseif pair == "edge:face" then
        return rowsLineInPlane(wA, aA, wB, aB, info, false)
    end
    return {}
end





local function buildConstraintRows(graph, pc, wA, aA, wB, aB)
    local info = { pcid=pc.id, mode=pc.mode }
    if pc.mode == "parallel"      then return rowsAxesParallel(wA, aA, wB, aB, info) end
    if pc.mode == "perpendicular" then return rowsAxesPerp(wA, aA, wB, aB, info) end
    if pc.mode == "distance"      then return rowsDistance(wA, aA, wB, aB, pc.distance, info) end

    local pair = (pc.parentFeature and pc.parentFeature.type or "") .. ":" .. (pc.childFeature and pc.childFeature.type or "")
    if pc.mode == "planar" then return rowsPlanar(pair, wA, aA, wB, aB, info) end

    if pair == "face:face"     then return rowsFaceFace(wA, aA, wB, aB, info)
    elseif pair == "edge:edge" then
        local rows = rowsPointOnLine(wA, aA, wB, aB, info, false)
        for _, r in ipairs(rowsAxesParallel(wA, aA, wB, aB, info)) do rows[#rows+1] = r end
        return rows
    elseif pair == "corner:corner" then return rowsPointCoincident(wA, aA, wB, aB, info)
    elseif pair == "face:corner"   then return rowsPointOnPlane(wA, aA, wB, aB, info, false)
    elseif pair == "corner:face"   then return rowsPointOnPlane(wB, aB, wA, aA, info, true)
    elseif pair == "edge:corner"   then return rowsPointOnLine(wA, aA, wB, aB, info, false)
    elseif pair == "corner:edge"   then return rowsPointOnLine(wB, aB, wA, aA, info, true)
    elseif pair == "face:edge"     then return rowsLineInPlane(wB, aB, wA, aA, info, true)
    elseif pair == "edge:face"     then return rowsLineInPlane(wA, aA, wB, aB, info, false)
    end
    return rowsPointCoincident(wA, aA, wB, aB, info)
end





local function resolveLocal(graph, node)
    local lp = PB.ResolveLocalPos and PB.ResolveLocalPos(graph, node) or node.localPos
    local la = PB.ResolveLocalAngle and PB.ResolveLocalAngle(graph, node) or node.localAngle
    return Vector(lp.x, lp.y, lp.z), Angle(la.p, la.y, la.r)
end

local function isFixed(graph, node)
    if not node or node.isPattern or node.isMirrorGenerated then return true end
    return (not node.parentID) or (not graph.nodes[node.parentID])
end

local function buildWorldFromTree(graph)
    for _, nid in ipairs(PB.TreeOrder(graph)) do
        local node = graph.nodes[nid]
        if node and not node.isPattern then
            local lp, la = resolveLocal(graph, node)
            if node.parentID and graph.nodes[node.parentID] then
                local p = graph.nodes[node.parentID]
                local wp, wa = LocalToWorld(lp, la, p.worldPos, p.worldAngle)
                node.worldPos, node.worldAngle = Vector(wp.x, wp.y, wp.z), Angle(wa.p, wa.y, wa.r)
            else
                node.worldPos, node.worldAngle = Vector(lp.x, lp.y, lp.z), Angle(la.p, la.y, la.r)
            end
        end
    end
end

local function writeLocalBack(graph, state)




    for _, nid in ipairs(state and state.movableIDs or {}) do
        local node = graph.nodes[nid]
        if node and not node.isPattern then
            if node.parentID and graph.nodes[node.parentID] then
                local p = graph.nodes[node.parentID]
                local lp, la = WorldToLocal(node.worldPos, node.worldAngle, p.worldPos, p.worldAngle)
                node.localPos, node.localAngle = Vector(lp.x, lp.y, lp.z), Angle(la.p, la.y, la.r)
            else
                node.localPos = Vector(node.worldPos.x, node.worldPos.y, node.worldPos.z)
                node.localAngle = Angle(node.worldAngle.p, node.worldAngle.y, node.worldAngle.r)
            end
        end
    end
end








local function bodyFrameError(T_cur, T_init)
    local dp = SE3.vsub(T_cur.pos, T_init.pos)
    local RT = SE3.mtrans(T_cur.R)
    local bdp = SE3.mvec(RT, dp)
    local dR = SE3.mmul(RT, T_init.R)
    local logv = SE3.logSO3(dR)
    return { bdp.x, bdp.y, bdp.z, -(logv.x or 0), -(logv.y or 0), -(logv.z or 0) }
end





local UI_AXES = {
    {f="pos", a="x"}, {f="pos", a="y"}, {f="pos", a="z"},
    {f="ang", a="p"}, {f="ang", a="y"}, {f="ang", a="r"},
}

local function uiAxisQ6(Tn, Tp, family, axis)
    local RnT = SE3.mtrans(Tn.R)
    if family == "pos" then
        local localAxis = axis=="x" and Vector(1,0,0) or axis=="y" and Vector(0,1,0) or Vector(0,0,1)
        local pR = Tp and Tp.R or SE3.identity3()
        local inWorld = SE3.mvec(pR, localAxis)
        local inBody = SE3.mvec(RnT, inWorld)
        return {inBody.x, inBody.y, inBody.z, 0, 0, 0}
    else
        local Rlocal = Tp and SE3.mmul(SE3.mtrans(Tp.R), Tn.R) or Tn.R
        local la = SE3.toAngle(Rlocal)
        local p, r = math.rad(la.p or 0), math.rad(la.r or 0)
        local sp, cp, sr, cr = math.sin(p), math.cos(p), math.sin(r), math.cos(r)
        local w
        if axis == "r" then w = Vector(1, 0, 0)
        elseif axis == "p" then w = Vector(0, cr, -sr)
        else w = Vector(-sp, sr*cp, cr*cp) end
        return {0, 0, 0, w.x, w.y, w.z}
    end
end











local function computeFreeUIAxes(graph, state, Jphys)
    local axes = {}
    local n = #state.movableIDs * 6

    local function all(v)
        return { pos={x=v,y=v,z=v}, ang={p=v,y=v,r=v} }
    end

    for _, nid in ipairs(state.nodeOrder or {}) do
        local node = graph.nodes[nid]
        if node and not node.isPattern then
            if isFixed(graph, node) then

                axes[tostring(nid)] = all(true)
            elseif state.passiveSet and state.passiveSet[nid] then



                axes[tostring(nid)] = all(true)
            else
                axes[tostring(nid)] = all(false)
            end
        end
    end

    if n == 0 then return axes end

    local rowBasis = stableRowBasis(Jphys or {})
    local nullBasis = computeNullBasis(rowBasis, n)

    if #nullBasis == 0 then return axes end

    local function addBasis3(basis, v, tol)
        local p = { v[1] or 0, v[2] or 0, v[3] or 0 }
        for pass = 1, 2 do
            for _, b in ipairs(basis) do
                local c = p[1] * b[1] + p[2] * b[2] + p[3] * b[3]
                if c ~= 0 then
                    p[1] = p[1] - c * b[1]
                    p[2] = p[2] - c * b[2]
                    p[3] = p[3] - c * b[3]
                end
            end
        end
        local pn = math.sqrt(p[1] * p[1] + p[2] * p[2] + p[3] * p[3])
        if pn <= (tol or 1e-7) then return false end
        basis[#basis + 1] = { p[1] / pn, p[2] / pn, p[3] / pn }
        return true
    end

    local function residual3(v, basis)
        local p = { v[1] or 0, v[2] or 0, v[3] or 0 }
        for pass = 1, 2 do
            for _, b in ipairs(basis or {}) do
                local c = p[1] * b[1] + p[2] * b[2] + p[3] * b[3]
                if c ~= 0 then
                    p[1] = p[1] - c * b[1]
                    p[2] = p[2] - c * b[2]
                    p[3] = p[3] - c * b[3]
                end
            end
        end
        return math.sqrt(p[1] * p[1] + p[2] * p[2] + p[3] * p[3])
    end

    local function vec3Norm(v)
        return math.sqrt((v[1] or 0) * (v[1] or 0) + (v[2] or 0) * (v[2] or 0) + (v[3] or 0) * (v[3] or 0))
    end

    local function setAxisIfInBasis(entry, family, axis, v, basis, axisTol)
        if not basis or #basis == 0 then return end
        local qn = vec3Norm(v)
        if qn <= 1e-12 then return end
        local err = residual3(v, basis) / qn
        if err <= (axisTol or 1e-4) then
            entry[family][axis] = true
        end
    end






    for _, nid in ipairs(state.movableIDs) do
        local node = graph.nodes[nid]
        local cb = state.colBase[nid]
        local Tn = state.poses[nid]
        local entry = axes[tostring(nid)]

        if node and cb and Tn and entry then
            local tvs, rvs = {}, {}
            local rotBasis, pureTransBasis = {}, {}
            local maxRot = 0

            for _, nb in ipairs(nullBasis) do
                local tv = { nb[cb] or 0, nb[cb + 1] or 0, nb[cb + 2] or 0 }
                local rv = { nb[cb + 3] or 0, nb[cb + 4] or 0, nb[cb + 5] or 0 }
                tvs[#tvs + 1] = tv
                rvs[#rvs + 1] = rv
                local rn = vec3Norm(rv)
                if rn > maxRot then maxRot = rn end
                if rn > 1e-8 then addBasis3(rotBasis, rv, 1e-7) end
            end



            local k = #nullBasis
            if k > 0 then
                local angularRows = { {}, {}, {} }
                for j = 1, k do
                    angularRows[1][j] = rvs[j][1] or 0
                    angularRows[2][j] = rvs[j][2] or 0
                    angularRows[3][j] = rvs[j][3] or 0
                end

                local coeffRowBasis = stableRowBasis(angularRows)
                local coeffBasis = computeNullBasis(coeffRowBasis, k)
                for _, coeff in ipairs(coeffBasis) do
                    local v = { 0, 0, 0 }
                    for j = 1, k do
                        local c = coeff[j] or 0
                        if c ~= 0 then
                            v[1] = v[1] + c * (tvs[j][1] or 0)
                            v[2] = v[2] + c * (tvs[j][2] or 0)
                            v[3] = v[3] + c * (tvs[j][3] or 0)
                        end
                    end
                    addBasis3(pureTransBasis, v, 1e-7)
                end
            end

            local parent = node.parentID and graph.nodes[node.parentID] or nil
            local Tp = parent and state.poses[node.parentID] or nil
            local axisTol = 1e-4

            for _, ua in ipairs(UI_AXES) do
                local q6 = uiAxisQ6(Tn, Tp, ua.f, ua.a)
                if q6 then
                    if ua.f == "pos" then
                        setAxisIfInBasis(entry, "pos", ua.a, { q6[1] or 0, q6[2] or 0, q6[3] or 0 }, pureTransBasis, axisTol)
                    elseif ua.f == "ang" and maxRot > 1e-7 then
                        setAxisIfInBasis(entry, "ang", ua.a, { q6[4] or 0, q6[5] or 0, q6[6] or 0 }, rotBasis, axisTol)
                    end
                end
            end
        end
    end

    return axes
end





local function buildPoseState(graph, activeSet)
    local state = {
        nodeOrder    = PB.TreeOrder(graph),
        movableIDs   = {}, fixedIDs = {},
        passiveSet   = {},
        colBase      = {},
        poses        = {},
        activeNodeSet= activeSet,
    }









    local touched = {}
    for _, pc in ipairs(PB.GetAllActivePConstraints(graph) or {}) do
        if pc.mode ~= "mirror" then
            if pc.parentNodeID then touched[pc.parentNodeID] = true end
            if pc.childNodeID  then touched[pc.childNodeID]  = true end
        end
    end
    if graph.nodes then
        for nid, node in pairs(graph.nodes) do
            local ov = istable(node.dofOverrides) and node.dofOverrides or nil
            local hasLock = false
            if ov then
                if istable(ov.pos) then
                    for _, ax in ipairs({"x", "y", "z"}) do
                        if ov.pos[ax] == "lock" then hasLock = true break end
                    end
                end
                if not hasLock and istable(ov.ang) then
                    for _, ax in ipairs({"p", "y", "r"}) do
                        if ov.ang[ax] == "lock" then hasLock = true break end
                    end
                end
            end
            if hasLock then touched[tonumber(nid)] = true end
        end
    end

    if graph._pbEditDrive then
        if istable(graph._pbEditDrive.axes) then
            for _, axisDrive in ipairs(graph._pbEditDrive.axes) do
                if axisDrive.nodeID then touched[tonumber(axisDrive.nodeID)] = true end
            end
        elseif graph._pbEditDrive.nodeID then
            touched[tonumber(graph._pbEditDrive.nodeID)] = true
        end
    end

    for _, nid in ipairs(state.nodeOrder) do
        local node = graph.nodes[nid]
        if node and not node.isPattern then
            state.poses[nid] = SE3.fromPosAng(node.worldPos, node.worldAngle)
            if (not activeSet) or activeSet[nid] then
                if activeSet and activeSet[nid] == "ref" then
                    state.fixedIDs[#state.fixedIDs+1] = nid
                elseif isFixed(graph, node) then
                    state.fixedIDs[#state.fixedIDs+1] = nid
                elseif not touched[nid] then


                    state.passiveSet[nid] = true
                else
                    state.colBase[nid] = #state.movableIDs * 6 + 1
                    state.movableIDs[#state.movableIDs+1] = nid
                end
            end
        end
    end
    return state
end

local function setPCRows(byPC, pc, status, pcRows)
    if not pc or not pc.id then return end
    pcRows = pcRows or {}
    pcRows._status = status or "ok"
    byPC[pc.id] = pcRows
end

local function assemblePhysicalRows(graph, state)
    local rows, byPC = {}, {}
    for _, pc in ipairs(PB.GetAllActivePConstraints(graph)) do
        if pc.mode == "mirror" then
            setPCRows(byPC, pc, "mirror")
        else
            local nA, nB = graph.nodes[pc.parentNodeID], graph.nodes[pc.childNodeID]
            local aSet = state.activeNodeSet
            local inComp = (not aSet) or (aSet[pc.parentNodeID] and aSet[pc.childNodeID])
            local status
            if not inComp then status = "outside_active_component"
            elseif not nA or not nB then status = "missing_node"
            elseif nA.isPattern or nB.isPattern then status = "pattern_node"
            elseif not IsValid(nA.entity) or not IsValid(nB.entity) then status = "invalid_entity"
            elseif not pc.parentFeature or not pc.childFeature then status = "missing_feature" end

            if status then
                setPCRows(byPC, pc, status)
            else
                local aA, aB = captureFrame(graph, pc, "A"), captureFrame(graph, pc, "B")
                if aA and aB then
                    local pcRows = buildConstraintRows(graph, pc, state.poses[pc.parentNodeID], aA, state.poses[pc.childNodeID], aB)
                    setPCRows(byPC, pc, "ok", pcRows)
                    for _, r in ipairs(pcRows) do rows[#rows+1] = r end
                else
                    setPCRows(byPC, pc, "invalid_feature_frame")
                end
            end
        end
    end
    return rows, byPC
end

local function buildJacobian(graph, state, rows)
    local n = #state.movableIDs * 6
    local J, r = zeros(#rows, n), {}




    local nanGuards = 0
    local function safeNum(v)
        if isFinite(v) then return v end
        nanGuards = nanGuards + 1
        return 0
    end

    for i, row in ipairs(rows) do
        if row.isRegulariser then

            r[i] = safeNum(row.r)
            for j = 1, n do J[i][j] = safeNum(row.Jrow[j] or 0) end
        elseif row.isDrive then

            local sc = row.angular and Solver.CONFIG.angularScale or 1.0
            r[i] = safeNum(row.r) * sc
            local cb = state.colBase[row.nodeID]
            if cb and row.J6 then for j=1,6 do J[i][cb+j-1] = safeNum(row.J6[j] or 0)*sc end end
        else

            local sc = row.angular and Solver.CONFIG.angularScale or 1.0
            r[i] = safeNum(row.r) * sc
            local pc = row.pcid and graph.pconstraints[row.pcid] or nil
            if pc then
                local cA = state.colBase[pc.parentNodeID]
                if cA and row.JA then for j=1,6 do J[i][cA+j-1] = safeNum(row.JA[j] or 0)*sc end end
                local cB = state.colBase[pc.childNodeID]
                if cB and row.JB then for j=1,6 do J[i][cB+j-1] = safeNum(row.JB[j] or 0)*sc end end
            end
        end
    end
    return J, r, nanGuards
end

local function normalEqs(J, r, lambda)
    local m, n = #J, (#J > 0 and #J[1]) or 0
    local A, b = zeros(n, n), {}
    for i=1,n do b[i] = 0 end
    for row=1,m do
        local Jr, rr = J[row], r[row] or 0
        local nz = {}
        for i=1,n do local v = Jr[i] or 0 if v ~= 0 then nz[#nz+1] = {i, v} b[i] = b[i] - v*rr end end
        for a=1,#nz do local ia,va = nz[a][1], nz[a][2]
            for bi=a,#nz do local ib,vb = nz[bi][1], nz[bi][2] A[ia][ib] = A[ia][ib] + va*vb end
        end
    end
    for i=1,n do for j=i+1,n do A[j][i] = A[i][j] end end
    for i=1,n do A[i][i] = A[i][i] + lambda * math.max(1, math.abs(A[i][i])) end
    return A, b
end








local function buildErrorVector(state, initPoses)
    local n = #state.movableIDs * 6
    local err = {} for i = 1, n do err[i] = 0 end
    for idx, nid in ipairs(state.movableIDs) do
        local Tc, Ti = state.poses[nid], initPoses[nid]
        if Tc and Ti then
            local e6 = bodyFrameError(Tc, Ti)
            local base = (idx-1)*6
            for i = 1, 6 do err[base+i] = e6[i] end
        end
    end
    return err
end

local function buildRegRows(state, nullBasis, initPoses)
    local n = #state.movableIDs * 6
    local sw = Solver.CONFIG.softAnchorWeight
    local err = buildErrorVector(state, initPoses)
    local rows = {}
    for _, b in ipairs(nullBasis) do
        local r = dot(err, b) * sw
        local Jrow = {} for i = 1, n do Jrow[i] = b[i] * sw end
        rows[#rows+1] = { isRegulariser=true, Jrow=Jrow, r=r }
    end
    return rows
end































local function buildDriveRows(graph, state)
    local d = graph and graph._pbEditDrive or nil
    local rows = {}
    local requested = {}

    if graph and graph.nodes then
        for nid, node in pairs(graph.nodes) do
            local ov = istable(node.dofOverrides) and node.dofOverrides or nil
            if ov and state.colBase[tonumber(nid)] then
                for _, ax in ipairs({"x", "y", "z"}) do
                    if istable(ov.pos) and ov.pos[ax] == "lock" then
                        requested[#requested + 1] = { nodeID = tonumber(nid), family = "pos", axis = ax }
                    end
                end
                for _, ax in ipairs({"p", "y", "r"}) do
                    if istable(ov.ang) and ov.ang[ax] == "lock" then
                        requested[#requested + 1] = { nodeID = tonumber(nid), family = "ang", axis = ax }
                    end
                end
            end
        end
    end

    if not d and #requested == 0 then return rows end
    if istable(d.axes) then
        for _, axisDrive in ipairs(d.axes) do
            requested[#requested + 1] = axisDrive
        end
    elseif d.nodeID then
        requested[#requested + 1] = {
            nodeID = d.nodeID,
            family = d.family,
            axis = d.axis
        }
    end

    if #requested == 0 then return rows end

    graph._pbDriveWarning = nil
    local dw = Solver.CONFIG.driveWeight or 1.0

    for _, req in ipairs(requested) do
        local nid = tonumber(req.nodeID)
        local node = nid and graph.nodes[nid] or nil
        if not node or not state.colBase[nid] then continue end

        local family = tostring(req.family or "")
        local axis = tostring(req.axis or "")
        local validPos = family == "pos" and (axis == "x" or axis == "y" or axis == "z")
        local validAng = family == "ang" and (axis == "p" or axis == "y" or axis == "r")
        if not validPos and not validAng then
            graph._pbDriveWarning = ("unknown drive axis: family=%s axis=%s")
                :format(tostring(req.family), tostring(req.axis))
            continue
        end

        local Tn = state.poses[nid]
        if not Tn then continue end

        local parent = node.parentID and graph.nodes[node.parentID] or nil
        local Tp = parent and state.poses[node.parentID] or nil
        local authPos, authAng = resolveLocal(graph, node)

        if req.target ~= nil then
            local target = tonumber(req.target)
            if target ~= nil then
                if validPos then
                    authPos[axis] = target
                else
                    authAng[axis] = target
                end
            end
        end

        local curPos, curAng
        if parent and Tp then
            local pp, pa = SE3.toPosAng(Tp)
            local np, na = SE3.toPosAng(Tn)
            curPos, curAng = WorldToLocal(np, na, pp, pa)
        else
            local np, na = SE3.toPosAng(Tn)
            curPos = Vector(np.x, np.y, np.z)
            curAng = Angle(na.p, na.y, na.r)
        end

        local q6 = uiAxisQ6(Tn, Tp, family, axis)
        if q6 then
            local err
            if validPos then
                err = axis == "x" and (curPos.x - authPos.x)
                   or axis == "y" and (curPos.y - authPos.y)
                   or                 (curPos.z - authPos.z)
            else
                local cur = axis == "p" and curAng.p or axis == "y" and curAng.y or curAng.r
                local auth = axis == "p" and authAng.p or axis == "y" and authAng.y or authAng.r
                err = wrapRad(math.rad(cur - auth))
            end

            local J6 = {}
            for i = 1, 6 do J6[i] = q6[i] * dw end
            rows[#rows + 1] = { isDrive = true, nodeID = nid, angular = validAng, r = err * dw, J6 = J6 }
        end
    end

    return rows
end

local function assembleAllRows(physRows, regRows, driveRows)
    local allRows = {}
    for _, r in ipairs(physRows) do allRows[#allRows+1] = r end
    for _, r in ipairs(driveRows) do allRows[#allRows+1] = r end
    for _, r in ipairs(regRows) do allRows[#allRows+1] = r end
    return allRows
end





local function updatePCDiag(graph, byPC)
    local over = {}
    local invalidResidual = (Solver.CONFIG.conflictTol or 0.5) + 1
    for _, pc in pairs(graph.pconstraints) do
        pc.solverResidual = 0
        pc.solverWeightedResidual = 0
        pc.solverSatisfied = false
        pc.solverStatus = "not_evaluated"
    end
    for pcid, rows in pairs(byPC) do
        local pc = graph.pconstraints[pcid]
        if not pc then continue end

        local status = rows._status or "ok"
        pc.solverStatus = status

        if status == "mirror" then
            pc.solverSatisfied = true
            continue
        end

        if status ~= "ok" then
            pc.solverResidual = invalidResidual
            pc.solverWeightedResidual = invalidResidual
            pc.solverSatisfied = false
            over[#over+1] = {pcid=pcid, residual=invalidResidual, status=status}
            continue
        end

        local raw, wt = 0, 0
        for _, r in ipairs(rows) do
            raw = raw + r.r*r.r
            local sc = r.angular and Solver.CONFIG.angularScale or 1.0
            wt = wt + (r.r*sc)*(r.r*sc)
        end
        raw, wt = math.sqrt(raw), math.sqrt(wt)
        pc.solverResidual = raw
        pc.solverWeightedResidual = wt
        pc.solverSatisfied = wt <= Solver.CONFIG.satTol
        if wt > Solver.CONFIG.conflictTol then over[#over+1] = {pcid=pcid, residual=wt, status=status} end
    end
    return over
end

local function buildDiag(graph, state, physRows, byPC, physResidNorm, augResidNorm, iters, accepted, modelStatus, attemptStatus, lambda, nodeAxes, physRank, nullity, numDrives, extras)
    local n = #state.movableIDs * 6
    local m = #physRows
    local over = updatePCDiag(graph, byPC)
    local hasConflicts = #over > 0
    local isUnder = nullity > 0
    local status = "ok"
    if isUnder and hasConflicts then status = "under_constrained_with_conflicts"
    elseif isUnder then status = "under_constrained"
    elseif hasConflicts then status = "over_constrained" end
    extras = extras or {}
    return {
        impl="se3_lm_nullbasis", status=status, modelStatus=modelStatus, attemptStatus=attemptStatus,
        converged = physResidNorm <= Solver.CONFIG.convergenceResidual and not hasConflicts and attemptStatus ~= "lambda_limit" and attemptStatus ~= "singular",
        accepted=accepted, iterations=iters,
        residualNorm=physResidNorm,
        physicalResidualNorm=physResidNorm,
        augmentedResidualNorm=augResidNorm,
        numEquations=m, numUnknowns=n, rank=physRank, nullity=nullity,
        numDrives=numDrives or 0,
        underConstrained = isUnder,
        hasConflicts = hasConflicts,
        overConstrained = over,
        nodeAxes=nodeAxes, nodeAxisScores={},
        axisSelection = { hiddenNullity=0, coupledPins=0, targetPins=nullity, selectedPins=nullity },
        redundantConstraints={}, rankContributions={},
        anchorNodeIDs=state.fixedIDs, gaugeNodeIDs={},
        branchAttempts=0, conditionEstimate=0,

        nullRefreshes      = extras.nullRefreshes or 0,
        nanGuards          = extras.nanGuards or 0,
        consecutiveSingular = extras.consecutiveSingular or 0,
        driveWarning       = extras.driveWarning,
    }
end





local function applyStep(state, step)




    local len = #state.movableIDs * 6
    for i = 1, len do
        if not isFinite(step[i] or 0) then return false end
    end
    for idx, nid in ipairs(state.movableIDs) do
        local base = (idx-1)*6
        state.poses[nid] = SE3.applyTwist(state.poses[nid],
            Vector(step[base+1] or 0, step[base+2] or 0, step[base+3] or 0),
            Vector(step[base+4] or 0, step[base+5] or 0, step[base+6] or 0))
    end
    return true
end

local function clonePoses(poses)
    local o = {}
    for k, v in pairs(poses) do o[k] = { pos=Vector(v.pos.x,v.pos.y,v.pos.z), R=copyMat(v.R) } end
    return o
end

local function applyToNodes(graph, state)




    for _, nid in ipairs(state.movableIDs) do
        local node = graph.nodes[nid]
        if node and not node.isPattern then
            local p, a = SE3.toPosAng(state.poses[nid])
            node.worldPos, node.worldAngle = Vector(p.x,p.y,p.z), Angle(a.p,a.y,a.r)
        end
    end




    for _, nid in ipairs(state.nodeOrder) do
        if state.passiveSet[nid] then
            local node = graph.nodes[nid]
            if node and not node.isPattern and node.parentID then
                local parent = graph.nodes[node.parentID]
                if parent then
                    local lp, la = resolveLocal(graph, node)
                    local wp, wa = LocalToWorld(lp, la, parent.worldPos, parent.worldAngle)
                    node.worldPos  = Vector(wp.x, wp.y, wp.z)
                    node.worldAngle = Angle(wa.p, wa.y, wa.r)
                end
            end
        end
    end
end

local function pushEntities(graph)
    if CLIENT then return end
    if PB.GraphAutoManageEnabled and not PB.GraphAutoManageEnabled(graph) then return end
    if PB.ApplyMirrorPConstraints then PB.ApplyMirrorPConstraints(graph) end
    for _, nid in ipairs(PB.TreeOrder(graph)) do
        local node = graph.nodes[nid]
        if node and not node.isPattern and IsValid(node.entity) then
            node.entity:SetPos(node.worldPos) node.entity:SetAngles(node.worldAngle)
            local phys = node.entity:GetPhysicsObject()
            if IsValid(phys) then phys:EnableMotion(false) phys:Sleep() end
        end
    end
    if PB.RebuildConstraints then PB.RebuildConstraints(graph, PB.TreeOrder(graph)) end
    for _, nid in ipairs(PB.TreeOrder(graph)) do
        local node = graph.nodes[nid]
        if node and node.isPattern and PB.RegeneratePattern then PB.RegeneratePattern(graph, nid) end
    end
end

local function physicalResidual(graph, state, physRows)
    local _, r = buildJacobian(graph, state, physRows)
    return vnorm(r)
end

function Solver.SolveGraph(graph, activeSet)
    buildWorldFromTree(graph)
    if PB.ApplyMirrorPConstraints then PB.ApplyMirrorPConstraints(graph) end

    graph._pbDriveWarning = nil
    local state = buildPoseState(graph, activeSet)
    local n = #state.movableIDs * 6


    local initPoses = clonePoses(state.poses)



    local physRows, byPC = assemblePhysicalRows(graph, state)
    local Jphys = buildJacobian(graph, state, physRows)
    local rowBasis = stableRowBasis(Jphys)
    local physRank = #rowBasis
    local nullBasis = computeNullBasis(rowBasis, n)
    local nullity = #nullBasis

    if n == 0 then
        applyToNodes(graph, state) writeLocalBack(graph, state) buildWorldFromTree(graph)
        if PB.ApplyMirrorPConstraints then PB.ApplyMirrorPConstraints(graph) end
        local nodeAxes = computeFreeUIAxes(graph, state, Jphys)
        local physResidNorm = physicalResidual(graph, state, physRows)
        graph.solverDiagnostic = buildDiag(graph, state, physRows, byPC, physResidNorm, physResidNorm, 0,
            physResidNorm <= Solver.CONFIG.convergenceResidual,
            #physRows > 0 and "well_constrained" or "empty", "accepted", 0, nodeAxes, physRank, nullity, 0)
        pushEntities(graph) return graph.solverDiagnostic.converged, graph.solverDiagnostic
    end


    local lambda = Solver.CONFIG.lambda0
    local accepted, hadAccepted = true, true
    local attemptStatus = "accepted"
    local maxIter, maxLam = getMaxIter(), getMaxLambda()
    local restarts, maxRestarts = 0, Solver.CONFIG.maxLambdaRestarts or 2
    local iterations = 0





    local acceptedSinceNull = 0
    local refreshNull = false
    local refreshes = 0




    local consecutiveSingular = 0
    local maxConsecSingular = Solver.CONFIG.maxConsecutiveSingular or 6




    local nanGuardTotal = 0

    local YIELD_MS = Solver.CONFIG.yieldMS or 6
    local sliceT = SysTime()
    local function maybeYield()
        if not coroutine.running() then return end
        if (SysTime() - sliceT)*1000 < YIELD_MS then return end
        coroutine.yield() sliceT = SysTime()
    end

    for iter = 1, maxIter do
        iterations = iter




        if refreshNull then
            local refRows = assemblePhysicalRows(graph, state)
            local refJ = buildJacobian(graph, state, refRows)
            local refRowBasis = stableRowBasis(refJ)
            nullBasis = computeNullBasis(refRowBasis, n)
            acceptedSinceNull = 0
            refreshNull = false
            refreshes = refreshes + 1
        end



        physRows, byPC = assemblePhysicalRows(graph, state)
        local regRows = buildRegRows(state, nullBasis, initPoses)
        local driveRows = buildDriveRows(graph, state)
        local allRows = assembleAllRows(physRows, regRows, driveRows)
        local J, r, ngThis = buildJacobian(graph, state, allRows)
        nanGuardTotal = nanGuardTotal + (ngThis or 0)
        local augResidual = vnorm(r)




        local physResid = physicalResidual(graph, state, physRows)
        local stopResid = (graph._pbEditDrive and #driveRows > 0) and augResidual or physResid
        if stopResid <= Solver.CONFIG.convergenceResidual then break end

        local A, b = normalEqs(J, r, lambda)
        local step, ok = gaussSolve(A, b, 1e-10)
        if not ok or not step then
            accepted = false attemptStatus = "singular"
            consecutiveSingular = consecutiveSingular + 1
            if consecutiveSingular >= maxConsecSingular then break end
            lambda = lambda * Solver.CONFIG.lambdaGrow
            if lambda > maxLam then
                if hadAccepted and restarts < maxRestarts then
                    restarts = restarts + 1 lambda = Solver.CONFIG.lambda0 hadAccepted = false
                else break end
            end
        else
            consecutiveSingular = 0
            local stepN = vnorm(step)
            local saved = clonePoses(state.poses)



            local applied = applyStep(state, step)
            if not applied then
                state.poses = saved
                accepted = false attemptStatus = "singular"
                consecutiveSingular = consecutiveSingular + 1
                if consecutiveSingular >= maxConsecSingular then break end
                lambda = lambda * Solver.CONFIG.lambdaGrow
                if lambda > maxLam then
                    if hadAccepted and restarts < maxRestarts then
                        restarts = restarts + 1 lambda = Solver.CONFIG.lambda0 hadAccepted = false
                    else break end
                end
            else

                local tPhys = assemblePhysicalRows(graph, state)
                local tReg = buildRegRows(state, nullBasis, initPoses)
                local tDrive = buildDriveRows(graph, state)
                local tAll = assembleAllRows(tPhys, tReg, tDrive)
                local _, tR = buildJacobian(graph, state, tAll)
                local tResid = vnorm(tR)

                if tResid < augResidual then
                    lambda = math.max(1e-8, lambda * Solver.CONFIG.lambdaShrink)
                    accepted = true hadAccepted = true attemptStatus = "accepted"







                    local newPhysResid = physicalResidual(graph, state, tPhys)
                    local stopResidPost = (graph._pbEditDrive and #tDrive > 0) and tResid or newPhysResid


                    acceptedSinceNull = acceptedSinceNull + 1
                    if acceptedSinceNull >= (Solver.CONFIG.nullRecomputeEvery or 25)
                       or stepN >= (Solver.CONFIG.nullRecomputeStepNorm or 1.0) then
                        refreshNull = true
                    end

                    if stepN <= Solver.CONFIG.convergenceStep
                       and stopResidPost <= Solver.CONFIG.convergenceResidual then break end
                else
                    state.poses = saved
                    lambda = lambda * Solver.CONFIG.lambdaGrow
                    accepted = hadAccepted attemptStatus = "rejected"
                    if lambda > maxLam then
                        if hadAccepted and restarts < maxRestarts then
                            restarts = restarts + 1 lambda = Solver.CONFIG.lambda0 hadAccepted = false
                        else attemptStatus = "lambda_limit" break end
                    end
                end
            end
        end
        maybeYield()
    end


    applyToNodes(graph, state) writeLocalBack(graph, state) buildWorldFromTree(graph)
    if PB.ApplyMirrorPConstraints then PB.ApplyMirrorPConstraints(graph) end


    physRows, byPC = assemblePhysicalRows(graph, state)
    Jphys = buildJacobian(graph, state, physRows)
    rowBasis = stableRowBasis(Jphys)
    physRank = #rowBasis
    nullBasis = computeNullBasis(rowBasis, n)
    nullity = #nullBasis
    local nodeAxes = computeFreeUIAxes(graph, state, Jphys)

    local finalReg = buildRegRows(state, nullBasis, initPoses)
    local finalDrive = buildDriveRows(graph, state)
    local finalAll = assembleAllRows(physRows, finalReg, finalDrive)
    local _, finalR = buildJacobian(graph, state, finalAll)
    local physResidNorm = physicalResidual(graph, state, physRows)
    local augResidNorm = vnorm(finalR)

    local modelStatus
    if #physRows == 0 then modelStatus = "empty"
    elseif physRank < n then modelStatus = "under_constrained"
    else modelStatus = "well_constrained" end

    if attemptStatus == "rejected" and hadAccepted then accepted = true end

    graph.solverDiagnostic = buildDiag(graph, state, physRows, byPC, physResidNorm, augResidNorm,
        iterations, accepted, modelStatus, attemptStatus, lambda, nodeAxes, physRank, nullity, #finalDrive,
        {
            nullRefreshes       = refreshes,
            nanGuards           = nanGuardTotal,
            consecutiveSingular = consecutiveSingular,
            driveWarning        = graph._pbDriveWarning,
        })
    pushEntities(graph)
    return graph.solverDiagnostic.converged, graph.solverDiagnostic
end





function PB.Propagate(graph, startID, opts)
    if not graph then return false end
    if PB.GraphAutoManageEnabled and not PB.GraphAutoManageEnabled(graph) then return true end

    opts = istable(opts) and opts or {}
    if SERVER and PB.ClearGConstraintRuntime and not opts.preserveGConstraints then
        PB.ClearGConstraintRuntime(graph)
    end




    local ok, diag = Solver.SolveGraph(graph, nil)
    graph._pbEditDrive = nil
    return ok, diag
end
