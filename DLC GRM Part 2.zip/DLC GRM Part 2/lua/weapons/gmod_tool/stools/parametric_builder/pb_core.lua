




































PB = PB or {}
PB.VERSION = "18.0.0"
PB.SCHEMA = 18






PB.MODULES = {


    { name = "pb_core",        side = "shared" },
    { name = "pb_config",      side = "shared" },
    { name = "pb_trace",       side = "shared" },
    { name = "pb_graph",       side = "shared" },
    { name = "pb_constraints", side = "shared" },
    { name = "pb_solver",      side = "shared" },
    { name = "pb_tool",        side = "shared" },
    { name = "pb_project",     side = "shared" },
    { name = "pb_net",         side = "server" },
    { name = "pb_ui",          side = "client" },
}

function PB.ModulePath(name)
    return "weapons/gmod_tool/stools/parametric_builder/" .. name .. ".lua"
end




PB.Log = PB.Log or {}
local CFG = PB.Config or {}
local L = PB.Log

L.LEVEL_TRACE, L.LEVEL_INFO, L.LEVEL_WARN, L.LEVEL_ERROR = 0, 1, 2, 3
L.LEVEL = L.LEVEL_INFO

local function logStrings()
    local cfg = PB.Config or CFG or {}
    local str = cfg.Strings or {}
    return str.Log or {}
end

local function fmt(level, ...)
    local ls = logStrings()
    local parts = {}
    for i = 1, select("#", ...) do parts[i] = tostring((select(i, ...))) end
    return string.format(tostring(ls.consoleFormat or "[GPara %s] %s"), tostring(level or "LOG"), table.concat(parts, " "))
end

function L.Trace(...) if L.LEVEL <= L.LEVEL_TRACE then local ls = logStrings() print(fmt(ls.trace or "TRACE", ...)) end end
function L.Info(...)  if L.LEVEL <= L.LEVEL_INFO  then local ls = logStrings() print(fmt(ls.info  or "INFO",  ...)) end end
function L.Warn(...)  if L.LEVEL <= L.LEVEL_WARN  then local ls = logStrings() print(fmt(ls.warn  or "WARN",  ...)) end end
function L.Error(...) if L.LEVEL <= L.LEVEL_ERROR then local ls = logStrings() print(fmt(ls.error or "ERROR", ...)) end end

function L.ToChat(ply, ...)
    if not ply or not ply.PrintMessage then return end
    ply:PrintMessage(3, CFG.ChatPrefix .. " " .. table.concat({...}, " "))
end




PB.Util = PB.Util or {}
local U = PB.Util

function U.CopyVec(v)
    if not v then return Vector(0, 0, 0) end
    return Vector(v.x or 0, v.y or 0, v.z or 0)
end

function U.CopyAng(a)
    if not a then return Angle(0, 0, 0) end
    return Angle(a.p or 0, a.y or 0, a.r or 0)
end

function U.ShallowCopy(t)
    local out = {}
    for k, v in pairs(t) do out[k] = v end
    return out
end

function U.DeepCopy(t, seen)
    if type(t) ~= "table" then return t end
    seen = seen or {}
    if seen[t] then return seen[t] end
    local out = {}
    seen[t] = out
    for k, v in pairs(t) do out[U.DeepCopy(k, seen)] = U.DeepCopy(v, seen) end
    return out
end

function U.Clamp(x, lo, hi)
    if x < lo then return lo end
    if x > hi then return hi end
    return x
end

function U.Sign(x)
    if x > 0 then return 1 end
    if x < 0 then return -1 end
    return 0
end

function U.Approx(a, b, eps)
    return math.abs(a - b) <= (eps or 1e-9)
end

function U.Count(t)
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n
end









PB.SE3 = PB.SE3 or {}
local SE3 = PB.SE3

local function vec3(x, y, z) return Vector(x or 0, y or 0, z or 0) end
local function vadd(a, b) return vec3(a.x + b.x, a.y + b.y, a.z + b.z) end
local function vsub(a, b) return vec3(a.x - b.x, a.y - b.y, a.z - b.z) end
local function vscale(a, s) return vec3(a.x * s, a.y * s, a.z * s) end
local function vdot(a, b) return a.x * b.x + a.y * b.y + a.z * b.z end
local function vcross(a, b)
    return vec3(a.y * b.z - a.z * b.y,
                a.z * b.x - a.x * b.z,
                a.x * b.y - a.y * b.x)
end
local function vnorm(a) return math.sqrt(vdot(a, a)) end
local function vnormalize(a)
    local n = vnorm(a)
    if n < 1e-15 then return vec3(0, 0, 0) end
    return vscale(a, 1 / n)
end

SE3.vec3 = vec3
SE3.vadd, SE3.vsub, SE3.vscale = vadd, vsub, vscale
SE3.vdot, SE3.vcross = vdot, vcross
SE3.vnorm, SE3.vnormalize = vnorm, vnormalize

local function mat3(a,b,c, d,e,f, g,h,i)
    return { {a or 0, b or 0, c or 0},
             {d or 0, e or 0, f or 0},
             {g or 0, h or 0, i or 0} }
end

local function identity3() return mat3(1,0,0, 0,1,0, 0,0,1) end

local function mmul(A, B)
    local r = mat3()
    for i = 1, 3 do
        for j = 1, 3 do
            r[i][j] = A[i][1]*B[1][j] + A[i][2]*B[2][j] + A[i][3]*B[3][j]
        end
    end
    return r
end

local function mtrans(A)
    return mat3(A[1][1], A[2][1], A[3][1],
                A[1][2], A[2][2], A[3][2],
                A[1][3], A[2][3], A[3][3])
end

local function mvec(A, v)
    return vec3(A[1][1]*v.x + A[1][2]*v.y + A[1][3]*v.z,
                A[2][1]*v.x + A[2][2]*v.y + A[2][3]*v.z,
                A[3][1]*v.x + A[3][2]*v.y + A[3][3]*v.z)
end

local function madd(A, B)
    return mat3(A[1][1]+B[1][1], A[1][2]+B[1][2], A[1][3]+B[1][3],
                A[2][1]+B[2][1], A[2][2]+B[2][2], A[2][3]+B[2][3],
                A[3][1]+B[3][1], A[3][2]+B[3][2], A[3][3]+B[3][3])
end

local function mscale(A, s)
    return mat3(A[1][1]*s, A[1][2]*s, A[1][3]*s,
                A[2][1]*s, A[2][2]*s, A[2][3]*s,
                A[3][1]*s, A[3][2]*s, A[3][3]*s)
end

local function skew(w)
    return mat3(   0, -w.z,  w.y,
                 w.z,    0, -w.x,
                -w.y,  w.x,    0)
end

SE3.mat3, SE3.identity3 = mat3, identity3
SE3.mmul, SE3.mtrans, SE3.mvec = mmul, mtrans, mvec
SE3.madd, SE3.mscale, SE3.skew = madd, mscale, skew







function SE3.expSO3(omega)
    local theta = vnorm(omega)
    local W = skew(omega)
    if theta < 1e-8 then

        local W2 = mmul(W, W)
        return madd(madd(identity3(), W), mscale(W2, 0.5))
    end
    local s = math.sin(theta) / theta
    local c = (1 - math.cos(theta)) / (theta * theta)
    local W2 = mmul(W, W)
    return madd(madd(identity3(), mscale(W, s)), mscale(W2, c))
end



function SE3.logSO3(R)
    local trace = R[1][1] + R[2][2] + R[3][3]
    local cos_t = U.Clamp((trace - 1) * 0.5, -1, 1)
    local theta = math.acos(cos_t)

    if theta < 1e-8 then
        return vec3((R[3][2] - R[2][3]) * 0.5,
                    (R[1][3] - R[3][1]) * 0.5,
                    (R[2][1] - R[1][2]) * 0.5)
    end

    if theta > math.pi - 1e-6 then

        local M = madd(R, identity3())
        local n1 = M[1][1]^2 + M[2][1]^2 + M[3][1]^2
        local n2 = M[1][2]^2 + M[2][2]^2 + M[3][2]^2
        local n3 = M[1][3]^2 + M[2][3]^2 + M[3][3]^2
        local axis
        if n1 >= n2 and n1 >= n3 then
            axis = vec3(M[1][1], M[2][1], M[3][1])
        elseif n2 >= n3 then
            axis = vec3(M[1][2], M[2][2], M[3][2])
        else
            axis = vec3(M[1][3], M[2][3], M[3][3])
        end
        return vscale(vnormalize(axis), theta)
    end

    local s = theta / (2 * math.sin(theta))
    return vec3((R[3][2] - R[2][3]) * s,
                (R[1][3] - R[3][1]) * s,
                (R[2][1] - R[1][2]) * s)
end





function SE3.pose(pos, R)
    return { pos = U.CopyVec(pos), R = R or identity3() }
end

function SE3.identity() return { pos = vec3(0, 0, 0), R = identity3() } end


function SE3.compose(A, B)
    return { pos = vadd(A.pos, mvec(A.R, B.pos)), R = mmul(A.R, B.R) }
end

function SE3.inverse(T)
    local Rt = mtrans(T.R)
    return { pos = vscale(mvec(Rt, T.pos), -1), R = Rt }
end

function SE3.apply(T, p) return vadd(T.pos, mvec(T.R, p)) end
function SE3.applyRot(T, v) return mvec(T.R, v) end




function SE3.applyTwist(T0, v, omega)
    return SE3.compose(T0, { pos = U.CopyVec(v), R = SE3.expSO3(omega) })
end







function SE3.fromAngle(ang)
    local p = math.rad(ang.p); local sp, cp = math.sin(p), math.cos(p)
    local y = math.rad(ang.y); local sy, cy = math.sin(y), math.cos(y)
    local r = math.rad(ang.r); local sr, cr = math.sin(r), math.cos(r)
    return mat3(
        cp*cy,  sp*sr*cy - cr*sy,  sp*cr*cy + sr*sy,
        cp*sy,  sp*sr*sy + cr*cy,  sp*cr*sy - sr*cy,
          -sp,             cp*sr,             cp*cr
    )
end

function SE3.toAngle(R)
    local sp = U.Clamp(-R[3][1], -1, 1)
    local p = math.asin(sp)
    local y, r
    if math.abs(sp) > 1 - 1e-7 then
        r, y = 0, math.atan2(-R[1][2], R[2][2])
    else
        y, r = math.atan2(R[2][1], R[1][1]), math.atan2(R[3][2], R[3][3])
    end
    return Angle(math.deg(p), math.deg(y), math.deg(r))
end

function SE3.fromPosAng(pos, ang) return { pos = U.CopyVec(pos), R = SE3.fromAngle(ang) } end
function SE3.toPosAng(T) return U.CopyVec(T.pos), SE3.toAngle(T.R) end













function SE3.pointJacobian(T0, p_local)
    local J_v = T0.R
    local J_w = mscale(mmul(T0.R, skew(p_local)), -1)
    return J_v, J_w
end

function SE3.directionJacobian(T0, d_local)
    local J_v = mat3(0,0,0, 0,0,0, 0,0,0)
    local J_w = mscale(mmul(T0.R, skew(d_local)), -1)
    return J_v, J_w
end
