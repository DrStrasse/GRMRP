--[[
	Script: Metal Detector
	Version: 2.0
	Created by DidVaitel (http://steamcommunity.com/profiles/76561198108670811)
]]


TOOL.Category		= "DidVaitel Tools"
TOOL.Name			= "Metal Detector Creator"

if CLIENT then
	language.Add( "Tool.ddv_metal_detector_tool.name", "Metal Detector Creator" );
	language.Add( "Tool.ddv_metal_detector_tool.desc", "Allows you to easily configure the metal detector configuration" );
	language.Add( "Tool.ddv_metal_detector_tool.0", "Left click to spawn detector. Right click on detector to edit his data." );
end

if SERVER then 
	util.AddNetworkString("Metal_Detector.SetWeaponsTable")

	net.Receive("Metal_Detector.SetWeaponsTable", function( Lenght, Player )

		if GetConVar("ddv_metal_detector_access") == 1 and !Player:IsSuperAdmin() then
			return
		end
		
		Player.IllegalWeapons = net.ReadTable()
		Player.WhitelistTable = net.ReadTable()

	end)

	CreateConVar("ddv_metal_detector_access", 1, FCVAR_ARCHIVE, "Change metal detector tool access")

	concommand.Add( "ddv_metal_detector_save", function( ply ) 
		
		if !ply:IsSuperAdmin() then return end
		mainTable = {}
		mainTable.IllegalWeapons = ply.IllegalWeapons
		mainTable.WhitelistTable = ply.WhitelistTable
		if (!file.Exists("didvaitel", "DATA")) then
			file.CreateDir("didvaitel")
		end
		file.Write( "didvaitel/metal_detector_config.txt", util.TableToJSON(mainTable) )
	end)
end


function TOOL:LeftClick( tr )

	if SERVER then

		if (GetConVar("ddv_metal_detector_access"):GetInt() == 1 and !self:GetOwner():IsSuperAdmin()) then
			return
		end

		if (!self:GetOwner().IllegalWeapons) then self:GetOwner().IllegalWeapons = {} end
		if (!self:GetOwner().WhitelistTable) then self:GetOwner().WhitelistTable = {} end

		local SpawnPos = tr.HitPos + tr.HitNormal * 65
		local SpawnAng = self:GetOwner():EyeAngles()
		SpawnAng.p = 0
		SpawnAng.y = SpawnAng.y + 180

		local ent = ents.Create( "ddv_metal_detector" )
		ent:SetPos( SpawnPos )
		ent:SetAngles( SpawnAng )
		ent:Spawn()
		ent:Activate()
		ent.IllegalWeapons = self:GetOwner().IllegalWeapons
		ent.WeaponWhiteList = self:GetOwner().WhitelistTable

		undo.Create( "SENT" )
			undo.SetPlayer( self:GetOwner() )
			undo.AddEntity( ent )
			undo.SetCustomUndoText( "Undone Metal Detector" )
		undo.Finish( "Scripted Entity (Metal Detector)" )

		return true

	end



 	return true

end

function TOOL:RightClick( Trace )

	if SERVER then

		if (GetConVar("ddv_metal_detector_access"):GetInt() == 1 and !self:GetOwner():IsSuperAdmin()) then
			return
		end

		if (!self:GetOwner().IllegalWeapons) then self:GetOwner().IllegalWeapons = {} end
		if (!self:GetOwner().WhitelistTable) then self:GetOwner().WhitelistTable = {} end

		if ( Trace.Entity and Trace.Entity:GetClass() == "ddv_metal_detector" ) then
			Trace.Entity:UpdateTables(self:GetOwner().IllegalWeapons, self:GetOwner().WhitelistTable)
			return true
		end

		return false

	end

	if ( Trace.Entity and Trace.Entity:GetClass() == "ddv_metal_detector" ) then
		return true
	end

 	return false

end


if ( CLIENT ) then

	function TOOL.BuildCPanel( CPanel )

		if ( !IsValid(LocalPlayer().WeaponsTable) ) then
			LocalPlayer().WeaponsTable = {}
		end
		if ( !IsValid(LocalPlayer().WhitelistTable) ) then
			LocalPlayer().WhitelistTable = {}
		end

		local Listbox2 = CPanel:AddControl( "button", { Label = "Save as default detector configuration", Height = 100, Command = "ddv_metal_detector_save"  } )

		CPanel:AddControl( "Header", { Description	= [[Illegal Weapons. Each illegal weapon will be detected!]]})

		local Listbox = CPanel:AddControl( "listbox", { Label = "Legal Weapons", Height = 250  } )
		local ListboxSelected = CPanel:AddControl( "listbox", { Label = "Illegal Weapons", Height = 250  } )

		CPanel:AddControl( "Header", { Description	= [[Whitelist. Whitelisted weapons can't be detected untill you add them to illegal table!]]})

		local Listbox2 = CPanel:AddControl( "listbox", { Label = "All Weapons", Height = 250  } )
		local ListboxWhitelisted = CPanel:AddControl( "listbox", { Label = "Whitelisted Weapons", Height = 250  } )

		for k,v in pairs( list.Get( "Weapon" ) ) do
			Listbox:AddLine(v.ClassName)
			Listbox2:AddLine(v.ClassName)
		end

		ListboxSelected.OnRowSelected = function( List, Index, Panel )
			Listbox:AddLine( Panel:GetColumnText( 1 ) )
			ListboxSelected:RemoveLine( Index )

			table.RemoveByValue( LocalPlayer().WeaponsTable, Panel:GetColumnText( 1 ) )

			net.Start("Metal_Detector.SetWeaponsTable")
				net.WriteTable( LocalPlayer().WeaponsTable )
				net.WriteTable( LocalPlayer().WhitelistTable )
			net.SendToServer()	
		end

		Listbox.OnRowSelected = function( List, Index, Panel )
			ListboxSelected:AddLine( Panel:GetColumnText( 1 ) )
			Listbox:RemoveLine( Index )

			table.insert( LocalPlayer().WeaponsTable, Panel:GetColumnText( 1 ) )

			net.Start("Metal_Detector.SetWeaponsTable")
				net.WriteTable( LocalPlayer().WeaponsTable )
				net.WriteTable( LocalPlayer().WhitelistTable )
			net.SendToServer()	
		end

		// Whitelist
		ListboxWhitelisted.OnRowSelected = function( List, Index, Panel )
			Listbox2:AddLine( Panel:GetColumnText( 1 ) )
			ListboxWhitelisted:RemoveLine( Index )

			table.RemoveByValue( LocalPlayer().WhitelistTable, Panel:GetColumnText( 1 ) )

			net.Start("Metal_Detector.SetWeaponsTable")
				net.WriteTable( LocalPlayer().WeaponsTable )
				net.WriteTable( LocalPlayer().WhitelistTable )
			net.SendToServer()	
		end

		Listbox2.OnRowSelected = function( List, Index, Panel )
			ListboxWhitelisted:AddLine( Panel:GetColumnText( 1 ) )
			Listbox2:RemoveLine( Index )

			table.insert( LocalPlayer().WhitelistTable, Panel:GetColumnText( 1 ) )

			net.Start("Metal_Detector.SetWeaponsTable")
				net.WriteTable( LocalPlayer().WeaponsTable )
				net.WriteTable( LocalPlayer().WhitelistTable )
			net.SendToServer()	
		end


	end

end