local CFG = PB.Config or {}
local TOOL_STR = ((CFG.Strings or {}).Tool or {})
local CHAT_STR = ((CFG.Strings or {}).Chat or {})
local TREE_STR = ((CFG.Strings or {}).Tree or {})

TOOL.Category = TOOL_STR.category
TOOL.Name = TOOL_STR.nameToken
TOOL.Command = nil
TOOL.ConfigName = ""
TOOL.ClientConVar = {
    ["freeze"] = "1",
    ["offset_x"] = "0",
    ["offset_y"] = "0",
    ["offset_z"] = "0",
    ["angle_p"] = "0",
    ["angle_y"] = "0",
    ["angle_r"] = "0",
    ["auto_parent"] = "1",
}

TOOL.Information = {
    {name = "left"},
    {name = "right"},
    {name = "reload"}
}

local PREFIX = CFG.CommandPrefix

local function TraceEvent(category, action, payload)
    if PB.Trace and PB.Trace.Event then PB.Trace.Event(category, action, payload or {}) end
end
local function TNode(node) return PB.Trace and PB.Trace.Node and PB.Trace.Node(node) or nil end
local function TPC(pc, graph) return PB.Trace and PB.Trace.PConstraint and PB.Trace.PConstraint(pc, graph) or nil end
local function TFeature(feature) return PB.Trace and PB.Trace.Feature and PB.Trace.Feature(feature) or feature end
local function TDiag(graph) return PB.Trace and PB.Trace.Diagnostic and PB.Trace.Diagnostic(graph and graph.solverDiagnostic or nil) or nil end

local function PBMsg(ply, message)
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTTALK, (CFG.ChatPrefix) .. " " .. tostring(message or ""))
    end
end

local NotifySelection = function(ply, nodeID)
    if PB and PB.NotifySelection then
        return PB.NotifySelection(ply, nodeID)
    end
    if IsValid(ply) then
        ply.PB_SelectedNode = nodeID
    end
end

local RegisterUndo = function(ply, label, graph, nodeID, removeEntity)
    if PB and PB.RegisterUndo then
        return PB.RegisterUndo(ply, label, graph, nodeID, removeEntity)
    end
    return false
end

local function ActiveProjectOrWarn(ply)
    if not SERVER or not IsValid(ply) then return true end
    if PB and PB.Store and PB.Store.ResolveActiveProject then
        local pid = PB.Store.ResolveActiveProject(ply:SteamID())
        if pid then return true end
    end
    PBMsg(ply, CHAT_STR.createOrSelectProject)
    return false
end

if SERVER then

if util and util.AddNetworkString then
    util.AddNetworkString(PREFIX .. "picker_prefs")
end

if net and net.Receive then
    net.Receive(PREFIX .. "picker_prefs", function(_, ply)
        local data = util.JSONToTable(net.ReadString() or "") or {}
        ply.PB_PickerPrefs = PB.NormalizePickerPrefs and PB.NormalizePickerPrefs(data) or data
    end)
end

function AddNodeToGraph(graph, ent, parentID, localPos, localAngle, freeze)
    local node = PB.NewNode(graph, ent, parentID, localPos, localAngle)
    node.model = ent:GetModel()
    node.worldPos = ent:GetPos()
    node.worldAngle = ent:GetAngles()
    if freeze and (not PB.GraphAutoManageEnabled or PB.GraphAutoManageEnabled(graph)) then
        local phys = ent:GetPhysicsObject()
        if IsValid(phys) then phys:EnableMotion(false) end
    end
    return node
end

function SyncPCState(ply)
    net.Start(PREFIX .. "sync_pc_state")
    local state = ply.PB_PCState
    if state and state.firstNodeID then
        net.WriteBool(true)
        net.WriteUInt(state.firstNodeID, 24)
        net.WriteString(state.firstFeature.type)
        net.WriteString(tostring(state.firstFeature.id))
    else
        net.WriteBool(false)
    end
    net.Send(ply)
end

function HandlePCLeftClick(ply, trace)
    if not ActiveProjectOrWarn(ply) then return end
    local ent = trace.Entity
    if not IsValid(ent) or ent:IsPlayer() or ent:IsWorld() then return end

    local graph = PB.GetGraph(ply)
    local node = PB.FindNodeByEntity(graph, ent)
    if not node then
        PBMsg(ply, CHAT_STR.notInGraph)
        return
    end

    local feature = PB.DetectFeature(ent, ply:EyePos(), ply:GetAimVector(), trace.HitPos, trace.HitNormal, ply.PB_PickerPrefs)
    if not feature then
        PBMsg(ply, ((((PB.Config or {}).Strings or {}).Chat or {}).featureUnavailable or CHAT_STR.featureUnavailable))
        return
    end

    local state = ply.PB_PCState or {}

    if not state.firstNodeID then
        state.firstNodeID = node.id
        state.firstFeature = feature
        ply.PB_PCState = state
        SyncPCState(ply)
        TraceEvent("pconstraint_tool", "first_feature_selected", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, node = TNode(node), feature = TFeature(feature), pendingMode = ply.PB_PCPendingMode })
        PBMsg(ply, "First: " .. node.label .. " [" .. feature.type .. "]")
        return
    end

    if node.id == state.firstNodeID then
        state.firstNodeID = nil
        state.firstFeature = nil
        ply.PB_PCState = state
        SyncPCState(ply)
        PBMsg(ply, ((((PB.Config or {}).Strings or {}).Chat or {}).selectionCleared or CHAT_STR.selectionCleared))
        return
    end

    local firstNode = graph.nodes[state.firstNodeID]
    local secondNode = node
    local parentID, childID = state.firstNodeID, node.id
    local parentFeature, childFeature = state.firstFeature, feature
    local function nodeIsRoot(n)
        return not n.parentID or not graph.nodes[n.parentID]
    end

    local childIsRoot  = nodeIsRoot(secondNode)
    local parentIsRoot = firstNode and nodeIsRoot(firstNode)

    if childIsRoot and not parentIsRoot then

        parentID, childID = childID, parentID
        parentFeature, childFeature = childFeature, parentFeature
    elseif firstNode and firstNode.parentID == node.id then

        parentID, childID = childID, parentID
        parentFeature, childFeature = childFeature, parentFeature
    end


    local mode = ply.PB_PCPendingMode or "geometric"


    if not PB.IsModeValidForFeatures(mode, parentFeature.type, childFeature.type) then
        TraceEvent("pconstraint_tool", "invalid_mode_for_features", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, mode = mode, parentNode = TNode(graph.nodes[parentID]), childNode = TNode(graph.nodes[childID]), parentFeature = TFeature(parentFeature), childFeature = TFeature(childFeature) })
        PBMsg(ply, (PB.MODE_NAMES[mode] or mode)
            .. " not valid for " .. parentFeature.type .. "/" .. childFeature.type)
        return
    end

    TraceEvent("pconstraint_tool", "create_attempt", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, parentNode = TNode(graph.nodes[parentID]), childNode = TNode(graph.nodes[childID]), parentFeature = TFeature(parentFeature), childFeature = TFeature(childFeature), mode = mode, diagBefore = TDiag(graph) })
    local pc = PB.NewPConstraint(graph, parentID, childID, parentFeature, childFeature, mode)
    if not pc then
        TraceEvent("pconstraint_tool", "create_failed", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, parentID = parentID, childID = childID, mode = mode, reason = "cycle_or_invalid" })
        PBMsg(ply, "Can't create (cycle?)")
    else
        PB.RecordAction(graph, "create_pc", { pcID = pc.id })
        TraceEvent("pconstraint_tool", "create_success_before_solve", { player = PB.Trace and PB.Trace.Player and PB.Trace.Player(ply) or nil, pc = TPC(pc, graph), summary = PB.DescribePConstraint(pc, graph) })

        PB.PropagateAndSync(ply, graph, nil, "tool_create_pc",
            { pc = TPC(pc, graph), summary = PB.DescribePConstraint(pc, graph) }, true)
        PBMsg(ply, "PC#" .. pc.id .. ": " .. PB.DescribePConstraint(pc, graph))
    end

    ply.PB_PCState = {}
    SyncPCState(ply)
end

function HandlePCRightClick(ply)
    local state = ply.PB_PCState or {}
    if state.firstNodeID then
        state.firstNodeID = nil
        state.firstFeature = nil
        ply.PB_PCState = state
        SyncPCState(ply)
        PBMsg(ply, ((((PB.Config or {}).Strings or {}).Chat or {}).selectionCleared or CHAT_STR.selectionCleared))
    else
        ply.PB_PCSelectMode = false
        ply.PB_PCState = {}
        PB.NotifyPCModeExit(ply)
        PBMsg(ply, CHAT_STR.pcModeCancelled)
    end
end


function HandleMirrorLeftClick(ply, trace)
    if not ActiveProjectOrWarn(ply) then return end
    local state = ply.PB_MirrorState or {}
    local sourceID = tonumber(state.sourceNodeID)
    if not sourceID then
        PBMsg(ply, "No mirror source selected")
        if PB.NotifyMirrorModeExit then PB.NotifyMirrorModeExit(ply) end
        return
    end

    local ent = trace.Entity
    if not IsValid(ent) or ent:IsPlayer() or ent:IsWorld() then return end

    local graph = PB.GetGraph(ply)
    local picked = PB.FindNodeByEntity(graph, ent)
    if not picked then
        PBMsg(ply, "Mirror prop must already be a PB node")
        return
    end

    if PB.NotifyMirrorNodePicked then
        PB.NotifyMirrorNodePicked(ply, sourceID, picked.id)
    elseif PB.NotifyMirrorModeExit then
        PB.NotifyMirrorModeExit(ply)
    end
    PBMsg(ply, "Picked mirror prop: " .. (picked.label or ("Node " .. tostring(picked.id))) .. ". Choose a plane in Properties, then Create or Delete Mirror.")
end

function HandleMirrorRightClick(ply)
    ply.PB_MirrorSelectMode = false
    ply.PB_MirrorState = {}
    if PB.NotifyMirrorModeExit then PB.NotifyMirrorModeExit(ply) end
    PBMsg(ply, "Exited mirror picker")
end

function TOOL:Reload(trace)
    local ply = self:GetOwner()
    if not IsValid(ply) then return false end

    if SERVER then
        local now = CurTime()
        ply.PB_LastReloadToggle = ply.PB_LastReloadToggle or 0
        if now - ply.PB_LastReloadToggle < 0.18 then return false end
        ply.PB_LastReloadToggle = now
        ply:ConCommand(PREFIX .. "open_panel")
    end

    return false
end

function TOOL:SpawnChildCopy(trace)
    local ply = self:GetOwner()
    if not ActiveProjectOrWarn(ply) then return false end
    local graph = PB.GetGraph(ply)
    local selectedID = ply.PB_SelectedNode

    if not selectedID or not graph.nodes[selectedID] or graph.nodes[selectedID].isPattern then
        PBMsg(ply, "Select a node first")
        return false
    end

    local parentNode = graph.nodes[selectedID]

    local localPos = Vector(
        self:GetClientNumber("offset_x"),
        self:GetClientNumber("offset_y"),
        self:GetClientNumber("offset_z"))
    local localAngle = Angle(
        self:GetClientNumber("angle_p"),
        self:GetClientNumber("angle_y"),
        self:GetClientNumber("angle_r"))
    local worldPos, worldAngle = LocalToWorld(localPos, localAngle, parentNode.worldPos, parentNode.worldAngle)

    local ent = ents.Create("prop_physics")
    ent:SetModel(parentNode.model)
    ent:SetPos(worldPos)
    ent:SetAngles(worldAngle)
    ent:Spawn()

    local node = AddNodeToGraph(graph, ent, selectedID, localPos, localAngle, true)

    PB.RecordAction(graph, "spawn_child", { nodeID = node.id })
    RegisterUndo(ply, "PB Spawn: " .. node.label, graph, node.id, true)
    if self:GetClientNumber("auto_parent") == 1 then NotifySelection(ply, node.id) end
    PBMsg(ply, "Spawned: " .. node.label)
    PB.SyncFullToClient(ply, graph)
    return true
end

end


function TOOL:LeftClick(trace)

    if not trace.HitPos then return false end

    if CLIENT then return true end
    local ply = self:GetOwner()
    if not ActiveProjectOrWarn(ply) then return false end

    if ply.PB_GCSelectMode and PB.GCPicker and PB.GCPicker.ToolLeftClick then
        return PB.GCPicker.ToolLeftClick(ply, trace)
    end

    if ply.PB_MirrorSelectMode then
        HandleMirrorLeftClick(ply, trace)
        return true
    end

    if ply.PB_PCSelectMode then
        HandlePCLeftClick(ply, trace)
        return true
    end

    if ply:KeyDown(IN_SPEED) then
        return self:SpawnChildCopy(trace)
    end

    local ent = trace.Entity
    if not IsValid(ent) or ent:IsPlayer() or ent:IsWorld() then return false end

    local graph = PB.GetGraph(ply)

    local existingNode = PB.FindNodeByEntity(graph, ent)
    if existingNode then
        NotifySelection(ply, existingNode.id)
        PBMsg(ply, TREE_STR.selectedPrefix .. existingNode.label)
        return true
    end

    local selectedID = ply.PB_SelectedNode
    local selectedNode = selectedID and graph.nodes[selectedID]
    local freeze = self:GetClientNumber("freeze") == 1

    if selectedNode and not selectedNode.isPattern then
        local localPos, localAngle = WorldToLocal(ent:GetPos(), ent:GetAngles(), selectedNode.worldPos, selectedNode.worldAngle)
        local node = AddNodeToGraph(graph, ent, selectedID, localPos, localAngle, freeze)
        PB.RecordAction(graph, "add_child", { nodeID = node.id, parentID = selectedID })
        RegisterUndo(ply, "PB Child: " .. node.label, graph, node.id, false)
        if self:GetClientNumber("auto_parent") == 1 then NotifySelection(ply, node.id) end
        PBMsg(ply, "Child: " .. node.label .. " -> " .. selectedNode.label)
    else
        local node = AddNodeToGraph(graph, ent, nil, ent:GetPos(), ent:GetAngles(), freeze)
        PB.RecordAction(graph, "add_root", { nodeID = node.id })
        RegisterUndo(ply, "PB Root: " .. node.label, graph, node.id, false)
        NotifySelection(ply, node.id)
        PBMsg(ply, "Root: " .. node.label)
    end

    PB.SyncFullToClient(ply, graph)
    return true
end

function TOOL:RightClick(trace)

    if not trace.HitPos then return false end

    if CLIENT then return true end

    local ply = self:GetOwner()
    if not ActiveProjectOrWarn(ply) then return false end

    if ply.PB_GCSelectMode and PB.GCPicker and PB.GCPicker.ToolRightClick then
        return PB.GCPicker.ToolRightClick(ply, trace)
    end

    if ply.PB_MirrorSelectMode then
        HandleMirrorRightClick(ply)
        return true
    end

    if ply.PB_PCSelectMode then
        HandlePCRightClick(ply)
        return true
    end

    if trace.Entity:IsWorld() then
        NotifySelection(ply, nil)
        PBMsg(ply, "Deselected")
        return true
    end

    if not IsValid(trace.Entity) or trace.Entity:IsPlayer() then return false end

    local graph = PB.GetGraph(ply)
    local node = PB.FindNodeByEntity(graph, trace.Entity)
    if node then
        NotifySelection(ply, node.id)
        PBMsg(ply, TREE_STR.selectedPrefix .. node.label)
    else
        PBMsg(ply, TREE_STR.notInGraphHint)
    end
    return true
end

if CLIENT then
    function TOOL:Reload(trace)
        RunConsoleCommand(PREFIX .. "open_panel")
        return false
    end

    function TOOL:Holster()
        if PB_ClosePanel then PB_ClosePanel() end
    end

    language.Add("Tool.parametric_builder.name", CFG.AddonName)
    language.Add("Tool.parametric_builder.desc", TOOL_STR.description)
    language.Add("Tool.parametric_builder.0", TOOL_STR.help)
    language.Add( "Tool.parametric_builder.left", "Create / Select a Prop (Node)" )
    language.Add( "Tool.parametric_builder.right", "Select a Prop (Node)" )
    language.Add( "Tool.parametric_builder.reload", "Open / Close Menu" )

    function TOOL.BuildCPanel(panel)
        panel:AddControl("Header", {
            Text = TOOL_STR.controlHeader,
            Description = TOOL_STR.cpanelDescription,
        })
        panel:AddControl("Checkbox", { Label = TOOL_STR.freeze, Command = PREFIX .. "freeze" })
        panel:AddControl("Checkbox", { Label = TOOL_STR.autoSelectChain, Command = PREFIX .. "auto_parent" })
















        panel:AddControl("Label", { Text = TOOL_STR.overlayHeader })
        local OVERLAY_CONVARS = {"overlay_enabled", "overlay_labels", "overlay_offsets", "overlay_constraints", "overlay_axes", "overlay_dimensions"}
        for _, convar in ipairs(OVERLAY_CONVARS) do
            panel:AddControl("Checkbox", {
                Label = convar:gsub("overlay_", ""),
                Command = PREFIX .. convar,
            })
        end


        panel:AddControl("Slider", {
            Label = TOOL_STR.gridSize, Type = "Float",
            Min = 0.1, Max = 50,
            Command = ((PB.Config and PB.Config.CVar and PB.Config.CVar("snapGrid")) or (PREFIX .. "snap_grid")),
        })

        panel:AddControl("Button", { Label = TOOL_STR.openPanel, Command = PREFIX .. "open_panel" })
        panel:AddControl("Button", { Label = TOOL_STR.resetPanelLayout, Command = PREFIX .. "reset_panel_layout" })
    end
end

function TOOL:Holster()
    if CLIENT and PB_ClosePanel then PB_ClosePanel() end
end


if CLIENT then
    do local d = ((PB.Config or {}).ConVars or {}).snapGrid or {}; CreateClientConVar(d.name or (PREFIX .. "snap_grid"), d.default or "1", true, false, d.help) end

    local nudgeKeys = {
        [KEY_UP]     = {  0,  1,  0 },
        [KEY_DOWN]   = {  0, -1,  0 },
        [KEY_LEFT]   = { -1,  0,  0 },
        [KEY_RIGHT]  = {  1,  0,  0 },
        [KEY_PAGEUP] = {  0,  0,  1 },
        [KEY_PAGEDOWN] = { 0, 0, -1 },
    }
    local nudgeCooldown = 0

    function TOOL:Think()
        if not PB_Overlay or not PB_Overlay.selectedNodeID then return end
        if not input.IsKeyDown(KEY_LALT) and not input.IsKeyDown(KEY_RALT) then return end
        if CurTime() < nudgeCooldown then return end

        local graph = PB.GetGraph(LocalPlayer())
        if not graph then return end
        local node = graph.nodes[PB_Overlay.selectedNodeID]
        if not node then return end

        local grid = GetConVar((PB.Config and PB.Config.CVar and PB.Config.CVar("snapGrid")) or (PREFIX .. "snap_grid")):GetFloat()
        for key, dir in pairs(nudgeKeys) do
            if input.IsKeyDown(key) then
                local nx = math.Round(node.localPos.x + dir[1] * grid, 4)
                local ny = math.Round(node.localPos.y + dir[2] * grid, 4)
                local nz = math.Round(node.localPos.z + dir[3] * grid, 4)
                RunConsoleCommand(PREFIX .. "set_pos_all",
                    tostring(PB_Overlay.selectedNodeID),
                    tostring(nx), tostring(ny), tostring(nz))
                nudgeCooldown = CurTime() + 0.08
                return
            end
        end
    end
else
    function TOOL:Think() end
end

if CLIENT then

    surface.CreateFont("PB_ToolScreenTiny", {
        font = "DermaDefaultBold",
        size = 11,
        weight = 800,
        antialias = true
    })

    surface.CreateFont("PB_ToolScreenLWH", {
        font = "DermaDefaultBold",
        size = 17,
        weight = 900,
        antialias = true
    })

    local function toolScreenRound1(value)
        return string.format("%.1f", tonumber(value) or 0)
    end

    local function getSelectedNodeLWH()
        if not PB_Overlay or not PB_Overlay.selectedNodeID then return nil end
        if not PB or not PB.GetGraph then return nil end

        local graph = PB.GetGraph(LocalPlayer())
        if not graph or not graph.nodes then return nil end

        local node = graph.nodes[PB_Overlay.selectedNodeID]
        if not node or not IsValid(node.entity) then return nil end

        local mins = node.entity:OBBMins()
        local maxs = node.entity:OBBMaxs()
        local size = maxs - mins

        return math.abs(size.x), math.abs(size.y), math.abs(size.z)
    end

    local function drawSelectedNodeLWH(width, height)
        local l, w, h = getSelectedNodeLWH()
        if not l then return end

        local margin = 6
        local panelH = 38
        local x = margin
        local y = height - 48 + 5
        local boxW = width - margin * 2

        draw.SimpleText("NODE "..PB_Overlay.selectedNodeID, "PB_ToolScreenLWH", 15, y, Color(40, 40, 100), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        draw.SimpleText("L " .. toolScreenRound1(l) .. "  W " .. toolScreenRound1(w) .. "  H " .. toolScreenRound1(h), "PB_ToolScreenLWH", 15, y + 18, Color(20, 20, 60), TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
    end

    local gp_rotate1 = 0
    local gp_rotate2 = 0
    local gp_rotate3 = 0
    local l_speed1 = -0.3
    local l_speed2 = -0.6
    local l_speed3 = 1

    function TOOL:DrawToolScreen(width, height)

        local gpara_bg = Material("gpara_background.png", "ignorez" )
        surface.SetMaterial( gpara_bg )
        surface.DrawTexturedRect( 0, 0, width, height )

        local gpara_gear1 = Material("gpara_gear1.png", "ignorez" )
        surface.SetMaterial( gpara_gear1 )
        surface.DrawTexturedRectRotated( 74, 97, 103, 103, gp_rotate1 )

        local gpara_gear2 = Material("gpara_gear2.png", "ignorez" )
        surface.SetMaterial( gpara_gear2 )
        surface.DrawTexturedRectRotated( 162, 160, 76, 76, gp_rotate2 )

        local gpara_gear3 = Material("gpara_gear3.png", "ignorez" )
        surface.SetMaterial( gpara_gear3 )
        surface.DrawTexturedRectRotated( 208, 96, 53, 53, gp_rotate3 )

        local gpara_words = Material("gpara_words.png", "ignorez" )
        surface.SetMaterial( gpara_words )
        surface.DrawTexturedRect( 0, 0, width, height )

        gp_rotate1 = gp_rotate1 + l_speed1
        gp_rotate2 = gp_rotate2 + l_speed2
        gp_rotate3 = gp_rotate3 + l_speed3

        if PB_SolverActive then
            gp_rotate1 = gp_rotate1 + (l_speed1 * 2)
            gp_rotate2 = gp_rotate2 + (l_speed2 * 2)
            gp_rotate3 = gp_rotate3 + (l_speed3 * 2)
        end

        if gp_rotate1 >= 360 then gp_rotate1 = 0 end
        if gp_rotate2 >= 360 then gp_rotate2 = 0 end
        if gp_rotate3 >= 360 then gp_rotate3 = 0 end

        drawSelectedNodeLWH(width, height)
    end
end
