-- lua/weapons/weapon_photo_camera/init.lua

AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

util.AddNetworkString("PhotoCam_ZoomUpdate")

function SWEP:PrimaryAttack()
    if not self:CanTakePhoto() then return end

    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    local maxPhotos = PhotoCamera.Settings.MaxPhotosPerPlayer

    self:SetNextPhotoTime(CurTime() + PhotoCamera.Settings.CooldownTime)
    self:SetNextPrimaryFire(CurTime() + PhotoCamera.Settings.CooldownTime)

    local photoID = PhotoCamera.Utils.GeneratePhotoID()

    net.Start("PhotoCam_CameraFlash")
        net.WriteEntity(owner)
    net.Broadcast()

    net.Start("PhotoCam_RequestRender")
        net.WriteString(photoID)
        net.WriteAngle(owner:EyeAngles())
        net.WriteVector(owner:EyePos())
        net.WriteFloat(self:GetZoomLevel())
    net.Send(owner)

    self:EmitSound("npc/scanner/scanner_photo1.wav", 75, 100, 1, CHAN_WEAPON)

    owner.PendingPhotoID = photoID
    self:SetPhotoCount(self:GetPhotoCount() + 1)
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
    self:SetZoomLevel(1.0)
end

function SWEP:Think()
end

function SWEP:OnRemove()
    local owner = self:GetOwner()
    if IsValid(owner) then
        owner.PendingPhotoID = nil
    end
end

-- Receive zoom updates from client
net.Receive("PhotoCam_ZoomUpdate", function(len, ply)
    if not IsValid(ply) then return end
    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "weapon_photo_camera" then return end

    local zoom = net.ReadFloat()
    zoom = math.Clamp(zoom, wep.ZoomMin, wep.ZoomMax)
    wep:SetZoomLevel(zoom)
end)