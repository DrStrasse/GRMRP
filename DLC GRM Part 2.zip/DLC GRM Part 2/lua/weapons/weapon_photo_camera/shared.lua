-- lua/weapons/weapon_photo_camera/shared.lua

SWEP.PrintName = "Photo Camera"
SWEP.Author = "puddingheh"
SWEP.Instructions = "LMB: Take photo\nHold RMB + Move mouse: Zoom\nR: Reset zoom\nE: Pick up / drop photos"
SWEP.Category = "Investigation system"

SWEP.Spawnable = true
SWEP.AdminOnly = false

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.Weight = 5
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.Slot = 5
SWEP.SlotPos = 1
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true

SWEP.ViewModel = "models/weapons/c_arms_citizen.mdl"
SWEP.WorldModel = "models/maxofs2d/camera.mdl"
SWEP.UseHands = true
SWEP.HoldType = "camera"

SWEP.ZoomMin = 0.15
SWEP.ZoomMax = 1.0
SWEP.ZoomSpeed = 0.003  -- per raw mouse pixel
SWEP.ViewfinderFraction = 0.65  -- доля высоты экрана для рамки видоискателя
function SWEP:SetupDataTables()
    self:NetworkVar("Float", 0, "NextPhotoTime")
    self:NetworkVar("Float", 1, "ZoomLevel")
    self:NetworkVar("Int", 0, "PhotoCount")
end

function SWEP:Initialize()
    self:SetHoldType("camera")
    self:SetNextPhotoTime(0)
    self:SetZoomLevel(1.0)
    self:SetPhotoCount(0)
end

function SWEP:CanTakePhoto()
    return CurTime() >= self:GetNextPhotoTime()
end

-- Smooth FOV transition handled client-side
function SWEP:TranslateFOV(fov)
    if CLIENT then
        self.BaseFOV = fov
        return fov * (self.SmoothedZoom or self:GetZoomLevel())
    end
    return fov * self:GetZoomLevel()
end

function SWEP:Reload()
    if SERVER then
        self:SetZoomLevel(1.0)
    end
end

function SWEP:SecondaryAttack()
end