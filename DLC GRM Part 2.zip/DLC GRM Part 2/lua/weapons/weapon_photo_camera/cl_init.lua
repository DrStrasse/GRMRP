-- lua/weapons/weapon_photo_camera/cl_init.lua
local weaponIcon = Material("weapons/weapon_photo_camera.png", "noclamp smooth")

function SWEP:DrawWeaponSelection(x, y, wide, tall, alpha)
    surface.SetDrawColor(255, 255, 255, alpha)
    surface.SetMaterial(weaponIcon)

    -- Центрируем иконку
    local iconSize = math.min(wide, tall) - 64
    local iconX = x + (wide - iconSize) / 2
    local iconY = y + (tall - iconSize) / 2

    surface.DrawTexturedRect(iconX, iconY, iconSize, iconSize)
end
include("shared.lua")

SWEP.ViewModelFOV = 62
SWEP.ViewModelFlip = false

-- Zoom state
local targetZoom = 1.0
local smoothZoom = 1.0
local isZoomingRMB = false
local lastZoomSend = 0
local ZOOM_LERP_SPEED = 12
local ZOOM_SEND_INTERVAL = 0.1

function SWEP:DrawWorldModel()
    self:DrawModel()
end

function SWEP:PreDrawViewModel(vm, weapon, ply)
    return false
end

function SWEP:PostDrawViewModel(vm, weapon, ply)
end

function SWEP:Deploy()
    targetZoom = self:GetZoomLevel()
    smoothZoom = targetZoom
    isZoomingRMB = false
    return true
end

function SWEP:Holster()
    isZoomingRMB = false
    return true
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
    targetZoom = 1.0
    self:SendZoom(true)
end

function SWEP:Think()
    local dt = FrameTime()
    local lerpFactor = 1 - math.exp(-ZOOM_LERP_SPEED * dt)
    smoothZoom = Lerp(lerpFactor, smoothZoom, targetZoom)

    if math.abs(smoothZoom - targetZoom) < 0.001 then
        smoothZoom = targetZoom
    end

    self.SmoothedZoom = smoothZoom

    if not isZoomingRMB then
        local serverZoom = self:GetZoomLevel()
        if math.abs(targetZoom - serverZoom) > 0.01 then
            targetZoom = serverZoom
        end
    end
end

function SWEP:SendZoom(force)
    if not force and CurTime() - lastZoomSend < ZOOM_SEND_INTERVAL then return end
    lastZoomSend = CurTime()

    net.Start("PhotoCam_ZoomUpdate")
        net.WriteFloat(targetZoom)
    net.SendToServer()
end

-- Mouse input for zoom
hook.Add("InputMouseApply", "PhotoCamera_ZoomMouse", function(cmd, x, y, ang)
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local wep = ply:GetActiveWeapon()
    if not IsValid(wep) or wep:GetClass() ~= "weapon_photo_camera" then
        if isZoomingRMB then
            isZoomingRMB = false
        end
        return
    end

    if input.IsMouseDown(MOUSE_RIGHT) then
        isZoomingRMB = true

        if y ~= 0 then
            targetZoom = math.Clamp(targetZoom - y * wep.ZoomSpeed, wep.ZoomMin, wep.ZoomMax)
            wep:SendZoom()
        end

        cmd:SetViewAngles(Angle(ang.p, ang.y, ang.r))
        return true
    else
        if isZoomingRMB then
            isZoomingRMB = false
            wep:SendZoom(true)
        end
    end
end)

-- HUD
function SWEP:DrawHUD()
    local w, h = ScrW(), ScrH()
    local zoom = smoothZoom

    local vfFrac = self.ViewfinderFraction
    local vfW = h * vfFrac
    local vfH = h * vfFrac
    local vfX = (w - vfW) / 2
    local vfY = (h - vfH) / 2

    local bracketLen = 30
    local bracketThick = 2

    local col = Color(255, 255, 255, 180)
    if zoom < 0.95 then
        col = Color(255, 200, 50, 220)
    end
    if isZoomingRMB then
        col = Color(100, 200, 255, 220)
    end

    surface.SetDrawColor(col)

    surface.DrawRect(vfX, vfY, bracketLen, bracketThick)
    surface.DrawRect(vfX, vfY, bracketThick, bracketLen)

    surface.DrawRect(vfX + vfW - bracketLen, vfY, bracketLen, bracketThick)
    surface.DrawRect(vfX + vfW - bracketThick, vfY, bracketThick, bracketLen)

    surface.DrawRect(vfX, vfY + vfH - bracketThick, bracketLen, bracketThick)
    surface.DrawRect(vfX, vfY + vfH - bracketLen, bracketThick, bracketLen)

    surface.DrawRect(vfX + vfW - bracketLen, vfY + vfH - bracketThick, bracketLen, bracketThick)
    surface.DrawRect(vfX + vfW - bracketThick, vfY + vfH - bracketLen, bracketThick, bracketLen)

    -- Crosshair
    surface.SetDrawColor(255, 255, 255, 100)
    surface.DrawRect(w / 2 - 8, h / 2, 16, 1)
    surface.DrawRect(w / 2, h / 2 - 8, 1, 16)

    -- Cooldown
    if not self:CanTakePhoto() then
        local frac = (self:GetNextPhotoTime() - CurTime()) / PhotoCamera.Settings.CooldownTime
        draw.RoundedBox(4, w / 2 - 50, h / 2 + 40, 100, 8, Color(0, 0, 0, 150))
        draw.RoundedBox(4, w / 2 - 50, h / 2 + 40, 100 * (1 - frac), 8, Color(255, 255, 255, 200))
    end

    -- Zoom bar
    if zoom < 0.99 then
        local barX = vfX + vfW + 15
        local barY = vfY
        local barW = 8
        local barH = vfH

        draw.RoundedBox(4, barX, barY, barW, barH, Color(0, 0, 0, 120))

        local fillFrac = 1 - ((zoom - self.ZoomMin) / (self.ZoomMax - self.ZoomMin))
        local fillH = barH * fillFrac
        draw.RoundedBox(4, barX, barY + barH - fillH, barW, fillH, Color(255, 200, 50, 200))

        draw.SimpleText(math.Round((1 / zoom) * 100) .. "%", "DermaDefaultBold",
            barX + barW / 2, barY - 15,
            Color(255, 200, 50, 220), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end

    -- Instructions
    if isZoomingRMB then
        draw.SimpleText("↑ Zoom In    ↓ Zoom Out", "DermaDefault",
            w / 2, vfY + vfH + 15,
            Color(100, 200, 255, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    elseif zoom < 0.95 then
        draw.SimpleText("[R] Reset Zoom", "DermaDefault",
            w / 2, vfY + vfH + 15,
            Color(200, 200, 200, 150), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    else
        draw.SimpleText("Hold RMB + Move Mouse to Zoom", "DermaDefault",
            w / 2, vfY + vfH + 15,
            Color(200, 200, 200, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

-- Flash
local flashAlpha = 0
local flashTime = 0

net.Receive("PhotoCam_CameraFlash", function()
    local ply = net.ReadEntity()
    if IsValid(ply) and ply == LocalPlayer() then
        flashAlpha = PhotoCamera.Settings.FlashColor.a
        flashTime = CurTime()
    end
end)

hook.Add("HUDPaint", "PhotoCamera_FlashEffect", function()
    if flashAlpha <= 0 then return end
    local frac = 1 - math.Clamp((CurTime() - flashTime) / PhotoCamera.Settings.FlashDuration, 0, 1)
    surface.SetDrawColor(255, 255, 255, flashAlpha * frac)
    surface.DrawRect(0, 0, ScrW(), ScrH())
    if frac <= 0 then flashAlpha = 0 end
end)