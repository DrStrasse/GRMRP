AddCSLuaFile("shared.lua")
AddCSLuaFile("cl_init.lua")
include("shared.lua")

function SWEP:Initialize()
    self:SetHoldType("suitcase")
    self.ArchiveStoredPhotos = self.ArchiveStoredPhotos or {}
    self.ArchivePhotoDataCache = self.ArchivePhotoDataCache or {}
    self.IsBeingPlaced = false
end

function SWEP:Deploy()
    local owner = self:GetOwner()
    if not IsValid(owner) then return true end

    self:CreateSuitcaseModel(owner)
    return true
end

function SWEP:Holster()
    if self.IsBeingPlaced then return true end

    -- При переключении на другое оружие — ставим чемодан на землю
    local owner = self:GetOwner()
    if IsValid(owner) then
        self:DropSuitcase(owner)
    end

    return true
end

function SWEP:OnRemove()
    self:RemoveSuitcaseModel()

    if not self.IsBeingPlaced then
        local owner = self:GetOwner()
        if IsValid(owner) then
            self:SpawnArchiveEntity(owner, owner:GetPos() + Vector(0, 0, 20), Angle(0, owner:EyeAngles().y, 0))
        end
    end
end

function SWEP:PrimaryAttack()
    if CLIENT then return end

    self:SetNextPrimaryFire(CurTime() + 0.5)

    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    self:PlaceDown(owner)
end

function SWEP:SecondaryAttack()
end

function SWEP:Reload()
end

function SWEP:Think()
    local owner = self:GetOwner()
    if not IsValid(owner) then return end

    if SERVER and self.SuitcaseModelEnt and not IsValid(self.SuitcaseModelEnt) then
        self:CreateSuitcaseModel(owner)
    end
end

function SWEP:CreateSuitcaseModel(owner)
    self:RemoveSuitcaseModel()

    if CLIENT then return end

    local mdl = ents.Create("prop_dynamic")
    if not IsValid(mdl) then return end

    mdl:SetModel("models/props_c17/BriefCase001a.mdl")
    mdl:SetMoveType(MOVETYPE_NONE)
    mdl:SetSolid(SOLID_NONE)
    mdl:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
    mdl:SetNoDraw(false)
    mdl:Spawn()
    mdl:Activate()

    -- Пытаемся найти стандартный аттачмент для правой руки (самый надежный способ)
    local attachID = owner:LookupAttachment("anim_attachment_RH")

    if attachID and attachID > 0 then
        -- Если есть аттачмент, родителем ставим игрока, а привязку делаем к аттачменту
        mdl:SetParent(owner)
        
        -- Важно: SetAttachment работает не у всех пропов корректно напрямую, 
        -- поэтому используем Fire или ручную привязку. 
        -- Самый стабильный вариант для prop_dynamic:
        mdl:Fire("SetParentAttachmentMaintainOffset", "anim_attachment_RH", 0.01)
        
        -- Небольшая коррекция позиции и поворота относительно руки
        -- Аттачмент " RH" обычно смотрит вперед по оси X модели оружия
        mdl:SetLocalPos(Vector(2, -10, 20)) 
        mdl:SetLocalAngles(Angle(0, 0, 0)) -- Чемодан лежит плоско в руке
    else
        -- Если аттачмента нет (редкость), используем кость через FollowBone
        local boneID = owner:LookupBone("ValveBiped.Bip01_R_Hand")
        
        if boneID then
            mdl:SetParent(owner)
            mdl:FollowBone(owner, boneID)
            -- Подгонка под стандартную ориентацию кости кости (обычно "вниз" или "вбок")
            mdl:SetLocalPos(Vector(10, 0, 0))
            mdl:SetLocalAngles(Angle(90, 0, 180))
        else
            -- Если вообще ничего нет, просто парент к игроку (будет в центре)
            mdl:SetParent(owner)
            mdl:SetLocalPos(Vector(10, 0, 0))
            mdl:SetLocalAngles(Angle(90, 0, 180))
        end
    end

    mdl:SetOwner(owner)

    self.SuitcaseModelEnt = mdl
    self:SetSuitcaseModel(mdl)
end

function SWEP:RemoveSuitcaseModel()
    if IsValid(self.SuitcaseModelEnt) then
        self.SuitcaseModelEnt:Remove()
        self.SuitcaseModelEnt = nil
    end
end

--- Сбросить чемодан при переключении оружия
function SWEP:DropSuitcase(owner)
    if self.IsBeingPlaced then return end
    self.IsBeingPlaced = true

    self:RemoveSuitcaseModel()

    -- Бросаем перед игроком
    local forward = owner:GetAimVector()
    forward.z = 0
    if forward:Length() < 0.1 then
        forward = owner:GetForward()
        forward.z = 0
    end
    forward:Normalize()

    local dropPos = owner:GetPos() + forward * 50 + Vector(0, 0, 30)

    -- Трейс вперёд чтобы не спавнить в стене
    local wallTr = util.TraceLine({
        start = owner:GetPos() + Vector(0, 0, 30),
        endpos = dropPos,
        filter = owner,
        mask = MASK_SOLID_BRUSHONLY,
    })

    if wallTr.Hit then
        dropPos = wallTr.HitPos - forward * 5
    end

    self:SpawnArchiveEntity(owner, dropPos, Angle(0, owner:EyeAngles().y, 0))

    timer.Simple(0, function()
        if IsValid(owner) then
            owner:StripWeapon("weapon_photo_archive")
        end
    end)
end

function SWEP:PlaceDown(owner)
    if self.IsBeingPlaced then return end
    self.IsBeingPlaced = true

    self:RemoveSuitcaseModel()

    local tr = util.TraceLine({
        start = owner:GetShootPos(),
        endpos = owner:GetShootPos() + owner:GetAimVector() * 100,
        filter = {owner, self, self.SuitcaseModelEnt},
        mask = MASK_SOLID_BRUSHONLY,
    })

    local dropPos
    if tr.Hit then
        dropPos = tr.HitPos + tr.HitNormal * 5
    else
        dropPos = owner:GetShootPos() + owner:GetAimVector() * 80
    end

    local floorTr = util.TraceLine({
        start = dropPos,
        endpos = dropPos - Vector(0, 0, 200),
        filter = {owner, self, self.SuitcaseModelEnt},
        mask = MASK_SOLID_BRUSHONLY,
    })

    if floorTr.Hit then
        dropPos = floorTr.HitPos + Vector(0, 0, 5)
    end

    self:SpawnArchiveEntity(owner, dropPos, Angle(0, owner:EyeAngles().y, 0))
    owner:StripWeapon("weapon_photo_archive")
end

function SWEP:SpawnArchiveEntity(owner, pos, ang)
    if CLIENT then return end

    local spawnPos = pos
    local spawnAng = ang

    if not spawnPos then
        if IsValid(owner) then
            spawnPos = owner:GetPos() + owner:GetForward() * 30 + Vector(0, 0, 10)
            spawnAng = Angle(0, owner:EyeAngles().y, 0)
        else
            spawnPos = self:GetPos()
            spawnAng = self:GetAngles()
        end
    end

    local archive = ents.Create("ent_photo_archive")
    if not IsValid(archive) then return end

    archive:SetPos(spawnPos)
    archive:SetAngles(spawnAng or Angle(0, 0, 0))
    archive:Spawn()
    archive:Activate()

    archive.StoredPhotos = self.ArchiveStoredPhotos or {}
    archive.PhotoDataCache = self.ArchivePhotoDataCache or {}
    archive:SetStoredCount(#archive.StoredPhotos)

    for photoID, data in pairs(archive.PhotoDataCache) do
        if PhotoCamera.Server and PhotoCamera.Server.PhotoData then
            PhotoCamera.Server.PhotoData[photoID] = data
        end
    end

    local phys = archive:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(30)
    end

    local photoList = {}
    for _, pd in ipairs(archive.StoredPhotos) do
        local photoID = pd.id
        if archive.PhotoDataCache[photoID] then
            table.insert(photoList, photoID)
        end
    end

    for i, photoID in ipairs(photoList) do
        timer.Simple(i * 0.3, function()
            if not IsValid(archive) then return end
            if archive.PhotoDataCache[photoID] then
                PhotoCamera.Server.BroadcastPhotoData(photoID, archive.PhotoDataCache[photoID], nil)
            end
        end)
    end

    timer.Simple(#photoList * 0.3 + 0.5, function()
        if IsValid(archive) then
            archive:BroadcastSync()
        end
    end)

    return archive
end

function SWEP:OwnerDied()
    if self.IsBeingPlaced then return end
    self.IsBeingPlaced = true

    self:RemoveSuitcaseModel()

    local owner = self:GetOwner()
    local dropPos
    if IsValid(owner) then
        dropPos = owner:GetPos() + Vector(0, 0, 20)
    end

    self:SpawnArchiveEntity(owner, dropPos, IsValid(owner) and Angle(0, owner:EyeAngles().y, 0) or nil)
end

hook.Add("PlayerDeath", "PhotoArchive_DropOnDeath", function(victim, inflictor, attacker)
    if not IsValid(victim) then return end

    local wep = victim:GetWeapon("weapon_photo_archive")
    if IsValid(wep) then
        wep:OwnerDied()
        victim:StripWeapon("weapon_photo_archive")
    end
end)

hook.Add("PlayerDisconnected", "PhotoArchive_DisconnectDrop", function(ply)
    if not IsValid(ply) then return end

    local wep = ply:GetWeapon("weapon_photo_archive")
    if IsValid(wep) and not wep.IsBeingPlaced then
        wep.IsBeingPlaced = true
        wep:RemoveSuitcaseModel()
        wep:SpawnArchiveEntity(ply, ply:GetPos() + Vector(0, 0, 20))
    end
end)
