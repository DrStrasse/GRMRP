SWEP.PrintName = "Photo Archive Suitcase"
SWEP.Author = "puddingheh"
SWEP.Category = "Investigation system"
SWEP.Spawnable = false
SWEP.AdminSpawnable = false

SWEP.Primary.ClipSize = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic = false
SWEP.Primary.Ammo = "none"

SWEP.Secondary.ClipSize = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic = false
SWEP.Secondary.Ammo = "none"

SWEP.Weight = 5
SWEP.AutoSwitchTo = false
SWEP.AutoSwitchFrom = false

SWEP.Slot = 5
SWEP.SlotPos = 10
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = true

SWEP.HoldType = "suitcase"
SWEP.ViewModelFOV = 54
SWEP.ViewModel = ""
SWEP.WorldModel = ""
SWEP.UseHands = false

SWEP.ArchiveStoredPhotos = nil
SWEP.ArchivePhotoDataCache = nil
SWEP.IsBeingPlaced = false

function SWEP:SetupDataTables()
    self:NetworkVar("Int", 0, "StoredCount")
    self:NetworkVar("Entity", 0, "SuitcaseModel")
end

function SWEP:Initialize()
    self:SetHoldType("suitcase")
    self.ArchiveStoredPhotos = self.ArchiveStoredPhotos or {}
    self.ArchivePhotoDataCache = self.ArchivePhotoDataCache or {}
    self.IsBeingPlaced = false
end
