include("shared.lua")

SWEP.PrintName = "Suitcase"
SWEP.Slot = 5
SWEP.SlotPos = 10
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false
SWEP.ViewModelFlip = false
SWEP.Instructions = "LMB — Drop Suitcase"
function SWEP:Initialize()
    self:SetHoldType("suitcase")
end

function SWEP:Deploy()
    self:SetHoldType("suitcase")
    return true
end

function SWEP:DrawWorldModel()
end

function SWEP:ViewModelDrawn()
end

function SWEP:DrawHUD()
end

function SWEP:CalcView(ply, pos, ang, fov)
    -- Убираем качание от первого лица
    return pos, ang, fov
end

function SWEP:CalcViewModelView(vm, oldEyePos, oldEyeAng, eyePos, eyeAng)
    -- Не показываем viewmodel вообще
    return eyePos, eyeAng
end

function SWEP:GetViewModelPosition(pos, ang)
    -- Скрываем viewmodel
    return pos, ang
end

function SWEP:PrimaryAttack()
end

function SWEP:SecondaryAttack()
end