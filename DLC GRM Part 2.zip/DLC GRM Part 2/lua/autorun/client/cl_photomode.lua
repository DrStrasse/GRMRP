local in_photomode = false
local cam_pos = Vector()
local cam_ang = Angle()

net.Receive("Photomode_Toggle", function()
    in_photomode = net.ReadBool()
    
    if in_photomode then
        cam_pos = LocalPlayer():EyePos()
        cam_ang = LocalPlayer():EyeAngles()
        
        if Glide and Glide.Camera then
            Glide.Camera.isPlayerUsingCamController = true
        end
    else
        if Glide and Glide.Camera then
            Glide.Camera.isPlayerUsingCamController = false
        end
    end
end)

hook.Add("Think", "Photomode_Movement", function()
    if not in_photomode or gui.IsGameUIVisible() then return end

    local speed = 200 * RealFrameTime() 
    if input.IsKeyDown(KEY_LSHIFT) then speed = speed * 3 end

    local forward = cam_ang:Forward()
    local right = cam_ang:Right()

    if input.IsKeyDown(KEY_W) then cam_pos = cam_pos + forward * speed end
    if input.IsKeyDown(KEY_S) then cam_pos = cam_pos - forward * speed end
    if input.IsKeyDown(KEY_A) then cam_pos = cam_pos - right * speed end
    if input.IsKeyDown(KEY_D) then cam_pos = cam_pos + right * speed end
    if input.IsKeyDown(KEY_SPACE) then cam_pos = cam_pos + Vector(0,0,1) * speed end
    if input.IsKeyDown(KEY_LCONTROL) then cam_pos = cam_pos - Vector(0,0,1) * speed end

    local x, y = gui.MouseX(), gui.MouseY()
end)

hook.Add("InputMouseApply", "Photomode_MouseLook", function(cmd, x, y, ang)
    if not in_photomode or gui.IsGameUIVisible() then return end
    
    cam_ang.y = cam_ang.y - x * 0.05
    cam_ang.p = math.Clamp(cam_ang.p + y * 0.05, -89, 89)
    
    return true
end)

hook.Add("CalcView", "Photomode_Camera", function(ply, pos, angles, fov)
    if not in_photomode then return end

    return {
        origin = cam_pos,
        angles = cam_ang,
        fov = fov,
        drawviewer = true
    }
end)

hook.Add("CreateMove", "Photomode_BlockInput", function(cmd)
    if in_photomode then
        cmd:ClearMovement()
        cmd:ClearButtons()
        return true
    end
end)

hook.Add("HUDShouldDraw", "Photomode_HideHUD", function(name)
    if in_photomode and name ~= "CHudChat" then 
        return false 
    end
end)

hook.Add("PlayerBindPress", "Photomode_BlockBinds", function(ply, bind, pressed)
    if in_photomode and (string.find(bind, "+attack") or string.find(bind, "+jump") or string.find(bind, "+duck")) then
        return true 
    end
end)

local lmb_was_down = false

hook.Add("Think", "Photomode_Screenshot", function()
    if not in_photomode or gui.IsGameUIVisible() then return end

    local lmb_is_down = input.IsMouseDown(MOUSE_LEFT)

    if lmb_is_down and not lmb_was_down then
        
        surface.PlaySound("npc/scanner/scanner_photo1.wav")
        
        RunConsoleCommand("jpeg")
        
    end

    lmb_was_down = lmb_is_down
end)

local IsSilenceRequired = false

net.Receive("Photomode_SilenceNotification", function()
    IsSilenceRequired = true
    
    timer.Create("Photomode_ResetChatFilter", 0.5, 1, function()
        IsSilenceRequired = false
    end)
end)

hook.Add("ChatText", "Photomode_HideCVarSpam", function(index, name, text, type)
    if IsSilenceRequired and string.find(text, "ai_disabled") then
        return true 
    end
end)