util.AddNetworkString("Photomode_Toggle")
util.AddNetworkString("Photomode_SilenceNotification")

local function ResetPlayerGlideVehicle(ply)
    if not IsValid(ply) then return end
    local veh = ply:GetVehicle()
    if IsValid(veh) then
        local glideVeh = veh.GlideVehicle or veh:GetParent()
        if IsValid(glideVeh) and glideVeh.ResetInputs then
            glideVeh:ResetInputs(1)
            glideVeh:ResetInputs(2)
        end
    end
end

local ActivePhotomodes = 0
local OriginalAIDisabled = false

local function SetAIDisabledSmart(stateStr)
    net.Start("Photomode_SilenceNotification")
    net.Broadcast()
    
    RunConsoleCommand("ai_disabled", stateStr)
end

concommand.Add("photomode", function(ply)
    if not IsValid(ply) then return end

    ply.InPhotomode = not ply.InPhotomode

    if ply.InPhotomode then
        ResetPlayerGlideVehicle(ply)

        ply.PrePhotoMoveType = ply:GetMoveType()
        ply.PrePhotoVelocity = ply:GetVelocity()
        
        ply:SetMoveType(MOVETYPE_NONE)

        ActivePhotomodes = ActivePhotomodes + 1
        if ActivePhotomodes == 1 then
            OriginalAIDisabled = GetConVar("ai_disabled"):GetBool()
            SetAIDisabledSmart("1")
            
            physenv.SetTimeScale(0)
            game.SetTimeScale(0.001)
        end
    else
        ply:SetMoveType(ply.PrePhotoMoveType or MOVETYPE_WALK)
        ply:SetVelocity(ply.PrePhotoVelocity or Vector(0, 0, 0))

        ActivePhotomodes = math.max(0, ActivePhotomodes - 1)
        if ActivePhotomodes == 0 then
            SetAIDisabledSmart(OriginalAIDisabled and "1" or "0")
            
            physenv.SetTimeScale(1)
            game.SetTimeScale(1)
        end
    end

    net.Start("Photomode_Toggle")
    net.WriteBool(ply.InPhotomode)
    net.Send(ply)
end)

hook.Add("PlayerDisconnected", "Photomode_EmergencyRestore", function(ply)
    if ply.InPhotomode then
        ActivePhotomodes = math.max(0, ActivePhotomodes - 1)
        if ActivePhotomodes == 0 then
            SetAIDisabledSmart(OriginalAIDisabled and "1" or "0")
            physenv.SetTimeScale(1)
            game.SetTimeScale(1)
        end
    end
end)

concommand.Add("freecam", function(ply)
    if not IsValid(ply) then return end
    if ply.InPhotomode then return end

    ply.InFreecam = not ply.InFreecam

    if ply.InFreecam then
        ResetPlayerGlideVehicle(ply)

        ply.PrePhotoMoveType = ply:GetMoveType()
        ply.PrePhotoVelocity = ply:GetVelocity()
        ply:SetMoveType(MOVETYPE_NONE)
    else
        ply:SetMoveType(ply.PrePhotoMoveType or MOVETYPE_WALK)
        ply:SetVelocity(ply.PrePhotoVelocity or Vector(0, 0, 0))
    end

    net.Start("Photomode_Toggle")
    net.WriteBool(ply.InFreecam)
    net.Send(ply)
end)

local function DetourGlideVehicle(ent)
    if not IsValid(ent) or not ent.IsGlideVehicle then return end
    if ent.PhotomodeDetoured then return end
    ent.PhotomodeDetoured = true

    if ent.SetInputBool then
        local oldSetInputBool = ent.SetInputBool
        ent.SetInputBool = function(self, seatIndex, action, pressed)
            local driver = self:GetDriver()
            if IsValid(driver) and (driver.InPhotomode or driver.InFreecam) then
                pressed = false 
            end
            return oldSetInputBool(self, seatIndex, action, pressed)
        end
    end

    if ent.SetInputFloat then
        local oldSetInputFloat = ent.SetInputFloat
        ent.SetInputFloat = function(self, seatIndex, action, value)
            local driver = self:GetDriver()
            if IsValid(driver) and (driver.InPhotomode or driver.InFreecam) then
                value = 0 
            end
            return oldSetInputFloat(self, seatIndex, action, value)
        end
    end
end

hook.Add("OnEntityCreated", "Photomode_BlockGlideInput", function(ent)
    timer.Simple(0, function()
        DetourGlideVehicle(ent)
    end)
end)

for _, ent in ipairs(ents.GetAll()) do
    DetourGlideVehicle(ent)
end

hook.Add("EntityFireBullets", "Photomode_BlockBullets", function(ent, data)
    for _, p in ipairs(player.GetAll()) do
        if p.InPhotomode then
            return false
        end
    end
end)