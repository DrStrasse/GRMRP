-- lua/autorun/sh_photocamera_init.lua

PhotoCamera = PhotoCamera or {}

PhotoCamera.Config = {
    MaxPhotos = "photocam_max_photos",
    PhotoSize = "photocam_photo_size",
    MaxBoardPhotos = "photocam_max_board_photos",
    PhotoQuality = "photocam_quality",
    StringColor = "photocam_string_color",
    CooldownTime = "photocam_cooldown",
    MaxStrings = "photocam_max_strings",
    PhotoLifetime = "photocam_photo_lifetime",
    BoardInteractDist = "photocam_board_dist",
}

PhotoCamera.NetStrings = {
    "PhotoCam_TakePhoto",
    "PhotoCam_PhotoData",
    "PhotoCam_PhotoMaterial",
    "PhotoCam_SpawnPhoto",
    "PhotoCam_DeletePhoto",
    "PhotoCam_BoardAttach",
    "PhotoCam_BoardDetach",
    "PhotoCam_BoardMovePhoto",
    "PhotoCam_BoardAddString",
    "PhotoCam_BoardRemoveString",
    "PhotoCam_BoardSync",
    "PhotoCam_BoardSyncRequest",
    "PhotoCam_PhotoDataChunk",
    "PhotoCam_PhotoDataComplete",
    "PhotoCam_RequestRender",
    "PhotoCam_CameraFlash",
    "PhotoCam_PickupPhoto",
    "PhotoCam_BoardAddText",
    "PhotoCam_BoardRemoveText",
    "PhotoCam_BoardMoveText",
    "PhotoCam_BoardResizePhoto",
    "PhotoCam_BoardDeletePhoto",
    "PhotoCam_BoardEditText",
    "PhotoCam_BoardResizeText",
    "PhotoCam_BoardSetZoneScale",
    "PhotoCam_BoardToggleModel",
    "PhotoCam_ZoomUpdate",
    "PhotoCam_PrinterSetURL",
    "PhotoCam_PrinterImageData",
    "PhotoCam_PrinterImageReady",
    "PhotoCam_ArchiveStore",
    "PhotoCam_ArchiveRetrieve",
    "PhotoCam_ArchiveSync",
    "PhotoCam_ArchiveSyncRequest",
    "PhotoCam_ArchiveOpenUI",
    "PhotoCam_BoardOpenUI",
    "PhotoCam_PrinterLocalData",
    "PhotoCam_ArchivePickup",
}

if SERVER then
    for _, str in ipairs(PhotoCamera.NetStrings) do
        util.AddNetworkString(str)
    end
end

local function IncludeFile(path)
    local fullPath = "photocamera/" .. path

    if SERVER then
        if path:find("^sh_") then
            AddCSLuaFile(fullPath)
            include(fullPath)
        elseif path:find("^sv_") then
            include(fullPath)
        elseif path:find("^cl_") then
            AddCSLuaFile(fullPath)
        end
    else
        if path:find("^sh_") or path:find("^cl_") then
            include(fullPath)
        end
    end
end

IncludeFile("sh_config.lua")
IncludeFile("sh_utils.lua")

if SERVER then
    AddCSLuaFile("photocamera/cl_capture.lua")
    AddCSLuaFile("photocamera/cl_photo_render.lua")
    AddCSLuaFile("photocamera/cl_board_ui.lua")
    AddCSLuaFile("photocamera/cl_strings.lua")
    AddCSLuaFile("photocamera/cl_printer.lua")
    AddCSLuaFile("photocamera/cl_archive.lua")
    IncludeFile("sv_networking.lua")
    IncludeFile("sv_photo.lua")
    IncludeFile("sv_board.lua")
    IncludeFile("sv_printer.lua")
    IncludeFile("sv_archive.lua")
end

if CLIENT then
    IncludeFile("cl_capture.lua")
    IncludeFile("cl_photo_render.lua")
    IncludeFile("cl_board_ui.lua")
    IncludeFile("cl_strings.lua")
    IncludeFile("cl_printer.lua")
    IncludeFile("cl_archive.lua")
end

if CLIENT then

    list.Set("SpawnableEntities", "ent_photo_board", {
        PrintName = "Investigation Board",
        ClassName = "ent_photo_board",
        Category = "Investigation system",
    })
    list.Set("SpawnableEntities", "ent_photo_printer", {
        PrintName = "Photo Printer",
        ClassName = "ent_photo_printer",
        Category = "Investigation system",
    })
    list.Set("SpawnableEntities", "ent_photo_archive", {
        PrintName = "Photo Archive",
        ClassName = "ent_photo_archive",
        Category = "Investigation system",
    })
end