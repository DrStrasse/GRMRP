-- lua/photocamera/cl_board_ui.lua

PhotoCamera.BoardUI = PhotoCamera.BoardUI or {}
PhotoCamera.BoardUI.Active = false
PhotoCamera.BoardUI.Board = nil
PhotoCamera.BoardUI.DraggingPhoto = nil
PhotoCamera.BoardUI.DraggingText = nil
PhotoCamera.BoardUI.ResizingPhoto = nil
PhotoCamera.BoardUI.ResizingText = nil
PhotoCamera.BoardUI.ResizeStartX = 0
PhotoCamera.BoardUI.ResizeStartScale = 1
PhotoCamera.BoardUI.StringMode = false
PhotoCamera.BoardUI.StringStartID = nil
PhotoCamera.BoardUI.BoardState = nil
PhotoCamera.BoardUI.HoveredPhotoID = nil
PhotoCamera.BoardUI.HoveredTextIndex = nil
PhotoCamera.BoardUI.SavedSizes = PhotoCamera.BoardUI.SavedSizes or {}

local MIN_W, MIN_H = 600, 400
local DEF_W, DEF_H = 900, 650
local TOOLBAR_H = 50
local HEADER_H = 25
local BASE_PHOTO = 80
local PHOTO_BRD = 5
local PIN_R = 6
local RSZ_H = 12
local WIN_RSZ = 18

local function DrawCircle(x, y, radius, color, segments)
    segments = segments or 24
    local circle = {}
    for i = 0, segments do
        local a = math.rad((i / segments) * 360)
        table.insert(circle, {
            x = x + math.cos(a) * radius,
            y = y + math.sin(a) * radius,
        })
    end
    draw.NoTexture()
    surface.SetDrawColor(color)
    surface.DrawPoly(circle)
end

local function DrawSmoothLine(points, thickness, color)
    if #points < 2 then return end

    draw.NoTexture()
    surface.SetDrawColor(color)

    local half = thickness / 2
    local side1 = {}
    local side2 = {}

    for i = 1, #points do
        local dx, dy

        if i == 1 then
            dx = points[2].x - points[1].x
            dy = points[2].y - points[1].y
        elseif i == #points then
            dx = points[#points].x - points[#points - 1].x
            dy = points[#points].y - points[#points - 1].y
        else
            dx = points[i + 1].x - points[i - 1].x
            dy = points[i + 1].y - points[i - 1].y
        end

        local len = math.sqrt(dx * dx + dy * dy)
        if len < 0.001 then dx, dy, len = 1, 0, 1 end

        local nx = -dy / len * half
        local ny =  dx / len * half

        side1[i] = { x = points[i].x + nx, y = points[i].y + ny }
        side2[i] = { x = points[i].x - nx, y = points[i].y - ny }
    end

    for i = 1, #points - 1 do
        surface.DrawPoly({
            side1[i],
            side2[i],
            side2[i + 1],
            side1[i + 1],
        })
    end
end

local uiFonts = {}
local function UIFont(s)
    local k = math.Round(s * 10)
    if not uiFonts[k] then
        surface.CreateFont("PCU_" .. k, {
            font = "Arial", size = math.max(8, math.Round(14 * s)),
            weight = 700, antialias = true })
        uiFonts[k] = "PCU_" .. k
    end
    return uiFonts[k]
end

local function PinPos(p, cw, ch, zs)
    zs = zs or 1
    local s = (p.scale or 1) * BASE_PHOTO / zs
    local px = p.u * cw
    local py = (1 - p.v) * ch
    return px, py - s / 2 - 1
end

local function BoardKey(b)
    return IsValid(b) and tostring(b:EntIndex()) or "x"
end

local function SaveSize(b, w, h)
    PhotoCamera.BoardUI.SavedSizes[BoardKey(b)] = {w = w, h = h}
end

local function LoadSize(b)
    local s = PhotoCamera.BoardUI.SavedSizes[BoardKey(b)]
    return s and s.w or DEF_W, s and s.h or DEF_H
end

-- ===== NET =====

net.Receive("PhotoCam_BoardSync", function()
    local board = net.ReadEntity()
    local dl = net.ReadUInt(32)
    local cd = net.ReadData(dl)
    local j = util.Decompress(cd)
    if not j then return end
    local st = util.JSONToTable(j)
    if not st then return end

    if IsValid(board) and board.BoardState ~= nil then board.BoardState = st end
    if IsValid(board) then
        if st.zoneScale then board:SetZoneScale(st.zoneScale) end
        if st.displayMode ~= nil then board:SetDisplayMode(st.displayMode) end
    end

    if PhotoCamera.BoardUI.Active and PhotoCamera.BoardUI.Board == board then
        PhotoCamera.BoardUI.BoardState = st
        PhotoCamera.BoardUI.RebuildCanvas()
    end
end)

net.Receive("PhotoCam_BoardOpenUI", function()
    local board = net.ReadEntity()
    local dl = net.ReadUInt(32)
    local cd = net.ReadData(dl)
    local j = util.Decompress(cd)
    if not j then return end
    local st = util.JSONToTable(j)
    if not st then return end

    if IsValid(board) and board.BoardState ~= nil then board.BoardState = st end
    if IsValid(board) then
        if st.zoneScale then board:SetZoneScale(st.zoneScale) end
        if st.displayMode ~= nil then board:SetDisplayMode(st.displayMode) end
    end

    PhotoCamera.BoardUI.BoardState = st
    PhotoCamera.BoardUI.Board = board
    PhotoCamera.BoardUI.OpenPanel()
end)

-- ===== OPEN =====

function PhotoCamera.BoardUI.OpenPanel()
    if IsValid(PhotoCamera.BoardUI.Panel) then PhotoCamera.BoardUI.Panel:Remove() end

    PhotoCamera.BoardUI.Active = true
    PhotoCamera.BoardUI.DraggingPhoto = nil
    PhotoCamera.BoardUI.DraggingText = nil
    PhotoCamera.BoardUI.ResizingPhoto = nil
    PhotoCamera.BoardUI.ResizingText = nil
    PhotoCamera.BoardUI.StringMode = false
    PhotoCamera.BoardUI.StringStartID = nil
    PhotoCamera.BoardUI.HoveredPhotoID = nil
    PhotoCamera.BoardUI.HoveredTextIndex = nil

    local board = PhotoCamera.BoardUI.Board
    local sw, sh = LoadSize(board)

    local frame = vgui.Create("DFrame")
    frame:SetSize(sw, sh)
    frame:Center()
    frame:MakePopup()
    frame:SetDeleteOnClose(true)
    frame:SetDraggable(true)
    frame:SetSizable(false)
    frame:SetTitle("")

    frame.OnClose = function()
        SaveSize(PhotoCamera.BoardUI.Board, frame:GetSize())
        PhotoCamera.BoardUI.Active = false
        hook.Remove("Think", "PCam_WinRsz")
    end

    frame.Paint = function(self, w, h)
        draw.RoundedBox(4, 0, 0, w, h, Color(50, 50, 50, 240))
        draw.RoundedBoxEx(4, 0, 0, w, HEADER_H, Color(70, 70, 70, 255), true, true, false, false)

        draw.SimpleText("Investigation Board",
            "DermaDefaultBold", 8, 5, Color(255, 255, 255))

        -- Window resize handle
        surface.SetDrawColor(150, 150, 150, 200)
        for i = 0, WIN_RSZ - 3, 4 do
            surface.DrawLine(w - WIN_RSZ + i, h - 1, w - 1, h - WIN_RSZ + i)
            surface.DrawLine(w - WIN_RSZ + i + 1, h - 1, w - 1, h - WIN_RSZ + i + 1)
        end
    end

    PhotoCamera.BoardUI.Panel = frame

    -- Window resize
    local rsz = false
    local rsx, rsy, rsw, rsh = 0, 0, 0, 0

    hook.Add("Think", "PCam_WinRsz", function()
        if not IsValid(frame) then hook.Remove("Think", "PCam_WinRsz"); return end

        if rsz then
            if not input.IsMouseDown(MOUSE_LEFT) then
                rsz = false
                SaveSize(PhotoCamera.BoardUI.Board, frame:GetSize())
                PhotoCamera.BoardUI.LayoutAll()
                frame:SetDraggable(true)
            else
                local nw = math.Clamp(rsw + gui.MouseX() - rsx, MIN_W, ScrW() - 20)
                local nh = math.Clamp(rsh + gui.MouseY() - rsy, MIN_H, ScrH() - 20)
                frame:SetSize(nw, nh)
                PhotoCamera.BoardUI.LayoutAll()
            end
        elseif input.IsMouseDown(MOUSE_LEFT) and not PhotoCamera.BoardUI.DraggingPhoto
            and not PhotoCamera.BoardUI.DraggingText and not PhotoCamera.BoardUI.ResizingPhoto
            and not PhotoCamera.BoardUI.ResizingText then
            local mx, my = frame:ScreenToLocal(gui.MouseX(), gui.MouseY())
            local w, h = frame:GetSize()
            if mx >= w - WIN_RSZ and my >= h - WIN_RSZ then
                rsz = true
                rsx, rsy = gui.MouseX(), gui.MouseY()
                rsw, rsh = w, h
                frame:SetDraggable(false)
            end
        end

        if not rsz then frame:SetDraggable(true) end
    end)

    PhotoCamera.BoardUI.LayoutAll()
end

-- ===== LAYOUT =====

function PhotoCamera.BoardUI.LayoutAll()
    local frame = PhotoCamera.BoardUI.Panel
    if not IsValid(frame) then return end
    local fw, fh = frame:GetSize()

    if IsValid(PhotoCamera.BoardUI.Viewport) then PhotoCamera.BoardUI.Viewport:Remove() end
    if PhotoCamera.BoardUI.TBE then
        for _, e in ipairs(PhotoCamera.BoardUI.TBE) do if IsValid(e) then e:Remove() end end
    end
    PhotoCamera.BoardUI.TBE = {}

    local vpW = fw - 20
    local vpH = fh - HEADER_H - TOOLBAR_H - 15

    local vp = vgui.Create("DPanel", frame)
    vp:SetPos(10, HEADER_H)
    vp:SetSize(vpW, vpH)
    vp.Paint = function(_, w, h) end

    PhotoCamera.BoardUI.Viewport = vp
    PhotoCamera.BoardUI.ViewportW = vpW
    PhotoCamera.BoardUI.ViewportH = vpH

    PhotoCamera.BoardUI.BuildCanvas()
    PhotoCamera.BoardUI.BuildToolbar(frame, fw, fh)
end

function PhotoCamera.BoardUI.DoScroll(d)
    -- No scrolling needed: entire zone always visible
end

-- ===== CANVAS =====

function PhotoCamera.BoardUI.BuildCanvas()
    local vp = PhotoCamera.BoardUI.Viewport
    if not IsValid(vp) then return end
    if IsValid(PhotoCamera.BoardUI.Canvas) then PhotoCamera.BoardUI.Canvas:Remove() end

    local st = PhotoCamera.BoardUI.BoardState or {}
    local zs = st.zoneScale or 1
    local vpW = PhotoCamera.BoardUI.ViewportW
    local vpH = PhotoCamera.BoardUI.ViewportH

    -- Сохраняем соотношение сторон доски из 3D
    local settings = PhotoCamera.Settings
    local boardAspect = settings.BoardWidth / settings.BoardHeight

    local cvW, cvH
    if vpW / vpH > boardAspect then
        -- Viewport шире чем доска — ограничиваем по высоте
        cvH = vpH
        cvW = math.floor(vpH * boardAspect)
    else
        -- Viewport уже чем доска — ограничиваем по ширине
        cvW = vpW
        cvH = math.floor(vpW / boardAspect)
    end

    local cvX = math.floor((vpW - cvW) / 2)
    local cvY = math.floor((vpH - cvH) / 2)

    local cv = vgui.Create("DPanel", vp)
    cv:SetPos(cvX, cvY)
    cv:SetSize(cvW, cvH)

    PhotoCamera.BoardUI.Canvas = cv
    PhotoCamera.BoardUI.CanvasW = cvW
    PhotoCamera.BoardUI.CanvasH = cvH

    cv.Paint = function(_, w, h)
        -- Cork board fills entire canvas
        surface.SetDrawColor(180, 140, 90, 255)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(170, 130, 80, 100)
        local gs = 20
        for x = 0, w, gs do surface.DrawLine(x, 0, x, h) end
        for y = 0, h, gs do surface.DrawLine(0, y, w, y) end
        surface.SetDrawColor(100, 70, 40, 120)
        surface.DrawOutlinedRect(0, 0, w, h, 2)

        local cur = PhotoCamera.BoardUI.BoardState
        local curZs = (cur and cur.zoneScale) or 1

        if cur and cur.strings then
            for _, str in ipairs(cur.strings) do
                local fr = PhotoCamera.BoardUI.FindPhoto(str[1])
                local to = PhotoCamera.BoardUI.FindPhoto(str[2])
                if fr and to then
                    local fx, fy = PinPos(fr, w, h, curZs)
                    local tx, ty = PinPos(to, w, h, curZs)

                    local segments = 30
                    local points = {}
                    for i = 0, segments do
                        local f = i / segments
                        local cx = Lerp(f, fx, tx)
                        local cy = Lerp(f, fy, ty) + math.sin(f * math.pi) * 10
                        table.insert(points, { x = cx, y = cy })
                    end

                    DrawSmoothLine(points, 3, PhotoCamera.Settings.StringColor)
                end
            end
        end

        if PhotoCamera.BoardUI.StringMode then
            draw.RoundedBox(4, w / 2 - 140, 2, 280, 22, Color(180, 30, 30, 200))
            draw.SimpleText("STRING MODE: Click two photos", "DermaDefaultBold",
                w / 2, 13, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            if PhotoCamera.BoardUI.StringStartID then
                local sp = PhotoCamera.BoardUI.FindPhoto(PhotoCamera.BoardUI.StringStartID)
                if sp then
                    local sx, sy = PinPos(sp, w, h, curZs)
                    local mx, my = cv:ScreenToLocal(gui.MouseX(), gui.MouseY())
                    surface.SetDrawColor(255, 50, 50, 150)
                    for t = -1, 1 do surface.DrawLine(sx, sy + t, mx, my + t) end
                end
            end
        end
    end

    PhotoCamera.BoardUI.PopulateCanvas()
end

function PhotoCamera.BoardUI.UpdateCanvasPos()
    local cv = PhotoCamera.BoardUI.Canvas
    if IsValid(cv) then cv:SetPos(0, 0) end
end

function PhotoCamera.BoardUI.RebuildCanvas()
    if IsValid(PhotoCamera.BoardUI.Panel) then PhotoCamera.BoardUI.BuildCanvas() end
end

-- ===== POPULATE =====

function PhotoCamera.BoardUI.PopulateCanvas()
    local cv = PhotoCamera.BoardUI.Canvas
    if not IsValid(cv) then return end
    for _, c in ipairs(cv:GetChildren()) do c:Remove() end

    local st = PhotoCamera.BoardUI.BoardState
    if not st then return end
    local cw, ch = cv:GetSize()
    local zs = st.zoneScale or 1

    if st.photos then
        for _, pd in ipairs(st.photos) do PhotoCamera.BoardUI.MkPhoto(cv, pd, cw, ch, zs) end
    end
    if st.texts then
        for i, td in ipairs(st.texts) do PhotoCamera.BoardUI.MkText(cv, td, i, cw, ch, zs) end
    end
end

function PhotoCamera.BoardUI.MkPhoto(cv, pd, cw, ch, zs)
    zs = zs or 1
    local s = pd.scale or 1
    local ps = BASE_PHOTO * s / zs

    local p = vgui.Create("DPanel", cv)
    p:SetPos(pd.u * cw - ps / 2, (1 - pd.v) * ch - ps / 2)
    p:SetSize(ps, ps + 15)
    p.PID = pd.id; p.PS = s; p.PD = pd; p.ZS = zs

    p.Paint = function(self, w, h)
        local sc = self.PS or 1
        local sz = BASE_PHOTO * sc / self.ZS

        draw.RoundedBox(0, 0, 0, sz, sz + 12, PhotoCamera.Settings.PhotoBorderColor)
        local mt = PhotoCamera.Capture and PhotoCamera.Capture.GetMaterial(self.PD.id)
        if mt and not mt:IsError() then
            surface.SetDrawColor(255, 255, 255)
            surface.SetMaterial(mt)
            surface.DrawTexturedRect(PHOTO_BRD, PHOTO_BRD, sz - PHOTO_BRD * 2, sz - PHOTO_BRD * 2)
        else
            surface.SetDrawColor(100, 100, 100)
            surface.DrawRect(PHOTO_BRD, PHOTO_BRD, sz - PHOTO_BRD * 2, sz - PHOTO_BRD * 2)
        end

        if self:IsHovered() then
            surface.SetDrawColor(255, 255, 100, 60)
            surface.DrawRect(0, 0, sz, sz + 12)
            PhotoCamera.BoardUI.HoveredPhotoID = self.PID
        end

        DisableClipping(true)
        DrawCircle(sz / 2, -1, PIN_R, PhotoCamera.Settings.PinColor)
        DisableClipping(false)

        surface.SetDrawColor(100, 100, 100, 180)
        surface.DrawRect(sz - RSZ_H, sz + 12 - RSZ_H, RSZ_H, RSZ_H)
        surface.SetDrawColor(200, 200, 200, 200)
        for o = 2, RSZ_H - 2, 3 do
            surface.DrawLine(sz - RSZ_H + o, sz + 12, sz, sz + 12 - RSZ_H + o)
        end
    end

    p.OnMousePressed = function(self, k)
        if k ~= MOUSE_LEFT then return end
        if PhotoCamera.BoardUI.StringMode then
            if not PhotoCamera.BoardUI.StringStartID then
                PhotoCamera.BoardUI.StringStartID = self.PID
            else
                local b = PhotoCamera.BoardUI.Board
                if IsValid(b) then
                    net.Start("PhotoCam_BoardAddString")
                    net.WriteEntity(b); net.WriteString(PhotoCamera.BoardUI.StringStartID)
                    net.WriteString(self.PID); net.SendToServer()
                end
                PhotoCamera.BoardUI.StringStartID = nil
            end
            return
        end
        local sc = self.PS or 1; local sz = BASE_PHOTO * sc / self.ZS
        local lx, ly = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
        if lx >= sz - RSZ_H and ly >= sz + 12 - RSZ_H then
            PhotoCamera.BoardUI.ResizingPhoto = self
            PhotoCamera.BoardUI.ResizeStartX = gui.MouseX()
            PhotoCamera.BoardUI.ResizeStartScale = sc
        else
            PhotoCamera.BoardUI.DraggingPhoto = self
        end
    end

    p.OnMouseWheeled = function(_, d) PhotoCamera.BoardUI.DoScroll(d) end

    p.Think = function(self)
        if PhotoCamera.BoardUI.ResizingPhoto == self then
            if not input.IsMouseDown(MOUSE_LEFT) then
                local b = PhotoCamera.BoardUI.Board
                if IsValid(b) then
                    net.Start("PhotoCam_BoardResizePhoto")
                    net.WriteEntity(b); net.WriteString(self.PID)
                    net.WriteFloat(self.PS); net.SendToServer()
                end
                PhotoCamera.BoardUI.ResizingPhoto = nil
            else
                local ns = PhotoCamera.BoardUI.ResizeStartScale + (gui.MouseX() - PhotoCamera.BoardUI.ResizeStartX) / 100
                ns = math.Clamp(ns, PhotoCamera.Settings.PhotoMinScale, PhotoCamera.Settings.PhotoMaxScale)
                self.PS = ns
                local vsz = BASE_PHOTO * ns / self.ZS
                self:SetSize(vsz, vsz + 15)
            end; return
        end
        if PhotoCamera.BoardUI.DraggingPhoto == self then
            if not input.IsMouseDown(MOUSE_LEFT) then
                PhotoCamera.BoardUI.DraggingPhoto = nil
                local cx, cy = cv:LocalToScreen(0, 0)
                local w2, h2 = cv:GetSize()
                net.Start("PhotoCam_BoardMovePhoto")
                net.WriteEntity(PhotoCamera.BoardUI.Board)
                net.WriteString(self.PID)
                net.WriteFloat(math.Clamp((gui.MouseX() - cx) / w2, 0.02, 0.98))
                net.WriteFloat(math.Clamp(1 - (gui.MouseY() - cy) / h2, 0.02, 0.98))
                net.SendToServer()
            else
                local cx, cy = cv:LocalToScreen(0, 0)
                local sc = self.PS or 1; local sz = BASE_PHOTO * sc / self.ZS
                self:SetPos(math.Clamp(gui.MouseX() - cx - sz / 2, 0, cw - sz),
                    math.Clamp(gui.MouseY() - cy - sz / 2, 0, ch - sz))
            end
        end
    end
end

function PhotoCamera.BoardUI.MkText(cv, td, idx, cw, ch, zs)
    zs = zs or 1
    local pad = 6
    local ts = td.scale or 1
    local fn = UIFont(ts / zs)
    surface.SetFont(fn)
    local tw, th = surface.GetTextSize(td.text or "")
    tw = math.max(tw, 30); th = math.max(th, 14)

    local p = vgui.Create("DPanel", cv)
    local pw = tw + pad * 2 + RSZ_H
    local ph = th + pad * 2
    p:SetPos(td.u * cw - pw / 2, (1 - td.v) * ch - ph / 2)
    p:SetSize(pw, ph)
    p.TI = idx; p.TD = td; p.TS = ts; p.ZS = zs

    local function RecalcSize(self)
        local sc = self.TS or 1
        local f = UIFont(sc / self.ZS)
        surface.SetFont(f)
        local tw2, th2 = surface.GetTextSize(self.TD.text or "")
        tw2 = math.max(tw2, 30); th2 = math.max(th2, 14)
        local newW = tw2 + pad * 2 + RSZ_H
        local newH = th2 + pad * 2
        self:SetSize(newW, newH)
        return tw2, th2, newW, newH
    end

    p.Paint = function(self, w, h)
        local sc = self.TS or 1
        local f = UIFont(sc / self.ZS)
        local t = self.TD.text or ""
        surface.SetFont(f)
        local tw2, th2 = surface.GetTextSize(t)
        tw2 = math.max(tw2, 30)
        local cW = tw2 + pad * 2
        local cH = th2 + pad * 2

        local tc = Color(self.TD.color and self.TD.color[1] or 30,
            self.TD.color and self.TD.color[2] or 30,
            self.TD.color and self.TD.color[3] or 30, 255)

        draw.SimpleText(t, f, cW / 2 + 1, cH / 2 + 1, Color(0, 0, 0, 40), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(t, f, cW / 2, cH / 2, tc, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        if self:IsHovered() or PhotoCamera.BoardUI.ResizingText == self or PhotoCamera.BoardUI.DraggingText == self then
            surface.SetDrawColor(255, 255, 100, 80)
            surface.DrawOutlinedRect(0, 0, w, h, 1)
            PhotoCamera.BoardUI.HoveredTextIndex = self.TI
        end

        surface.SetDrawColor(100, 100, 100, 150)
        surface.DrawRect(w - RSZ_H, h - RSZ_H, RSZ_H, RSZ_H)
        surface.SetDrawColor(200, 200, 200, 180)
        for o = 2, RSZ_H - 2, 3 do
            surface.DrawLine(w - RSZ_H + o, h, w, h - RSZ_H + o)
        end
    end

    p.OnMousePressed = function(self, k)
        if k ~= MOUSE_LEFT then return end
        local w, h = self:GetSize()
        local lx, ly = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
        if lx >= w - RSZ_H and ly >= h - RSZ_H then
            PhotoCamera.BoardUI.ResizingText = self
            PhotoCamera.BoardUI.ResizeStartX = gui.MouseX()
            PhotoCamera.BoardUI.ResizeStartScale = self.TS or 1
        else
            PhotoCamera.BoardUI.DraggingText = self
        end
    end

    p.OnMouseWheeled = function(_, d) PhotoCamera.BoardUI.DoScroll(d) end

    p.Think = function(self)
        if PhotoCamera.BoardUI.ResizingText == self then
            if not input.IsMouseDown(MOUSE_LEFT) then
                net.Start("PhotoCam_BoardResizeText")
                net.WriteEntity(PhotoCamera.BoardUI.Board)
                net.WriteUInt(self.TI, 8); net.WriteFloat(self.TS)
                net.SendToServer()
                PhotoCamera.BoardUI.ResizingText = nil
            else
                local ns = PhotoCamera.BoardUI.ResizeStartScale + (gui.MouseX() - PhotoCamera.BoardUI.ResizeStartX) / 80
                ns = math.Clamp(ns, PhotoCamera.Settings.TextMinScale, PhotoCamera.Settings.TextMaxScale)
                self.TS = ns
                RecalcSize(self)
            end
            return
        end
        if PhotoCamera.BoardUI.DraggingText == self then
            if not input.IsMouseDown(MOUSE_LEFT) then
                PhotoCamera.BoardUI.DraggingText = nil
                local cx, cy = cv:LocalToScreen(0, 0)
                local w2, h2 = cv:GetSize()
                net.Start("PhotoCam_BoardMoveText")
                net.WriteEntity(PhotoCamera.BoardUI.Board)
                net.WriteUInt(self.TI, 8)
                net.WriteFloat(math.Clamp((gui.MouseX() - cx) / w2, 0.02, 0.98))
                net.WriteFloat(math.Clamp(1 - (gui.MouseY() - cy) / h2, 0.02, 0.98))
                net.SendToServer()
            else
                local cx, cy = cv:LocalToScreen(0, 0)
                local w, h = self:GetSize()
                self:SetPos(math.Clamp(gui.MouseX() - cx - w / 2, 0, cw - w),
                    math.Clamp(gui.MouseY() - cy - h / 2, 0, ch - h))
            end
        end
    end
end

-- ===== TOOLBAR =====

function PhotoCamera.BoardUI.BuildToolbar(frame, fw, fh)
    local st = PhotoCamera.BoardUI.BoardState or {}
    local zs = st.zoneScale or 1
    local el = {}
    local by = fh - TOOLBAR_H + 2
    local bx = 10
    local bh = 24

    local function B(t, w, cb, tc)
        local b = vgui.Create("DButton", frame)
        b:SetPos(bx, by); b:SetSize(w, bh); b:SetText(t)
        if tc then b:SetTextColor(tc) end
        b.DoClick = cb; table.insert(el, b); bx = bx + w + 3; return b
    end

    local bs = B("String", 55, function() end)
    bs.DoClick = function()
        PhotoCamera.BoardUI.StringMode = not PhotoCamera.BoardUI.StringMode
        PhotoCamera.BoardUI.StringStartID = nil
        bs:SetText(PhotoCamera.BoardUI.StringMode and "Cancel" or "String")
    end

    B("Clr Str", 50, function()
        local b = PhotoCamera.BoardUI.Board; if not IsValid(b) then return end
        local s = PhotoCamera.BoardUI.BoardState
        if s and s.strings then
            for i = #s.strings, 1, -1 do
                net.Start("PhotoCam_BoardRemoveString"); net.WriteEntity(b)
                net.WriteUInt(i, 8); net.SendToServer()
            end
        end
    end)

    B("+Text", 45, function() PhotoCamera.BoardUI.OpenTextDialog() end)

    B("-Text", 45, function()
        if PhotoCamera.BoardUI.HoveredTextIndex then
            net.Start("PhotoCam_BoardRemoveText"); net.WriteEntity(PhotoCamera.BoardUI.Board)
            net.WriteUInt(PhotoCamera.BoardUI.HoveredTextIndex, 8); net.SendToServer()
        end
    end)

    B("Detach", 48, function()
        if PhotoCamera.BoardUI.HoveredPhotoID then
            net.Start("PhotoCam_BoardDetach"); net.WriteEntity(PhotoCamera.BoardUI.Board)
            net.WriteString(PhotoCamera.BoardUI.HoveredPhotoID); net.SendToServer()
        end
    end)

    B("Del", 35, function()
        if PhotoCamera.BoardUI.HoveredPhotoID then
            Derma_Query("Delete?", "Confirm", "Yes", function()
                net.Start("PhotoCam_BoardDeletePhoto"); net.WriteEntity(PhotoCamera.BoardUI.Board)
                net.WriteString(PhotoCamera.BoardUI.HoveredPhotoID); net.SendToServer()
            end, "No", function() end)
        end
    end, Color(200, 50, 50))

    -- Zone
    local lz = vgui.Create("DLabel", frame)
    lz:SetPos(bx, by + 3); lz:SetSize(28, bh); lz:SetText("Zone:")
    lz:SetTextColor(Color(255, 255, 255)); table.insert(el, lz); bx = bx + 28

    local lv = vgui.Create("DLabel", frame); table.insert(el, lv)
    local step = PhotoCamera.Settings.BoardZoneStepSize

    B("-", 18, function()
        local b = PhotoCamera.BoardUI.Board; if not IsValid(b) then return end
        local nv = math.Clamp((b:GetZoneScale() or 1) - step,
            PhotoCamera.Settings.BoardZoneMinScale, PhotoCamera.Settings.BoardZoneMaxScale)
        net.Start("PhotoCam_BoardSetZoneScale"); net.WriteEntity(b); net.WriteFloat(nv); net.SendToServer()
        lv:SetText(math.Round(nv, 2) .. "x")
    end)

    lv:SetPos(bx, by + 3); lv:SetSize(30, bh)
    lv:SetText(math.Round(zs, 2) .. "x"); lv:SetTextColor(Color(255, 255, 255))
    lv:SetContentAlignment(5); bx = bx + 32

    B("+", 18, function()
        local b = PhotoCamera.BoardUI.Board; if not IsValid(b) then return end
        local nv = math.Clamp((b:GetZoneScale() or 1) + step,
            PhotoCamera.Settings.BoardZoneMinScale, PhotoCamera.Settings.BoardZoneMaxScale)
        net.Start("PhotoCam_BoardSetZoneScale"); net.WriteEntity(b); net.WriteFloat(nv); net.SendToServer()
        lv:SetText(math.Round(nv, 2) .. "x")
    end)

    local modeNames = { [0] = "Full", [1] = "Clean", [2] = "Hidden" }
    local curMode = st.displayMode or 0
    local bh2 = B(modeNames[curMode] or "Full", 50, function() end)
    bh2.DoClick = function()
        local b = PhotoCamera.BoardUI.Board; if not IsValid(b) then return end
        net.Start("PhotoCam_BoardToggleModel"); net.WriteEntity(b); net.SendToServer()
        local newMode = ((b:GetDisplayMode() or 0) + 1) % 3
        bh2:SetText(modeNames[newMode] or "Full")
    end

    local ht = vgui.Create("DLabel", frame)
    ht:SetPos(10, by + bh + 1); ht:SetSize(fw - 20, 12)
    ht:SetText("Corner: Resize window | Zone +/- scales content")
    ht:SetTextColor(Color(140, 140, 140)); ht:SetFont("DermaDefault"); table.insert(el, ht)

    PhotoCamera.BoardUI.TBE = el
end

-- ===== TEXT DIALOG =====

function PhotoCamera.BoardUI.OpenTextDialog()
    local d = vgui.Create("DFrame")
    d:SetSize(400, 200); d:Center(); d:SetTitle("Add Text"); d:MakePopup(); d:SetDeleteOnClose(true)

    local l = vgui.Create("DLabel", d); l:SetPos(10, 35); l:SetSize(380, 20)
    l:SetText("Text:"); l:SetTextColor(Color(0, 0, 0))

    local t = vgui.Create("DTextEntry", d); t:SetPos(10, 55); t:SetSize(380, 25)
    t:SetPlaceholderText("Enter text..."); t:SetMaximumCharCount(PhotoCamera.Settings.TextMaxLength)

    local l2 = vgui.Create("DLabel", d); l2:SetPos(10, 90); l2:SetSize(380, 20)
    l2:SetText("Color:"); l2:SetTextColor(Color(0, 0, 0))

    local cp = vgui.Create("DColorMixer", d); cp:SetPos(10, 110); cp:SetSize(280, 40)
    cp:SetPalette(false); cp:SetAlphaBar(false); cp:SetWangs(false); cp:SetColor(Color(30, 30, 30))

    local ok = vgui.Create("DButton", d); ok:SetPos(300, 110); ok:SetSize(90, 40); ok:SetText("Add")
    ok.DoClick = function()
        local tx = t:GetValue(); if tx == "" then return end
        local c = cp:GetColor()
        net.Start("PhotoCam_BoardAddText"); net.WriteEntity(PhotoCamera.BoardUI.Board)
        net.WriteString(tx); net.WriteFloat(0.5); net.WriteFloat(0.5)
        net.WriteUInt(c.r, 8); net.WriteUInt(c.g, 8); net.WriteUInt(c.b, 8); net.SendToServer()
        d:Close()
    end

    local cn = vgui.Create("DButton", d); cn:SetPos(300, 155); cn:SetSize(90, 25)
    cn:SetText("Cancel"); cn.DoClick = function() d:Close() end
end

function PhotoCamera.BoardUI.FindPhoto(id)
    local st = PhotoCamera.BoardUI.BoardState
    if not st or not st.photos then return nil end
    for _, p in ipairs(st.photos) do if p.id == id then return p end end
    return nil
end

hook.Add("Think", "PCam_DistChk", function()
    if not PhotoCamera.BoardUI.Active then return end
    if not IsValid(PhotoCamera.BoardUI.Board) then
        if IsValid(PhotoCamera.BoardUI.Panel) then PhotoCamera.BoardUI.Panel:Close() end; return
    end
    local b = PhotoCamera.BoardUI.Board
    local zs = b:GetZoneScale() or 1
    if LocalPlayer():GetPos():Distance(b:GetPos()) > PhotoCamera.Settings.BoardInteractDistance * zs * 1.5 then
        if IsValid(PhotoCamera.BoardUI.Panel) then PhotoCamera.BoardUI.Panel:Close() end
    end
end)