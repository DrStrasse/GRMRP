-- lua/photocamera/cl_archive.lua

PhotoCamera.Archive = PhotoCamera.Archive or {}
PhotoCamera.Archive.Panel = nil

function PhotoCamera.Archive.OpenUI(archive, archiveState)
    if IsValid(PhotoCamera.Archive.Panel) then
        PhotoCamera.Archive.Panel:Remove()
    end

    local photos = archiveState.photos or {}
    local maxPhotos = archiveState.maxPhotos or PhotoCamera.Settings.ArchiveMaxPhotos

    local frame = vgui.Create("DFrame")
    frame:SetSize(500, 490)
    frame:Center()
    frame:MakePopup()
    frame:SetDeleteOnClose(true)
    frame:SetDraggable(true)
    frame:SetTitle("")

    frame.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(45, 45, 48, 248))
        draw.RoundedBoxEx(6, 0, 0, w, 28, Color(60, 60, 65, 255), true, true, false, false)
        draw.SimpleText("Photo Archive",
            "DermaDefaultBold", 10, 7, Color(255, 255, 255))
    end

    frame.OnClose = function()
        PhotoCamera.Archive.Panel = nil
    end

    PhotoCamera.Archive.Panel = frame
    PhotoCamera.Archive.Archive = archive

    local helpLabel = vgui.Create("DLabel", frame)
    helpLabel:SetPos(10, 32)
    helpLabel:SetSize(480, 18)
    helpLabel:SetText("Hold a photo and press E on archive to store. Click 'Take Out' to retrieve.")
    helpLabel:SetTextColor(Color(180, 180, 180))
    helpLabel:SetFont("DermaDefault")

    local scrollPanel = vgui.Create("DScrollPanel", frame)
    scrollPanel:SetPos(10, 55)
    scrollPanel:SetSize(480, 350)

    local sbar = scrollPanel:GetVBar()
    sbar:SetWide(6)
    sbar.Paint = function(self, w, h)
        draw.RoundedBox(3, 0, 0, w, h, Color(30, 30, 30, 200))
    end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    sbar.btnGrip.Paint = function(self, w, h)
        draw.RoundedBox(3, 0, 0, w, h, Color(120, 120, 120, 200))
    end

    if #photos == 0 then
        local emptyLabel = vgui.Create("DLabel", scrollPanel)
        emptyLabel:SetPos(0, 20)
        emptyLabel:SetSize(480, 40)
        emptyLabel:SetText("Archive is empty.\nHold a photo (E to pick up) and press E on this archive to store it.")
        emptyLabel:SetTextColor(Color(140, 140, 140))
        emptyLabel:SetFont("DermaDefault")
        emptyLabel:SetContentAlignment(5)
        emptyLabel:SetWrap(true)
    else
        for i, photoData in ipairs(photos) do
            local row = PhotoCamera.Archive.CreatePhotoRow(scrollPanel, archive, photoData, i)
            row:DockMargin(0, 0, 0, 4)
            row:Dock(TOP)
        end
    end

    local bottomY = 410

    if #photos > 0 then
        local retrieveAllBtn = vgui.Create("DButton", frame)
        retrieveAllBtn:SetPos(10, bottomY)
        retrieveAllBtn:SetSize(120, 28)
        retrieveAllBtn:SetText("Take Out All")
        retrieveAllBtn:SetTextColor(Color(255, 255, 255))
        retrieveAllBtn.Paint = function(self, w, h)
            local col = self:IsHovered() and Color(180, 120, 40, 255) or Color(140, 90, 20, 255)
            draw.RoundedBox(4, 0, 0, w, h, col)
        end
        retrieveAllBtn.DoClick = function()
            for idx = #photos, 1, -1 do
                timer.Simple((#photos - idx) * 0.15, function()
                    if not IsValid(archive) then return end
                    net.Start("PhotoCam_ArchiveRetrieve")
                        net.WriteEntity(archive)
                        net.WriteUInt(1, 16)
                    net.SendToServer()
                end)
            end
        end
    end

    -- Кнопка "Take a suitcase"
    local takeBtn = vgui.Create("DButton", frame)
    takeBtn:SetPos(330, bottomY)
    takeBtn:SetSize(160, 28)
    takeBtn:SetText("  Take a suitcase")
    takeBtn:SetTextColor(Color(255, 255, 255))
    takeBtn:SetFont("DermaDefaultBold")
    takeBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(70, 100, 160, 255) or Color(50, 80, 140, 255)
        draw.RoundedBox(4, 0, 0, w, h, col)
    end
    takeBtn.DoClick = function()
        if not IsValid(archive) then return end
        net.Start("PhotoCam_ArchivePickup")
            net.WriteEntity(archive)
        net.SendToServer()

        if IsValid(PhotoCamera.Archive.Panel) then
            PhotoCamera.Archive.Panel:Close()
        end
    end

    local hintLabel = vgui.Create("DLabel", frame)
    hintLabel:SetPos(10, bottomY + 34)
    hintLabel:SetSize(480, 30)
    hintLabel:SetText("'Take a suitcase' — carry archive in hand. LMB to place down. Drops on death.")
    hintLabel:SetTextColor(Color(120, 120, 120))
    hintLabel:SetFont("DermaDefault")
    hintLabel:SetWrap(true)
end

function PhotoCamera.Archive.CreatePhotoRow(parent, archive, photoData, index)
    local row = vgui.Create("DPanel", parent)
    row:SetSize(460, 70)

    row.Paint = function(self, w, h)
        local bgCol = self:IsHovered() and Color(65, 65, 70, 255) or Color(55, 55, 58, 255)
        draw.RoundedBox(4, 0, 0, w, h, bgCol)
        surface.SetDrawColor(80, 80, 85, 255)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end

    local preview = vgui.Create("DPanel", row)
    preview:SetPos(5, 5)
    preview:SetSize(60, 60)
    preview.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 30, 255)
        surface.DrawRect(0, 0, w, h)

        local mat = nil
        if PhotoCamera.Capture and PhotoCamera.Capture.GetMaterial then
            mat = PhotoCamera.Capture.GetMaterial(photoData.id)
        end
        if (not mat or mat:IsError()) and PhotoCamera.Printer and PhotoCamera.Printer.GetMaterial then
            mat = PhotoCamera.Printer.GetMaterial(photoData.id)
        end

        if mat and not mat:IsError() then
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(mat)
            surface.DrawTexturedRect(2, 2, w - 4, h - 4)
        else
            draw.SimpleText("?", "DermaLarge",
                w / 2, h / 2, Color(100, 100, 100),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    local infoX = 72

    local idLabel = vgui.Create("DLabel", row)
    idLabel:SetPos(infoX, 5)
    idLabel:SetSize(260, 16)
    local shortID = string.sub(photoData.id, 1, 30)
    idLabel:SetText("ID: " .. shortID)
    idLabel:SetTextColor(Color(200, 200, 200))
    idLabel:SetFont("DermaDefault")

    local authorLabel = vgui.Create("DLabel", row)
    authorLabel:SetPos(infoX, 22)
    authorLabel:SetSize(260, 16)
    authorLabel:SetText("By: " .. (photoData.photographer or "Unknown"))
    authorLabel:SetTextColor(Color(170, 170, 170))
    authorLabel:SetFont("DermaDefault")

    local timeLabel = vgui.Create("DLabel", row)
    timeLabel:SetPos(infoX, 39)
    timeLabel:SetSize(260, 16)
    local timeAgo = ""
    if photoData.storedTime then
        local diff = CurTime() - photoData.storedTime
        if diff < 60 then
            timeAgo = math.floor(diff) .. "s ago"
        elseif diff < 3600 then
            timeAgo = math.floor(diff / 60) .. "m ago"
        else
            timeAgo = math.floor(diff / 3600) .. "h ago"
        end
    end
    timeLabel:SetText("Stored: " .. timeAgo)
    timeLabel:SetTextColor(Color(140, 140, 140))
    timeLabel:SetFont("DermaDefault")

    local numLabel = vgui.Create("DLabel", row)
    numLabel:SetPos(infoX, 54)
    numLabel:SetSize(100, 14)
    numLabel:SetText("#" .. index)
    numLabel:SetTextColor(Color(120, 120, 120))
    numLabel:SetFont("DermaDefault")

    local takeBtn = vgui.Create("DButton", row)
    takeBtn:SetPos(350, 10)
    takeBtn:SetSize(100, 22)
    takeBtn:SetText("Take Out")
    takeBtn:SetTextColor(Color(255, 255, 255))
    takeBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(60, 140, 60, 255) or Color(40, 110, 40, 255)
        draw.RoundedBox(4, 0, 0, w, h, col)
    end
    takeBtn.DoClick = function()
        if not IsValid(archive) then return end
        net.Start("PhotoCam_ArchiveRetrieve")
            net.WriteEntity(archive)
            net.WriteUInt(photoData.index, 16)
        net.SendToServer()
    end

    local delBtn = vgui.Create("DButton", row)
    delBtn:SetPos(350, 40)
    delBtn:SetSize(100, 22)
    delBtn:SetText("Delete")
    delBtn:SetTextColor(Color(255, 255, 255))
    delBtn.Paint = function(self, w, h)
        local col = self:IsHovered() and Color(180, 50, 50, 255) or Color(140, 40, 40, 255)
        draw.RoundedBox(4, 0, 0, w, h, col)
    end
    delBtn.DoClick = function()
        if not IsValid(archive) then return end
        net.Start("PhotoCam_ArchiveStore")
            net.WriteEntity(archive)
            net.WriteUInt(photoData.index, 16)
            net.WriteBool(true)
        net.SendToServer()
    end

    return row
end

-- ===== NET RECEIVERS =====

net.Receive("PhotoCam_ArchiveOpenUI", function()
    local archive = net.ReadEntity()
    local dataLen = net.ReadUInt(32)
    local compressedData = net.ReadData(dataLen)

    local json = util.Decompress(compressedData)
    if not json then return end
    local state = util.JSONToTable(json)
    if not state then return end

    if IsValid(PhotoCamera.Archive.Panel) and PhotoCamera.Archive.Archive == archive then
        local oldX, oldY = PhotoCamera.Archive.Panel:GetPos()
        local oldW, oldH = PhotoCamera.Archive.Panel:GetSize()

        PhotoCamera.Archive.Panel:Remove()
        PhotoCamera.Archive.OpenUI(archive, state)

        if IsValid(PhotoCamera.Archive.Panel) then
            PhotoCamera.Archive.Panel:SetPos(oldX, oldY)
            PhotoCamera.Archive.Panel:SetSize(oldW, oldH)
        end
    else
        PhotoCamera.Archive.OpenUI(archive, state)
    end
end)

net.Receive("PhotoCam_ArchiveSync", function()
    local archive = net.ReadEntity()
    local dataLen = net.ReadUInt(32)
    local compressedData = net.ReadData(dataLen)

    local json = util.Decompress(compressedData)
    if not json then return end
    local state = util.JSONToTable(json)
    if not state then return end

    if IsValid(PhotoCamera.Archive.Panel) and PhotoCamera.Archive.Archive == archive then
        local oldX, oldY = PhotoCamera.Archive.Panel:GetPos()
        local oldW, oldH = PhotoCamera.Archive.Panel:GetSize()

        PhotoCamera.Archive.Panel:Remove()
        PhotoCamera.Archive.OpenUI(archive, state)

        if IsValid(PhotoCamera.Archive.Panel) then
            PhotoCamera.Archive.Panel:SetPos(oldX, oldY)
            PhotoCamera.Archive.Panel:SetSize(oldW, oldH)
        end
    end
end)