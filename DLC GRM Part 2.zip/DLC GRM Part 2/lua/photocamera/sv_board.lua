-- lua/photocamera/sv_board.lua

PhotoCamera.Board = PhotoCamera.Board or {}

local function ValidateBoardAccess(ply, board)
    if not IsValid(board) or board:GetClass() ~= "ent_photo_board" then return false end
    if not IsValid(ply) then return false end
    local dist = ply:GetPos():Distance(board:GetPos())
    local maxDist = PhotoCamera.Settings.BoardInteractDistance * (board:GetZoneScale() or 1)
    if dist > maxDist then return false end
    return true
end

net.Receive("PhotoCam_BoardAttach", function(len, ply)
    local board = net.ReadEntity()
    local photoEnt = net.ReadEntity()
    local u = net.ReadFloat()
    local v = net.ReadFloat()

    if not ValidateBoardAccess(ply, board) then return end
    if not IsValid(photoEnt) or photoEnt:GetClass() ~= "ent_photo" then return end

    if table.Count(board.AttachedPhotos) >= PhotoCamera.Settings.MaxBoardPhotos then
        ply:ChatPrint("Board is full!")
        return
    end

    board:AttachPhoto(photoEnt, u, v, PhotoCamera.Settings.PhotoDefaultScale)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardDetach", function(len, ply)
    local board = net.ReadEntity()
    local photoID = net.ReadString()

    if not ValidateBoardAccess(ply, board) then return end
    board:DetachPhoto(photoID)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardDeletePhoto", function(len, ply)
    local board = net.ReadEntity()
    local photoID = net.ReadString()

    if not ValidateBoardAccess(ply, board) then return end
    board:DeletePhoto(photoID)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardMovePhoto", function(len, ply)
    local board = net.ReadEntity()
    local photoID = net.ReadString()
    local u = net.ReadFloat()
    local v = net.ReadFloat()

    if not ValidateBoardAccess(ply, board) then return end
    board:MovePhotoOnBoard(photoID, u, v)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardResizePhoto", function(len, ply)
    local board = net.ReadEntity()
    local photoID = net.ReadString()
    local scale = net.ReadFloat()

    if not ValidateBoardAccess(ply, board) then return end
    board:ResizePhoto(photoID, scale)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardAddString", function(len, ply)
    local board = net.ReadEntity()
    local photoID1 = net.ReadString()
    local photoID2 = net.ReadString()

    if not ValidateBoardAccess(ply, board) then return end

    if #(board:GetStrings()) >= PhotoCamera.Settings.MaxStringsPerBoard then
        ply:ChatPrint("Maximum strings reached!")
        return
    end

    board:AddString(photoID1, photoID2)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardRemoveString", function(len, ply)
    local board = net.ReadEntity()
    local stringIndex = net.ReadUInt(8)

    if not ValidateBoardAccess(ply, board) then return end
    board:RemoveString(stringIndex)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardAddText", function(len, ply)
    local board = net.ReadEntity()
    local text = net.ReadString()
    local u = net.ReadFloat()
    local v = net.ReadFloat()
    local r = net.ReadUInt(8)
    local g = net.ReadUInt(8)
    local b = net.ReadUInt(8)

    if not ValidateBoardAccess(ply, board) then return end
    board:AddText(text, u, v, Color(r, g, b, 255), PhotoCamera.Settings.TextDefaultScale)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardRemoveText", function(len, ply)
    local board = net.ReadEntity()
    local textIndex = net.ReadUInt(8)

    if not ValidateBoardAccess(ply, board) then return end
    board:RemoveText(textIndex)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardMoveText", function(len, ply)
    local board = net.ReadEntity()
    local textIndex = net.ReadUInt(8)
    local u = net.ReadFloat()
    local v = net.ReadFloat()

    if not ValidateBoardAccess(ply, board) then return end
    board:MoveText(textIndex, u, v)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardEditText", function(len, ply)
    local board = net.ReadEntity()
    local textIndex = net.ReadUInt(8)
    local newText = net.ReadString()

    if not ValidateBoardAccess(ply, board) then return end
    board:EditText(textIndex, newText)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardResizeText", function(len, ply)
    local board = net.ReadEntity()
    local textIndex = net.ReadUInt(8)
    local scale = net.ReadFloat()

    if not ValidateBoardAccess(ply, board) then return end
    board:ResizeText(textIndex, scale)
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardSetZoneScale", function(len, ply)
    local board = net.ReadEntity()
    local scale = net.ReadFloat()

    if not ValidateBoardAccess(ply, board) then return end
    board:SetBoardZoneScale(scale)

    -- Reposition all photos with new zone scale
    for photoID, _ in pairs(board.AttachedPhotos) do
        board:RepositionPhoto(photoID)
    end

    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardToggleModel", function(len, ply)
    local board = net.ReadEntity()

    if not ValidateBoardAccess(ply, board) then return end
    board:CycleDisplayMode()
    PhotoCamera.Server.SyncBoard(board)
end)

net.Receive("PhotoCam_BoardSyncRequest", function(len, ply)
    local board = net.ReadEntity()
    if IsValid(board) and board:GetClass() == "ent_photo_board" then
        PhotoCamera.Server.SyncBoardToPlayer(ply, board)
    end
end)

function PhotoCamera.Server.SyncBoard(board)
    if not IsValid(board) then return end
    local data = board:SerializeBoardState()
    net.Start("PhotoCam_BoardSync")
        net.WriteEntity(board)
        net.WriteUInt(#data, 32)
        net.WriteData(data, #data)
    net.Broadcast()
end

function PhotoCamera.Server.SyncBoardToPlayer(ply, board)
    if not IsValid(board) or not IsValid(ply) then return end
    local data = board:SerializeBoardState()
    net.Start("PhotoCam_BoardSync")
        net.WriteEntity(board)
        net.WriteUInt(#data, 32)
        net.WriteData(data, #data)
    net.Send(ply)
end