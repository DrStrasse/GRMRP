-- lua/photocamera/cl_capture.lua

PhotoCamera.Capture = PhotoCamera.Capture or {}
PhotoCamera.Capture.Materials = PhotoCamera.Capture.Materials or {}

local RT_NAME = "PhotoCamera_CaptureRT"
local rtTexture = GetRenderTarget(RT_NAME, PhotoCamera.Settings.CaptureWidth, PhotoCamera.Settings.CaptureHeight, false)

net.Receive("PhotoCam_RequestRender", function()
    local photoID = net.ReadString()
    local eyeAng = net.ReadAngle()
    local eyePos = net.ReadVector()
    local zoomLevel = net.ReadFloat()

    timer.Simple(0, function()
        PhotoCamera.Capture.DoCapture(photoID, eyePos, eyeAng, zoomLevel)
    end)
end)

function PhotoCamera.Capture.DoCapture(photoID, eyePos, eyeAng, zoomLevel)
    local captureW = PhotoCamera.Settings.CaptureWidth
    local captureH = PhotoCamera.Settings.CaptureHeight

    -- Берём BaseFOV и SmoothedZoom из оружия (совпадают с тем, что видит игрок)
    local wep = LocalPlayer():GetActiveWeapon()
    local baseFOV
    local zoom = zoomLevel
    local vfFrac = 0.65

    if IsValid(wep) and wep:GetClass() == "weapon_photo_camera" then
        baseFOV = wep.BaseFOV
        if wep.SmoothedZoom then
            zoom = wep.SmoothedZoom
        end
        vfFrac = wep.ViewfinderFraction or 0.65
    end

    -- Fallback если BaseFOV не закэширован
    if not baseFOV or baseFOV == 0 then
        local fovCvar = GetConVar("fov_desired")
        baseFOV = fovCvar and fovCvar:GetInt() or 75
        if baseFOV == 0 then baseFOV = 75 end
    end

    -- FOV, которым рисуется экран игрока (то что видит TranslateFOV)
    local screenFOV = baseFOV * zoom
    local scrW, scrH = ScrW(), ScrH()

    -- Рамка видоискателя: квадрат scrH*vfFrac × scrH*vfFrac на экране scrW × scrH
    -- Угловой полу-размер рамки (одинаков по горизонтали и вертикали, т.к. квадрат):
    --   tan(α) = (vfW/2) / (scrW/2) * tan(screenFOV/2)
    --          = vfFrac * (scrH/scrW) * tan(screenFOV/2)
    local vfHalfAngle = math.atan(vfFrac * (scrH / scrW) * math.tan(math.rad(screenFOV / 2)))

    -- Подгоняем FOV захвата под соотношение сторон RT,
    -- чтобы рамка видоискателя целиком вписалась в фото
    local captureAspect = captureW / captureH
    local captureFOV

    if captureAspect >= 1 then
        -- RT широкий/квадратный: вертикаль = рамка, горизонталь чуть шире
        captureFOV = math.deg(2 * math.atan(math.tan(vfHalfAngle) * captureAspect))
    else
        -- RT высокий: горизонталь = рамка, вертикаль чуть выше
        captureFOV = math.deg(2 * vfHalfAngle)
    end

    render.PushRenderTarget(rtTexture)
    render.Clear(0, 0, 0, 255, true, true)

    render.RenderView({
        origin = eyePos,
        angles = eyeAng,
        x = 0, y = 0,
        w = captureW, h = captureH,
        fov = captureFOV,
        drawviewmodel = false,
        drawhud = false,
    })

    local captureData = render.Capture({
        format = "jpeg",
        quality = PhotoCamera.Settings.JpegQuality,
        x = 0, y = 0,
        w = captureW, h = captureH,
    })

    render.PopRenderTarget()

    if not captureData or #captureData == 0 then
        print("Failed to capture!")
        return
    end

    local compressed = PhotoCamera.Utils.CompressData(captureData)
    if not compressed then
        print("Failed to compress!")
        return
    end

    PhotoCamera.Capture.SendPhotoData(photoID, compressed)
    PhotoCamera.Capture.StoreLocal(photoID, captureData)
end

function PhotoCamera.Capture.SendPhotoData(photoID, compressedData)
    local chunkSize = PhotoCamera.Settings.ChunkSize
    local totalSize = #compressedData
    local chunks = math.ceil(totalSize / chunkSize)

    for i = 1, chunks do
        local startPos = (i - 1) * chunkSize + 1
        local endPos = math.min(i * chunkSize, totalSize)
        local chunk = string.sub(compressedData, startPos, endPos)

        timer.Simple((i - 1) * 0.05, function()
            net.Start("PhotoCam_PhotoDataChunk")
                net.WriteString(photoID)
                net.WriteUInt(i, 16)
                net.WriteUInt(chunks, 16)
                net.WriteUInt(#chunk, 32)
                net.WriteData(chunk, #chunk)
            net.SendToServer()
        end)
    end
end

function PhotoCamera.Capture.StoreLocal(photoID, jpegData)
    local fileName = "photocamera/" .. photoID .. ".jpg"
    file.CreateDir("photocamera")
    file.Write(fileName, jpegData)

    local mat = Material("../data/" .. fileName)
    PhotoCamera.Capture.Materials[photoID] = mat
end

function PhotoCamera.Capture.GetMaterial(photoID)
    return PhotoCamera.Capture.Materials[photoID]
end

net.Receive("PhotoCam_PhotoMaterial", function()
    local photoID = net.ReadString()
    local dataLen = net.ReadUInt(32)
    local compressedData = net.ReadData(dataLen)

    local jpegData = PhotoCamera.Utils.DecompressData(compressedData)
    if jpegData then
        PhotoCamera.Capture.StoreLocal(photoID, jpegData)
    end
end)