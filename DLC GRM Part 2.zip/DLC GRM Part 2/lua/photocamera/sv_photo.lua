-- lua/photocamera/sv_photo.lua

function PhotoCamera.Server.FindNearestBoard(pos)
    local best = nil
    local bestDist = math.huge

    for _, board in ipairs(ents.FindByClass("ent_photo_board")) do
        if IsValid(board) then
            local zs = board:GetZoneScale() or 1
            local d = pos:Distance(board:GetPos())
            local effectiveDist = PhotoCamera.Settings.BoardInteractDistance * zs
            if d < effectiveDist and d < bestDist then
                best = board
                bestDist = d
            end
        end
    end

    return best
end

function PhotoCamera.Server.FindNearestArchive(pos)
    local best = nil
    local bestDist = math.huge

    for _, archive in ipairs(ents.FindByClass("ent_photo_archive")) do
        if IsValid(archive) then
            local d = pos:Distance(archive:GetPos())
            if d < PhotoCamera.Settings.ArchiveInteractDistance and d < bestDist then
                best = archive
                bestDist = d
            end
        end
    end

    return best
end

function PhotoCamera.Server.SpawnPhoto(ply, photoID)
    if not IsValid(ply) then return end

    local pos = ply:GetShootPos() + ply:GetAimVector() * 40 - Vector(0, 0, 10)

    local photo = ents.Create("ent_photo")
    if not IsValid(photo) then return end

    photo:SetPos(pos)
    photo:SetAngles(Angle(0, ply:EyeAngles().y + 180, 0))
    photo:Spawn()
    photo:Activate()
    photo:SetPhotoID(photoID)
    photo:SetPhotographer(ply)
    photo:SetCreationTime(CurTime())

    local phys = photo:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(5)
        phys:SetVelocity(ply:GetAimVector() * 50 + Vector(0, 0, 30))
    end

    ply.PhotoEntities = ply.PhotoEntities or {}
    table.insert(ply.PhotoEntities, photo)

    net.Start("PhotoCam_SpawnPhoto")
        net.WriteEntity(photo)
        net.WriteString(photoID)
    net.Broadcast()
end

hook.Add("AllowPlayerPickup", "PhotoCamera_AllowPickup", function(ply, ent)
    if ent:GetClass() == "ent_photo" then
        if ent:GetOnBoard() then return false end
        return true
    end
end)

hook.Add("PhysgunPickup", "PhotoCamera_PhysgunPickup", function(ply, ent)
    if ent:GetClass() == "ent_photo" then
        if ent:GetOnBoard() then return false end
        return true
    end
end)

hook.Add("PlayerDisconnected", "PhotoCamera_DropOnDisconnect", function(ply)
end)

hook.Add("PlayerInitialSpawn", "PhotoCamera_LateJoin", function(ply)
    timer.Simple(5, function()
        if not IsValid(ply) then return end
        for _, ent in ipairs(ents.FindByClass("ent_photo")) do
            if IsValid(ent) then
                local photoID = ent:GetPhotoID()
                if photoID and photoID ~= "" then
                    PhotoCamera.Server.SendPhotoToPlayer(ply, photoID)
                end
            end
        end
        for _, board in ipairs(ents.FindByClass("ent_photo_board")) do
            if IsValid(board) then
                PhotoCamera.Server.SyncBoardToPlayer(ply, board)
            end
        end
        for _, printer in ipairs(ents.FindByClass("ent_photo_printer")) do
            if IsValid(printer) and printer:GetHasImage() then
                local imageID = printer:GetImageID()
                if imageID and imageID ~= "" then
                    PhotoCamera.Printer.SendImageToPlayer(ply, imageID)
                end
            end
        end
        for _, archive in ipairs(ents.FindByClass("ent_photo_archive")) do
            if IsValid(archive) and #archive.StoredPhotos > 0 then
                for _, pd in ipairs(archive.StoredPhotos) do
                    local photoID = pd.id
                    if archive.PhotoDataCache[photoID] then
                        PhotoCamera.Server.SendPhotoToPlayer(ply, photoID)
                    end
                end
            end
        end
    end)
end)