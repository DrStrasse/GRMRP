-- lua/photocamera/sv_archive.lua

PhotoCamera.ArchiveServer = PhotoCamera.ArchiveServer or {}

net.Receive("PhotoCam_ArchiveRetrieve", function(len, ply)
    local archive = net.ReadEntity()
    local index = net.ReadUInt(16)

    if not IsValid(ply) then return end
    if not IsValid(archive) or archive:GetClass() ~= "ent_photo_archive" then return end

    local dist = ply:GetPos():Distance(archive:GetPos())
    if dist > PhotoCamera.Settings.ArchiveInteractDistance then
        ply:ChatPrint("Too far!")
        return
    end

    archive:RetrievePhoto(ply, index)
end)

net.Receive("PhotoCam_ArchiveStore", function(len, ply)
    local archive = net.ReadEntity()
    local index = net.ReadUInt(16)
    local isDelete = net.ReadBool()

    if not IsValid(ply) then return end
    if not IsValid(archive) or archive:GetClass() ~= "ent_photo_archive" then return end

    local dist = ply:GetPos():Distance(archive:GetPos())
    if dist > PhotoCamera.Settings.ArchiveInteractDistance then
        ply:ChatPrint("Too far!")
        return
    end

    if isDelete then
        if archive.StoredPhotos[index] then
            local photoID = archive.StoredPhotos[index].id
            table.remove(archive.StoredPhotos, index)
            archive.PhotoDataCache[photoID] = nil
            archive:SetStoredCount(#archive.StoredPhotos)
            archive:BroadcastSync()
        else
            ply:ChatPrint("Photo not found!")
        end
    end
end)

net.Receive("PhotoCam_ArchiveSyncRequest", function(len, ply)
    local archive = net.ReadEntity()
    if not IsValid(archive) or archive:GetClass() ~= "ent_photo_archive" then return end

    archive:OpenArchiveUI(ply)
end)

net.Receive("PhotoCam_ArchivePickup", function(len, ply)
    local archive = net.ReadEntity()

    if not IsValid(ply) then return end
    if not IsValid(archive) or archive:GetClass() ~= "ent_photo_archive" then return end

    local dist = ply:GetPos():Distance(archive:GetPos())
    if dist > PhotoCamera.Settings.ArchiveInteractDistance then
        ply:ChatPrint("Too far!")
        return
    end

    if IsValid(ply:GetWeapon("weapon_photo_archive")) then
        ply:ChatPrint("You are already carrying a suitcase!")
        return
    end

    -- Сохраняем данные
    local storedPhotos = table.Copy(archive.StoredPhotos or {})
    local photoDataCache = {}
    for k, v in pairs(archive.PhotoDataCache or {}) do
        photoDataCache[k] = v
    end
    local storedCount = #storedPhotos

    -- Удаляем entity без высыпания фото
    archive.SuppressDropOnRemove = true
    archive:Remove()

    -- Выдаём SWEP
    local wep = ply:Give("weapon_photo_archive")
    if IsValid(wep) then
        wep.ArchiveStoredPhotos = storedPhotos
        wep.ArchivePhotoDataCache = photoDataCache
        wep:SetStoredCount(storedCount)
        wep.IsBeingPlaced = false

        ply:SelectWeapon("weapon_photo_archive")
    else
        -- Фоллбэк: спавним entity обратно
        local newArchive = ents.Create("ent_photo_archive")
        if IsValid(newArchive) then
            newArchive:SetPos(ply:GetPos() + Vector(0, 0, 20))
            newArchive:SetAngles(Angle(0, 0, 0))
            newArchive:Spawn()
            newArchive:Activate()
            newArchive.StoredPhotos = storedPhotos
            newArchive.PhotoDataCache = photoDataCache
            newArchive:SetStoredCount(storedCount)

            -- Порционная рассылка
            local photoList = {}
            for _, pd in ipairs(storedPhotos) do
                if photoDataCache[pd.id] then
                    table.insert(photoList, pd.id)
                end
            end
            for i, photoID in ipairs(photoList) do
                timer.Simple(i * 0.3, function()
                    if IsValid(newArchive) and newArchive.PhotoDataCache[photoID] then
                        PhotoCamera.Server.BroadcastPhotoData(photoID, newArchive.PhotoDataCache[photoID], nil)
                    end
                end)
            end
            timer.Simple(#photoList * 0.3 + 0.5, function()
                if IsValid(newArchive) then newArchive:BroadcastSync() end
            end)
        end
        ply:ChatPrint("Failed to pick up suitcase!")
    end
end)