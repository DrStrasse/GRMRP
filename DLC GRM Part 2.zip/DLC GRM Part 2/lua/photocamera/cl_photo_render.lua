

PhotoCamera.Render = PhotoCamera.Render or {}

--- Create a bordered photo material with Polaroid style
function PhotoCamera.Render.CreatePolaroidTexture(photoID, size)
    local baseMat = PhotoCamera.Capture.GetMaterial(photoID)
    if not baseMat or baseMat:IsError() then return nil end

    -- For 3D rendering, we just use the base material
    -- The border is drawn via cam.Start3D2D in the entity
    return baseMat
end

--- Pre-cache all known photo materials
function PhotoCamera.Render.PrecacheAll()
    for _, ent in ipairs(ents.FindByClass("ent_photo")) do
        if IsValid(ent) then
            local photoID = ent:GetPhotoID()
            if photoID and photoID ~= "" then
                if not PhotoCamera.Capture.GetMaterial(photoID) then
                    -- Request from server
                    -- (handled by late-join sync)
                end
            end
        end
    end
end

hook.Add("InitPostEntity", "PhotoCamera_PrecachePhotos", function()
    timer.Simple(10, function()
        PhotoCamera.Render.PrecacheAll()
    end)
end)