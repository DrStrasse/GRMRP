

PhotoCamera.StringRenderer = PhotoCamera.StringRenderer or {}

--- Рисуем провисающую нить между двумя 3D точками
function PhotoCamera.StringRenderer.DrawThread3D(startPos, endPos, color, thickness, segments)
    segments = segments or 20
    thickness = thickness or 2
    color = color or PhotoCamera.Settings.StringColor

    local dist = startPos:Distance(endPos)
    local sag = dist * 0.05

    local points = {}
    for i = 0, segments do
        local frac = i / segments
        local pos = LerpVector(frac, startPos, endPos)

        local sagAmount = math.sin(frac * math.pi) * sag
        pos = pos - Vector(0, 0, sagAmount)

        table.insert(points, pos)
    end

    render.SetColorMaterial()

    for i = 1, #points - 1 do
        local p1 = points[i]
        local p2 = points[i + 1]

        render.DrawLine(p1, p2, color, false)

        if thickness > 1 then
            local dir = (p2 - p1):GetNormalized()
            local upVec = Vector(0, 0, 1)
            local rightVec = dir:Cross(upVec):GetNormalized()

            for t = 1, math.floor(thickness / 2) do
                render.DrawLine(p1 + rightVec * t * 0.3, p2 + rightVec * t * 0.3, color, false)
                render.DrawLine(p1 - rightVec * t * 0.3, p2 - rightVec * t * 0.3, color, false)
            end
        end
    end
end

--- Вычислить мировую позицию пина фото (красная точка сверху)
local function GetPhotoPinWorldPos(board, photoData)
    local settings = PhotoCamera.Settings
    local ang = board:GetAngles()
    local fwd = ang:Forward()
    local right = ang:Right()
    local up = ang:Up()

    local halfW = settings.BoardWidth / 2
    local halfH = settings.BoardHeight / 2

    local offsetRight = (photoData.u - 0.5) * halfW * 2
    local offsetUp = (photoData.v - 0.5) * halfH * 2

    -- Пин находится сверху фото — добавляем смещение по Up
    -- PhotoEntitySize * 0.15 (scale) * 2 (half) + border
    local photoHalfSize = settings.PhotoEntitySize * 0.15 + 0.6
    local pinOffsetUp = photoHalfSize

    local worldPos = board:GetPos() + fwd * 3 + right * offsetRight + up * (offsetUp + pinOffsetUp)
    return worldPos
end