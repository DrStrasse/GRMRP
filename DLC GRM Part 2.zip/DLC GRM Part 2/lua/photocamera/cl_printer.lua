-- lua/photocamera/cl_printer.lua

PhotoCamera.Printer = PhotoCamera.Printer or {}
PhotoCamera.Printer.Materials = PhotoCamera.Printer.Materials or {}
PhotoCamera.Printer.PendingDownloads = PhotoCamera.Printer.PendingDownloads or {}

--- Получить материал по imageID
function PhotoCamera.Printer.GetMaterial(imageID)
    return PhotoCamera.Printer.Materials[imageID]
end

--- Сохранить изображение локально и создать материал
function PhotoCamera.Printer.StoreImage(imageID, imageData)
    local fileName = "photocamera/printer_" .. imageID .. ".png"
    file.CreateDir("photocamera")
    file.Write(fileName, imageData)

    local mat = Material("../data/" .. fileName)
    PhotoCamera.Printer.Materials[imageID] = mat

    -- Также сохраняем в PhotoCamera.Capture.Materials,
    -- чтобы ent_photo мог найти этот материал
    if PhotoCamera.Capture and PhotoCamera.Capture.Materials then
        PhotoCamera.Capture.Materials[imageID] = mat
    end

    return mat
end

--- Валидация URL
function PhotoCamera.Printer.IsValidURL(url)
    if not url or url == "" then return false end
    if #url > PhotoCamera.Settings.PrinterMaxURLLength then return false end

    -- Проверяем протокол
    if not string.StartWith(url, "http://") and not string.StartWith(url, "https://") then
        return false
    end

    -- Проверяем расширение
    local ext = string.lower(string.GetExtensionFromFilename(url) or "")
    -- Убираем query параметры из расширения
    ext = string.match(ext, "^(%w+)") or ext

    local allowed = PhotoCamera.Settings.PrinterAllowedExtensions
    local valid = false
    for _, allowedExt in ipairs(allowed) do
        if ext == allowedExt then
            valid = true
            break
        end
    end

    return valid
end

--- UI для ввода URL
function PhotoCamera.Printer.OpenUI(printer, currentURL)
    if IsValid(PhotoCamera.Printer.Panel) then
        PhotoCamera.Printer.Panel:Remove()
    end

    local frame = vgui.Create("DFrame")
    frame:SetSize(500, 280)
    frame:Center()
    frame:MakePopup()
    frame:SetDeleteOnClose(true)
    frame:SetDraggable(true)
    frame:SetTitle("Photo Printer")

    -- Инструкция
    local infoLabel = vgui.Create("DLabel", frame)
    infoLabel:SetPos(15, 35)
    infoLabel:SetSize(470, 20)
    infoLabel:SetText("Paste a direct image URL (jpg, jpeg, png) or browse local photos.")
    infoLabel:SetTextColor(Color(200, 200, 200))

    -- Кнопка browse (иконка folder_explore) — СЛЕВА от поля ввода
    local browseBtn = vgui.Create("DImageButton", frame)
    browseBtn:SetPos(15, 62)
    browseBtn:SetSize(24, 24)
    browseBtn:SetImage("icon16/folder_explore.png")
    browseBtn:SetTooltip("Browse local photos")

    -- Поле ввода URL — сдвинуто правее на ширину кнопки + отступ
    local urlEntry = vgui.Create("DTextEntry", frame)
    urlEntry:SetPos(44, 60)
    urlEntry:SetSize(441, 30)
    urlEntry:SetPlaceholderText("https://example.com/image.jpg")
    urlEntry:SetMaximumCharCount(PhotoCamera.Settings.PrinterMaxURLLength)
    if currentURL and currentURL ~= "" then
        urlEntry:SetValue(currentURL)
    end

    -- Клик по browse открывает локальный браузер
    browseBtn.DoClick = function()
        PhotoCamera.Printer.OpenLocalBrowser(printer, urlEntry, frame)
    end

    -- Статус
    local statusLabel = vgui.Create("DLabel", frame)
    statusLabel:SetPos(15, 100)
    statusLabel:SetSize(470, 20)
    statusLabel:SetText("")
    statusLabel:SetTextColor(Color(255, 200, 50))

    -- Превью
    local previewPanel = vgui.Create("DPanel", frame)
    previewPanel:SetPos(380, 125)
    previewPanel:SetSize(100, 60)
    previewPanel.PreviewMat = nil
    previewPanel.Paint = function(self, w, h)
        surface.SetDrawColor(30, 30, 30, 255)
        surface.DrawRect(0, 0, w, h)
        if self.PreviewMat and not self.PreviewMat:IsError() then
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(self.PreviewMat)
            surface.DrawTexturedRect(2, 2, w - 4, h - 4)
        else
            draw.SimpleText("Preview", "DermaDefault",
                w / 2, h / 2, Color(100, 100, 100),
                TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
    end

    -- Кнопка превью
    local previewBtn = vgui.Create("DButton", frame)
    previewBtn:SetPos(15, 130)
    previewBtn:SetSize(80, 25)
    previewBtn:SetText("Preview")
    previewBtn.DoClick = function()
        local url = urlEntry:GetValue()

        -- Проверяем, является ли это локальным путём
        if PhotoCamera.Printer.IsLocalPath(url) then
            local mat = Material("../data/" .. url)
            if mat and not mat:IsError() then
                previewPanel.PreviewMat = mat
                statusLabel:SetText("Local photo loaded!")
                statusLabel:SetTextColor(Color(50, 255, 50))
            else
                statusLabel:SetText("Failed to load local photo!")
                statusLabel:SetTextColor(Color(255, 80, 80))
            end
            return
        end

        if not PhotoCamera.Printer.IsValidURL(url) then
            statusLabel:SetText("Invalid URL! Must be a direct link to jpg/jpeg/png.")
            statusLabel:SetTextColor(Color(255, 80, 80))
            return
        end

        statusLabel:SetText("Downloading preview...")
        statusLabel:SetTextColor(Color(255, 200, 50))

        HTTP({
            url = url,
            method = "GET",
            headers = {
                ["User-Agent"] = "Garry's Mod PhotoCamera",
            },
            success = function(code, body, headers)
                if code ~= 200 or not body or #body == 0 then
                    statusLabel:SetText("Download failed! HTTP " .. tostring(code))
                    statusLabel:SetTextColor(Color(255, 80, 80))
                    return
                end

                if #body > PhotoCamera.Settings.PrinterMaxFileSize then
                    statusLabel:SetText("Image too large! Max 2MB.")
                    statusLabel:SetTextColor(Color(255, 80, 80))
                    return
                end

                local previewID = "preview_" .. os.time() .. "_" .. math.random(1000, 9999)
                local fileName = "photocamera/printer_" .. previewID .. ".png"
                file.CreateDir("photocamera")
                file.Write(fileName, body)

                local mat = Material("../data/" .. fileName)
                if IsValid(previewPanel) then
                    previewPanel.PreviewMat = mat
                end

                statusLabel:SetText("Preview loaded! (" .. math.Round(#body / 1024) .. " KB)")
                statusLabel:SetTextColor(Color(50, 255, 50))
            end,
            failed = function(reason)
                if IsValid(statusLabel) then
                    statusLabel:SetText("Download failed: " .. tostring(reason))
                    statusLabel:SetTextColor(Color(255, 80, 80))
                end
            end,
        })
    end

    -- Кнопка отправки
    local submitBtn = vgui.Create("DButton", frame)
    submitBtn:SetPos(15, 195)
    submitBtn:SetSize(160, 35)
    submitBtn:SetText("Print Photo")
    submitBtn:SetFont("DermaDefaultBold")
    submitBtn.Paint = function(self, w, h)
        local bgCol = self:IsHovered() and Color(60, 140, 60, 255) or Color(40, 120, 40, 255)
        draw.RoundedBox(4, 0, 0, w, h, bgCol)
    end
    submitBtn:SetTextColor(Color(255, 255, 255))
    submitBtn.DoClick = function()
        local url = urlEntry:GetValue()

        -- Если это локальный путь — отправляем файл на сервер
        if PhotoCamera.Printer.IsLocalPath(url) then
            PhotoCamera.Printer.PrintLocalFile(printer, url, statusLabel, frame)
            return
        end

        if not PhotoCamera.Printer.IsValidURL(url) then
            statusLabel:SetText("Invalid URL! Must be direct link to jpg/jpeg/png.")
            statusLabel:SetTextColor(Color(255, 80, 80))
            return
        end

        statusLabel:SetText("Sending to printer...")
        statusLabel:SetTextColor(Color(255, 200, 50))

        net.Start("PhotoCam_PrinterSetURL")
            net.WriteEntity(printer)
            net.WriteString(url)
            net.WriteBool(true)
        net.SendToServer()

        timer.Simple(1, function()
            if IsValid(frame) then frame:Close() end
        end)
    end

    -- Кнопка очистки
    local clearBtn = vgui.Create("DButton", frame)
    clearBtn:SetPos(185, 195)
    clearBtn:SetSize(80, 35)
    clearBtn:SetText("Clear")
    clearBtn.DoClick = function()
        net.Start("PhotoCam_PrinterSetURL")
            net.WriteEntity(printer)
            net.WriteString("")
            net.WriteBool(true)
        net.SendToServer()

        statusLabel:SetText("Image cleared.")
        statusLabel:SetTextColor(Color(200, 200, 200))
    end

    -- Кнопка отмены
    local cancelBtn = vgui.Create("DButton", frame)
    cancelBtn:SetPos(275, 195)
    cancelBtn:SetSize(80, 35)
    cancelBtn:SetText("Cancel")
    cancelBtn.DoClick = function()
        frame:Close()
    end

    PhotoCamera.Printer.Panel = frame
end
--- Проверяет, является ли значение локальным путём к файлу в data/photocamera
function PhotoCamera.Printer.IsLocalPath(path)
    if not path or path == "" then return false end
    if string.StartWith(path, "http://") or string.StartWith(path, "https://") then
        return false
    end
    if string.StartWith(path, "photocamera/") then
        return true
    end
    return false
end

--- Получить список всех фото из data/photocamera, отсортированных от нового к старому
function PhotoCamera.Printer.GetLocalPhotos()
    local photos = {}
    local files, _ = file.Find("photocamera/*.jpg", "DATA")
    local pngFiles, _ = file.Find("photocamera/*.png", "DATA")

    -- Добавляем jpg
    if files then
        for _, f in ipairs(files) do
            -- Пропускаем превью-файлы
            if not string.StartWith(f, "printer_preview_") then
                local fullPath = "photocamera/" .. f
                local modTime = file.Time(fullPath, "DATA")
                table.insert(photos, {
                    name = f,
                    path = fullPath,
                    time = modTime,
                    size = file.Size(fullPath, "DATA"),
                })
            end
        end
    end

    -- Добавляем png
    if pngFiles then
        for _, f in ipairs(pngFiles) do
            if not string.StartWith(f, "printer_preview_") then
                local fullPath = "photocamera/" .. f
                local modTime = file.Time(fullPath, "DATA")
                table.insert(photos, {
                    name = f,
                    path = fullPath,
                    time = modTime,
                    size = file.Size(fullPath, "DATA"),
                })
            end
        end
    end

    -- Сортировка от нового к старому
    table.sort(photos, function(a, b)
        return a.time > b.time
    end)

    return photos
end

--- Открыть браузер локальных фото
function PhotoCamera.Printer.OpenLocalBrowser(printer, urlEntry, parentFrame)
    if IsValid(PhotoCamera.Printer.BrowserPanel) then
        PhotoCamera.Printer.BrowserPanel:Remove()
    end

    local photos = PhotoCamera.Printer.GetLocalPhotos()

    local frame = vgui.Create("DFrame")
    frame:SetSize(520, 500)
    frame:Center()
    frame:MakePopup()
    frame:SetDeleteOnClose(true)
    frame:SetDraggable(true)
    frame:SetTitle("")

    frame.Paint = function(self, w, h)
        draw.RoundedBox(6, 0, 0, w, h, Color(40, 40, 43, 250))
        draw.RoundedBoxEx(6, 0, 0, w, 28, Color(55, 55, 60, 255), true, true, false, false)
        draw.SimpleText("Local Photos (" .. #photos .. ")",
            "DermaDefaultBold", 10, 7, Color(255, 255, 255))
    end

    PhotoCamera.Printer.BrowserPanel = frame

    if #photos == 0 then
        local emptyLabel = vgui.Create("DLabel", frame)
        emptyLabel:SetPos(10, 40)
        emptyLabel:SetSize(500, 40)
        emptyLabel:SetText("No photos found in data/photocamera/\nTake some photos with the camera first!")
        emptyLabel:SetTextColor(Color(180, 180, 180))
        emptyLabel:SetFont("DermaDefault")
        emptyLabel:SetWrap(true)
        return
    end

    -- Панель прокрутки с сеткой фото
    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:SetPos(10, 35)
    scroll:SetSize(500, 420)

    local sbar = scroll:GetVBar()
    sbar:SetWide(6)
    sbar.Paint = function(self, w, h)
        draw.RoundedBox(3, 0, 0, w, h, Color(30, 30, 30, 200))
    end
    sbar.btnUp.Paint = function() end
    sbar.btnDown.Paint = function() end
    sbar.btnGrip.Paint = function(self, w, h)
        draw.RoundedBox(3, 0, 0, w, h, Color(120, 120, 120, 200))
    end

    -- Размер превью в сетке
    local thumbSize = 90
    local thumbPad = 6
    local columns = math.floor(490 / (thumbSize + thumbPad))
    if columns < 1 then columns = 1 end

    local gridLayout = vgui.Create("DIconLayout", scroll)
    gridLayout:Dock(TOP)
    gridLayout:SetSpaceX(thumbPad)
    gridLayout:SetSpaceY(thumbPad)

    for i, photoInfo in ipairs(photos) do
        local item = gridLayout:Add("DPanel")
        item:SetSize(thumbSize, thumbSize)

        local mat = Material("../data/" .. photoInfo.path)
        local isSelected = false

        item.Paint = function(self, w, h)
            local bgCol
            if isSelected then
                bgCol = Color(60, 140, 60, 255)
            elseif self:IsHovered() then
                bgCol = Color(70, 70, 75, 255)
            else
                bgCol = Color(55, 55, 58, 255)
            end
            draw.RoundedBox(4, 0, 0, w, h, bgCol)

            -- Превью изображения
            if mat and not mat:IsError() then
                surface.SetDrawColor(255, 255, 255, 255)
                surface.SetMaterial(mat)
                surface.DrawTexturedRect(3, 3, thumbSize - 6, thumbSize - 6)
            else
                surface.SetDrawColor(80, 80, 80, 255)
                surface.DrawRect(3, 3, thumbSize - 6, thumbSize - 6)
                draw.SimpleText("?", "DermaDefault",
                    thumbSize / 2, thumbSize / 2,
                    Color(150, 150, 150),
                    TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
        end

        item.OnMousePressed = function(self, key)
            if key ~= MOUSE_LEFT then return end

            -- Вставляем путь в URL поле
            if IsValid(urlEntry) then
                urlEntry:SetValue(photoInfo.path)
            end

            -- Закрываем браузер
            if IsValid(frame) then
                frame:Close()
            end
        end

        -- Тултип с информацией
        item:SetTooltip(photoInfo.name .. "\n" ..
            os.date("%Y-%m-%d %H:%M:%S", photoInfo.time) .. "\n" ..
            (photoInfo.size and (math.Round(photoInfo.size / 1024) .. " KB") or ""))
    end

    -- Кнопка закрытия внизу
    local closeBtn = vgui.Create("DButton", frame)
    closeBtn:SetPos(210, 462)
    closeBtn:SetSize(100, 28)
    closeBtn:SetText("Cancel")
    closeBtn.DoClick = function()
        frame:Close()
    end
end

--- Отправить локальный файл на сервер для печати
function PhotoCamera.Printer.PrintLocalFile(printer, localPath, statusLabel, parentFrame)
    local fileData = file.Read(localPath, "DATA")
    if not fileData or #fileData == 0 then
        if IsValid(statusLabel) then
            statusLabel:SetText("Failed to read local file!")
            statusLabel:SetTextColor(Color(255, 80, 80))
        end
        return
    end

    if #fileData > PhotoCamera.Settings.PrinterMaxFileSize then
        if IsValid(statusLabel) then
            statusLabel:SetText("File too large! Max 2MB.")
            statusLabel:SetTextColor(Color(255, 80, 80))
        end
        return
    end

    if IsValid(statusLabel) then
        statusLabel:SetText("Uploading local photo...")
        statusLabel:SetTextColor(Color(255, 200, 50))
    end

    local compressed = util.Compress(fileData)
    if not compressed then
        if IsValid(statusLabel) then
            statusLabel:SetText("Failed to compress file!")
            statusLabel:SetTextColor(Color(255, 80, 80))
        end
        return
    end

    local imageID = string.format("local_%s_%d", os.time(), math.random(100000, 999999))

    -- Создаём материал из уже существующего файла, без дублирования
    local mat = Material("../data/" .. localPath)
    PhotoCamera.Printer.Materials[imageID] = mat

    if PhotoCamera.Capture and PhotoCamera.Capture.Materials then
        PhotoCamera.Capture.Materials[imageID] = mat
    end

    -- Отправляем чанками на сервер
    local chunkSize = PhotoCamera.Settings.ChunkSize
    local totalSize = #compressed
    local chunks = math.ceil(totalSize / chunkSize)

    for i = 1, chunks do
        local startPos = (i - 1) * chunkSize + 1
        local endPos = math.min(i * chunkSize, totalSize)
        local chunk = string.sub(compressed, startPos, endPos)

        timer.Simple((i - 1) * 0.05, function()
            net.Start("PhotoCam_PrinterLocalData")
                net.WriteEntity(printer)
                net.WriteString(imageID)
                net.WriteUInt(i, 16)
                net.WriteUInt(chunks, 16)
                net.WriteUInt(#chunk, 32)
                net.WriteData(chunk, #chunk)
            net.SendToServer()
        end)
    end

    timer.Simple(chunks * 0.05 + 0.5, function()
        if IsValid(parentFrame) then parentFrame:Close() end
    end)
end
-- Получение команды открыть UI или данные от сервера
net.Receive("PhotoCam_PrinterSetURL", function()
    local printer = net.ReadEntity()
    local currentURL = net.ReadString()
    local isSubmit = net.ReadBool()

    if not isSubmit then
        -- Сервер просит открыть UI
        PhotoCamera.Printer.OpenUI(printer, currentURL)
    end
end)

-- Получение данных изображения от сервера (для всех клиентов)
net.Receive("PhotoCam_PrinterImageReady", function()
    local printer = net.ReadEntity()
    local imageID = net.ReadString()
    local dataLen = net.ReadUInt(32)
    local compressedData = net.ReadData(dataLen)

    local imageData = util.Decompress(compressedData)
    if not imageData then
        print("Failed to decompress image data")
        return
    end

    PhotoCamera.Printer.StoreImage(imageID, imageData)

    -- Обновляем материал на entity если он уже существует
    if IsValid(printer) then
        printer.PrinterMaterial = PhotoCamera.Printer.GetMaterial(imageID)
        printer.LastImageID = imageID
    end
end)

-- Получение данных по чанкам для больших изображений
net.Receive("PhotoCam_PrinterImageData", function()
    local imageID = net.ReadString()
    local chunkNum = net.ReadUInt(16)
    local totalChunks = net.ReadUInt(16)
    local chunkSize = net.ReadUInt(32)
    local chunkData = net.ReadData(chunkSize)

    PhotoCamera.Printer.PendingDownloads[imageID] = PhotoCamera.Printer.PendingDownloads[imageID] or {
        chunks = {},
        totalChunks = totalChunks,
        receivedCount = 0,
    }

    local pending = PhotoCamera.Printer.PendingDownloads[imageID]
    pending.chunks[chunkNum] = chunkData
    pending.receivedCount = pending.receivedCount + 1

    if pending.receivedCount >= pending.totalChunks then
        local fullData = ""
        for i = 1, pending.totalChunks do
            if pending.chunks[i] then
                fullData = fullData .. pending.chunks[i]
            end
        end

        local imageData = util.Decompress(fullData)
        if imageData then
            PhotoCamera.Printer.StoreImage(imageID, imageData)

            -- Обновляем все принтеры с этим imageID
            for _, ent in ipairs(ents.FindByClass("ent_photo_printer")) do
                if IsValid(ent) and ent:GetImageID() == imageID then
                    ent.PrinterMaterial = PhotoCamera.Printer.GetMaterial(imageID)
                    ent.LastImageID = imageID
                end
            end
        end

        PhotoCamera.Printer.PendingDownloads[imageID] = nil
    end
end)