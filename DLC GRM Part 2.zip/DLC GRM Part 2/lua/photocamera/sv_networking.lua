PhotoCamera.Server = PhotoCamera.Server or {}
PhotoCamera.Server.PendingChunks = PhotoCamera.Server.PendingChunks or {}
PhotoCamera.Server.PhotoData = PhotoCamera.Server.PhotoData or {}

--- Receive photo data chunks from client
net.Receive("PhotoCam_PhotoDataChunk", function(len, ply)
    local photoID = net.ReadString()
    local chunkNum = net.ReadUInt(16)
    local totalChunks = net.ReadUInt(16)
    local chunkSize = net.ReadUInt(32)
    local chunkData = net.ReadData(chunkSize)

    -- Validate
    if not IsValid(ply) then return end
    if not photoID or photoID == "" then return end

    -- Initialize storage for this photo
    if not PhotoCamera.Server.PendingChunks[photoID] then
        PhotoCamera.Server.PendingChunks[photoID] = {
            player = ply,
            chunks = {},
            totalChunks = totalChunks,
            receivedCount = 0,
            startTime = CurTime(),
        }
    end

    local pending = PhotoCamera.Server.PendingChunks[photoID]

    -- Security: only accept from original player
    if pending.player ~= ply then return end

    -- Timeout check (30 seconds max)
    if CurTime() - pending.startTime > 30 then
        PhotoCamera.Server.PendingChunks[photoID] = nil
        return
    end

    -- Store chunk
    pending.chunks[chunkNum] = chunkData
    pending.receivedCount = pending.receivedCount + 1

    -- Check if all chunks received
    if pending.receivedCount >= pending.totalChunks then
        -- Reconstruct data
        local fullData = ""
        for i = 1, pending.totalChunks do
            if pending.chunks[i] then
                fullData = fullData .. pending.chunks[i]
            end
        end

        -- Store the compressed photo data
        PhotoCamera.Server.PhotoData[photoID] = fullData

        -- Clean up pending
        PhotoCamera.Server.PendingChunks[photoID] = nil

        -- Spawn the photo entity
        PhotoCamera.Server.SpawnPhoto(ply, photoID)

        -- Send photo data to all other clients
        PhotoCamera.Server.BroadcastPhotoData(photoID, fullData, ply)
    end
end)

--- Broadcast photo data to all players except the photographer
function PhotoCamera.Server.BroadcastPhotoData(photoID, compressedData, excludePlayer)
    local recipients = player.GetAll()

    for _, ply in ipairs(recipients) do
        if IsValid(ply) and ply ~= excludePlayer then
            net.Start("PhotoCam_PhotoMaterial")
                net.WriteString(photoID)
                net.WriteUInt(#compressedData, 32)
                net.WriteData(compressedData, #compressedData)
            net.Send(ply)
        end
    end
end

--- Send photo data to a specific player (for late joiners)
function PhotoCamera.Server.SendPhotoToPlayer(ply, photoID)
    local data = PhotoCamera.Server.PhotoData[photoID]
    if not data then return end

    net.Start("PhotoCam_PhotoMaterial")
        net.WriteString(photoID)
        net.WriteUInt(#data, 32)
        net.WriteData(data, #data)
    net.Send(ply)
end