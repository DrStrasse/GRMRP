-- lua/photocamera/sv_printer.lua

PhotoCamera.Printer = PhotoCamera.Printer or {}
PhotoCamera.Printer.ImageCache = PhotoCamera.Printer.ImageCache or {}
PhotoCamera.Printer.Cooldowns = PhotoCamera.Printer.Cooldowns or {}

local COOLDOWN = 5 -- секунд между запросами

--- Валидация URL на сервере
local function IsValidImageURL(url)
    if not url or url == "" then return false end
    if #url > PhotoCamera.Settings.PrinterMaxURLLength then return false end

    if not string.StartWith(url, "http://") and not string.StartWith(url, "https://") then
        return false
    end

    local ext = string.lower(string.GetExtensionFromFilename(url) or "")
    ext = string.match(ext, "^(%w+)") or ext

    local allowed = PhotoCamera.Settings.PrinterAllowedExtensions
    for _, allowedExt in ipairs(allowed) do
        if ext == allowedExt then return true end
    end

    return false
end

--- Генерация ID для изображения принтера
local function GenerateImageID()
    return string.format("printer_%s_%d", os.time(), math.random(100000, 999999))
end

--- Отправить данные изображения клиентам чанками
function PhotoCamera.Printer.SendImageToPlayers(imageID, compressedData, recipients)
    local chunkSize = PhotoCamera.Settings.ChunkSize
    local totalSize = #compressedData
    local chunks = math.ceil(totalSize / chunkSize)

    if chunks <= 1 then
        local printerEnt = NULL
        for _, ent in ipairs(ents.FindByClass("ent_photo_printer")) do
            if IsValid(ent) and ent:GetImageID() == imageID then
                printerEnt = ent
                break
            end
        end

        for _, ply in ipairs(recipients) do
            if IsValid(ply) then
                net.Start("PhotoCam_PrinterImageReady")
                    net.WriteEntity(printerEnt)
                    net.WriteString(imageID)
                    net.WriteUInt(totalSize, 32)
                    net.WriteData(compressedData, totalSize)
                net.Send(ply)
            end
        end
    else
        for i = 1, chunks do
            local startPos = (i - 1) * chunkSize + 1
            local endPos = math.min(i * chunkSize, totalSize)
            local chunk = string.sub(compressedData, startPos, endPos)

            timer.Simple((i - 1) * 0.05, function()
                for _, ply in ipairs(recipients) do
                    if IsValid(ply) then
                        net.Start("PhotoCam_PrinterImageData")
                            net.WriteString(imageID)
                            net.WriteUInt(i, 16)
                            net.WriteUInt(chunks, 16)
                            net.WriteUInt(#chunk, 32)
                            net.WriteData(chunk, #chunk)
                        net.Send(ply)
                    end
                end
            end)
        end
    end
end

--- Отправить данные изображения конкретному игроку (late join)
function PhotoCamera.Printer.SendImageToPlayer(ply, imageID)
    local cached = PhotoCamera.Printer.ImageCache[imageID]
    if not cached then return end

    PhotoCamera.Printer.SendImageToPlayers(imageID, cached, { ply })
end

--- Скачать изображение по URL и раздать всем
function PhotoCamera.Printer.DownloadAndDistribute(printer, url, requestingPlayer)
    local imageID = GenerateImageID()

    HTTP({
        url = url,
        method = "GET",
        headers = {
            ["User-Agent"] = "Garry's Mod PhotoCamera Server",
        },
        success = function(code, body, headers)
            if code ~= 200 or not body or #body == 0 then
                if IsValid(requestingPlayer) then
                    requestingPlayer:ChatPrint("Failed to download image! HTTP " .. tostring(code))
                end
                return
            end

            if #body > PhotoCamera.Settings.PrinterMaxFileSize then
                if IsValid(requestingPlayer) then
                    requestingPlayer:ChatPrint("Image too large! Max 2MB.")
                end
                return
            end

            local compressed = util.Compress(body)
            if not compressed then
                if IsValid(requestingPlayer) then
                    requestingPlayer:ChatPrint("Failed to process image!")
                end
                return
            end

            -- Кэшируем
            PhotoCamera.Printer.ImageCache[imageID] = compressed

            -- Устанавливаем картинку на принтер
            if IsValid(printer) then
                printer:SetPrinterImage(url, imageID)
            end

            -- Сохраняем как фото-данные (чтобы ent_photo тоже могло показать)
            PhotoCamera.Server.PhotoData[imageID] = compressed

            -- Спавним физическое фото сверху принтера
            if IsValid(printer) and IsValid(requestingPlayer) then
                PhotoCamera.Printer.SpawnPhotoAbove(printer, requestingPlayer, imageID)
            end

            -- Раздаём изображение всем игрокам
            PhotoCamera.Printer.SendImageToPlayers(imageID, compressed, player.GetAll())

            if IsValid(requestingPlayer) then
                requestingPlayer:ChatPrint("Image printed successfully!")
            end
        end,
        failed = function(reason)
            if IsValid(requestingPlayer) then
                requestingPlayer:ChatPrint("Download failed: " .. tostring(reason))
            end
        end,
    })
end

function PhotoCamera.Printer.SpawnPhotoAbove(printer, ply, imageID)
    if not IsValid(printer) then return end

    -- Получаем верхнюю точку модели в мировых координатах
    local obbCenter = printer:OBBCenter()
    local obbMaxs = printer:OBBMaxs()

    -- Мировая позиция центра + высота модели + отступ
    local worldCenter = printer:LocalToWorld(obbCenter)
    local modelHeight = obbMaxs.z - printer:OBBMins().z
    local spawnPos = worldCenter + Vector(0, 0, modelHeight / 2 + 10)

    local photo = ents.Create("ent_photo")
    if not IsValid(photo) then return end

    photo:SetPos(spawnPos)
    photo:SetAngles(Angle(0, printer:GetAngles().y, 0))
    photo:Spawn()
    photo:Activate()
    photo:SetPhotoID(imageID)
    photo:SetPhotographer(ply)
    photo:SetCreationTime(CurTime())
    photo.JustRetrieved = CurTime()
    photo.JustDetached = CurTime()

    local phys = photo:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(5)
        phys:SetVelocity(Vector(0, 0, 80))
    end

    ply.PhotoEntities = ply.PhotoEntities or {}
    table.insert(ply.PhotoEntities, photo)

    net.Start("PhotoCam_SpawnPhoto")
        net.WriteEntity(photo)
        net.WriteString(imageID)
    net.Broadcast()
end

-- Получение URL от клиента
net.Receive("PhotoCam_PrinterSetURL", function(len, ply)
    local printer = net.ReadEntity()
    local url = net.ReadString()
    local isSubmit = net.ReadBool()

    if not isSubmit then return end
    if not IsValid(ply) then return end
    if not IsValid(printer) or printer:GetClass() ~= "ent_photo_printer" then return end

    -- Проверка расстояния
    local dist = ply:GetPos():Distance(printer:GetPos())
    if dist > 200 then
        ply:ChatPrint("Too far from printer!")
        return
    end

    -- Кулдаун
    local steamID = ply:SteamID()
    if PhotoCamera.Printer.Cooldowns[steamID] and
       CurTime() - PhotoCamera.Printer.Cooldowns[steamID] < COOLDOWN then
        ply:ChatPrint("Please wait before printing again!")
        return
    end
    PhotoCamera.Printer.Cooldowns[steamID] = CurTime()

    -- Очистка
    if url == "" then
        printer:ClearImage()
        ply:ChatPrint("Image cleared.")
        return
    end

    -- Валидация URL
    if not IsValidImageURL(url) then
        ply:ChatPrint("Invalid URL! Must be a direct link to jpg/jpeg/png.")
        return
    end

    ply:ChatPrint("Downloading image...")

    -- Скачиваем и раздаём
    PhotoCamera.Printer.DownloadAndDistribute(printer, url, ply)
end)
-- Хранилище чанков для локальных файлов
PhotoCamera.Printer.PendingLocalChunks = PhotoCamera.Printer.PendingLocalChunks or {}

-- Получение локального файла от клиента чанками
net.Receive("PhotoCam_PrinterLocalData", function(len, ply)
    local printer = net.ReadEntity()
    local imageID = net.ReadString()
    local chunkNum = net.ReadUInt(16)
    local totalChunks = net.ReadUInt(16)
    local chunkSize = net.ReadUInt(32)
    local chunkData = net.ReadData(chunkSize)

    if not IsValid(ply) then return end
    if not IsValid(printer) or printer:GetClass() ~= "ent_photo_printer" then return end

    -- Проверка расстояния
    local dist = ply:GetPos():Distance(printer:GetPos())
    if dist > 200 then return end

    -- Кулдаун
    local steamID = ply:SteamID()
    if PhotoCamera.Printer.Cooldowns[steamID] and
       CurTime() - PhotoCamera.Printer.Cooldowns[steamID] < COOLDOWN then
        ply:ChatPrint("Please wait before printing again!")
        return
    end

    -- Инициализируем хранилище для этого imageID
    if not PhotoCamera.Printer.PendingLocalChunks[imageID] then
        PhotoCamera.Printer.PendingLocalChunks[imageID] = {
            player = ply,
            printer = printer,
            chunks = {},
            totalChunks = totalChunks,
            receivedCount = 0,
            startTime = CurTime(),
        }
    end

    local pending = PhotoCamera.Printer.PendingLocalChunks[imageID]

    -- Только от того же игрока
    if pending.player ~= ply then return end

    -- Таймаут 30 секунд
    if CurTime() - pending.startTime > 30 then
        PhotoCamera.Printer.PendingLocalChunks[imageID] = nil
        return
    end

    -- Сохраняем чанк
    pending.chunks[chunkNum] = chunkData
    pending.receivedCount = pending.receivedCount + 1

    -- Все чанки получены
    if pending.receivedCount >= pending.totalChunks then
        local fullData = ""
        for i = 1, pending.totalChunks do
            if pending.chunks[i] then
                fullData = fullData .. pending.chunks[i]
            end
        end

        PhotoCamera.Printer.PendingLocalChunks[imageID] = nil

        -- Устанавливаем кулдаун
        PhotoCamera.Printer.Cooldowns[steamID] = CurTime()

        -- fullData — это сжатые данные, распаковываем для проверки размера
        local imageData = util.Decompress(fullData)
        if not imageData or #imageData == 0 then
            ply:ChatPrint("Failed to process image!")
            return
        end

        if #imageData > PhotoCamera.Settings.PrinterMaxFileSize then
            ply:ChatPrint("Image too large! Max 2MB.")
            return
        end

        -- Кэшируем сжатые данные
        PhotoCamera.Printer.ImageCache[imageID] = fullData

        -- Устанавливаем на принтер
        if IsValid(printer) then
            printer:SetPrinterImage("local://" .. imageID, imageID)
        end

        -- Сохраняем как фото-данные
        PhotoCamera.Server.PhotoData[imageID] = fullData

        -- Спавним фото сверху принтера
        if IsValid(printer) and IsValid(ply) then
            PhotoCamera.Printer.SpawnPhotoAbove(printer, ply, imageID)
        end

        -- Раздаём всем игрокам кроме отправителя
        local recipients = {}
        for _, p in ipairs(player.GetAll()) do
            if IsValid(p) and p ~= ply then
                table.insert(recipients, p)
            end
        end
        PhotoCamera.Printer.SendImageToPlayers(imageID, fullData, recipients)

        if IsValid(ply) then
            ply:ChatPrint("Local photo printed successfully!")
        end
    end
end)