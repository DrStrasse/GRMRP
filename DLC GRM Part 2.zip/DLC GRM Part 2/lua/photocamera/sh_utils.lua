PhotoCamera.Utils = {}

--- Generate a unique photo ID
function PhotoCamera.Utils.GeneratePhotoID()
    return string.format("photo_%s_%d", os.time(), math.random(100000, 999999))
end

--- Clamp a 2D position within bounds
function PhotoCamera.Utils.ClampToBounds(x, y, minX, minY, maxX, maxY)
    return math.Clamp(x, minX, maxX), math.Clamp(y, minY, maxY)
end

--- Check if a point is within a rectangle
function PhotoCamera.Utils.PointInRect(px, py, rx, ry, rw, rh)
    return px >= rx and px <= rx + rw and py >= ry and py <= ry + rh
end

--- Linear interpolation for smooth movement
function PhotoCamera.Utils.LerpVector2D(frac, x1, y1, x2, y2)
    return Lerp(frac, x1, x2), Lerp(frac, y1, y2)
end

--- Convert world position to board-local UV coordinates
function PhotoCamera.Utils.WorldToBoardUV(board, worldPos)
    if not IsValid(board) then return nil, nil end

    local localPos = board:WorldToLocal(worldPos)
    local settings = PhotoCamera.Settings
    local halfW = settings.BoardWidth / 2
    local halfH = settings.BoardHeight / 2

    local u = (localPos.y + halfW) / (halfW * 2)
    local v = (localPos.z + halfH) / (halfH * 2)

    return u, v
end

--- Convert board UV coordinates to world position
function PhotoCamera.Utils.BoardUVToWorld(board, u, v)
    if not IsValid(board) then return Vector(0, 0, 0) end

    local settings = PhotoCamera.Settings
    local halfW = settings.BoardWidth / 2
    local halfH = settings.BoardHeight / 2

    local localPos = Vector(2, u * halfW * 2 - halfW, v * halfH * 2 - halfH)
    return board:LocalToWorld(localPos)
end

--- Distance between two 2D points
function PhotoCamera.Utils.Distance2D(x1, y1, x2, y2)
    local dx = x2 - x1
    local dy = y2 - y1
    return math.sqrt(dx * dx + dy * dy)
end

--- Compress image data for networking
function PhotoCamera.Utils.CompressData(data)
    return util.Compress(data)
end

--- Decompress image data
function PhotoCamera.Utils.DecompressData(data)
    return util.Decompress(data)
end