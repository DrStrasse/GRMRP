
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

if (SERVER) then
	function ENT:InitializeParent()
		self:SetModel("models/hunter/plates/plate.mdl") -- models/squad/sf_bars/sf_bar25x25x1.mdl
		self:DrawShadow(false)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
		self:Freeze()
	end

	function ENT:GravGunPickupAllowed()
		return false
	end
else
	function ENT:Draw()
		local activeWeapon = LocalPlayer():GetActiveWeapon()
		
		if (IsValid(activeWeapon)) then
			local weaponClass = activeWeapon:GetClass()

			if (weaponClass == "gmod_tool" or weaponClass == "weapon_physgun") then
				self:DrawModel()
			end
		end
	end
end

function ENT:GravGunPunt()
	return false
end
