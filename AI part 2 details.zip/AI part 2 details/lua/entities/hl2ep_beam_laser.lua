
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_beam"

ENT.PrintName = "Beam (Laser)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.Sprite = "sprites/laserbeam.vtf"
end
