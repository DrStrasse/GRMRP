
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_tesla"

ENT.PrintName = "Tesla (Plasma)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.TeslaSprite = "sprites/plasmabeam.spr"
end
