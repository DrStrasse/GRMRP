
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

ENT.PrintName = "Combine Ground Turret (NPC)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:Initialize()
		self:InitializeParent()

		self.combineTurret = ents.Create("npc_turret_ground")
		self.combineTurret:SetPos(self:GetPos() - Vector(0, 0, 10))
		self.combineTurret:SetAngles(self:GetAngles() + Angle(0, 180, 0))
		self.combineTurret:SetKeyValue("squadname", "Overwatch")
		self.combineTurret:SetParent(self)
		self.combineTurret:Spawn()
		self.combineTurret:Activate()
		self.combineTurret:Fire("Enable")
		self.combineTurret:SetCurrentWeaponProficiency(WEAPON_PROFICIENCY_PERFECT)

		-- hack not to override SpawnFunction
		timer.Simple(0, function()
			if (IsValid(self)) then
				self:SetPos(self:GetPos() + Vector(0, 0, 37))
			end
		end)
	end
end

hook.Add("PhysgunPickup", "hl2e++_NoCombineTurretPhysPickup", function(_, entity)
	if (entity:GetClass() == "npc_turret_ground") then
		return false
	end
end)
