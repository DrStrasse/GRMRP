
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

if (SERVER) then
	function ENT:Initialize()
		self:InitializeParent()
		self:SetModel("models/squad/sf_bars/sf_bar25x25x1.mdl")

		self.tesla = ents.Create("point_tesla")
		self.tesla:SetPos(self:GetPos())
		self.tesla:SetKeyValue("m_SoundName", "DoSpark")
		self.tesla:SetKeyValue("texture", self.TeslaSprite)
		self.tesla:SetKeyValue("m_Color", "255 255 255")
		self.tesla:SetKeyValue("m_flRadius", "200")
		self.tesla:SetKeyValue("beamcount_min", "6")
		self.tesla:SetKeyValue("beamcount_max", "8")
		self.tesla:SetKeyValue("thick_min", "4")
		self.tesla:SetKeyValue("thick_max", "5")
		self.tesla:SetKeyValue("lifetime_min", "0.3")
		self.tesla:SetKeyValue("lifetime_max", "0.3")
		self.tesla:SetKeyValue("interval_min", "0.5")
		self.tesla:SetKeyValue("interval_max", "2")
		self.tesla:Fire("TurnOn")
		self.tesla:SetParent(self)
		self.tesla:Spawn()
		self.tesla:Activate()
	end

	function ENT:Think()
		if (!IsValid(self.tesla)) then
			self:Remove()
		end
	end
end
