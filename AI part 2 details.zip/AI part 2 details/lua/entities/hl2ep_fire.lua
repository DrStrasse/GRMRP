
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

ENT.PrintName = "Fire"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:Initialize()
		self:InitializeParent()

		local position = self:GetPos()
		local angles = self:GetAngles()

		self.fire = ents.Create("env_fire")
		self.fire:SetPos(position)
		self.fire:SetAngles(angles)
		self.fire:SetKeyValue("spawnflags", "1")
		self.fire:SetKeyValue("firesize", "64")
		self.fire:SetKeyValue("firetype", "0")
		self.fire:SetKeyValue("ignitionpoint", "32")
		self.fire:Fire("StartFire")
		self.fire:SetParent(self)
		self.fire:Spawn()
		self.fire:Activate()

		self.lightEffect = ents.Create("light_dynamic")
		self.lightEffect:SetPos(position)
		self.lightEffect:SetAngles(angles)
		self.lightEffect:SetKeyValue("_light", "255 85 0")
		self.lightEffect:SetKeyValue("distance", "230")
		self.lightEffect:SetParent(self)
		self.lightEffect:Spawn()

		self.fireSoundID = self:StartLoopingSound("ambient/fire/fire_small1.wav")
	end

	function ENT:Think()
		if (!IsValid(self.fire) or !IsValid(self.lightEffect) or !self.fireSoundID) then
			self:Remove()
		end
	end

	function ENT:OnRemove()
		if (self.fireSoundID) then
			self:StopLoopingSound(self.fireSoundID)
		end
	end
end
