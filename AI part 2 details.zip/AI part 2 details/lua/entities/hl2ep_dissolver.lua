
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Dissolver"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true
ENT.AdminOnly = true

if (SERVER) then
	function ENT:Initialize()
		self:SetModel("models/dav0r/hoverball.mdl")
		self:SetNoDraw(false)
		self:DrawShadow(false)
		self:SetMaterial("models/alyx/emptool_glow")
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:Freeze()
	end

	function ENT:Touch(activator)
		if (activator.hl2epp_IsDissolving) then
			return
		end

		self.dissolver = ents.Create("env_entity_dissolver")
		self.dissolver:SetKeyValue("dissolvetype", "0")
		self.dissolver:SetKeyValue("magnitude", "0")
		self.dissolver:SetPos(activator:GetPos())
		self.dissolver:Spawn()

		local toDisolve = activator:GetName()

		if (activator:IsPlayer()) then
			if (!activator.hl2epp_HammerName) then
				toDisolve = activator:GetClass() .. "_" .. activator:SteamID64()
				activator.hl2epp_HammerName = toDisolve

				activator:SetName(toDisolve)
			else
				toDisolve = activator.hl2epp_HammerName
			end
		elseif (!IsValid(toDisolve)) then
			toDisolve = activator:GetClass() .. "_" .. activator:EntIndex()

			activator:SetName(toDisolve)
		end

		activator.hl2epp_IsDissolving = true

		self.dissolver:Fire("Dissolve", toDisolve)
		self.dissolver:Fire("Kill")
		self.dissolver:Remove()
	end

	function ENT:GravGunPickupAllowed()
		return false
	end

	hook.Add("PlayerSpawn", "hl2e++_RemoveIsDissolvingMark", function(client)
		if (client.hl2epp_IsDissolving) then
			client.hl2epp_IsDissolving = nil
		end
	end)
end

function ENT:GravGunPunt()
	return false
end
