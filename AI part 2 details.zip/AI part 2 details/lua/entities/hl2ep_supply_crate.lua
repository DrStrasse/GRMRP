
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Supply Crate"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:Initialize()
		local itemCrate = ents.Create("item_item_crate")
		itemCrate.itemClass = "item_dynamic_resupply"
		itemCrate.itemCount = 2

		itemCrate:SetPos(self:GetPos() - Vector(0, 0, 9))
		itemCrate:SetAngles(self:GetAngles())
		itemCrate:SetKeyValue("ItemCount", itemCrate.itemCount)
		itemCrate:SetKeyValue("ItemClass", itemCrate.itemClass)
		itemCrate:Spawn()

		self:ReplaceEntity(itemCrate, self.PrintName)
	end
end
