
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_tesla"

ENT.PrintName = "Tesla (Red)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.TeslaSprite = "sprites/combineball_trail_red_1.spr"
end
