
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

ENT.PrintName = "Dust Puff"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if SERVER then
	function ENT:Initialize()
		self:InitializeParent()

		timer.Simple(0, function()
			if (IsValid(self)) then
				self.bSpawnDust = nil
			end
		end)

		self.dustPuff = ents.Create("env_dustpuff")
		self.dustPuff:SetPos(self:GetPos())
		self.dustPuff:SetAngles(self:GetAngles() - Angle(90, 0, 0))
		self.dustPuff:SetKeyValue("scale", "8")
		self.dustPuff:SetKeyValue("speed", "16")
		self.dustPuff:SetKeyValue("color", "128 128 128")
		self.dustPuff:SetParent(self)
		self.dustPuff:Spawn()
		self.dustPuff:Activate()
	end

	function ENT:Think()
		if (IsValid(self.dustPuff)) then
			if (!self.bSpawnDust) then
				self.bSpawnDust = true

				timer.Simple(1, function()
					if (IsValid(self) and IsValid(self.dustPuff)) then
						self.bSpawnDust = false

						self.dustPuff:Fire("SpawnDust")
					end
				end)
			end
		else
			self:Remove()
		end
	end
end
