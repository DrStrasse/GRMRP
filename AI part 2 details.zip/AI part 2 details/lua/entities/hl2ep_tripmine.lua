
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Tripmine"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	local colorRed = Color(255, 0, 0)
	local colorGreen = Color(0, 255, 0)

	function ENT:Initialize()
		local tripmine = ents.Create("npc_tripmine")
		tripmine:SetPos(self:GetPos())
		tripmine:SetAngles(self:GetAngles())
		tripmine:Spawn()
		tripmine:Activate()
		tripmine:NextThink(0)
		tripmine:DropToFloor()
		tripmine:AddCallback("OnAngleChange", function(entity, angle)
			if (entity:GetInternalVariable("m_bIsLive")) then
				return
			end

			angle:RotateAroundAxis(entity:GetRight(), 90)
			local vDirection = angle:Forward()

			entity:SetSaveValue("m_vecDir", vDirection)
			entity:SetSaveValue("m_vecEnd", entity:GetPos() + vDirection * 2048)
		end)

		self:ReplaceEntity(tripmine, self.PrintName)

		local creator = self:GetCreator()

		if (IsValid(creator)) then
			local message = {
				"Tripmine is currently", colorRed, " off. ", color_white,
				"Enable it by selecting", colorGreen, " Activate ", color_white, "property in context menu"
			}

			net.Start("hl2e++_NotifyEntityCreator")
				net.WriteTable(message)
			net.Send(creator)
		end
	end
end
