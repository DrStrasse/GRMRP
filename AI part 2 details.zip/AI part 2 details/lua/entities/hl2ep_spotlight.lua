
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Spotlight"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:Initialize()
		self:SetModel("models/props_wasteland/light_spotlight01_lamp.mdl")
		self:SetNoDraw(false)
		self:DrawShadow(true)
		self:SetSkin(1)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		self:Freeze()

		self.spotlight = ents.Create("point_spotlight")
		self.spotlight:SetPos(self:GetPos() + Vector(0, 0, 4))
		self.spotlight:SetAngles(self:GetAngles())
		self.spotlight:SetKeyValue("spotlightlength", "500")
		self.spotlight:SetKeyValue("spotlightwidth", "50")
		self.spotlight:SetParent(self)
		self.spotlight:Spawn()
		self.spotlight:Activate()
	end

	function ENT:Use(activator)
		if (activator:IsPlayer()) then
			if (self.Active) then
				self.Active = false
				self.spotlight:Fire("lightoff")
				self:EmitSound("buttons/lightswitch2.wav")
				self:SetSkin(1)
			else
				self.Active = true
				self.spotlight:Fire("lighton")
				self:EmitSound("buttons/lightswitch2.wav")
				self:SetSkin(0)
			end
		end
	end

	function ENT:OnRemove()
		if (IsValid(self.spotlight)) then
			self.spotlight:SetParent()
			self.spotlight:Fire("lightoff")
			self.spotlight:Fire("kill", self.spotlight, 0.5)
		end
	end
end
