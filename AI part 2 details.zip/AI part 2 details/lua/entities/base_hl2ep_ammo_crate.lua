
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

if (SERVER) then
	function ENT:Initialize()
		local ammoCrate = ents.Create("item_ammo_crate")
		ammoCrate.ammoType = self.AmmoType

		ammoCrate:SetPos(self:GetPos() + Vector(0, 0, 6))
		ammoCrate:SetAngles(self:GetAngles())
		ammoCrate:SetKeyValue("AmmoType", ammoCrate.ammoType)
		ammoCrate:Spawn()
		ammoCrate:Activate()
		--ammoCrate:SetModel(self.CrateModel)

		self:ReplaceEntity(ammoCrate, self.PrintName)
	end
end
