
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

if (SERVER) then
	function ENT:Initialize()
		timer.Simple(0, function()
			if (IsValid(self)) then
				local creator = self:GetCreator()
				local bPersistent = self:GetPersistent()
				local position = creator:IsPlayer() and
					creator:GetEyeTrace().HitPos or self:GetPos()
				local angles = self:GetAngles()

				self:InitializeParent()
				self:SetPos(bPersistent and self.beamEndPos or position + Vector(0, 0, 5))

				local beamEndName = "beamEnd" .. self:GetCreationID()
				self:SetName(beamEndName)

				position = bPersistent and self.beamStartPos or position

				self.beamStart = ents.Create("base_hl2ep_parented_entity")
				self.beamStart:InitializeParent()
				self.beamStart:SetModel("models/weapons/shell.mdl")
				self.beamStart:SetMaterial("hunter/myplastic")
				self.beamStart:SetPos(position)
				self.beamStart:SetAngles(angles)
				self.beamStart:Spawn()
				self.beamStart:Activate()

				self.beamStartPos = self.beamStart:GetPos()

				local beamStartName = "beamStart" .. self.beamStart:GetCreationID()
				self.beamStart:SetName(beamStartName)

				self.beam = ents.Create("env_beam")
				self.beam:SetPos(position)
				self.beam:SetAngles(angles)
				self.beam:SetKeyValue("life", "0")
				self.beam:SetKeyValue("BoltWidth", "5")
				self.beam:SetKeyValue("NoiseAmplitude", "0") -- 10
				self.beam:SetKeyValue("texture", self.Sprite)
				self.beam:SetKeyValue("TextureScroll", "35")
				self.beam:SetKeyValue("framerate", "0")
				self.beam:SetKeyValue("damage", "100")
				self.beam:SetKeyValue("LightningStart", beamStartName)
				self.beam:SetKeyValue("LightningEnd", beamEndName)
				self.beam:SetKeyValue("renderamt", "100")
				self.beam:Spawn()
				self.beam:Activate()
			end
		end)
	end

	function ENT:Think()
		if (!IsValid(self.beam) or !IsValid(self.beamStart)) then
			self:Remove()
		else
			self.beamEndPos = self:GetPos()
		end
	end

	function ENT:OnRemove()
		if (IsValid(self.beam)) then
			self.beam:Remove()
		end

		if (IsValid(self.beamStart)) then
			self.beamStart:Remove()
		end

	end
end
