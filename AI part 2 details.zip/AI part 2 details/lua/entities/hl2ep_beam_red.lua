
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_beam"

ENT.PrintName = "Beam (Red)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.Sprite = "sprites/combineball_trail_red_1.vtf"
end
