
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_headcrab_canister"

ENT.PrintName = "Crab Canister (Normal)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.HeadcrabType = 0
end
