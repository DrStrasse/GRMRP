
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_ammo_crate"

ENT.PrintName = "Ammo Crate (Grenades)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
--	ENT.CrateModel = "models/items/ammocrate_grenade.mdl"
	ENT.AmmoType = 5
end
