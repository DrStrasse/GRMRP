
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"

if (SERVER) then
	util.AddNetworkString("hl2e++_NotifyEntityCreator")

	function ENT:Freeze()
		local physObj = self:GetPhysicsObject()

		if (IsValid(physObj)) then
			physObj:Sleep()
			physObj:EnableMotion(false)
		end
	end

	function ENT:ReplaceEntity(entityReplaceTo, undoName)
		local creator = self:GetCreator()

		if (creator:IsPlayer()) then
			timer.Simple(0, function()
				local isSelfValid = IsValid(self)
				local isEntityValid = IsValid(entityReplaceTo)

				if (isSelfValid and isEntityValid) then
					self:Remove()

					undo.Create(undoName)
						undo.AddEntity(entityReplaceTo)
						undo.SetPlayer(creator)
					undo.Finish()
				elseif (isSelfValid and !isEntityValid) then
					self:Remove()
				elseif(!isSelfValid and isEntityValid) then
					entityReplaceTo:Remove()
				end
			end)
		end
	end
end
