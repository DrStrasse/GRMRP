
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

if (SERVER) then
	function ENT:Initialize()
		local carnister = ents.Create("env_headcrabcanister")
		carnister:SetPos(self:GetPos())
		carnister:SetAngles(self:GetAngles() + Angle(math.random(-90, -130), math.random(0, 360), 0))
		carnister:SetKeyValue("HeadcrabType", self.HeadcrabType)
		carnister:SetKeyValue("HeadcrabCount", "6") -- 10
		carnister:SetKeyValue("FlightSpeed", "3000") -- 7500
		carnister:SetKeyValue("FlightTime", "5") -- 4
		carnister:SetKeyValue("Damage", "150") -- 75
		carnister:SetKeyValue("DamageRadius", "750") -- 300
		carnister:SetKeyValue("SmokeLifetime", "30") -- 10
		carnister:SetKeyValue("spawnflags", "8192")
		carnister:Spawn()
		carnister:Input("FireCanister", self, self)

		self:ReplaceEntity(carnister, self.PrintName)
	end
end
