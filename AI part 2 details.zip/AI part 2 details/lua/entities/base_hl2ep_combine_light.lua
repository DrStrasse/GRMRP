
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

if (SERVER) then
	function ENT:Initialize()
		self:SetModel(self.Model)
		self:SetNoDraw(false)
		self:DrawShadow(true)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:Freeze()

		timer.Simple(0, function()
			if (IsValid(self)) then
				if (self.ShouldDrawProjectedTexture) then
					local position, angles = self:GetBonePosition(0)
					local anglesRight = angles:Right()

					self.flashBase = ents.Create("env_projectedtexture")
					self.flashBase:SetParent(self)
					self.flashBase:SetPos(position + angles:Up() * 5)
					self.flashBase:SetKeyValue("lightcolor", "147 226 240")
					self.flashBase:SetKeyValue("lightfov", self.LightFOV)
					self.flashBase:SetKeyValue("farz", self.LightFarZ)
					self.flashBase:SetKeyValue("nearz", "2")
					self.flashBase:SetKeyValue("shadowquality", "1")
					self.flashBase:Input("SpotlightTexture", nil, nil, "effects/flashlight001")

					angles:RotateAroundAxis(anglesRight, 180)
					self.flashBase:SetAngles(angles)
					self.flashBase:Spawn()
					self.flashBase:Activate()
				end

				self.lightDynamic = ents.Create("light_dynamic")
				self.lightDynamic:SetParent(self)
				self.lightDynamic:SetPos(self:GetPos())
				self.lightDynamic:SetParent(self)
				self.lightDynamic:SetKeyValue("_light", "147 226 240") 
				self.lightDynamic:SetKeyValue("distance", self.LightDistance)
				self.lightDynamic:Spawn()
			end
		end)
	end
end
