
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

if (SERVER) then
	function ENT:Initialize()
		self:InitializeParent()

		self.steam = ents.Create("env_steam")
		self.steam:SetPos(self:GetPos())
		self.steam:SetAngles(self:GetAngles())
		self.steam:SetKeyValue("InitialState", "1")
		self.steam:SetKeyValue("SpreadSpeed", "15")
		self.steam:SetKeyValue("Speed", "120")
		self.steam:SetKeyValue("StartSize", "10")
		self.steam:SetKeyValue("EndSize", "25")
		self.steam:SetKeyValue("Rate", "26")
		self.steam:SetKeyValue("JetLength", "80")
		self.steam:SetKeyValue("renderamt", "255")
		self.steam:SetKeyValue("type", self.SteamType)
		self.steam:SetParent(self)
		self.steam:Spawn()
		self.steam:Activate()

		self.steamSoundID = self:StartLoopingSound(self.SteamSound)
	end

	function ENT:Think()
		if (!IsValid(self.steam) or !self.steamSoundID) then
			self:Remove()
		end
	end

	function ENT:OnRemove()
		if (self.steamSoundID) then
			self:StopLoopingSound(self.steamSoundID)
		end
	end
end
