
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Combine Lock"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:SpawnCombineLock(combineLock, client, trace, class)
		local entity = trace.Entity
		combineLock = combineLock or ents.Create(class)

		if (IsValid(entity) and entity:GetClass():find("door") and !entity.combineLock) then
			local handle = entity:LookupBone("handle")
			local position = handle and handle >= 1 and entity:GetBonePosition(handle) or entity:GetPos()
			local angle = client:GetEyeTrace().HitNormal:Angle() or entity:GetForward():Angle()

			position = position + angle:Forward() * 7.2 + angle:Up() * 10 + angle:Right() * 2

			angle:RotateAroundAxis(angle:Up(), 90)
			angle:RotateAroundAxis(angle:Forward(), 180)
			angle:RotateAroundAxis(angle:Right(), 180)

			entity.combineLock = combineLock
			combineLock.door = entity
			combineLock.doorMapID = entity:MapCreationID()

			combineLock:SetPos(position)
			combineLock:SetAngles(angle)
		else
			combineLock:SetPos(trace.HitPos)
			combineLock:SetAngles(Angle(0, client:EyeAngles().yaw + 90, 0))
		end

		combineLock:Spawn()
		combineLock:Activate()

		return combineLock
	end

	function ENT:SpawnFunction(client, trace, class)
		return self:SpawnCombineLock(nil, client, trace, class)
	end

	function ENT:Initialize()
		self:SetModel("models/props_combine/combine_lock01.mdl")
		self:SetNoDraw(false)
		self:DrawShadow(true)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		self:Freeze()

		if (self.doorMapID or self.door) then
			if (!self.door) then
				for k, v in ipairs(ents.FindByClass("*_door_*")) do
					if (v:MapCreationID() == self.doorMapID) then
						self.door = v

						break
					end
				end
			end

			self:SetParent(self.door)

			if (self.door:GetClass() == "prop_door_rotating") then
				self.door.oldSpawnFlags = self.door:GetInternalVariable("spawnflags")
				self.door:SetKeyValue("spawnflags", bit.bor(self.door.oldSpawnFlags, 32768))
			else
				self.door.oldLockedSound = self.door:GetInternalVariable("locked_sound")
				self.door:SetKeyValue("locked_sound", "")
			end

			self.door:Fire("lock")
		end
	end

	function ENT:OnRemove()
		if (IsValid(self.door)) then
			if (self.door:GetClass() == "prop_door_rotating") then
				self.door:SetKeyValue("spawnflags", self.door.oldSpawnFlags)
			else
				self.door:SetKeyValue("locked_sound", self.door.oldLockedSound)
			end

			self.door.combineLock = nil
			self.door:Fire("unlock")
		end
	end

	function ENT:Use(activator)
		if (activator:IsPlayer()) then
			self:EmitSound("buttons/combine_button_locked.wav")
		end
	end
end
