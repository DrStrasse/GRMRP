
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_beam"

ENT.PrintName = "Beam (Phys)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true
ENT.AdminOnly = false

if (SERVER) then
	ENT.Sprite = "sprites/physbeama.vtf"
end
