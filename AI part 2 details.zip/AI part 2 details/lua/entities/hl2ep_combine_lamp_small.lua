
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_combine_light"

ENT.PrintName = "Combine Lamp (Small)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.Model = "models/props_combine/combine_light001a.mdl"
	ENT.ShouldDrawProjectedTexture = true
	ENT.LightFOV = 80
	ENT.LightFarZ = 512
	ENT.LightDistance = 50
end
