
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

ENT.PrintName = "Flare"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:Initialize()
		self:InitializeParent()

		self.flare = ents.Create("env_flare")
		self.flare:SetPos(self:GetPos())
		self.flare:SetAngles(self:GetAngles())
		self.flare:SetKeyValue("spawnflags", "4")
		self.flare:SetKeyValue("scale", "2")
		self.flare:Fire("Start")
		self.flare:SetParent(self)
		self.flare:Spawn()
		self.flare:Activate()
		self.flare:EmitSound("weapons/flaregun/fire.wav")
	end

	function ENT:Think()
		if (!IsValid(self.flare)) then
			self:Remove()
		end
	end

	function ENT:OnRemove()
		self.flare:StopSound("weapons/flaregun/fire.wav")
	end
end
