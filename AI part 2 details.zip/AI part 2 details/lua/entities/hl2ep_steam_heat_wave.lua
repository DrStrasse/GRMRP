
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_steam"

ENT.PrintName = "Steam (Heat Wave)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.SteamSound = "ambient/gas/steam_loop1.wav"
	ENT.SteamType = 1
end
