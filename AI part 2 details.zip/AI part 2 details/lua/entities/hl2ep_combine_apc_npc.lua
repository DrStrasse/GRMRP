
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Combine APC (NPC)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:Initialize()
		local apcVisual = ents.Create("prop_vehicle_apc")
		apcVisual:SetPos(self:GetPos())
		apcVisual:SetAngles(self:GetAngles())
		apcVisual:SetKeyValue("model", "models/combine_apc.mdl")
		apcVisual:SetKeyValue("vehiclescript", "scripts/vehicles/apc_npc.txt")
		apcVisual:SetKeyValue("VehicleLocked", "true")
		apcVisual:SetKeyValue("actionScale", "1")
		apcVisual:Spawn()
		apcVisual:Activate()

		self:ReplaceEntity(apcVisual, self.PrintName)

		local apcVisualName = "apc_visual_" .. apcVisual:GetCreationID()
		apcVisual:SetName(apcVisualName)

		local boneID = apcVisual:LookupBone("APC.Gun_Base")
		local bonePos, _ = apcVisual:GetBonePosition(boneID)

		local apcDriver = ents.Create("npc_apcdriver")
		apcDriver:SetPos(bonePos)
		apcDriver:SetKeyValue("vehicle", apcVisualName)
		apcDriver:SetParent(apcVisual)
		apcDriver:Spawn()
		apcDriver:Activate()
	end

	hook.Add("OnPhysgunFreeze", "hl2e++_PreventCombineAPCFreeze", function(_, _, entity)
		if (entity:GetClass() == "prop_vehicle_apc") then
			return false
		end
	end)
end
