
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Thumper (Large)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	function ENT:Initialize()
		local thumperLarge = ents.Create("prop_thumper")
		thumperLarge.dustScale = "256"

		thumperLarge:SetModel("models/props_combine/combinethumper001a.mdl")
		thumperLarge:SetPos(self:GetPos() - Vector(0, 0, 10))
		thumperLarge:DropToFloor()
		thumperLarge:SetAngles(self:GetAngles())
		thumperLarge:SetKeyValue("dustscale", thumperLarge.dustScale)
		thumperLarge:Spawn()
		thumperLarge:Activate()

		self:ReplaceEntity(thumperLarge, self.PrintName)
	end
end
