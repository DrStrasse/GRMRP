
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_parented_entity"

ENT.PrintName = "Citadel Energy Core"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true
ENT.AdminOnly = false

if (SERVER) then
	function ENT:Initialize()
		self:InitializeParent()

		local position = self:GetPos()
		local angles = self:GetAngles()

		self.citadelCore = ents.Create("env_citadel_energy_core")
		self.citadelCore:SetPos(position)
		self.citadelCore:SetAngles(angles)
		self.citadelCore:SetOwner(self:GetOwner())
		self.citadelCore:SetKeyValue("scale", "2")
		self.citadelCore:SetKeyValue("spawnflags", "2")
		self.citadelCore:Fire("StartCharge", "2")
		self.citadelCore:SetParent(self)
		self.citadelCore:Spawn()
		self.citadelCore:Activate()

		self.lightEffect = ents.Create("light_dynamic")
		self.lightEffect:SetPos(position)
		self.lightEffect:SetAngles(angles)
		self.lightEffect:SetKeyValue("_light", "147 226 240")  
		self.lightEffect:SetKeyValue("distance", "200")
		self.lightEffect:SetParent(self)
		self.lightEffect:Spawn()

		self.citadelCoreSoundID = self:StartLoopingSound("ambient/levels/citadel/core_near_uncontained_loop2.wav")
	end

	function ENT:Think()
		if (!IsValid(self.citadelCore) or !IsValid(self.lightEffect) or !self.citadelCoreSoundID) then
			self:Remove()
		end
	end

	function ENT:OnRemove()
		if (self.citadelCoreSoundID) then
			self:StopLoopingSound(self.citadelCoreSoundID)
		end
	end
end
