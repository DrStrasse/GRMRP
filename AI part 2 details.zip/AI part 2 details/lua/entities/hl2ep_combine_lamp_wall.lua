
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_combine_light"

ENT.PrintName = "Combine Lamp (Wall)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.Model = "models/props_combine/combine_light002a.mdl"
	ENT.LightDistance = 250 -- 500
end
