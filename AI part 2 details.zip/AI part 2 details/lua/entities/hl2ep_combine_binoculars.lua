
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_entity"

ENT.PrintName = "Combine Binoculars"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true
ENT.AdminOnly = false

if (SERVER) then
	function ENT:Initialize()
		self:SetModel("models/props_combine/combine_binocular01.mdl")
		self:SetNoDraw(false)
		self:DrawShadow(true)
		self:PhysicsInit(SOLID_VPHYSICS)
		self:SetMoveType(MOVETYPE_VPHYSICS)
		self:SetSolid(SOLID_VPHYSICS)
		self:SetUseType(SIMPLE_USE)
		self:SetPos(self:GetPos() + Vector(0, 0, 50))
		self:SetAngles(self:GetAngles() + Angle(0, 180, 0))
		self:Freeze()
	end

	function ENT:Use(activator)
		if (!self.NoUse and activator:IsPlayer()) then
			if (!self.User or self.User == activator) then

				if (!self.InUse) then
					local angleDifference = math.abs(math.AngleDifference(self:GetAngles().y, activator:GetAngles().y))

					if (angleDifference < 90) then
						self:SetUseStatus(true, activator)

						self:EmitSound("weapons/sniper/sniper_zoomin.wav")
					end
				end
			else
				self:EmitSound("buttons/combine_button_locked.wav")
			end
		end
	end

	function ENT:Think()
		local user = self.User

		if (!IsValid(user) or !user:Alive() or self:GetPos():DistToSqr(user:GetPos()) > 10000) then
			self:SetUseStatus(false)
		end

		if (self.NoUse) then
			self.NoUse = nil
		end
	end

	function ENT:OnRemove()
		self:SetUseStatus(false)
	end

	function ENT:SetUseStatus(status, user)
		user = user or self.User

		self.InUse = status
		self.User = status and user or nil

		if (IsValid(user)) then
			user:SetNWEntity("hl2e++_CombineBinoculars", status and self or Entity(0))
		end
	end

	hook.Add("KeyPress", "hl2e++_CombineBinocularsExit", function(client, key)
		if (key == IN_USE) then
			local entity = client:GetNWEntity("hl2e++_CombineBinoculars")

			if (IsValid(entity)) then
				entity.NoUse = true

				entity:SetUseStatus(false, client)
				entity:EmitSound("weapons/sniper/sniper_zoomout.wav")
			end
		end
	end)
else
	local combineBinoculars = Material("effects/combine_binocoverlay")
	local minFOV = 5
	local maxFOV = 50

	function ENT:Draw()
		if (!IsValid(LocalPlayer():GetNWEntity("hl2e++_CombineBinoculars"))) then
			self:DrawModel()
		end
	end

	hook.Add("InitPostEntity", "hl2e++_CombineBinocularsInitVars", function()
		local client = LocalPlayer()

		client.hl2epp_BinocularsFOV = maxFOV
		client.hl2epp_BinocularsFOV_Goal = {
			from = maxFOV,
			to = maxFOV
		}
	end)

	hook.Add("CalcView", "hl2e++_CombineBinocularsView", function(client, position, angles, fov)
		if (!client.hl2epp_BinocularsFOV) then
			return
		end

		local entity = client:GetNWEntity("hl2e++_CombineBinoculars")

		if (IsValid(entity)) then
			if (client.hl2epp_BinocularsFOV != client.hl2epp_BinocularsFOV_Goal.to) then
				local realFrameTime = RealFrameTime() * 3
				local fovMin, fovMax

				if (client.hl2epp_BinocularsFOV_Goal.from < client.hl2epp_BinocularsFOV_Goal.to) then
					fovMin, fovMax = client.hl2epp_BinocularsFOV_Goal.from, client.hl2epp_BinocularsFOV_Goal.to
				else 
					fovMin, fovMax = client.hl2epp_BinocularsFOV_Goal.to, client.hl2epp_BinocularsFOV_Goal.from
					realFrameTime = -realFrameTime
				end

				local fovFraction = math.Remap(client.hl2epp_BinocularsFOV, fovMin, fovMax, 0, 1)

				client.hl2epp_BinocularsFOV = Lerp(realFrameTime + fovFraction, fovMin, fovMax)
			end

			return {
				origin = entity:GetPos() + Vector(0, 0, 28),
				angles = entity:GetAngles(),
				fov = client.hl2epp_BinocularsFOV
			}
		elseif (client.hl2epp_BinocularsFOV != client.hl2epp_BinocularsFOV_Goal.to) then
			client.hl2epp_BinocularsFOV = client.hl2epp_BinocularsFOV_Goal.to
		end
	end)

	hook.Add("KeyPress", "hl2e++_CombineBinocularsZoom", function(client, key)
		if (!game.SinglePlayer() and !IsFirstTimePredicted()) then
			return
		end

		local entity = client:GetNWEntity("hl2e++_CombineBinoculars")

		if (IsValid(entity)) then
			local newBinocularsFOV
			local zoomSound

			if (key == IN_FORWARD) then
				newBinocularsFOV = client.hl2epp_BinocularsFOV_Goal.to - 5
				zoomSound = "weapons/sniper/sniper_zoomin.wav"
			elseif (key == IN_BACK) then
				newBinocularsFOV = client.hl2epp_BinocularsFOV_Goal.to + 5
				zoomSound = "weapons/sniper/sniper_zoomout.wav"
			end

			if (isnumber(newBinocularsFOV)) then
				newBinocularsFOV = math.Clamp(newBinocularsFOV, minFOV, maxFOV)

				if (newBinocularsFOV != client.hl2epp_BinocularsFOV_Goal.to) then
					client.hl2epp_BinocularsFOV_Goal = {
						from = client.hl2epp_BinocularsFOV,
						to = newBinocularsFOV
					}

					client:EmitSound(zoomSound)
				end
			end
		end
	end)

	hook.Add("PreDrawViewModel", "hl2e++_CombineBinocularsHideViewModel", function(_, client)
		if (IsValid(client:GetNWEntity("hl2e++_CombineBinoculars"))) then
			return true
		end
	end)

	hook.Add("RenderScreenspaceEffects", "hl2e++_CombineBinocularsOverlay", function()
		if (IsValid(LocalPlayer():GetNWEntity("hl2e++_CombineBinoculars"))) then
			render.UpdateScreenEffectTexture()

			combineBinoculars:SetFloat("$alpha", 0.5)
			combineBinoculars:SetInt("$ignorez", 1)

			render.SetMaterial(combineBinoculars)
			render.DrawScreenQuad()
		end
	end)

	hook.Add("InputMouseApply", "hl2e++_CombineBinocularsLockMouse", function(cUserCmd, x, y, angle)
		if (IsValid(LocalPlayer():GetNWEntity("hl2e++_CombineBinoculars"))) then
			return true
		end
	end)
end

hook.Add("StartCommand", "hl2e++_CombineBinocularsFreeze", function(client, cUserCmd)
	if (IsValid(client:GetNWEntity("hl2e++_CombineBinoculars"))) then
		cUserCmd:RemoveKey(IN_ATTACK + IN_ATTACK2 + IN_RELOAD + IN_JUMP + IN_DUCK)
		cUserCmd:ClearMovement()
	end
end)
