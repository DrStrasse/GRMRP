
AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_hl2ep_combine_light"

ENT.PrintName = "Combine Lamp (Large)"
ENT.Author = "FiLzO"
ENT.Category = "Half-Life 2 Entities++"

ENT.Spawnable = true

if (SERVER) then
	ENT.Model = "models/props_combine/combine_light001b.mdl"
	ENT.ShouldDrawProjectedTexture = true
	ENT.LightFOV = 110
	ENT.LightFarZ = 1024
	ENT.LightDistance = 50
end
