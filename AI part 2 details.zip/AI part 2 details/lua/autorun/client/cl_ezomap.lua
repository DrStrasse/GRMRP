local function Create_Texte( x, y, w, h, text, parent ) --  Create_Texte( w, h, 500, 30, "", frame )
    local TextName = vgui.Create("DLabel", parent)
    TextName:SetPos( x, y )
    TextName:SetFont("EzoFont")
    TextName:SetSize( w, h )
    TextName:SetText(text)
end

local function Create_Button( x, y, w, h, text, parent, click ) --Create_Button( w, h, 100, 50, "", frame, function()  end)
    local ButtonName = vgui.Create( "DButton", parent )
    ButtonName:SetParent( parent )
    ButtonName:SetPos( x, y)
    ButtonName:SetSize( w, h )
    ButtonName:SetText( text )
    ButtonName:SetParent( parent )
    function ButtonName:DoClick()
        click()
    end
    ButtonName.Paint = function( self, w, h )
     surface.SetDrawColor( 68, 87, 101, 255 ) -- What color do You want to paint the button (R, B, G, A)
     surface.DrawRect( 0, 0, ButtonName:GetWide(), ButtonName:GetTall() )
    end
end


local OPEN = 0 

local function Minimap( ply )

ply = net.ReadEntity("Minimap")
        if OPEN == 0 then
            w = ScrW()
            h = ScrH()

            Mapframe = vgui.Create( 'DFrame' )
            Mapframe:SetTitle(" ")
            Mapframe:SetSize( h / 3.8, h / 3.8 )
            Mapframe:SetPos(0, 0)
            Mapframe:ShowCloseButton( false )
            --Mapframe:MakePopup()

            function Mapframe:Paint( w, h )

                draw.RoundedBox( 0, 0, 0, h, w, Color(0, 0, 0,255) )

                local x, y, z = LocalPlayer():GetPos()
                local PlayerAngle = LocalPlayer():GetAngles().y

                render.RenderView( {
                    origin = LocalPlayer():GetPos()+Vector(0,0,3000), -- change to your liking
                    angles = Angle(90,LocalPlayer():EyeAngles().yaw,0), -- change to your liking
                    x = 4,
                    y = 4,
                    w = w - 8,
                    h = h - 8,
                 } )

                draw.RoundedBox( 255, h / 2, w / 2, 5, 5, Color(0,0,255,255) )


                    -- Boussole
                if (PlayerAngle) >= 60 and (PlayerAngle) <= 120 then
                    draw.SimpleTextOutlined( "N", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )    
                end
                
                if (PlayerAngle) >= -30 and (PlayerAngle) <= 30 then
                    draw.SimpleTextOutlined( "E", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )    
                end
                
                if (PlayerAngle) >= 30 and (PlayerAngle) <= 60 then
                    draw.SimpleTextOutlined( "NE", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )   
                end
                
                if (PlayerAngle) >= 120 and (PlayerAngle) <= 150 then
                    draw.SimpleTextOutlined( "NW", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )   
                end
                
                if (PlayerAngle) <= -120 and (PlayerAngle) >= -150 then
                    draw.SimpleTextOutlined( "WS", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )   
                end
                
                if (PlayerAngle) <= -30 and (PlayerAngle) >= -60 then
                    draw.SimpleTextOutlined( "SE", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )   
                end
                
                if (PlayerAngle) <= -150 and (PlayerAngle) >= -180 then
                    draw.SimpleTextOutlined( "W", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )    
                end
                
                if (PlayerAngle) >= 150 and (PlayerAngle) <= 180 then
                    draw.SimpleTextOutlined( "W", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )    
                end
                
                if (PlayerAngle) <= -60 and (PlayerAngle) >= -120 then
                    draw.SimpleTextOutlined( "S", "EzoFont", w - 20, h - 20, Color( 255, 255, 255 ), 1, 1, 2, color_black )
                end

            end
            Mapframe:SetVisible( true )
            OPEN = 1
        else
            Mapframe:SetVisible( false )
            OPEN = 0
        end
end

usermessage.Hook("Minimap", Minimap)





surface.CreateFont( "EzoFont", { 
    font = "Arial",
    extended = true,
    size = 20,
} )