hook.Add( "PlayerButtonDown", "KeyDown_Minimap", function( ply, button )
	if ( button == 23 ) then -- M	
		if (SERVER) then
			umsg.Start( "Minimap", ply );
			umsg.End();
			print("OK2")
		end
		
	end
end )

print("OK")