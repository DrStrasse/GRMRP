





local BASE = "weapons/gmod_tool/stools/parametric_builder/"

if SERVER then
    AddCSLuaFile("weapons/gmod_tool/stools/parametric_builder.lua")
    AddCSLuaFile(BASE .. "pb_core.lua")
end

include(BASE .. "pb_core.lua")

for _, mod in ipairs(PB.MODULES) do
    local path = BASE .. mod.name .. ".lua"
    if SERVER and (mod.side == "shared" or mod.side == "client") then
        AddCSLuaFile(path)
    end

    if mod.name ~= "pb_core" then
        if mod.side == "shared" then
            include(path)
        elseif mod.side == "server" then
            if SERVER then include(path) end
        elseif mod.side == "client" then
            if CLIENT then include(path) end
        end
    end
end
