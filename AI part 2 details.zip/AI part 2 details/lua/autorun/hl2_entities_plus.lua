
--[[NOTIFICATIONS]]--
local colorRed, colorGreen

if (SERVER) then
	util.AddNetworkString("hl2e++_NotifyEntityCreator")

	colorRed, colorGreen = Color(255, 0, 0), Color(0, 255, 0)
else
	local colorBlue = Color(69, 180, 235)

	net.Receive("hl2e++_NotifyEntityCreator", function()
		local message = net.ReadTable()
		
		table.insert(message, color_white)
		table.insert(message, ".")

		chat.AddText(colorBlue, "[HL2 Entities++]: ", color_white, unpack(message))
	end)
end

--[[GLOBALS]]--
local globalStates = {}
globalStates["gordon_precriminal"] = "Gordon pre-criminal"
globalStates["antlion_allied"] = "Antlions are player allies"
globalStates["citizens_passive"] = "Citizens are not player allies"

if (SERVER) then
	concommand.Add("hl2epp_global_state", function(client, _, arguments)
		local bIsClientValid = IsValid(client)

		if (!bIsClientValid or client:IsAdmin()) then
			local globalState = arguments[1]
			local globalStateName = globalStates[arguments[1]]

			if (!globalStateName) then
				return
			end

			local globalKey = "global_state_" .. globalState 
			local bIsGlobalStateOff = !_G[globalKey]

			game.SetGlobalState(globalState, bIsGlobalStateOff and 1 or 0)
			_G[globalKey] = bIsGlobalStateOff and true or false

			if (bIsClientValid) then
				local statusMessage = bIsGlobalStateOff and {colorGreen, "on"} or {colorRed, "off"}
				local message = {
					"Global state \"" .. globalStateName .. "\" is now ",
					unpack(statusMessage)
				}

				net.Start("hl2e++_NotifyEntityCreator")
					net.WriteTable(message)
				net.Send(client)
			end
		end
	end)
else
	hook.Add("PopulateToolMenu", "hl2e++_ToolMenu", function()
		spawnmenu.AddToolMenuOption("Utilities", "Admin", "hl2e++_GlobalStates", "Global States", "", "", function(contextPanel)
			contextPanel:Clear()

			local textFormat = "Toggle \"%s\" global state."

			for k, v in pairs(globalStates) do
				contextPanel:Button(string.format(textFormat, v), "hl2epp_global_state", k)
			end
		end)
	end)
end

--[[PROPERTIES]]--
local noPersistenceEntities = {}
noPersistenceEntities["prop_vehicle_apc"] = true
noPersistenceEntities["npc_turret_ground"] = true
noPersistenceEntities["env_headcrabcanister"] = true

hook.Add("CanProperty", "hl2e++_BlockPersistence", function(_, property, entity)
	if (property == "persist" and noPersistenceEntities[entity:GetClass()]) then
		return false
	end
end)

properties.Add("activateTripmine", {
	MenuLabel = "Activate",
	Order = 999,
	MenuIcon = "icon16/map.png",
	Filter = function(self, entity, client)
		return entity:GetClass() == "npc_tripmine" and !entity:GetInternalVariable("m_bIsLive") and
			gamemode.Call("CanProperty", client, "persist", entity) != false
	end,
	Action = function(self, entity)
		self:MsgStart()
			net.WriteEntity(entity)
		self:MsgEnd()
	end,
	Receive = function(self, length, client)
		local entity = net.ReadEntity()

		if (!IsValid(entity) or !self:Filter(entity, client)) then
			return
		end

		entity:NextThink(CurTime())
	end
})

--[[DUPLICATOR]]--
duplicator.RegisterEntityClass("hl2e_combine_lock", function(client, position, angles, doorMapID)
	local combineLock = ents.Create("hl2ep_combine_lock")

	if (IsValid(combineLock)) then
		if (!IsValid(client)) then
			if (doorMapID) then
				combineLock.doorMapID = doorMapID
			end

			combineLock:SetPos(position)
			combineLock:SetAngles(angles)
			combineLock:Spawn()
			combineLock:Activate()

			return combineLock
		else
			return combineLock:SpawnCombineLock(combineLock, client, client:GetEyeTrace())
		end
	end
end, "pos", "ang", "doorMapID")

duplicator.RegisterEntityClass("item_ammo_crate", function(client, position, angles, ammoType)
	local ammoCrate = ents.Create("item_ammo_crate")

	if (IsValid(ammoCrate)) then
		ammoCrate:SetPos(position)
		ammoCrate:SetAngles(angles)

		if (ammoType) then
			ammoCrate.ammoType = ammoType
			ammoCrate:SetKeyValue("AmmoType", ammoType)
		end

		ammoCrate:Spawn()
		ammoCrate:Activate()

		return ammoCrate
	end
end, "pos", "ang", "ammoType")

duplicator.RegisterEntityClass("item_item_crate", function(client, position, angles, itemClass, itemCount)
	local supplyCrate = ents.Create("item_item_crate")

	if (IsValid(supplyCrate)) then
		supplyCrate:SetPos(position)
		supplyCrate:SetAngles(angles)

		if (itemClass) then
			supplyCrate.itemClass = itemClass
			supplyCrate:SetKeyValue("ItemClass", itemClass)
		end

		if (itemCount) then
			supplyCrate.itemCount = itemCount
			supplyCrate:SetKeyValue("ItemCount", itemCount)
		end

		supplyCrate:Spawn()
		supplyCrate:Activate()

		return supplyCrate
	end
end, "pos", "ang", "itemClass", "itemCount")

duplicator.RegisterEntityClass("prop_thumper", function(client, entity)
	local thumper = duplicator.GenericDuplicatorFunction(client, entity)

	if (thumper) then
		local dustScale = thumper.dustScale

		if (dustScale) then
			thumper:SetKeyValue("dustscale", dustScale)
		end

		return thumper
	end
end, "Data")
