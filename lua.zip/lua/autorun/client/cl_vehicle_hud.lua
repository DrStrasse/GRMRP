--[[--------------------------------------------------------------------
    VEHICLE KEY SYSTEM (VK) — Клиент: пассивная подпись владельца

    Показывает над машиной (без необходимости доставать SWEP):
      • Название и тип транспорта (Стандартный / SimFPhys / LVS)
      • Владелец: игрок (ник) или фракция (тег/цвет фракции)
      • Статус замка

    Работает при простом взгляде на машину с расстояния VK.HUD_RANGE.
--------------------------------------------------------------------]]

if SERVER then return end

VK = VK or {}
VK.ClientData = VK.ClientData or {}

net.Receive("VK_SyncVehicle", function()
    local veh = net.ReadEntity()
    local ownerType    = net.ReadString()
    local ownerSteam   = net.ReadString()
    local ownerNick    = net.ReadString()
    local factionName  = net.ReadString()
    local locked       = net.ReadBool()

    if not IsValid(veh) then return end
    veh.VK_OwnerType   = ownerType ~= "" and ownerType or nil
    veh.VK_OwnerSteam  = ownerSteam ~= "" and ownerSteam or nil
    veh.VK_OwnerNick   = ownerNick ~= "" and ownerNick or nil
    veh.VK_FactionName = factionName ~= "" and factionName or nil
    veh.VK_Locked      = locked
end)

net.Receive("VK_Result", function()
    local ok = net.ReadBool()
    local msg = net.ReadString()
    if msg == "" then return end
    local col = ok and Color(120, 220, 140) or Color(220, 90, 90)
    chat.AddText(col, "[VK] ", Color(220, 225, 245), msg)
end)

local function getFactionColor(name)
    if not Factions or not name then return Color(160, 160, 160) end
    local f = Factions[name]
    if f and f.Color then return Color(f.Color.r or 200, f.Color.g or 200, f.Color.b or 200) end
    return Color(160, 160, 160)
end

local function getOwnerLine(veh)
    if veh.VK_OwnerType == "player" and veh.VK_OwnerNick then
        return "Владелец: " .. veh.VK_OwnerNick, Color(120, 200, 255)
    elseif veh.VK_OwnerType == "faction" and veh.VK_FactionName then
        return "Фракция: " .. veh.VK_FactionName, getFactionColor(veh.VK_FactionName)
    end
    return "Без владельца", Color(150, 150, 150)
end

hook.Add("HUDPaint", "VK_OwnerLabel", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    -- Не рисуем поверх открытого SWEP HUD (у него своя, более подробная панель)
    local activeWep = ply:GetActiveWeapon()
    if IsValid(activeWep) and activeWep:GetClass() == (VK.KEY_CONFIG and VK.KEY_CONFIG.SWEP_CLASS or "vehicle_keys_swep") then
        return
    end

    local range = VK.HUD_RANGE or 220
    local tr = util.TraceLine({
        start  = ply:EyePos(),
        endpos = ply:EyePos() + ply:GetAimVector() * range,
        filter = ply,
        mask   = MASK_ALL,
    })

    local veh = tr.Entity
    if not IsValid(veh) or not VK.IsVehicle(veh) then return end
    if not (veh.VK_OwnerType or veh.VK_Locked ~= nil) then return end -- нет данных VK — не зарегистрирована

    local sw, sh = ScrW(), ScrH()
    local name = VK.GetVehicleDisplayName(veh)
    local typeLabel = VK.VehicleTypeLabel(veh)
    local ownerLine, ownerCol = getOwnerLine(veh)

    local cx = sw / 2
    local y  = sh / 2 + 55

    draw.SimpleText(name .. "  [" .. typeLabel .. "]", "DS_H_Title",
        cx, y, Color(255, 220, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

    draw.SimpleText(ownerLine, "DS_H_Sub",
        cx, y + 20, ownerCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)

    local lockTxt = veh.VK_Locked and "🔒 Заблокирована" or "🔓 Разблокирована"
    local lockCol = veh.VK_Locked and Color(255, 90, 90) or Color(90, 230, 110)
    draw.SimpleText(lockTxt, "DS_H_Sub",
        cx, y + 38, lockCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
end)

-- Резервные шрифты на случай, если Door System не загружен
if not DS then
    surface.CreateFont("DS_H_Title", { font = "Roboto", size = 20, weight = 700, antialias = true })
    surface.CreateFont("DS_H_Sub",   { font = "Roboto", size = 16, weight = 500, antialias = true })
    surface.CreateFont("DS_H_Hint",  { font = "Roboto", size = 14, weight = 600, antialias = true })
    surface.CreateFont("DS_H_Tiny",  { font = "Roboto", size = 13, weight = 500, antialias = true })
end