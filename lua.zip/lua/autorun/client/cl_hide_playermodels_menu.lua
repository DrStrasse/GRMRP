-- Отключаем добавление моделей в реестр
if player_manager then
    player_manager.AddValidModel = function() end
    player_manager.AddValidHands = function() end
    -- Очищаем уже существующие списки
    if player_manager.AllValidModels then
        -- Можно заменить таблицу моделей на пустую
        local oldGet = player_manager.AllValidModels
        player_manager.AllValidModels = function() return {} end
    end
end