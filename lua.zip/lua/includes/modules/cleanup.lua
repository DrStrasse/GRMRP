
module( "cleanup", package.seeall )

local cleanup_types = {}

local function IsType( type )

	for key, val in ipairs( cleanup_types ) do

		if ( val == type ) then return true end

	end

	return false

end

function Register( type )

	if ( type == "all" ) then return end

	for key, val in ipairs( cleanup_types ) do

		if val == type then return end

	end

	table.insert( cleanup_types, type )

end

function GetTable()
	return cleanup_types
end


if ( SERVER ) then

	local cleanup_list = {}

	local function CleanupInvalidEntities()
		for uniqId, cleanupTypes in pairs( cleanup_list ) do
			for cleanupType, entities in pairs( cleanupTypes ) do
				for key, ent in pairs( entities ) do
					if ( !IsValid( ent ) ) then
						entities[ key ] = nil
					end
				end

				-- Clear the table for this "cleanup type" if its empty
				if ( !next( entities ) ) then cleanupTypes[ cleanupType ] = nil end
			end

			-- Clear the top level table for the player if there's nothing in it left
			if ( !next( cleanupTypes ) ) then cleanup_list[ uniqId ] = nil end
		end
	end

	local numCleanups = 0
	hook.Add( "EntityRemoved", "Cleanup_RemoveInvalidEntities", function()

		-- Use a timer to guard against many entities being removed at once
		timer.Create( "Cleanup_QueuedRemoveInvalidEntities", 0, 1, function()
			numCleanups = numCleanups + 1

			-- Cleanup invalid entities only every once in a while
			-- The value is arbitrary, we just don't want to go through the entire table on every entity removal
			-- As the memory savings would not be worth the execution time
			if ( numCleanups >= 16 ) then
				numCleanups = 0
				CleanupInvalidEntities()
			end
		end )

	end )

	function GetList()
		return cleanup_list
	end

	saverestore.AddSaveHook( "CleanupTable", function( save )
		saverestore.WriteTable( cleanup_list, save )
	end )
	saverestore.AddRestoreHook( "CleanupTable", function( restore )
		cleanup_list = saverestore.ReadTable( restore )
	end )

	function Add( pl, type, ent )

		if ( !ent ) then return end

		if ( !IsType( type ) ) then return end

		local id = pl:UniqueID()

		cleanup_list[ id ] = cleanup_list[ id ] or {}
		cleanup_list[ id ][ type ] = cleanup_list[ id ][ type ] or {}

		if ( !IsValid( ent ) ) then return end

		table.insert( cleanup_list[ id ][ type ], ent )

	end

	function ReplaceEntity( from, to )

		local ActionTaken = false

		for _, PlayerTable in pairs( cleanup_list ) do
			for _, TypeTable in pairs( PlayerTable ) do
				for key, ent in pairs( TypeTable ) do

					if ( ent == from ) then
						TypeTable[ key ] = to
						ActionTaken = true
					end

				end
			end
		end

		return ActionTaken

	end


	function CC_Cleanup( pl, command, args )

		if ( !IsValid( pl ) ) then return end

		local id = pl:UniqueID()

		if ( !cleanup_list[ id ] ) then return end

		if ( !args[ 1 ] ) then

			local count = 0

			for key, val in pairs( cleanup_list[ id ] ) do

				for _, ent in pairs( val ) do

					if ( IsValid( ent ) ) then ent:Remove() end
					count = count + 1

				end

				table.Empty( val )

			end

			-- Send tooltip command to client
			if ( count > 0 ) then
				pl:SendLua( "hook.Run('OnCleanup','all')" )
			end

			return

		end

		if ( !IsType( args[1] ) ) then return end
		if ( !cleanup_list[id][ args[1] ] ) then return end

		for key, ent in pairs( cleanup_list[id][ args[1] ] ) do

			if ( IsValid( ent ) ) then ent:Remove() end

		end

		table.Empty( cleanup_list[id][ args[1] ] )

		-- Send tooltip command to client
		pl:SendLua( string.format( "hook.Run('OnCleanup',%q)", args[1] ) )

	end

	function CC_AdminCleanup( pl, command, args )

		if ( IsValid( pl ) && !pl:IsAdmin() ) then return end

		if ( !args[ 1 ] ) then

			for key, ply in pairs( cleanup_list ) do

				for _, type in pairs( ply ) do

					for __, ent in pairs( type ) do

						if ( IsValid( ent ) ) then ent:Remove() end

					end

					table.Empty( type )

				end

			end

			game.CleanUpMap( false, nil, function()
				-- Send tooltip command to client
				if ( IsValid( pl ) ) then pl:SendLua( "hook.Run('OnCleanup','all')" ) end
			end )

			return

		end

		if ( !IsType( args[ 1 ] ) ) then return end

		for key, ply in pairs( cleanup_list ) do

			if ( ply[ args[ 1 ] ] != nil ) then

				for id, ent in pairs( ply[ args[ 1 ] ] ) do

					if ( IsValid( ent ) ) then ent:Remove() end

				end

				table.Empty( ply[ args[ 1 ] ] )

			end

		end

		-- Send tooltip command to client
		if ( IsValid( pl ) ) then pl:SendLua( string.format( "hook.Run('OnCleanup',%q)", args[1] ) ) end

	end

	concommand.Add( "gmod_cleanup", CC_Cleanup, nil, "", { FCVAR_DONTRECORD } )
	concommand.Add( "gmod_admin_cleanup", CC_AdminCleanup, nil, "", { FCVAR_DONTRECORD } )

else

	local function BuildPanel( pnl, command )
		if ( !IsValid( pnl ) ) then return end

		local cleanup_types_s = {}
		for _, val in ipairs( cleanup_types ) do
			cleanup_types_s[ language.GetPhrase( "Cleanup_" .. val ) ] = val
		end

		pnl:Clear()
		pnl:Help( "#spawnmenu.utilities.cleanup.help" )
		pnl:Button( "#spawnmenu.utilities.cleanup.all", command )

		for key, val in SortedPairs( cleanup_types_s ) do
			pnl:Button( key, command, val )
		end
	end

	function UpdateUI()
		local Panel = controlpanel.Get( "User_Cleanup" )
		if ( IsValid( Panel ) ) then BuildPanel( Panel, "gmod_cleanup" ) end

		local Panel = controlpanel.Get( "Admin_Cleanup" )
		if ( IsValid( Panel ) ) then BuildPanel( Panel, "gmod_admin_cleanup" ) end
	end

	hook.Add( "PopulateToolMenu", "Cleanup_RegisterToolMenu", function()

		spawnmenu.AddToolMenuOption( "Utilities", "User", "User_Cleanup", "#spawnmenu.utilities.cleanup", "", "", function( pnl )
			BuildPanel( pnl, "gmod_cleanup" )
		end )

		spawnmenu.AddToolMenuOption( "Utilities", "Admin", "Admin_Cleanup", "#spawnmenu.utilities.cleanup", "", "", function( pnl )
			BuildPanel( pnl, "gmod_admin_cleanup" )
		end )

	end )

end
