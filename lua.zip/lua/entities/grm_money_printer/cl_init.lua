--[[--------------------------------------------------------------------
    grm_money_printer — cl_init.lua (CLIENT)

    3D2D HUD над принтером:
      • Сумма накопленного, температура, статус
      • Glow-спрайт: зелёный (холодный) → красный (жаркий)
      • Мигание при активном цикле печати
--------------------------------------------------------------------]]

include("shared.lua")

surface.CreateFont("GRM_P3D_Big", {
    font = "Verdana", size = 28, weight = 700, antialias = true
})
surface.CreateFont("GRM_P3D_Small", {
    font = "Verdana", size = 16, weight = 600, antialias = true
})
surface.CreateFont("GRM_P3D_Tiny", {
    font = "Verdana", size = 12, weight = 500, antialias = true
})

local matGlow  = Material("sprites/light_glow02_add")
local matPaper = Material("sprites/heatwave")   -- небольшой эффект над принтером

function ENT:Draw()
    self:DrawModel()

    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    local dist = lp:GetPos():Distance(self:GetPos())
    if dist > 450 then return end

    local alpha    = math.Clamp((450 - dist) / 180, 0, 1)
    local held     = self:GetHeldMoney()
    local working  = self:GetWorking()
    local heat     = self:GetHeat()
    local printing = self:GetPrintingNow()

    -- ── 3D2D панель ──────────────────────────────────────────────
    local pos = self:GetPos() + Vector(0, 0, 58)
    local ang = lp:EyeAngles()
    ang:RotateAroundAxis(ang:Forward(), 90)
    ang:RotateAroundAxis(ang:Right(),   90)

    cam.Start3D2D(pos, ang, 0.10)

        local W, H   = 240, 84
        local halfW  = W * 0.5
        local floorA = math.floor

        -- Фон
        surface.SetDrawColor(8, 10, 18, floorA(210 * alpha))
        surface.DrawRect(-halfW, -H * 0.5, W, H)

        -- Полоса температуры (слева — зелёная, справа — красная)
        local heatFrac = heat / 100
        local barW     = math.floor(W * heatFrac)
        local barR     = math.floor(heatFrac * 255)
        local barG     = math.floor((1 - heatFrac) * 200)
        surface.SetDrawColor(barR, barG, 0, floorA(200 * alpha))
        surface.DrawRect(-halfW, -H * 0.5, barW, 5)

        -- Полоса заполнения принтера (синяя, снизу)
        local maxHeld  = self.GRM_MaxHeld or 2000
        local fillFrac = math.min(1, held / maxHeld)
        surface.SetDrawColor(30, 80, 200, floorA(160 * alpha))
        surface.DrawRect(-halfW, H * 0.5 - 5, math.floor(W * fillFrac), 5)

        -- Сумма
        local moneyCol = printing
            and Color(255, 255, 80, floorA(255 * alpha))   -- мигает жёлтым при печати
            or  Color(255, 240, 140, floorA(255 * alpha))
        draw.SimpleText(
            GRM.Format(held),
            "GRM_P3D_Big",
            0, -12,
            moneyCol,
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
        )

        -- Статус
        local statusStr, statusCol
        if not working then
            statusStr = "⚠ ПЕРЕГРЕВ — " .. math.floor(heat) .. "°"
            statusCol = Color(255, 70, 40, floorA(255 * alpha))
        elseif printing then
            statusStr = "▶ Печатает..."
            statusCol = Color(100, 255, 120, floorA(255 * alpha))
        elseif heat > 70 then
            statusStr = "~ Горячо: " .. math.floor(heat) .. "°"
            statusCol = Color(255, 180, 50, floorA(255 * alpha))
        else
            if held > 0 then
                statusStr = "[E] Забрать деньги"
                statusCol = Color(100, 220, 100, floorA(255 * alpha))
            else
                statusStr = "Ожидание следующего цикла"
                statusCol = Color(150, 150, 150, floorA(255 * alpha))
            end
        end
        draw.SimpleText(statusStr, "GRM_P3D_Small", 0, 22, statusCol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)

        -- Температура (мелко, правый угол)
        draw.SimpleText(
            math.floor(heat) .. "°C",
            "GRM_P3D_Tiny",
            halfW - 6, -H * 0.5 + 8,
            Color(200, 200, 200, floorA(180 * alpha)),
            TEXT_ALIGN_RIGHT
        )

    cam.End3D2D()

    -- ── Glow-спрайт ──────────────────────────────────────────────
    if dist < 350 then
        local speed  = working and (printing and 4 or 2) or 0.4
        local pulse  = math.abs(math.sin(CurTime() * speed)) * 0.5 + 0.5
        local gr     = math.floor(heat * 2.55)
        local gg     = math.floor((1 - heat / 100) * 200)
        local sz     = 18 + pulse * 12
        render.SetMaterial(matGlow)
        render.DrawSprite(
            self:GetPos() + Vector(0, 0, 18),
            sz, sz,
            Color(gr, gg, 0, math.floor(160 * alpha * pulse))
        )
    end
end

-- Регистрация в Q-меню (категория GRM Finance, AdminSpawnable)
list.Set("SpawnableEntities", "grm_money_printer", {
    PrintName = "GRM Money Printer",
    ClassName = "grm_money_printer",
    Category  = "GRM Finance",
})
