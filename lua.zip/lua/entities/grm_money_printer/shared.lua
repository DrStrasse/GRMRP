--[[--------------------------------------------------------------------
    grm_money_printer — shared.lua
    Модель: models/props_c17/consolebox03a.mdl
--------------------------------------------------------------------]]

ENT.Type           = "anim"
ENT.Base           = "base_gmodentity"
ENT.PrintName      = "GRM Money Printer"
ENT.Author         = "GRM System v2.1"
ENT.Category       = "GRM Finance"
ENT.Spawnable      = false       -- Спавн только через !spawnprinter или меню
ENT.AdminSpawnable = true
ENT.RenderGroup    = RENDERGROUP_OPAQUE

-- ── Настройки принтера ────────────────────────────────────────────
ENT.GRM_PerCycle   = 200    -- GRM за один цикл печати
ENT.GRM_CycleTime  = 45     -- секунд между циклами
ENT.GRM_MaxHeld    = 2000   -- максимум GRM до сбора
ENT.GRM_MaxHealth  = 150    -- прочность

-- ── Сетевые переменные ────────────────────────────────────────────
function ENT:SetupDataTables()
    self:NetworkVar("Int",   0, "HeldMoney")    -- GRM в принтере
    self:NetworkVar("Bool",  0, "Working")       -- работает/перегрев
    self:NetworkVar("Float", 0, "Heat")          -- температура 0..100
    self:NetworkVar("Bool",  1, "PrintingNow")   -- мигание при активном цикле
end
