--[[--------------------------------------------------------------------
    grm_money_printer — init.lua (SERVER)

    Механика:
      • Каждые GRM_CycleTime секунд генерирует GRM_PerCycle GRM.
      • При каждом цикле воспроизводит звук печатающего принтера.
      • Нагревается на 12° за цикл. При 100° — перегрев, пауза.
      • Остывает на 2°/3 сек. При падении ниже 80° — возобновляет работу.
      • [E] — забрать накопленные деньги (охлаждает на 20°).
      • Урон → нагрев. При 0 HP — взрыв (деньги теряются).
    Модель: models/props_c17/consolebox03a.mdl
--------------------------------------------------------------------]]

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

local SND_PRINT_LOOP  = "ambient/machines/machine2.wav"
local SND_PRINT_CYCLE = "ambient/office/printer_paper1.wav"
local SND_COLLECT     = "buttons/button15.wav"
local SND_OVERHEAT    = "ambient/alarms/warningbell1.wav"
local SND_EXPLODE     = "ambient/machines/explode1.wav"

function ENT:Initialize()
    self:SetModel("models/props_c17/consolebox03a.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then phys:Wake() end

    self:SetHealth(self.GRM_MaxHealth)
    self:SetMaxHealth(self.GRM_MaxHealth)
    self:SetHeldMoney(0)
    self:SetWorking(true)
    self:SetHeat(0)
    self:SetPrintingNow(false)

    -- Флаг: смерть уже запущена (защита от повторного входа)
    self._dying = false

    self._loopSound = CreateSound(self, SND_PRINT_LOOP)
    if self._loopSound then
        self._loopSound:SetSoundLevel(65)
        self._loopSound:Play()
    end

    self:NextThink(CurTime() + self.GRM_CycleTime)
end

function ENT:Think()
    local now = CurTime()

    if not self:GetWorking() then
        local heat = math.max(0, self:GetHeat() - 2)
        self:SetHeat(heat)
        if heat <= 80 then
            self:SetWorking(true)
            if self._loopSound then self._loopSound:Play() end
        end
        self:SetPrintingNow(false)
        self:NextThink(now + 3)
        return true
    end

    local heat = math.min(100, self:GetHeat() + 12)
    self:SetHeat(heat)

    if heat >= 100 then
        self:SetWorking(false)
        self:SetPrintingNow(false)
        if self._loopSound then self._loopSound:Stop() end
        self:EmitSound(SND_OVERHEAT, 75, 100)

        local eff = EffectData()
        eff:SetOrigin(self:GetPos() + Vector(0, 0, 20))
        eff:SetScale(2)
        util.Effect("Sparks", eff)

        self:NextThink(now + 3)
        return true
    end

    local held = self:GetHeldMoney()
    if held < self.GRM_MaxHeld then
        local earned = heat > 75
            and math.floor(self.GRM_PerCycle * 0.5)
            or  self.GRM_PerCycle
        self:SetHeldMoney(math.min(self.GRM_MaxHeld, held + earned))
    end

    self:SetPrintingNow(true)
    self:EmitSound(SND_PRINT_CYCLE, 70, math.random(95, 105))

    local eff = EffectData()
    eff:SetOrigin(self:GetPos() + Vector(0, 0, 20))
    eff:SetScale(0.8)
    util.Effect("Sparks", eff)

    timer.Simple(1.5, function()
        if IsValid(self) then self:SetPrintingNow(false) end
    end)

    self:NextThink(now + self.GRM_CycleTime)
    return true
end

function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    local held = self:GetHeldMoney()
    if held <= 0 then
        activator:ChatPrint("[GRM Принтер] Деньги ещё не накоплены, подождите.")
        return
    end

    GRM.GiveMoney(activator, held)
    activator:ChatPrint("[GRM Принтер] Собрано " .. GRM.Format(held) .. "!")
    self:EmitSound(SND_COLLECT, 75, 100)
    self:SetHeldMoney(0)

    local newHeat = math.max(0, self:GetHeat() - 20)
    self:SetHeat(newHeat)
    if not self:GetWorking() and newHeat < 80 then
        self:SetWorking(true)
        if self._loopSound then self._loopSound:Play() end
    end
end

function ENT:OnTakeDamage(dmginfo)
    -- ФИХ 1: защита от повторного входа.
    -- Без этого флага очередь/дробовик/взрыв могут вызвать OnTakeDamage
    -- несколько раз за один тик, и весь блок смерти выполняется параллельно.
    if self._dying then return end

    local dmg   = dmginfo:GetDamage()
    local newHP = self:Health() - dmg
    self:SetHealth(newHP)
    self:SetHeat(math.min(100, self:GetHeat() + dmg * 0.5))

    if newHP > 0 then return end

    -- ФИХ 2: ставим флаг ДО любых дальнейших операций.
    self._dying = true

    local blastPos = self:GetPos()
    local owner    = self:GetOwner()
    local lost     = self:GetHeldMoney()

    if self._loopSound then self._loopSound:Stop() end

    local exp = EffectData()
    exp:SetOrigin(blastPos)
    exp:SetScale(2)
    util.Effect("Explosion", exp)
    self:EmitSound(SND_EXPLODE, 90, 100)

    if lost > 0 and IsValid(owner) and owner:IsPlayer() then
        owner:ChatPrint("[GRM Принтер] Принтер уничтожен! Потеряно " .. GRM.Format(lost) .. "!")
    end

    -- ФИХ 3: BlastDamage вызывается ДО Remove(), пока сущность ещё валидна,
    -- и БЕЗ timer.Simple — это убирало задержку, при которой движок уже
    -- не знал кто атакующий, и порождало цепные взрывы между принтерами.
    --
    -- Чтобы исключить цепную реакцию принтеров друг на друга:
    -- используем игрока-владельца как атакующего (или world если его нет),
    -- и игнорируем урон от взрыва внутри OnTakeDamage через флаг _dying.
    local attacker = (IsValid(owner) and owner:IsPlayer()) and owner or game.GetWorld()
    util.BlastDamage(attacker, attacker, blastPos, 80, 30)

    -- Удаляем сущность последней — после всех операций с ней
    self:Remove()
end

function ENT:OnRemove()
    if self._loopSound then self._loopSound:Stop() end
end

function ENT:PreEntityCopy()
    return { owner = IsValid(self:GetOwner()) and self:GetOwner():SteamID64() or nil }
end

function ENT:PostEntityPaste(ply)
    if IsValid(ply) then self:SetOwner(ply) end
end
