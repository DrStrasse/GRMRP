--[[--------------------------------------------------------------------
    grm_money_drop — shared.lua
    Физическая пачка денег на земле (результат !dropmoney)
--------------------------------------------------------------------]]

ENT.Type           = "anim"
ENT.Base           = "base_gmodentity"
ENT.PrintName      = "Деньги"
ENT.Author         = "GRM System v2.1"
ENT.Category       = "GRM Finance"
ENT.Spawnable      = false
ENT.AdminSpawnable = false
ENT.RenderGroup    = RENDERGROUP_OPAQUE

function ENT:SetupDataTables()
    self:NetworkVar("Int",    0, "Amount")      -- сумма
    self:NetworkVar("String", 0, "Dropper")     -- SteamID64 бросившего
end
