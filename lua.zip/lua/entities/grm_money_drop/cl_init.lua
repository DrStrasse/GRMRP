--[[--------------------------------------------------------------------
    grm_money_drop — cl_init.lua (CLIENT)
    3D2D подпись с суммой над пачкой денег.
    Видна с расстояния до 200 единиц.
--------------------------------------------------------------------]]

include("shared.lua")

surface.CreateFont("GRM_Drop_Big", {
    font = "Verdana", size = 22, weight = 700, antialias = true
})
surface.CreateFont("GRM_Drop_Small", {
    font = "Verdana", size = 14, weight = 500, antialias = true
})

local matGlow = Material("sprites/light_glow02_add")

function ENT:Draw()
    self:DrawModel()

    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    local dist = lp:GetPos():Distance(self:GetPos())
    if dist > 200 then return end

    local alpha  = math.Clamp((200 - dist) / 80, 0, 1)
    local amount = self:GetAmount()

    -- Лёгкое вращение для привлечения внимания
    local pos = self:GetPos() + Vector(0, 0, 22)
    local ang = lp:EyeAngles()
    ang:RotateAroundAxis(ang:Forward(), 90)
    ang:RotateAroundAxis(ang:Right(),   90)

    cam.Start3D2D(pos, ang, 0.09)

        -- Фон
        surface.SetDrawColor(10, 30, 10, math.floor(200 * alpha))
        surface.DrawRect(-90, -22, 180, 44)

        -- Зелёная рамка
        surface.SetDrawColor(60, 180, 60, math.floor(200 * alpha))
        surface.DrawOutlinedRect(-90, -22, 180, 44, 2)

        -- Символ валюты
        draw.SimpleText(
            GRM.Format(amount),
            "GRM_Drop_Big",
            0, -6,
            Color(80, 240, 80, math.floor(255 * alpha)),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
        )
        draw.SimpleText(
            "[E] подобрать",
            "GRM_Drop_Small",
            0, 14,
            Color(180, 220, 180, math.floor(200 * alpha)),
            TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
        )

    cam.End3D2D()

    -- Мягкое зелёное свечение
    if dist < 150 then
        local pulse = math.abs(math.sin(CurTime() * 2.5)) * 0.4 + 0.6
        local sz    = 14 + pulse * 8
        render.SetMaterial(matGlow)
        render.DrawSprite(
            self:GetPos() + Vector(0, 0, 8),
            sz, sz,
            Color(40, 200, 40, math.floor(140 * alpha * pulse))
        )
    end
end
