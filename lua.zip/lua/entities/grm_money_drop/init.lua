--[[--------------------------------------------------------------------
    grm_money_drop — init.lua (SERVER)
    Физическая пачка денег, появляющаяся от !dropmoney.
    Подобрать: [E] или через контекстное меню.
    Исчезает сама через 5 минут.
--------------------------------------------------------------------]]

AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

local SND_PICKUP = "items/itempickup.wav"

function ENT:Initialize()
    self:SetModel("models/props/cs_assault/money.mdl")
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_VPHYSICS)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:Wake()
        phys:SetMass(0.5)
    end

    self:SetAmount(0)
    self:SetDropper("")

    -- Автоудаление через 5 минут
    timer.Create("GRM_Drop_" .. self:EntIndex(), 300, 1, function()
        if IsValid(self) then self:Remove() end
    end)
end

-- [E] Подобрать деньги
function ENT:Use(activator, caller)
    if not IsValid(activator) or not activator:IsPlayer() then return end
    self:PickUp(activator)
end

function ENT:PickUp(ply)
    local amount = self:GetAmount()
    if amount <= 0 then self:Remove(); return end

    GRM.GiveMoney(ply, amount)
    ply:ChatPrint("[GRM] Подобрано: " .. GRM.Format(amount))
    self:EmitSound(SND_PICKUP, 70, 100)

    timer.Remove("GRM_Drop_" .. self:EntIndex())
    self:Remove()
end

function ENT:OnRemove()
    timer.Remove("GRM_Drop_" .. self:EntIndex())
end
