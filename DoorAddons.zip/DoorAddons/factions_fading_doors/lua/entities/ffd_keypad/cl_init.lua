include("shared.lua")

-- Цвета индикации состояния кейпада
local COLOR_LINKED = Color(80, 220, 120, 255)
local COLOR_UNLINKED = Color(220, 90, 90, 255)

function ENT:Draw()
    self:DrawModel()

    -- Рисуем индикатор привязки (маленький кружок на кейпаде)
    local door = self:GetLinkedDoor()
    local color = IsValid(door) and COLOR_LINKED or COLOR_UNLINKED

    local pos = self:GetPos() + self:GetUp() * 3
    local ang = self:GetAngles()
    ang:RotateAroundAxis(ang:Up(), 90)

    cam.Start3D2D(pos, ang, 0.05)
        draw.RoundedBox(8, -20, -20, 40, 40, color)
    cam.End3D2D()
end