ENT.Type            = "anim"
ENT.Base            = "base_gmodentity"
ENT.PrintName       = "FFD Кейпад"
ENT.Author          = "FFD"
ENT.Category        = "Factions Fading Doors"
ENT.Spawnable       = false
ENT.AdminSpawnable  = true

function ENT:SetupDataTables()
    self:NetworkVar("Entity", 0, "LinkedDoor")
    self:NetworkVar("Bool", 0, "HasAccessOverride")
end
