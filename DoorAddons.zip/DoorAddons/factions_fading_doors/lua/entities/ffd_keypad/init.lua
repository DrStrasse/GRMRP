AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")
include("shared.lua")

function ENT:Initialize()
    self:SetModel(self:GetModel() or FFD.DEFAULT_KEYPAD_MODEL)
    self:PhysicsInit(SOLID_VPHYSICS)
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_VPHYSICS)
    self:SetUseType(SIMPLE_USE)

    local phys = self:GetPhysicsObject()
    if IsValid(phys) then
        phys:EnableMotion(false)
    end

    -- Небольшая защита от дребезга: не даём вызвать Use чаще, чем
    -- раз в 0.5 сек (движок иногда шлёт Use несколько раз на одно
    -- нажатие E при лаге/рестарте сети).
    self.FFDLastUse = 0

    -- Счётчик попыток поиска двери (чтобы не искать бесконечно)
    self.FFDSearchAttempts = 0
    self.FFDMaxSearchAttempts = 15 -- 15 попыток × 2 сек = 30 сек поиска

    -- Автосканирование: если кейпад не привязан к двери, периодически
    -- ищем ближайшую Fading Door и привязываем автоматически.
    self:NextThink(CurTime() + 2)
end

function ENT:Think()
    if not IsValid(self:GetLinkedDoor()) then
        -- Ограничиваем количество попыток поиска
        if self.FFDSearchAttempts < self.FFDMaxSearchAttempts then
            self.FFDSearchAttempts = (self.FFDSearchAttempts or 0) + 1

            -- Сначала пробуем найти по сохранённому ID двери
            local doorId = self._FFDPendingDoorLink or self.FFDLinkedDoorID
            if doorId and doorId ~= "" then
                for _, door in ipairs(ents.GetAll()) do
                    if IsValid(door) and door.FFDSavedID == doorId then
                        self:SetLinkedDoor(door)
                        self._FFDPendingDoorLink = nil
                        self.FFDSearchAttempts = self.FFDMaxSearchAttempts -- Прекращаем поиск
                        break
                    end
                end
            end

            -- Если не нашли по ID — ищем ближайшую
            if not IsValid(self:GetLinkedDoor()) then
                local nearest = FFD.FindNearestDoor(self:GetPos(), FFD.KEYPAD_LINK_RADIUS)
                if IsValid(nearest) then
                    self:SetLinkedDoor(nearest)
                    self.FFDSearchAttempts = self.FFDMaxSearchAttempts -- Прекращаем поиск
                end
            end

            self:NextThink(CurTime() + 2)
            return true
        end
        -- После исчерпания попыток — проверяем раз в 30 секунд
        self:NextThink(CurTime() + 30)
        return true
    end

    -- Дверь привязана — проверяем редко (на случай удаления двери)
    self:NextThink(CurTime() + 10)
    return true
end

function ENT:Use(activator)
    if not IsValid(activator) or not activator:IsPlayer() then return end

    local now = CurTime()
    if now - (self.FFDLastUse or 0) < 0.5 then return end
    self.FFDLastUse = now

    local door = self:GetLinkedDoor()
    if not IsValid(door) or not door.isFadingDoor then
        activator:ChatPrint("[Кейпад] Не привязан ни к одной двери.")
        return
    end

    local access = self.FFDAccessOverride or door.FFDAccess or { accessType = FFD.ACCESS.PUBLIC }
    if not FFD.CheckAccess(activator, access) then
        activator:ChatPrint("[Кейпад] Доступ запрещён.")
        self:EmitSound("buttons/button11.wav", 350, 100)
        return
    end

    if door.fadeActive then
        if door.fadeDeactivate then door:fadeDeactivate() end
    else
        if door.fadeActivate then door:fadeActivate() end
    end
    self:EmitSound("buttons/button14.wav", 350, 100)
end

function ENT:OnRemove()
end