--[[--------------------------------------------------------------------
    FFD Keypad — ставит проп-кейпад, привязывает его к ближайшей
    Fading Door (в радиусе FFD.KEYPAD_LINK_RADIUS) и позволяет
    настроить отдельный доступ по фракции/роли. Суперадмин может
    сохранить кейпад навсегда на карте.

    Исправлено:
    - RightClick открывает панель через net-сообщение
    - Улучшена обработка ошибок
--------------------------------------------------------------------]]

TOOL.Category   = "Construction"
TOOL.Name       = "#FFD Keypad (Фракции)"
TOOL.Command    = nil
TOOL.ConfigName = ""

TOOL.ClientConVar = {
    model       = "models/props_lab/keypad.mdl",
    radius      = tostring(FFD.KEYPAD_LINK_RADIUS),
    permanent   = "0",
    mode        = "place",
}

if CLIENT then
    language.Add("tool.ffd_keypad.name", "FFD Keypad (Фракции)")
    language.Add("tool.ffd_keypad.desc", "Ставит кейпад и привязывает его к ближайшей Fading Door. ЛКМ — поставить/перепривязать, ПКМ — настроить доступ, Перезарядка — удалить.")
    language.Add("tool.ffd_keypad.0", "ЛКМ: поставить кейпад (привязка к ближайшей двери). ПКМ на кейпаде: доступ. Перезарядка: удалить кейпад.")
end

function TOOL:LeftClick(tr)
    if not tr.HitPos then return false end
    if tr.Entity and tr.Entity:IsPlayer() then return false end
    if CLIENT then return true end

    local pl = self:GetOwner()
    if not IsValid(pl) then return false end

    local mode = self:GetClientInfo("mode")

    -- ─── Режим "Привязать вручную" ────────────────────────────────
    if mode == "link" then
        if tr.Entity and IsValid(tr.Entity) and tr.Entity:GetClass() == "ffd_keypad" then
            self.LinkSource = tr.Entity
            pl:ChatPrint("[FFD] Кейпад выбран. Теперь кликните ЛКМ по нужной Fading Door.")
            return true
        end

        if tr.Entity and IsValid(tr.Entity) and tr.Entity.isFadingDoor then
            if not IsValid(self.LinkSource) then
                pl:ChatPrint("[FFD] Сначала кликните по кейпаду, который нужно привязать.")
                return false
            end
            self.LinkSource:SetLinkedDoor(tr.Entity)
            pl:ChatPrint("[FFD] Кейпад привязан к этой двери.")
            if self.LinkSource.FFDSavedID then
                FFD.SaveKeypad(pl, self.LinkSource)
            end
            self.LinkSource = nil
            return true
        end

        pl:ChatPrint("[FFD] Наведитесь на кейпад, затем на дверь, чтобы привязать вручную.")
        return false
    end

    -- ─── Режим "Установить новый" ─────────────────────────────────
    local model = self:GetClientInfo("model")
    if not model or model == "" then model = FFD.DEFAULT_KEYPAD_MODEL end

    local ang = tr.HitNormal:Angle()
    ang:RotateAroundAxis(ang:Up(), 90)
    ang:RotateAroundAxis(ang:Forward(), 90)

    local ent = ents.Create("ffd_keypad")
    if not IsValid(ent) then return false end

    ent:SetModel(model)
    ent:SetPos(tr.HitPos + tr.HitNormal * 2)
    ent:SetAngles(ang)
    ent:Spawn()
    ent:SetMoveType(MOVETYPE_NONE)
    ent:SetSolid(SOLID_VPHYSICS)

    if tr.Entity and IsValid(tr.Entity) and not tr.Entity:IsWorld() then
        ent:SetParent(tr.Entity)
    end

    local radius = self:GetClientNumber("radius")
    local nearestDoor = FFD.FindNearestDoor(ent:GetPos(), radius)

    if IsValid(nearestDoor) then
        ent:SetLinkedDoor(nearestDoor)
        pl:ChatPrint("[FFD] Кейпад поставлен и привязан к двери.")
    else
        pl:ChatPrint("[FFD] Кейпад поставлен, но рядом не найдено Fading Door (радиус " .. radius .. "). Он будет автоматически привязан, как только рядом появится дверь, либо привяжите вручную (Перезарядка/режим привязки).")
    end

    undo.Create("FFD Keypad")
    undo.AddEntity(ent)
    undo.SetPlayer(pl)
    undo.Finish()

    if self:GetClientNumber("permanent") == 1 then
        local ok, err = FFD.SaveKeypad(pl, ent)
        pl:ChatPrint(ok and "[FFD] Кейпад сохранён навсегда на карте." or ("[FFD] Не удалось сохранить: " .. tostring(err)))
    end

    self.LastKeypad = ent
    return true
end

function TOOL:RightClick(tr)
    if not tr.Entity or not tr.Entity:IsValid() then return false end
    if tr.Entity:GetClass() ~= "ffd_keypad" then return false end

    if CLIENT then
        -- Отправляем запрос серверу на открытие панели доступа
        net.Start("FFD_OpenAccessEditor")
        net.WriteEntity(tr.Entity)
        net.SendToServer()
        return true
    end

    -- На сервере: отправляем клиенту команду открыть панель
    local pl = self:GetOwner()
    if IsValid(pl) then
        net.Start("FFD_OpenAccessEditor")
        net.WriteEntity(tr.Entity)
        net.Send(pl)
    end

    return true
end

function TOOL:Reload(tr)
    if CLIENT then return true end

    local pl = self:GetOwner()
    if not IsValid(pl) then return false end

    -- Найти кейпад: сначала прямой трейс, иначе — ближайший в небольшом радиусе
    -- (чтобы неточная коллизия модели не мешала удалению/привязке).
    local keypad = (tr.Entity and IsValid(tr.Entity) and tr.Entity:GetClass() == "ffd_keypad") and tr.Entity or nil
    if not keypad and tr.HitPos then
        keypad = FFD.FindNearestKeypad(tr.HitPos, 48)
    end

    if IsValid(keypad) then
        if keypad.FFDSavedID then FFD.UnsaveKeypad(pl, keypad) end
        keypad:Remove()
        pl:ChatPrint("[FFD] Кейпад удалён.")
        return true
    end

    -- Если смотрим на Fading Door — перепривязать последний поставленный кейпад к ней.
    if tr.Entity and IsValid(tr.Entity) and tr.Entity.isFadingDoor and IsValid(self.LastKeypad) then
        self.LastKeypad:SetLinkedDoor(tr.Entity)
        pl:ChatPrint("[FFD] Кейпад перепривязан к этой двери.")
        if self.LastKeypad.FFDSavedID then FFD.SaveKeypad(pl, self.LastKeypad) end
        return true
    end

    pl:ChatPrint("[FFD] Наведитесь точно на кейпад (для удаления) или на дверь (для перепривязки последнего кейпада).")
    return false
end

if CLIENT then
    function TOOL.BuildCPanel(panel)
        panel:AddControl("Header", { Text = "#tool.ffd_keypad.name", Description = "#tool.ffd_keypad.desc" })

        local modeCombo = vgui.Create("DComboBox", panel)
        modeCombo:SetValue("Установить новый кейпад")
        modeCombo:AddChoice("Установить новый кейпад", "place")
        modeCombo:AddChoice("Привязать вручную (кейпад → дверь)", "link")
        modeCombo.OnSelect = function(_, _, _, data)
            RunConsoleCommand("ffd_keypad_mode", data)
        end
        panel:AddItem(modeCombo)

        panel:AddControl("TextBox", { Label = "Модель кейпада", Command = "ffd_keypad_model" })
        panel:AddControl("Slider", { Label = "Радиус поиска двери", Command = "ffd_keypad_radius", Type = "Integer", Min = 50, Max = 500 })

        panel:AddControl("Header", { Text = "Постоянное сохранение" })
        panel:CheckBox("Сохранить навсегда на карте (только суперадмин)", "ffd_keypad_permanent")
    end
end