--[[--------------------------------------------------------------------
    FFD Fading Door — обёртка над штатным Fading Door STOOL,
    добавляет привязку доступа к фракциям/ролям и постоянное
    сохранение на карте (только суперадмин).

    Требует установленный на сервере оригинальный Fading Door STOOL
    (тот, что регистрирует duplicator.RegisterEntityModifier("Fading Door", ...)).

    Исправлено:
    - ClientConVar теперь использует литеральные строки (не FFD.ACCESS.*)
      чтобы избежать ошибки при загрузке до autorun
    - Reload теперь полностью очищает Fading Door (numpad, wire, dupe)
    - RightClick открывает панель через net-сообщение (isFadingDoor не
      синхронизируется на клиент)
--------------------------------------------------------------------]]

TOOL.Category   = "Construction"
TOOL.Name       = "#FFD Fading Door (Фракции)"
TOOL.Command    = nil
TOOL.ConfigName = ""

-- ВАЖНО: здесь нельзя использовать FFD.ACCESS.PUBLIC и т.д.,
-- потому что на момент загрузки stool файла таблица FFD может
-- ещё не существовать (autorun загружается отдельно).
-- Все значения должны быть литеральными строками.
TOOL.ClientConVar = {
    key         = "0",
    swap        = "0",
    reversed    = "0",
    mat         = "sprites/heatwave",
    opensound   = "0",
    loopsound   = "0",
    closesound  = "0",
    accesstype  = "public",
    factions    = "[]",
    roles       = "[]",
    permanent   = "0",
}

if CLIENT then
    language.Add("tool.ffd_fading_door.name", "FFD Fading Door (Фракции)")
    language.Add("tool.ffd_fading_door.desc", "Делает проп исчезающей дверью с доступом по фракции/роли. ЛКМ — применить, ПКМ — настроить доступ, Перезарядка — снять.")
    language.Add("tool.ffd_fading_door.0", "ЛКМ: применить к пропу. ПКМ: открыть/настроить доступ. Перезарядка: снять.")
end

function TOOL:LeftClick(tr)
    if not tr.Entity or not tr.Entity:IsValid() then return false end
    if tr.Entity:IsPlayer() or tr.HitWorld then return false end
    if CLIENT then return true end

    local ent = tr.Entity
    local pl = self:GetOwner()
    if not IsValid(pl) then return false end

    -- Проверяем, что FFD загружен
    if not FFD or not FFD.ApplyDoorConfig then
        pl:ChatPrint("[FFD] Ошибка: система FFD не загружена.")
        return false
    end

    local phys = ent:GetPhysicsObject()
    local canDisableMotion = false
    if IsValid(phys) then
        local motionEnabled = phys:IsMotionEnabled()
        phys:EnableMotion(not motionEnabled)
        canDisableMotion = motionEnabled ~= phys:IsMotionEnabled()
        phys:EnableMotion(motionEnabled)
    end

    local stuff = {
        key                 = self:GetClientNumber("key"),
        toggle              = self:GetClientNumber("swap") == 1,
        reversed            = self:GetClientNumber("reversed") == 1,
        CanDisableMotion    = canDisableMotion,
        DoorMaterial        = self:GetClientInfo("mat"),
        DoorOpenSound       = self:GetClientNumber("opensound"),
        DoorLoopSound       = self:GetClientNumber("loopsound"),
        DoorCloseSound      = self:GetClientNumber("closesound"),
    }

    local jsonOk, jsonFactions = pcall(util.JSONToTable, self:GetClientInfo("factions"))
    local factions = (jsonOk and istable(jsonFactions)) and jsonFactions or {}
    local jsonOk2, jsonRoles = pcall(util.JSONToTable, self:GetClientInfo("roles"))
    local roles = (jsonOk2 and istable(jsonRoles)) and jsonRoles or {}

    local access = {
        accessType = self:GetClientInfo("accesstype"),
        factions = factions,
        roles = roles,
    }

    local applied = FFD.ApplyDoorConfig(ent, stuff, access, pl)
    if not applied then return false end

    if self:GetClientNumber("permanent") == 1 then
        local savedOk, saveErr = FFD.SaveDoor(pl, ent)
        pl:ChatPrint(savedOk and "[FFD] Дверь сохранена навсегда на карте." or ("[FFD] Не удалось сохранить: " .. tostring(saveErr)))
    end

    local accessLabel = "public"
    if FFD.ACCESS_LABELS then
        accessLabel = FFD.ACCESS_LABELS[access.accessType] or access.accessType
    end
    pl:ChatPrint("[FFD] Fading Door применена. Доступ: " .. accessLabel)
    return true
end

function TOOL:RightClick(tr)
    if not tr.Entity or not tr.Entity:IsValid() then return false end
    if tr.Entity:IsPlayer() or tr.HitWorld then return false end

    local ent = tr.Entity

    if CLIENT then
        -- Отправляем запрос серверу на открытие панели доступа.
        -- Мы не можем проверить ent.isFadingDoor на клиенте, т.к. это
        -- серверное поле. Сервер проверит и отправит ответ.
        net.Start("FFD_OpenAccessEditor")
        net.WriteEntity(ent)
        net.SendToServer()
        return true
    end

    -- На сервере: проверяем и отправляем клиенту команду открыть панель
    if ent.isFadingDoor or ent:GetClass() == "ffd_keypad" then
        local pl = self:GetOwner()
        if IsValid(pl) then
            net.Start("FFD_OpenAccessEditor")
            net.WriteEntity(ent)
            net.Send(pl)
        end
    end

    return true
end

function TOOL:Reload(tr)
    if not tr.Entity or not tr.Entity:IsValid() then return false end
    if tr.Entity:IsPlayer() or tr.HitWorld then return false end
    if CLIENT then return true end

    local ent = tr.Entity
    local pl = self:GetOwner()
    if not IsValid(pl) then return false end

    if not FFD or not FFD.RemoveFadingDoor then
        pl:ChatPrint("[FFD] Ошибка: система FFD не загружена.")
        return false
    end

    -- Случай 1: Нормальная Fading Door
    if ent.isFadingDoor then
        -- Убираем сохранение из БД, если было
        if ent.FFDSavedID then
            FFD.UnsaveDoor(pl, ent)
        end

        -- Полная очистка Fading Door (numpad, wire, dupe, звуки)
        FFD.RemoveFadingDoor(ent)

        pl:ChatPrint("[FFD] Fading Door полностью снята с пропа.")
        return true
    end

    -- Случай 2: "Призрачный" проп — имеет FFDSavedID или FFDManaged,
    -- но isFadingDoor не установлен (сломанное восстановление из старой версии)
    if ent.FFDSavedID or ent.FFDManaged or ent.FFDCreatedByRestore then
        FFD.ForceRemoveDoor(pl, ent)
        return true
    end

    -- Случай 3: Проп вообще не связан с FFD — пробуем удалить как обычный
    -- (на случай если это "мёртвый" проп без меток, созданный старым кодом)
    -- Суперадмин может использовать ffd_remove_aim для принудительного удаления
    pl:ChatPrint("[FFD] Этот проп не является Fading Door. Используйте консольную команду 'ffd_remove_aim' для принудительного удаления.")
    return false
end

if CLIENT then
    function TOOL.BuildCPanel(panel)
        panel:AddControl("Header", { Text = "#tool.ffd_fading_door.name", Description = "#tool.ffd_fading_door.desc" })

        panel:AddControl("Slider", { Label = "Numpad клавиша", Command = "ffd_fading_door_key", Type = "Integer", Min = 0, Max = 9 })
        panel:CheckBox("Переключатель (toggle)", "ffd_fading_door_swap")
        panel:CheckBox("Инвертировать (открыта по умолчанию)", "ffd_fading_door_reversed")

        panel:AddControl("Header", { Text = "Доступ (фракции)" })

        local accessCombo = vgui.Create("DComboBox", panel)
        accessCombo:SetValue("Публичный (все)")
        -- Безопасная проверка FFD.ACCESS_LABELS
        if FFD and FFD.ACCESS_LABELS then
            for accessType, label in pairs(FFD.ACCESS_LABELS) do
                accessCombo:AddChoice(label, accessType)
            end
        else
            accessCombo:AddChoice("Публичный (все)", "public")
            accessCombo:AddChoice("По фракции", "faction")
            accessCombo:AddChoice("Фракция + роль", "faction_role")
            accessCombo:AddChoice("Только суперадмин", "superadmin")
        end
        accessCombo.OnSelect = function(_, _, _, data)
            RunConsoleCommand("ffd_fading_door_accesstype", data)
        end
        panel:AddItem(accessCombo)

        local factionList = vgui.Create("DPanelList", panel)
        factionList:SetTall(160)
        factionList:EnableVerticalScrollbar(true)
        panel:AddItem(factionList)

        local function rebuildFactions()
            factionList:Clear(true)
            local selectedFactions = {}
            local convar = GetConVar("ffd_fading_door_factions")
            if convar then
                local jsonOk, decoded = pcall(util.JSONToTable, convar:GetString())
                if jsonOk and istable(decoded) then selectedFactions = decoded end
            end

            local clientFactions = (FFD and FFD.ClientFactions) or {}
            for _, f in ipairs(clientFactions) do
                local box = vgui.Create("DCheckBoxLabel")
                box:SetText(f.name)
                box:SizeToContents()
                box:SetValue(table.HasValue(selectedFactions, f.name))
                box.OnChange = function(_, val)
                    local cv = GetConVar("ffd_fading_door_factions")
                    local curStr = cv and cv:GetString() or "[]"
                    local jsonOk2, cur = pcall(util.JSONToTable, curStr)
                    cur = (jsonOk2 and istable(cur)) and cur or {}
                    if val then
                        if not table.HasValue(cur, f.name) then cur[#cur + 1] = f.name end
                    else
                        table.RemoveByValue(cur, f.name)
                    end
                    RunConsoleCommand("ffd_fading_door_factions", util.TableToJSON(cur))
                end
                factionList:AddItem(box)
            end
        end

        if FFD and FFD.RequestFactions then
            FFD.RequestFactions()
        end
        timer.Simple(0.5, rebuildFactions)
        hook.Add("FFD_FactionsUpdated", panel, rebuildFactions)

        panel:AddControl("Header", { Text = "Постоянное сохранение" })
        panel:CheckBox("Сохранить навсегда на карте (только суперадмин)", "ffd_fading_door_permanent")

        panel:AddControl("Header", { Text = "Материал / звуки" })
        panel:AddControl("TextBox", { Label = "Материал двери", Command = "ffd_fading_door_mat" })
    end
end