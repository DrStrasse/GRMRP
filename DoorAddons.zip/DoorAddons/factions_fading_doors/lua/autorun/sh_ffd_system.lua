--[[--------------------------------------------------------------------
    FFD — Fading Door + Keypad, привязанные к системе фракций
    Главный shared-файл. Лежит в lua/autorun, поэтому движок сам
    отправляет его клиенту — отдельный AddCSLuaFile не нужен.

    Исправлено:
    - Добавлена сетевая строка FFD_OpenAccessEditor
    - Улучшена обработка ошибок в GetPlayerFactionRole
--------------------------------------------------------------------]]

FFD = FFD or {}
FFD.VERSION = "1.1.0"

-- ─── Типы доступа для дверей / кейпадов ──────────────────────────
FFD.ACCESS = {
    PUBLIC       = "public",       -- открыто всем
    FACTION      = "faction",      -- только участники выбранных фракций
    FACTION_ROLE = "faction_role", -- фракция + конкретная(ые) роль(и)
    SUPERADMIN   = "superadmin",   -- только суперадмины
}

FFD.ACCESS_LABELS = {
    [FFD.ACCESS.PUBLIC]       = "Публичный (все)",
    [FFD.ACCESS.FACTION]      = "По фракции",
    [FFD.ACCESS.FACTION_ROLE] = "Фракция + роль",
    [FFD.ACCESS.SUPERADMIN]   = "Только суперадмин",
}

-- Модель кейпада по умолчанию (можно сменить в настройках инструмента)
FFD.DEFAULT_KEYPAD_MODEL = "models/props_lab/keypad.mdl"

-- Радиус, в котором инструмент кейпада ищет ближайшую Fading Door
FFD.KEYPAD_LINK_RADIUS = 180

-- ─── Стабильный ID пропа (совпадает по формату с DS.DoorID) ──────
-- mapname_h{hammerID} если проп из карты, иначе mapname_e{entIndex}
function FFD.StableID(ent)
    if not IsValid(ent) then return nil end
    local hid = ent.MapCreationID and ent:MapCreationID() or 0
    if hid and hid > 0 then
        return game.GetMap() .. "_h" .. hid
    end
    return game.GetMap() .. "_e" .. ent:EntIndex()
end

-- ─── Найти фракцию/роль игрока через глобальную таблицу Factions ──
-- (она объявляется в аддоне факций пользователя: factions.lua)
function FFD.GetPlayerFactionRole(ply)
    if not IsValid(ply) then return nil, nil end
    if not istable(Factions) then return nil, nil end

    local steam = ply:SteamID64() or ply:SteamID()
    local steam2 = ply:SteamID()

    for name, f in pairs(Factions) do
        if istable(f) and istable(f.Members) then
            local m = f.Members[steam2] or f.Members[steam]
            if m then
                return name, istable(m) and m.Role or nil
            end
        end
    end
    return nil, nil
end

-- ─── Проверка доступа игрока к конфигу {accessType, factions, roles} ──
-- Суперадмины всегда проходят проверку (могут открыть любую дверь).
function FFD.CheckAccess(ply, cfg)
    if not IsValid(ply) then return false end
    if ply:IsSuperAdmin() then return true end

    cfg = cfg or {}
    local accessType = cfg.accessType or FFD.ACCESS.PUBLIC

    if accessType == FFD.ACCESS.PUBLIC then return true end
    if accessType == FFD.ACCESS.SUPERADMIN then return false end

    local pFaction, pRole = FFD.GetPlayerFactionRole(ply)
    if not pFaction then return false end

    if accessType == FFD.ACCESS.FACTION then
        return table.HasValue(cfg.factions or {}, pFaction)
    end

    if accessType == FFD.ACCESS.FACTION_ROLE then
        if not table.HasValue(cfg.factions or {}, pFaction) then return false end
        if not cfg.roles or #cfg.roles == 0 then return true end
        return table.HasValue(cfg.roles, pRole)
    end

    return false
end

-- ─── Список фракций + ролей в формате для UI ──────────────────────
-- Возвращает { {name=..., roles={...}}, ... } на основе глобальной Factions
function FFD.BuildFactionList()
    local out = {}
    if not istable(Factions) then return out end
    for name, f in pairs(Factions) do
        if istable(f) then
            local roles = {}
            if istable(f.Roles) then
                for _, r in ipairs(f.Roles) do
                    roles[#roles + 1] = istable(r) and (r.Name or r.name) or r
                end
            end
            out[#out + 1] = { name = name, roles = roles }
        end
    end
    table.sort(out, function(a, b) return a.name < b.name end)
    return out
end

-- ─── Сеть ──────────────────────────────────────────────────────────
if SERVER then
    util.AddNetworkString("FFD_RequestFactions")
    util.AddNetworkString("FFD_SyncFactions")
    util.AddNetworkString("FFD_KeypadUse")
    util.AddNetworkString("FFD_SaveDoor")
    util.AddNetworkString("FFD_SaveKeypad")
    util.AddNetworkString("FFD_UnsaveDoor")
    util.AddNetworkString("FFD_UnsaveKeypad")
    util.AddNetworkString("FFD_OpenAccessEditor")
    util.AddNetworkString("FFD_SetAccessConfig")
    util.AddNetworkString("FFD_Notify")

    AddCSLuaFile("ffd/cl_core.lua")
    AddCSLuaFile("ffd/cl_access_panel.lua")

    include("ffd/sv_core.lua")
end

if CLIENT then
    include("ffd/cl_core.lua")
    include("ffd/cl_access_panel.lua")
end