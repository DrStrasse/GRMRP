--[[--------------------------------------------------------------------
    FFD Keypad Patch v2.2 — Сохранение настроек доступа в БД
    - Добавлены колонки access_type, factions, roles в таблицу ffd_keypads
    - Переопределены FFD.SaveKeypad и FFD.UnsaveKeypad для работы с доступом
    - Восстановление доступа при загрузке карты
--------------------------------------------------------------------]]

if SERVER then
    -- ============================================================
    -- 1. МИГРАЦИЯ БД: добавляем колонки для хранения доступа
    -- ============================================================
    local function addColumnIfNotExists(tableName, colDef)
        local cols = sql.Query("PRAGMA table_info(" .. tableName .. ")")
        if not cols then return end
        local colName = colDef:match("^(%S+)")
        for _, row in ipairs(cols) do
            if row.name == colName then return end
        end
        sql.Query("ALTER TABLE " .. tableName .. " ADD COLUMN " .. colDef)
        print("[FFD] Добавлена колонка " .. colName .. " в " .. tableName)
    end

    hook.Add("Initialize", "FFD_KeypadPatch_MigrateDB", function()
        addColumnIfNotExists("ffd_keypads", "access_type TEXT DEFAULT 'public'")
        addColumnIfNotExists("ffd_keypads", "factions TEXT DEFAULT '[]'")
        addColumnIfNotExists("ffd_keypads", "roles TEXT DEFAULT '[]'")
    end)

    -- ============================================================
    -- 2. ПЕРЕОПРЕДЕЛЯЕМ FFD.SaveKeypad (с сохранением доступа)
    -- ============================================================
    local origSaveKeypad = FFD.SaveKeypad
    FFD.SaveKeypad = function(ply, keypadEnt)
        if not IsValid(keypadEnt) then return false, "Невалидный кейпад" end
        if not IsValid(ply) or not ply:IsSuperAdmin() then
            return false, "Требуются права суперадмина"
        end

        local doorEnt = keypadEnt:GetLinkedDoor()
        local doorId = IsValid(doorEnt) and (doorEnt.FFDSavedID or FFD.StableID(doorEnt)) or (keypadEnt.FFDLinkedDoorID or "")

        -- Получаем доступ кейпада (если есть переопределение, иначе пустой)
        local accessOverride = keypadEnt.FFDAccessOverride
        local accessType = accessOverride and accessOverride.accessType or "public"
        local factions = accessOverride and accessOverride.factions or {}
        local roles = accessOverride and accessOverride.roles or {}

        local id = keypadEnt.FFDSavedID or util.CRC(tostring(keypadEnt:GetPos()) .. tostring(SysTime()) .. tostring(math.random(1, 999999)))
        local pos, ang = keypadEnt:GetPos(), keypadEnt:GetAngles()

        sql.Query(string.format([[
            REPLACE INTO ffd_keypads
            (id, map, door_id, pos_x, pos_y, pos_z, ang_p, ang_y, ang_r, model, saved_by, saved_at,
             access_type, factions, roles)
            VALUES (%s, %s, %s, %f, %f, %f, %f, %f, %f, %s, %s, %d, %s, %s, %s)
        ]],
            sql.SQLStr(id), sql.SQLStr(game.GetMap()), sql.SQLStr(doorId),
            pos.x, pos.y, pos.z, ang.p, ang.y, ang.r,
            sql.SQLStr(keypadEnt:GetModel() or FFD.DEFAULT_KEYPAD_MODEL),
            sql.SQLStr(ply:SteamID()), os.time(),
            sql.SQLStr(accessType),
            sql.SQLStr(util.TableToJSON(factions)),
            sql.SQLStr(util.TableToJSON(roles))
        ))

        keypadEnt.FFDSavedID = id
        FFD.RestoredKeypadIDs[id] = true
        return true
    end

    -- ============================================================
    -- 3. ПЕРЕОПРЕДЕЛЯЕМ FFD.UnsaveKeypad (удаление записи)
    -- ============================================================
    local origUnsaveKeypad = FFD.UnsaveKeypad
    FFD.UnsaveKeypad = function(ply, keypadEnt)
        if not IsValid(keypadEnt) then return false, "Невалидный кейпад" end
        if not IsValid(ply) or not ply:IsSuperAdmin() then
            return false, "Требуются права суперадмина"
        end
        if not keypadEnt.FFDSavedID then
            return false, "Кейпад не был сохранён"
        end
        sql.Query("DELETE FROM ffd_keypads WHERE id = " .. sql.SQLStr(keypadEnt.FFDSavedID))
        FFD.RestoredKeypadIDs[keypadEnt.FFDSavedID] = nil
        keypadEnt.FFDSavedID = nil
        return true
    end

    -- ============================================================
    -- 4. ВОССТАНОВЛЕНИЕ ДОСТУПА КЕЙПАДОВ ИЗ БД
    -- ============================================================
    local function restoreKeypadAccess()
        local rows = sql.Query("SELECT * FROM ffd_keypads WHERE map = " .. sql.SQLStr(game.GetMap()))
        if not rows then return end

        local count = 0
        for _, row in ipairs(rows) do
            local id = row.id
            -- Ищем кейпад с таким FFDSavedID
            for _, ent in ipairs(ents.FindByClass("ffd_keypad")) do
                if IsValid(ent) and ent.FFDSavedID == id then
                    -- Восстанавливаем доступ
                    local accessType = row.access_type or "public"
                    local factions = util.JSONToTable(row.factions or "[]") or {}
                    local roles = util.JSONToTable(row.roles or "[]") or {}
                    ent.FFDAccessOverride = {
                        accessType = accessType,
                        factions = factions,
                        roles = roles,
                    }
                    ent:SetHasAccessOverride(true)
                    count = count + 1
                    break
                end
            end
        end
        print("[FFD] Восстановлен доступ для " .. count .. " кейпадов.")
    end

    -- Запускаем восстановление после того, как оригинальный код загрузит кейпады
    hook.Add("InitPostEntity", "FFD_KeypadPatch_RestoreAccess", function()
        timer.Simple(2, restoreKeypadAccess) -- Даём время на восстановление оригиналом
    end)

    -- ============================================================
    -- 5. ОСТАЛЬНЫЕ СЕТЕВЫЕ ОБРАБОТЧИКИ (из предыдущего патча)
    -- ============================================================
    util.AddNetworkString("FFD_Keypad_Link")
    util.AddNetworkString("FFD_Keypad_Delete")
    util.AddNetworkString("FFD_Keypad_GetDoors")

    net.Receive("FFD_Keypad_GetDoors", function(_, ply)
        if not ply:IsSuperAdmin() then return end
        local doorList = {}
        for _, ent in ipairs(ents.GetAll()) do
            if IsValid(ent) and ent.isFadingDoor then
                local id = ent.FFDSavedID or (FFD and FFD.StableID and FFD.StableID(ent)) or ""
                if id ~= "" then
                    table.insert(doorList, {
                        entIndex = ent:EntIndex(),
                        id = id,
                        model = ent:GetModel(),
                        pos = ent:GetPos(),
                    })
                end
            end
        end
        if DS and DS.DoorID then
            for _, ent in ipairs(ents.GetAll()) do
                if IsValid(ent) and DS.IsDoor(ent) then
                    local id = DS.DoorID(ent)
                    if id then
                        table.insert(doorList, {
                            entIndex = ent:EntIndex(),
                            id = id,
                            model = ent:GetModel(),
                            pos = ent:GetPos(),
                            isDS = true,
                        })
                    end
                end
            end
        end
        net.Start("FFD_Keypad_DoorsList")
        net.WriteTable(doorList)
        net.Send(ply)
    end)

    net.Receive("FFD_Keypad_Link", function(_, ply)
        if not ply:IsSuperAdmin() then return end
        local keypadEnt = net.ReadEntity()
        local doorEntIdx = net.ReadInt(32)
        if not IsValid(keypadEnt) or keypadEnt:GetClass() ~= "ffd_keypad" then
            ply:ChatPrint("[FFD] Неверный кейпад.")
            return
        end
        local doorEnt = Entity(doorEntIdx)
        if not IsValid(doorEnt) or (not doorEnt.isFadingDoor and not (DS and DS.IsDoor and DS.IsDoor(doorEnt))) then
            ply:ChatPrint("[FFD] Неверная дверь.")
            return
        end
        keypadEnt:SetLinkedDoor(doorEnt)
        keypadEnt.FFDLinkedDoorID = doorEnt.FFDSavedID or (FFD and FFD.StableID and FFD.StableID(doorEnt)) or ""
        keypadEnt._FFDPendingDoorLink = nil
        -- Сохраняем изменения в БД (с доступом, который уже есть)
        if keypadEnt.FFDSavedID then
            FFD.SaveKeypad(ply, keypadEnt)
        end
        ply:ChatPrint("[FFD] Кейпад привязан к двери.")
    end)

    net.Receive("FFD_Keypad_Delete", function(_, ply)
        if not ply:IsSuperAdmin() then return end
        local keypadEnt = net.ReadEntity()
        if not IsValid(keypadEnt) or keypadEnt:GetClass() ~= "ffd_keypad" then
            ply:ChatPrint("[FFD] Неверный кейпад.")
            return
        end
        if keypadEnt.FFDSavedID then
            FFD.UnsaveKeypad(ply, keypadEnt)
        end
        keypadEnt:Remove()
        ply:ChatPrint("[FFD] Кейпад удалён.")
    end)

    print("[FFD Keypad Patch] Серверная часть (с сохранением доступа) загружена.")
end

-- ============================================================
-- КЛИЕНТСКАЯ ЧАСТЬ (без изменений, из предыдущей версии)
-- ============================================================
if CLIENT then
    -- Принудительно устанавливаем режим "place" при загрузке
    RunConsoleCommand("ffd_keypad_mode", "place")

    local function buildPanel(ent)
        local frame = vgui.Create("DFrame")
        frame:SetSize(400, 500)
        frame:Center()
        frame:SetTitle("FFD — Настройка доступа (кейпад)")
        frame:MakePopup()

        local scroll = vgui.Create("DScrollPanel", frame)
        scroll:Dock(FILL)
        scroll:DockMargin(4, 4, 4, 40)

        -- Тип доступа
        local accessLabel = vgui.Create("DLabel", scroll)
        accessLabel:SetText("Тип доступа:")
        accessLabel:SetDark(true)
        accessLabel:Dock(TOP)
        accessLabel:DockMargin(4, 4, 4, 2)

        local accessCombo = vgui.Create("DComboBox", scroll)
        accessCombo:Dock(TOP)
        accessCombo:DockMargin(4, 2, 4, 8)
        for accessType, label in pairs(FFD.ACCESS_LABELS or {public="Публичный (все)", faction="По фракции", faction_role="Фракция+роль", superadmin="Только суперадмин"}) do
            accessCombo:AddChoice(label, accessType)
        end

        -- Текущий доступ, если есть
        local currentAccess = ent.FFDAccessOverride or ent.FFDAccess
        if currentAccess then
            for i, choice in ipairs(accessCombo:GetItems()) do
                if choice.data == currentAccess.accessType then
                    accessCombo:ChooseOptionID(i)
                    break
                end
            end
        end

        -- Фракции
        local factionLabel = vgui.Create("DLabel", scroll)
        factionLabel:SetText("Фракции и роли:")
        factionLabel:SetDark(true)
        factionLabel:Dock(TOP)
        factionLabel:DockMargin(4, 4, 4, 2)

        local factionContainer = vgui.Create("DPanel", scroll)
        factionContainer:Dock(TOP)
        factionContainer:DockMargin(4, 2, 4, 4)
        factionContainer:SetTall(200)

        local function buildChecklist()
            factionContainer:Clear()
            local factions = FFD.ClientFactions or {}
            local selectedFactions = {}
            if currentAccess and currentAccess.factions then
                selectedFactions = currentAccess.factions
            end
            for _, f in ipairs(factions) do
                local box = vgui.Create("DCheckBoxLabel", factionContainer)
                box:SetText(f.name)
                box:Dock(TOP)
                box:DockMargin(4, 2, 4, 2)
                box:SetValue(table.HasValue(selectedFactions, f.name))
                box._faction = f.name
            end
        end
        buildChecklist()

        -- Кнопка "Применить"
        local saveBtn = vgui.Create("DButton", frame)
        saveBtn:SetText("Применить")
        saveBtn:Dock(BOTTOM)
        saveBtn:DockMargin(4, 4, 4, 4)
        saveBtn.DoClick = function()
            local _, accessType = accessCombo:GetSelected()
            accessType = accessType or "public"
            local factions = {}
            for _, child in ipairs(factionContainer:GetChildren()) do
                if IsValid(child) and child.GetChecked and child:GetChecked() then
                    table.insert(factions, child._faction)
                end
            end
            net.Start("FFD_SetAccessConfig")
            net.WriteEntity(ent)
            net.WriteString(accessType)
            net.WriteString(util.TableToJSON(factions))
            net.WriteString(util.TableToJSON({})) -- roles
            net.SendToServer()
            frame:Close()
            notification.AddLegacy("Настройки доступа применены", NOTIFY_GENERIC, 3)
        end

        -- Кнопки управления
        local btnPanel = vgui.Create("DPanel", frame)
        btnPanel:Dock(BOTTOM)
        btnPanel:SetTall(40)
        btnPanel:DockMargin(4, 4, 4, 4)
        btnPanel:SetPaintBackground(false)

        local btnLink = vgui.Create("DButton", btnPanel)
        btnLink:Dock(LEFT)
        btnLink:SetWide(150)
        btnLink:SetText("Привязать к двери...")
        btnLink:SetFont("DermaDefault")
        btnLink:SetTextColor(Color(255, 255, 255))
        btnLink.Paint = function(s, w, h)
            draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(40, 100, 200) or Color(30, 70, 150))
        end
        btnLink.DoClick = function()
            net.Start("FFD_Keypad_GetDoors")
            net.SendToServer()

            local waitFrame = vgui.Create("DFrame")
            waitFrame:SetSize(400, 300)
            waitFrame:Center()
            waitFrame:SetTitle("Выбор двери")
            waitFrame:MakePopup()

            local loadingLbl = vgui.Create("DLabel", waitFrame)
            loadingLbl:SetText("Загрузка списка дверей...")
            loadingLbl:SetPos(10, 50)
            loadingLbl:SetSize(380, 30)
            loadingLbl:SetFont("DermaDefault")
            loadingLbl:SetContentAlignment(5)

            local listView = vgui.Create("DListView", waitFrame)
            listView:SetPos(10, 90)
            listView:SetSize(380, 160)
            listView:AddColumn("Модель"):SetWidth(200)
            listView:AddColumn("ID"):SetWidth(100)
            listView:AddColumn("Позиция"):SetWidth(80)

            local recv = function()
                local data = net.ReadTable() or {}
                listView:Clear()
                for _, door in ipairs(data) do
                    local posStr = string.format("%.0f,%.0f,%.0f", door.pos.x, door.pos.y, door.pos.z)
                    local line = listView:AddLine(door.model or "?", door.id or "?", posStr)
                    line._doorIdx = door.entIndex
                end
                if #data == 0 then
                    listView:AddLine("Нет доступных дверей", "", "")
                end
                loadingLbl:Remove()
            end
            net.Receive("FFD_Keypad_DoorsList", recv)

            local btnOk = vgui.Create("DButton", waitFrame)
            btnOk:SetPos(10, 260)
            btnOk:SetSize(180, 30)
            btnOk:SetText("Привязать")
            btnOk.Paint = function(s, w, h)
                draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(40, 160, 80) or Color(30, 130, 60))
            end
            btnOk.DoClick = function()
                local line = listView:GetSelectedLine()
                if not IsValid(line) or not line._doorIdx then
                    notification.AddLegacy("Выберите дверь", NOTIFY_ERROR, 3)
                    return
                end
                net.Start("FFD_Keypad_Link")
                net.WriteEntity(ent)
                net.WriteInt(line._doorIdx, 32)
                net.SendToServer()
                waitFrame:Close()
                frame:Close()
                notification.AddLegacy("Запрос на привязку отправлен", NOTIFY_GENERIC, 3)
            end

            local btnCancel = vgui.Create("DButton", waitFrame)
            btnCancel:SetPos(210, 260)
            btnCancel:SetSize(180, 30)
            btnCancel:SetText("Отмена")
            btnCancel.Paint = function(s, w, h)
                draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(180, 50, 40) or Color(130, 30, 30))
            end
            btnCancel.DoClick = function()
                waitFrame:Close()
            end
        end

        local btnDelete = vgui.Create("DButton", btnPanel)
        btnDelete:Dock(LEFT)
        btnDelete:SetWide(150)
        btnDelete:DockMargin(10, 0, 0, 0)
        btnDelete:SetText("Удалить кейпад")
        btnDelete:SetFont("DermaDefault")
        btnDelete:SetTextColor(Color(255, 255, 255))
        btnDelete.Paint = function(s, w, h)
            draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(200, 60, 50) or Color(160, 40, 30))
        end
        btnDelete.DoClick = function()
            Derma_Query("Удалить этот кейпад? Это действие необратимо.", "Подтверждение",
                "Удалить", function()
                    net.Start("FFD_Keypad_Delete")
                    net.WriteEntity(ent)
                    net.SendToServer()
                    frame:Close()
                end,
                "Отмена", function() end
            )
        end

        local btnRefresh = vgui.Create("DButton", btnPanel)
        btnRefresh:Dock(RIGHT)
        btnRefresh:SetWide(100)
        btnRefresh:SetText("Обновить")
        btnRefresh:SetFont("DermaDefault")
        btnRefresh:SetTextColor(Color(255, 255, 255))
        btnRefresh.Paint = function(s, w, h)
            draw.RoundedBox(4, 0, 0, w, h, s:IsHovered() and Color(80, 80, 100) or Color(60, 60, 80))
        end
        btnRefresh.DoClick = function()
            frame:Close()
            FFD.OpenAccessEditor(ent)
        end
    end

    local function initPatch()
        if not FFD then
            timer.Simple(0.5, initPatch)
            return
        end

        print("[FFD Keypad Patch] Клиентская инициализация начата.")

        -- Полностью переопределяем OpenAccessEditor (без вызова оригинала)
        function FFD.OpenAccessEditor(ent)
            if not IsValid(ent) then return end
            if not LocalPlayer():IsSuperAdmin() then
                notification.AddLegacy("Только суперадмин может настраивать кейпады.", NOTIFY_ERROR, 3)
                return
            end
            buildPanel(ent)
        end

        -- Перехватываем net-сообщение
        net.Receive("FFD_OpenAccessEditor", function()
            local ent = net.ReadEntity()
            if IsValid(ent) then
                FFD.OpenAccessEditor(ent)
            end
        end)

        -- Переопределяем RightClick инструмента ffd_keypad
        local function patchTool()
            local tool = GAMEMODE and GAMEMODE.Tools and GAMEMODE.Tools["ffd_keypad"]
            if tool and tool.RightClick then
                local origRightClick = tool.RightClick
                tool.RightClick = function(self, tr)
                    if IsValid(tr.Entity) and tr.Entity:GetClass() == "ffd_keypad" then
                        if LocalPlayer():IsSuperAdmin() then
                            FFD.OpenAccessEditor(tr.Entity)
                            return true
                        end
                    end
                    if origRightClick then
                        return origRightClick(self, tr)
                    end
                    return false
                end
                print("[FFD Keypad Patch] Инструмент ffd_keypad переопределён.")
                return true
            end
            return false
        end

        if not patchTool() then
            timer.Simple(0.5, function()
                if not patchTool() then
                    print("[FFD Keypad Patch] Не удалось переопределить инструмент. Используйте консольную команду ffd_keypad_edit.")
                end
            end)
        end

        concommand.Add("ffd_keypad_edit", function()
            if not LocalPlayer():IsSuperAdmin() then return end
            local tr = LocalPlayer():GetEyeTrace()
            if IsValid(tr.Entity) and tr.Entity:GetClass() == "ffd_keypad" then
                FFD.OpenAccessEditor(tr.Entity)
            else
                notification.AddLegacy("Наведитесь на кейпад", NOTIFY_ERROR, 3)
            end
        end)

        print("[FFD Keypad Patch] Клиентская часть загружена.")
    end

    hook.Add("InitPostEntity", "FFDKeypadPatchInit", function()
        timer.Simple(0.1, initPatch)
    end)
end