--[[--------------------------------------------------------------------
    FFD — серверное ядро: SQLite-хранение, применение конфигов,
    восстановление дверей/кейпадов при загрузке карты.

    Исправлено:
    - Восстановление дверей через prop_physics (не fading_door)
    - Поиск существующих пропов по MapCreationID/позиции
    - Защита от дублирования при рестарте
    - Оптимизация FindNearestDoor через ents.FindInSphere
    - Полная очистка Fading Door через FADING_DOOR.onRemove
    - Синхронизация кейпадов с дверями через повторный поиск
    - Консольные команды для очистки старых/сломанных пропов
    - Reload работает и с "призрачными" пропами (FFDSavedID без isFadingDoor)
--------------------------------------------------------------------]]

FFD.Cache = FFD.Cache or {
    doors   = {},   -- [stableID] = cfg
    keypads = {},   -- array of { id, doorId, pos, ang, model, ent }
}

-- Множество уже восстановленных ID (защита от дублирования)
FFD.RestoredDoorIDs = FFD.RestoredDoorIDs or {}
FFD.RestoredKeypadIDs = FFD.RestoredKeypadIDs or {}

local function q(str)
    return sql.SQLStr(str or "")
end

-- ─── Вспомогательная функция для добавления колонок, если их нет ──
local function addColumnIfNotExists(tableName, colDef)
    local cols = sql.Query("PRAGMA table_info(" .. tableName .. ")")
    if not cols then return end
    local colName = colDef:match("^(%S+)")
    for _, row in ipairs(cols) do
        if row.name == colName then return end
    end
    sql.Query("ALTER TABLE " .. tableName .. " ADD COLUMN " .. colDef)
end

function FFD.EnsureDB()
    sql.Query([[
        CREATE TABLE IF NOT EXISTS ffd_doors (
            id TEXT PRIMARY KEY,
            map TEXT,
            fkey INTEGER DEFAULT 0,
            toggle INTEGER DEFAULT 0,
            reversed INTEGER DEFAULT 0,
            can_disable_motion INTEGER DEFAULT 0,
            material TEXT DEFAULT 'sprites/heatwave',
            open_sound INTEGER DEFAULT 0,
            loop_sound INTEGER DEFAULT 0,
            close_sound INTEGER DEFAULT 0,
            access_type TEXT DEFAULT 'public',
            factions TEXT DEFAULT '[]',
            roles TEXT DEFAULT '[]',
            saved_by TEXT DEFAULT '',
            saved_at INTEGER DEFAULT 0
        )
    ]])

    sql.Query([[
        CREATE TABLE IF NOT EXISTS ffd_keypads (
            id TEXT PRIMARY KEY,
            map TEXT,
            door_id TEXT,
            pos_x REAL, pos_y REAL, pos_z REAL,
            ang_p REAL, ang_y REAL, ang_r REAL,
            model TEXT DEFAULT 'models/props_lab/keypad.mdl',
            saved_by TEXT DEFAULT '',
            saved_at INTEGER DEFAULT 0
        )
    ]])

    -- Добавляем недостающие колонки для дверей (миграция)
    addColumnIfNotExists("ffd_doors", "model TEXT DEFAULT 'models/props_c17/door01.mdl'")
    addColumnIfNotExists("ffd_doors", "pos_x REAL DEFAULT 0")
    addColumnIfNotExists("ffd_doors", "pos_y REAL DEFAULT 0")
    addColumnIfNotExists("ffd_doors", "pos_z REAL DEFAULT 0")
    addColumnIfNotExists("ffd_doors", "ang_p REAL DEFAULT 0")
    addColumnIfNotExists("ffd_doors", "ang_y REAL DEFAULT 0")
    addColumnIfNotExists("ffd_doors", "ang_r REAL DEFAULT 0")
end
hook.Add("Initialize", "FFD_EnsureDB", FFD.EnsureDB)

local function decodeArr(str)
    local ok, res = pcall(util.JSONToTable, str or "[]")
    if ok and istable(res) then return res end
    return {}
end

local function encodeArr(t)
    return util.TableToJSON(t or {})
end

-- ─── Применить конфиг фейд-двери к энтити (визуал + доступ) ───────
-- stuff: { key, toggle, reversed, CanDisableMotion, DoorMaterial,
--          DoorOpenSound, DoorLoopSound, DoorCloseSound }
-- accessCfg: { accessType, factions, roles }
function FFD.ApplyDoorConfig(ent, stuff, accessCfg, pl)
    if not IsValid(ent) then return false end

    local modifier = duplicator.EntityModifiers and duplicator.EntityModifiers["Fading Door"]
    if not modifier then
        if IsValid(pl) then
            pl:ChatPrint("[FFD] Не найден Fading Door STOOL (duplicator modifier). Установите его на сервер.")
        end
        return false
    end

    modifier(pl, ent, stuff)

    ent.FFDAccess = accessCfg or { accessType = FFD.ACCESS.PUBLIC, factions = {}, roles = {} }
    ent.FFDStuff = stuff
    -- Помечаем, что этот проп управляется FFD (для идентификации)
    ent.FFDManaged = true

    return true
end

-- ─── Полное снятие Fading Door с пропа ───────────────────────────
-- Использует экспортированную функцию из оригинального тула, если доступна
function FFD.RemoveFadingDoor(ent)
    if not IsValid(ent) then return end

    -- Если проп является Fading Door — снимаем модификатор
    if ent.isFadingDoor then
        -- Используем экспортированную функцию из fading_door.lua
        if FADING_DOOR and FADING_DOOR.onRemove then
            FADING_DOOR.onRemove(ent)
        else
            -- Fallback: ручная очистка
            if ent.fadeDeactivate then ent:fadeDeactivate() end
            if ent.fadeUpNum then numpad.Remove(ent.fadeUpNum) end
            if ent.fadeDownNum then numpad.Remove(ent.fadeDownNum) end
            ent.isFadingDoor = nil
            ent.fadeActive = nil
            ent.fadeMaterial = nil
            ent.fadeToggle = nil
            ent.fadeDoorMaterial = nil
            ent.fadeMoveable = nil
            ent.fadeCanDisableMotion = nil
            ent.fadeDoorOpenSound = nil
            ent.fadeDoorCloseSound = nil
            ent.fadeDoorLoopSound = nil
            ent.fadeDeactivate = nil
            ent.fadeActivate = nil
            ent.fadeUpNum = nil
            ent.fadeDownNum = nil
            ent.fadeToggleActive = nil
            ent.fadeReversed = nil
            ent.fadeKey = nil
            if ent.FadeDoorSound then ent.FadeDoorSound:Stop() end
            ent.FadeDoorSound = nil
            if IsValid(ent.FadingDoorDummy) then ent.FadingDoorDummy:Remove() end
            ent.FadingDoorDummy = nil
            duplicator.ClearEntityModifier(ent, "Fading Door")
        end
    end

    -- Очистка FFD-специфичных данных
    ent.FFDAccess = nil
    ent.FFDStuff = nil
    ent.FFDManaged = nil
end

-- ─── Принудительное удаление пропа (для "призрачных" дверей) ──────
-- Удаляет проп из мира И из БД. Работает даже если isFadingDoor == nil.
function FFD.ForceRemoveDoor(pl, ent)
    if not IsValid(ent) then return false, "Невалидный проп" end

    -- Убираем из БД
    local id = ent.FFDSavedID
    if id then
        sql.Query("DELETE FROM ffd_doors WHERE id = " .. q(id))
        FFD.Cache.doors[id] = nil
        FFD.RestoredDoorIDs[id] = nil
    end

    -- Снимаем Fading Door если есть
    FFD.RemoveFadingDoor(ent)

    -- Удаляем проп с карты (если он был создан FFD, а не является частью карты)
    local hid = ent.MapCreationID and ent:MapCreationID() or 0
    if hid == 0 or ent.FFDCreatedByRestore then
        -- Это динамический проп (не часть карты) — можно удалить
        ent:Remove()
        if IsValid(pl) then
            pl:ChatPrint("[FFD] Проп удалён с карты и из базы данных.")
        end
    else
        -- Это проп карты — не удаляем, только снимаем модификатор
        ent.FFDSavedID = nil
        if IsValid(pl) then
            pl:ChatPrint("[FFD] Fading Door снята. Проп карты оставлен на месте.")
        end
    end

    return true
end

-- ─── Сохранить дверь навсегда (только суперадмин) ─────────────────
function FFD.SaveDoor(pl, ent)
    if not IsValid(pl) or not pl:IsSuperAdmin() then return false, "Требуются права суперадмина" end
    if not IsValid(ent) or not ent.isFadingDoor then return false, "Проп не является Fading Door" end

    -- Генерируем стабильный ID, если его ещё нет
    local id = ent.FFDSavedID
    if not id then
        local hid = ent.MapCreationID and ent:MapCreationID() or 0
        if hid > 0 then
            id = game.GetMap() .. "_h" .. hid
        else
            id = util.CRC(tostring(ent:GetPos()) .. tostring(SysTime()) .. tostring(math.random(1, 999999)))
        end
        ent.FFDSavedID = id
    end

    local stuff = ent.FFDStuff or {
        key = ent.fadeKey or 0,
        toggle = ent.fadeToggle or false,
        reversed = ent.fadeReversed or false,
        CanDisableMotion = ent.fadeCanDisableMotion or false,
        DoorMaterial = ent.fadeDoorMaterial or "sprites/heatwave",
        DoorOpenSound = ent.fadeDoorOpenSound or 0,
        DoorLoopSound = ent.fadeDoorLoopSound or 0,
        DoorCloseSound = ent.fadeDoorCloseSound or 0,
    }
    local access = ent.FFDAccess or { accessType = FFD.ACCESS.PUBLIC, factions = {}, roles = {} }

    local pos = ent:GetPos()
    local ang = ent:GetAngles()
    local model = ent:GetModel() or "models/props_c17/door01.mdl"

    sql.Query(string.format([[
        REPLACE INTO ffd_doors
        (id, map, fkey, toggle, reversed, can_disable_motion, material,
         open_sound, loop_sound, close_sound, access_type, factions, roles,
         saved_by, saved_at, model, pos_x, pos_y, pos_z, ang_p, ang_y, ang_r)
        VALUES (%s, %s, %d, %d, %d, %d, %s, %d, %d, %d, %s, %s, %s, %s, %d, %s, %f, %f, %f, %f, %f, %f)
    ]],
        q(id), q(game.GetMap()),
        tonumber(stuff.key) or 0,
        stuff.toggle and 1 or 0,
        stuff.reversed and 1 or 0,
        stuff.CanDisableMotion and 1 or 0,
        q(stuff.DoorMaterial or "sprites/heatwave"),
        tonumber(stuff.DoorOpenSound) or 0,
        tonumber(stuff.DoorLoopSound) or 0,
        tonumber(stuff.DoorCloseSound) or 0,
        q(access.accessType or FFD.ACCESS.PUBLIC),
        q(encodeArr(access.factions)),
        q(encodeArr(access.roles)),
        q(pl:SteamID()),
        os.time(),
        q(model),
        pos.x, pos.y, pos.z,
        ang.p, ang.y, ang.r
    ))

    ent.FFDSavedID = id
    FFD.RestoredDoorIDs[id] = true
    FFD.Cache.doors[id] = { stuff = stuff, access = access }
    return true
end

function FFD.UnsaveDoor(pl, ent)
    if not IsValid(pl) or not pl:IsSuperAdmin() then return false, "Требуются права суперадмина" end
    if not IsValid(ent) then return false, "Невалидный проп" end
    local id = ent.FFDSavedID
    if not id then return false, "Дверь не сохранена" end
    sql.Query("DELETE FROM ffd_doors WHERE id = " .. q(id))
    FFD.Cache.doors[id] = nil
    FFD.RestoredDoorIDs[id] = nil
    ent.FFDSavedID = nil
    return true
end

-- ─── Сохранить кейпад навсегда (только суперадмин) ────────────────
function FFD.SaveKeypad(pl, keypadEnt)
    if not IsValid(pl) or not pl:IsSuperAdmin() then return false, "Требуются права суперадмина" end
    if not IsValid(keypadEnt) then return false, "Невалидный кейпад" end

    local doorEnt = keypadEnt:GetLinkedDoor()
    local doorId = IsValid(doorEnt) and (doorEnt.FFDSavedID or FFD.StableID(doorEnt)) or (keypadEnt.FFDLinkedDoorID or "")

    local id = keypadEnt.FFDSavedID or util.CRC(tostring(keypadEnt:GetPos()) .. tostring(SysTime()) .. tostring(math.random(1, 999999)))
    local pos, ang = keypadEnt:GetPos(), keypadEnt:GetAngles()

    sql.Query(string.format([[
        REPLACE INTO ffd_keypads
        (id, map, door_id, pos_x, pos_y, pos_z, ang_p, ang_y, ang_r, model, saved_by, saved_at)
        VALUES (%s, %s, %s, %f, %f, %f, %f, %f, %f, %s, %s, %d)
    ]],
        q(id), q(game.GetMap()), q(doorId),
        pos.x, pos.y, pos.z, ang.p, ang.y, ang.r,
        q(keypadEnt:GetModel() or FFD.DEFAULT_KEYPAD_MODEL),
        q(pl:SteamID()), os.time()
    ))

    keypadEnt.FFDSavedID = id
    FFD.RestoredKeypadIDs[id] = true
    return true
end

function FFD.UnsaveKeypad(pl, keypadEnt)
    if not IsValid(pl) or not pl:IsSuperAdmin() then return false, "Требуются права суперадмина" end
    if not IsValid(keypadEnt) or not keypadEnt.FFDSavedID then return false, "Кейпад не был сохранён" end
    sql.Query("DELETE FROM ffd_keypads WHERE id = " .. q(keypadEnt.FFDSavedID))
    FFD.RestoredKeypadIDs[keypadEnt.FFDSavedID] = nil
    keypadEnt.FFDSavedID = nil
    return true
end

-- ─── Найти ближайшую Fading Door рядом с позицией ─────────────────
-- Оптимизировано: используем ents.FindInSphere вместо перебора всех энтити
function FFD.FindNearestDoor(pos, radius)
    radius = radius or FFD.KEYPAD_LINK_RADIUS
    local best, bestDist = nil, radius * radius

    local nearby = ents.FindInSphere(pos, radius)
    for _, ent in ipairs(nearby) do
        if IsValid(ent) and ent.isFadingDoor then
            local d = ent:GetPos():DistToSqr(pos)
            if d <= bestDist then
                best, bestDist = ent, d
            end
        end
    end
    return best
end

-- ─── Найти ближайший кейпад рядом с позицией ──────────────────────
function FFD.FindNearestKeypad(pos, radius)
    radius = radius or 64
    local best, bestDist = nil, radius * radius
    for _, ent in ipairs(ents.FindByClass("ffd_keypad")) do
        if IsValid(ent) then
            local d = ent:GetPos():DistToSqr(pos)
            if d <= bestDist then
                best, bestDist = ent, d
            end
        end
    end
    return best
end

-- ─── Найти существующий проп на карте по MapCreationID или позиции ─
local function findExistingProp(row)
    local id = row.id
    local mapPrefix = game.GetMap() .. "_h"

    -- Если ID начинается с mapPrefix — это проп карты, ищем по MapCreationID
    if string.StartWith(id, mapPrefix) then
        local hammerID = tonumber(string.sub(id, #mapPrefix + 1))
        if hammerID and hammerID > 0 then
            for _, ent in ipairs(ents.GetAll()) do
                if IsValid(ent) and ent.MapCreationID and ent:MapCreationID() == hammerID then
                    return ent
                end
            end
        end
    end

    -- Поиск по позиции (с допуском 2 юнита) — для динамических пропов
    local savedPos = Vector(tonumber(row.pos_x) or 0, tonumber(row.pos_y) or 0, tonumber(row.pos_z) or 0)
    local nearby = ents.FindInSphere(savedPos, 2)
    for _, ent in ipairs(nearby) do
        if IsValid(ent) and not ent:IsPlayer() and not ent:IsNPC() then
            local model = ent:GetModel()
            if model and model == (row.model or "models/props_c17/door01.mdl") then
                return ent
            end
        end
    end

    -- Поиск среди уже помеченных FFDSavedID
    for _, ent in ipairs(ents.GetAll()) do
        if IsValid(ent) and ent.FFDSavedID == id then
            return ent
        end
    end

    return nil
end

-- ─── Восстановление при загрузке карты ────────────────────────────
local function restoreDoors()
    local rows = sql.Query("SELECT * FROM ffd_doors WHERE map = " .. q(game.GetMap()))
    if not rows then return end

    for _, row in ipairs(rows) do
        local id = row.id

        -- Защита от дублирования: не восстанавливаем, если уже восстановлено
        if FFD.RestoredDoorIDs[id] then continue end

        local ent = findExistingProp(row)

        if not IsValid(ent) then
            -- Создаём prop_physics (НЕ fading_door — такого класса нет)
            ent = ents.Create("prop_physics")
            if not IsValid(ent) then continue end

            ent:SetPos(Vector(tonumber(row.pos_x) or 0, tonumber(row.pos_y) or 0, tonumber(row.pos_z) or 0))
            ent:SetAngles(Angle(tonumber(row.ang_p) or 0, tonumber(row.ang_y) or 0, tonumber(row.ang_r) or 0))
            ent:SetModel(row.model or "models/props_c17/door01.mdl")
            ent:Spawn()
            ent:Activate()

            -- Заморозить физику
            local phys = ent:GetPhysicsObject()
            if IsValid(phys) then
                phys:EnableMotion(false)
            end

            -- Помечаем, что этот проп создан системой восстановления FFD
            ent.FFDCreatedByRestore = true
        end

        local stuff = {
            key = tonumber(row.fkey) or 0,
            toggle = row.toggle == "1",
            reversed = row.reversed == "1",
            CanDisableMotion = row.can_disable_motion == "1",
            DoorMaterial = row.material,
            DoorOpenSound = tonumber(row.open_sound) or 0,
            DoorLoopSound = tonumber(row.loop_sound) or 0,
            DoorCloseSound = tonumber(row.close_sound) or 0,
        }
        local access = {
            accessType = row.access_type,
            factions = decodeArr(row.factions),
            roles = decodeArr(row.roles),
        }
        FFD.ApplyDoorConfig(ent, stuff, access, nil)
        ent.FFDSavedID = id
        FFD.RestoredDoorIDs[id] = true
        FFD.Cache.doors[id] = { stuff = stuff, access = access }
    end
end

local function restoreKeypads()
    local rows = sql.Query("SELECT * FROM ffd_keypads WHERE map = " .. q(game.GetMap()))
    if not rows then return end

    for _, row in ipairs(rows) do
        local id = row.id

        -- Защита от дублирования
        if FFD.RestoredKeypadIDs[id] then continue end

        -- Проверяем, нет ли уже кейпада с этим ID на карте
        local alreadyExists = false
        for _, existing in ipairs(ents.FindByClass("ffd_keypad")) do
            if IsValid(existing) and existing.FFDSavedID == id then
                alreadyExists = true
                break
            end
        end
        if alreadyExists then
            FFD.RestoredKeypadIDs[id] = true
            continue
        end

        local ent = ents.Create("ffd_keypad")
        if IsValid(ent) then
            ent:SetPos(Vector(tonumber(row.pos_x) or 0, tonumber(row.pos_y) or 0, tonumber(row.pos_z) or 0))
            ent:SetAngles(Angle(tonumber(row.ang_p) or 0, tonumber(row.ang_y) or 0, tonumber(row.ang_r) or 0))
            ent:SetModel(row.model ~= "" and row.model or FFD.DEFAULT_KEYPAD_MODEL)
            ent:Spawn()
            ent:SetMoveType(MOVETYPE_NONE)
            ent:SetSolid(SOLID_VPHYSICS)
            ent.FFDSavedID = id
            ent.FFDLinkedDoorID = row.door_id
            ent.FFDCreatedByRestore = true

            -- Пытаемся привязать к двери сразу
            local linked = false
            for _, door in ipairs(ents.GetAll()) do
                if IsValid(door) and door.FFDSavedID == row.door_id then
                    ent:SetLinkedDoor(door)
                    linked = true
                    break
                end
            end

            -- Если дверь ещё не найдена — будет привязана через Think кейпада
            -- или через отложенную синхронизацию ниже
            if not linked then
                ent._FFDPendingDoorLink = row.door_id
            end

            FFD.RestoredKeypadIDs[id] = true
        end
    end
end

-- ─── Отложенная синхронизация кейпадов с дверями ──────────────────
local function syncKeypadsWithDoors()
    for _, keypad in ipairs(ents.FindByClass("ffd_keypad")) do
        if IsValid(keypad) and not IsValid(keypad:GetLinkedDoor()) then
            local doorId = keypad._FFDPendingDoorLink or keypad.FFDLinkedDoorID
            if doorId and doorId ~= "" then
                -- Ищем дверь по FFDSavedID
                for _, door in ipairs(ents.GetAll()) do
                    if IsValid(door) and door.FFDSavedID == doorId then
                        keypad:SetLinkedDoor(door)
                        keypad._FFDPendingDoorLink = nil
                        break
                    end
                end

                -- Если не нашли по ID — ищем ближайшую Fading Door
                if not IsValid(keypad:GetLinkedDoor()) then
                    local nearest = FFD.FindNearestDoor(keypad:GetPos(), FFD.KEYPAD_LINK_RADIUS)
                    if IsValid(nearest) then
                        keypad:SetLinkedDoor(nearest)
                        keypad._FFDPendingDoorLink = nil
                    end
                end
            end
        end
    end
end

hook.Add("InitPostEntity", "FFD_RestoreOnMapLoad", function()
    -- Сбрасываем трекеры при загрузке карты
    FFD.RestoredDoorIDs = {}
    FFD.RestoredKeypadIDs = {}

    timer.Simple(1, function()
        restoreDoors()
        restoreKeypads()

        -- Повторная синхронизация кейпадов через 3 сек
        timer.Simple(3, syncKeypadsWithDoors)
    end)
end)

-- ─── Защита от дублирования при changelevel / перезагрузке ────────
hook.Add("PreCleanupMap", "FFD_CleanupBeforeRestore", function()
    FFD.RestoredDoorIDs = {}
    FFD.RestoredKeypadIDs = {}
end)

-- ═══════════════════════════════════════════════════════════════════
-- ─── КОНСОЛЬНЫЕ КОМАНДЫ ДЛЯ УПРАВЛЕНИЯ (только суперадмин) ───────
-- ═══════════════════════════════════════════════════════════════════

-- ffd_cleanup — удаляет ВСЕ "призрачные" FFD-пропы (с FFDSavedID или
-- FFDManaged/FFDCreatedByRestore, но без isFadingDoor) и очищает БД для карты
concommand.Add("ffd_cleanup", function(pl)
    if IsValid(pl) and not pl:IsSuperAdmin() then
        pl:ChatPrint("[FFD] Требуются права суперадмина.")
        return
    end

    local removedDoors = 0
    local removedKeypads = 0
    local fixedDoors = 0

    -- Находим и удаляем "призрачные" пропы (FFDSavedID есть, но isFadingDoor нет)
    for _, ent in ipairs(ents.GetAll()) do
        if IsValid(ent) then
            if ent.FFDSavedID and not ent.isFadingDoor and ent:GetClass() ~= "ffd_keypad" then
                -- Это "призрачный" проп — удаляем
                local hid = ent.MapCreationID and ent:MapCreationID() or 0
                if hid == 0 or ent.FFDCreatedByRestore then
                    ent:Remove()
                    removedDoors = removedDoors + 1
                else
                    -- Проп карты — просто снимаем метку
                    ent.FFDSavedID = nil
                    ent.FFDManaged = nil
                    fixedDoors = fixedDoors + 1
                end
            end
        end
    end

    -- Удаляем все кейпады, которые не привязаны и помечены как созданные FFD
    for _, ent in ipairs(ents.FindByClass("ffd_keypad")) do
        if IsValid(ent) and ent.FFDCreatedByRestore and not IsValid(ent:GetLinkedDoor()) then
            ent:Remove()
            removedKeypads = removedKeypads + 1
        end
    end

    -- Очищаем БД для текущей карты
    sql.Query("DELETE FROM ffd_doors WHERE map = " .. q(game.GetMap()))
    sql.Query("DELETE FROM ffd_keypads WHERE map = " .. q(game.GetMap()))
    FFD.Cache.doors = {}
    FFD.RestoredDoorIDs = {}
    FFD.RestoredKeypadIDs = {}

    local msg = string.format("[FFD] Очистка завершена: удалено %d дверей, %d кейпадов, исправлено %d пропов карты. БД очищена.", removedDoors, removedKeypads, fixedDoors)
    if IsValid(pl) then
        pl:ChatPrint(msg)
    end
    print(msg)
end, nil, "Удалить все сохранённые FFD двери/кейпады с текущей карты и очистить БД")

-- ffd_remove_aim — удаляет проп, на который смотрит суперадмин
-- (работает даже если проп "призрачный" и не реагирует на инструменты)
concommand.Add("ffd_remove_aim", function(pl)
    if not IsValid(pl) or not pl:IsSuperAdmin() then
        if IsValid(pl) then pl:ChatPrint("[FFD] Требуются права суперадмина.") end
        return
    end

    local tr = pl:GetEyeTrace()
    local ent = tr.Entity

    if not IsValid(ent) then
        pl:ChatPrint("[FFD] Не найден проп в прицеле.")
        return
    end

    if ent:IsPlayer() or ent:IsNPC() then
        pl:ChatPrint("[FFD] Нельзя удалить игрока/NPC.")
        return
    end

    -- Удаляем из БД если есть
    if ent.FFDSavedID then
        sql.Query("DELETE FROM ffd_doors WHERE id = " .. q(ent.FFDSavedID))
        sql.Query("DELETE FROM ffd_keypads WHERE id = " .. q(ent.FFDSavedID))
        FFD.Cache.doors[ent.FFDSavedID] = nil
        FFD.RestoredDoorIDs[ent.FFDSavedID] = nil
        FFD.RestoredKeypadIDs[ent.FFDSavedID] = nil
    end

    -- Снимаем Fading Door если есть
    if ent.isFadingDoor then
        FFD.RemoveFadingDoor(ent)
    end

    -- Удаляем проп
    local className = ent:GetClass()
    local model = ent:GetModel() or "unknown"
    ent:Remove()

    pl:ChatPrint("[FFD] Удалён проп: " .. className .. " (" .. model .. ")")
end, nil, "Удалить проп в прицеле (включая призрачные FFD пропы)")

-- ffd_list — показать все сохранённые двери/кейпады в БД для текущей карты
concommand.Add("ffd_list", function(pl)
    if IsValid(pl) and not pl:IsSuperAdmin() then
        pl:ChatPrint("[FFD] Требуются права суперадмина.")
        return
    end

    local doors = sql.Query("SELECT id, model, pos_x, pos_y, pos_z FROM ffd_doors WHERE map = " .. q(game.GetMap()))
    local keypads = sql.Query("SELECT id, model, pos_x, pos_y, pos_z, door_id FROM ffd_keypads WHERE map = " .. q(game.GetMap()))

    local msg = "[FFD] === Сохранённые объекты на карте " .. game.GetMap() .. " ===\n"

    if doors then
        msg = msg .. "Двери (" .. #doors .. "):\n"
        for i, row in ipairs(doors) do
            local pos = string.format("(%.0f, %.0f, %.0f)", tonumber(row.pos_x) or 0, tonumber(row.pos_y) or 0, tonumber(row.pos_z) or 0)
            msg = msg .. "  " .. i .. ". ID=" .. row.id .. " Модель=" .. (row.model or "?") .. " Позиция=" .. pos .. "\n"
        end
    else
        msg = msg .. "Двери: нет\n"
    end

    if keypads then
        msg = msg .. "Кейпады (" .. #keypads .. "):\n"
        for i, row in ipairs(keypads) do
            local pos = string.format("(%.0f, %.0f, %.0f)", tonumber(row.pos_x) or 0, tonumber(row.pos_y) or 0, tonumber(row.pos_z) or 0)
            msg = msg .. "  " .. i .. ". ID=" .. row.id .. " Дверь=" .. (row.door_id or "?") .. " Позиция=" .. pos .. "\n"
        end
    else
        msg = msg .. "Кейпады: нет\n"
    end

    if IsValid(pl) then
        -- Разбиваем на строки для чата (чат имеет лимит)
        for line in msg:gmatch("[^\n]+") do
            pl:ChatPrint(line)
        end
    end
    print(msg)
end, nil, "Показать все сохранённые FFD объекты на текущей карте")

-- ffd_reset_db — ПОЛНАЯ очистка БД (все карты)
concommand.Add("ffd_reset_db", function(pl)
    if IsValid(pl) and not pl:IsSuperAdmin() then
        pl:ChatPrint("[FFD] Требуются права суперадмина.")
        return
    end

    sql.Query("DELETE FROM ffd_doors")
    sql.Query("DELETE FROM ffd_keypads")
    FFD.Cache.doors = {}
    FFD.RestoredDoorIDs = {}
    FFD.RestoredKeypadIDs = {}

    local msg = "[FFD] База данных полностью очищена (все карты)."
    if IsValid(pl) then pl:ChatPrint(msg) end
    print(msg)
end, nil, "Полная очистка БД FFD (все карты). Пропы на текущей карте останутся до рестарта.")

-- ═══════════════════════════════════════════════════════════════════
-- ─── СЕТЬ ─────────────────────────────────────────────────────────
-- ═══════════════════════════════════════════════════════════════════

-- ─── Сеть: синхронизация фракций для панелей инструмента ──────────
net.Receive("FFD_RequestFactions", function(len, ply)
    net.Start("FFD_SyncFactions")
    net.WriteTable(FFD.BuildFactionList())
    net.Send(ply)
end)

-- ─── Сеть: использование кейпада игроком ──────────────────────────
-- (заглушка, реальное переключение в ENT:Use)
net.Receive("FFD_KeypadUse", function(len, ply)
    net.ReadEntity()
end)

-- ─── Сеть: суперадмин сохраняет/убирает дверь ─────────────────────
net.Receive("FFD_SaveDoor", function(len, ply)
    local ent = net.ReadEntity()
    local ok, err = FFD.SaveDoor(ply, ent)
    ply:ChatPrint(ok and "[FFD] Дверь сохранена навсегда." or ("[FFD] Ошибка: " .. tostring(err)))
end)

net.Receive("FFD_UnsaveDoor", function(len, ply)
    local ent = net.ReadEntity()
    local ok, err = FFD.UnsaveDoor(ply, ent)
    ply:ChatPrint(ok and "[FFD] Постоянное сохранение двери убрано." or ("[FFD] Ошибка: " .. tostring(err)))
end)

net.Receive("FFD_SaveKeypad", function(len, ply)
    local ent = net.ReadEntity()
    local ok, err = FFD.SaveKeypad(ply, ent)
    ply:ChatPrint(ok and "[FFD] Кейпад сохранён навсегда." or ("[FFD] Ошибка: " .. tostring(err)))
end)

net.Receive("FFD_UnsaveKeypad", function(len, ply)
    local ent = net.ReadEntity()
    local ok, err = FFD.UnsaveKeypad(ply, ent)
    ply:ChatPrint(ok and "[FFD] Постоянное сохранение кейпада убрано." or ("[FFD] Ошибка: " .. tostring(err)))
end)

-- ─── Сеть: открыть панель доступа (сервер → клиент) ──────────────
net.Receive("FFD_OpenAccessEditor", function(len, ply)
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end

    -- Проверяем, что это дверь или кейпад
    if ent.isFadingDoor or ent:GetClass() == "ffd_keypad" then
        net.Start("FFD_OpenAccessEditor")
        net.WriteEntity(ent)
        net.Send(ply)
    end
end)

-- ─── Сеть: применить конфиг доступа с клиентской панели ───────────
net.Receive("FFD_SetAccessConfig", function(len, ply)
    local ent = net.ReadEntity()
    if not IsValid(ent) then return end

    local accessType = net.ReadString()
    local factions = decodeArr(net.ReadString())
    local roles = decodeArr(net.ReadString())

    local access = { accessType = accessType, factions = factions, roles = roles }

    if ent:GetClass() == "ffd_keypad" then
        ent.FFDAccessOverride = access
        ent:SetHasAccessOverride(true)
    elseif ent.isFadingDoor then
        ent.FFDAccess = access
    else
        return
    end

    ply:ChatPrint("[FFD] Настройки доступа обновлены.")
end)