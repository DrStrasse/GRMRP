--[[--------------------------------------------------------------------
    FFD — панель редактора доступа (фракция/роль) для двери или кейпада.
    Открывается через net-сообщение FFD_OpenAccessEditor от сервера.

    Исправлено:
    - Панель ожидает получения списка фракций перед отображением
    - Добавлена кнопка обновления списка фракций
--------------------------------------------------------------------]]

local function buildFactionChecklist(parent, selectedFactions, selectedRoles)
    local factionBoxes, roleBoxes = {}, {}

    if not FFD.ClientFactions or #FFD.ClientFactions == 0 then
        local label = vgui.Create("DLabel", parent)
        label:SetText("Фракции не загружены. Нажмите «Обновить».")
        label:SetDark(true)
        label:Dock(TOP)
        label:DockMargin(4, 4, 4, 4)
        return factionBoxes, roleBoxes
    end

    for _, f in ipairs(FFD.ClientFactions) do
        local fCheck = vgui.Create("DCheckBoxLabel", parent)
        fCheck:SetText(f.name)
        fCheck:SetValue(table.HasValue(selectedFactions, f.name))
        fCheck:Dock(TOP)
        fCheck:DockMargin(4, 2, 4, 2)
        factionBoxes[f.name] = fCheck

        if f.roles and #f.roles > 0 then
            local roleHolder = vgui.Create("DPanel", parent)
            roleHolder:Dock(TOP)
            roleHolder:DockMargin(20, 0, 4, 4)
            roleHolder:SetTall(#f.roles * 22)
            roleHolder.Paint = function() end

            for _, roleName in ipairs(f.roles) do
                local rCheck = vgui.Create("DCheckBoxLabel", roleHolder)
                rCheck:SetText(roleName)
                rCheck:SetValue(table.HasValue(selectedRoles, roleName))
                rCheck:Dock(TOP)
                roleBoxes[roleName] = rCheck
            end
        end
    end

    return factionBoxes, roleBoxes
end

function FFD.OpenAccessEditor(ent)
    if not IsValid(ent) then return end

    -- Запрашиваем фракции и открываем панель
    FFD.RequestFactions()

    local frame = vgui.Create("DFrame")
    frame:SetSize(360, 520)
    frame:Center()
    frame:SetTitle("FFD — Настройка доступа")
    frame:MakePopup()

    local scroll = vgui.Create("DScrollPanel", frame)
    scroll:Dock(FILL)
    scroll:DockMargin(4, 4, 4, 40)

    -- Тип доступа
    local accessLabel = vgui.Create("DLabel", scroll)
    accessLabel:SetText("Тип доступа:")
    accessLabel:SetDark(true)
    accessLabel:Dock(TOP)
    accessLabel:DockMargin(4, 4, 4, 2)

    local accessCombo = vgui.Create("DComboBox", scroll)
    accessCombo:Dock(TOP)
    accessCombo:DockMargin(4, 2, 4, 8)
    accessCombo:SetValue("Публичный (все)")
    for accessType, label in pairs(FFD.ACCESS_LABELS) do
        accessCombo:AddChoice(label, accessType)
    end

    -- Разделитель
    local factionLabel = vgui.Create("DLabel", scroll)
    factionLabel:SetText("Фракции и роли:")
    factionLabel:SetDark(true)
    factionLabel:Dock(TOP)
    factionLabel:DockMargin(4, 4, 4, 2)

    -- Контейнер для чекбоксов фракций (будет перестроен после загрузки)
    local factionContainer = vgui.Create("DPanel", scroll)
    factionContainer:Dock(TOP)
    factionContainer:DockMargin(4, 2, 4, 4)
    factionContainer:SetAutoSize(true)
    factionContainer.Paint = function() end

    local factionBoxes, roleBoxes = {}, {}

    local function rebuildChecklist()
        factionContainer:Clear()
        factionBoxes, roleBoxes = buildFactionChecklist(factionContainer, {}, {})
        factionContainer:InvalidateLayout(true)
        factionContainer:SizeToChildren(false, true)
    end

    -- Кнопка обновления списка фракций
    local refreshBtn = vgui.Create("DButton", scroll)
    refreshBtn:SetText("Обновить список фракций")
    refreshBtn:Dock(TOP)
    refreshBtn:DockMargin(4, 2, 4, 8)
    refreshBtn.DoClick = function()
        FFD.RequestFactions()
        timer.Simple(0.5, rebuildChecklist)
    end

    -- Строим чекбоксы сразу (если фракции уже загружены) или ждём
    if FFD.ClientFactions and #FFD.ClientFactions > 0 then
        rebuildChecklist()
    else
        timer.Simple(0.7, rebuildChecklist)
    end

    -- Обновляем при получении фракций
    hook.Add("FFD_FactionsUpdated", frame, function()
        if IsValid(factionContainer) then
            rebuildChecklist()
        end
    end)

    -- Кнопка "Применить"
    local saveBtn = vgui.Create("DButton", frame)
    saveBtn:SetText("Применить")
    saveBtn:Dock(BOTTOM)
    saveBtn:DockMargin(4, 4, 4, 4)
    saveBtn.DoClick = function()
        local _, accessType = accessCombo:GetSelected()
        accessType = accessType or FFD.ACCESS.PUBLIC

        local factions, roles = {}, {}
        for name, box in pairs(factionBoxes) do
            if box:GetChecked() then factions[#factions + 1] = name end
        end
        for name, box in pairs(roleBoxes) do
            if box:GetChecked() then roles[#roles + 1] = name end
        end

        net.Start("FFD_SetAccessConfig")
        net.WriteEntity(ent)
        net.WriteString(accessType)
        net.WriteString(util.TableToJSON(factions))
        net.WriteString(util.TableToJSON(roles))
        net.SendToServer()

        frame:Close()
    end

    -- Удаляем хук при закрытии панели
    frame.OnClose = function()
        hook.Remove("FFD_FactionsUpdated", frame)
    end
end