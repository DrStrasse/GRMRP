--[[--------------------------------------------------------------------
    FFD — клиентское ядро: кэш списка фракций/ролей для панелей
    инструментов, подсветка кейпадов, обработка net-сообщений.

    Исправлено:
    - Добавлен обработчик FFD_OpenAccessEditor (сервер → клиент)
    - Панель доступа открывается по команде сервера (не по клиентской
      проверке isFadingDoor, которая на клиенте недоступна)
--------------------------------------------------------------------]]

FFD.ClientFactions = FFD.ClientFactions or {} -- { {name=..., roles={...}}, ... }

net.Receive("FFD_SyncFactions", function()
    FFD.ClientFactions = net.ReadTable() or {}
    hook.Run("FFD_FactionsUpdated")
end)

function FFD.RequestFactions()
    net.Start("FFD_RequestFactions")
    net.SendToServer()
end

hook.Add("InitPostEntity", "FFD_RequestFactionsOnJoin", function()
    timer.Simple(2, FFD.RequestFactions)
end)

-- ─── Обработчик: сервер говорит открыть панель доступа ────────────
net.Receive("FFD_OpenAccessEditor", function()
    local ent = net.ReadEntity()
    if IsValid(ent) and FFD.OpenAccessEditor then
        FFD.OpenAccessEditor(ent)
    end
end)

-- ─── Подсветка кейпадов, на которые смотрит игрок ─────────────────
hook.Add("HUDPaint", "FFD_KeypadHint", function()
    local ply = LocalPlayer()
    if not IsValid(ply) then return end

    local tr = ply:GetEyeTrace()
    local ent = tr.Entity

    if IsValid(ent) and ent:GetClass() == "ffd_keypad" and ply:GetPos():DistToSqr(ent:GetPos()) < (200 * 200) then
        local doorLinked = IsValid(ent:GetLinkedDoor())
        local text = doorLinked and "[E] Использовать кейпад" or "Кейпад не привязан к двери"
        local x, y = ScrW() / 2, ScrH() / 2 + 40
        draw.SimpleTextOutlined(text, "DermaDefaultBold", x, y, doorLinked and Color(120, 220, 140) or Color(220, 90, 90), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0, 0, 0, 200))
    end
end)

-- ПРИМЕЧАНИЕ: открытие/закрытие двери по нажатию E обрабатывается
-- нативным ENT:Use (движковый "+use"), отдельный KeyPress-хук с
-- net-сообщением сюда специально НЕ добавлен — раньше он приводил
-- к двойному срабатыванию (открыть и сразу закрыть) на одно нажатие.