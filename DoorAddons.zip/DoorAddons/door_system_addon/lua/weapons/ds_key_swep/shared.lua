--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Key SWEP (Связка ключей)

    Пустые руки с 4 действиями:
      ЛКМ (Primary)   — lock   / unlock  (переключение замка)
      ПКМ (Secondary) — open   / close   (открыть/закрыть дверь)

    Требования:
      • У игрока должен быть ключ для данной двери
        (OR игрок — владелец/совладелец OR суперадмин)
      • Смотреть на дверь с расстояния <= DS.INTERACT_RANGE

    Сервер: сетевые команды отправляются в sv_core.lua
    Клиент: HUD-подсказки про текущее действие
--------------------------------------------------------------------]]

SWEP.PrintName       = "Door Keys GRM"
SWEP.Author          = "Groennerland2036"
SWEP.Instructions    = "ЛКМ: замок  |  ПКМ: открыть/закрыть  |  R: меню двери (имя/настройки)"
SWEP.Category        = "Door System"

SWEP.Spawnable       = true    -- видно всем в Q → Оружие → Door System
SWEP.AdminSpawnable  = true

-- Пустые руки
SWEP.ViewModel       = "models/weapons/c_arms_citizen.mdl"
SWEP.WorldModel      = ""
SWEP.UseHands        = true

SWEP.Primary.ClipSize    = -1
SWEP.Primary.DefaultClip = -1
SWEP.Primary.Automatic   = false
SWEP.Primary.Ammo        = "none"

SWEP.Secondary.ClipSize    = -1
SWEP.Secondary.DefaultClip = -1
SWEP.Secondary.Automatic   = false
SWEP.Secondary.Ammo        = "none"

-- Кулдаун между действиями
SWEP._nextAction  = 0
SWEP._cooldown    = 0.6  -- секунд

-- ─── Инициализация ───────────────────────────────────────────────
function SWEP:Initialize()
    self:SetHoldType("normal")
end

function SWEP:Deploy()
    self:SetHoldType("normal")
    return true
end

function SWEP:Holster() return true end

-- ─── Найти дверь перед владельцем SWEP ───────────────────────────
function SWEP:GetAimedDoor()
    local ply = self:GetOwner()
    if not IsValid(ply) then return nil end
    local tr = util.TraceLine({
        start  = ply:EyePos(),
        endpos = ply:EyePos() + ply:GetAimVector() * (DS and DS.INTERACT_RANGE or 120),
        filter = ply,
        mask   = MASK_ALL,
    })
    if IsValid(tr.Entity) and DS and DS.IsDoor and DS.IsDoor(tr.Entity) then
        return tr.Entity
    end
    return nil
end

-- ─── Проверка: можно ли взаимодействовать ────────────────────────
function SWEP:CanInteract(doorEnt)
    local ply = self:GetOwner()
    if not IsValid(ply) or not IsValid(doorEnt) then return false end
    if SERVER then
        if ply:IsSuperAdmin() then return true end
        local id = DS.DoorID(doorEnt)
        if not id then return true end
        -- Владелец/совладелец
        if DS.IsOwner(ply:SteamID(), id, true) then return true end
        -- Фракционный доступ: члены допущенных фракций могут взаимодействовать
        local rec = DS.Cache.doors[id]
        if rec and (rec.access == DS.ACCESS.FACTION or rec.access == DS.ACCESS.FACTION_ROLE) then
            local faction, role = DS.GetPlayerFaction(ply)
            if faction then
                local flist = DS.Cache.factions[id]
                if flist and table.HasValue(flist, faction) then
                    if rec.access == DS.ACCESS.FACTION_ROLE then
                        local roles = DS.Cache.roles[id] and DS.Cache.roles[id][faction]
                        if roles and #roles > 0 then
                            return table.HasValue(roles, role)
                        end
                    end
                    return true
                end
            end
        end
        -- Ключ в кольце (ключ привязан к owner_steam, не к door_id)
        local ring = DS.Cache.rings[ply:SteamID()] or {}
        local doorOwners = DS.Cache.owners[id] or {}
        -- Дверь без владельца — ключ не работает
        if next(doorOwners) == nil then return false end
        for _, kid in ipairs(ring) do
            local k = DS.Cache.keys[kid]
            if k and doorOwners[k.owner_steam] then return true end
        end
        return false
    end
    return true  -- Клиент считает что может (сервер проверит)
end

-- ─── ЛКМ: ЗАМОК / РАЗБЛОКИРОВАТЬ ─────────────────────────────────
function SWEP:PrimaryAttack()
    if CurTime() < self._nextAction then return end
    self._nextAction = CurTime() + self._cooldown

    local door = self:GetAimedDoor()
    if not IsValid(door) then return end

    if SERVER then
        local ply = self:GetOwner()
        if not self:CanInteract(door) then
            if IsValid(ply) then
                ply:EmitSound(DS.SND.DENY, 65, 100, 0.7)
                DS.Result(ply, false, "Нет ключа или прав")
            end
            return
        end
        local id  = DS.DoorID(door)
        if not id then return end
        local rec = DS.Cache.doors[id]
        if not rec then return end
        -- Запрет блокировки двери без владельца — кроме фракционных дверей
        local doorOwners = DS.Cache.owners[id] or {}
        local isFactionDoor = rec.access == DS.ACCESS.FACTION or
                              rec.access == DS.ACCESS.FACTION_ROLE
        if next(doorOwners) == nil and not ply:IsSuperAdmin() and not isFactionDoor then
            DS.Result(ply, false, "У двери нет владельца")
            return
        end
        rec.locked = not rec.locked
        -- Физически запереть/отпереть дверь в движке
        DS.ApplyLockState(id, rec.locked)
        ply:EmitSound(rec.locked and DS.SND.LOCK or DS.SND.UNLOCK, 65, 100)
        sql.Query("UPDATE ds_doors SET locked=" .. (rec.locked and 1 or 0) ..
                  " WHERE id=" .. sql.SQLStr(id))
        DS.SyncDoor(id)
        DS.Result(ply, true, rec.locked and "Заперта" or "Разблокирована")
    end

    self:SendWeaponAnim(ACT_VM_PRIMARYATTACK)
end

-- ─── ПКМ: ОТКРЫТЬ / ЗАКРЫТЬ ──────────────────────────────────────
function SWEP:SecondaryAttack()
    if CurTime() < self._nextAction then return end
    self._nextAction = CurTime() + self._cooldown

    local door = self:GetAimedDoor()
    if not IsValid(door) then return end

    if SERVER then
        local ply = self:GetOwner()
        if not self:CanInteract(door) then
            if IsValid(ply) then
                ply:EmitSound(DS.SND.DENY, 65, 100, 0.7)
                DS.Result(ply, false, "Нет ключа или прав")
            end
            return
        end
        -- Проверить замок
        local id  = DS.DoorID(door)
        local rec = DS.Cache.doors[id]
        if rec and rec.locked then
            ply:EmitSound(DS.SND.DENY, 65, 100, 0.7)
            DS.Result(ply, false, "Дверь заперта на замок")
            return
        end
        -- Открыть/закрыть — активируем USE
        door:Fire("toggle", "", 0)
        local cls = door:GetClass()
        -- Для func_door используем Open/Close
        if cls == "func_door" or cls == "func_door_rotating" then
            local state = door:GetInternalVariable("m_toggle_state")
            -- 0=закрыта, 1=открывается, 2=открыта, 3=закрывается
            if state == 0 or state == 3 then
                door:Fire("Open",  "", 0)
            else
                door:Fire("Close", "", 0)
            end
        end
    end

    self:SendWeaponAnim(ACT_VM_SECONDARYATTACK)
end

-- ─── R: ПРОСТОЕ МЕНЮ ДВЕРИ ───────────────────────────────────────
function SWEP:Reload()
    if CLIENT then
        -- Открываем простое меню только при взгляде на дверь
        local door = self:GetAimedDoor()
        if IsValid(door) and DS_OpenSimpleMenu then
            DS_OpenSimpleMenu(door)
        end
    end
end

-- ─── Клиентский HUD: подсказки ───────────────────────────────────
if CLIENT then
    -- Вспомогательная функция: нарисовать одну строку-подсказку
    -- Бейдж авто-расширяется под ключевое слово (нет наслоений)
    local function drawHint(cx, panelX, ry, keyStr, labelStr, labelCol)
        surface.SetFont("DS_H_Hint")
        local kw = surface.GetTextSize(keyStr)
        local bw = kw + 12   -- 6px отступ с каждой стороны
        local bx = panelX + 8
        draw.RoundedBox(4, bx, ry, bw, 18, Color(40, 55, 110))
        draw.SimpleText(keyStr, "DS_H_Hint",
            bx + bw/2, ry + 1,
            Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        draw.SimpleText(labelStr, "DS_H_Sub",
            bx + bw + 8, ry + 1,
            labelCol or Color(130, 145, 180))
    end

    function SWEP:DrawHUD()
        local ply = self:GetOwner()
        if ply ~= LocalPlayer() then return end
        -- Не рисуем если открыто любое DS-меню (настройки, простое и т.д.)
        if DS_IsMenuOpen and DS_IsMenuOpen() then return end

        local C      = DS and DS.COL or {}
        local sw, sh = ScrW(), ScrH()

        local door = self:GetAimedDoor()
        if not IsValid(door) then return end

        local data, doorID
        if DS_GetDoorByEnt then
            data, doorID = DS_GetDoorByEnt(door)
        end

        local isLocked = data and data.locked or false

        -- Блок подсказок: 3 строки по 22px + отступы
        local W   = 300
        local H   = 8 + 3 * 22 + 6   -- 92px
        local y   = sh / 2 + 90
        local cx  = sw / 2
        local px  = cx - W / 2

        -- Фон
        draw.RoundedBox(8, px, y, W, H, Color(6, 10, 24, 218))
        surface.SetDrawColor(50, 65, 120, 160)
        surface.DrawOutlinedRect(px, y, W, H, 1)

        -- Строки: ЛКМ / ПКМ / R
        local lmbTxt = isLocked and "Разблокировать" or "Заблокировать"
        local lmbCol = isLocked and Color(80, 220, 100) or Color(220, 80, 80)

        drawHint(cx, px, y + 8,       "ЛКМ", lmbTxt,              lmbCol)
        drawHint(cx, px, y + 8 + 22,  "ПКМ", "Открыть / Закрыть", C.DIM or Color(130,145,180))
        drawHint(cx, px, y + 8 + 44,  "R",   "Меню / Имя",             Color(160,200,255))

        -- Статус ключа — правый угол, первая строка
        local hasKey = false
        if DS_GetMyKeyRing then
            local owners = data and data.owners or {}
            local mySt   = LocalPlayer():SteamID()
            for _, k in pairs(DS_GetMyKeyRing()) do
                if owners[k.owner_steam] then hasKey = true; break end
            end
        end
        local keyTxt = hasKey and "🔑 Ключ есть" or "Нет ключа"
        local keyCol = hasKey and (C.KEY or Color(255,215,0)) or Color(200,80,80)
        draw.SimpleText(keyTxt, "DS_H_Tiny",
            px + W - 8, y + 10,
            keyCol, TEXT_ALIGN_RIGHT, TEXT_ALIGN_TOP)
    end
end
