--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Главный файл (shared)
    Полное переосмысление: SQLite, категории, групповые владельцы,
    временная аренда, сканирование дверей карты.
--------------------------------------------------------------------]]
if SERVER then
    AddCSLuaFile("doors/cl_hud.lua")
    AddCSLuaFile("doors/cl_menu.lua")
    AddCSLuaFile("doors/cl_admin.lua")
    AddCSLuaFile("weapons/ds_key_swep/shared.lua")
end

DS = DS or {}
DS.VERSION = "2.0.0"

-- ─── Типы доступа ─────────────────────────────────────────────────
DS.ACCESS = {
    PUBLIC       = "public",
    PRIVATE      = "private",
    FACTION      = "faction",
    FACTION_ROLE = "faction_role",
    WHITELIST    = "whitelist",
    KEY          = "key",
    OWNER_ONLY   = "owner_only",
}

-- ─── Типы владельцев ──────────────────────────────────────────────
DS.OWNER_TYPE = {
    OWNER   = "owner",    -- главный владелец (может менять настройки)
    COOWNER = "coowner",  -- совладелец (только вход + замок)
}

-- ─── Типы групп фракций (настраиваемые в панели суперадмина) ──────
-- Каждый тип — это «роль» фракции в мире сервера.
-- Используется чтобы быстро понять какие фракции государственные,
-- какие медицинские и т.д. при настройке дверей.
DS.FACTION_GROUP_TYPES = {
    { name = "Государственные", r = 220, g = 60,  b = 60  },
    { name = "Военные",         r = 180, g = 130, b = 50  },
    { name = "Медицинские",     r = 80,  g = 220, b = 120 },
    { name = "Коммерческие",    r = 255, g = 200, b = 50  },
    { name = "Религиозные",     r = 200, g = 100, b = 220 },
    { name = "Прочие",          r = 130, g = 145, b = 180 },
}

-- Получить цвет группы по имени
function DS.GetFactionGroupColor(groupName)
    for _, g in ipairs(DS.FACTION_GROUP_TYPES) do
        if g.name == groupName then return Color(g.r, g.g, g.b) end
    end
    return Color(130, 145, 180)
end

-- ─── Встроенные категории по умолчанию ────────────────────────────
DS.DEFAULT_CATEGORIES = {
    { name = "Без категории",  r = 100, g = 100, b = 120 },
    { name = "Жилой дом",      r = 80,  g = 160, b = 255 },
    { name = "Магазин",        r = 60,  g = 200, b = 100 },
    { name = "Склад",          r = 200, g = 140, b = 50  },
    { name = "Государственный",r = 220, g = 50,  b = 50  },
    { name = "Больница",       r = 255, g = 255, b = 255 },
    { name = "Производство",   r = 180, g = 100, b = 220 },
    { name = "Офис",           r = 100, g = 200, b = 200 },
}

-- ─── Поддерживаемые классы дверей ────────────────────────────────
DS.DOOR_CLASSES = {
    "func_door",
    "func_door_rotating",
    "func_button",
    "prop_door_rotating",
    "func_movelinear",
    "func_door_rotating_checkpoint",
}

-- ─── Дальности ───────────────────────────────────────────────────
DS.HUD_RANGE       = 180
DS.INTERACT_RANGE  = 120

-- ─── Конфиг ключей (настраивай здесь) ────────────────────────────
-- ds_givekey          — выдать себе ключ (без аргументов = ключ от тебя самого)
-- ds_givekey <steam>  — выдать ключ от тебя другому игроку (SteamID64 или SteamID)
-- ds_revokekey <steam> — отозвать свой ключ у игрока
DS.KEY_CONFIG = {
    SWEP_CLASS     = "ds_key_swep",   -- класс оружия связки ключей (не менять)
    AUTO_GIVE_SWEP = true,            -- авто-выдача SWEP при получении первого ключа
    AUTO_STRIP_SWEP= true,            -- авто-снятие SWEP когда ключей не осталось
    DEFAULT_COLOR  = {r=255,g=215,b=0}, -- цвет ключа по умолчанию (золотой)
    -- Звуки (стандартные звуки GMod, менять на пути к кастомным если нужно)
    -- DS.SND.KEY_GET = "items/ammo_pickup.wav"
}

-- ─── Звуки ───────────────────────────────────────────────────────
DS.SND = {
    LOCK    = "doors/latchbolt.wav",
    UNLOCK  = "doors/latchunbolt.wav",
    DENY    = "buttons/button11.wav",
    KEY_GET = "items/ammo_pickup.wav",
    BUY     = "buttons/button14.wav",
}

-- ─── Цветовая палитра ────────────────────────────────────────────
DS.COL = {
    BG        = Color(8,   12,  28,  240),
    BG2       = Color(14,  18,  40,  230),
    PANEL     = Color(18,  24,  52,  220),
    ACCENT    = Color(55,  135, 255, 255),
    SUCCESS   = Color(50,  200, 90,  255),
    DANGER    = Color(220, 55,  55,  255),
    WARNING   = Color(255, 185, 40,  255),
    TEXT      = Color(225, 232, 255, 255),
    DIM       = Color(130, 145, 180, 255),
    BORDER    = Color(50,  65,  120, 180),
    KEY       = Color(255, 215, 0,   255),
    GOLD      = Color(255, 200, 60,  255),
    OWNER     = Color(80,  220, 120, 255),
    COOWNER   = Color(120, 180, 255, 255),
}

-- ─── Утилиты (общие) ─────────────────────────────────────────────
function DS.IsDoor(ent)
    if not IsValid(ent) then return false end
    local cls = ent:GetClass()
    for _, c in ipairs(DS.DOOR_CLASSES) do
        if cls == c then return true end
    end
    return false
end

function DS.GetFactionColor(name)
    local f = Factions and Factions[name]
    if f and f.Color then return Color(f.Color.r or 200, f.Color.g or 200, f.Color.b or 200) end
    return Color(160, 160, 160)
end

function DS.GetFactionTag(name)
    local f = Factions and Factions[name]
    if f and f.Tag and f.Tag ~= "" then return f.Tag end
    return string.upper(string.sub(name or "?", 1, 4))
end

function DS.AccessLabel(a)
    local t = {
        [DS.ACCESS.PUBLIC]       = "Публичный",
        [DS.ACCESS.PRIVATE]      = "Приватный",
        [DS.ACCESS.FACTION]      = "Фракция",
        [DS.ACCESS.FACTION_ROLE] = "Фракция + Роль",
        [DS.ACCESS.WHITELIST]    = "Белый список",
        [DS.ACCESS.KEY]          = "По ключу",
        [DS.ACCESS.OWNER_ONLY]   = "Только владелец",
    }
    return t[a] or "Неизвестно"
end

-- Красиво форматировать секунды
function DS.FormatTime(secs)
    if secs <= 0 then return "Бессрочно" end
    local d = math.floor(secs / 86400)
    local h = math.floor((secs % 86400) / 3600)
    local m = math.floor((secs % 3600) / 60)
    if d > 0 then return d .. "д " .. h .. "ч" end
    if h > 0 then return h .. "ч " .. m .. "м" end
    return m .. "м"
end

-- Осталось времени (от unix-метки до сейчас)
function DS.TimeLeft(expires_at)
    if not expires_at or expires_at == 0 then return 0 end
    return math.max(0, expires_at - os.time())
end

-- Стабильный ID двери (SHARED — работает на клиенте и сервере)
-- Формат: mapname_h{hammerID} или mapname_e{entIndex}
function DS.DoorID(ent)
    if not IsValid(ent) then return nil end
    local hid = ent:MapCreationID()
    if hid and hid > 0 then
        return game.GetMap() .. "_h" .. hid
    end
    return game.GetMap() .. "_e" .. ent:EntIndex()
end

-- ─── Загрузка клиентских файлов ──────────────────────────────────
-- Выполняется ПОСЛЕ всех определений DS, чтобы клиентские файлы
-- видели полностью инициализированный DS при загрузке.
if SERVER then
    include("doors/sv_core.lua")
    include("doors/sv_keys.lua")
    include("doors/sv_factions.lua")
    include("doors/sv_buttons.lua")
    include("doors/sv_ulx.lua")
    include("doors/sv_migrate.lua")
end

if CLIENT then
    include("doors/cl_hud.lua")
    include("doors/cl_menu.lua")
    include("doors/cl_admin.lua")
end
