--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Панель администратора (клиент, ПОЛНЫЙ ПЕРЕЗАПИС)

    Команда: ds_admin_panel
    Возможности:
      • Список всех дверей карты с поиском
      • Сброс любой двери / всей карты
      • Назначение владельца (тип + срок)
      • Управление категориями (добавить/удалить/цвет)
--------------------------------------------------------------------]]

local C = DS.COL

surface.CreateFont("DSA_Title", { font="Roboto Bold", size=22, weight=800 })
surface.CreateFont("DSA_Tab",   { font="Roboto",      size=14, weight=700 })
surface.CreateFont("DSA_Label", { font="Roboto",      size=14, weight=500 })
surface.CreateFont("DSA_Small", { font="Roboto",      size=12, weight=400 })
surface.CreateFont("DSA_Btn",   { font="Roboto Bold", size=13, weight=700 })

local function rbox(x,y,w,h,r,col) draw.RoundedBox(r,x,y,w,h,col) end
local function stxt(s,f,x,y,col,ax,ay)
    draw.SimpleText(s,f,x,y,col,ax or TEXT_ALIGN_LEFT,ay or TEXT_ALIGN_TOP)
end
local function outline(x,y,w,h,r,g,b,a)
    surface.SetDrawColor(r,g,b,a or 255); surface.DrawOutlinedRect(x,y,w,h,1)
end

local function mkBtn(parent,text,x,y,w,h,col,fn)
    local btn=vgui.Create("DButton",parent)
    btn:SetPos(x,y); btn:SetSize(w,h); btn:SetText("")
    local bc=col or Color(55,100,200)
    function btn:Paint(bw,bh)
        rbox(0,0,bw,bh,5,self:IsHovered() and Color(bc.r+25,bc.g+25,bc.b+25) or bc)
        stxt(text,"DSA_Btn",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    end
    btn.DoClick=fn; return btn
end

local function mkEntry(parent,x,y,w,h,ph,def)
    local e=vgui.Create("DTextEntry",parent)
    e:SetPos(x,y); e:SetSize(w,h); e:SetPlaceholderText(ph or ""); e:SetValue(def or "")
    e:SetFont("DSA_Label"); e:SetTextColor(Color(225,232,255)); e:SetDrawBackground(false)
    function e:Paint(ew,eh)
        rbox(0,0,ew,eh,5,Color(18,24,50)); outline(0,0,ew,eh,55,80,160,140)
        self:DrawTextEntryText(Color(225,232,255),Color(70,110,230),Color(255,255,255))
    end
    return e
end

local function mkCombo(parent,x,y,w,h)
    local cb=vgui.Create("DComboBox",parent)
    cb:SetPos(x,y); cb:SetSize(w,h)
    cb:SetFont("DSA_Label"); cb:SetTextColor(Color(225,232,255)); cb:SetDrawBackground(false)
    function cb:Paint(cw,ch)
        rbox(0,0,cw,ch,5,Color(18,24,50)); outline(0,0,cw,ch,55,80,160,140)
        stxt(self:GetValue(),"DSA_Label",10,ch/2,Color(225,232,255),TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        surface.SetDrawColor(120,140,200)
        surface.DrawLine(cw-14,ch/2-2,cw-8,ch/2+4); surface.DrawLine(cw-8,ch/2+4,cw-2,ch/2-2)
    end
    return cb
end

local function mkScroll(parent,x,y,w,h)
    local sc=vgui.Create("DScrollPanel",parent)
    sc:SetPos(x,y); sc:SetSize(w,h)
    function sc:Paint(sw,sh) rbox(0,0,sw,sh,6,Color(10,14,32)); outline(0,0,sw,sh,50,65,120,80) end
    local sb=sc:GetVBar(); sb:SetWide(4)
    function sb:Paint(sw,sh)     rbox(0,0,sw,sh,2,Color(16,20,44)) end
    function sb.btnUp:Paint()    end
    function sb.btnDown:Paint()  end
    function sb.btnGrip:Paint(sw,sh) rbox(0,0,sw,sh,2,Color(60,90,200,180)) end
    return sc
end

local function mkSep(parent,x,y,w)
    local p=vgui.Create("DPanel",parent); p:SetPos(x,y); p:SetSize(w,1)
    function p:Paint(pw,ph) rbox(0,0,pw,ph,0,Color(50,65,120,140)) end
end

local function mkLbl(parent,text,x,y,w,col)
    local l=vgui.Create("DLabel",parent); l:SetPos(x,y); l:SetSize(w or 400,20)
    l:SetText(text); l:SetFont("DSA_Label"); l:SetTextColor(col or C.DIM); return l
end

-- ─── Кэш данных ──────────────────────────────────────────────────
local AdminDoors    = {}
local singleton     = nil
local FactionGroups = {}  -- [factionName] = groupName (с сервера)
local FactionList   = {}  -- [{name, tag, r, g, b}] (из DS_SyncFactions)

net.Receive("DS_FactionGroupsSync", function()
    FactionGroups = net.ReadTable() or {}
end)

-- Единственный net.Receive("DS_SyncFactions") находится в cl_hud.lua.
-- Здесь подписываемся на хук который он вызывает после обновления данных.
hook.Add("DS_FactionsListUpdated", "DS_Admin_FacList", function(list)
    FactionList = list
end)

-- ─── Открыть панель ──────────────────────────────────────────────
local function openAdminPanel()
    if not LocalPlayer():IsAdmin() then
        DS_Notify("Недостаточно прав (нужен admin или выше)","error"); return
    end
    if IsValid(singleton) then singleton:Remove() end

    net.Start("DS_AdminAction"); net.WriteString("get_all"); net.SendToServer()

    local W,H = 760,600
    local frame=vgui.Create("DFrame")
    frame:SetTitle(""); frame:SetSize(W,H); frame:Center()
    frame:SetDraggable(true); frame:MakePopup()
    singleton=frame

    function frame:Paint(fw,fh)
        rbox(4,4,fw,fh,12,Color(0,0,0,70))
        rbox(0,0,fw,fh,12,Color(6,10,24,252))
        rbox(0,0,fw,4,12,C.ACCENT); rbox(0,2,fw,2,0,C.ACCENT)
        stxt("Панель администратора — Door System v2.0","DSA_Title",fw/2,18,C.TEXT,TEXT_ALIGN_CENTER,TEXT_ALIGN_TOP)
    end

    local xBtn=vgui.Create("DButton",frame); xBtn:SetPos(W-36,8); xBtn:SetSize(28,28); xBtn:SetText("")
    function xBtn:Paint(bw,bh)
        rbox(0,0,bw,bh,5,self:IsHovered() and Color(180,40,40) or Color(100,30,30))
        stxt("✕","DSA_Label",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    end
    xBtn.DoClick=function() frame:Remove() end

    -- Вкладки
    local TABS={"Двери","Категории","Назначить владельца","Фракции"}
    local panels={}
    local tabBtns={}

    local tabBar=vgui.Create("DPanel",frame); tabBar:SetPos(10,56); tabBar:SetSize(W-20,32)
    function tabBar:Paint() end

    local content=vgui.Create("DPanel",frame); content:SetPos(10,92); content:SetSize(W-20,H-102)
    function content:Paint(cw,ch)
        rbox(0,0,cw,ch,8,Color(12,16,36,240)); outline(0,0,cw,ch,50,65,120,120)
    end

    local CW=content:GetWide()-16
    local CH=content:GetTall()-8
    local tabW=(W-20)/#TABS

    local function switchTab(idx)
        for i,p in ipairs(panels) do p:SetVisible(i==idx) end
        for i,b in ipairs(tabBtns) do b._active=(i==idx) end
    end

    for i,name in ipairs(TABS) do
        local b=vgui.Create("DButton",tabBar)
        b:SetPos((i-1)*tabW,0); b:SetSize(tabW,32); b:SetText(""); b._active=(i==1)
        function b:Paint(bw,bh)
            local ac=self._active
            rbox(0,0,bw,bh,ac and 6 or 4,ac and Color(35,75,180,220) or Color(18,26,50,200))
            if ac then rbox(0,bh-2,bw,2,0,C.ACCENT) end
            stxt(name,"DSA_Tab",bw/2,bh/2,ac and C.TEXT or C.DIM,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
        end
        b.DoClick=function() switchTab(i) end; tabBtns[i]=b
    end

    local function mkPanel()
        local p=vgui.Create("DPanel",content); p:SetPos(0,0); p:SetSize(content:GetWide(),content:GetTall())
        function p:Paint() end; table.insert(panels,p); p:SetVisible(#panels==1); return p
    end

    -- ================================================================
    -- ВКЛ 1: Двери
    -- ================================================================
    local panDoors=mkPanel()
    local filterE=mkEntry(panDoors,10,10,220,28,"Поиск...","")
    mkBtn(panDoors,"Обновить",240,10,100,28,Color(40,90,180),function()
        net.Start("DS_AdminAction"); net.WriteString("get_all"); net.SendToServer()
    end)
    mkBtn(panDoors,"Сбросить ВСЁ",350,10,130,28,Color(160,30,30),function()
        Derma_Query("Сбросить все двери карты?\nЭто действие необратимо!","Подтверждение",
            "Сбросить",function()
                net.Start("DS_AdminAction"); net.WriteString("reset_all"); net.SendToServer()
                AdminDoors={}
            end,"Отмена",function() end)
    end)

    local dScroll=mkScroll(panDoors,10,46,CW,CH-50)

    local dRows={}
    local function buildDoorList()
        for _,r in ipairs(dRows) do if IsValid(r) then r:Remove() end end; dRows={}
        local fs=string.lower(filterE:GetValue())
        local sorted={}
        for id,d in pairs(AdminDoors) do table.insert(sorted,{id=id,d=d}) end
        table.sort(sorted,function(a,b) return a.id<b.id end)
        local y=4
        for _,item in ipairs(sorted) do
            local id,d=item.id,item.d
            if fs~="" and not string.find(string.lower(id),fs,1,true)
               and not string.find(string.lower(d.name or ""),fs,1,true) then goto skip end

            local ownerStr=""
            for s,o in pairs(d.owners or {}) do
                if o.owner_type=="owner" then ownerStr=(o.nick or s) break end
            end
            if ownerStr=="" then ownerStr="Нет владельца" end

            local r=vgui.Create("DPanel",dScroll); r:SetPos(4,y); r:SetSize(CW-10,44)
            table.insert(dRows,r)
            local locked=d.locked or false
            function r:Paint(rw,rh)
                rbox(0,0,rw,rh,5,Color(16,22,46)); outline(0,0,rw,rh,50,65,120,80)
                rbox(0,0,3,rh,2,locked and Color(200,55,55) or Color(50,180,80))
                stxt(string.sub(id,1,30),"DSA_Small",10,4,C.DIM)
                local nm=(d.name and d.name~="") and d.name or "Без названия"
                stxt(nm,"DSA_Label",10,rh/2,C.TEXT,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
                stxt(ownerStr,"DSA_Small",rw-300,rh/2,C.DIM,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
                stxt(DS.AccessLabel(d.access or "public"),"DSA_Small",rw-120,rh/2,C.DIM,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
            end
            local cid=id
            mkBtn(r,"Сброс",CW-10-70,8,66,28,Color(140,35,35),function()
                local doorEnt=nil
                for _,e in ipairs(ents.GetAll()) do
                    if DS.IsDoor(e) and DS.DoorID(e)==cid then doorEnt=e break end
                end
                if not IsValid(doorEnt) then DS_Notify("Дверь не найдена","error") return end
                net.Start("DS_AdminReset"); net.WriteInt(doorEnt:EntIndex(),16); net.SendToServer()
                AdminDoors[cid]=nil; r:Remove()
            end)
            y=y+48
            ::skip::
        end
    end

    filterE.OnChange=function() buildDoorList() end
    timer.Simple(0.6,buildDoorList)

    net.Receive("DS_AdminSync",function()
        AdminDoors=net.ReadTable() or {}
        if IsValid(panDoors) then buildDoorList() end
    end)

    -- ================================================================
    -- ВКЛ 2: Категории
    -- ================================================================
    local panCat=mkPanel()
    local cy=10
    mkLbl(panCat,"Добавить новую категорию:",10,cy); cy=cy+24
    local catNE=mkEntry(panCat,10,cy,180,30,"Название...","")
    local catRE=mkEntry(panCat,200,cy,46,30,"R","100")
    local catGE=mkEntry(panCat,254,cy,46,30,"G","120")
    local catBE=mkEntry(panCat,308,cy,46,30,"B","255")
    -- Превью цвета
    local prevPanel=vgui.Create("DPanel",panCat); prevPanel:SetPos(362,cy); prevPanel:SetSize(30,30)
    local prevCol=Color(100,120,255)
    function prevPanel:Paint(pw,ph) rbox(0,0,pw,ph,5,prevCol); outline(0,0,pw,ph,255,255,255,60) end
    local function updatePreview()
        prevCol=Color(
            math.Clamp(tonumber(catRE:GetValue()) or 100,0,255),
            math.Clamp(tonumber(catGE:GetValue()) or 120,0,255),
            math.Clamp(tonumber(catBE:GetValue()) or 255,0,255))
    end
    catRE.OnChange=updatePreview; catGE.OnChange=updatePreview; catBE.OnChange=updatePreview

    mkBtn(panCat,"+ Добавить",400,cy,120,30,Color(35,115,60),function()
        local name=catNE:GetValue()
        if name=="" then DS_Notify("Введите название","error") return end
        net.Start("DS_AdminSetCategory")
        net.WriteString("add"); net.WriteString(name)
        net.WriteUInt(math.Clamp(tonumber(catRE:GetValue()) or 100,0,255),8)
        net.WriteUInt(math.Clamp(tonumber(catGE:GetValue()) or 120,0,255),8)
        net.WriteUInt(math.Clamp(tonumber(catBE:GetValue()) or 255,0,255),8)
        net.SendToServer(); catNE:SetValue(""); DS_Notify("Категория добавлена","success")
    end)
    cy=cy+40; mkSep(panCat,10,cy,CW); cy=cy+12
    mkLbl(panCat,"Текущие категории:",10,cy); cy=cy+24

    local catSc=mkScroll(panCat,10,cy,CW,CH-cy-10)
    local catRows={}
    local function buildCatList()
        for _,r in ipairs(catRows) do if IsValid(r) then r:Remove() end end; catRows={}
        local cats=DS_GetCategories(); local cy2=4
        for _,cat in ipairs(cats) do
            local r=vgui.Create("DPanel",catSc); r:SetPos(4,cy2); r:SetSize(CW-10,38); table.insert(catRows,r)
            local cc=Color(cat.r,cat.g,cat.b)
            function r:Paint(rw,rh)
                rbox(0,0,rw,rh,5,Color(16,22,46)); outline(0,0,rw,rh,cc.r,cc.g,cc.b,100)
                rbox(0,0,4,rh,2,cc); rbox(10,9,20,20,4,cc)
                stxt(cat.name,"DSA_Label",38,rh/2,C.TEXT,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
                stxt("R:"..cat.r.."  G:"..cat.g.."  B:"..cat.b,"DSA_Small",240,rh/2,C.DIM,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
            end
            if cat.name~="Без категории" then
                local cap=cat.name
                mkBtn(r,"Удалить",CW-10-80,5,76,28,Color(140,35,35),function()
                    net.Start("DS_AdminSetCategory"); net.WriteString("delete"); net.WriteString(cap)
                    net.WriteUInt(0,8); net.WriteUInt(0,8); net.WriteUInt(0,8); net.SendToServer(); r:Remove()
                end)
            end
            cy2=cy2+42
        end
    end
    net.Receive("DS_SyncCategories",function()
        net.ReadTable()  -- обновит кэш через HUD-хук автоматически
        if IsValid(panCat) then timer.Simple(0.1,buildCatList) end
    end)
    timer.Simple(0.4,buildCatList)

    -- ================================================================
    -- ВКЛ 3: Назначить владельца
    -- ================================================================
    local panOwn=mkPanel(); local oy=10
    mkLbl(panOwn,"EntIndex двери (наведитесь и введите):",10,oy); oy=oy+22
    local doorEE=mkEntry(panOwn,10,oy,180,30,"EntIndex...","")
    mkBtn(panOwn,"Взять прицел",200,oy,140,30,Color(50,90,160),function()
        local ply=LocalPlayer()
        local tr=util.TraceLine({start=ply:EyePos(),endpos=ply:EyePos()+ply:GetAimVector()*200,filter=ply,mask=MASK_ALL})
        if IsValid(tr.Entity) and DS.IsDoor(tr.Entity) then
            doorEE:SetValue(tostring(tr.Entity:EntIndex()))
            DS_Notify("Дверь: "..tostring(tr.Entity:EntIndex()),"success")
        else DS_Notify("Нет двери перед собой","error") end
    end)
    oy=oy+40

    mkLbl(panOwn,"Игрок (SteamID или выбор):",10,oy); oy=oy+22
    local plyC=mkCombo(panOwn,10,oy,220,30)
    plyC:AddChoice("[Убрать всех владельцев]","")
    for _,p in ipairs(player.GetAll()) do plyC:AddChoice(p:Nick(),p:SteamID()) end
    oy=oy+40

    mkLbl(panOwn,"Тип владельца:",10,oy)
    mkLbl(panOwn,"Срок (дни, 0=бессрочно):",200,oy)
    oy=oy+22
    local typeC=mkCombo(panOwn,10,oy,180,30)
    typeC:AddChoice("Владелец","owner"); typeC:AddChoice("Совладелец","coowner")
    local durE2=mkEntry(panOwn,200,oy,120,30,"Дни","0")
    mkBtn(panOwn,"Назначить →",330,oy,CW-324,30,Color(40,110,190),function()
        local idx=tonumber(doorEE:GetValue())
        local _,tS=plyC:GetSelected(); local _,oT=typeC:GetSelected()
        local days=tonumber(durE2:GetValue()) or 0
        if not idx then DS_Notify("Введите EntIndex","error") return end
        local ent=Entity(idx)
        if not IsValid(ent) or not DS.IsDoor(ent) then DS_Notify("Дверь не найдена","error") return end
        net.Start("DS_AdminSetOwner"); net.WriteInt(idx,16)
        net.WriteString(tS or ""); net.WriteString(oT or "owner"); net.WriteDouble(days*86400)
        net.SendToServer(); DS_Notify("Назначено","success")
    end)
    oy=oy+40; mkSep(panOwn,10,oy,CW); oy=oy+12
    mkLbl(panOwn,"Онлайн игроки (клик = выбрать):",10,oy); oy=oy+24

    local plySc=mkScroll(panOwn,10,oy,CW,CH-oy-10)
    local py2=4
    for _,p in ipairs(player.GetAll()) do
        local r=vgui.Create("DPanel",plySc); r:SetPos(4,py2); r:SetSize(CW-10,36)
        local steam=p:SteamID(); local nick=p:Nick()
        function r:Paint(rw,rh)
            rbox(0,0,rw,rh,5, self:IsHovered() and Color(22,30,58) or Color(16,22,46))
            outline(0,0,rw,rh,50,65,120,80)
            stxt(nick,"DSA_Label",10,rh/2,C.TEXT,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
            stxt(steam,"DSA_Small",220,rh/2,C.DIM,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
            local adm=p:IsSuperAdmin() and "SuperAdmin" or (p:IsAdmin() and "Admin" or "Player")
            stxt(adm,"DSA_Small",rw-90,rh/2,p:IsSuperAdmin() and C.GOLD or C.DIM,TEXT_ALIGN_LEFT,TEXT_ALIGN_CENTER)
        end
        r:SetMouseInputEnabled(true)
        r.OnMousePressed=function()
            for i=1,plyC:GetItemCount() do
                if select(2,plyC:GetOptionData(i))==steam then plyC:ChooseOptionID(i) break end
            end
            DS_Notify("Выбран: "..nick,"success")
        end
        py2=py2+40
    end

    -- ================================================================
    -- ВКЛ 4: Фракции — назначение групп
    -- ================================================================
    local panFac = mkPanel()
    local fgY    = 10

    -- Легенда групп (цветные бейджи)
    mkLbl(panFac, "Типы групп:", 10, fgY)
    fgY = fgY + 22
    local legendX = 10
    for _, gt in ipairs(DS.FACTION_GROUP_TYPES) do
        local gc = Color(gt.r, gt.g, gt.b)
        local lb = vgui.Create("DPanel", panFac)
        lb:SetPos(legendX, fgY); lb:SetSize(140, 22)
        function lb:Paint(lw, lh)
            rbox(0, 0, lw, lh, 4, Color(gc.r*0.25, gc.g*0.25, gc.b*0.25, 200))
            rbox(0, 0, 4, lh, 2, gc)
            stxt(gt.name, "DSA_Small", 10, lh/2, gc, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        legendX = legendX + 148
        if legendX + 148 > CW then legendX = 10; fgY = fgY + 28 end
    end
    fgY = fgY + 30
    mkSep(panFac, 10, fgY, CW); fgY = fgY + 12
    mkLbl(panFac, "Назначьте группу каждой фракции (изменения сохраняются сразу):", 10, fgY)
    fgY = fgY + 26

    -- Скролл с фракциями
    local facSc   = mkScroll(panFac, 10, fgY, CW, CH - fgY - 10)
    local facRows = {}

    -- Строит список фракций из FactionList (пришёл от DS_SyncFactions)
    local function buildFacList()
        for _, r in ipairs(facRows) do if IsValid(r) then r:Remove() end end
        facRows = {}

        -- Если FactionList пуст — взять из кэша DS (он доступен shared)
        local src = FactionList
        if not src or #src == 0 then
            -- Попробуем получить через DS_SyncFactions (уже должен прийти)
            src = {}
        end

        if #src == 0 then
            mkLbl(facSc, "Список фракций не получен. Подождите или перезайдите.", 10, 10, CW - 20, C.DIM)
            return
        end

        -- Группируем фракции по текущей группе для наглядности
        -- Но показываем просто список — по алфавиту
        local sorted = {}
        for _, f in ipairs(src) do table.insert(sorted, f) end
        table.sort(sorted, function(a, b) return a.name < b.name end)

        local ry = 4
        for _, fdata in ipairs(sorted) do
            local fname    = fdata.name
            local ftag     = fdata.tag or string.upper(string.sub(fname, 1, 4))
            local fcol     = Color(fdata.r or 160, fdata.g or 160, fdata.b or 160)
            local curGroup = FactionGroups[fname] or ""

            local row = vgui.Create("DPanel", facSc)
            row:SetPos(4, ry); row:SetSize(CW - 10, 42)
            table.insert(facRows, row)

            -- Цвет бейджа группы
            local function getGroupCol()
                local g = FactionGroups[fname] or ""
                return DS.GetFactionGroupColor(g)
            end

            function row:Paint(rw, rh)
                rbox(0, 0, rw, rh, 5, Color(16, 22, 46))
                -- Полоска цвета фракции
                rbox(0, 0, 4, rh, 0, fcol)
                -- Тег
                rbox(8, 9, 36, 24, 4, Color(fcol.r*0.3, fcol.g*0.3, fcol.b*0.3, 200))
                stxt(ftag, "DSA_Small", 26, rh/2, fcol, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                -- Имя фракции
                stxt(fname, "DSA_Label", 52, rh/2, C.TEXT, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                -- Текущая группа
                local grp = FactionGroups[fname] or "Не назначена"
                local gc2 = getGroupCol()
                if FactionGroups[fname] then
                    rbox(rw - 290, rh/2 - 10, 110, 20, 4,
                         Color(gc2.r*0.2, gc2.g*0.2, gc2.b*0.2, 180))
                    stxt(grp, "DSA_Small", rw - 235, rh/2, gc2, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
                else
                    stxt("Не назначена", "DSA_Small", rw - 285, rh/2, C.DIM, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                end
                outline(0, 0, rw, rh, 50, 65, 120, 80)
            end

            -- Дропдаун выбора группы
            local combo = mkCombo(row, CW - 10 - 200, 6, 140, 30)
            combo:AddChoice("— Без группы —", "")
            local selIdx = 1
            for gi, gt in ipairs(DS.FACTION_GROUP_TYPES) do
                combo:AddChoice(gt.name, gt.name)
                if gt.name == curGroup then selIdx = gi + 1 end
            end
            combo:ChooseOptionID(selIdx)

            -- Кнопка Сохранить
            local cfname = fname
            mkBtn(row, "Сохранить", CW - 10 - 52, 6, 48, 30, Color(35, 105, 55), function()
                local _, grpVal = combo:GetSelected()
                FactionGroups[cfname] = (grpVal ~= "" and grpVal or nil)
                net.Start("DS_FactionGroupSave")
                net.WriteString(cfname)
                net.WriteString(grpVal or "")
                net.SendToServer()
                DS_Notify("Сохранено: " .. cfname, "success")
            end)

            ry = ry + 46
        end
    end

    -- Запросим DS_SyncFactions если список ещё пуст
    timer.Simple(0.5, function()
        if IsValid(panFac) then
            buildFacList()
        end
    end)

    -- Пересобрать список когда придут свежие данные фракций
    hook.Add("DS_FactionGroupsUpdated", "DS_AdminPanel_FacGroups", function()
        if IsValid(panFac) then buildFacList() end
    end)

    switchTab(1)
end

concommand.Add("ds_admin_panel",function()
    if LocalPlayer():IsSuperAdmin() then openAdminPanel()
    else DS_Notify("Только суперадмин","error") end
end)

print("[DoorSystem] Панель администратора v2.0 загружена")
