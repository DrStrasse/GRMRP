--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — HUD + уведомления (клиент)
    Протокол v2: DS_SyncDoor = WriteString(id) + WriteTable(data)
    Поля данных: name, category, access, locked, key_id,
                 owners{}, factions{}, roles{}, wl_count,
                 for_sale, sale_price
--------------------------------------------------------------------]]

-- ─── Локальный кэш ───────────────────────────────────────────────
-- DoorCache[doorID] = полная таблица данных двери
-- doorID вычисляется через DS.DoorID(ent) — та же функция что на сервере
local DoorCache    = {}
local MyKeyRing    = {}   -- [keyID] = {name, r, g, b, owner_steam}
local Categories   = {}   -- [{name,r,g,b}]
local FactionList  = {}   -- [{name, tag, r, g, b}] — приходит через DS_SyncFactions

-- ─── Сетевые приёмники ───────────────────────────────────────────
net.Receive("DS_SyncDoor", function()
    local id   = net.ReadString()
    local data = net.ReadTable()
    if not id or id == "" then return end
    if data and data.reset then
        DoorCache[id] = nil
        return
    end
    if data then
        data.id       = id
        DoorCache[id] = data
    end
end)

net.Receive("DS_SyncAllDoors", function()
    local batch = net.ReadTable()
    DoorCache = {}
    for id, data in pairs(batch or {}) do
        data.id       = id
        DoorCache[id] = data
    end
end)

net.Receive("DS_SyncCategories", function()
    Categories = net.ReadTable() or {}
end)

net.Receive("DS_Keys_Sync", function()
    MyKeyRing = net.ReadTable() or {}
end)

net.Receive("DS_SyncFactions", function()
    FactionList = net.ReadTable() or {}
    hook.Run("DS_FactionsListUpdated", FactionList)
end)

-- Переопределяем DS.GetFactionColor / DS.GetFactionTag для клиента:
-- на клиенте глобальной таблицы Factions нет, используем FactionList.
function DS.GetFactionColor(name)
    for _, f in ipairs(FactionList) do
        if f.name == name then return Color(f.r, f.g, f.b) end
    end
    return Color(160, 160, 160)
end

function DS.GetFactionTag(name)
    for _, f in ipairs(FactionList) do
        if f.name == name then return f.tag end
    end
    return string.upper(string.sub(name or "?", 1, 4))
end

net.Receive("DS_ActionResult", function()
    local ok  = net.ReadBool()
    local msg = net.ReadString()
    DS_Notify(msg, ok and "success" or "error")
end)

net.Receive("DS_DoorDenied", function()
    local reason = net.ReadString()
    net.ReadVector()  -- позиция (не используем на клиенте)
    DS_Notify(reason, "error")
end)

-- ─── Система уведомлений ─────────────────────────────────────────
local _notifQ = {}
function DS_Notify(msg, kind)
    -- Дедупликация
    for _, n in ipairs(_notifQ) do
        if n.msg == msg then n.time = CurTime() + 3.5 return end
    end
    table.insert(_notifQ, { msg=msg, kind=kind, time=CurTime()+3.5 })
    if #_notifQ > 5 then table.remove(_notifQ, 1) end
end

-- ─── Шрифты ──────────────────────────────────────────────────────
surface.CreateFont("DS_H_Title",  {font="Roboto", size=18, weight=700})
surface.CreateFont("DS_H_Sub",    {font="Roboto", size=14, weight=400})
surface.CreateFont("DS_H_Tiny",   {font="Roboto", size=12, weight=400})
surface.CreateFont("DS_H_Hint",   {font="Roboto", size=13, weight=700})
surface.CreateFont("DS_H_Notif",  {font="Roboto", size=15, weight=600})
surface.CreateFont("DS_H_Time",   {font="Roboto", size=12, weight=500})

-- ─── Короткий доступ к цветам ────────────────────────────────────
local C = DS.COL

-- ─── Локальные утилиты (не зависят от порядка загрузки DS) ──────
local DOOR_CLASSES = {
    func_door=true, func_door_rotating=true, func_button=true,
    prop_door_rotating=true, func_movelinear=true,
    func_door_rotating_checkpoint=true,
}

local function localIsDoor(ent)
    return IsValid(ent) and DOOR_CLASSES[ent:GetClass()] == true
end

-- Вычисляет stable ID двери, идентичный серверной DS.DoorID
local function localDoorID(ent)
    if not IsValid(ent) then return nil end
    local hid = ent:MapCreationID()
    if hid and hid > 0 then
        return game.GetMap() .. "_h" .. hid
    end
    return game.GetMap() .. "_e" .. ent:EntIndex()
end

local HUD_RANGE = 180   -- синхронно с DS.HUD_RANGE в sh_door_system.lua

-- ─── Найти дверь перед игроком ───────────────────────────────────
local _lastReq = 0
local _lastEnt = nil

local function getDoorInSight()
    local ply = LocalPlayer()
    if not IsValid(ply) then return nil end
    local tr = util.TraceLine({
        start  = ply:EyePos(),
        endpos = ply:EyePos() + ply:GetAimVector() * HUD_RANGE,
        filter = ply,
        mask   = MASK_ALL,
    })
    if localIsDoor(tr.Entity) then return tr.Entity end
    return nil
end

-- Данные двери по Entity — использует локальный localDoorID, не DS.DoorID
local function doorDataByEnt(ent)
    if not IsValid(ent) then return nil, nil end
    local id = localDoorID(ent)
    if id and DoorCache[id] then return DoorCache[id], id end
    return nil, nil
end

-- Есть ли у нас ключ от этой двери?
-- Ключ привязан к owner_steam (владельцу), а не к door_id.
local function hasKeyFor(doorID)
    local data = DoorCache[doorID]
    local doorOwners = data and data.owners or {}
    for _, k in pairs(MyKeyRing) do
        if k.owner_steam and doorOwners[k.owner_steam] then return true end
    end
    return false
end

-- Цвет категории
local function catColor(catName)
    for _, c in ipairs(Categories) do
        if c.name == catName then return Color(c.r, c.g, c.b) end
    end
    return Color(100, 100, 120)
end

-- ─── Анимация ────────────────────────────────────────────────────
local hudA   = 0   -- текущая прозрачность [0..1]
local hudTgt = 0
local lastData = nil

-- ─── Вспомогательное рисование ───────────────────────────────────
local function rbox(x, y, w, h, r, col) draw.RoundedBox(r, x, y, w, h, col) end
local function txt(s, f, x, y, col, ax, ay)
    draw.SimpleText(s, f, x, y, col, ax or TEXT_ALIGN_LEFT, ay or TEXT_ALIGN_TOP)
end
local function aplha(col, a)
    return Color(col.r, col.g, col.b, math.Clamp(math.floor(a), 0, 255))
end

-- Pill-тег (возвращает ширину)
local function pill(label, x, y, bg, fg, font)
    font = font or "DS_H_Tiny"
    surface.SetFont(font)
    local tw = surface.GetTextSize(label)
    local pw, ph = tw + 14, 16
    rbox(x, y, pw, ph, 8, bg)
    txt(label, font, x + pw/2, y + 1, fg, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    return pw
end

-- Рисуем строку «ключ: иконка + текст»
local function drawKeyLine(x, y, doorID, alpha)
    local has = hasKeyFor(doorID)
    local col = has and aplha(C.KEY, alpha) or aplha(C.DANGER, alpha)
    local lbl = has and "  Ключ есть" or "  Нет ключа"
    txt(lbl, "DS_H_Tiny", x, y, col)
end

-- ─── Основной HUD hook ───────────────────────────────────────────
hook.Add("HUDPaint", "DS_HUD", function()
    local sw, sh = ScrW(), ScrH()
    local now    = CurTime()

    -- ── Уведомления (верхняя правая часть экрана) ────────────────
    local ny = sh - 170
    for i = #_notifQ, 1, -1 do
        local n = _notifQ[i]
        if now > n.time then table.remove(_notifQ, i); goto cont end
        local fade   = math.Clamp((n.time - now) / 0.5, 0, 1)
        local nalpha = math.floor(fade * 240)
        surface.SetFont("DS_H_Notif")
        local tw = surface.GetTextSize(n.msg)
        local nw = tw + 32
        local nx = sw - nw - 16
        local nh = 28
        local bg = n.kind == "success" and Color(25,100,55,nalpha) or Color(120,30,30,nalpha)
        rbox(nx, ny, nw, nh, 7, bg)
        surface.SetDrawColor(n.kind == "success" and 50 or 200, n.kind == "success" and 200 or 60, 60, nalpha)
        surface.DrawOutlinedRect(nx, ny, nw, nh, 1)
        txt(n.msg, "DS_H_Notif", nx + nw/2, ny + 5, Color(240,245,255,nalpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        ny = ny - 34
        ::cont::
    end

    -- ── Скрываем панель двери если открыто меню или держим SWEP ──
    -- (SWEP рисует свой собственный блок подсказок — дублировать не нужно)
    do
        local lp = LocalPlayer()
        if not IsValid(lp) then return end
        local wep = lp:GetActiveWeapon()
        if IsValid(wep) and wep:GetClass() == "ds_key_swep" then return end
        if DS_IsMenuOpen and DS_IsMenuOpen() then return end
    end

    -- ── Дверь перед игроком ─────────────────────────────────────
    local ent    = getDoorInSight()
    hudTgt       = IsValid(ent) and 1 or 0
    hudA         = Lerp(FrameTime() * 9, hudA, hudTgt)
    if hudA < 0.015 then return end

    -- Данные (мультивозврат через if, не через and)
    local data, doorID
    if IsValid(ent) then
        data, doorID = doorDataByEnt(ent)
    end

    if not data and IsValid(ent) then
        -- Запросить данные если ещё нет в кэше
        if now - _lastReq > 1 and ent ~= _lastEnt then
            _lastReq = now
            _lastEnt = ent
            net.Start("DS_RequestDoorData")
            net.WriteInt(ent:EntIndex(), 16)
            net.SendToServer()
        end
        -- Показать заглушку пока данные грузятся
        if lastData then
            data   = lastData
            doorID = lastData.id
        else
            return
        end
    else
        if data then lastData = data; doorID = data.id end
    end

    -- Если нет никаких данных — выходим
    if not data then return end
    doorID = doorID or (data and data.id)

    -- ── Размеры и позиция панели ─────────────────────────────────
    local alpha = hudA * 255
    local W, H  = 296, 170
    local px    = sw / 2 - W / 2
    local py    = sh * 0.58

    -- Тень
    rbox(px + 3, py + 3, W, H, 10, Color(0,0,0, math.floor(alpha * 0.4)))
    -- Фон
    rbox(px, py, W, H, 10, aplha(C.BG, alpha * 0.92))
    -- Рамка
    surface.SetDrawColor(C.BORDER.r, C.BORDER.g, C.BORDER.b, math.floor(alpha * 0.8))
    surface.DrawOutlinedRect(px, py, W, H, 1)

    -- Цветная полоса (категория или фракция)
    local accent = C.ACCENT
    local facs   = data.factions
    if facs and #facs > 0 then
        accent = DS.GetFactionColor(facs[1])
    elseif data.category then
        accent = catColor(data.category)
    end
    rbox(px, py, W, 4, 2, aplha(accent, alpha))

    -- ── Строка 1: Замок + Имя + Статус ───────────────────────────
    local lockStr  = data.locked and "[ ЗАМОК ]" or "[ ОТКРЫТО ]"
    local lockCol  = data.locked and aplha(C.DANGER, alpha) or aplha(C.SUCCESS, alpha)
    local doorName = (data.name and data.name ~= "") and data.name or "Дверь"

    txt(doorName, "DS_H_Title", px + 12, py + 10, aplha(C.TEXT, alpha))
    txt(lockStr, "DS_H_Tiny", px + W - 10, py + 13, lockCol, TEXT_ALIGN_RIGHT)

    -- Категория
    if data.category and data.category ~= "" then
        local cc = catColor(data.category)
        pill(data.category, px + 12, py + 32, Color(cc.r,cc.g,cc.b, math.floor(alpha*0.25)),
             Color(cc.r,cc.g,cc.b, math.floor(alpha)), "DS_H_Tiny")
    end

    -- ── Разделитель ──────────────────────────────────────────────
    surface.SetDrawColor(C.BORDER.r, C.BORDER.g, C.BORDER.b, math.floor(alpha*0.6))
    surface.DrawRect(px+10, py+52, W-20, 1)

    -- ── Строка владельцев ────────────────────────────────────────
    local owners = data.owners or {}
    local ownerNicks = {}
    for steam, o in pairs(owners) do
        if o.owner_type == DS.OWNER_TYPE.OWNER then
            table.insert(ownerNicks, 1, o.nick or steam)
        else
            table.insert(ownerNicks, (o.nick or steam) .. " (сов.)")
        end
    end

    local ownerTxt = #ownerNicks > 0 and table.concat(ownerNicks, ", ") or "Нет владельца"
    -- Обрезаем длинное имя
    if #ownerTxt > 34 then ownerTxt = string.sub(ownerTxt, 1, 31) .. "..." end
    txt("Владелец: " .. ownerTxt, "DS_H_Sub", px+12, py+58, aplha(C.DIM, alpha))

    -- Срок аренды (если есть)
    local mySteam = LocalPlayer():SteamID()
    local myOwn   = owners[mySteam]
    if myOwn and myOwn.expires_at and myOwn.expires_at > 0 then
        local left = DS.TimeLeft(myOwn.expires_at)
        local tCol = left < 3600 and aplha(C.WARNING, alpha) or aplha(C.SUCCESS, alpha)
        txt("Срок: " .. DS.FormatTime(left), "DS_H_Time", px+12, py+76, tCol)
    end

    -- Тип доступа
    txt("Доступ: " .. DS.AccessLabel(data.access), "DS_H_Sub", px+12, py+94, aplha(C.DIM, alpha))

    -- Теги фракций
    if facs and #facs > 0 then
        local tx = px + 12
        local ty = py + 112
        for i, fname in ipairs(facs) do
            if tx > px + W - 20 then break end
            local fc  = DS.GetFactionColor(fname)
            local tag = DS.GetFactionTag(fname)
            local pw  = pill(tag, tx, ty,
                Color(fc.r,fc.g,fc.b, math.floor(alpha*0.25)),
                Color(fc.r,fc.g,fc.b, math.floor(alpha)), "DS_H_Tiny")
            tx = tx + pw + 5
        end
    end

    -- Ключ
    if data.access == DS.ACCESS.KEY and doorID then
        drawKeyLine(px+12, py+130, doorID, alpha)
    end

    -- (строка "Продаётся: N $" убрана — валюты нет, только аренда)

    -- ── Подсказки (авто-ширина бейджей, без наслоений) ───────────
    surface.SetDrawColor(C.BORDER.r, C.BORDER.g, C.BORDER.b, math.floor(alpha*0.5))
    surface.DrawRect(px+10, py+H-24, W-20, 1)

    local hints = {
        { key="E",  text="Открыть" },
        { key="F4", text="Меню"    },
        { key="G",  text="Замок"   },
    }
    local hBH = 14   -- высота бейджа
    local hY  = py + H - 19
    local hx  = px + 10
    local col255 = Color(255,255,255,math.floor(alpha))
    local colDim = aplha(C.DIM, alpha)
    local colBox = Color(55,70,130, math.floor(alpha*0.8))

    for _, h in ipairs(hints) do
        -- Измеряем ширину текста ключа
        surface.SetFont("DS_H_Hint")
        local kw = surface.GetTextSize(h.key)
        local bw = kw + 10   -- отступы по 5px с каждой стороны
        -- Бейдж
        rbox(hx, hY, bw, hBH, 3, colBox)
        txt(h.key, "DS_H_Hint", hx + bw/2, hY + 1,
            col255, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        -- Метка
        txt(h.text, "DS_H_Tiny", hx + bw + 5, hY + 1, colDim)
        -- Сдвигаемся вправо
        surface.SetFont("DS_H_Tiny")
        local lw = surface.GetTextSize(h.text)
        hx = hx + bw + lw + 14
    end
end)

-- ─── F4 — простое меню (все игроки) ──────────────────────────────
-- Только: приобрести дверь / дать имя / продать дверь.
hook.Add("PlayerButtonDown", "DS_HUD_F4", function(ply, btn)
    if btn ~= KEY_F4 then return end
    local ent = getDoorInSight()
    if not IsValid(ent) then return end
    if DS_OpenSimpleMenu then DS_OpenSimpleMenu(ent) end
end)

-- ─── F — расширенные настройки (ТОЛЬКО superadmin) ──────────────
-- Обычные игроки и admin не имеют доступа к расширенному меню.
-- Если игрока разжаловали до user — меню закрывается автоматически.
hook.Add("PlayerButtonDown", "DS_HUD_F", function(ply, btn)
    if btn ~= KEY_F then return end
    local lp = LocalPlayer()
    if not IsValid(lp) then return end

    -- Сначала проверяем дверь: без двери F ничего не делает
    local ent = getDoorInSight()
    if not IsValid(ent) then return end

    if not lp:IsSuperAdmin() then
        DS_Notify("Расширенные настройки — только для суперадмина", "error")
        return
    end

    if DS_OpenDoorMenu then DS_OpenDoorMenu(ent) end
end)

-- ─── Принудительное закрытие меню с сервера ──────────────────────
net.Receive("DS_ForceCloseMenu", function()
    if DS_IsMenuOpen and DS_IsMenuOpen() then
        -- Закрываем только расширенное (FullMenu), не SimpleMenu
        if DS_CloseMenuIfNoPerms then DS_CloseMenuIfNoPerms() end
    end
    DS_Notify("Меню закрыто: права изменены", "error")
end)

-- ─── Постоянная проверка: если не superadmin — закрыть FullMenu ───
local _prevSA   = false
local _saCheck  = 0
hook.Add("Think", "DS_PermWatch", function()
    local now = CurTime()
    if now - _saCheck < 1 then return end  -- проверять раз в секунду
    _saCheck = now

    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local nowSA = ply:IsSuperAdmin()

    if _prevSA ~= nowSA then
        _prevSA = nowSA
        -- Ранг упал — закрыть расширенное меню немедленно
        if not nowSA then
            if DS_CloseMenuIfNoPerms then DS_CloseMenuIfNoPerms() end
            if DS_IsMenuOpen and DS_IsMenuOpen() then
                DS_Notify("Права изменены — меню закрыто", "error")
            end
        end
    end
end)

-- ─── G — быстрый замок ───────────────────────────────────────────
hook.Add("PlayerButtonDown", "DS_HUD_Q", function(ply, btn)
    if btn ~= KEY_G then return end
    local lp = LocalPlayer()
    if not IsValid(lp) then return end
    local ent = getDoorInSight()
    if not IsValid(ent) then return end
    local data, id = doorDataByEnt(ent)
    if not data then return end
    local mySteam = lp:SteamID()
    local owns = data.owners or {}
    -- Владелец/совладелец или admin — пропускаем сразу
    -- Для фракционных дверей (access == faction/faction_role) — тоже пропускаем
    -- (сервер сделает финальную проверку через DS.CanLock)
    local isFactionDoor = data.access == DS.ACCESS.FACTION or
                          data.access == DS.ACCESS.FACTION_ROLE
    if not owns[mySteam] and not lp:IsAdmin() and not isFactionDoor then return end
    net.Start("DS_LockDoor")
    net.WriteInt(ent:EntIndex(), 16)
    net.SendToServer()
end)

-- ─── Экспортировать вспомогательные функции для меню ─────────────
function DS_GetDoorCache()    return DoorCache end
function DS_GetDoorByEnt(ent) return doorDataByEnt(ent) end
function DS_GetMyKeyRing()    return MyKeyRing end
function DS_GetCategories()   return Categories end

print("[DoorSystem] HUD v2.0 загружен")
