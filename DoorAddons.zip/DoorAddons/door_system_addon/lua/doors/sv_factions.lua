--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Синхронизация фракций с клиентом
    Читает напрямую из глобальной таблицы Factions (система фракций).
    Не зависит от factions.json — данные всегда актуальны.
    Автоматически переотправляет клиентам при вызове broadcastFactionData().
--------------------------------------------------------------------]]

-- Сетевые строки уже объявлены в sv_core.lua через NETS-таблицу,
-- но добавим guard на случай отдельной загрузки
if not util.NetworkStringToID("DS_SyncFactions") or
   util.NetworkStringToID("DS_SyncFactions") == 0 then
    util.AddNetworkString("DS_SyncFactions")
end
if not util.NetworkStringToID("DS_RequestWhitelist") or
   util.NetworkStringToID("DS_RequestWhitelist") == 0 then
    util.AddNetworkString("DS_RequestWhitelist")
end
if not util.NetworkStringToID("DS_SyncWhitelist") or
   util.NetworkStringToID("DS_SyncWhitelist") == 0 then
    util.AddNetworkString("DS_SyncWhitelist")
end

-- ─── Построить список фракций из живой таблицы Factions ───────────
-- Вызывается каждый раз при необходимости — данные всегда свежие.
local function buildFactionList()
    local list = {}
    local src  = Factions  -- глобальная таблица из системы фракций

    if not istable(src) then
        print("[DS] Предупреждение: Factions ещё не загружен")
        return list
    end

    for name, fdata in pairs(src) do
        if type(fdata) == "table" then
            local col = istable(fdata.Color) and fdata.Color or {}
            local tag = fdata.Tag
            if type(tag) ~= "string" or tag == "" then
                tag = string.upper(string.sub(name, 1, 4))
            end
            table.insert(list, {
                name = name,
                tag  = tag,
                r    = tonumber(col.r) or 160,
                g    = tonumber(col.g) or 160,
                b    = tonumber(col.b) or 160,
            })
        end
    end

    table.sort(list, function(a, b) return a.name < b.name end)
    return list
end

-- ─── Отправить список фракций одному игроку ───────────────────────
local function syncFactions(ply)
    if not IsValid(ply) then return end
    net.Start("DS_SyncFactions")
    net.WriteTable(buildFactionList())
    net.Send(ply)
end

-- ─── Разослать всем ───────────────────────────────────────────────
local function syncFactionsAll()
    local list = buildFactionList()
    net.Start("DS_SyncFactions")
    net.WriteTable(list)
    net.Broadcast()
    print("[DS] Фракции синхронизированы: " .. #list .. " шт.")
end

-- ─── При входе игрока — слать через 3 с (после инициализации) ──────
hook.Add("PlayerInitialSpawn", "DS_FactionSync", function(ply)
    timer.Simple(3, function()
        if IsValid(ply) then syncFactions(ply) end
    end)
end)

-- ─── Перехват broadcastFactionData из системы фракций ─────────────
-- Когда фракционный аддон меняет данные и вызывает broadcastFactionData(),
-- дверной системе нужно переотправить свой список клиентам.
-- Ждём до следующего тика, чтобы Factions уже обновился.
hook.Add("InitPostEntity", "DS_WrapBroadcastFactions", function()
    if type(broadcastFactionData) == "function" then
        local _orig = broadcastFactionData
        function broadcastFactionData()
            _orig()  -- оригинальная рассылка фракционного аддона
            timer.Simple(0.1, syncFactionsAll)  -- наша рассылка следом
        end
        print("[DS] broadcastFactionData перехвачен для синхронизации дверей")
    else
        print("[DS] Предупреждение: broadcastFactionData не найден — синхронизация только при входе")
    end
end)

-- ─── Команда ручной перезагрузки ──────────────────────────────────
concommand.Add("ds_reload_factions", function(ply)
    if IsValid(ply) and not ply:IsAdmin() then return end
    syncFactionsAll()
end)

-- ─── Whitelist: отдать содержимое одному игроку ───────────────────
net.Receive("DS_RequestWhitelist", function(_, ply)
    local doorID = net.ReadString()
    if not doorID or doorID == "" then return end

    -- Только владелец или суперадмин
    local isAuth = ply:IsAdmin() or
                   (DS.Cache.owners[doorID] and DS.Cache.owners[doorID][ply:SteamID()])
    if not isAuth then return end

    local wl  = DS.Cache.whitelist[doorID] or {}
    local out = {}
    for steam, nick in pairs(wl) do
        table.insert(out, { steam = steam, nick = nick })
    end

    net.Start("DS_SyncWhitelist")
    net.WriteString(doorID)
    net.WriteTable(out)
    net.Send(ply)
end)

-- ─── Уведомление об изменении whitelist ───────────────────────────
hook.Add("DS_WhitelistChanged", "DS_WL_Notify", function(doorID)
    if not DS.Cache.owners[doorID] then return end
    for steam in pairs(DS.Cache.owners[doorID]) do
        local owner = player.GetBySteamID(steam)
        if IsValid(owner) then
            local wl  = DS.Cache.whitelist[doorID] or {}
            local out = {}
            for s, n in pairs(wl) do table.insert(out, { steam = s, nick = n }) end
            net.Start("DS_SyncWhitelist")
            net.WriteString(doorID)
            net.WriteTable(out)
            net.Send(owner)
        end
    end
end)

print("[DS] Faction sync + Whitelist net загружены")
