--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Группировка func_button с дверями

    При захвате двери автоматически сканирует радиус BUTTON_RADIUS
    и привязывает ближайшие func_button к этой двери.
    Привязанные кнопки:
      • блокируются, если дверь заперта / режим доступа = private
      • разблокируются, когда у игрока есть доступ к двери

    Хранение: таблица DS.ButtonLinks[doorID] = {entIndex, ...}
    Персистентность: SQLite (ds_button_links)
--------------------------------------------------------------------]]

local BUTTON_RADIUS = 200   -- единицы GMod (~200 = ~2 метра)

local function q(s)   return sql.Query(s) end
local function esc(s) return sql.SQLStr(tostring(s or "")) end

-- ─── Создать таблицу ─────────────────────────────────────────────
q([[CREATE TABLE IF NOT EXISTS ds_button_links (
    door_id    TEXT NOT NULL,
    map        TEXT NOT NULL,
    hammer_id  INTEGER DEFAULT 0,
    ent_class  TEXT DEFAULT 'func_button',
    PRIMARY KEY (door_id, hammer_id)
)]])

DS.ButtonLinks = DS.ButtonLinks or {}   -- [doorID] = [{hammerID, entIdx}]

-- ─── Загрузить ссылки из БД ──────────────────────────────────────
local function loadLinks()
    DS.ButtonLinks = {}
    local rows = q("SELECT * FROM ds_button_links WHERE map=" .. esc(game.GetMap()))
    if not rows then return end
    for _, row in ipairs(rows) do
        DS.ButtonLinks[row.door_id] = DS.ButtonLinks[row.door_id] or {}
        table.insert(DS.ButtonLinks[row.door_id], {
            hammerID = tonumber(row.hammer_id) or 0,
            entIdx   = nil,   -- заполним при запуске
        })
    end
end

loadLinks()

-- ─── Связать Entity-индексы с сохранёнными hammerID ──────────────
local function resolveEntIndices()
    for doorID, links in pairs(DS.ButtonLinks) do
        for _, link in ipairs(links) do
            if link.hammerID > 0 then
                for _, ent in ipairs(ents.FindByClass("func_button")) do
                    if ent:MapCreationID() == link.hammerID then
                        link.entIdx = ent:EntIndex()
                        break
                    end
                end
            end
        end
    end
end

hook.Add("InitPostEntity", "DS_Buttons_Resolve", function()
    timer.Simple(1.5, resolveEntIndices)
end)

-- ─── Сканировать кнопки рядом с дверью ───────────────────────────
local function scanButtons(doorEnt, doorID)
    local pos     = doorEnt:GetPos()
    local found   = {}
    local existing = {}

    -- Текущие сохранённые
    for _, lnk in ipairs(DS.ButtonLinks[doorID] or {}) do
        existing[lnk.hammerID] = true
    end

    for _, btn in ipairs(ents.FindByClass("func_button")) do
        if IsValid(btn) and btn:GetPos():Distance(pos) <= BUTTON_RADIUS then
            local hid = btn:MapCreationID()
            if hid and hid > 0 and not existing[hid] then
                table.insert(found, { hammerID=hid, entIdx=btn:EntIndex() })
                q("INSERT OR IGNORE INTO ds_button_links(door_id,map,hammer_id,ent_class) VALUES("
                  .. esc(doorID) .. "," .. esc(game.GetMap()) .. "," .. hid .. ",'func_button')")
            end
        end
    end

    DS.ButtonLinks[doorID] = DS.ButtonLinks[doorID] or {}
    for _, lnk in ipairs(found) do
        table.insert(DS.ButtonLinks[doorID], lnk)
    end

    return #found
end

-- ─── Вызывается при захвате двери ────────────────────────────────
function DS.ScanAndLinkButtons(doorEnt, doorID)
    if not IsValid(doorEnt) then return end
    local n = scanButtons(doorEnt, doorID)
    if n > 0 then
        print("[DS] Привязано кнопок к " .. doorID .. ": " .. n)
    end
end

-- ─── Убрать привязки (при reset двери) ───────────────────────────
function DS.UnlinkButtons(doorID)
    DS.ButtonLinks[doorID] = nil
    q("DELETE FROM ds_button_links WHERE door_id=" .. esc(doorID))
end

-- ─── Найти дверь по кнопке ───────────────────────────────────────
local function getDoorForButton(btn)
    if not IsValid(btn) then return nil, nil end
    local hid = btn:MapCreationID()
    if not hid then return nil, nil end
    for doorID, links in pairs(DS.ButtonLinks) do
        for _, lnk in ipairs(links) do
            if lnk.hammerID == hid then return doorID, lnk end
        end
    end
    return nil, nil
end

-- ─── Блокировать использование привязанной кнопки ────────────────
hook.Add("PlayerUse", "DS_ButtonUseHook", function(ply, ent)
    if not IsValid(ent) or ent:GetClass() ~= "func_button" then return end
    local doorID, _ = getDoorForButton(ent)
    if not doorID then return end   -- кнопка не привязана — пропускаем

    local rec = DS.Cache.doors[doorID]
    if not rec then return end

    -- Проверить доступ как к двери
    -- Найти Entity двери для CanUse (нужна реальная дверь)
    -- Найдём по doorID
    local doorEnt = nil
    for _, e in ipairs(ents.GetAll()) do
        if DS.IsDoor(e) and DS.DoorID(e) == doorID then
            doorEnt = e
            break
        end
    end

    if IsValid(doorEnt) and not DS.CanUse(ply, doorEnt) then
        ply:EmitSound(DS.SND.DENY, 65, 100, 0.7)
        net.Start("DS_DoorDenied")
        net.WriteString("Доступ к кнопке заблокирован")
        net.WriteVector(ent:GetPos())
        net.Send(ply)
        return false
    end
end)

-- ─── Автоматическое сканирование при захвате двери ───────────────
-- Перехватываем claim из sv_core.lua через хук
hook.Add("DS_DoorClaimed", "DS_AutoScanButtons", function(doorID, doorEnt)
    DS.ScanAndLinkButtons(doorEnt, doorID)
end)

-- ─── Конзольная команда: ручная привязка ─────────────────────────
concommand.Add("ds_link_buttons", function(ply, _, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    local entIdx = tonumber(args[1])
    local doorEnt = entIdx and Entity(entIdx)
    if not IsValid(doorEnt) or not DS.IsDoor(doorEnt) then
        print("[DS] ds_link_buttons <entindex> — укажите EntIndex двери")
        return
    end
    local doorID = DS.DoorID(doorEnt)
    local n = scanButtons(doorEnt, doorID)
    print("[DS] Привязано кнопок: " .. n)
end)

print("[DoorSystem] Кнопки (func_button) v2.0 загружены")
