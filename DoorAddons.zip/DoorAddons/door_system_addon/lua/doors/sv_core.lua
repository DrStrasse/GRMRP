--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Серверное ядро
    
    • SQLite-хранилище (7 таблиц)
    • Автосканирование дверей карты при инициализации
    • Одиночные и групповые владельцы (owner/coowner)
    • Временная аренда с автоистечением
    • Категории дверей
    • Полная синхронизация с клиентами
--------------------------------------------------------------------]]

-- ─── Сетевые строки ──────────────────────────────────────────────
local NETS = {
    "DS_SyncDoor", "DS_SyncAllDoors", "DS_SyncCategories",
    "DS_RequestDoorData", "DS_SetDoorData", "DS_ActionResult",
    "DS_LockDoor", "DS_DoorDenied", "DS_AcquireDoor",
    "DS_AdminSync", "DS_AdminAction", "DS_AdminReset",
    "DS_AdminSetCategory", "DS_AdminSetOwner", "DS_CategoryList",
    "DS_DoorScan", "DS_RenewOwnership",
    -- Фракции и whitelist
    "DS_SyncFactions", "DS_RequestWhitelist", "DS_SyncWhitelist",
    -- Группы фракций
    "DS_FactionGroupSave", "DS_FactionGroupsSync",
    -- Принудительное закрытие меню
    "DS_ForceCloseMenu",
    -- Кнопки
    "DS_ButtonLinked",
}
for _, n in ipairs(NETS) do util.AddNetworkString(n) end

-- ─── SQL: инициализация схемы ─────────────────────────────────────
local function q(stmt) return sql_Exec and sql_Exec(stmt) or sql.Query(stmt) end
local function qv(stmt) return sql.QueryValue(stmt) end
local function esc(s) return sql.SQLStr(tostring(s or "")) end

local function initDB()
    q([[CREATE TABLE IF NOT EXISTS ds_doors (
        id         TEXT PRIMARY KEY,
        map        TEXT NOT NULL DEFAULT '',
        name       TEXT DEFAULT '',
        category   TEXT DEFAULT 'Без категории',
        access     TEXT DEFAULT 'public',
        locked     INTEGER DEFAULT 0,
        key_id     TEXT DEFAULT '',
        sale_price INTEGER DEFAULT 0,
        for_sale   INTEGER DEFAULT 0,
        updated_at INTEGER DEFAULT 0
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_owners (
        door_id    TEXT NOT NULL,
        steam_id   TEXT NOT NULL,
        nick       TEXT DEFAULT '',
        owner_type TEXT DEFAULT 'owner',
        expires_at INTEGER DEFAULT 0,
        acquired   INTEGER DEFAULT 0,
        PRIMARY KEY (door_id, steam_id)
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_factions (
        door_id  TEXT NOT NULL,
        faction  TEXT NOT NULL,
        PRIMARY KEY (door_id, faction)
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_roles (
        door_id TEXT NOT NULL,
        faction TEXT NOT NULL,
        role    TEXT NOT NULL,
        PRIMARY KEY (door_id, faction, role)
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_whitelist (
        door_id  TEXT NOT NULL,
        steam_id TEXT NOT NULL,
        nick     TEXT DEFAULT '',
        PRIMARY KEY (door_id, steam_id)
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_categories (
        name  TEXT PRIMARY KEY,
        col_r INTEGER DEFAULT 100,
        col_g INTEGER DEFAULT 100,
        col_b INTEGER DEFAULT 120
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_keys (
        id           TEXT PRIMARY KEY,
        owner_steam  TEXT NOT NULL,
        name         TEXT DEFAULT '',
        col_r        INTEGER DEFAULT 255,
        col_g        INTEGER DEFAULT 215,
        col_b        INTEGER DEFAULT 0,
        created_at   INTEGER DEFAULT 0
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_player_keys (
        steam_id TEXT NOT NULL,
        key_id   TEXT NOT NULL,
        PRIMARY KEY (steam_id, key_id)
    )]])

    q([[CREATE TABLE IF NOT EXISTS ds_faction_groups (
        faction    TEXT PRIMARY KEY,
        group_name TEXT NOT NULL DEFAULT ''
    )]])

    -- Встроенные категории (если не существуют)
    for _, cat in ipairs(DS.DEFAULT_CATEGORIES) do
        local exists = qv("SELECT name FROM ds_categories WHERE name=" .. esc(cat.name))
        if not exists then
            q("INSERT INTO ds_categories(name,col_r,col_g,col_b) VALUES(" ..
              esc(cat.name) .. "," .. cat.r .. "," .. cat.g .. "," .. cat.b .. ")")
        end
    end

    print("[DS] База данных инициализирована")
end

initDB()

-- ─── Кэш в памяти (для быстрого доступа без SQL-запросов) ────────
DS.Cache = {
    doors         = {},  -- [doorID] = { id, name, category, access, locked, ... }
    owners        = {},  -- [doorID] = { [steamID] = {nick, type, expires, acquired} }
    factions      = {},  -- [doorID] = { faction1, faction2, ... }
    roles         = {},  -- [doorID] = { [faction] = { role1, role2 } }
    whitelist     = {},  -- [doorID] = { [steamID] = nick }
    categories    = {},  -- { {name, r, g, b}, ... }
    keys          = {},  -- [keyID] = { door_id, name, ... }
    rings         = {},  -- [steamID] = { keyID, ... }
    factionGroups = {},  -- [factionName] = groupName
}

-- ─── Загрузка кэша из БД ─────────────────────────────────────────
local function loadCache()
    -- Двери
    local rows = sql.Query("SELECT * FROM ds_doors WHERE map=" .. esc(game.GetMap()))
    if rows then
        for _, row in ipairs(rows) do
            DS.Cache.doors[row.id] = {
                id        = row.id,
                name      = row.name,
                category  = row.category,
                access    = row.access,
                locked    = tobool(row.locked),
                key_id    = row.key_id,
                sale_price= tonumber(row.sale_price) or 0,
                for_sale  = tobool(row.for_sale),
            }
            DS.Cache.owners[row.id]   = {}
            DS.Cache.factions[row.id] = {}
            DS.Cache.roles[row.id]    = {}
            DS.Cache.whitelist[row.id]= {}
        end
    end

    -- Владельцы
    local owns = sql.Query("SELECT * FROM ds_owners")
    if owns then
        for _, row in ipairs(owns) do
            if DS.Cache.owners[row.door_id] then
                DS.Cache.owners[row.door_id][row.steam_id] = {
                    nick       = row.nick,
                    owner_type = row.owner_type,
                    expires_at = tonumber(row.expires_at) or 0,
                    acquired   = tonumber(row.acquired) or 0,
                }
            end
        end
    end

    -- Фракции
    local facs = sql.Query("SELECT * FROM ds_factions")
    if facs then
        for _, row in ipairs(facs) do
            if DS.Cache.factions[row.door_id] then
                table.insert(DS.Cache.factions[row.door_id], row.faction)
            end
        end
    end

    -- Роли
    local roles = sql.Query("SELECT * FROM ds_roles")
    if roles then
        for _, row in ipairs(roles) do
            if DS.Cache.roles[row.door_id] then
                DS.Cache.roles[row.door_id][row.faction] = DS.Cache.roles[row.door_id][row.faction] or {}
                table.insert(DS.Cache.roles[row.door_id][row.faction], row.role)
            end
        end
    end

    -- Whitelist
    local wl = sql.Query("SELECT * FROM ds_whitelist")
    if wl then
        for _, row in ipairs(wl) do
            if DS.Cache.whitelist[row.door_id] then
                DS.Cache.whitelist[row.door_id][row.steam_id] = row.nick
            end
        end
    end

    -- Категории
    local cats = sql.Query("SELECT * FROM ds_categories ORDER BY name")
    DS.Cache.categories = {}
    if cats then
        for _, row in ipairs(cats) do
            table.insert(DS.Cache.categories, {
                name = row.name,
                r    = tonumber(row.col_r) or 100,
                g    = tonumber(row.col_g) or 100,
                b    = tonumber(row.col_b) or 120,
            })
        end
    end

    -- Ключи (owner_steam = кто выдал, ключ открывает ВСЕ двери этого владельца)
    local keys = sql.Query("SELECT * FROM ds_keys")
    if keys then
        for _, row in ipairs(keys) do
            DS.Cache.keys[row.id] = {
                owner_steam = row.owner_steam,
                name        = row.name,
                r           = tonumber(row.col_r) or 255,
                g           = tonumber(row.col_g) or 215,
                b           = tonumber(row.col_b) or 0,
            }
        end
    end

    -- Кольца ключей
    local rings = sql.Query("SELECT * FROM ds_player_keys")
    if rings then
        for _, row in ipairs(rings) do
            DS.Cache.rings[row.steam_id] = DS.Cache.rings[row.steam_id] or {}
            table.insert(DS.Cache.rings[row.steam_id], row.key_id)
        end
    end

    -- Группы фракций
    DS.Cache.factionGroups = {}
    local fgs = sql.Query("SELECT * FROM ds_faction_groups")
    if fgs then
        for _, row in ipairs(fgs) do
            DS.Cache.factionGroups[row.faction] = row.group_name
        end
    end

    print("[DS] Кэш загружен: " .. table.Count(DS.Cache.doors) .. " дверей, " ..
          #DS.Cache.categories .. " категорий")
end

loadCache()

-- DS.DoorID определена в sh_door_system.lua (shared) — не дублируем

-- ─── Физически запереть / отпереть дверь в движке GMod ───────────
-- Вызывай каждый раз при изменении rec.locked.
-- func_button и func_movelinear блокируются только через PlayerUse hook.
local function findDoorEnt(id)
    for _, cls in ipairs(DS.DOOR_CLASSES) do
        for _, ent in ipairs(ents.FindByClass(cls)) do
            if IsValid(ent) and DS.DoorID(ent) == id then
                return ent
            end
        end
    end
    return nil
end

local function applyLockState(id, locked)
    local ent = findDoorEnt(id)
    if not IsValid(ent) then return end
    local cls = ent:GetClass()
    if cls == "func_door" or cls == "func_door_rotating" or
       cls == "func_door_rotating_checkpoint" then
        ent:Fire(locked and "Lock" or "Unlock", "", 0)
    elseif cls == "prop_door_rotating" then
        ent:SetSaveValue("m_bLocked", locked)
        if locked then ent:Fire("Close", "", 0) end
    end
    -- func_movelinear и func_button — только через PlayerUse return false
end

-- Экспортируем чтобы SWEP мог вызывать напрямую
DS.ApplyLockState = applyLockState

-- ─── Убедиться, что запись о двери существует ─────────────────────
local function ensureDoor(ent)
    local id = DS.DoorID(ent)
    if not id then return nil end
    if not DS.Cache.doors[id] then
        DS.Cache.doors[id]     = { id=id, name="", category="Без категории",
            access=DS.ACCESS.PUBLIC, locked=false, key_id="", sale_price=0, for_sale=false }
        DS.Cache.owners[id]    = {}
        DS.Cache.factions[id]  = {}
        DS.Cache.roles[id]     = {}
        DS.Cache.whitelist[id] = {}
        q("INSERT OR IGNORE INTO ds_doors(id,map,updated_at) VALUES(" ..
          esc(id) .. "," .. esc(game.GetMap()) .. "," .. os.time() .. ")")
    end
    return id
end

-- ─── Автосканирование дверей карты ───────────────────────────────
local function scanMapDoors()
    local count = 0
    for _, ent in ipairs(ents.GetAll()) do
        if DS.IsDoor(ent) then
            local id = ensureDoor(ent)
            -- Восстановить физическое состояние замка из кэша
            if id and DS.Cache.doors[id] and DS.Cache.doors[id].locked then
                applyLockState(id, true)
            end
            count = count + 1
        end
    end
    print("[DS] Отсканировано дверей карты: " .. count)
    return count
end

hook.Add("InitPostEntity", "DS_ScanDoors", function()
    timer.Simple(1, scanMapDoors)
end)

-- Повторное сканирование при появлении новой двери
hook.Add("OnEntityCreated", "DS_TrackNewDoor", function(ent)
    timer.Simple(0.1, function()
        if IsValid(ent) and DS.IsDoor(ent) then
            ensureDoor(ent)
        end
    end)
end)

-- ─── Получить запись двери из кэша ───────────────────────────────
function DS.GetDoor(ent)
    local id = DS.DoorID(ent)
    return id and DS.Cache.doors[id], id
end

-- ─── Проверка: является ли игрок владельцем ───────────────────────
function DS.IsOwner(steam, doorID, checkCoowner)
    local owners = DS.Cache.owners[doorID]
    if not owners then return false end
    local entry = owners[steam]
    if not entry then return false end
    -- Проверить срок
    if entry.expires_at and entry.expires_at > 0 and os.time() > entry.expires_at then
        DS.RevokeOwner(doorID, steam)
        return false
    end
    if checkCoowner then return true end
    return entry.owner_type == DS.OWNER_TYPE.OWNER
end

-- ─── Получить фракцию/роль игрока ────────────────────────────────
function DS.GetPlayerFaction(ply)
    if not IsValid(ply) then return nil, nil, nil end
    local steam = ply:SteamID()
    for name, f in pairs(Factions or {}) do
        if istable(f) and istable(f.Members) and f.Members[steam] then
            local m = f.Members[steam]
            return name, m.Role, m.Department
        end
    end
    return nil, nil, nil
end

-- ─── Проверка права на блокировку/разблокировку двери ───────────
-- Владелец и совладелец могут всегда.
-- Для фракционных дверей — члены допущенных фракций тоже могут.
function DS.CanLock(ply, id)
    if not IsValid(ply) then return false end
    if ply:IsSuperAdmin() then return true end
    local steam = ply:SteamID()
    -- Личный владелец/совладелец
    if DS.IsOwner(steam, id, true) then return true end
    -- Фракционный доступ: проверить членство
    local rec = DS.Cache.doors[id]
    if not rec then return false end
    if rec.access == DS.ACCESS.FACTION or rec.access == DS.ACCESS.FACTION_ROLE then
        local faction, role = DS.GetPlayerFaction(ply)
        if not faction then return false end
        local flist = DS.Cache.factions[id]
        if not flist or not table.HasValue(flist, faction) then return false end
        if rec.access == DS.ACCESS.FACTION_ROLE then
            local roles = DS.Cache.roles[id] and DS.Cache.roles[id][faction]
            if roles and #roles > 0 then
                return table.HasValue(roles, role)
            end
        end
        return true
    end
    return false
end

-- ─── ГЛАВНАЯ: проверка доступа ────────────────────────────────────
function DS.CanUse(ply, ent)
    if not IsValid(ply) or not IsValid(ent) then return false end
    if ply:IsSuperAdmin() then return true end

    local rec, id = DS.GetDoor(ent)
    if not rec then return true end

    local steam = ply:SteamID()

    -- Владелец/совладелец всегда имеет доступ
    if DS.IsOwner(steam, id, true) then return true end

    -- Whitelist всегда проходит
    if DS.Cache.whitelist[id] and DS.Cache.whitelist[id][steam] then return true end

    -- Заблокировано — никто кроме владельца
    if rec.locked then return false end

    local access = rec.access

    if access == DS.ACCESS.PUBLIC      then return true
    elseif access == DS.ACCESS.PRIVATE or
           access == DS.ACCESS.OWNER_ONLY then return false
    elseif access == DS.ACCESS.WHITELIST  then return false -- нет в whitelist
    elseif access == DS.ACCESS.KEY then
        -- Ключ: привязан к ВЛАДЕЛЬЦУ, открывает все его двери
        local ring = DS.Cache.rings[steam]
        if not ring then return false end
        local doorOwners = DS.Cache.owners[id] or {}
        for _, kid in ipairs(ring) do
            local k = DS.Cache.keys[kid]
            if k and doorOwners[k.owner_steam] then return true end
        end
        return false
    elseif access == DS.ACCESS.FACTION or access == DS.ACCESS.FACTION_ROLE then
        local faction, role = DS.GetPlayerFaction(ply)
        if not faction then return false end
        local flist = DS.Cache.factions[id]
        if not flist or not table.HasValue(flist, faction) then return false end
        if access == DS.ACCESS.FACTION_ROLE then
            local roles = DS.Cache.roles[id] and DS.Cache.roles[id][faction]
            if roles and #roles > 0 then
                return table.HasValue(roles, role)
            end
        end
        return true
    end

    return false
end

-- ─── Сохранить дверь в БД ────────────────────────────────────────
local function saveDoor(id)
    local rec = DS.Cache.doors[id]
    if not rec then return end
    q("UPDATE ds_doors SET name=" .. esc(rec.name) ..
      ",category=" .. esc(rec.category) ..
      ",access=" .. esc(rec.access) ..
      ",locked=" .. (rec.locked and 1 or 0) ..
      ",key_id=" .. esc(rec.key_id) ..
      ",sale_price=" .. (tonumber(rec.sale_price) or 0) ..
      ",for_sale=" .. (rec.for_sale and 1 or 0) ..
      ",updated_at=" .. os.time() ..
      " WHERE id=" .. esc(id))
end

-- ─── Добавить владельца ───────────────────────────────────────────
function DS.AddOwner(doorID, steam, nick, ownerType, expiresAt)
    DS.Cache.owners[doorID] = DS.Cache.owners[doorID] or {}
    DS.Cache.owners[doorID][steam] = {
        nick       = nick or steam,
        owner_type = ownerType or DS.OWNER_TYPE.OWNER,
        expires_at = expiresAt or 0,
        acquired   = os.time(),
    }
    q("INSERT OR REPLACE INTO ds_owners(door_id,steam_id,nick,owner_type,expires_at,acquired) VALUES(" ..
      esc(doorID) .. "," .. esc(steam) .. "," .. esc(nick) .. "," ..
      esc(ownerType or DS.OWNER_TYPE.OWNER) .. "," .. (expiresAt or 0) .. "," .. os.time() .. ")")
end

-- ─── Убрать владельца ────────────────────────────────────────────
function DS.RevokeOwner(doorID, steam)
    if DS.Cache.owners[doorID] then
        DS.Cache.owners[doorID][steam] = nil
    end
    q("DELETE FROM ds_owners WHERE door_id=" .. esc(doorID) .. " AND steam_id=" .. esc(steam))
end

-- ─── Полностью сбросить владельцев двери ──────────────────────────
function DS.ClearOwners(doorID)
    DS.Cache.owners[doorID] = {}
    q("DELETE FROM ds_owners WHERE door_id=" .. esc(doorID))
end

-- ─── Добавить в whitelist ─────────────────────────────────────────
function DS.WhitelistAdd(doorID, steam, nick)
    DS.Cache.whitelist[doorID] = DS.Cache.whitelist[doorID] or {}
    DS.Cache.whitelist[doorID][steam] = nick or steam
    q("INSERT OR REPLACE INTO ds_whitelist(door_id,steam_id,nick) VALUES(" ..
      esc(doorID) .. "," .. esc(steam) .. "," .. esc(nick) .. ")")
end

function DS.WhitelistRemove(doorID, steam)
    if DS.Cache.whitelist[doorID] then DS.Cache.whitelist[doorID][steam] = nil end
    q("DELETE FROM ds_whitelist WHERE door_id=" .. esc(doorID) .. " AND steam_id=" .. esc(steam))
end

-- ─── Синхронизация одной двери ────────────────────────────────────
function DS.SyncDoor(id, target)
    local rec = DS.Cache.doors[id]
    if not rec then return end

    -- Собрать список владельцев для передачи
    local ownerList = {}
    for s, o in pairs(DS.Cache.owners[id] or {}) do
        ownerList[s] = { nick = o.nick, owner_type = o.owner_type,
                         expires_at = o.expires_at, acquired = o.acquired }
    end

    -- Whitelist — только count для публичной синхронизации
    local wlCount = table.Count(DS.Cache.whitelist[id] or {})

    local data = {
        id         = id,
        name       = rec.name,
        category   = rec.category,
        access     = rec.access,
        locked     = rec.locked,
        key_id     = rec.key_id,
        sale_price = rec.sale_price,
        for_sale   = rec.for_sale,
        owners     = ownerList,
        factions   = DS.Cache.factions[id] or {},
        roles      = DS.Cache.roles[id] or {},
        wl_count   = wlCount,
    }

    net.Start("DS_SyncDoor")
    net.WriteString(id)
    net.WriteTable(data)
    if target then net.Send(target) else net.Broadcast() end
end

-- ─── Синхронизация всех дверей одному игроку ─────────────────────
local function syncAllToPlayer(ply)
    local batch = {}
    for id, rec in pairs(DS.Cache.doors) do
        local ownerList = {}
        for s, o in pairs(DS.Cache.owners[id] or {}) do
            ownerList[s] = { nick=o.nick, owner_type=o.owner_type,
                             expires_at=o.expires_at, acquired=o.acquired }
        end
        batch[id] = {
            id         = id, name=rec.name, category=rec.category,
            access     = rec.access, locked=rec.locked, key_id=rec.key_id,
            sale_price = rec.sale_price, for_sale=rec.for_sale,
            owners     = ownerList,
            factions   = DS.Cache.factions[id] or {},
            roles      = DS.Cache.roles[id] or {},
            wl_count   = table.Count(DS.Cache.whitelist[id] or {}),
        }
    end
    net.Start("DS_SyncAllDoors")
    net.WriteTable(batch)
    net.Send(ply)

    -- Синхронизировать категории
    net.Start("DS_SyncCategories")
    net.WriteTable(DS.Cache.categories)
    net.Send(ply)
end

hook.Add("PlayerInitialSpawn", "DS_InitSync", function(ply)
    timer.Simple(3, function()
        if IsValid(ply) then syncAllToPlayer(ply) end
    end)
end)

-- ─── Перехват использования двери ────────────────────────────────
hook.Add("PlayerUse", "DS_UseHook", function(ply, ent)
    if not DS.IsDoor(ent) then return end
    local id = ensureDoor(ent)
    if not id then return end

    if not DS.CanUse(ply, ent) then
        ply:EmitSound(DS.SND.DENY, 65, 100, 0.7)
        net.Start("DS_DoorDenied")
        net.WriteString("Нет доступа")
        net.WriteVector(ent:GetPos())
        net.Send(ply)
        return false
    end
end)

-- ─── Получение данных одной двери ────────────────────────────────
net.Receive("DS_RequestDoorData", function(_, ply)
    local entIdx = net.ReadInt(16)
    local ent    = Entity(entIdx)
    if not IsValid(ent) or not DS.IsDoor(ent) then return end
    local id = ensureDoor(ent)
    if id then DS.SyncDoor(id, ply) end
end)

-- ─── Обновление настроек двери ───────────────────────────────────
net.Receive("DS_SetDoorData", function(_, ply)
    local payload = net.ReadTable()
    if not payload then return end

    local ent = Entity(payload.entidx or 0)
    if not IsValid(ent) or not DS.IsDoor(ent) then
        DS.Result(ply, false, "Дверь не найдена"); return
    end

    local id = ensureDoor(ent)
    local rec = DS.Cache.doors[id]
    local steam = ply:SteamID()
    local isOwner = ply:IsSuperAdmin() or DS.IsOwner(steam, id, false)
    local isCoown = ply:IsSuperAdmin() or DS.IsOwner(steam, id, true)

    local action = payload.action

    -- ── Захват двери ─────────────────────────────────────────────
    if action == "claim" then
        -- Государственная дверь (фракционный доступ) — захват запрещён
        if not ply:IsSuperAdmin() and
           (rec.access == DS.ACCESS.FACTION or rec.access == DS.ACCESS.FACTION_ROLE) then
            DS.Result(ply, false, "Государственная дверь — захват недоступен"); return
        end
        -- Нет никакого owner
        local ownerCount = 0
        for _ in pairs(DS.Cache.owners[id] or {}) do ownerCount = ownerCount + 1 end
        if ownerCount > 0 and not ply:IsSuperAdmin() then
            DS.Result(ply, false, "Дверь уже занята"); return
        end
        local duration = tonumber(payload.duration) or 0  -- секунды, 0=бессрочно
        local expires  = duration > 0 and (os.time() + duration) or 0
        DS.AddOwner(id, steam, ply:Nick(), DS.OWNER_TYPE.OWNER, expires)
        ply:EmitSound(DS.SND.BUY, 65, 100)
        DS.Result(ply, true, "Дверь теперь ваша!" .. (duration > 0 and (" На " .. DS.FormatTime(duration)) or ""))
        saveDoor(id)
        DS.SyncDoor(id)
        -- Хук для sv_buttons.lua — автопривязка кнопок
        hook.Run("DS_DoorClaimed", id, ent)
        return

    -- ── Аренда/продление ─────────────────────────────────────────
    elseif action == "renew" then
        if not isOwner then DS.Result(ply, false, "Нет прав"); return end
        local duration = tonumber(payload.duration) or 0
        if duration <= 0 then DS.Result(ply, false, "Укажите срок"); return end
        local cur = DS.Cache.owners[id] and DS.Cache.owners[id][steam]
        if not cur then DS.Result(ply, false, "Вы не владелец"); return end
        local base = math.max(os.time(), cur.expires_at or 0)
        local newExp = base + duration
        DS.AddOwner(id, steam, ply:Nick(), DS.OWNER_TYPE.OWNER, newExp)
        DS.Result(ply, true, "Срок продлён до " .. os.date("%d.%m.%Y %H:%M", newExp))
        DS.SyncDoor(id)
        return

    -- ── Отказ от двери ───────────────────────────────────────────
    elseif action == "unclaim" or action == "release" then
        if not isOwner then DS.Result(ply, false, "Нет прав"); return end
        DS.ClearOwners(id)
        rec.access = DS.ACCESS.PUBLIC
        rec.locked = false
        saveDoor(id)
        DS.SyncDoor(id)
        DS.Result(ply, true, "Вы отказались от двери")
        return

    -- ── Добавить совладельца ─────────────────────────────────────
    elseif action == "add_coowner" then
        if not ply:IsSuperAdmin() then DS.Result(ply, false, "Только суперадмин"); return end
        local tPly = player.GetBySteamID(payload.target_steam or "")
        if not IsValid(tPly) then DS.Result(ply, false, "Игрок не найден"); return end
        DS.AddOwner(id, tPly:SteamID(), tPly:Nick(), DS.OWNER_TYPE.COOWNER, 0)
        DS.Result(ply, true, tPly:Nick() .. " добавлен как совладелец")
        DS.SyncDoor(id)
        return

    -- ── Убрать совладельца ───────────────────────────────────────
    elseif action == "rm_coowner" then
        if not ply:IsSuperAdmin() then DS.Result(ply, false, "Только суперадмин"); return end
        DS.RevokeOwner(id, payload.target_steam or "")
        DS.Result(ply, true, "Совладелец убран")
        DS.SyncDoor(id)
        return

    -- ── Замок ────────────────────────────────────────────────────
    elseif action == "lock" or action == "unlock" then
        if not DS.CanLock(ply, id) then DS.Result(ply, false, "Нет прав"); return end
        rec.locked = (action == "lock")
        applyLockState(id, rec.locked)
        local snd = rec.locked and DS.SND.LOCK or DS.SND.UNLOCK
        ply:EmitSound(snd, 65, 100)
        saveDoor(id)
        DS.SyncDoor(id)
        DS.Result(ply, true, rec.locked and "Заперта" or "Разблокирована")
        return

    -- ── Обновить настройки ───────────────────────────────────────
    elseif action == "update" then
        -- Изменение доступа, фракций, категории — только суперадмин
        if not ply:IsSuperAdmin() then DS.Result(ply, false, "Только суперадмин"); return end

        if type(payload.name) == "string" then
            rec.name = string.sub(payload.name, 1, 40)
        end
        if payload.access and table.HasValue(DS.ACCESS, payload.access) then
            rec.access = payload.access
        end
        if type(payload.category) == "string" then
            rec.category = payload.category
        end
        if istable(payload.factions) then
            DS.Cache.factions[id] = payload.factions
            q("DELETE FROM ds_factions WHERE door_id=" .. esc(id))
            for _, f in ipairs(payload.factions) do
                q("INSERT OR IGNORE INTO ds_factions(door_id,faction) VALUES(" .. esc(id) .. "," .. esc(f) .. ")")
            end
        end
        if istable(payload.roles) then
            DS.Cache.roles[id] = payload.roles
            q("DELETE FROM ds_roles WHERE door_id=" .. esc(id))
            for faction, rlist in pairs(payload.roles) do
                for _, role in ipairs(rlist) do
                    q("INSERT OR IGNORE INTO ds_roles(door_id,faction,role) VALUES(" .. esc(id) .. "," .. esc(faction) .. "," .. esc(role) .. ")")
                end
            end
        end
        if type(payload.for_sale) == "boolean" then rec.for_sale = payload.for_sale end
        if type(payload.sale_price) == "number"  then rec.sale_price = math.max(0, payload.sale_price) end

        saveDoor(id)
        DS.SyncDoor(id)
        DS.Result(ply, true, "Настройки сохранены")
        return

    -- ── Whitelist add/remove ──────────────────────────────────────
    elseif action == "wl_add" then
        if not ply:IsSuperAdmin() then DS.Result(ply, false, "Только суперадмин"); return end
        local tPly = player.GetBySteamID(payload.target_steam or "")
        if not IsValid(tPly) then DS.Result(ply, false, "Игрок не найден"); return end
        DS.WhitelistAdd(id, tPly:SteamID(), tPly:Nick())
        DS.Result(ply, true, tPly:Nick() .. " добавлен в белый список")
        DS.SyncDoor(id, ply)
        return

    elseif action == "wl_remove" then
        if not ply:IsSuperAdmin() then DS.Result(ply, false, "Только суперадмин"); return end
        DS.WhitelistRemove(id, payload.target_steam or "")
        DS.Result(ply, true, "Удалён из белого списка")
        DS.SyncDoor(id, ply)
        return
    end

    DS.Result(ply, false, "Неизвестное действие: " .. tostring(action))
end)

-- ─── Переключение замка (быстро) ─────────────────────────────────
net.Receive("DS_LockDoor", function(_, ply)
    local entIdx = net.ReadInt(16)
    local ent    = Entity(entIdx)
    if not IsValid(ent) or not DS.IsDoor(ent) then return end
    local id    = ensureDoor(ent)
    -- Проверяем право на замок (включает фракционный доступ)
    if not DS.CanLock(ply, id) then
        DS.Result(ply, false, "Нет прав"); return
    end
    -- Дверь без владельца И без фракционного доступа — замок недоступен
    local rec = DS.Cache.doors[id]
    local isFactionDoor = rec and (rec.access == DS.ACCESS.FACTION or rec.access == DS.ACCESS.FACTION_ROLE)
    local ownerCount = 0
    for _ in pairs(DS.Cache.owners[id] or {}) do ownerCount = ownerCount + 1 end
    if ownerCount == 0 and not isFactionDoor and not ply:IsSuperAdmin() then
        DS.Result(ply, false, "У двери нет владельца"); return
    end
    local rec = DS.Cache.doors[id]
    if not rec then return end
    rec.locked = not rec.locked
    applyLockState(id, rec.locked)
    ply:EmitSound(rec.locked and DS.SND.LOCK or DS.SND.UNLOCK, 65, 100)
    saveDoor(id)
    DS.SyncDoor(id)
    DS.Result(ply, true, rec.locked and "Заперта" or "Открыта")
end)

-- ─── Admin: получить весь список / reset ─────────────────────────
net.Receive("DS_AdminAction", function(_, ply)
    if not ply:IsSuperAdmin() then return end
    local action = net.ReadString()

    if action == "get_all" then
        local out = {}
        for id, rec in pairs(DS.Cache.doors) do
            local ownerList = {}
            for s, o in pairs(DS.Cache.owners[id] or {}) do ownerList[s] = o end
            out[id] = {
                name=rec.name, category=rec.category, access=rec.access,
                locked=rec.locked, owners=ownerList, factions=DS.Cache.factions[id] or {},
                for_sale=rec.for_sale, sale_price=rec.sale_price,
            }
        end
        net.Start("DS_AdminSync")
        net.WriteTable(out)
        net.Send(ply)

    elseif action == "reset_all" then
        DS.Cache.doors     = {}
        DS.Cache.owners    = {}
        DS.Cache.factions  = {}
        DS.Cache.roles     = {}
        DS.Cache.whitelist = {}
        q("DELETE FROM ds_doors WHERE map=" .. esc(game.GetMap()))
        q("DELETE FROM ds_owners")
        q("DELETE FROM ds_factions")
        q("DELETE FROM ds_roles")
        q("DELETE FROM ds_whitelist")
        DS.Result(ply, true, "Все двери сброшены")
        net.Start("DS_SyncAllDoors"); net.WriteTable({}); net.Broadcast()
        scanMapDoors()
    end
end)

-- ─── Admin: сброс одной двери ────────────────────────────────────
net.Receive("DS_AdminReset", function(_, ply)
    if not ply:IsSuperAdmin() then return end
    local entIdx = net.ReadInt(16)
    local ent    = Entity(entIdx)
    if not IsValid(ent) or not DS.IsDoor(ent) then return end
    local id = DS.DoorID(ent)
    if not id then return end

    DS.Cache.doors[id]     = nil
    DS.Cache.owners[id]    = nil
    DS.Cache.factions[id]  = nil
    DS.Cache.roles[id]     = nil
    DS.Cache.whitelist[id] = nil

    q("DELETE FROM ds_doors WHERE id=" .. esc(id))
    q("DELETE FROM ds_owners WHERE door_id=" .. esc(id))
    q("DELETE FROM ds_factions WHERE door_id=" .. esc(id))
    q("DELETE FROM ds_roles WHERE door_id=" .. esc(id))
    q("DELETE FROM ds_whitelist WHERE door_id=" .. esc(id))

    ensureDoor(ent)  -- Пересоздать запись
    DS.SyncDoor(id)
    DS.Result(ply, true, "Дверь сброшена")
end)

-- ─── Admin: управление категорией ────────────────────────────────
net.Receive("DS_AdminSetCategory", function(_, ply)
    if not ply:IsSuperAdmin() then return end
    local action   = net.ReadString()
    local catName  = net.ReadString()
    local r, g, b  = net.ReadUInt(8), net.ReadUInt(8), net.ReadUInt(8)

    if action == "add" then
        local exists = false
        for _, c in ipairs(DS.Cache.categories) do if c.name == catName then exists = true break end end
        if not exists then
            table.insert(DS.Cache.categories, { name=catName, r=r, g=g, b=b })
            q("INSERT OR REPLACE INTO ds_categories(name,col_r,col_g,col_b) VALUES(" ..
              esc(catName) .. "," .. r .. "," .. g .. "," .. b .. ")")
        end
    elseif action == "delete" then
        for i, c in ipairs(DS.Cache.categories) do
            if c.name == catName then table.remove(DS.Cache.categories, i) break end
        end
        q("DELETE FROM ds_categories WHERE name=" .. esc(catName))
    end

    -- Синхронизировать новые категории всем
    net.Start("DS_SyncCategories")
    net.WriteTable(DS.Cache.categories)
    net.Broadcast()
    DS.Result(ply, true, "Категории обновлены")
end)

-- ─── Admin: назначить владельца (с типом и сроком) ───────────────
net.Receive("DS_AdminSetOwner", function(_, ply)
    if not ply:IsSuperAdmin() then return end
    local entIdx   = net.ReadInt(16)
    local tSteam   = net.ReadString()
    local ownerType= net.ReadString()
    local duration = net.ReadDouble()  -- секунды, 0 = бессрочно

    local ent = Entity(entIdx)
    if not IsValid(ent) or not DS.IsDoor(ent) then DS.Result(ply, false, "Дверь не найдена") return end
    local id = ensureDoor(ent)

    if tSteam == "" then
        DS.ClearOwners(id)
        DS.Result(ply, true, "Владельцы убраны")
        DS.SyncDoor(id)
        return
    end

    -- Поиск игрока
    local target = player.GetBySteamID(tSteam)
    local nick   = IsValid(target) and target:Nick() or tSteam

    local expires = duration > 0 and (os.time() + math.floor(duration)) or 0
    DS.AddOwner(id, tSteam, nick, ownerType, expires)
    DS.SyncDoor(id)
    DS.Result(ply, true, "Владелец назначен")
end)

-- ─── Утилита: отправить результат ────────────────────────────────
function DS.Result(ply, ok, msg)
    if not IsValid(ply) then return end
    net.Start("DS_ActionResult")
    net.WriteBool(ok)
    net.WriteString(msg or "")
    net.Send(ply)
end

-- ─── Таймер: проверка истёкших владений (каждые 60 сек) ──────────
timer.Create("DS_OwnerExpiry", 60, 0, function()
    local now = os.time()
    for id, owners in pairs(DS.Cache.owners) do
        for steam, o in pairs(owners) do
            if o.expires_at and o.expires_at > 0 and now > o.expires_at then
                DS.RevokeOwner(id, steam)
                print("[DS] Владение истекло: " .. steam .. " -> " .. id)
                -- Синхронизировать
                DS.SyncDoor(id)
            end
        end
    end
end)

-- ─── Синхронизировать кольцо ключей с клиентом ───────────────────
function DS.SyncKeyRing(ply)
    if not IsValid(ply) then return end
    local steam    = ply:SteamID()
    local ring     = DS.Cache.rings[steam] or {}
    local keyData  = {}
    for _, kid in ipairs(ring) do
        local k = DS.Cache.keys[kid]
        if k then keyData[kid] = { name=k.name, r=k.r, g=k.g, b=k.b, owner_steam=k.owner_steam } end
    end
    net.Start("DS_Keys_Sync")
    net.WriteTable(keyData)
    net.Send(ply)
end

-- ─── Мониторинг смены ранга: принудительно закрыть меню ──────────
-- Отправляет DS_ForceCloseMenu игроку если он потерял права суперадмина.

local function checkPlayerSA(ply)
    if not IsValid(ply) then return end
    if not ply:IsSuperAdmin() then
        net.Start("DS_ForceCloseMenu")
        net.Send(ply)
    end
end

-- ULib вызывает этот хук при смене группы (ulx setgroup, демотирование и т.д.)
hook.Add("ULibUserGroupChanged", "DS_RoleWatch", function(ply)
    timer.Simple(0.1, function() checkPlayerSA(ply) end)
end)

-- Запасной таймер: каждые 15 сек проверяем всех онлайн-игроков.
-- Нужен если ULib-хук не сработал (например смена группы вне ULX).
local _saStatus = {}  -- [SteamID] = lastSAState

timer.Create("DS_RoleCheckTimer", 15, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then
            local steam = ply:SteamID()
            local nowSA = ply:IsSuperAdmin()
            local wasSA = _saStatus[steam]

            -- При первом появлении игрока — запомнить
            if wasSA == nil then
                _saStatus[steam] = nowSA
            elseif wasSA and not nowSA then
                -- Был SA, стал не-SA → принудительно закрыть меню
                _saStatus[steam] = false
                net.Start("DS_ForceCloseMenu")
                net.Send(ply)
                print("[DS] Ранг понижен, меню закрыто: " .. ply:Nick())
            else
                _saStatus[steam] = nowSA
            end
        end
    end
end)

-- Очищать статус при выходе с сервера
hook.Add("PlayerDisconnected", "DS_RoleWatchClean", function(ply)
    if IsValid(ply) then _saStatus[ply:SteamID()] = nil end
end)

-- ─── Группы фракций: синхронизация ───────────────────────────────
function DS.SyncFactionGroups(target)
    net.Start("DS_FactionGroupsSync")
    net.WriteTable(DS.Cache.factionGroups)
    if target then net.Send(target) else net.Broadcast() end
end

-- При входе — слать группы игроку вместе с остальным
hook.Add("PlayerInitialSpawn", "DS_FactionGroupSync", function(ply)
    timer.Simple(3.2, function()
        if IsValid(ply) then DS.SyncFactionGroups(ply) end
    end)
end)

-- Сохранить/удалить группу фракции (только суперадмин)
-- Формат: { faction=string, group=string }  (group="" = убрать из группы)
net.Receive("DS_FactionGroupSave", function(_, ply)
    if not ply:IsSuperAdmin() then return end
    local faction = net.ReadString()
    local group   = net.ReadString()

    if faction == "" then return end

    if group == "" then
        -- Убрать из группы
        DS.Cache.factionGroups[faction] = nil
        q("DELETE FROM ds_faction_groups WHERE faction=" .. esc(faction))
    else
        -- Сохранить
        DS.Cache.factionGroups[faction] = group
        q("INSERT OR REPLACE INTO ds_faction_groups(faction,group_name) VALUES(" ..
          esc(faction) .. "," .. esc(group) .. ")")
    end

    DS.SyncFactionGroups()
    DS.Result(ply, true, "Группа сохранена")
end)

print("[DoorSystem] Серверное ядро v2.0 загружено")
