--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Миграция данных из door_system.json (v1 формат)

    Запуск: введи в консоль сервера  ds_migrate_v1
    Или с флагом дебага:             ds_migrate_v1 debug

    Что переносит:
      • Owner / OwnerName  → ds_owners (owner_type = "owner")
      • Name               → ds_doors.name
      • Locked             → ds_doors.locked
      • Access             → ds_doors.access (маппинг public/private/...)
      • Factions[]         → ds_factions
      • Roles[]            → ds_roles (по каждой фракции из Factions[])
      • Whitelist[]        → ds_whitelist

    Повторный запуск безопасен — использует INSERT OR IGNORE / UPDATE.
    Дверь в v1 с Owner="" считается публичной, не переносит пустого владельца.
    После успешной миграции переименовывает door_system.json →
    door_system_migrated.json, чтобы не запускать повторно случайно.
--------------------------------------------------------------------]]

if not SERVER then return end

-- Маппинг типов доступа v1 → v2
local ACCESS_MAP = {
    public    = DS.ACCESS.PUBLIC,
    private   = DS.ACCESS.PRIVATE,
    faction   = DS.ACCESS.FACTION,
    whitelist = DS.ACCESS.WHITELIST,
    key       = DS.ACCESS.KEY,
    owner     = DS.ACCESS.OWNER_ONLY,
    owner_only= DS.ACCESS.OWNER_ONLY,
}

local function q(stmt)   return sql.Query(stmt) end
local function esc(s)    return sql.SQLStr(tostring(s or "")) end
local function now()     return os.time() end

local function migrate(ply, args)
    local debug = args and args[1] == "debug"

    local function log(msg)
        print("[DS Migrate] " .. msg)
        if IsValid(ply) then ply:ChatPrint("[DS Migrate] " .. msg) end
    end

    local function dlog(msg)
        if debug then log(msg) end
    end

    -- ── Читаем файл ──────────────────────────────────────────────
    local FILE_IN  = "door_system.json"
    local FILE_OUT = "door_system_migrated.json"

    if not file.Exists(FILE_IN, "DATA") then
        log("Файл DATA/" .. FILE_IN .. " не найден. Миграция отменена.")
        return
    end

    local raw = file.Read(FILE_IN, "DATA")
    if not raw or raw == "" then
        log("Файл пустой. Миграция отменена.")
        return
    end

    local ok, data = pcall(util.JSONToTable, raw)
    if not ok or not istable(data) then
        log("Ошибка разбора JSON: " .. tostring(data))
        return
    end

    local map = game.GetMap()
    local total, skipped, errors = 0, 0, 0

    -- ── Перебираем двери ─────────────────────────────────────────
    for rawID, rec in pairs(data) do
        if type(rec) ~= "table" then goto ds_next end

        -- v1 использует тот же формат ID: mapname_hHAMMERID
        -- Принимаем запись только если она принадлежит текущей карте
        if not string.find(rawID, map, 1, true) then
            dlog("Пропускаю (чужая карта): " .. rawID)
            skipped = skipped + 1
            goto ds_next
        end

        total = total + 1
        local id = rawID  -- ID совпадает, используем как есть

        -- Убеждаемся что запись в ds_doors есть
        q("INSERT OR IGNORE INTO ds_doors(id, map, updated_at) VALUES(" ..
          esc(id) .. "," .. esc(map) .. "," .. now() .. ")")

        -- Name
        if type(rec.Name) == "string" and rec.Name ~= "" then
            q("UPDATE ds_doors SET name=" .. esc(rec.Name) ..
              " WHERE id=" .. esc(id))
        end

        -- Access
        local rawAccess = type(rec.Access) == "string" and string.lower(rec.Access) or "public"
        local access = ACCESS_MAP[rawAccess] or DS.ACCESS.PUBLIC
        q("UPDATE ds_doors SET access=" .. esc(access) .. " WHERE id=" .. esc(id))

        -- Locked
        local locked = rec.Locked == true and 1 or 0
        q("UPDATE ds_doors SET locked=" .. locked .. " WHERE id=" .. esc(id))

        dlog("Дверь " .. id .. " | access=" .. access .. " locked=" .. tostring(locked == 1))

        -- Owner → ds_owners
        if type(rec.Owner) == "string" and rec.Owner ~= "" then
            local steam  = rec.Owner
            local nick   = type(rec.OwnerName) == "string" and rec.OwnerName or steam
            q("INSERT OR IGNORE INTO ds_owners(door_id, steam_id, nick, owner_type, expires_at, acquired) VALUES(" ..
              esc(id) .. "," .. esc(steam) .. "," .. esc(nick) ..
              ",'owner',0," .. now() .. ")")
            dlog("  Владелец: " .. nick .. " (" .. steam .. ")")
        end

        -- Factions[] → ds_factions
        if istable(rec.Factions) then
            for _, fname in ipairs(rec.Factions) do
                if type(fname) == "string" and fname ~= "" then
                    q("INSERT OR IGNORE INTO ds_factions(door_id, faction) VALUES(" ..
                      esc(id) .. "," .. esc(fname) .. ")")
                    dlog("  Фракция: " .. fname)

                    -- Roles[] → ds_roles (привязываем к каждой фракции из Factions)
                    if istable(rec.Roles) then
                        for _, role in ipairs(rec.Roles) do
                            if type(role) == "string" and role ~= "" then
                                q("INSERT OR IGNORE INTO ds_roles(door_id, faction, role) VALUES(" ..
                                  esc(id) .. "," .. esc(fname) .. "," .. esc(role) .. ")")
                                dlog("    Роль: " .. role)
                            end
                        end
                    end
                end
            end
        end

        -- Whitelist[] → ds_whitelist
        -- v1: массив steamID строк
        if istable(rec.Whitelist) then
            for _, wlEntry in ipairs(rec.Whitelist) do
                local steam, nick
                if type(wlEntry) == "string" then
                    steam = wlEntry; nick  = wlEntry
                elseif type(wlEntry) == "table" then
                    steam = wlEntry.steam or wlEntry.SteamID or ""
                    nick  = wlEntry.nick  or wlEntry.Name   or steam
                end
                if steam and steam ~= "" then
                    q("INSERT OR IGNORE INTO ds_whitelist(door_id, steam_id, nick) VALUES(" ..
                      esc(id) .. "," .. esc(steam) .. "," .. esc(nick) .. ")")
                    dlog("  Whitelist: " .. steam)
                end
            end
        end

        ::ds_next::
    end

    -- ── Обновить кэш в памяти ─────────────────────────────────────
    log("Перезагружаю кэш DS...")
    DS.Cache.doors     = {}
    DS.Cache.owners    = {}
    DS.Cache.factions  = {}
    DS.Cache.roles     = {}
    DS.Cache.whitelist = {}

    -- Перечитываем из БД (копия loadCache логики)
    local rows = sql.Query("SELECT * FROM ds_doors WHERE map=" .. esc(map))
    if rows then
        for _, row in ipairs(rows) do
            DS.Cache.doors[row.id] = {
                id        = row.id,
                name      = row.name,
                category  = row.category,
                access    = row.access,
                locked    = tobool(row.locked),
                key_id    = row.key_id,
                sale_price= tonumber(row.sale_price) or 0,
                for_sale  = tobool(row.for_sale),
            }
            DS.Cache.owners[row.id]    = {}
            DS.Cache.factions[row.id]  = {}
            DS.Cache.roles[row.id]     = {}
            DS.Cache.whitelist[row.id] = {}
        end
    end
    local owns = sql.Query("SELECT * FROM ds_owners")
    if owns then
        for _, row in ipairs(owns) do
            if DS.Cache.owners[row.door_id] then
                DS.Cache.owners[row.door_id][row.steam_id] = {
                    nick       = row.nick,
                    owner_type = row.owner_type,
                    expires_at = tonumber(row.expires_at) or 0,
                    acquired   = tonumber(row.acquired) or 0,
                }
            end
        end
    end
    local facs = sql.Query("SELECT * FROM ds_factions")
    if facs then
        for _, row in ipairs(facs) do
            if DS.Cache.factions[row.door_id] then
                table.insert(DS.Cache.factions[row.door_id], row.faction)
            end
        end
    end
    local roles = sql.Query("SELECT * FROM ds_roles")
    if roles then
        for _, row in ipairs(roles) do
            if DS.Cache.roles[row.door_id] then
                DS.Cache.roles[row.door_id][row.faction] = DS.Cache.roles[row.door_id][row.faction] or {}
                table.insert(DS.Cache.roles[row.door_id][row.faction], row.role)
            end
        end
    end
    local wl = sql.Query("SELECT * FROM ds_whitelist")
    if wl then
        for _, row in ipairs(wl) do
            if DS.Cache.whitelist[row.door_id] then
                DS.Cache.whitelist[row.door_id][row.steam_id] = row.nick
            end
        end
    end

    -- Разослать обновления всем клиентам
    net.Start("DS_SyncAllDoors")
    local out = {}
    for id2, rec2 in pairs(DS.Cache.doors) do
        out[id2] = {
            name      = rec2.name,
            category  = rec2.category,
            access    = rec2.access,
            locked    = rec2.locked,
            owners    = DS.Cache.owners[id2] or {},
            factions  = DS.Cache.factions[id2] or {},
        }
    end
    net.WriteTable(out)
    net.Broadcast()

    -- ── Переименовываем исходный файл ─────────────────────────────
    local raw2 = file.Read(FILE_IN, "DATA")
    if raw2 then
        file.Write(FILE_OUT, raw2)
        file.Delete(FILE_IN)
        log("Исходный файл переименован в DATA/" .. FILE_OUT)
    end

    log(string.format("Миграция завершена: обработано %d, пропущено %d, ошибок %d",
        total, skipped, errors))
end

concommand.Add("ds_migrate_v1", function(ply, _, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[DS] Только суперадмин может запускать миграцию")
        return
    end
    migrate(ply, args)
end, nil, "Мигрировать двери из door_system.json (v1) в SQLite (v2). Аргумент: debug")

print("[DS] Миграционный скрипт загружен. Команда: ds_migrate_v1 [debug]")
