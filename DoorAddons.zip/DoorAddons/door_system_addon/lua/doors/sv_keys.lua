--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Ключи (сервер)

    Концепция: ключ привязан к ВЛАДЕЛЬЦУ (owner_steam), а не к двери.
    Один ключ открывает ВСЕ двери данного владельца.

    Конфиг: DS.KEY_CONFIG в sh_door_system.lua

    Команды консоли:
      ds_givekey              → выдать себе ключ (от себя самого)
      ds_givekey <steam>      → выдать ключ от себя другому игроку
      ds_revokekey <steam>    → отозвать свой ключ у игрока
--------------------------------------------------------------------]]

util.AddNetworkString("DS_Keys_Sync")
util.AddNetworkString("DS_Keys_Request")
util.AddNetworkString("DS_Keys_Give")
util.AddNetworkString("DS_Keys_Revoke")
util.AddNetworkString("DS_Keys_Delete")

local function esc(s) return sql.SQLStr(tostring(s or "")) end
local function q(s)   return sql.Query(s) end

local CFG = function() return DS.KEY_CONFIG or {} end

-- ─── Генерация ID ─────────────────────────────────────────────────
local function genID()
    return "key_" .. os.time() .. "_" .. math.random(10000, 99999)
end

-- ─── Создать ключ (привязан к владельцу) ──────────────────────────
-- ownerSteam = SteamID хозяина дверей (кто выдаёт ключ)
-- name       = отображаемое имя ключа
function DS.CreateKey(ownerSteam, name, r, g, b)
    local cfg = CFG()
    local dc  = cfg.DEFAULT_COLOR or {r=255,g=215,b=0}
    r, g, b = r or dc.r, g or dc.g, b or dc.b
    local id = genID()
    DS.Cache.keys[id] = {
        owner_steam = ownerSteam,
        name        = name or "Ключ",
        r = r, g = g, b = b,
    }
    q("INSERT INTO ds_keys(id,owner_steam,name,col_r,col_g,col_b,created_at) VALUES(" ..
      esc(id) .. "," .. esc(ownerSteam) .. "," .. esc(name) ..
      "," .. r .. "," .. g .. "," .. b .. "," .. os.time() .. ")")
    return id
end

-- ─── Получить или создать ключ для владельца ──────────────────────
-- Один владелец = один ключ (все его двери открываются одним)
function DS.GetOrCreateOwnerKey(ownerSteam, displayName)
    for kid, k in pairs(DS.Cache.keys) do
        if k.owner_steam == ownerSteam then return kid end
    end
    return DS.CreateKey(ownerSteam, displayName or ("Ключи: " .. ownerSteam))
end

-- ─── Удалить ключ ─────────────────────────────────────────────────
function DS.DeleteKey(keyID)
    DS.Cache.keys[keyID] = nil
    for _, ring in pairs(DS.Cache.rings) do
        for i = #ring, 1, -1 do
            if ring[i] == keyID then table.remove(ring, i) end
        end
    end
    q("DELETE FROM ds_keys WHERE id=" .. esc(keyID))
    q("DELETE FROM ds_player_keys WHERE key_id=" .. esc(keyID))
end

-- ─── Выдать ключ игроку ───────────────────────────────────────────
function DS.GiveKey(holderSteam, keyID)
    if not DS.Cache.keys[keyID] then return false, "Ключ не существует" end
    DS.Cache.rings[holderSteam] = DS.Cache.rings[holderSteam] or {}
    if table.HasValue(DS.Cache.rings[holderSteam], keyID) then return false, "Уже есть" end
    table.insert(DS.Cache.rings[holderSteam], keyID)
    q("INSERT OR IGNORE INTO ds_player_keys(steam_id,key_id) VALUES(" ..
      esc(holderSteam) .. "," .. esc(keyID) .. ")")
    return true
end

-- ─── Отозвать ключ у игрока ───────────────────────────────────────
function DS.RevokeKey(holderSteam, keyID)
    local ring = DS.Cache.rings[holderSteam]
    if not ring then return false end
    for i, kid in ipairs(ring) do
        if kid == keyID then
            table.remove(ring, i)
            q("DELETE FROM ds_player_keys WHERE steam_id=" ..
              esc(holderSteam) .. " AND key_id=" .. esc(keyID))
            return true
        end
    end
    return false
end

-- ─── Авто-выдача / изъятие SWEP ──────────────────────────────────
local SWEP_CLASS = (DS.KEY_CONFIG or {}).SWEP_CLASS or "ds_key_swep"

function DS.UpdateKeySwep(ply)
    if not IsValid(ply) then return end
    local cfg     = CFG()
    local steam   = ply:SteamID()
    local ring    = DS.Cache.rings[steam]
    local hasKeys = ring and #ring > 0

    if hasKeys then
        if cfg.AUTO_GIVE_SWEP ~= false and not ply:HasWeapon(SWEP_CLASS) then
            ply:Give(SWEP_CLASS)
        end
    else
        if cfg.AUTO_STRIP_SWEP ~= false and ply:HasWeapon(SWEP_CLASS) then
            ply:StripWeapon(SWEP_CLASS)
        end
    end
end

-- ─── Синхронизация при входе ──────────────────────────────────────
hook.Add("PlayerInitialSpawn", "DS_KeysSync", function(ply)
    timer.Simple(3, function()
        if not IsValid(ply) then return end
        DS.SyncKeyRing(ply)
        DS.UpdateKeySwep(ply)
    end)
end)

-- ─── Сетевые обработчики ─────────────────────────────────────────
net.Receive("DS_Keys_Request", function(_, ply)
    DS.SyncKeyRing(ply)
end)

-- Выдать ключ: выдающий = владелец двери, получатель = tSteam
net.Receive("DS_Keys_Give", function(_, ply)
    local entIdx  = net.ReadInt(16)
    local tSteam  = net.ReadString()
    net.ReadString() -- name (не используем — имя берём от владельца)

    local ent = Entity(entIdx)
    if not IsValid(ent) or not DS.IsDoor(ent) then
        DS.Result(ply, false, "Дверь не найдена"); return
    end

    local id    = DS.DoorID(ent)
    local steam = ply:SteamID()
    if not ply:IsSuperAdmin() and not DS.IsOwner(steam, id, false) then
        DS.Result(ply, false, "Только владелец выдаёт ключи"); return
    end

    -- Ключ привязан к выдающему (владельцу), открывает все его двери
    local nick = ply:Nick()
    local kid  = DS.GetOrCreateOwnerKey(steam, "Ключи " .. nick)

    -- Установить тип доступа двери
    local rec = DS.Cache.doors[id]
    if rec then
        rec.access = DS.ACCESS.KEY
        sql.Query("UPDATE ds_doors SET access='key' WHERE id=" .. sql.SQLStr(id))
        DS.SyncDoor(id)
    end

    local ok, msg = DS.GiveKey(tSteam, kid)
    if ok then
        local tPly = player.GetBySteamID(tSteam)
        if IsValid(tPly) then
            tPly:EmitSound(DS.SND.KEY_GET, 65, 100)
            DS.SyncKeyRing(tPly)
            DS.UpdateKeySwep(tPly)
            DS.Result(tPly, true, "Вам выдан ключ от " .. nick)
        end
    end
    DS.Result(ply, ok or msg == "Уже есть", ok and "Ключ выдан" or msg)
end)

-- Отозвать ключ: отзывающий = владелец, у tSteam
net.Receive("DS_Keys_Revoke", function(_, ply)
    local entIdx = net.ReadInt(16)
    local tSteam = net.ReadString()
    local ent    = Entity(entIdx)
    if not IsValid(ent) or not DS.IsDoor(ent) then return end

    local id    = DS.DoorID(ent)
    local steam = ply:SteamID()
    if not ply:IsSuperAdmin() and not DS.IsOwner(steam, id, false) then
        DS.Result(ply, false, "Нет прав"); return
    end

    -- Найти ключ этого владельца
    local kid
    for k_id, k in pairs(DS.Cache.keys) do
        if k.owner_steam == steam then kid = k_id; break end
    end

    if not kid then DS.Result(ply, false, "Ключ ещё не создавался"); return end

    local ok = DS.RevokeKey(tSteam, kid)
    local tPly = player.GetBySteamID(tSteam)
    if IsValid(tPly) then
        DS.SyncKeyRing(tPly)
        DS.UpdateKeySwep(tPly)
    end
    DS.Result(ply, ok, ok and "Ключ изъят" or "У игрока нет этого ключа")
end)

-- ─── Консольные команды ──────────────────────────────────────────
-- ds_givekey              → ключ от ТЕБЯ САМОГО себе (тест: открывает твои двери)
-- ds_givekey <steamID>    → ключ от тебя — другому игроку
-- ds_revokekey <steamID>  → отозвать свой ключ у игрока

concommand.Add("ds_givekey", function(ply, _, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[DS] Только суперадмин"); return
    end

    local ownerSteam = IsValid(ply) and ply:SteamID() or "STEAM_0:0:0"
    local ownerNick  = IsValid(ply) and ply:Nick() or "Сервер"

    -- Получатель ключа
    local holderPly, holderSteam
    if args[1] and args[1] ~= "" then
        -- Пробуем найти по имени или SteamID
        for _, p in ipairs(player.GetAll()) do
            if p:SteamID() == args[1] or p:SteamID64() == args[1] or
               string.lower(p:Nick()) == string.lower(args[1]) then
                holderPly   = p
                holderSteam = p:SteamID()
                break
            end
        end
        if not holderSteam then
            holderSteam = args[1]  -- оффлайн-игрок (только по SteamID)
        end
    else
        holderPly   = IsValid(ply) and ply or nil
        holderSteam = ownerSteam
    end

    local kid = DS.GetOrCreateOwnerKey(ownerSteam, "Ключи " .. ownerNick)
    local ok, msg = DS.GiveKey(holderSteam, kid)

    if IsValid(holderPly) then
        DS.SyncKeyRing(holderPly)
        DS.UpdateKeySwep(holderPly)
        if ok then
            holderPly:EmitSound(DS.SND.KEY_GET, 65, 100)
            holderPly:ChatPrint("[DS] Выдан ключ от " .. ownerNick ..
                " — открывает все его двери")
        end
    end

    local resultMsg = ok
        and ("Ключ выдан → " .. holderSteam)
        or  ("Ключ уже был: " .. holderSteam)

    if IsValid(ply) then ply:ChatPrint("[DS] " .. resultMsg)
    else print("[DS] " .. resultMsg) end
end)

concommand.Add("ds_revokekey", function(ply, _, args)
    if IsValid(ply) and not ply:IsSuperAdmin() then
        ply:ChatPrint("[DS] Только суперадмин"); return
    end
    if not args[1] or args[1] == "" then
        if IsValid(ply) then ply:ChatPrint("[DS] Использование: ds_revokekey <steamID или имя>")
        else print("[DS] Использование: ds_revokekey <steamID>") end
        return
    end

    local ownerSteam = IsValid(ply) and ply:SteamID() or "STEAM_0:0:0"

    local holderPly, holderSteam
    for _, p in ipairs(player.GetAll()) do
        if p:SteamID() == args[1] or p:SteamID64() == args[1] or
           string.lower(p:Nick()) == string.lower(args[1]) then
            holderPly   = p
            holderSteam = p:SteamID()
            break
        end
    end
    holderSteam = holderSteam or args[1]

    local kid
    for k_id, k in pairs(DS.Cache.keys) do
        if k.owner_steam == ownerSteam then kid = k_id; break end
    end
    if not kid then
        if IsValid(ply) then ply:ChatPrint("[DS] Ты ещё не создавал ключей") end
        return
    end

    local ok = DS.RevokeKey(holderSteam, kid)
    if IsValid(holderPly) then
        DS.SyncKeyRing(holderPly)
        DS.UpdateKeySwep(holderPly)
        if ok then holderPly:ChatPrint("[DS] Ваш ключ от " ..
            (IsValid(ply) and ply:Nick() or "сервера") .. " отозван") end
    end

    local msg = ok and "Ключ отозван у " .. holderSteam
                    or "Ключа не было у " .. holderSteam
    if IsValid(ply) then ply:ChatPrint("[DS] " .. msg)
    else print("[DS] " .. msg) end
end)

print("[DoorSystem] Ключи v2.0 загружены")
