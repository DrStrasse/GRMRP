--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — ULX / ULib интеграция

    Команды (требуют ULX):
      ulx ds_claim       <target>              — захватить дверь для игрока
      ulx ds_unclaim                           — сбросить дверь
      ulx ds_lock                              — замкнуть дверь
      ulx ds_unlock                            — открыть дверь
      ulx ds_owner       <target> [days]       — назначить владельца
      ulx ds_coowner     <target>              — добавить совладельца
      ulx ds_category    <категория>           — установить категорию
      ulx ds_access      <тип доступа>         — установить тип доступа
      ulx ds_scan                              — переcканировать двери карты
      ulx ds_admin                             — открыть панель администратора
--------------------------------------------------------------------]]

-- Загружаем только если ULib доступна
if not ULib or not ulx then
    print("[DS] ULX/ULib не найден — команды ULX не зарегистрированы")
    return
end

-- ─── Вспомогательная: получить дверь перед игроком ───────────────
local function getAimedDoor(ply)
    local tr = util.TraceLine({
        start  = ply:EyePos(),
        endpos = ply:EyePos() + ply:GetAimVector() * 150,
        filter = ply,
        mask   = MASK_ALL,
    })
    if IsValid(tr.Entity) and DS.IsDoor(tr.Entity) then
        return tr.Entity
    end
    return nil
end

local function getAimedDoorID(ply)
    local ent = getAimedDoor(ply)
    if not IsValid(ent) then return nil, nil end
    local id = DS.DoorID(ent)
    if not DS.Cache.doors[id] then
        DS.Cache.doors[id]     = { id=id, name="", category="Без категории",
            access=DS.ACCESS.PUBLIC, locked=false, key_id="", sale_price=0, for_sale=false }
        DS.Cache.owners[id]    = {}
        DS.Cache.factions[id]  = {}
        DS.Cache.roles[id]     = {}
        DS.Cache.whitelist[id] = {}
        sql.Query("INSERT OR IGNORE INTO ds_doors(id,map,updated_at) VALUES("
            ..sql.SQLStr(id)..","..sql.SQLStr(game.GetMap())..","..os.time()..")")
    end
    return id, ent
end

-- ─── Ярлыки типов аргументов ──────────────────────────────────────
local CPLY = ULib.cmds.PlayerArg
local CSTR = ULib.cmds.StringArg
local CNUM = ULib.cmds.NumArg

-- ─── ulx ds_claim ────────────────────────────────────────────────
local function cmd_claim(calling_ply, target_ply, duration_days)
    local id, ent = getAimedDoorID(calling_ply)
    if not id then
        ULib.tsay(calling_ply, "[DS] Наведитесь на дверь", true); return
    end
    local t       = IsValid(target_ply) and target_ply or calling_ply
    local days    = tonumber(duration_days) or 0
    local expires = days > 0 and (os.time() + days * 86400) or 0
    DS.ClearOwners(id)
    DS.AddOwner(id, t:SteamID(), t:Nick(), DS.OWNER_TYPE.OWNER, expires)
    DS.SyncDoor(id)
    hook.Run("DS_DoorClaimed", id, ent)
    ulx.fancyLog(calling_ply, "%s захватил дверь для %s",
        ulx.getEscapeStr(calling_ply:Nick()), t:Nick())
end

local cmdClaim = ulx.command("Door System", "ulx ds_claim", cmd_claim, "!ds_claim")
cmdClaim:addParam{ type=CPLY }
cmdClaim:addParam{ type=CNUM, min=0, max=365, [ULib.cmds.optional]=true }
cmdClaim:defaultAccess(ULib.ACCESS_ADMIN)
cmdClaim.help = "Захватить прицеленную дверь для игрока [дни]"

-- ─── ulx ds_unclaim ──────────────────────────────────────────────
local function cmd_unclaim(calling_ply)
    local id = getAimedDoorID(calling_ply)
    if not id then ULib.tsay(calling_ply, "[DS] Нет двери", true) return end
    DS.ClearOwners(id)
    local rec = DS.Cache.doors[id]
    if rec then rec.access = DS.ACCESS.PUBLIC; rec.locked = false end
    sql.Query("UPDATE ds_doors SET access='public',locked=0 WHERE id=" .. sql.SQLStr(id))
    DS.SyncDoor(id)
    ulx.fancyLog(calling_ply, "%s сбросил владельца двери",
        ulx.getEscapeStr(calling_ply:Nick()))
end

local cmdUnclaim = ulx.command("Door System", "ulx ds_unclaim", cmd_unclaim, "!ds_unclaim")
cmdUnclaim:defaultAccess(ULib.ACCESS_ADMIN)
cmdUnclaim.help = "Сбросить владельца прицеленной двери"

-- ─── ulx ds_lock / ds_unlock ─────────────────────────────────────
local function cmd_lock(calling_ply, lock)
    local id, _ = getAimedDoorID(calling_ply)
    if not id then ULib.tsay(calling_ply, "[DS] Нет двери", true) return end
    local rec = DS.Cache.doors[id]
    if not rec then return end
    rec.locked = lock
    sql.Query("UPDATE ds_doors SET locked=" .. (lock and 1 or 0) ..
              " WHERE id=" .. sql.SQLStr(id))
    calling_ply:EmitSound(lock and DS.SND.LOCK or DS.SND.UNLOCK, 65, 100)
    DS.SyncDoor(id)
    ulx.fancyLog(calling_ply, "%s %s дверь",
        ulx.getEscapeStr(calling_ply:Nick()), lock and "запер" or "открыл")
end

local cmdLock = ulx.command("Door System", "ulx ds_lock",
    function(p) cmd_lock(p, true) end, "!ds_lock")
cmdLock:defaultAccess(ULib.ACCESS_ADMIN)
cmdLock.help = "Запереть прицеленную дверь"

local cmdUnlock = ulx.command("Door System", "ulx ds_unlock",
    function(p) cmd_lock(p, false) end, "!ds_unlock")
cmdUnlock:defaultAccess(ULib.ACCESS_ADMIN)
cmdUnlock.help = "Открыть (снять замок) прицеленную дверь"

-- ─── ulx ds_owner ────────────────────────────────────────────────
local function cmd_owner(calling_ply, target_ply, days)
    local id, ent = getAimedDoorID(calling_ply)
    if not id then ULib.tsay(calling_ply, "[DS] Нет двери", true) return end
    days = tonumber(days) or 0
    local expires = days > 0 and (os.time() + days * 86400) or 0
    DS.AddOwner(id, target_ply:SteamID(), target_ply:Nick(), DS.OWNER_TYPE.OWNER, expires)
    DS.SyncDoor(id)
    hook.Run("DS_DoorClaimed", id, ent)
    ulx.fancyLog(calling_ply, "%s назначил владельца: %s (срок: %s)",
        ulx.getEscapeStr(calling_ply:Nick()), target_ply:Nick(),
        days > 0 and (days .. " дн.") or "бессрочно")
end

local cmdOwner = ulx.command("Door System", "ulx ds_owner", cmd_owner, "!ds_owner")
cmdOwner:addParam{ type=CPLY }
cmdOwner:addParam{ type=CNUM, min=0, max=365, [ULib.cmds.optional]=true }
cmdOwner:defaultAccess(ULib.ACCESS_ADMIN)
cmdOwner.help = "Назначить владельца прицеленной двери [дни]"

-- ─── ulx ds_coowner ──────────────────────────────────────────────
local function cmd_coowner(calling_ply, target_ply)
    local id = getAimedDoorID(calling_ply)
    if not id then ULib.tsay(calling_ply, "[DS] Нет двери", true) return end
    DS.AddOwner(id, target_ply:SteamID(), target_ply:Nick(), DS.OWNER_TYPE.COOWNER, 0)
    DS.SyncDoor(id)
    ulx.fancyLog(calling_ply, "%s добавил совладельца: %s",
        ulx.getEscapeStr(calling_ply:Nick()), target_ply:Nick())
end

local cmdCoowner = ulx.command("Door System", "ulx ds_coowner", cmd_coowner, "!ds_coowner")
cmdCoowner:addParam{ type=CPLY }
cmdCoowner:defaultAccess(ULib.ACCESS_ADMIN)
cmdCoowner.help = "Добавить совладельца прицеленной двери"

-- ─── ulx ds_category ─────────────────────────────────────────────
local function cmd_category(calling_ply, catName)
    local id = getAimedDoorID(calling_ply)
    if not id then ULib.tsay(calling_ply, "[DS] Нет двери", true) return end
    local rec = DS.Cache.doors[id]
    if not rec then return end
    rec.category = catName
    sql.Query("UPDATE ds_doors SET category=" .. sql.SQLStr(catName) ..
              " WHERE id=" .. sql.SQLStr(id))
    DS.SyncDoor(id)
    ulx.fancyLog(calling_ply, "%s установил категорию '%s'",
        ulx.getEscapeStr(calling_ply:Nick()), catName)
end

local cmdCategory = ulx.command("Door System", "ulx ds_category", cmd_category, "!ds_category")
cmdCategory:addParam{ type=CSTR }
cmdCategory:defaultAccess(ULib.ACCESS_ADMIN)
cmdCategory.help = "Установить категорию прицеленной двери"

-- ─── ulx ds_access ───────────────────────────────────────────────
local function cmd_access(calling_ply, accessStr)
    local id = getAimedDoorID(calling_ply)
    if not id then ULib.tsay(calling_ply, "[DS] Нет двери", true) return end
    if not table.HasValue(DS.ACCESS, accessStr) then
        ULib.tsay(calling_ply, "[DS] Неверный тип. Доступные: " ..
            table.concat(table.GetValues(DS.ACCESS), ", "), true)
        return
    end
    local rec = DS.Cache.doors[id]
    if not rec then return end
    rec.access = accessStr
    sql.Query("UPDATE ds_doors SET access=" .. sql.SQLStr(accessStr) ..
              " WHERE id=" .. sql.SQLStr(id))
    DS.SyncDoor(id)
    ulx.fancyLog(calling_ply, "%s установил доступ '%s'",
        ulx.getEscapeStr(calling_ply:Nick()), accessStr)
end

local cmdAccess = ulx.command("Door System", "ulx ds_access", cmd_access, "!ds_access")
cmdAccess:addParam{ type=CSTR }
cmdAccess:defaultAccess(ULib.ACCESS_ADMIN)
cmdAccess.help = "Установить тип доступа: public / private / faction / whitelist / key / owner_only"

-- ─── ulx ds_scan ─────────────────────────────────────────────────
local function cmd_scan(calling_ply)
    local count = 0
    for _, ent in ipairs(ents.GetAll()) do
        if DS.IsDoor(ent) then
            local id = DS.DoorID(ent)
            if not DS.Cache.doors[id] then
                DS.Cache.doors[id]     = { id=id, name="", category="Без категории",
                    access=DS.ACCESS.PUBLIC, locked=false, key_id="", sale_price=0, for_sale=false }
                DS.Cache.owners[id]    = {}
                DS.Cache.factions[id]  = {}
                DS.Cache.roles[id]     = {}
                DS.Cache.whitelist[id] = {}
                sql.Query("INSERT OR IGNORE INTO ds_doors(id,map,updated_at) VALUES("
                    .. sql.SQLStr(id) .. "," .. sql.SQLStr(game.GetMap()) .. "," .. os.time() .. ")")
                count = count + 1
            end
        end
    end
    ulx.fancyLog(calling_ply, "%s пересканировал двери: найдено новых %d",
        ulx.getEscapeStr(calling_ply:Nick()), count)
end

local cmdScan = ulx.command("Door System", "ulx ds_scan", cmd_scan, "!ds_scan")
cmdScan:defaultAccess(ULib.ACCESS_ADMIN)
cmdScan.help = "Пересканировать все двери карты"

-- ─── ulx ds_admin ────────────────────────────────────────────────
local function cmd_admin(calling_ply)
    if not IsValid(calling_ply) then return end
    net.Start("DS_AdminAction")
    net.WriteString("get_all")
    net.Send(calling_ply)
    net.Start("DS_DoorScan")
    net.Send(calling_ply)
end

local cmdAdmin = ulx.command("Door System", "ulx ds_admin", cmd_admin, "!ds_admin")
cmdAdmin:defaultAccess(ULib.ACCESS_ADMIN)
cmdAdmin.help = "Открыть панель администратора Door System"

print("[DS] ULX/ULib v2.0 загружен — 10 команд зарегистрировано")
