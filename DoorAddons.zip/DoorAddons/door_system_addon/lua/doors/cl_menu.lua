--[[--------------------------------------------------------------------
    DOOR SYSTEM v2.0 — Меню настройки двери (клиент, ПОЛНЫЙ ПЕРЕЗАПИС)

    Протокол v2:
      • DS_SyncDoor = ReadString(id) + ReadTable(data)
      • DS_SetDoorData отправляет ReadTable с lowercase-полями:
        action, entidx, name, access, category, factions, roles,
        target_steam, duration, for_sale, sale_price
      • DS_SyncFactions — список [{name,tag,r,g,b}]
      • DS_SyncWhitelist — [{steam,nick}] для конкретной двери
      • DS_RequestWhitelist — запросить whitelist (ReadString doorID)

    Функции из cl_hud.lua:
      DS_GetDoorByEnt(ent) -> data, id
      DS_GetMyKeyRing()    -> {keyID={name,r,g,b,door_id}}
      DS_GetCategories()   -> [{name,r,g,b}]
      DS_Notify(msg, kind)
--------------------------------------------------------------------]]

-- ─── Клиентский кэш фракций (из DS_SyncFactions через хук) ───────
local FactionList = {}   -- [{name, tag, r, g, b}]
local WLCache     = {}   -- [doorID] = [{steam,nick}]

-- Единственный net.Receive("DS_SyncFactions") находится в cl_hud.lua.
-- Здесь подписываемся на хук который он вызывает после обновления данных.
hook.Add("DS_FactionsListUpdated", "DS_Menu_FacList", function(list)
    FactionList = list
end)

net.Receive("DS_SyncWhitelist", function()
    local doorID = net.ReadString()
    WLCache[doorID] = net.ReadTable() or {}
end)

-- ─── Цветовая схема (v2: DS.COL) ─────────────────────────────────
local C = DS.COL  -- DS.COL определён в sh_door_system.lua

-- ─── Шрифты ──────────────────────────────────────────────────────
surface.CreateFont("DSM_Title",  { font="Roboto Bold", size=20, weight=800 })
surface.CreateFont("DSM_Tab",    { font="Roboto",      size=14, weight=700 })
surface.CreateFont("DSM_Label",  { font="Roboto",      size=14, weight=500 })
surface.CreateFont("DSM_Small",  { font="Roboto",      size=12, weight=400 })
surface.CreateFont("DSM_Btn",    { font="Roboto Bold", size=13, weight=700 })
surface.CreateFont("DSM_Sub",    { font="Roboto",      size=13, weight=400 })

-- ─── Утилиты рисования ───────────────────────────────────────────
local function rbox(x, y, w, h, r, col)  draw.RoundedBox(r, x, y, w, h, col) end
local function stxt(s, f, x, y, col, ax, ay)
    draw.SimpleText(s, f, x, y, col, ax or TEXT_ALIGN_LEFT, ay or TEXT_ALIGN_TOP)
end
local function outline(x, y, w, h, r, g, b, a)
    surface.SetDrawColor(r, g, b, a or 255)
    surface.DrawOutlinedRect(x, y, w, h, 1)
end

-- ─── Компоненты VGUI ─────────────────────────────────────────────
local function makeBtn(parent, text, x, y, w, h, col, onClick)
    local btn = vgui.Create("DButton", parent)
    btn:SetPos(x, y)
    btn:SetSize(w, h)
    btn:SetText("")
    local bc = col or Color(55, 100, 200)
    function btn:Paint(bw, bh)
        local hov = self:IsHovered()
        local c   = hov and Color(bc.r+25, bc.g+25, bc.b+25) or bc
        rbox(0, 0, bw, bh, 6, c)
        stxt(text, "DSM_Btn", bw/2, bh/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    btn.DoClick = onClick
    return btn
end

local function makeEntry(parent, x, y, w, h, placeholder, default)
    local e = vgui.Create("DTextEntry", parent)
    e:SetPos(x, y)
    e:SetSize(w, h)
    e:SetPlaceholderText(placeholder or "")
    e:SetValue(default or "")
    e:SetFont("DSM_Label")
    e:SetTextColor(Color(225, 232, 255))
    e:SetDrawBackground(false)
    function e:Paint(ew, eh)
        rbox(0, 0, ew, eh, 5, Color(20, 26, 52))
        outline(0, 0, ew, eh, 55, 80, 160, 160)
        self:DrawTextEntryText(Color(225,232,255), Color(70,110,230), Color(255,255,255))
    end
    return e
end

local function makeCombo(parent, x, y, w, h)
    local cb = vgui.Create("DComboBox", parent)
    cb:SetPos(x, y)
    cb:SetSize(w, h)
    cb:SetFont("DSM_Label")
    cb:SetTextColor(Color(225, 232, 255))
    cb:SetDrawBackground(false)
    function cb:Paint(cw, ch)
        rbox(0, 0, cw, ch, 5, Color(20, 26, 52))
        outline(0, 0, cw, ch, 55, 80, 160, 160)
        stxt(self:GetValue(), "DSM_Label", 10, ch/2, Color(225,232,255),
             TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        -- Стрелка
        surface.SetDrawColor(120, 140, 200)
        local ax, ay = cw - 14, ch/2 - 2
        surface.DrawLine(ax,   ay,   ax+6, ay+6)
        surface.DrawLine(ax+6, ay+6, ax+12, ay)
    end
    return cb
end

local function sectionLbl(parent, text, x, y, col)
    local l = vgui.Create("DLabel", parent)
    l:SetPos(x, y)
    l:SetAutoStretchVertical(true)
    l:SetWide(390)
    l:SetText(text)
    l:SetFont("DSM_Sub")
    l:SetTextColor(col or C.DIM)
    return l
end

-- ─── Разделитель ─────────────────────────────────────────────────
local function separator(parent, x, y, w)
    local p = vgui.Create("DPanel", parent)
    p:SetPos(x, y)
    p:SetSize(w, 1)
    function p:Paint(pw, ph) draw.RoundedBox(0,0,0,pw,ph, Color(50,65,120,150)) end
    return p
end

-- ─── Singleton ────────────────────────────────────────────────────
local openMenu    = nil
local _menuOwners = {}   -- owners на момент открытия (для авто-закрытия)

-- Закрыть расширенное меню если игрок больше не суперадмин
function DS_CloseMenuIfNoPerms()
    if not IsValid(openMenu) then return end
    if not LocalPlayer():IsSuperAdmin() then
        openMenu:Remove()
    end
end

-- ═══════════════════════════════════════════════════════════════════
-- F4 / R: ПРОСТОЕ МЕНЮ — три действия, без валюты
--   • Приобрести дверь  (если свободна) + выбор срока аренды
--   • Дать имя двери    (если твоя)
--   • Освободить дверь  (если твоя)
-- ═══════════════════════════════════════════════════════════════════
function DS_OpenSimpleMenu(ent)
    if IsValid(openMenu) then openMenu:Remove() end
    if not IsValid(ent) then return end

    net.Start("DS_RequestDoorData")
    net.WriteInt(ent:EntIndex(), 16)
    net.SendToServer()

    local entIdx  = ent:EntIndex()
    local mySteam = LocalPlayer():SteamID()
    local selDur  = 0   -- выбранный срок аренды в секундах (0 = ∞)

    local durPresets = {
        { label="∞",   secs=0        },
        { label="1ч",  secs=3600     },
        { label="6ч",  secs=21600    },
        { label="12ч", secs=43200    },
        { label="1д",  secs=86400    },
        { label="3д",  secs=259200   },
        { label="7д",  secs=604800   },
        { label="30д", secs=2592000  },
    }

    local function getData()
        local d = DS_GetDoorByEnt(ent)
        return d or {}
    end

    local W = 340

    local frame = vgui.Create("DFrame")
    frame:SetTitle("")
    frame:SetDraggable(true)
    frame:MakePopup()
    openMenu = frame

    function frame:Paint(fw, fh)
        rbox(4, 4, fw, fh, 10, Color(0,0,0,90))
        rbox(0, 0, fw, fh, 10, Color(8, 12, 28, 250))
        rbox(0, 0, fw, 4,  10, C.ACCENT)
        local d  = getData()
        local nm = (d.name and d.name ~= "") and d.name or "Дверь"
        stxt(nm,        "DSM_Title", fw/2, 10, C.TEXT, TEXT_ALIGN_CENTER)
        stxt("F4 / R",  "DSM_Small", fw/2, 32, C.DIM,  TEXT_ALIGN_CENTER)
    end

    local xBtn = vgui.Create("DButton", frame)
    xBtn:SetPos(W - 34, 6); xBtn:SetSize(26, 26); xBtn:SetText("")
    function xBtn:Paint(bw, bh)
        rbox(0,0,bw,bh,4, self:IsHovered() and Color(180,40,40) or Color(100,30,30))
        stxt("✕","DSM_Small",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
    end
    xBtn.DoClick = function() frame:Remove() end

    -- ── Строим содержимое один раз после синхронизации данных ─────
    timer.Simple(0.35, function()
        if not IsValid(frame) then return end

        local d      = getData()
        local owners = d.owners or {}
        local myOwn  = owners[mySteam]
        local hasOwn = next(owners) ~= nil
        local iAmOwner = myOwn and myOwn.owner_type == DS.OWNER_TYPE.OWNER
        local canEdit  = iAmOwner or LocalPlayer():IsSuperAdmin()

        local PW = W - 20
        local y  = 46

        -- ══ 1. ПРИОБРЕСТИ ДВЕРЬ ══════════════════════════════════
        local isGovDoor = d.access == DS.ACCESS.FACTION or d.access == DS.ACCESS.FACTION_ROLE
        if isGovDoor then
            -- Государственная дверь — захват недоступен
            local lbl = vgui.Create("DLabel", frame)
            lbl:SetPos(10, y); lbl:SetSize(PW, 36)
            lbl:SetText("🏛 Государственная дверь — захват недоступен")
            lbl:SetFont("DSM_Small"); lbl:SetTextColor(Color(220, 160, 60))
            lbl:SetWrap(true)
            y = y + 40
        elseif not hasOwn then
            -- Метка «Срок аренды»
            local lbl = vgui.Create("DLabel", frame)
            lbl:SetPos(10, y); lbl:SetSize(PW, 16)
            lbl:SetText("Срок аренды:")
            lbl:SetFont("DSM_Small"); lbl:SetTextColor(C.DIM)
            y = y + 18

            -- Сегменты срока: ряд кнопок
            local n    = #durPresets
            local gap  = 3
            local segW = math.floor((PW - gap*(n-1)) / n)
            for i, dur in ipairs(durPresets) do
                local bx = 10 + (i-1)*(segW+gap)
                local seg = vgui.Create("DButton", frame)
                seg:SetPos(bx, y); seg:SetSize(segW, 26); seg:SetText("")
                function seg:Paint(bw, bh)
                    local sel = (dur.secs == selDur)
                    rbox(0,0,bw,bh,4, sel and C.ACCENT or Color(25,35,70))
                    local tc = sel and Color(255,255,255) or C.DIM
                    stxt(dur.label,"DSM_Small",bw/2,bh/2,tc,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
                end
                seg.DoClick = function() selDur = dur.secs end
            end
            y = y + 32

            -- Кнопка «Приобрести»
            local btn = vgui.Create("DButton", frame)
            btn:SetPos(10, y); btn:SetSize(PW, 32); btn:SetText("")
            function btn:Paint(bw, bh)
                rbox(0,0,bw,bh,6, self:IsHovered() and Color(45,140,70) or Color(30,105,55))
                stxt("Приобрести дверь","DSM_Label",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            btn.DoClick = function()
                net.Start("DS_SetDoorData")
                net.WriteTable({ action="claim", entidx=entIdx, duration=selDur })
                net.SendToServer()
                frame:Remove()
            end
            y = y + 38
        end

        -- ══ 2. НАЗВАНИЕ ДВЕРИ ════════════════════════════════════
        if canEdit then
            local nameE = makeEntry(frame, 10, y, PW - 124, 32,
                "Название двери...", d.name or "")
            local saveB = vgui.Create("DButton", frame)
            saveB:SetPos(PW - 112, y); saveB:SetSize(122, 32); saveB:SetText("")
            function saveB:Paint(bw, bh)
                rbox(0,0,bw,bh,6, self:IsHovered() and Color(50,110,210) or Color(35,80,165))
                stxt("Сохранить","DSM_Small",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            saveB.DoClick = function()
                local v = nameE:GetValue()
                if v == "" then DS_Notify("Введите название", "error"); return end
                net.Start("DS_SetDoorData")
                net.WriteTable({ action="update", entidx=entIdx, name=v })
                net.SendToServer()
                DS_Notify("Имя сохранено", "success")
            end
            y = y + 38

            -- ══ 3. ОСВОБОДИТЬ ДВЕРЬ ══════════════════════════════
            local relB = vgui.Create("DButton", frame)
            relB:SetPos(10, y); relB:SetSize(PW, 32); relB:SetText("")
            function relB:Paint(bw, bh)
                rbox(0,0,bw,bh,6, self:IsHovered() and Color(185,45,45) or Color(135,28,28))
                stxt("Освободить дверь","DSM_Label",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            relB.DoClick = function()
                net.Start("DS_SetDoorData")
                net.WriteTable({ action="release", entidx=entIdx })
                net.SendToServer()
                DS_Notify("Дверь освобождена", "success")
                frame:Remove()
            end
            y = y + 38
        end

        -- ══ Нет доступных действий ═══════════════════════════════
        if hasOwn and not canEdit then
            local lbl = vgui.Create("DLabel", frame)
            lbl:SetPos(10, y); lbl:SetSize(PW, 36)
            lbl:SetText("Дверь занята. Нет доступных действий.")
            lbl:SetFont("DSM_Small"); lbl:SetTextColor(C.DIM)
            lbl:SetWrap(true)
            y = y + 40
        end

        frame:SetSize(W, y + 10)
        frame:Center()
    end)
end

-- Экспорт: проверить открыто ли любое DS-меню (используется HUD и SWEP)
function DS_IsMenuOpen() return IsValid(openMenu) end

-- ─── Открыть меню ─────────────────────────────────────────────────
function DS_OpenDoorMenu(ent)
    if IsValid(openMenu) then openMenu:Remove() end
    if not IsValid(ent) then return end

    -- Свежие данные
    net.Start("DS_RequestDoorData")
    net.WriteInt(ent:EntIndex(), 16)
    net.SendToServer()

    local entIdx  = ent:EntIndex()
    local mySteam = LocalPlayer():SteamID()

    -- isSA всегда пересчитывается актуально
    local function isSA()     return LocalPlayer():IsSuperAdmin() end
    local function getData()
        local d, _ = DS_GetDoorByEnt(ent)
        return d or {}
    end
    local function getOwners() return getData().owners or {} end
    local function isOwner()
        if isSA() then return true end
        local o = getOwners()[mySteam]
        return o and o.owner_type == DS.OWNER_TYPE.OWNER
    end
    local function isCoowner()
        if isSA() then return true end
        return getOwners()[mySteam] ~= nil
    end
    local function doorID()
        local _, id = DS_GetDoorByEnt(ent)
        return id or ""
    end

    -- ── Главное окно (полное, только для суперадмина) ─────────────
    local W, H = 460, 540
    local frame = vgui.Create("DFrame")
    frame:SetTitle("")
    frame:SetSize(W, H)
    frame:Center()
    frame:SetDraggable(true)
    frame:MakePopup()
    frame:SetPaintedManually(false)
    openMenu = frame

    -- Авто-закрытие если права были сняты пока меню открыто
    function frame:Think()
        if not LocalPlayer():IsSuperAdmin() then
            self:Remove()
        end
    end

    function frame:Paint(fw, fh)
        -- Тень
        rbox(4, 4, fw, fh, 12, Color(0,0,0,80))
        -- Фон
        rbox(0, 0, fw, fh, 12, Color(8, 12, 28, 248))
        -- Полоса акцента
        rbox(0, 0, fw, 4, 12, C.ACCENT)
        rbox(0, 2, fw, 2, 0, C.ACCENT)
        -- Заголовок
        stxt("Настройки двери", "DSM_Title", fw/2, 18, C.TEXT, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
        -- Имя двери под заголовком
        local d  = getData()
        local nm = (d.name and d.name ~= "") and d.name or "Безымянная дверь"
        stxt(nm, "DSM_Small", fw/2, 44, C.DIM, TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
    end

    -- Кнопка закрыть (рисованная, не дефолтный Х)
    local xBtn = vgui.Create("DButton", frame)
    xBtn:SetPos(W - 36, 8)
    xBtn:SetSize(28, 28)
    xBtn:SetText("")
    function xBtn:Paint(bw, bh)
        rbox(0, 0, bw, bh, 5, self:IsHovered() and Color(180,40,40) or Color(100,30,30))
        stxt("✕", "DSM_Label", bw/2, bh/2, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
    xBtn.DoClick = function() frame:Remove() end

    -- ── Вкладки ─────────────────────────────────────────────────
    -- Нарисуем вкладки вручную, т.к. DPropertySheet не стилизуется
    local TABS   = { "Основное", "Совладельцы", "Фракции", "Белый список", "Ключи" }
    local tabIdx = 1
    local panels = {}

    local tabBar = vgui.Create("DPanel", frame)
    tabBar:SetPos(10, 62)
    tabBar:SetSize(W - 20, 30)
    function tabBar:Paint() end   -- прозрачная

    local content = vgui.Create("DPanel", frame)
    content:SetPos(10, 96)
    content:SetSize(W - 20, H - 106)
    function content:Paint(cw, ch)
        rbox(0, 0, cw, ch, 8, Color(14, 18, 40, 230))
        outline(0, 0, cw, ch, 50, 65, 120, 130)
    end

    local tabBtns = {}
    local tabW    = (W - 20) / #TABS

    local function switchTab(idx)
        tabIdx = idx
        for i, pan in ipairs(panels) do
            pan:SetVisible(i == idx)
        end
        for i, btn in ipairs(tabBtns) do
            btn._active = (i == idx)
        end
    end

    for i, name in ipairs(TABS) do
        local btn = vgui.Create("DButton", tabBar)
        btn:SetPos((i-1)*tabW, 0)
        btn:SetSize(tabW, 30)
        btn:SetText("")
        btn._active = (i == 1)
        function btn:Paint(bw, bh)
            local ac = self._active
            rbox(0, 0, bw, bh, ac and 6 or 4,
                 ac and Color(38, 80, 180, 220) or Color(20, 28, 55, 180))
            if ac then
                rbox(0, bh-2, bw, 2, 0, C.ACCENT)
            end
            stxt(name, "DSM_Tab", bw/2, bh/2,
                 ac and C.TEXT or C.DIM,
                 TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        btn.DoClick = function() switchTab(i) end
        tabBtns[i] = btn
    end

    -- ── Вспомогательная: создать скролл-панель ───────────────────
    local function makePanel()
        local p = vgui.Create("DScrollPanel", content)
        p:SetPos(0, 0)
        p:SetSize(content:GetWide(), content:GetTall())
        function p:Paint() end
        local sbar = p:GetVBar()
        sbar:SetWide(4)
        function sbar:Paint(sw, sh)   rbox(0,0,sw,sh,2,Color(20,25,50)) end
        function sbar.btnUp:Paint()   end
        function sbar.btnDown:Paint() end
        function sbar.btnGrip:Paint(sw,sh) rbox(0,0,sw,sh,2,Color(70,100,200,180)) end
        table.insert(panels, p)
        p:SetVisible(#panels == 1)
        return p
    end

    -- =================================================================
    -- ВКЛ 1: Основное
    -- =================================================================
    local panMain = makePanel()
    local PW = content:GetWide() - 16   -- ширина контента

    local d = getData()

    -- Название
    local nameY = 12
    sectionLbl(panMain, "Название двери", 12, nameY)
    local nameEntry = makeEntry(panMain, 12, nameY+20, PW, 32, "Название...", d.name or "")

    -- Категория
    local catY = nameY + 62
    sectionLbl(panMain, "Категория", 12, catY)
    local catCombo = makeCombo(panMain, 12, catY+20, PW, 32)
    local catList  = DS_GetCategories()
    if not catList or #catList == 0 then
        catList = DS.DEFAULT_CATEGORIES or {{ name = "Без категории" }}
    end
    local curCatIdx = 1
    local catCount  = 0
    for i, cat in ipairs(catList) do
        catCombo:AddChoice(cat.name, cat.name)
        catCount = catCount + 1
        if cat.name == d.category then curCatIdx = i end
    end
    if catCount > 0 then
        catCombo:ChooseOptionID(curCatIdx)
    end

    -- Тип доступа
    local accY = catY + 62
    sectionLbl(panMain, "Тип доступа", 12, accY)
    local accCombo = makeCombo(panMain, 12, accY+20, PW, 32)
    local accOpts  = {
        { DS.ACCESS.PUBLIC,       "Публичный — все могут войти"   },
        { DS.ACCESS.PRIVATE,      "Приватный — только владелец"   },
        { DS.ACCESS.FACTION,      "Фракция"                       },
        { DS.ACCESS.FACTION_ROLE, "Фракция + Роль"                },
        { DS.ACCESS.WHITELIST,    "Белый список"                  },
        { DS.ACCESS.KEY,          "По ключу"                      },
        { DS.ACCESS.OWNER_ONLY,   "Только владелец"               },
    }
    local curAccIdx = 1
    local accCount  = 0
    for i, o in ipairs(accOpts) do
        accCombo:AddChoice(o[2], o[1])
        accCount = accCount + 1
        if o[1] == d.access then curAccIdx = i end
    end
    if accCount > 0 then
        accCombo:ChooseOptionID(curAccIdx)
    end

    separator(panMain, 12, accY+62, PW)

    -- Статус владельца
    local ownY   = accY + 72
    local owners = d.owners or {}
    local ownTxts = {}
    for s, o in pairs(owners) do
        local badge = o.owner_type == DS.OWNER_TYPE.OWNER and "[Вл]" or "[Св]"
        local expire = o.expires_at and o.expires_at > 0
            and (" ← " .. DS.FormatTime(DS.TimeLeft(o.expires_at))) or ""
        table.insert(ownTxts, badge .. " " .. (o.nick or s) .. expire)
    end
    local ownStr = #ownTxts > 0 and table.concat(ownTxts, "  ") or "Нет владельца"
    sectionLbl(panMain, "Владельцы: " .. ownStr, 12, ownY, Color(150,210,130))

    -- Кнопки захвата / отказа
    local btnY = ownY + 24
    local hasOwner = next(owners) ~= nil
    local myOwn    = owners[mySteam]

    local isGovDoorFull = d.access == DS.ACCESS.FACTION or d.access == DS.ACCESS.FACTION_ROLE
    if isGovDoorFull and not isSA() then
        -- Государственная дверь — захват недоступен
        local govLbl = vgui.Create("DLabel", panMain)
        govLbl:SetPos(12, btnY); govLbl:SetSize(PW, 36)
        govLbl:SetText("🏛 Государственная дверь — захват недоступен")
        govLbl:SetFont("DSM_Small"); govLbl:SetTextColor(Color(220, 160, 60))
        govLbl:SetWrap(true)
        btnY = btnY + 40
    elseif not hasOwner then
        -- Нет владельца — предложить захватить
        sectionLbl(panMain, "Срок аренды (дни, 0 = бессрочно):", 12, btnY)
        local durEntry = makeEntry(panMain, 12, btnY+20, 100, 28, "0", "0")
        makeBtn(panMain, "Захватить дверь", 122, btnY+20, PW-110, 28, Color(35,115,60), function()
            local days = tonumber(durEntry:GetValue()) or 0
            net.Start("DS_SetDoorData")
            net.WriteTable({ action="claim", entidx=entIdx, duration=days*86400 })
            net.SendToServer()
            frame:Remove()
        end)
        btnY = btnY + 58
    elseif myOwn and myOwn.owner_type == DS.OWNER_TYPE.OWNER or isSA() then
        makeBtn(panMain, "Продлить аренду на 30 дней", 12, btnY, PW/2-8, 30, Color(40,110,170), function()
            net.Start("DS_SetDoorData")
            net.WriteTable({ action="renew", entidx=entIdx, duration=2592000 })
            net.SendToServer()
        end)
        makeBtn(panMain, "Отказаться от двери", PW/2+8, btnY, PW/2-8, 30, Color(140,40,40), function()
            net.Start("DS_SetDoorData")
            net.WriteTable({ action="unclaim", entidx=entIdx })
            net.SendToServer()
            frame:Remove()
        end)
        btnY = btnY + 40
    end

    -- Замок
    local isLocked = d.locked or false
    if isCoowner() then
        makeBtn(panMain, isLocked and "Разблокировать" or "Заблокировать",
            12, btnY, PW, 30,
            isLocked and Color(45,170,80) or Color(160,55,55), function()
            net.Start("DS_LockDoor")
            net.WriteInt(entIdx, 16)
            net.SendToServer()
            frame:Remove()
        end)
        btnY = btnY + 40
    end

    separator(panMain, 12, btnY, PW)
    btnY = btnY + 10

    -- Кнопка сохранить настройки
    makeBtn(panMain, "Сохранить настройки", 12, btnY, PW, 36, Color(40,110,200), function()
        local _, accID  = accCombo:GetSelected()
        local _, catID  = catCombo:GetSelected()
        net.Start("DS_SetDoorData")
        net.WriteTable({
            action   = "update",
            entidx   = entIdx,
            name     = nameEntry:GetValue(),
            access   = accID or DS.ACCESS.PUBLIC,
            category = catID or "Без категории",
        })
        net.SendToServer()
        frame:Remove()
    end)

    -- =================================================================
    -- ВКЛ 2: Совладельцы
    -- =================================================================
    local panCo = makePanel()
    local coY   = 12

    sectionLbl(panCo, "Добавить совладельца (онлайн игроки):", 12, coY)
    coY = coY + 22

    local coList = makeCombo(panCo, 12, coY, PW - 130, 30)
    for _, p in ipairs(player.GetAll()) do
        if p ~= LocalPlayer() then coList:AddChoice(p:Nick(), p:SteamID()) end
    end

    makeBtn(panCo, "+ Добавить", PW - 112, coY, 110, 30, Color(35,115,60), function()
        local _, tSteam = coList:GetSelected()
        if not tSteam then DS_Notify("Выберите игрока", "error") return end
        net.Start("DS_SetDoorData")
        net.WriteTable({ action="add_coowner", entidx=entIdx, target_steam=tSteam })
        net.SendToServer()
    end)
    coY = coY + 42

    separator(panCo, 12, coY, PW); coY = coY + 12

    sectionLbl(panCo, "Текущие совладельцы:", 12, coY); coY = coY + 22

    local coDone = false
    for steam, o in pairs(getOwners()) do
        coDone = true
        local isCo = o.owner_type == DS.OWNER_TYPE.COOWNER
        local badge = isCo and "Совладелец" or "Владелец"
        local badgCol = isCo and C.COOWNER or C.OWNER

        local row = vgui.Create("DPanel", panCo)
        row:SetPos(12, coY)
        row:SetSize(PW, 34)
        function row:Paint(rw, rh)
            rbox(0, 0, rw, rh, 5, Color(18, 24, 50))
            outline(0, 0, rw, rh, 50, 65, 120, 100)
            -- Полоска цвета
            rbox(0, 0, 3, rh, 2, badgCol)
            stxt(o.nick or steam, "DSM_Label", 12, rh/2, C.TEXT,
                 TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            stxt(badge, "DSM_Small", rw-100, rh/2, badgCol,
                 TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            -- Время
            if o.expires_at and o.expires_at > 0 then
                local tl = DS.TimeLeft(o.expires_at)
                local tc = tl < 3600 and C.WARNING or C.DIM
                stxt(DS.FormatTime(tl), "DSM_Small", rw-10, rh/2, tc,
                     TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
        end

        if isCo and (isOwner() or isSA()) then
            local rmBtn = vgui.Create("DButton", row)
            rmBtn:SetPos(PW - 24, 7)
            rmBtn:SetSize(20, 20)
            rmBtn:SetText("")
            local rm_steam = steam
            function rmBtn:Paint(bw, bh)
                rbox(0,0,bw,bh,4, self:IsHovered() and Color(180,40,40) or Color(100,25,25))
                stxt("✕","DSM_Small",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            rmBtn.DoClick = function()
                net.Start("DS_SetDoorData")
                net.WriteTable({ action="rm_coowner", entidx=entIdx, target_steam=rm_steam })
                net.SendToServer()
                row:Remove()
            end
        end

        coY = coY + 38
    end
    if not coDone then
        sectionLbl(panCo, "Нет совладельцев", 12, coY, C.DIM)
    end

    -- =================================================================
    -- ВКЛ 3: Фракции
    -- =================================================================
    local panFac = makePanel()
    local fY = 12

    sectionLbl(panFac, "Фракции с доступом (выберите):", 12, fY); fY = fY + 24

    local selFac = {}
    local curFacs = (getData().factions) or {}
    for _, f in ipairs(curFacs) do selFac[f] = true end

    local fRows = {}
    if #FactionList == 0 then
        sectionLbl(panFac, "Фракции не загружены. Ждите синхронизации...", 12, fY, C.WARNING)
        fY = fY + 22
    else
        for _, fdata in ipairs(FactionList) do
            local fname = fdata.name
            local fc    = Color(fdata.r, fdata.g, fdata.b)
            local tag   = fdata.tag or string.upper(string.sub(fname, 1, 4))

            local chk   = selFac[fname] or false
            local row   = vgui.Create("DPanel", panFac)
            row:SetPos(12, fY)
            row:SetSize(PW, 36)

            local rdata = { checked=chk, name=fname }
            fRows[fname] = rdata

            function row:Paint(rw, rh)
                local bg = rdata.checked and Color(fc.r,fc.g,fc.b,40) or Color(18,24,50)
                rbox(0, 0, rw, rh, 5, bg)
                outline(0, 0, rw, rh, fc.r, fc.g, fc.b, rdata.checked and 180 or 50)
                -- Tag pill
                rbox(8, 8, 32, 20, 4, Color(fc.r,fc.g,fc.b, rdata.checked and 200 or 80))
                stxt(tag, "DSM_Small", 24, 9, Color(255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
                -- Имя
                stxt(fname, "DSM_Label", 50, rh/2, rdata.checked and C.TEXT or C.DIM,
                     TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
                -- Галочка
                if rdata.checked then
                    stxt("✓", "DSM_Label", rw-14, rh/2, Color(fc.r,fc.g,fc.b),
                         TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
                end
            end
            row:SetMouseInputEnabled(true)
            row.OnMousePressed = function()
                rdata.checked = not rdata.checked
                selFac[fname] = rdata.checked or nil
            end

            fY = fY + 42
        end
    end

    separator(panFac, 12, fY, PW); fY = fY + 10

    makeBtn(panFac, "Применить фракции", 12, fY, PW, 34, Color(40,110,190), function()
        local facList = {}
        for f, v in pairs(selFac) do if v then table.insert(facList, f) end end
        net.Start("DS_SetDoorData")
        net.WriteTable({ action="update", entidx=entIdx, factions=facList })
        net.SendToServer()
        DS_Notify("Фракции сохранены", "success")
    end)

    -- =================================================================
    -- ВКЛ 4: Белый список
    -- =================================================================
    local panWL  = makePanel()
    local wlY    = 12
    local did    = doorID()

    sectionLbl(panWL, "Добавить в белый список:", 12, wlY); wlY = wlY + 22

    local wlPList = makeCombo(panWL, 12, wlY, PW - 130, 30)
    for _, p in ipairs(player.GetAll()) do
        if p ~= LocalPlayer() then wlPList:AddChoice(p:Nick(), p:SteamID()) end
    end

    makeBtn(panWL, "Добавить", PW - 112, wlY, 110, 30, Color(35,115,60), function()
        local _, tSteam = wlPList:GetSelected()
        if not tSteam then DS_Notify("Выберите игрока", "error") return end
        net.Start("DS_SetDoorData")
        net.WriteTable({ action="wl_add", entidx=entIdx, target_steam=tSteam })
        net.SendToServer()
        -- Обновить WL
        timer.Simple(0.5, function()
            net.Start("DS_RequestWhitelist")
            net.WriteString(did)
            net.SendToServer()
        end)
    end)
    wlY = wlY + 42

    separator(panWL, 12, wlY, PW); wlY = wlY + 12

    -- Запросить whitelist
    net.Start("DS_RequestWhitelist")
    net.WriteString(did)
    net.SendToServer()

    sectionLbl(panWL, "Текущий белый список:", 12, wlY); wlY = wlY + 24

    -- Scroll-контейнер для WL
    local wlScroll = vgui.Create("DScrollPanel", panWL)
    wlScroll:SetPos(12, wlY)
    wlScroll:SetSize(PW, 220)
    function wlScroll:Paint(sw, sh)
        rbox(0,0,sw,sh,6,Color(14,18,40))
        outline(0,0,sw,sh, 50,65,120,100)
    end
    local wlSbar = wlScroll:GetVBar()
    wlSbar:SetWide(4)
    function wlSbar:Paint(sw,sh)     rbox(0,0,sw,sh,2,Color(20,25,50)) end
    function wlSbar.btnUp:Paint()    end
    function wlSbar.btnDown:Paint()  end
    function wlSbar.btnGrip:Paint(sw,sh) rbox(0,0,sw,sh,2,Color(70,100,200,180)) end

    -- Функция обновления списка WL в реальном времени
    local wlItems = {}
    local function rebuildWL()
        for _, item in ipairs(wlItems) do
            if IsValid(item) then item:Remove() end
        end
        wlItems = {}
        local list = WLCache[did] or {}
        if #list == 0 then
            local empty = sectionLbl(wlScroll, "Список пуст", 10, 8, C.DIM)
            table.insert(wlItems, empty)
            return
        end
        local wy = 6
        for _, entry in ipairs(list) do
            local r = vgui.Create("DPanel", wlScroll)
            r:SetPos(6, wy)
            r:SetSize(wlScroll:GetWide() - 12, 32)
            local eName = entry.nick or entry.steam
            local eSteam = entry.steam
            function r:Paint(rw, rh)
                rbox(0,0,rw,rh,5,Color(20,26,52))
                rbox(0,0,3,rh,2,C.ACCENT)
                stxt(eName,  "DSM_Label", 10, rh/2, C.TEXT, TEXT_ALIGN_LEFT,  TEXT_ALIGN_CENTER)
                stxt(eSteam, "DSM_Small", rw-10, rh/2, C.DIM, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER)
            end
            -- Кнопка убрать
            local rmWL = vgui.Create("DButton", r)
            rmWL:SetPos(r:GetWide() - 55, 6)
            rmWL:SetSize(46, 20)
            rmWL:SetText("")
            local cap_steam = eSteam
            function rmWL:Paint(bw,bh)
                rbox(0,0,bw,bh,4, self:IsHovered() and Color(160,40,40) or Color(100,25,25))
                stxt("Убрать","DSM_Small",bw/2,bh/2,Color(255,255,255),TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER)
            end
            rmWL.DoClick = function()
                net.Start("DS_SetDoorData")
                net.WriteTable({ action="wl_remove", entidx=entIdx, target_steam=cap_steam })
                net.SendToServer()
                timer.Simple(0.5, function()
                    net.Start("DS_RequestWhitelist")
                    net.WriteString(did)
                    net.SendToServer()
                end)
            end
            table.insert(wlItems, r)
            wy = wy + 36
        end
    end

    -- Обновлять список при получении данных
    local oldWLReceive = net.Receivers["DS_SyncWhitelist"]
    net.Receive("DS_SyncWhitelist", function()
        local wdoorID = net.ReadString()
        WLCache[wdoorID] = net.ReadTable() or {}
        if wdoorID == did and IsValid(panWL) then
            rebuildWL()
        end
    end)

    rebuildWL()

    -- =================================================================
    -- ВКЛ 5: Ключи
    -- =================================================================
    local panKeys = makePanel()
    local kY = 12

    sectionLbl(panKeys, "Выдать ключ игроку:", 12, kY); kY = kY + 22

    local kPList = makeCombo(panKeys, 12, kY, PW - 130, 30)
    for _, p in ipairs(player.GetAll()) do
        if p ~= LocalPlayer() then kPList:AddChoice(p:Nick(), p:SteamID()) end
    end
    makeBtn(panKeys, "Выдать", PW - 112, kY, 110, 30, Color(35,115,60), function()
        local _, tSteam = kPList:GetSelected()
        if not tSteam then DS_Notify("Выберите игрока", "error") return end
        net.Start("DS_Keys_Give")
        net.WriteInt(entIdx, 16)
        net.WriteString(tSteam)
        net.WriteString("")
        net.SendToServer()
    end)
    kY = kY + 42

    makeBtn(panKeys, "Отозвать ключ", 12, kY, PW, 30, Color(140,40,40), function()
        local _, tSteam = kPList:GetSelected()
        if not tSteam then DS_Notify("Выберите игрока", "error") return end
        net.Start("DS_Keys_Revoke")
        net.WriteInt(entIdx, 16)
        net.WriteString(tSteam)
        net.SendToServer()
    end)
    kY = kY + 42

    separator(panKeys, 12, kY, PW); kY = kY + 12

    sectionLbl(panKeys, "Моё кольцо ключей:", 12, kY); kY = kY + 22

    local ring   = DS_GetMyKeyRing()
    local hasAny = false
    for kid, kd in pairs(ring) do
        hasAny = true
        local kc = Color(kd.r or 255, kd.g or 215, kd.b or 0)
        local kr = vgui.Create("DPanel", panKeys)
        kr:SetPos(12, kY)
        kr:SetSize(PW, 36)
        local ownerLabel = kd.owner_steam or "?"
        function kr:Paint(rw, rh)
            rbox(0, 0, rw, rh, 5, Color(18, 24, 50))
            rbox(0, 0, 4, rh, 2, kc)
            stxt(kd.name or "Ключ", "DSM_Label", 12, rh/2 - 7, C.TEXT,
                 TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            stxt("владелец: " .. ownerLabel, "DSM_Small", 12, rh/2 + 7, C.DIM,
                 TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        kY = kY + 40
    end
    if not hasAny then
        sectionLbl(panKeys, "Ключей нет. Используй ds_givekey в консоли для теста.", 12, kY, C.DIM)
    end

    -- ── Первоначальное отображение ───────────────────────────────
    switchTab(1)
end

print("[DoorSystem] Меню v2.0 загружено")
